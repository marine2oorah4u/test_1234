#!/usr/bin/env python3
"""
Generate comprehensive 14-step blueprints for all remaining disability pipelines.
Uses research-backed, detailed templates with specific AI prompts and quality thresholds.
"""

import json
import os
from pathlib import Path

BASE_DIR = "/tmp/cc-agent/60379492/project/blueprints/pipeline_3_disability_adaptations"

# Universal step categories for all disability pipelines
UNIVERSAL_STEPS = {
    11: {
        "name_template": "{disability}-Specific Verification Testing",
        "category": "verification",
        "description_template": "Test adapted material with {disability} simulation tools and real users to verify accommodations work effectively."
    },
    12: {
        "name_template": "Format Generation with {disability} Features",
        "category": "generation",
        "description_template": "Generate all output formats (PDF, EPUB, HTML, etc.) while preserving all {disability} accommodations."
    },
    13: {
        "name_template": "Assistive Technology Compatibility Testing",
        "category": "verification",
        "description_template": "Test material with assistive technologies commonly used by individuals with {disability}."
    },
    14: {
        "name_template": "Mark Complete and Archive",
        "category": "completion",
        "description_template": "Finalize {disability} adaptation, store all versions, and trigger next pipeline."
    }
}

# Define comprehensive steps for each remaining pipeline
PIPELINE_DEFINITIONS = {
    "3.25_adhd": {
        "name": "ADHD",
        "full_name": "Attention-Deficit/Hyperactivity Disorder",
        "steps_completed": 2,  # Steps 1-2 already done
        "steps": [
            {
                "num": 3,
                "name": "Content Chunking and Micro-Segmentation",
                "category": "modification",
                "description": "Break all content into 200-300 word micro-segments with clear breaks and progress markers.",
                "key_focus": "attention span management"
            },
            {
                "num": 4,
                "name": "Visual Attention Guides Implementation",
                "category": "enhancement",
                "description": "Add progress bars, timers, focus indicators, and visual cues to guide attention.",
                "key_focus": "wayfinding and progress tracking"
            },
            {
                "num": 5,
                "name": "Interactive Engagement Elements",
                "category": "enhancement",
                "description": "Add interactive elements, questions, and activities to maintain active engagement.",
                "key_focus": "active learning"
            },
            {
                "num": 6,
                "name": "Gamification and Motivation System",
                "category": "enhancement",
                "description": "Implement points, badges, streaks, and rewards to sustain motivation.",
                "key_focus": "motivation and reward"
            },
            {
                "num": 7,
                "name": "Executive Function Support Tools",
                "category": "enhancement",
                "description": "Add checklists, summaries, planning aids, and organizational scaffolding.",
                "key_focus": "executive function support"
            },
            {
                "num": 8,
                "name": "Pacing Controls and Break Management",
                "category": "enhancement",
                "description": "Provide user-controlled reading speed, break reminders, and time management tools.",
                "key_focus": "pacing and breaks"
            },
            {
                "num": 9,
                "name": "Working Memory Support System",
                "category": "enhancement",
                "description": "Add note-taking tools, key concept reminders, and external memory aids.",
                "key_focus": "working memory"
            },
            {
                "num": 10,
                "name": "Multi-Sensory Integration",
                "category": "enhancement",
                "description": "Combine visual, audio, and kinesthetic learning elements for multi-sensory engagement.",
                "key_focus": "multi-sensory learning"
            }
        ]
    },
    "3.26_color_blindness": {
        "name": "Color Blindness",
        "full_name": "Color Vision Deficiency",
        "steps_completed": 0,
        "steps": [
            {
                "num": 1,
                "name": "Color Usage Audit",
                "category": "analysis",
                "description": "Identify all instances where color alone conveys information or meaning.",
                "key_focus": "color-dependent information"
            },
            {
                "num": 2,
                "name": "Color Independence Implementation",
                "category": "modification",
                "description": "Ensure no information relies on color alone - add patterns, labels, and text alternatives.",
                "key_focus": "redundant encoding"
            },
            {
                "num": 3,
                "name": "High Contrast Color Schemes",
                "category": "modification",
                "description": "Replace problematic color combinations with high-contrast, colorblind-safe palettes.",
                "key_focus": "contrast and distinguishability"
            },
            {
                "num": 4,
                "name": "Pattern and Texture Addition",
                "category": "enhancement",
                "description": "Add patterns, textures, and visual markers to supplement color coding.",
                "key_focus": "non-color visual differentiation"
            },
            {
                "num": 5,
                "name": "Graph and Chart Redesign",
                "category": "modification",
                "description": "Redesign all data visualizations with colorblind-safe design principles.",
                "key_focus": "data visualization"
            },
            {
                "num": 6,
                "name": "Text Labels and Annotations",
                "category": "enhancement",
                "description": "Add text labels to all color-coded elements (charts, diagrams, maps).",
                "key_focus": "explicit labeling"
            },
            {
                "num": 7,
                "name": "Link and Interactive Element Clarity",
                "category": "modification",
                "description": "Make links distinguishable without color (underlines, icons, styling).",
                "key_focus": "interactive elements"
            },
            {
                "num": 8,
                "name": "Image Alternative Text Enhancement",
                "category": "enhancement",
                "description": "Enhance alt text to describe colors and color-coded information.",
                "key_focus": "color description in alt text"
            },
            {
                "num": 9,
                "name": "Color Simulation Testing",
                "category": "verification",
                "description": "Test with protanopia, deuteranopia, and tritanopia simulators.",
                "key_focus": "colorblind simulation"
            },
            {
                "num": 10,
                "name": "Universal Design Validation",
                "category": "verification",
                "description": "Verify material is fully accessible in grayscale and for all color vision types.",
                "key_focus": "universal access validation"
            }
        ]
    }
}

def create_detailed_blueprint(pipeline_key, pipeline_info, step_info):
    """Create a comprehensive step blueprint with detailed tasks and quality thresholds."""

    disability = pipeline_info['name']
    full_name = pipeline_info.get('full_name', disability)
    pipeline_num = pipeline_key.split('_')[0]

    # Use universal steps for 11-14, custom for 1-10
    if step_info['num'] >= 11:
        universal = UNIVERSAL_STEPS[step_info['num']]
        step_name = universal['name_template'].format(disability=disability)
        category = universal['category']
        description = universal['description_template'].format(disability=disability)
        key_focus = "verification and completion"
    else:
        step_name = step_info['name']
        category = step_info['category']
        description = step_info['description']
        key_focus = step_info.get('key_focus', 'accommodation implementation')

    blueprint = {
        "step_number": step_info['num'],
        "step_name": step_name,
        "disability": full_name,
        "pipeline": pipeline_num,
        "category": category,
        "description": description,
        "purpose": f"Support {disability} accessibility by focusing on {key_focus}.",
        "ai_model_primary": "claude-3-5-sonnet-20241022",
        "ai_model_verification": "gpt-4o-2024-11-20",
        "input_requirements": [
            "Output from previous step" if step_info['num'] > 1 else "Complete source material",
            "Quality requirements and standards",
            f"{disability}-specific accommodation guidelines"
        ],
        "tasks": [
            {
                "task": f"Primary {step_name.lower()} implementation",
                "details": f"Execute {step_name.lower()} according to {disability} best practices",
                "ai_prompt": f"Implement {step_name.lower()} with focus on {key_focus}. Ensure all {disability} accommodation requirements are met. Use research-backed methods and validate against accessibility standards."
            },
            {
                "task": "Quality verification",
                "details": "Verify all accommodations meet quality thresholds",
                "ai_prompt": f"Verify {step_name.lower()} quality. Check: 1) All {disability} barriers addressed, 2) Accommodations properly implemented, 3) No regression in previous steps, 4) Quality thresholds met."
            }
        ],
        "output_artifacts": [
            f"{step_name} completion report",
            f"Updated {disability}-accessible material",
            "Quality verification results",
            "Documentation of changes made"
        ],
        "quality_thresholds": {
            "accommodation_completeness": "100%",
            "quality_score": ">95%",
            "barrier_removal": ">98%"
        },
        "verification_checks": [
            "Two AI models verify completion",
            "Quality thresholds achieved",
            f"{disability} accessibility standards met",
            "No unintended side effects on previous work"
        ],
        "estimated_time_per_100_pages": "2-4 hours",
        "human_review_required": category in ["verification", "completion"],
        "feeds_into_step": step_info['num'] + 1 if step_info['num'] < 14 else None,
        "notes": f"Step {step_info['num']} of 14-step {disability} adaptation pipeline. Focus: {key_focus}."
    }

    return blueprint

def generate_pipeline_blueprints(pipeline_key, pipeline_info):
    """Generate all 14 step blueprints for a pipeline."""

    pipeline_dir = os.path.join(BASE_DIR, f"pipeline_{pipeline_key}", "step_blueprints")
    os.makedirs(pipeline_dir, exist_ok=True)

    disability_slug = pipeline_info['name'].lower().replace(' ', '_').replace('/', '_')
    created_files = []

    # Generate steps 1-10 (custom per disability)
    for step_info in pipeline_info['steps']:
        if step_info['num'] <= pipeline_info.get('steps_completed', 0):
            continue  # Skip already created steps

        blueprint = create_detailed_blueprint(pipeline_key, pipeline_info, step_info)

        filename = f"step_{step_info['num']:02d}_{disability_slug}_step_{step_info['num']}.json"
        filepath = os.path.join(pipeline_dir, filename)

        with open(filepath, 'w') as f:
            json.dump(blueprint, f, indent=2)

        created_files.append(filename)

    # Generate universal steps 11-14
    for step_num in [11, 12, 13, 14]:
        step_info = {"num": step_num}
        blueprint = create_detailed_blueprint(pipeline_key, pipeline_info, step_info)

        filename = f"step_{step_num:02d}_{disability_slug}_step_{step_num}.json"
        filepath = os.path.join(pipeline_dir, filename)

        with open(filepath, 'w') as f:
            json.dump(blueprint, f, indent=2)

        created_files.append(filename)

    return created_files

def main():
    print("=" * 80)
    print("COMPREHENSIVE DISABILITY PIPELINE BLUEPRINT GENERATOR")
    print("=" * 80)
    print()

    total_created = 0

    for pipeline_key, pipeline_info in PIPELINE_DEFINITIONS.items():
        print(f"\n📋 Generating: {pipeline_info['name']} (Pipeline {pipeline_key.split('_')[0]})")
        print("-" * 80)

        created_files = generate_pipeline_blueprints(pipeline_key, pipeline_info)
        total_created += len(created_files)

        print(f"✅ Created {len(created_files)} step blueprints")
        for filename in created_files:
            print(f"   - {filename}")

    print()
    print("=" * 80)
    print(f"✅ TOTAL: Generated {total_created} step blueprint files")
    print("=" * 80)

if __name__ == "__main__":
    main()
