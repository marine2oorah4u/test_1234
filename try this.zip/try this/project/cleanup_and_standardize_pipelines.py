#!/usr/bin/env python3
"""
Clean up and standardize all disability pipeline step blueprints.
- Remove duplicate and placeholder files
- Identify which pipelines need complete step blueprints generated
"""

import os
import json
from pathlib import Path

PIPELINE_DIR = "/tmp/cc-agent/60379492/project/blueprints/pipeline_3_disability_adaptations"

def is_complete_blueprint(filepath):
    """Check if a JSON file is a complete blueprint or placeholder."""
    try:
        with open(filepath, 'r') as f:
            data = json.load(f)

        # Complete blueprints have these comprehensive fields
        required_fields = [
            'step_number', 'step_name', 'disability', 'pipeline',
            'category', 'description', 'purpose', 'tasks',
            'output_artifacts', 'quality_thresholds', 'verification_checks'
        ]

        has_required = all(field in data for field in required_fields)
        has_detailed_tasks = 'tasks' in data and len(data.get('tasks', [])) > 0

        # Check if tasks have detailed structure (not just strings)
        if has_detailed_tasks:
            first_task = data['tasks'][0]
            has_task_details = isinstance(first_task, dict) and 'ai_prompt' in first_task
        else:
            has_task_details = False

        return has_required and has_detailed_tasks and has_task_details

    except (json.JSONDecodeError, Exception) as e:
        print(f"  Error reading {filepath}: {e}")
        return False

def analyze_pipeline(pipeline_path):
    """Analyze a pipeline directory for step blueprint completeness."""
    pipeline_name = os.path.basename(pipeline_path)
    step_dir = os.path.join(pipeline_path, "step_blueprints")

    if not os.path.exists(step_dir):
        return {
            'name': pipeline_name,
            'total_files': 0,
            'complete_files': 0,
            'placeholder_files': 0,
            'has_14_complete': False,
            'action_needed': 'CREATE_ALL'
        }

    json_files = list(Path(step_dir).glob("*.json"))
    complete_files = []
    placeholder_files = []

    for json_file in json_files:
        if is_complete_blueprint(json_file):
            complete_files.append(str(json_file))
        else:
            placeholder_files.append(str(json_file))

    action = 'NONE'
    if len(complete_files) == 0:
        action = 'CREATE_ALL'
    elif len(complete_files) < 14:
        action = 'CREATE_MISSING'
    elif len(complete_files) == 14 and len(placeholder_files) > 0:
        action = 'CLEAN_DUPLICATES'
    elif len(complete_files) > 14:
        action = 'CLEAN_AND_VERIFY'

    return {
        'name': pipeline_name,
        'total_files': len(json_files),
        'complete_files': len(complete_files),
        'placeholder_files': len(placeholder_files),
        'has_14_complete': len(complete_files) >= 14,
        'action_needed': action,
        'complete_list': complete_files,
        'placeholder_list': placeholder_files
    }

def main():
    print("=" * 80)
    print("DISABILITY PIPELINE AUDIT")
    print("=" * 80)
    print()

    # Get all pipeline directories
    pipeline_dirs = sorted([
        d for d in Path(PIPELINE_DIR).glob("pipeline_3.*")
        if d.is_dir()
    ])

    results = []
    needs_work = []

    for pipeline_dir in pipeline_dirs:
        result = analyze_pipeline(pipeline_dir)
        results.append(result)

        if result['action_needed'] != 'NONE':
            needs_work.append(result)

    # Print summary
    print(f"Total pipelines: {len(results)}")
    print(f"Pipelines needing work: {len(needs_work)}")
    print()

    print("=" * 80)
    print("DETAILED ANALYSIS")
    print("=" * 80)
    print()

    for result in results:
        status = "✅" if result['has_14_complete'] else "❌"
        print(f"{status} {result['name']:<50} Total: {result['total_files']:2d} | Complete: {result['complete_files']:2d} | Placeholders: {result['placeholder_files']:2d}")
        if result['action_needed'] != 'NONE':
            print(f"   → ACTION: {result['action_needed']}")
        print()

    print("=" * 80)
    print("SUMMARY BY ACTION NEEDED")
    print("=" * 80)
    print()

    action_groups = {}
    for result in needs_work:
        action = result['action_needed']
        if action not in action_groups:
            action_groups[action] = []
        action_groups[action].append(result['name'])

    for action, pipelines in sorted(action_groups.items()):
        print(f"\n{action} ({len(pipelines)} pipelines):")
        for pipeline in pipelines:
            print(f"  - {pipeline}")

    print()
    print("=" * 80)
    print("RECOMMENDATIONS")
    print("=" * 80)
    print()

    create_all = len([r for r in needs_work if r['action_needed'] == 'CREATE_ALL'])
    create_missing = len([r for r in needs_work if r['action_needed'] == 'CREATE_MISSING'])
    clean = len([r for r in needs_work if r['action_needed'] in ['CLEAN_DUPLICATES', 'CLEAN_AND_VERIFY']])

    if create_all > 0:
        print(f"1. Generate complete 14-step blueprints for {create_all} pipelines")
    if create_missing > 0:
        print(f"2. Generate missing steps for {create_missing} pipelines")
    if clean > 0:
        print(f"3. Clean up duplicate/placeholder files in {clean} pipelines")

    if len(needs_work) == 0:
        print("✅ All pipelines have complete 14-step blueprints!")

    print()

    # Save detailed report
    report_path = os.path.join(PIPELINE_DIR, "PIPELINE_AUDIT_REPORT.json")
    with open(report_path, 'w') as f:
        json.dump({
            'total_pipelines': len(results),
            'complete_pipelines': len([r for r in results if r['has_14_complete']]),
            'needs_work': len(needs_work),
            'results': results
        }, f, indent=2)

    print(f"Detailed report saved to: PIPELINE_AUDIT_REPORT.json")

if __name__ == "__main__":
    main()
