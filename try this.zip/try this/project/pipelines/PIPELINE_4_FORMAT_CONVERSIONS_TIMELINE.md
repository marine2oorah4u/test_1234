# PIPELINE 4: FORMAT CONVERSIONS - COMPLETE TIMELINE

**Purpose:** Convert all 328 books into 7 different file formats
**Input:** All 328 books (1 Master + 7 Reading Levels + 320 Disability Adaptations)
**Output:** 2,296 files (328 books × 7 formats)
**Total Duration:** 10-30 minutes per format (all 7 run in parallel)

---

## 📋 OVERVIEW

**The Process:**
1. Take all 328 completed books
2. Convert each book into 7 different file formats
3. Each format has specific requirements:
   - PDF (universal reading, print-ready)
   - EPUB (e-readers, mobile devices)
   - HTML (web browsers, online platforms)
   - Audio/MP3 (audiobooks, accessibility)
   - DOCX (Microsoft Word, editing)
   - Markdown (plain text, developers)
   - LaTeX (academic, mathematical typesetting)

**Key Principle:** All 7 formats convert in parallel for each book

---

## 🎯 FORMAT SPECIFICATIONS

### 1. PDF (Portable Document Format)
- **Purpose:** Universal reading, printing, archival
- **Features:** Fixed layout, embedded fonts, print-ready
- **Accessibility:** Tagged PDF, screen reader compatible
- **File size:** 2-5 MB per book (average)
- **Duration:** 10-15 minutes

### 2. EPUB (Electronic Publication)
- **Purpose:** E-readers (Kindle, Kobo, etc.), mobile apps
- **Features:** Reflowable text, responsive layout, bookmarks
- **Accessibility:** EPUB3 with accessibility metadata
- **File size:** 1-3 MB per book (average)
- **Duration:** 15-20 minutes

### 3. HTML (Web/Online)
- **Purpose:** Web browsers, online learning platforms
- **Features:** Interactive, linkable, searchable, responsive
- **Accessibility:** WCAG 2.1 AA compliant, semantic HTML5
- **File size:** 500 KB - 2 MB per book (HTML + CSS + assets)
- **Duration:** 10-12 minutes

### 4. Audio/MP3 (Audiobook)
- **Purpose:** Listening, auditory learners, accessibility
- **Features:** Natural text-to-speech, chapter markers, speed control
- **Accessibility:** Essential for blind/low vision users
- **File size:** 50-150 MB per book (average, 128 kbps)
- **Duration:** 20-30 minutes (longest - TTS processing)

### 5. DOCX (Microsoft Word)
- **Purpose:** Editing, customization, teachers
- **Features:** Editable, collaborative, template-friendly
- **Accessibility:** Word accessibility features enabled
- **File size:** 2-4 MB per book (average)
- **Duration:** 10-15 minutes

### 6. Markdown (Plain Text)
- **Purpose:** Developers, plain text preference, version control
- **Features:** Human-readable, Git-friendly, portable
- **Accessibility:** Screen reader friendly (plain text)
- **File size:** 100-500 KB per book (smallest)
- **Duration:** 5-10 minutes (fastest)

### 7. LaTeX (Academic Typesetting)
- **Purpose:** Academic publishing, mathematical content
- **Features:** Professional typesetting, math equations, citations
- **Accessibility:** Can generate accessible PDFs
- **File size:** 200 KB - 1 MB (source), 3-8 MB (compiled PDF)
- **Duration:** 15-20 minutes

---

## ⏱️ TIME ESTIMATES

### Conversion Times (Per Book)
- Markdown conversion: 5-10 minutes (fastest)
- HTML conversion: 10-12 minutes
- PDF conversion: 10-15 minutes
- DOCX conversion: 10-15 minutes
- EPUB conversion: 15-20 minutes
- LaTeX conversion: 15-20 minutes
- Audio/MP3 conversion: 20-30 minutes (slowest - TTS processing)

### API Call Times
- Single AI query: 5-20 seconds
- 4 parallel AI queries: 5-20 seconds
- Synthesis step: 8-15 seconds

---

## 📖 FORMAT CONVERSION PIPELINE

Each format follows this pipeline. All 7 formats process in parallel.

---

## FORMAT 1: PDF CONVERSION (10-15 minutes)

### STEP 1: PREPARE SOURCE (2-3 minutes)

**T+0:00** - Launch 5 preparation workers in parallel

**Each worker:**
- T+0:00 - Query GPT-4, Claude, Gemini, Perplexity (parallel)
  - Analyze source content structure
  - Identify page break locations
  - Plan pagination strategy
  - Map heading hierarchy
  - Identify figure/table placements
- T+0:25 - Receive 4 preparation plans
- T+0:25 - Launch synthesis (Claude creates optimal plan)
- T+0:40 - Synthesis complete
- **Worker done: ~40 seconds**

**T+0:40** - Preparation complete → Have conversion plan

**T+0:40** - Launch 3 verifiers

**T+0:55** - Verification complete
- ✅ Pass → Step 2

**API Calls:** 20 + 5 + 12 = **37 calls**

---

### STEP 2: LAYOUT & TYPOGRAPHY (3-4 minutes)

**T+3:00** - Launch 6 layout workers in parallel

**Each worker:**
- T+3:00 - Query all 4 models (parallel)
  - Apply professional typography
  - Set margins and spacing
  - Configure headers/footers
  - Apply page numbering
  - Set font embedding
  - Configure print settings
- T+3:35 - Receive 4 layout versions
- T+3:35 - Synthesis (Gemini picks best layout)
- T+3:55 - Complete

**T+3:55** - Launch 5 verifiers
**T+4:15** - Verification complete

**API Calls:** 24 + 6 + 20 = **50 calls**

---

### STEP 3: ACCESSIBILITY TAGS (2-3 minutes)

**T+6:00** - Launch 5 accessibility workers

**Each worker:**
- T+6:00 - Query all 4 models
  - Add PDF tags for structure
  - Add alt text to images
  - Set reading order
  - Add bookmarks/TOC
  - Configure metadata
- T+6:30 - Complete

**T+6:30** - Launch 3 verifiers
**T+6:45** - Verification complete

**API Calls:** 20 + 5 + 12 = **37 calls**

---

### STEP 4: GENERATE & OPTIMIZE (2-3 minutes)

**T+9:00** - Launch PDF generation (automated process)
- Generate PDF file
- Embed fonts
- Compress images
- Optimize file size
- Add security settings
- **Duration: 1-2 minutes (no AI calls)**

**T+11:00** - Launch 5 verifiers

**Each verifier:**
- T+11:00 - Query all 4 models
  - Verify PDF renders correctly
  - Check accessibility compliance
  - Verify file size reasonable
  - Test on multiple PDF readers
- T+11:20 - Consensus check

**API Calls:** 20 calls

---

### STEP 5: FINAL VALIDATION (1-2 minutes)

**T+12:00** - Launch 3 validators
- Verify PDF/A compliance (archival standard)
- Check accessibility (PDF/UA)
- Validate metadata
- Test download/display

**API Calls:** 12 calls

**PDF CONVERSION TOTAL: 10-15 minutes**
**Total API Calls: 136 calls**

---

## FORMAT 2: EPUB CONVERSION (15-20 minutes)

### STEP 1: PREPARE EPUB STRUCTURE (3-4 minutes)

**T+0:00** - Launch 5 structure workers

**Each worker:**
- T+0:00 - Query all 4 models
  - Create EPUB3 structure
  - Define spine order
  - Create navigation document
  - Set up metadata (OPF file)
  - Configure content documents
- T+0:35 - Complete

**T+0:35** - Launch 3 verifiers
**T+0:50** - Verification complete

**API Calls:** 37 calls

---

### STEP 2: CONVERT CONTENT (4-6 minutes)

**T+4:00** - Launch 8 content workers

**Each worker:**
- T+4:00 - Query all 4 models
  - Convert to XHTML5
  - Apply CSS styling
  - Configure reflowable layout
  - Add media overlays (if audio present)
  - Optimize for e-readers
- T+4:50 - Complete

**T+4:50** - Launch 5 verifiers
**T+5:15** - Verification complete

**API Calls:** 32 + 8 + 20 = **60 calls**

---

### STEP 3: ACCESSIBILITY METADATA (2-3 minutes)

**T+10:00** - Launch 5 accessibility workers
- Add EPUB accessibility metadata
- Configure screen reader support
- Add semantic inflation
- Set display options
- Configure MathML (if needed)

**T+10:30** - Complete
**T+10:30** - Launch 3 verifiers
**T+10:45** - Verification complete

**API Calls:** 37 calls

---

### STEP 4: PACKAGE & VALIDATE (3-4 minutes)

**T+13:00** - Package EPUB (automated)
- Create EPUB container
- Add mimetype file
- Package all resources
- Generate manifest
- **Duration: 1-2 minutes**

**T+15:00** - Launch 5 validators
- Run EPUBCheck validation
- Test on multiple e-readers
- Verify accessibility
- Check file integrity

**API Calls:** 20 calls

---

### STEP 5: FINAL QUALITY CHECK (2-3 minutes)

**T+17:00** - Launch 5 quality checkers
- Verify EPUB3 compliance
- Test readability across devices
- Verify all features work
- Check file size

**API Calls:** 20 calls

**EPUB CONVERSION TOTAL: 15-20 minutes**
**Total API Calls: 174 calls**

---

## FORMAT 3: HTML CONVERSION (10-12 minutes)

### STEP 1: SEMANTIC HTML GENERATION (3-4 minutes)

**T+0:00** - Launch 6 HTML workers
- Generate semantic HTML5
- Apply ARIA labels
- Create navigation structure
- Add meta tags
- Configure responsive layout

**API Calls:** 50 calls

---

### STEP 2: CSS STYLING (2-3 minutes)

**T+4:00** - Launch 5 CSS workers
- Create responsive CSS
- Add print stylesheets
- Configure accessibility styles
- Add dark mode support
- Optimize for performance

**API Calls:** 45 calls

---

### STEP 3: INTERACTIVITY (2-3 minutes)

**T+7:00** - Launch 5 interactivity workers
- Add table of contents navigation
- Configure search functionality
- Add bookmark support
- Add print functionality
- Add sharing options

**API Calls:** 45 calls

---

### STEP 4: ACCESSIBILITY & VALIDATION (2-3 minutes)

**T+10:00** - Launch 5 validators
- Validate HTML5
- Check WCAG 2.1 AA compliance
- Test keyboard navigation
- Verify screen reader compatibility
- Check cross-browser compatibility

**API Calls:** 20 calls

**HTML CONVERSION TOTAL: 10-12 minutes**
**Total API Calls: 160 calls**

---

## FORMAT 4: AUDIO/MP3 CONVERSION (20-30 minutes)

### STEP 1: TEXT PREPARATION (3-5 minutes)

**T+0:00** - Launch 6 text prep workers
- Clean text for TTS
- Add pronunciation guides
- Configure pauses and pacing
- Add chapter markers
- Prepare SSML markup

**API Calls:** 50 calls

---

### STEP 2: VOICE SELECTION (2-3 minutes)

**T+5:00** - Launch 3 voice workers
- Select appropriate voice (age, gender, accent)
- Configure voice parameters
- Set speed and pitch
- Configure prosody

**API Calls:** 25 calls

---

### STEP 3: AUDIO GENERATION (10-15 minutes)

**T+8:00** - Generate audio (TTS processing)
- Text-to-speech conversion
- Add chapter markers
- Normalize audio levels
- Apply compression
- **Duration: 10-15 minutes (no AI calls, CPU-intensive)**

---

### STEP 4: AUDIO OPTIMIZATION (2-4 minutes)

**T+23:00** - Launch 5 audio workers
- Optimize bitrate (128 kbps)
- Add ID3 tags
- Create chapter tracks
- Generate cover art
- Package files

**API Calls:** 45 calls

---

### STEP 5: QUALITY VERIFICATION (2-3 minutes)

**T+27:00** - Launch 5 verifiers
- Test audio playback
- Verify chapter markers work
- Check audio quality
- Verify metadata correct

**API Calls:** 20 calls

**AUDIO CONVERSION TOTAL: 20-30 minutes**
**Total API Calls: 140 calls**

---

## FORMAT 5: DOCX CONVERSION (10-15 minutes)

### STEP 1: DOCUMENT STRUCTURE (3-4 minutes)

**T+0:00** - Launch 6 structure workers
- Create Word document structure
- Apply styles (headings, paragraphs)
- Configure page layout
- Add section breaks
- Set up headers/footers

**API Calls:** 50 calls

---

### STEP 2: CONTENT FORMATTING (3-5 minutes)

**T+4:00** - Launch 7 formatting workers
- Apply formatting
- Insert images
- Create tables
- Add captions
- Configure numbering

**API Calls:** 55 calls

---

### STEP 3: ACCESSIBILITY FEATURES (2-3 minutes)

**T+9:00** - Launch 5 accessibility workers
- Add alt text
- Configure reading order
- Add table headers
- Enable accessibility checker
- Configure document properties

**API Calls:** 45 calls

---

### STEP 4: VALIDATION (2-3 minutes)

**T+12:00** - Launch 3 validators
- Test in Microsoft Word
- Check formatting consistency
- Verify editability
- Check file compatibility

**API Calls:** 20 calls

**DOCX CONVERSION TOTAL: 10-15 minutes**
**Total API Calls: 170 calls**

---

## FORMAT 6: MARKDOWN CONVERSION (5-10 minutes)

### STEP 1: CLEAN CONVERSION (2-3 minutes)

**T+0:00** - Launch 5 markdown workers
- Convert to clean Markdown
- Preserve formatting
- Optimize for readability
- Add front matter (YAML)
- Configure extensions (tables, etc.)

**API Calls:** 45 calls

---

### STEP 2: OPTIMIZATION (2-3 minutes)

**T+3:00** - Launch 3 optimization workers
- Optimize link structure
- Clean up whitespace
- Verify syntax correctness
- Test rendering

**API Calls:** 25 calls

---

### STEP 3: VALIDATION (1-2 minutes)

**T+6:00** - Launch 3 validators
- Validate Markdown syntax
- Test in multiple renderers
- Verify all features work

**API Calls:** 12 calls

**MARKDOWN CONVERSION TOTAL: 5-10 minutes**
**Total API Calls: 82 calls**

---

## FORMAT 7: LaTeX CONVERSION (15-20 minutes)

### STEP 1: LaTeX DOCUMENT SETUP (3-4 minutes)

**T+0:00** - Launch 5 LaTeX workers
- Create document class
- Configure packages
- Set up preamble
- Define custom commands
- Configure bibliography

**API Calls:** 45 calls

---

### STEP 2: CONTENT CONVERSION (4-6 minutes)

**T+4:00** - Launch 7 content workers
- Convert content to LaTeX
- Format equations (if any)
- Create figures/tables
- Add cross-references
- Configure citations

**API Calls:** 55 calls

---

### STEP 3: COMPILATION & FORMATTING (3-5 minutes)

**T+10:00** - Compile LaTeX (automated)
- Run pdflatex
- Generate bibliography
- Create index
- **Duration: 2-3 minutes**

**T+13:00** - Launch 5 formatting workers
- Adjust spacing
- Optimize page breaks
- Format headers/footers
- Polish typography

**API Calls:** 45 calls

---

### STEP 4: VALIDATION (2-3 minutes)

**T+17:00** - Launch 3 validators
- Verify compilation successful
- Check PDF output quality
- Verify all references work
- Test on different LaTeX engines

**API Calls:** 20 calls

**LaTeX CONVERSION TOTAL: 15-20 minutes**
**Total API Calls: 165 calls**

---

## ✅ ALL FORMATS COMPLETE: 20-30 minutes (parallel)

**CRITICAL:** All 7 formats convert in parallel
- Each format has different duration
- All start at same time
- **Total time = longest format (Audio/MP3: 20-30 minutes)**

---

## 📊 API CALL SUMMARY (Per Book, All Formats)

| Format | API Calls | Duration |
|--------|-----------|----------|
| PDF | 136 | 10-15 min |
| EPUB | 174 | 15-20 min |
| HTML | 160 | 10-12 min |
| Audio/MP3 | 140 | 20-30 min ⏱️ |
| DOCX | 170 | 10-15 min |
| Markdown | 82 | 5-10 min |
| LaTeX | 165 | 15-20 min |
| **TOTAL** | **1,027** | **20-30 min** |

**Total API Calls (All 328 Books × 7 Formats):** 336,856 calls
**Total Duration (Parallel):** 20-30 minutes

---

## 🔄 PARALLEL EXECUTION

### Worker Distribution at Peak:

**Audio Generation - Most Workers:**
- EPUB Step 2: 8 content workers per book
- 328 books × 8 workers = **2,624 workers simultaneously**
- Plus verification workers: ~1,640 additional
- **Peak: ~4,264 workers**

### API Call Distribution:

**Peak API load:**
- All 328 books converting simultaneously
- Each book: ~40-60 API calls per 30-second window
- **Peak: ~13,000-19,000 API calls per 30-second window**

---

## 💰 COST ESTIMATE

**Per Book (All 7 Formats):** ~1,027 API calls
**Cost per call:** $0.15-0.25
**Cost per book:** $154-257

**Total (328 Books):**
**API Calls:** 336,856 calls
**Estimated Cost:** $50,528-84,214

---

## 📝 NOTES

- All 7 formats process in parallel
- Audio/MP3 is the longest (20-30 min) - sets total duration
- Markdown is the fastest (5-10 min)
- Most formats require accessibility verification
- Each format must pass quality checks
- File sizes vary significantly by format
- All formats must be compatible with common readers/viewers
- Storage requirements: 328 books × 7 formats × avg 10 MB = ~23 GB

---

## 🔗 DEPENDENCIES

**Input Required:**
- Master Reference Book (Pipeline 1) ✅
- 7 Reading Level Adaptations (Pipeline 2) ✅
- 320 Disability Adaptations (Pipeline 3) ✅

**Enables:**
- Distribution to users
- Storage in tiered systems
- CDN deployment

**Blocks:**
- Cannot start until all 328 books are complete and certified
