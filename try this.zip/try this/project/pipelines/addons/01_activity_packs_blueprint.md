# 🎯 ACTIVITY PACKS - Complete Blueprint

**Status:** ✅ APPROVED
**Category:** Core Educational Addons
**Priority:** HIGH
**Last Updated:** 2025-12-02

---

## 📋 OVERVIEW

### What They Are
Hands-on activities that students DO to learn the material. Each activity is a complete, self-contained learning experience.

### Quantity per Topic
- **Minimum:** 100 activities
- **Target:** 125 activities
- **Maximum:** 150 activities

### Purpose
Give students practical, engaging ways to apply and practice concepts from lessons through real-world activities.

---

## 📦 COMPONENTS

### Each Activity Includes (17 Components):

1. **Title** - Engaging, clear, descriptive
2. **Learning Objective** - Specific, measurable, tied to lesson
3. **Time Estimate** - 15 min / 30 min / 60 min / multi-day
4. **Difficulty Level** - Beginner / Intermediate / Advanced
5. **Materials List** - Complete with budget alternatives
6. **Step-by-Step Instructions** - Numbered, clear, simple language
7. **Safety Guidelines** - Age-appropriate warnings and precautions
8. **Setup Instructions** - Preparation work needed before starting
9. **Assessment Rubric** - How to evaluate student work
10. **Troubleshooting Guide** - Solutions for common problems
11. **Extension Activities** - For advanced learners
12. **Simplification Options** - For struggling learners
13. **Group vs Individual** - Can be done alone or together
14. **Indoor/Outdoor Variations** - Flexibility for environment
15. **Home/Classroom Adaptations** - Works in both settings
16. **Real-World Connections** - Why this matters, how it's used
17. **Photos/Diagrams** - Visual instructions (generated or sourced)

---

## 🤖 AI MODEL ASSIGNMENTS

### PHASE 1: RESEARCH (7 AIs - 80% Consensus Required)

**Models & Roles:**

1. **o4-mini-deep-research** (OpenAI)
   - Research pedagogical best practices for activity-based learning
   - Find educational standards and curriculum guidelines
   - Identify proven teaching methods for topic

2. **Perplexity Pro**
   - Find real-world examples of successful activities
   - Research materials availability and costs
   - Discover practical implementation tips

3. **Gemini Pro 1.5** (Google)
   - Verify STEM accuracy and scientific validity
   - Check feasibility of procedures
   - Validate technical specifications

4. **DeepSeek-V3**
   - Logic checks for activity flow
   - Safety verification for age group
   - Identify potential hazards or issues

5. **GPT-5.1** (OpenAI)
   - Generate creative activity concepts
   - Brainstorm engaging variations
   - Ideate real-world applications

6. **Claude 3.5 Sonnet** (Anthropic)
   - Structure and organize information
   - Create logical groupings
   - Develop comprehensive outlines

7. **Gemini Flash** (Google)
   - Quick fact-checking
   - Rapid validation of claims
   - Fast verification of materials/resources

**Deliverable:** Research report with 80%+ consensus on activity viability

---

### PHASE 2: GENERATION (5 AIs - 75% Consensus Required)

**Models & Roles:**

1. **GPT-5 Pro** (OpenAI)
   - Premium quality instruction writing
   - Sophisticated explanations
   - High-level content creation

2. **Claude 3.5 Sonnet** (Anthropic)
   - Clear step-by-step formatting
   - Logical flow and structure
   - Precise language

3. **Gemini Pro 1.5** (Google)
   - STEM accuracy in procedures
   - Technical precision
   - Scientific validity

4. **GPT-5.1** (OpenAI)
   - Engaging descriptions
   - Student-friendly explanations
   - Motivating language

5. **DeepSeek-V3**
   - Logic verification of steps
   - Sequence validation
   - Coherence checking

**Deliverable:** Draft activities with 75%+ agreement on content quality

---

### PHASE 3: VERIFICATION (12 AIs/ALL - 90% Consensus Required) ⭐ CRITICAL

**All 12 Models Verify:**

✅ **Safety Checks:**
- Activity is safe for target age group
- No dangerous procedures or materials
- Safety guidelines are adequate
- Adult supervision requirements clear

✅ **Feasibility Checks:**
- Materials are actually available
- Materials are affordable (or alternatives provided)
- Time estimates are realistic
- Activity can actually be completed as described

✅ **Educational Checks:**
- Activity directly ties to specific lesson objective
- Learning goals are achievable
- Assessment rubric is appropriate
- Skill level matches target age/grade

✅ **Clarity Checks:**
- Instructions are clear and unambiguous
- Steps are in logical order
- Language is age-appropriate
- No confusing jargon

✅ **Accessibility Checks:**
- Can be adapted for students with disabilities
- Multiple learning styles accommodated
- No exclusive requirements
- Alternative approaches provided

✅ **Practicality Checks:**
- Can be done in home or classroom
- No specialized equipment required (or alternatives given)
- Works in various environments
- Reasonable space requirements

✅ **Cultural Sensitivity:**
- Respectful of diverse backgrounds
- No cultural biases
- Inclusive language
- Universal applicability

**Verification Process:**
1. Each AI independently scores on 25-point checklist
2. Scores aggregated and averaged
3. 90%+ agreement required (22.5/25 points minimum)
4. Any flagged issues must be addressed
5. Re-verification if changes made

**Deliverable:** Verified activities with 90%+ quality score

---

### PHASE 4: REFINEMENT (5 AIs - 80% Consensus Required)

**Models & Roles:**

1. **GPT-5 Pro** (OpenAI)
   - Polish language and clarity
   - Enhance professional quality
   - Improve flow

2. **Claude 3.5 Sonnet** (Anthropic)
   - Improve readability
   - Simplify complex explanations
   - Enhance structure

3. **Gemini Pro 1.5** (Google)
   - Final accuracy check
   - Technical review
   - Validate improvements

4. **GPT-5.1** (OpenAI)
   - Enhance engagement
   - Add motivating elements
   - Improve student appeal

5. **Mistral Large**
   - Alternative perspective review
   - Identify blind spots
   - Suggest improvements

**Deliverable:** Refined activities with 80%+ approval

---

### PHASE 5: POLISH (3 AIs - 85% Consensus Required)

**Models & Roles:**

1. **GPT-5 Pro** (OpenAI)
   - Final quality pass
   - Production-ready polish
   - Consistency check

2. **Claude 3.5 Sonnet** (Anthropic)
   - Final readability check
   - Format consistency
   - Clear communication

3. **Gemini Pro 1.5** (Google)
   - Final verification
   - Last accuracy check
   - Technical validation

**Deliverable:** Production-ready activities

---

## 📄 FILE FORMATS

### 1. PDF Format
- **Purpose:** Printable, shareable
- **Features:**
  - Professional layout
  - Clear typography
  - Checkboxes for materials
  - Space for notes
  - Print-optimized (black & white friendly)
- **Specs:** 8.5"x11", 1" margins, Arial 11pt

### 2. HTML Format
- **Purpose:** Interactive web version
- **Features:**
  - Responsive design
  - Collapsible sections
  - Printable button
  - Bookmark capability
  - Share link
- **Specs:** Mobile-first, accessible (WCAG 2.1 AA)

### 3. DOCX Format
- **Purpose:** Editable by teachers
- **Features:**
  - Structured headings
  - Easy modification
  - Comments/notes capability
  - Track changes enabled
- **Specs:** Word 2016+ compatible

### 4. EPUB Format
- **Purpose:** E-reader compatible
- **Features:**
  - Reflowable text
  - Bookmark support
  - Search capability
  - Adjustable fonts
- **Specs:** EPUB 3.0 standard

---

## 🎯 QUALITY GUARANTEES

### What We Promise:

✅ **Every activity is safe**
- Verified by 12 AI models
- Age-appropriate safety guidelines
- No dangerous procedures

✅ **Every activity is feasible**
- Materials are available
- Time estimates are realistic
- Can actually be completed

✅ **Every activity teaches**
- Directly tied to lesson objective
- Measurable learning outcomes
- Assessment included

✅ **Every activity is clear**
- Unambiguous instructions
- Logical step sequence
- Age-appropriate language

✅ **Every activity is accessible**
- Multiple adaptations available
- Various learning styles supported
- Inclusive design

✅ **Every activity is tested**
- 90%+ consensus from 12 AIs
- Multiple verification rounds
- Quality score of 22.5/25 minimum

---

## 📊 ORGANIZATION

### Activities Grouped By:

1. **Learning Objective** - Which lesson concept it teaches
2. **Difficulty Level** - Beginner / Intermediate / Advanced
3. **Time Required** - Quick (15m) / Standard (30m) / Extended (60m) / Multi-day
4. **Setting** - Indoor / Outdoor / Either
5. **Group Size** - Individual / Pairs / Small Group / Whole Class
6. **Budget** - Free / Low ($0-5) / Moderate ($5-20)
7. **Materials** - Common household / School supplies / Specialized

### Indexing:
- Searchable by keyword
- Filterable by all categories above
- Cross-referenced with lessons
- Tagged with skills practiced

---

## 💾 DATABASE SCHEMA

### Table: addon_activities

```sql
CREATE TABLE addon_activities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id UUID REFERENCES books(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  learning_objective TEXT NOT NULL,
  time_estimate INTEGER, -- minutes
  difficulty_level TEXT CHECK (difficulty_level IN ('beginner', 'intermediate', 'advanced')),
  materials JSONB, -- array of materials with alternatives
  instructions JSONB, -- numbered steps
  safety_guidelines TEXT[],
  setup_instructions TEXT,
  assessment_rubric JSONB,
  troubleshooting JSONB,
  extensions TEXT[],
  simplifications TEXT[],
  group_options TEXT[],
  settings TEXT[], -- indoor, outdoor
  real_world_connections TEXT,
  budget_tier TEXT CHECK (budget_tier IN ('free', 'low', 'moderate')),

  -- AI Generation Data
  research_consensus_score NUMERIC(4,2),
  generation_consensus_score NUMERIC(4,2),
  verification_consensus_score NUMERIC(4,2), -- must be >= 90.0
  refinement_consensus_score NUMERIC(4,2),
  polish_consensus_score NUMERIC(4,2),

  -- Metadata
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  generated_by TEXT, -- which AI pipeline
  quality_score NUMERIC(4,2), -- 0-25 scale
  verification_details JSONB, -- detailed scores from each AI

  -- Files
  pdf_url TEXT,
  html_url TEXT,
  docx_url TEXT,
  epub_url TEXT,

  -- Search & Filtering
  tags TEXT[],
  skills_practiced TEXT[],
  related_lesson_ids UUID[]
);

-- Indexes for performance
CREATE INDEX idx_activities_book_id ON addon_activities(book_id);
CREATE INDEX idx_activities_difficulty ON addon_activities(difficulty_level);
CREATE INDEX idx_activities_time ON addon_activities(time_estimate);
CREATE INDEX idx_activities_quality ON addon_activities(quality_score);
CREATE INDEX idx_activities_tags ON addon_activities USING GIN(tags);

-- RLS Policies
ALTER TABLE addon_activities ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Activities viewable by authenticated users"
  ON addon_activities FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Activities manageable by admins"
  ON addon_activities FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role IN ('admin', 'super_admin')
    )
  );
```

---

## 🔄 GENERATION WORKFLOW

### Step-by-Step Process:

```typescript
async function generateActivityPacks(bookId: string, topic: string) {
  // PHASE 1: RESEARCH
  const research = await multiAIResearch({
    models: [
      'o4-mini-deep-research',
      'perplexity-pro',
      'gemini-pro-1.5',
      'deepseek-v3',
      'gpt-5.1',
      'claude-3.5-sonnet',
      'gemini-flash'
    ],
    consensusThreshold: 0.80,
    prompt: `Research best practices for hands-on activities teaching: ${topic}`
  });

  if (research.consensus < 0.80) {
    throw new Error('Research consensus too low');
  }

  // PHASE 2: GENERATION
  const activities = await multiAIGeneration({
    models: [
      'gpt-5-pro',
      'claude-3.5-sonnet',
      'gemini-pro-1.5',
      'gpt-5.1',
      'deepseek-v3'
    ],
    consensusThreshold: 0.75,
    count: 125,
    context: research.findings,
    prompt: `Generate 125 hands-on activities for: ${topic}`
  });

  // PHASE 3: VERIFICATION (CRITICAL)
  const verified = await multiAIVerification({
    models: 'ALL', // All 12 models
    consensusThreshold: 0.90,
    activities: activities.draft,
    checklist: verificationChecklist // 25-point checklist
  });

  if (verified.consensus < 0.90) {
    // Refine and re-verify
    await refineAndReverify(verified.flaggedActivities);
  }

  // PHASE 4: REFINEMENT
  const refined = await multiAIRefinement({
    models: [
      'gpt-5-pro',
      'claude-3.5-sonnet',
      'gemini-pro-1.5',
      'gpt-5.1',
      'mistral-large'
    ],
    consensusThreshold: 0.80,
    activities: verified.activities
  });

  // PHASE 5: POLISH
  const polished = await multiAIPolish({
    models: [
      'gpt-5-pro',
      'claude-3.5-sonnet',
      'gemini-pro-1.5'
    ],
    consensusThreshold: 0.85,
    activities: refined.activities
  });

  // SAVE TO DATABASE
  for (const activity of polished.activities) {
    await saveActivity(bookId, activity);
  }

  // GENERATE FILE FORMATS
  await generateFormats(polished.activities, ['pdf', 'html', 'docx', 'epub']);

  return {
    count: polished.activities.length,
    averageQuality: polished.averageScore,
    status: 'complete'
  };
}
```

---

## 📈 SUCCESS METRICS

### Quality Metrics:
- **Verification Score:** 90%+ required
- **Overall Quality:** 22.5/25 minimum
- **Safety Score:** 100% (no compromise)
- **Clarity Score:** 85%+ required
- **Feasibility Score:** 90%+ required

### Production Metrics:
- **Generation Time:** ~30 minutes per 100 activities
- **Cost per Activity:** ~$0.15 (AI API calls)
- **Storage per Activity:** ~50KB (text + metadata)
- **File Size:** PDF ~200KB, DOCX ~150KB, HTML ~100KB, EPUB ~180KB

### Usage Metrics:
- Track which activities used most
- Collect teacher ratings
- Monitor completion rates
- Gather feedback for improvements

---

## 🎓 EXAMPLE ACTIVITY

### Solar System Scale Model

**Learning Objective:** Understand relative sizes and distances of planets in solar system

**Time Estimate:** 60 minutes

**Difficulty Level:** Intermediate

**Materials:**
- String (30 meters)
- Tape measure
- Paper (various colors)
- Markers
- Scissors
- Tape
- Budget: $5 or less
- Alternatives: Use newspaper instead of colored paper

**Setup Instructions:**
1. Clear hallway or outdoor space (30m long)
2. Gather all materials
3. Pre-cut string to 30m length
4. Prepare workspace with tape and scissors

**Step-by-Step Instructions:**

1. **Create the Sun** (5 min)
   - Use yellow paper
   - Draw circle 10cm diameter
   - Label "Sun"
   - Place at starting point

2. **Measure Mercury** (3 min)
   - Measure 4m from Sun
   - Draw 2mm circle on white paper
   - Label "Mercury"
   - Tape to string

3. **Measure Venus** (3 min)
   - Measure 7m from Sun
   - Draw 5mm circle on brown paper
   - Label "Venus"
   - Tape to string

[Continue for all planets...]

**Safety Guidelines:**
- Use scissors carefully under adult supervision
- Don't run with tape measure extended
- Work in safe, clear area

**Assessment Rubric:**
- Correct distances: 40 points
- Correct relative sizes: 30 points
- Labels clear: 15 points
- Participation: 15 points
- Total: 100 points

**Troubleshooting:**
- **Problem:** Not enough space
  - **Solution:** Use 1/2 scale (15m) or create 2D poster
- **Problem:** Hard to see small planets
  - **Solution:** Magnify sizes by 2x (keep distances same)

**Extension Activities:**
- Calculate actual distances using scale ratio
- Research each planet's features
- Create 3D models instead of 2D
- Add moons to each planet
- Compare with other solar systems

**Simplification Options:**
- Pre-cut all materials
- Use simpler scale (1m = 1 planet)
- Only include 4-5 planets
- Use pre-made planet images
- Work in pairs with adult help

**Group Options:**
- Individual: Student creates mini-model
- Pairs: Two students work together
- Small Group: Each student does 2-3 planets
- Whole Class: Create hallway-sized model together

**Settings:**
- Indoor: Hallway, gym, cafeteria
- Outdoor: Playground, field, parking lot

**Real-World Connections:**
- Space missions plan using these distances
- Astronomers use scale models
- Understanding space travel time
- Importance in planetary science

**Photos/Diagrams:**
[Generated diagrams showing setup, measurements, final result]

---

## ✅ APPROVAL STATUS

**Reviewed By:** User
**Approved:** 2025-12-02
**Status:** READY FOR IMPLEMENTATION

**Next Steps:**
1. Create database table
2. Implement generation workflow
3. Set up AI orchestration
4. Test with sample topic
5. Generate first batch

---

**Blueprint Complete** ✅
