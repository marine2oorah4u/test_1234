# COMPLETE INFRASTRUCTURE REQUIREMENTS

**Purpose:** Comprehensive list of all hardware, software, services, credentials, and setup needed for the system
**Scope:** From zero to mega-scale (500 workers → 5 million workers)
**Last Updated:** 2025-11-25

---

## 📋 OVERVIEW

This document covers EVERYTHING you need to acquire, configure, and operate the system at any scale.

**Four scaling scenarios:**
- **Scenario A:** 500-5,000 workers (minimal funding)
- **Scenario B:** 10,000-100,000 workers (moderate funding)
- **Scenario C:** 100,000-1,000,000 workers (high funding)
- **Scenario D:** 1,000,000-5,000,000+ workers (extreme funding)

---

## 🔑 SECTION 1: REQUIRED API KEYS & CREDENTIALS

### AI Model APIs (REQUIRED - Core functionality)

**OpenAI (GPT-4):**
- API Key: `sk-...` (from platform.openai.com)
- Organization ID: `org-...`
- Project ID: `proj_...` (optional, for better tracking)
- Rate limit tier: Minimum Tier 3 ($5,000+ monthly spend)
  - Tier 4 preferred ($25,000+ monthly): 10,000 RPM
  - Tier 5 for scale ($100,000+ monthly): 80,000 RPM
- **Cost:** $0.03/1K input tokens, $0.06/1K output tokens (GPT-4)
- **Setup:** https://platform.openai.com/api-keys

**Anthropic (Claude):**
- API Key: `sk-ant-...` (from console.anthropic.com)
- Rate limit tier: Minimum Tier 2 ($500+ monthly)
  - Tier 3 preferred ($5,000+ monthly): 5,000 RPM
  - Tier 4 for scale ($40,000+ monthly): 10,000 RPM
- **Cost:** $0.015/1K input tokens, $0.075/1K output tokens (Claude 3 Opus)
- **Setup:** https://console.anthropic.com/

**Google AI (Gemini):**
- API Key: `AIza...` (from aistudio.google.com)
- OR: Use Google Cloud Vertex AI (better for production)
  - Project ID
  - Service account JSON
  - Region: us-central1 or us-east1
- Rate limits: 60 RPM (free), 1,000+ RPM (paid)
- **Cost:** $0.00025/1K input tokens, $0.005/1K output tokens (Gemini 1.5 Pro)
- **Setup:** https://aistudio.google.com/app/apikey OR https://console.cloud.google.com/vertex-ai

**Perplexity AI:**
- API Key: `pplx-...` (from perplexity.ai)
- **Cost:** $0.001/request (varies by model)
- **Setup:** https://www.perplexity.ai/settings/api

**CRITICAL:** You need ALL FOUR API keys. Each AI provides different perspectives for quality.

---

### Cloud Platform Credentials

#### **Supabase (Database & Storage - PRIMARY)**
- Already configured in your `.env`:
  - `VITE_SUPABASE_URL`
  - `VITE_SUPABASE_ANON_KEY`
- Service role key (for backend): `SUPABASE_SERVICE_ROLE_KEY`
- Database URL: `postgresql://postgres:[password]@[project-ref].supabase.co:5432/postgres`
- **Setup:** https://supabase.com/dashboard

#### **AWS (Optional - for scale)**
- Access Key ID: `AKIA...`
- Secret Access Key: `...`
- Region: `us-east-1` (or preferred)
- Account ID: 12 digits
- **Services needed:**
  - S3 (storage)
  - EC2 (workers)
  - Lambda (serverless)
  - SQS (queues)
  - CloudWatch (monitoring)
- **Setup:** https://aws.amazon.com/console/

#### **Google Cloud (Optional - for scale)**
- Project ID: `your-project-id`
- Service Account Email: `worker@your-project.iam.gserviceaccount.com`
- Service Account JSON key file
- Region: `us-central1` or `us-east1`
- **Services needed:**
  - Cloud Storage (buckets)
  - Compute Engine (VMs)
  - Cloud Run (containers)
  - Pub/Sub (queues)
  - Cloud Monitoring
- **Setup:** https://console.cloud.google.com/

#### **Azure (Optional - for scale)**
- Subscription ID
- Tenant ID
- Service Principal (App ID + Secret)
- Resource Group name
- Region: `eastus` or `westus2`
- **Services needed:**
  - Blob Storage
  - Virtual Machines
  - Container Instances
  - Service Bus (queues)
  - Monitor
- **Setup:** https://portal.azure.com/

---

### Additional Services

#### **CDN (for file delivery)**
**Option 1: Cloudflare (Recommended for start)**
- Account email
- API Token
- Zone ID (for your domain)
- **Cost:** Free tier available, Pro at $20/month
- **Setup:** https://dash.cloudflare.com/

**Option 2: AWS CloudFront**
- Included with AWS account
- Distribution ID after setup
- **Cost:** Pay per GB transferred

**Option 3: Google Cloud CDN**
- Included with GCP account
- **Cost:** Pay per GB transferred

#### **Monitoring & Logging**
**Option 1: Datadog (Comprehensive)**
- API Key
- Application Key
- **Cost:** $15/host/month (monitoring), $0.10/GB (logs)
- **Setup:** https://app.datadoghq.com/

**Option 2: Elastic Stack (Self-hosted)**
- Elasticsearch cluster
- Kibana dashboard
- Logstash/Filebeat
- **Cost:** Infrastructure only (free software)

**Option 3: Cloud-native (Simplest)**
- AWS: CloudWatch (included)
- GCP: Cloud Logging (included)
- Azure: Monitor (included)

#### **Error Tracking**
**Sentry:**
- DSN (Data Source Name)
- Project ID
- Organization slug
- **Cost:** Free for 5K events/month, $26/month for 50K
- **Setup:** https://sentry.io/

---

### Domain & Email

**Domain Registrar:**
- Domain name (e.g., youreducation.com)
- DNS management access
- **Providers:** Namecheap, Google Domains, Cloudflare Registrar

**Email Service (for notifications, alerts):**
**Option 1: SendGrid**
- API Key
- **Cost:** Free for 100 emails/day, $15/month for 40K
- **Setup:** https://sendgrid.com/

**Option 2: AWS SES**
- Included with AWS
- **Cost:** $0.10 per 1,000 emails

---

## 💻 SECTION 2: SOFTWARE REQUIREMENTS

### Development Environment

**Required Software:**
- **Node.js:** v18+ (https://nodejs.org/)
- **npm:** v9+ (comes with Node.js)
- **Git:** v2.30+ (https://git-scm.com/)
- **VS Code:** Latest (https://code.visualstudio.com/) OR your preferred IDE
- **Docker Desktop:** Latest (https://www.docker.com/products/docker-desktop/)
- **Docker Compose:** v2.0+ (included with Docker Desktop)

**Optional but Recommended:**
- **Postman:** API testing (https://www.postman.com/)
- **Insomnia:** API testing alternative (https://insomnia.rest/)
- **TablePlus:** Database GUI (https://tableplus.com/)
- **Supabase CLI:** `npm install -g supabase` (for local development)

---

### Production Dependencies (npm packages)

**Already installed (from your package.json):**
```json
{
  "@supabase/supabase-js": "^2.57.4",
  "lucide-react": "^0.344.0",
  "react": "^18.3.1",
  "react-dom": "^18.3.1"
}
```

**Additional packages needed for workers:**
```bash
# AI SDK clients
npm install openai anthropic @google/generative-ai axios

# Queue/messaging
npm install bull redis ioredis aws-sdk @google-cloud/pubsub

# File processing
npm install pdf-lib epubjs marked latex.js

# Utilities
npm install dotenv zod uuid date-fns lodash

# Monitoring
npm install @sentry/node pino pino-pretty

# Testing
npm install --save-dev vitest @testing-library/react @testing-library/jest-dom
```

**For Python workers (alternative):**
```bash
pip install openai anthropic google-generativeai requests
pip install redis celery boto3 google-cloud-storage
pip install pypdf2 ebooklib markdown python-docx
pip install python-dotenv pydantic
pip install sentry-sdk
```

---

### Container Images (Docker)

**Base images needed:**
```dockerfile
# Node.js worker
FROM node:18-alpine

# Python worker
FROM python:3.11-slim

# For LaTeX generation
FROM texlive/texlive:latest
```

**Container registry:**
- Docker Hub (free for public images)
- AWS ECR (private, $0.10/GB/month)
- Google Artifact Registry (private, $0.10/GB/month)
- GitHub Container Registry (free for public)

---

## 🖥️ SECTION 3: HARDWARE & VM REQUIREMENTS

### Scenario A: 500-5,000 Workers (Low Funding)

**Recommended VMs:**

**AWS EC2:**
- Instance type: `c7i.8xlarge` (32 vCPU, 64 GB RAM)
- Workers per VM: 100-200 (I/O-heavy tasks)
- VMs needed:
  - 500 workers: 3-5 VMs
  - 2,000 workers: 10-20 VMs
  - 5,000 workers: 25-50 VMs
- Cost: ~$1.36/hour per VM = $979/month per VM
- **Total cost:** $3,000-50,000/month

**GCP Compute Engine:**
- Instance type: `c3-standard-44` (44 vCPU, 88 GB RAM)
- Workers per VM: 100-220
- VMs needed: Similar to AWS
- Cost: ~$1.50/hour per VM = $1,080/month per VM

**Azure Virtual Machines:**
- Instance type: `F32s_v2` (32 vCPU, 64 GB RAM)
- Workers per VM: 100-160
- VMs needed: Similar to AWS
- Cost: ~$1.26/hour per VM = $907/month per VM

**Cheapest option: Azure F-series OR AWS Spot Instances (70% discount)**

---

### Scenario B: 10,000-100,000 Workers (Mid Funding)

**Recommended VMs:**

**AWS EC2:**
- Instance type: `c7i.24xlarge` (96 vCPU, 192 GB RAM) - Largest in C7i family
- Workers per VM: 300-500
- VMs needed:
  - 10K workers: 20-35 VMs
  - 50K workers: 100-170 VMs
  - 100K workers: 200-335 VMs
- Cost: ~$4.08/hour per VM = $2,937/month per VM
- **Total cost:** $60K-1M/month

**OR: Kubernetes cluster with smaller nodes:**
- Instance type: `c7i.8xlarge` (32 vCPU)
- Nodes: 40-1,000 nodes
- Auto-scaling: Enabled
- Managed service: EKS (AWS), GKE (Google), AKS (Azure)

**Multi-region deployment recommended at this scale**

---

### Scenario C: 100,000-1,000,000 Workers (High Funding)

**Recommended VMs:**

**AWS EC2:**
- Instance type: `c7i.48xlarge` (192 vCPU, 384 GB RAM) - LARGEST
- Workers per VM: 500-1,000
- VMs needed:
  - 100K workers: 100-200 VMs
  - 500K workers: 500-1,000 VMs
  - 1M workers: 1,000-2,000 VMs
- Cost: ~$8.16/hour per VM = $5,875/month per VM
- **Total cost:** $600K-12M/month

**GCP Compute Engine:**
- Instance type: `c3-standard-176` (176 vCPU, 352 GB RAM) - LARGEST
- Workers per VM: 500-880
- VMs needed: Similar to AWS
- Cost: ~$8.00/hour per VM

**Azure:**
- Instance type: `HC44rs` (44 vCPU, 352 GB RAM, HPC-optimized)
- Workers per VM: 200-400
- OR: Use Azure Batch for massive scaling

**Multi-cloud + Multi-region REQUIRED at this scale**

---

### Scenario D: 1M-5M Workers (Ultra Extreme)

**Bare metal + Cloud hybrid:**

**Bare Metal Servers (for cost efficiency at scale):**
- **Vendors:** Equinix Metal, OVHcloud, Hetzner
- **Specs:** Dual AMD EPYC 7763 (128 cores each = 256 cores total)
- **RAM:** 512 GB - 2 TB
- **Workers per server:** 1,000-2,500
- **Servers needed:**
  - 1M workers: 400-1,000 servers
  - 5M workers: 2,000-5,000 servers
- **Cost:** $500-1,500/month per server
- **Total:** $200K-7.5M/month

**Cloud for bursting:**
- Use AWS/GCP/Azure for overflow
- Kubernetes federation across clouds
- Global load balancing

**HPC Options:**
- AWS ParallelCluster
- Google Cloud HPC
- Azure CycleCloud
- Allocate entire datacenters if needed

---

## 📊 SECTION 4: STORAGE REQUIREMENTS

### Scenario A: 500-5,000 Workers

**Storage needed (English only, generating 1,000 topics):**
- Per topic: 23 GB
- 1,000 topics: 23 TB
- With backups (3×): 69 TB

**Supabase Storage:**
- Sufficient for start
- Cost: $0.021/GB/month = $1,449/month for 69 TB

**AWS S3 (backup):**
- Standard: $0.023/GB/month
- Glacier (cold): $0.00099/GB/month
- 69 TB total: ~$1,587/month (Standard) OR $68/month (Glacier)

---

### Scenario B: 10K-100K Workers

**Storage needed (English only, generating 50,000 topics):**
- 50,000 topics: 1.15 PB
- With backups (3×): 3.45 PB

**Multi-cloud storage:**
- Primary: Supabase + AWS S3
- Backup: Google Cloud Storage
- Archive: AWS Glacier Deep Archive

**Cost:** ~$70K-80K/month

---

### Scenario C & D: 100K+ Workers

**Storage needed (all 520,200 topics, English only):**
- 520,200 topics: 12 PB
- With backups (3×): 36 PB

**With 1,000 languages:**
- Per language: 12 PB
- 1,000 languages: 12,000 PB = 12 EB (exabytes)
- With backups: 36 EB

**Multi-cloud, multi-region strategy essential**
**Cost:** Negotiate volume discounts (millions per month)

---

## 🔄 SECTION 5: QUEUE & MESSAGING SYSTEMS

### Scenario A: 500-5,000 Workers

**Simple queue:**
- **Redis** (managed): Upstash, Redis Cloud, AWS ElastiCache
- **Queues needed:** 1-3 queues
  - `master-book-queue`
  - `addon-generation-queue`
  - `verification-queue`
- **Cost:** $50-200/month

---

### Scenario B: 10K-100K Workers

**Distributed queues:**
- **AWS SQS:** 1-50 queues (FIFO or Standard)
- **Google Cloud Pub/Sub:** 10-100 topics
- **Queue sharding:** Split by subject group (24 groups)
- **Cost:** $500-5,000/month

---

### Scenario C: 100K-1M Workers

**Massive queue infrastructure:**
- **Kafka cluster:** Self-managed or MSK (AWS), Confluent
- **Partitions:** 100-1,000 partitions
- **Topics:** 50-500 topics
- **Cost:** $10K-50K/month

---

### Scenario D: 1M-5M Workers

**Planet-scale messaging:**
- **Apache Kafka** (multi-region, multi-cloud)
- **Or: Apache Pulsar** (better for geo-distribution)
- **Partitions:** 1,000-10,000
- **Replication:** 3× across regions
- **Cost:** $100K-500K/month

---

## 🗄️ SECTION 6: DATABASE REQUIREMENTS

### Scenario A: Single Supabase Instance

**Sufficient for:**
- 520,200 topics metadata
- Generation progress tracking
- User data
- Quality scores

**Supabase Pro plan:**
- Database: 8 GB (expandable to 256 GB)
- Connections: 200 (expandable)
- Cost: $25/month + overages

---

### Scenario B: Add Read Replicas

**Primary database:** Supabase (writes)
**Read replicas:** 2-5 replicas (reads)
**Cost:** $25/month (primary) + $10-25/month per replica

---

### Scenario C: Database Sharding

**Shard by:** Subject group (24 shards)
**Each shard:** Separate Supabase project OR PostgreSQL instance
**Coordination:** Application-level routing
**Cost:** $600-1,500/month (24 shards)

---

### Scenario D: Distributed Database

**Options:**
- **CockroachDB:** Multi-region, auto-sharding
- **YugabyteDB:** PostgreSQL-compatible, distributed
- **Google Cloud Spanner:** Global consistency
- **Amazon Aurora Global:** Multi-region replication

**Cost:** $10K-100K/month

---

## 🌐 SECTION 7: NETWORKING REQUIREMENTS

### Bandwidth Estimates

**Per topic generation (complete workflow):**
- API calls: ~10 MB uploaded, ~50 MB downloaded
- File uploads: ~23 GB uploaded
- **Total per topic:** ~23.06 GB bandwidth

**Bandwidth needed:**
- 1,000 topics: 23 TB
- 10,000 topics: 230 TB
- 100,000 topics: 2.3 PB

**Cost:**
- AWS: $0.09/GB = $207/topic = $207K for 1,000 topics
- GCP: $0.08/GB (slightly cheaper)
- Cloudflare: Free egress (if using Cloudflare)

**Use CDN to reduce costs!**

---

### VPC & Networking Setup

**AWS VPC:**
- CIDR: 10.0.0.0/16
- Subnets: Public (workers) + Private (databases)
- NAT Gateway: For private subnet internet access
- Security groups: Worker SG, DB SG, ALB SG
- Internet Gateway: For public access

**GCP VPC:**
- Similar structure
- Cloud NAT for private instances
- Firewall rules

**Multi-region:**
- VPC peering between regions
- OR: Use global load balancer

---

## 🚀 SECTION 8: ORCHESTRATION & DEPLOYMENT

### Container Orchestration

**Kubernetes (Recommended for Scenario B+):**
- **Managed services:**
  - AWS: EKS (Elastic Kubernetes Service)
  - GCP: GKE (Google Kubernetes Engine)
  - Azure: AKS (Azure Kubernetes Service)
- **Cost:** ~$70-150/month per cluster (control plane) + nodes

**Docker Swarm (Simpler, for Scenario A):**
- Self-managed
- Easier than Kubernetes
- Less features but sufficient for small scale

**Serverless (Alternative for specific tasks):**
- AWS Lambda
- Google Cloud Functions
- Azure Functions
- **Limits:** 15 min max execution (Lambda), memory limits
- **Use for:** Quick tasks, not long-running workers

---

### CI/CD Pipeline

**GitHub Actions (Recommended):**
- Already integrated with GitHub
- Free for public repos
- $0.008/minute for private repos
- **Workflow:**
  1. Push code → GitHub
  2. Actions run tests
  3. Build Docker image
  4. Push to registry
  5. Deploy to production (Kubernetes/Swarm)

**Alternatives:**
- GitLab CI/CD
- CircleCI
- Jenkins (self-hosted)

---

### Infrastructure as Code

**Terraform (Recommended):**
- Manage all cloud resources as code
- Version controlled
- Reproducible deployments
- Multi-cloud support

**Alternatives:**
- AWS CloudFormation (AWS only)
- Google Cloud Deployment Manager (GCP only)
- Pulumi (modern, multi-cloud)

---

## 🔐 SECTION 9: SECURITY & COMPLIANCE

### Secrets Management

**AWS Secrets Manager:**
- Store API keys, database passwords
- Automatic rotation
- Cost: $0.40/secret/month + $0.05 per 10K API calls

**Google Secret Manager:**
- Similar to AWS
- Cost: $0.06 per secret version/month

**HashiCorp Vault:**
- Self-hosted
- More control
- Free (OSS) or Enterprise

**Environment Variables (for development):**
- `.env` file (NEVER commit to Git!)
- Use `.env.example` as template

---

### SSL/TLS Certificates

**Let's Encrypt (Free):**
- Auto-renewal with Certbot
- Trusted by all browsers

**AWS Certificate Manager (Free with AWS):**
- Auto-renewal
- Integrated with CloudFront, ALB

**Cloudflare (Free):**
- Automatic SSL
- DDoS protection included

---

### Access Control

**IAM (Identity & Access Management):**
- Principle of least privilege
- Create service accounts per service
- Rotate credentials regularly
- MFA for admin accounts

**Network Security:**
- Firewall rules (allow only necessary ports)
- Private subnets for databases
- Bastion host for SSH access
- VPN for admin access

---

## 📈 SECTION 10: MONITORING & OBSERVABILITY

### Metrics to Track

**System Health:**
- CPU usage per VM/container
- RAM usage
- Disk I/O
- Network bandwidth
- API latency
- Queue depth

**Application Metrics:**
- Topics generated per hour
- Average generation time
- Error rate
- Quality scores
- API costs per topic
- Worker utilization

**Business Metrics:**
- Total topics completed
- Revenue per topic
- Cost per topic
- Profit margin
- User signups
- Conversion rate

---

### Dashboards

**Grafana (Recommended):**
- Open source
- Beautiful dashboards
- Integrates with Prometheus, InfluxDB
- Self-hosted or Grafana Cloud

**Cloud-native:**
- AWS CloudWatch Dashboards
- Google Cloud Monitoring
- Azure Monitor

**Required dashboards:**
1. System overview (all key metrics)
2. Worker performance (by worker type)
3. Cost tracking (real-time spend)
4. Quality monitoring (scores, errors)
5. Business KPIs (revenue, users, growth)

---

### Alerting

**Alert on:**
- Error rate > 5%
- Quality score < 85
- API rate limit approaching
- Storage > 90% full
- Cost exceeding budget by 20%
- System downtime
- Database connection failures

**Alert channels:**
- Email (immediate)
- Slack/Discord (real-time)
- PagerDuty (for on-call)
- SMS (critical only)

---

## 💰 SECTION 11: COST SUMMARY

### Scenario A: 500-5,000 Workers
- VMs: $3K-50K/month
- Storage: $1.5K-10K/month
- API costs: $30K-300K/month (depends on generation volume)
- Database: $25-100/month
- Monitoring: $0-500/month
- **Total:** ~$35K-360K/month

### Scenario B: 10K-100K Workers
- VMs: $60K-1M/month
- Storage: $10K-80K/month
- API costs: $300K-3M/month
- Database: $100-1K/month
- Monitoring: $500-5K/month
- **Total:** ~$370K-4M/month

### Scenario C: 100K-1M Workers
- VMs: $600K-12M/month
- Storage: $80K-500K/month
- API costs: $3M-30M/month
- Database: $1K-100K/month
- Monitoring: $5K-50K/month
- **Total:** ~$3.7M-42M/month

### Scenario D: 1M-5M Workers
- Hardware/VMs: $200K-7.5M/month
- Storage: $500K-5M/month
- API costs: $30M-150M/month
- Database: $100K-1M/month
- Monitoring: $50K-500K/month
- **Total:** ~$31M-164M/month

**These are operational costs. One-time content generation is different from continuous operation.**

---

## ✅ SETUP CHECKLIST

### Phase 1: Local Development (Week 1)
- [ ] Install Node.js, npm, Git, VS Code, Docker
- [ ] Clone repository
- [ ] Install dependencies (`npm install`)
- [ ] Get Supabase keys (already have)
- [ ] Get AI API keys (OpenAI, Anthropic, Google, Perplexity)
- [ ] Create `.env` file with all keys
- [ ] Test locally (`npm run dev`)
- [ ] Build Docker image
- [ ] Test Docker container locally

### Phase 2: Cloud Setup (Week 2)
- [ ] Choose primary cloud (AWS, GCP, or Azure)
- [ ] Create account
- [ ] Set up billing alerts
- [ ] Create VPC/network
- [ ] Set up IAM roles/service accounts
- [ ] Create storage buckets
- [ ] Set up database (or use Supabase)
- [ ] Set up queue system
- [ ] Set up container registry

### Phase 3: Deployment (Week 3)
- [ ] Push Docker image to registry
- [ ] Set up Kubernetes cluster (or Docker Swarm)
- [ ] Deploy first worker pod
- [ ] Test with 1 worker
- [ ] Scale to 10 workers
- [ ] Monitor and optimize
- [ ] Set up CI/CD pipeline
- [ ] Set up monitoring dashboards
- [ ] Set up alerting

### Phase 4: Scaling (Ongoing)
- [ ] Scale to 100 workers
- [ ] Scale to 1,000 workers
- [ ] Add auto-scaling rules
- [ ] Add read replicas (database)
- [ ] Expand to multiple regions
- [ ] Add multi-cloud (if needed)
- [ ] Optimize costs continuously

---

## 🎯 RECOMMENDED STARTING POINT

**For initial launch (proof of concept):**
1. Use Supabase (database + storage) - $25/month
2. OpenAI API only (GPT-4) - ~$100/month for testing
3. 1-10 workers on your local machine (free)
4. Total cost: ~$125/month

**Once proven, scale to Scenario A:**
1. Add Anthropic, Google, Perplexity APIs
2. Deploy 100-500 workers on AWS/GCP
3. Set up proper monitoring
4. Total cost: ~$35K-50K/month

**Then scale based on funding and demand.**

---

This covers EVERYTHING you need from zero to mega-scale! 🚀
