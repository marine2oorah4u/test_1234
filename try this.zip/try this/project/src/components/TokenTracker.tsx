import { useState, useEffect } from 'react';
import { Activity, AlertTriangle, CheckCircle, TrendingUp, TrendingDown, Zap } from 'lucide-react';
import { AI_MODELS, CloudProvider } from '../config/maximumQualityModels';
import { modelRouter } from '../config/maximumQualityModels';

interface TokenTrackerProps {
  compact?: boolean;
  provider?: CloudProvider;
}

export function TokenTracker({ compact = false, provider }: TokenTrackerProps) {
  const [modelStats, setModelStats] = useState<any[]>([]);
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    const updateStats = () => {
      const stats = Object.values(AI_MODELS)
        .filter(model => !provider || model.provider === provider)
        .map(model => {
          const usage = model.currentUsage;
          const maxTokens = model.maxTPM;
          const remaining = maxTokens - usage.tokens;
          const percentUsed = (usage.tokens / maxTokens) * 100;
          const resetTime = new Date(usage.lastReset);
          const minutesSinceReset = (Date.now() - resetTime.getTime()) / 60000;
          const tokensPerMinute = usage.tokens / Math.max(minutesSinceReset, 1);

          return {
            id: model.id,
            name: model.name,
            provider: model.provider,
            tokens: {
              used: usage.tokens,
              max: maxTokens,
              remaining,
              percentUsed,
            },
            requests: {
              used: usage.requests,
              max: model.maxRPM,
              remaining: model.maxRPM - usage.requests,
              percentUsed: (usage.requests / model.maxRPM) * 100,
            },
            rate: {
              tokensPerMinute: Math.round(tokensPerMinute),
              requestsPerMinute: Math.round(usage.requests / Math.max(minutesSinceReset, 1)),
            },
            cost: {
              estimated: (
                (usage.tokens * 0.3 / 1000000) * model.cost.inputPer1M +
                (usage.tokens * 0.7 / 1000000) * model.cost.outputPer1M
              ).toFixed(2),
            },
            health: percentUsed < 70 ? 'healthy' : percentUsed < 90 ? 'warning' : 'critical',
            enabled: model.enabled,
            priority: model.priority,
          };
        })
        .sort((a, b) => a.priority - b.priority || b.tokens.percentUsed - a.tokens.percentUsed);

      setModelStats(stats);
    };

    updateStats();
    const interval = setInterval(() => {
      updateStats();
      setRefreshKey(k => k + 1);
    }, 2000);

    return () => clearInterval(interval);
  }, [provider, refreshKey]);

  if (compact) {
    return (
      <div className="space-y-2">
        {modelStats.slice(0, 5).map(stat => (
          <div key={stat.id} className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              {stat.health === 'healthy' ? (
                <CheckCircle className="w-4 h-4 text-green-600" />
              ) : stat.health === 'warning' ? (
                <AlertTriangle className="w-4 h-4 text-yellow-600" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-red-600" />
              )}
              <span className="text-gray-700">{stat.name}</span>
            </div>
            <div className="text-right">
              <div className="font-medium text-gray-900">{stat.tokens.remaining.toLocaleString()}</div>
              <div className="text-xs text-gray-500">tokens left</div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  const totalUsed = modelStats.reduce((sum, s) => sum + s.tokens.used, 0);
  const totalMax = modelStats.reduce((sum, s) => sum + s.tokens.max, 0);
  const totalCost = modelStats.reduce((sum, s) => sum + parseFloat(s.cost.estimated), 0);
  const avgHealth = modelStats.filter(s => s.health === 'healthy').length / modelStats.length;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-600">Total Tokens Used</span>
            <TrendingUp className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900">{totalUsed.toLocaleString()}</div>
          <div className="text-xs text-gray-500 mt-1">of {totalMax.toLocaleString()} available</div>
          <div className="mt-2 w-full bg-gray-100 rounded-full h-2">
            <div
              className="bg-blue-600 h-2 rounded-full"
              style={{ width: `${Math.min((totalUsed / totalMax) * 100, 100)}%` }}
            />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-600">Estimated Cost</span>
            <Zap className="w-4 h-4 text-yellow-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900">${totalCost.toFixed(2)}</div>
          <div className="text-xs text-gray-500 mt-1">current session</div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-600">Active Models</span>
            <Activity className="w-4 h-4 text-green-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900">
            {modelStats.filter(s => s.enabled).length}
          </div>
          <div className="text-xs text-gray-500 mt-1">of {modelStats.length} total</div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-600">System Health</span>
            <CheckCircle className="w-4 h-4 text-green-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900">{(avgHealth * 100).toFixed(0)}%</div>
          <div className="text-xs text-gray-500 mt-1">models healthy</div>
        </div>
      </div>

      <div className="space-y-3">
        {modelStats.map(stat => (
          <div
            key={stat.id}
            className={`bg-white rounded-lg shadow-sm border p-4 transition-all ${
              stat.health === 'critical' ? 'border-red-300 bg-red-50' :
              stat.health === 'warning' ? 'border-yellow-300 bg-yellow-50' :
              'border-gray-200'
            }`}
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg ${
                  stat.health === 'healthy' ? 'bg-green-100' :
                  stat.health === 'warning' ? 'bg-yellow-100' :
                  'bg-red-100'
                }`}>
                  {stat.health === 'healthy' ? (
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  ) : (
                    <AlertTriangle className={`w-5 h-5 ${
                      stat.health === 'warning' ? 'text-yellow-600' : 'text-red-600'
                    }`} />
                  )}
                </div>
                <div>
                  <h3 className="font-bold text-gray-900">{stat.name}</h3>
                  <p className="text-sm text-gray-600">{stat.provider.toUpperCase()}</p>
                </div>
              </div>
              <div className="text-right">
                <div className="px-3 py-1 rounded-full text-xs font-medium" style={{
                  backgroundColor: stat.enabled ? '#dcfce7' : '#fee2e2',
                  color: stat.enabled ? '#166534' : '#991b1b',
                }}>
                  {stat.enabled ? 'Enabled' : 'Disabled'}
                </div>
                <div className="text-xs text-gray-500 mt-1">Priority: {stat.priority}</div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm text-gray-600">Token Usage</span>
                  <span className="text-sm font-medium text-gray-900">
                    {stat.tokens.percentUsed.toFixed(1)}%
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div
                    className={`h-2.5 rounded-full transition-all ${
                      stat.tokens.percentUsed > 90 ? 'bg-red-600' :
                      stat.tokens.percentUsed > 70 ? 'bg-yellow-600' :
                      'bg-green-600'
                    }`}
                    style={{ width: `${Math.min(stat.tokens.percentUsed, 100)}%` }}
                  />
                </div>
                <div className="flex items-center justify-between mt-1 text-xs text-gray-600">
                  <span>{stat.tokens.used.toLocaleString()} used</span>
                  <span className="font-medium text-gray-900">
                    {stat.tokens.remaining.toLocaleString()} left
                  </span>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm text-gray-600">Request Usage</span>
                  <span className="text-sm font-medium text-gray-900">
                    {stat.requests.percentUsed.toFixed(1)}%
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div
                    className={`h-2.5 rounded-full transition-all ${
                      stat.requests.percentUsed > 90 ? 'bg-red-600' :
                      stat.requests.percentUsed > 70 ? 'bg-yellow-600' :
                      'bg-green-600'
                    }`}
                    style={{ width: `${Math.min(stat.requests.percentUsed, 100)}%` }}
                  />
                </div>
                <div className="flex items-center justify-between mt-1 text-xs text-gray-600">
                  <span>{stat.requests.used.toLocaleString()} used</span>
                  <span className="font-medium text-gray-900">
                    {stat.requests.remaining.toLocaleString()} left
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-gray-200">
              <div className="flex items-center gap-4 text-sm">
                <div>
                  <span className="text-gray-600">Rate: </span>
                  <span className="font-medium text-gray-900">
                    {stat.rate.tokensPerMinute.toLocaleString()} tok/min
                  </span>
                </div>
                <div>
                  <span className="text-gray-600">Requests: </span>
                  <span className="font-medium text-gray-900">
                    {stat.rate.requestsPerMinute} req/min
                  </span>
                </div>
              </div>
              <div className="text-sm">
                <span className="text-gray-600">Est. Cost: </span>
                <span className="font-bold text-gray-900">${stat.cost.estimated}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
