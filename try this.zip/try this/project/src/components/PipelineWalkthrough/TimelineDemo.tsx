import { useState, useEffect, useRef } from 'react';
import { CheckCircle, Circle, Loader, Play, Pause, RotateCcw, X, Zap, Users, Database, Cpu } from 'lucide-react';
import type { PipelineDemo } from '../../config/completeBookPipeline';

interface TimelineDemoProps {
  demo: PipelineDemo;
  onComplete?: () => void;
}

interface AIWorkerState {
  id: string;
  type: string;
  instanceNumber: number;
  status: 'querying' | 'processing' | 'complete';
  progress: number;
  currentTask: string;
}

export function TimelineDemo({ demo, onComplete }: TimelineDemoProps) {
  const [showIntro, setShowIntro] = useState(true);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [stepProgress, setStepProgress] = useState(0);
  const [completedMicroTasks, setCompletedMicroTasks] = useState<Set<number>>(new Set());
  const [activeMicroTask, setActiveMicroTask] = useState<number | null>(null);
  const [activeMicroTaskProgress, setActiveMicroTaskProgress] = useState(0);
  const [logLines, setLogLines] = useState<string[]>([]);
  const [aiWorkers, setAIWorkers] = useState<AIWorkerState[]>([]);
  const [showCompletionOverlay, setShowCompletionOverlay] = useState(false);
  const [microTaskResults, setMicroTaskResults] = useState<Map<number, string>>(new Map());
  const [showErrorScenario, setShowErrorScenario] = useState(false);
  const [hasTriggeredError, setHasTriggeredError] = useState(false);

  const activeStepRef = useRef<HTMLDivElement>(null);
  const stepProgressRef = useRef(0);
  const logUpdateCounter = useRef(0);

  const currentStep = demo.steps[currentStepIndex];
  const isLastStep = currentStepIndex === demo.steps.length - 1;

  // Scroll active step into view
  useEffect(() => {
    if (activeStepRef.current) {
      activeStepRef.current.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest',
        inline: 'nearest'
      });
    }
  }, [currentStepIndex]);

  // Reset when step changes
  useEffect(() => {
    // Pause before starting new step
    setIsPlaying(false);
    setStepProgress(0);
    stepProgressRef.current = 0;
    setCompletedMicroTasks(new Set());
    setActiveMicroTask(null);
    setActiveMicroTaskProgress(0);
    setLogLines([]);
    setMicroTaskResults(new Map());
    logUpdateCounter.current = 0;

    // Initialize AI workers for this step - show up to 12 workers max
    const workers: AIWorkerState[] = [];
    let workerIdCounter = 0;

    currentStep.workers.forEach((workerType) => {
      // Distribute display slots across worker types
      const remainingSlots = 12 - workers.length;
      const displayCount = Math.min(workerType.count, Math.max(1, Math.floor(remainingSlots / (currentStep.workers.length - currentStep.workers.indexOf(workerType)))));

      for (let i = 0; i < displayCount; i++) {
        workers.push({
          id: `${workerType.type}-${workerIdCounter++}`,
          type: workerType.type,
          instanceNumber: i + 1,
          status: 'querying',
          progress: 0,
          currentTask: 'Waiting to start...'
        });
      }
    });

    setAIWorkers(workers);

    // Resume after brief pause (but not if intro is showing)
    if (!showIntro) {
      const resumeTimer = setTimeout(() => {
        setIsPlaying(true);
      }, 800);

      return () => clearTimeout(resumeTimer);
    }
  }, [currentStepIndex, currentStep, showIntro]);

  // Main step progress - SINGLE TIMER
  useEffect(() => {
    if (!isPlaying) return;

    let timer: NodeJS.Timeout;

    // Short delay before progress starts (workers initialize first)
    const startDelay = setTimeout(() => {
      const duration = currentStep.duration;
      const interval = 50;
      const increment = (interval / duration) * 100;

      timer = setInterval(() => {
        setStepProgress(prev => {
          const next = prev + increment;
          const clamped = next >= 100 ? 100 : next;
          stepProgressRef.current = clamped;
          return clamped;
        });
      }, interval);
    }, 300);

    return () => {
      clearTimeout(startDelay);
      if (timer) clearInterval(timer);
    };
  }, [isPlaying, currentStep.duration]);

  // Force all workers to complete immediately when step reaches 100%
  useEffect(() => {
    if (stepProgress >= 100 && aiWorkers.length > 0) {
      setAIWorkers(prev => prev.map(worker => ({
        ...worker,
        progress: 100,
        status: 'complete' as const,
        currentTask: 'Complete ✓'
      })));
    }
  }, [stepProgress, aiWorkers.length]);

  // Handle step completion separately
  useEffect(() => {
    if (stepProgress < 100) return;

    const timeout = setTimeout(() => {
      // Mark error as triggered after Step 8 completes
      if (showErrorScenario && currentStep.id === 'step8-fix-issues') {
        setHasTriggeredError(true);
      }

      if (!isLastStep) {
        setCurrentStepIndex(i => i + 1);
      } else {
        setIsPlaying(false);
        setTimeout(() => {
          setShowCompletionOverlay(true);
        }, 500);
      }
    }, 700);

    return () => clearTimeout(timeout);
  }, [stepProgress, isLastStep, showErrorScenario, currentStep.id]);

  // Update AI workers based on step progress with realistic variance
  useEffect(() => {
    if (!isPlaying || aiWorkers.length === 0) return;

    const workerInterval = setInterval(() => {
      const currentStepProgress = stepProgressRef.current;

      setAIWorkers(prev => {
        if (prev.length === 0) return prev;

        return prev.map((worker, idx) => {
          // Each worker has unique characteristics
          const workerSeed = parseInt(worker.id.split('-')[1]);

          let targetProgress: number;
          let newProgress: number;

          // When step is nearly complete (95%+), force all workers to complete together
          if (currentStepProgress >= 95) {
            // All workers converge to completion
            targetProgress = currentStepProgress;
            const diff = targetProgress - worker.progress;
            newProgress = Math.min(100, worker.progress + Math.max(1, diff * 0.5));
          } else {
            // Normal variance during main progress
            const speedMultiplier = [0.85, 0.90, 0.95, 1.0, 1.05, 1.10, 1.15][workerSeed % 7];
            const randomJitter = (Math.random() - 0.5) * 3; // Random -1.5 to +1.5
            targetProgress = (currentStepProgress * speedMultiplier) + randomJitter;
            const clampedTarget = Math.max(0, Math.min(100, targetProgress));

            // Smooth progress movement with occasional bursts
            const diff = clampedTarget - worker.progress;
            const burstChance = Math.random();
            const progressIncrement = burstChance > 0.95
              ? Math.max(2, diff * 0.6) // Occasional burst
              : Math.max(0.5, diff * 0.3); // Normal speed

            newProgress = Math.min(100, worker.progress + progressIncrement);
          }

          let status: 'querying' | 'processing' | 'complete' = worker.status;
          let currentTask = worker.currentTask;

          // Different task descriptions based on worker type and progress
          if (newProgress < 5) {
            status = 'querying';
            currentTask = 'Initializing connection...';
          } else if (newProgress < 15) {
            status = 'querying';
            const queryTasks = [
              `Authenticating with ${worker.type}...`,
              `Establishing ${worker.type} session...`,
              `Preparing ${worker.type} request...`
            ];
            currentTask = queryTasks[workerSeed % queryTasks.length];
          } else if (newProgress < 30) {
            status = 'querying';
            const sendingTasks = [
              `Sending prompt to ${worker.type}...`,
              `Querying ${worker.type} API...`,
              `Waiting for ${worker.type} response...`
            ];
            currentTask = sendingTasks[workerSeed % sendingTasks.length];
          } else if (newProgress < 50) {
            status = 'processing';
            const earlyTasks = [
              'Receiving response stream...',
              'Parsing AI output...',
              'Extracting structured data...',
              'Analyzing content quality...'
            ];
            currentTask = earlyTasks[Math.floor((newProgress / 10 + workerSeed) % earlyTasks.length)];
          } else if (newProgress < 75) {
            status = 'processing';
            const midTasks = [
              'Validating output format...',
              'Checking content guidelines...',
              'Processing educational content...',
              'Formatting markdown...',
              'Generating metadata...'
            ];
            currentTask = midTasks[Math.floor((newProgress / 12 + workerSeed) % midTasks.length)];
          } else if (newProgress < 92) {
            status = 'processing';
            const lateTasks = [
              'Quality checking...',
              'Verifying completeness...',
              'Final content review...',
              'Preparing output...'
            ];
            currentTask = lateTasks[Math.floor((newProgress / 15 + workerSeed) % lateTasks.length)];
          } else if (newProgress < 100) {
            status = 'processing';
            currentTask = 'Finalizing and saving...';
          } else {
            status = 'complete';
            currentTask = 'Complete ✓';
          }

          return {
            ...worker,
            progress: newProgress,
            status,
            currentTask
          };
        });
      });
    }, 100); // Update workers more frequently to stay in sync with timer

    return () => clearInterval(workerInterval);
  }, [isPlaying, aiWorkers.length]);

  // Calculate total workers for use in effects
  const totalAIWorkers = currentStep.workers.reduce((sum, w) => sum + w.count, 0);

  // Micro tasks progress
  useEffect(() => {
    if (!currentStep.microTasks) return;

    const totalTasks = currentStep.microTasks.length;
    const completedCount = Math.floor((stepProgress / 100) * totalTasks);

    const newCompleted = new Set<number>();
    const newResults = new Map(microTaskResults);

    for (let i = 0; i < completedCount; i++) {
      newCompleted.add(i);
      // Generate consistent result for each completed task
      if (!newResults.has(i)) {
        const task = currentStep.microTasks[i];
        if (task.name?.includes('Worker') && task.detail?.includes('...')) {
          // Generate word count that increases with task index
          const baseWords = 500 + (i * 50);
          const variation = Math.floor(Math.random() * 100);
          newResults.set(i, `✓ ${baseWords + variation} words`);
        } else if (task.detail?.includes('citations')) {
          const citations = 10 + (i * 2) + Math.floor(Math.random() * 5);
          newResults.set(i, `✓ ${citations} citations`);
        } else if (task.detail?.includes('...')) {
          newResults.set(i, '✓ Complete');
        } else {
          newResults.set(i, task.detail || '✓ Complete');
        }
      }
    }

    setMicroTaskResults(newResults);
    setCompletedMicroTasks(newCompleted);

    if (completedCount < totalTasks && stepProgress < 100) {
      setActiveMicroTask(completedCount);
      // Calculate progress within the active task
      const taskProgressStart = (completedCount / totalTasks) * 100;
      const taskProgressEnd = ((completedCount + 1) / totalTasks) * 100;
      const taskProgressRange = taskProgressEnd - taskProgressStart;
      const relativeProgress = ((stepProgress - taskProgressStart) / taskProgressRange) * 100;
      setActiveMicroTaskProgress(Math.max(0, Math.min(100, relativeProgress)));
    } else {
      setActiveMicroTask(null);
      setActiveMicroTaskProgress(0);
    }
  }, [stepProgress, currentStep.microTasks]);

  // Update log lines with extra activity for scale - throttled for readability
  useEffect(() => {
    if (!currentStep.logLines) return;

    // Only update logs every few progress ticks to slow down output
    logUpdateCounter.current += 1;
    if (logUpdateCounter.current % 3 !== 0 && stepProgress > 0 && stepProgress < 100) {
      return;
    }

    // Override logs for error scenario
    let logsToUse = currentStep.logLines;

    // Step 7: Show failures when error scenario is enabled
    if (showErrorScenario && currentStep.id === 'step7-format-verification' && !hasTriggeredError) {
      logsToUse = [
        '> Launching 5 format verifiers...',
        '> Checking PDF rendering quality...',
        '> Validating HTML structure...',
        '> Verifying WCAG compliance...',
        '> Checking citations and references...',
        '> Validating page layout...',
        '⚠ Verifier 2: Citation format mismatch detected',
        '⚠ Verifier 4: HTML accessibility issue found',
        '✗ Format verification: FAILED (2 issues)',
        '> Triggering fix phase...'
      ];
    }

    // Step 8: Show actual fix process when error scenario is enabled
    if (showErrorScenario && currentStep.id === 'step8-fix-issues' && !hasTriggeredError) {
      logsToUse = [
        '> Issues detected in Step 7',
        '> Launching 3 fix workers...',
        '> Worker 1: Querying 4 AIs for citation fix...',
        '> Worker 2: Querying 4 AIs for HTML fix...',
        '> Worker 3: Querying 4 AIs for validation...',
        '> GPT-4: Proposed citation format correction',
        '> Claude: Proposed alt-text addition',
        '> Gemini: Confirmed fixes',
        '> Perplexity: Validated solution',
        '> Applying fix 1: Citation format corrected',
        '> Applying fix 2: Aria-label added to image',
        '✓ All fixes applied',
        '> Re-running Step 7 verification...',
        '> Verifier 2: Citation format now PASS',
        '> Verifier 4: HTML accessibility now PASS',
        '✓ All verifiers: PASS',
        '> Issues resolved successfully'
      ];
    }

    const baseLogCount = Math.floor((stepProgress / 100) * logsToUse.length);
    const newLogs = [...logsToUse.slice(0, Math.max(1, baseLogCount))];

    // Add extra logs showing worker activity at scale
    if (stepProgress > 15 && stepProgress < 95 && totalAIWorkers > 10) {
      const completedSoFar = Math.floor((stepProgress / 100) * totalAIWorkers);
      const activeSoFar = Math.floor(completedSoFar * 0.8);

      // Worker completion messages - less frequent
      if (Math.random() > 0.75) {
        const workerNum = Math.floor(Math.random() * totalAIWorkers) + 1;
        const actions = ['Processing', 'Analyzing', 'Synthesizing', 'Validating', 'Generating'];
        const action = actions[Math.floor(Math.random() * actions.length)];
        newLogs.push(`> Worker ${workerNum}: ${action}... (${Math.floor(40 + Math.random() * 50)}%)`);
      }

      // Overall progress updates
      if (Math.random() > 0.80 && completedSoFar > 3) {
        newLogs.push(`> Progress: ${completedSoFar}/${totalAIWorkers} workers (${Math.floor(stepProgress)}%)`);
      }

      // Throughput stats
      if (Math.random() > 0.85) {
        const throughput = Math.floor(totalAIWorkers * 8.5 * (stepProgress / 100) + Math.random() * 50);
        newLogs.push(`> Throughput: ${throughput} tokens/sec`);
      }

      // Worker pool status for large jobs
      if (totalAIWorkers > 50 && Math.random() > 0.88) {
        newLogs.push(`> ${activeSoFar} active • ${completedSoFar - activeSoFar} completed • ${totalAIWorkers - completedSoFar} queued`);
      }

      // API call stats
      if (Math.random() > 0.90) {
        const apiCalls = Math.floor(totalAIWorkers * 0.25 * (stepProgress / 100));
        newLogs.push(`> API calls: ${apiCalls} parallel queries in flight`);
      }

      // Memory/resource info for massive scale
      if (totalAIWorkers > 100 && Math.random() > 0.93) {
        const memory = Math.floor(totalAIWorkers * 0.12 + Math.random() * 5);
        newLogs.push(`> Memory: ${memory}GB • CPU: ${Math.floor(60 + Math.random() * 30)}%`);
      }
    }

    setLogLines(newLogs);
  }, [stepProgress, currentStep.logLines, currentStep.id, totalAIWorkers, showErrorScenario, hasTriggeredError]);

  const handleReset = () => {
    setCurrentStepIndex(0);
    setStepProgress(0);
    setIsPlaying(true);
    setShowCompletionOverlay(false);
    setHasTriggeredError(false);
  };

  const handleBack = () => {
    setShowCompletionOverlay(false);
    if (onComplete) {
      onComplete();
    }
  };

  const activeWorkers = aiWorkers.filter(w => w.status !== 'complete').length;
  const completedWorkers = aiWorkers.filter(w => w.status === 'complete').length;

  // ROI Calculator logic
  useEffect(() => {
    const bookCountInput = document.getElementById('book-count-input') as HTMLInputElement;
    const addonCountInput = document.getElementById('addon-count-input') as HTMLInputElement;
    const revenueInput = document.getElementById('revenue-input') as HTMLInputElement;

    const updateCalculations = () => {
      if (!bookCountInput || !addonCountInput || !revenueInput) return;

      const bookCount = parseInt(bookCountInput.value) || 0;
      const addonCount = parseInt(addonCountInput.value) || 0;
      const revenuePerProduct = parseInt(revenueInput.value) || 0;

      const totalAddons = bookCount * addonCount;
      const totalProducts = bookCount + totalAddons;
      const totalRevenue = totalProducts * revenuePerProduct;
      const avgCostPerBook = 11.50;
      const totalCost = bookCount * avgCostPerBook;
      const roi = totalCost > 0 ? Math.round(totalRevenue / totalCost) : 0;

      const totalProductsEl = document.getElementById('total-products');
      const totalRevenueEl = document.getElementById('total-revenue');
      const totalCostEl = document.getElementById('total-cost');
      const roiEl = document.getElementById('roi');

      if (totalProductsEl) {
        totalProductsEl.textContent = totalProducts.toLocaleString();
        const breakdown = totalProductsEl.nextElementSibling;
        if (breakdown) {
          breakdown.textContent = `${bookCount.toLocaleString()} base + ${totalAddons.toLocaleString()} addons`;
        }
      }

      if (totalRevenueEl) {
        totalRevenueEl.textContent = `$${totalRevenue.toLocaleString()}`;
      }

      if (totalCostEl) {
        totalCostEl.textContent = `$${totalCost.toLocaleString()}`;
      }

      if (roiEl) {
        roiEl.textContent = `${roi}x`;
      }
    };

    if (bookCountInput && addonCountInput && revenueInput) {
      bookCountInput.addEventListener('input', updateCalculations);
      addonCountInput.addEventListener('input', updateCalculations);
      revenueInput.addEventListener('input', updateCalculations);

      return () => {
        bookCountInput.removeEventListener('input', updateCalculations);
        addonCountInput.removeEventListener('input', updateCalculations);
        revenueInput.removeEventListener('input', updateCalculations);
      };
    }
  }, [showCompletionOverlay]);

  // Intro screen comparing old vs new way
  if (showIntro) {
    return (
      <div className="min-h-screen flex items-center justify-center p-8" style={{ backgroundColor: 'var(--color-background)' }}>
        <div className="max-w-5xl w-full">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-4" style={{ color: 'var(--color-text)' }}>
              Book Generation Pipeline
            </h1>
            <p className="text-lg" style={{ color: 'var(--color-textMuted)' }}>
              See how our AI-powered system transforms educational content creation
            </p>
          </div>

          <div className="grid grid-cols-2 gap-8 mb-12">
            {/* Old Way */}
            <div
              className="rounded-xl p-8 border-2"
              style={{
                backgroundColor: 'var(--color-surface)',
                borderColor: 'var(--color-error)'
              }}
            >
              <div className="flex items-center gap-3 mb-6">
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: 'var(--color-error)' }}
                />
                <h2 className="text-2xl font-bold" style={{ color: 'var(--color-text)' }}>
                  Traditional Method
                </h2>
              </div>

              <div className="space-y-6">
                <div>
                  <div className="text-sm font-semibold mb-2" style={{ color: 'var(--color-textMuted)' }}>
                    Time per Book
                  </div>
                  <div className="text-4xl font-bold" style={{ color: 'var(--color-error)' }}>
                    5-7 hours
                  </div>
                </div>

                <div>
                  <div className="text-sm font-semibold mb-2" style={{ color: 'var(--color-textMuted)' }}>
                    API Costs per Book
                  </div>
                  <div className="text-4xl font-bold" style={{ color: 'var(--color-error)' }}>
                    $45-$80
                  </div>
                </div>

                <div>
                  <div className="text-sm font-semibold mb-2" style={{ color: 'var(--color-textMuted)' }}>
                    Quality Issues
                  </div>
                  <ul className="space-y-2 text-sm" style={{ color: 'var(--color-textMuted)' }}>
                    <li>• Manual verification needed</li>
                    <li>• Inconsistent output quality</li>
                    <li>• Human intervention required</li>
                    <li>• No automated error recovery</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* New Way */}
            <div
              className="rounded-xl p-8 border-2"
              style={{
                backgroundColor: 'var(--color-surface)',
                borderColor: 'var(--color-primary)'
              }}
            >
              <div className="flex items-center gap-3 mb-6">
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: 'var(--color-primary)' }}
                />
                <h2 className="text-2xl font-bold" style={{ color: 'var(--color-text)' }}>
                  Our AI Pipeline
                </h2>
              </div>

              <div className="space-y-6">
                <div>
                  <div className="text-sm font-semibold mb-2" style={{ color: 'var(--color-textMuted)' }}>
                    Time per Book
                  </div>
                  <div className="text-4xl font-bold" style={{ color: 'var(--color-primary)' }}>
                    4-8 minutes
                  </div>
                  <div className="text-sm font-semibold mt-1" style={{ color: 'var(--color-success)' }}>
                    50-80x faster
                  </div>
                </div>

                <div>
                  <div className="text-sm font-semibold mb-2" style={{ color: 'var(--color-textMuted)' }}>
                    API Costs per Book
                  </div>
                  <div className="text-4xl font-bold" style={{ color: 'var(--color-primary)' }}>
                    $8-$15
                  </div>
                  <div className="text-sm font-semibold mt-1" style={{ color: 'var(--color-success)' }}>
                    5-6x cheaper
                  </div>
                </div>

                <div>
                  <div className="text-sm font-semibold mb-2" style={{ color: 'var(--color-textMuted)' }}>
                    Quality Advantages
                  </div>
                  <ul className="space-y-2 text-sm" style={{ color: 'var(--color-textMuted)' }}>
                    <li>• Fully automated verification</li>
                    <li>• Consistent 95+ quality scores</li>
                    <li>• Zero human intervention</li>
                    <li>• Self-healing error recovery</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Stats Banner */}
          <div
            className="rounded-xl p-6 mb-8"
            style={{
              backgroundColor: 'var(--color-surface)',
              borderWidth: '1px',
              borderStyle: 'solid',
              borderColor: 'var(--color-border)'
            }}
          >
            <div className="grid grid-cols-3 gap-8 text-center">
              <div>
                <div className="text-3xl font-bold mb-2" style={{ color: 'var(--color-primary)' }}>
                  80+ Workers
                </div>
                <div className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
                  Parallel AI processing
                </div>
              </div>
              <div>
                <div className="text-3xl font-bold mb-2" style={{ color: 'var(--color-primary)' }}>
                  18 Steps
                </div>
                <div className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
                  Comprehensive quality checks
                </div>
              </div>
              <div>
                <div className="text-3xl font-bold mb-2" style={{ color: 'var(--color-primary)' }}>
                  4 AI Models
                </div>
                <div className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
                  GPT-4, Claude, Gemini, Perplexity
                </div>
              </div>
            </div>
          </div>

          {/* CTA */}
          <div className="flex justify-center gap-4">
            <button
              onClick={() => {
                setShowIntro(false);
                setIsPlaying(true);
              }}
              className="px-8 py-4 rounded-lg font-semibold text-lg transition"
              style={{
                backgroundColor: 'var(--color-primary)',
                color: 'var(--color-background)'
              }}
            >
              See How It Works
            </button>
            {onComplete && (
              <button
                onClick={() => {
                  setShowIntro(false);
                  if (onComplete) onComplete();
                }}
                className="px-8 py-4 rounded-lg font-semibold text-lg transition"
                style={{
                  backgroundColor: 'var(--color-surface)',
                  borderWidth: '1px',
                  borderStyle: 'solid',
                  borderColor: 'var(--color-border)',
                  color: 'var(--color-text)'
                }}
              >
                Skip Demo
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  if (showCompletionOverlay) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--color-background)' }}>
        <div
          className="max-w-3xl mx-4 p-12 rounded-2xl text-center"
          style={{
            backgroundColor: 'var(--color-surface)',
            borderWidth: '2px',
            borderStyle: 'solid',
            borderColor: 'var(--color-success)'
          }}
        >
          <div
            className="w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6"
            style={{ backgroundColor: 'var(--color-success)' }}
          >
            <CheckCircle className="w-16 h-16" style={{ color: 'white' }} />
          </div>
          <h2 className="text-5xl font-bold mb-4" style={{ color: 'var(--color-text)' }}>
            Pipeline Complete!
          </h2>
          <p className="text-2xl mb-4 leading-relaxed font-semibold" style={{ color: 'var(--color-primary)' }}>
            Book Generation: START → FINISH
          </p>
          <p className="text-xl mb-8 leading-relaxed" style={{ color: 'var(--color-textMuted)' }}>
            You just watched the complete 18-step pipeline. In production, steps 1-9 run <span className="font-bold" style={{ color: 'var(--color-primary)' }}>84 times in parallel</span> (one per section), creating an entire 12-chapter textbook in approximately <span className="font-bold" style={{ color: 'var(--color-success)' }}>75-90 minutes</span>.
          </p>

          <div className="grid grid-cols-3 gap-4 mb-8">
            <div className="p-4 rounded-xl" style={{ backgroundColor: 'var(--color-background)' }}>
              <div className="text-3xl font-bold mb-1" style={{ color: 'var(--color-primary)' }}>84</div>
              <div className="text-sm" style={{ color: 'var(--color-textMuted)' }}>Sections Generated</div>
            </div>
            <div className="p-4 rounded-xl" style={{ backgroundColor: 'var(--color-background)' }}>
              <div className="text-3xl font-bold mb-1" style={{ color: 'var(--color-success)' }}>240+</div>
              <div className="text-sm" style={{ color: 'var(--color-textMuted)' }}>Peak AI Workers</div>
            </div>
            <div className="p-4 rounded-xl" style={{ backgroundColor: 'var(--color-background)' }}>
              <div className="text-3xl font-bold mb-1" style={{ color: 'var(--color-accent)' }}>75-90</div>
              <div className="text-sm" style={{ color: 'var(--color-textMuted)' }}>Minutes Total</div>
            </div>
          </div>

          {/* ROI Calculator */}
          <div
            className="rounded-xl p-8 mb-8 text-left"
            style={{
              backgroundColor: 'var(--color-background)',
              borderWidth: '2px',
              borderStyle: 'solid',
              borderColor: 'var(--color-primary)'
            }}
          >
            <h3 className="text-2xl font-bold mb-6 text-center" style={{ color: 'var(--color-text)' }}>
              Business Impact Calculator
            </h3>

            <div className="grid grid-cols-2 gap-8 mb-6">
              {/* Left: Input */}
              <div className="space-y-6">
                <div>
                  <label className="text-sm font-semibold mb-2 block" style={{ color: 'var(--color-textMuted)' }}>
                    Base Books to Generate
                  </label>
                  <input
                    type="number"
                    min="1"
                    defaultValue="1000"
                    className="w-full px-4 py-3 rounded-lg text-lg font-semibold"
                    style={{
                      backgroundColor: 'var(--color-surface)',
                      borderWidth: '1px',
                      borderStyle: 'solid',
                      borderColor: 'var(--color-border)',
                      color: 'var(--color-text)'
                    }}
                    id="book-count-input"
                  />
                </div>

                <div>
                  <label className="text-sm font-semibold mb-2 block" style={{ color: 'var(--color-textMuted)' }}>
                    Addons per Book (avg)
                  </label>
                  <input
                    type="number"
                    min="1"
                    defaultValue="50"
                    className="w-full px-4 py-3 rounded-lg text-lg font-semibold"
                    style={{
                      backgroundColor: 'var(--color-surface)',
                      borderWidth: '1px',
                      borderStyle: 'solid',
                      borderColor: 'var(--color-border)',
                      color: 'var(--color-text)'
                    }}
                    id="addon-count-input"
                  />
                </div>

                <div>
                  <label className="text-sm font-semibold mb-2 block" style={{ color: 'var(--color-textMuted)' }}>
                    Avg Revenue per Product
                  </label>
                  <input
                    type="number"
                    min="1"
                    defaultValue="25"
                    className="w-full px-4 py-3 rounded-lg text-lg font-semibold"
                    style={{
                      backgroundColor: 'var(--color-surface)',
                      borderWidth: '1px',
                      borderStyle: 'solid',
                      borderColor: 'var(--color-border)',
                      color: 'var(--color-text)'
                    }}
                    id="revenue-input"
                  />
                </div>
              </div>

              {/* Right: Output */}
              <div className="space-y-4">
                <div
                  className="p-4 rounded-lg"
                  style={{ backgroundColor: 'var(--color-surface)' }}
                >
                  <div className="text-sm mb-1" style={{ color: 'var(--color-textMuted)' }}>
                    Total Products Generated
                  </div>
                  <div className="text-3xl font-bold" style={{ color: 'var(--color-primary)' }} id="total-products">
                    51,000
                  </div>
                  <div className="text-xs mt-1" style={{ color: 'var(--color-textMuted)' }}>
                    1,000 base + 50,000 addons
                  </div>
                </div>

                <div
                  className="p-4 rounded-lg"
                  style={{ backgroundColor: 'var(--color-surface)' }}
                >
                  <div className="text-sm mb-1" style={{ color: 'var(--color-textMuted)' }}>
                    Potential Revenue
                  </div>
                  <div className="text-3xl font-bold" style={{ color: 'var(--color-success)' }} id="total-revenue">
                    $1,275,000
                  </div>
                  <div className="text-xs mt-1" style={{ color: 'var(--color-textMuted)' }}>
                    @ $25 avg per product
                  </div>
                </div>

                <div
                  className="p-4 rounded-lg"
                  style={{ backgroundColor: 'var(--color-surface)' }}
                >
                  <div className="text-sm mb-1" style={{ color: 'var(--color-textMuted)' }}>
                    Total Generation Cost
                  </div>
                  <div className="text-3xl font-bold" style={{ color: 'var(--color-accent)' }} id="total-cost">
                    $11,500
                  </div>
                  <div className="text-xs mt-1" style={{ color: 'var(--color-textMuted)' }}>
                    @ $11.50 avg per book
                  </div>
                </div>

                <div
                  className="p-4 rounded-lg border-2"
                  style={{
                    backgroundColor: 'var(--color-surface)',
                    borderColor: 'var(--color-primary)'
                  }}
                >
                  <div className="text-sm mb-1" style={{ color: 'var(--color-textMuted)' }}>
                    ROI
                  </div>
                  <div className="text-3xl font-bold" style={{ color: 'var(--color-primary)' }} id="roi">
                    110x
                  </div>
                  <div className="text-xs mt-1" style={{ color: 'var(--color-textMuted)' }}>
                    Revenue / Cost
                  </div>
                </div>
              </div>
            </div>

            <div
              className="p-4 rounded-lg text-center"
              style={{
                backgroundColor: 'var(--color-surface)',
                borderWidth: '1px',
                borderStyle: 'dashed',
                borderColor: 'var(--color-primary)'
              }}
            >
              <div className="text-sm font-semibold" style={{ color: 'var(--color-text)' }}>
                Generation Time: 51,000 products in ~75-90 minutes (per batch of 1,000 base books)
              </div>
            </div>
          </div>

          {/* Sample Output Preview */}
          <div
            className="rounded-xl p-8 mb-8"
            style={{
              backgroundColor: 'var(--color-background)',
              borderWidth: '2px',
              borderStyle: 'solid',
              borderColor: 'var(--color-success)'
            }}
          >
            <h3 className="text-2xl font-bold mb-6 text-center" style={{ color: 'var(--color-text)' }}>
              Sample Output Preview
            </h3>

            <div className="grid grid-cols-3 gap-6">
              {/* Book Page Sample */}
              <div
                className="rounded-lg p-6"
                style={{
                  backgroundColor: 'white',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
                }}
              >
                <div className="text-xs font-bold mb-4 text-right text-gray-400">Page 42</div>
                <div className="border-b-2 border-gray-800 pb-2 mb-4">
                  <h4 className="text-lg font-bold text-gray-900">Chapter 3: Basic Addition</h4>
                  <div className="text-xs text-gray-500 mt-1">Section 3.2 - Adding Two-Digit Numbers</div>
                </div>
                <div className="space-y-3 text-sm text-gray-700 leading-relaxed">
                  <p>When adding two-digit numbers, we start by adding the ones place first, then move to the tens place.</p>
                  <div className="bg-blue-50 border-2 border-blue-200 rounded p-3 my-3">
                    <div className="text-xs font-bold text-blue-800 mb-2">Example:</div>
                    <div className="font-mono text-center text-lg">
                      <div>  23</div>
                      <div>+ 45</div>
                      <div className="border-t-2 border-blue-800 pt-1 mt-1">  68</div>
                    </div>
                  </div>
                  <p className="text-xs">Remember: If the ones place adds up to more than 9, we carry the 1 to the tens place.</p>
                </div>
                <div className="mt-4 pt-3 border-t border-gray-200 text-center">
                  <div className="text-xs text-gray-400">Mathematics • Grade 2 • Common Core Aligned</div>
                </div>
              </div>

              {/* Worksheet Sample */}
              <div
                className="rounded-lg p-6"
                style={{
                  backgroundColor: 'white',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
                }}
              >
                <div className="border-b-2 border-gray-800 pb-2 mb-4">
                  <h4 className="text-lg font-bold text-gray-900">Practice Worksheet</h4>
                  <div className="text-xs text-gray-500 mt-1">Addition Practice - Level 2</div>
                </div>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div className="border border-gray-300 rounded p-2">
                      <div className="font-bold text-xs text-gray-500 mb-1">Problem 1</div>
                      <div className="font-mono text-center">
                        <div>  34</div>
                        <div>+ 21</div>
                        <div className="border-t border-gray-400 mt-1 pt-1">____</div>
                      </div>
                    </div>
                    <div className="border border-gray-300 rounded p-2">
                      <div className="font-bold text-xs text-gray-500 mb-1">Problem 2</div>
                      <div className="font-mono text-center">
                        <div>  52</div>
                        <div>+ 37</div>
                        <div className="border-t border-gray-400 mt-1 pt-1">____</div>
                      </div>
                    </div>
                    <div className="border border-gray-300 rounded p-2">
                      <div className="font-bold text-xs text-gray-500 mb-1">Problem 3</div>
                      <div className="font-mono text-center">
                        <div>  18</div>
                        <div>+ 63</div>
                        <div className="border-t border-gray-400 mt-1 pt-1">____</div>
                      </div>
                    </div>
                    <div className="border border-gray-300 rounded p-2">
                      <div className="font-bold text-xs text-gray-500 mb-1">Problem 4</div>
                      <div className="font-mono text-center">
                        <div>  45</div>
                        <div>+ 29</div>
                        <div className="border-t border-gray-400 mt-1 pt-1">____</div>
                      </div>
                    </div>
                  </div>
                  <div className="text-xs text-gray-500 text-center pt-2 border-t border-gray-200">
                    Show your work in the space below
                  </div>
                </div>
              </div>

              {/* Flashcard Sample */}
              <div
                className="rounded-lg p-6"
                style={{
                  backgroundColor: 'white',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
                }}
              >
                <div className="border-b-2 border-gray-800 pb-2 mb-4">
                  <h4 className="text-lg font-bold text-gray-900">Digital Flashcards</h4>
                  <div className="text-xs text-gray-500 mt-1">Quick Practice Set</div>
                </div>
                <div className="space-y-3">
                  <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg p-4 text-white text-center">
                    <div className="text-xs font-bold mb-2">Question</div>
                    <div className="text-3xl font-bold">23 + 45 = ?</div>
                    <div className="text-xs mt-3 opacity-75">Tap to reveal answer</div>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="bg-green-100 border border-green-300 rounded p-2 text-center">
                      <div className="font-bold text-green-800">27 + 31</div>
                      <div className="text-green-600">= 58</div>
                    </div>
                    <div className="bg-green-100 border border-green-300 rounded p-2 text-center">
                      <div className="font-bold text-green-800">19 + 24</div>
                      <div className="text-green-600">= 43</div>
                    </div>
                    <div className="bg-yellow-100 border border-yellow-300 rounded p-2 text-center">
                      <div className="font-bold text-yellow-800">56 + 38</div>
                      <div className="text-yellow-600">In Progress</div>
                    </div>
                    <div className="bg-gray-100 border border-gray-300 rounded p-2 text-center">
                      <div className="font-bold text-gray-600">42 + 51</div>
                      <div className="text-gray-500">Not Started</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div
              className="mt-6 p-4 rounded-lg text-center"
              style={{
                backgroundColor: 'var(--color-surface)',
                borderWidth: '1px',
                borderStyle: 'dashed',
                borderColor: 'var(--color-success)'
              }}
            >
              <div className="text-sm font-semibold" style={{ color: 'var(--color-text)' }}>
                Every book includes: PDF pages, interactive worksheets, digital flashcards, assessments, answer keys, and educator guides
              </div>
            </div>
          </div>

          <div className="flex gap-4 justify-center">
            <button
              onClick={handleReset}
              className="px-8 py-4 rounded-xl font-semibold text-lg transition"
              style={{
                backgroundColor: 'var(--color-primary)',
                color: 'var(--color-background)'
              }}
            >
              <Play className="w-5 h-5 inline mr-2" />
              Watch Again
            </button>
            <button
              onClick={handleBack}
              className="px-8 py-4 rounded-xl font-semibold text-lg transition"
              style={{
                backgroundColor: 'var(--color-surface)',
                borderWidth: '2px',
                borderStyle: 'solid',
                borderColor: 'var(--color-border)',
                color: 'var(--color-text)'
              }}
            >
              <X className="w-5 h-5 inline mr-2" />
              Back to Demo
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--color-background)' }}>
      <div className="max-w-[1800px] mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex-1">
            <h1 className="text-3xl font-bold mb-2" style={{ color: 'var(--color-text)' }}>
              {demo.name}
            </h1>
            <p style={{ color: 'var(--color-textMuted)' }}>{demo.description}</p>
          </div>
          <button
            onClick={handleBack}
            className="p-2 rounded-lg transition"
            style={{
              backgroundColor: 'var(--color-surface)',
              color: 'var(--color-text)'
            }}
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Stats Bar */}
        <div className="grid grid-cols-4 gap-4 mb-6">
          <div
            className="p-4 rounded-xl"
            style={{
              backgroundColor: 'var(--color-surface)',
              borderWidth: '1px',
              borderStyle: 'solid',
              borderColor: 'var(--color-border)'
            }}
          >
            <div className="flex items-center gap-3">
              <Zap className="w-8 h-8" style={{ color: 'var(--color-primary)' }} />
              <div>
                <div className="text-2xl font-bold" style={{ color: 'var(--color-text)' }}>
                  {currentStepIndex + 1} / {demo.steps.length}
                </div>
                <div className="text-sm" style={{ color: 'var(--color-textMuted)' }}>Current Step</div>
              </div>
            </div>
          </div>

          <div
            className="p-4 rounded-xl"
            style={{
              backgroundColor: 'var(--color-surface)',
              borderWidth: '1px',
              borderStyle: 'solid',
              borderColor: 'var(--color-border)'
            }}
          >
            <div className="flex items-center gap-3">
              <Users className="w-8 h-8" style={{ color: 'var(--color-success)' }} />
              <div>
                <div className="text-2xl font-bold" style={{ color: 'var(--color-text)' }}>
                  {activeWorkers} / {totalAIWorkers}
                </div>
                <div className="text-sm" style={{ color: 'var(--color-textMuted)' }}>Active Workers</div>
              </div>
            </div>
          </div>

          <div
            className="p-4 rounded-xl"
            style={{
              backgroundColor: 'var(--color-surface)',
              borderWidth: '1px',
              borderStyle: 'solid',
              borderColor: 'var(--color-border)'
            }}
          >
            <div className="flex items-center gap-3">
              <Database className="w-8 h-8" style={{ color: 'var(--color-accent)' }} />
              <div>
                <div className="text-2xl font-bold" style={{ color: 'var(--color-text)' }}>
                  {currentStep.estimatedRealTime}
                </div>
                <div className="text-sm" style={{ color: 'var(--color-textMuted)' }}>Real-World Time</div>
              </div>
            </div>
          </div>

          <div
            className="p-4 rounded-xl"
            style={{
              backgroundColor: 'var(--color-surface)',
              borderWidth: '1px',
              borderStyle: 'solid',
              borderColor: 'var(--color-border)'
            }}
          >
            <div className="flex items-center gap-3">
              <CheckCircle className="w-8 h-8" style={{ color: 'var(--color-primary)' }} />
              <div>
                <div className="text-2xl font-bold" style={{ color: 'var(--color-text)' }}>
                  {Math.round(stepProgress)}%
                </div>
                <div className="text-sm" style={{ color: 'var(--color-textMuted)' }}>Step Progress</div>
              </div>
            </div>
          </div>
        </div>

        {/* Controls */}
        <div
          className="flex items-center gap-4 p-4 rounded-xl mb-6"
          style={{
            backgroundColor: 'var(--color-surface)',
            borderWidth: '1px',
            borderStyle: 'solid',
            borderColor: 'var(--color-border)'
          }}
        >
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="p-3 rounded-lg transition"
              style={{
                backgroundColor: 'var(--color-primary)',
                color: 'var(--color-background)'
              }}
            >
              {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
            </button>
            <button
              onClick={handleReset}
              className="p-3 rounded-lg transition"
              style={{
                backgroundColor: 'var(--color-surface)',
                borderWidth: '1px',
                borderStyle: 'solid',
                borderColor: 'var(--color-border)',
                color: 'var(--color-text)'
              }}
            >
              <RotateCcw className="w-5 h-5" />
            </button>
          </div>

          <div className="flex items-center gap-2 px-4">
            <input
              type="checkbox"
              id="error-scenario"
              checked={showErrorScenario}
              onChange={(e) => {
                setShowErrorScenario(e.target.checked);
                setHasTriggeredError(false);
              }}
              className="w-4 h-4 rounded"
              style={{ accentColor: 'var(--color-error)' }}
            />
            <label
              htmlFor="error-scenario"
              className="text-sm font-semibold cursor-pointer"
              style={{ color: 'var(--color-text)' }}
            >
              Show Error Scenario
            </label>
          </div>

          <div className="flex-1">
            <div
              className="h-3 rounded-full overflow-hidden"
              style={{ backgroundColor: 'var(--color-background)' }}
            >
              <div
                className="h-full transition-all duration-200"
                style={{
                  width: `${((currentStepIndex / demo.steps.length) * 100) + (stepProgress / demo.steps.length)}%`,
                  backgroundColor: 'var(--color-primary)'
                }}
              />
            </div>
            <div className="flex justify-between mt-1 text-xs" style={{ color: 'var(--color-textMuted)' }}>
              <span>Pipeline Progress</span>
              <span>{Math.round(((currentStepIndex / demo.steps.length) * 100) + (stepProgress / demo.steps.length))}%</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-12 gap-6">
          {/* Left: Compact Timeline */}
          <div className="col-span-3">
            <div
              className="rounded-xl p-4 sticky top-4"
              style={{
                backgroundColor: 'var(--color-surface)',
                borderWidth: '1px',
                borderStyle: 'solid',
                borderColor: 'var(--color-border)',
                maxHeight: 'calc(100vh - 120px)',
                overflowY: 'auto'
              }}
            >
              <h2 className="text-lg font-bold mb-4" style={{ color: 'var(--color-text)' }}>
                All 18 Steps
              </h2>

              <div className="space-y-2">
                {demo.steps.map((step, index) => {
                  const isCompleted = index < currentStepIndex;
                  const isActive = index === currentStepIndex;

                  return (
                    <div
                      key={step.id}
                      ref={isActive ? activeStepRef : null}
                      className="flex items-center gap-2 p-2 rounded-lg transition"
                      style={{
                        backgroundColor: isActive
                          ? 'var(--color-primary)'
                          : isCompleted
                          ? 'var(--color-success)'
                          : 'var(--color-background)',
                        opacity: isActive || isCompleted ? 1 : 0.5
                      }}
                    >
                      <div className="flex-shrink-0">
                        {isCompleted ? (
                          <CheckCircle className="w-5 h-5" style={{ color: 'white' }} />
                        ) : isActive ? (
                          <Loader className="w-5 h-5 animate-spin" style={{ color: 'white' }} />
                        ) : (
                          <Circle className="w-5 h-5" style={{ color: 'var(--color-textMuted)' }} />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div
                          className="text-xs font-semibold truncate"
                          style={{
                            color: isActive || isCompleted ? 'white' : 'var(--color-text)'
                          }}
                        >
                          {index + 1}. {step.title}
                        </div>
                        <div
                          className="text-xs truncate"
                          style={{
                            color: isActive || isCompleted
                              ? 'rgba(255,255,255,0.7)'
                              : 'var(--color-textMuted)'
                          }}
                        >
                          {step.category}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Middle: Current Step Details + System Log */}
          <div className="col-span-5 flex flex-col gap-6" style={{ maxHeight: 'calc(100vh - 120px)' }}>
            {/* Current Task */}
            <div
              className="rounded-xl p-6 flex-shrink-0"
              style={{
                backgroundColor: 'var(--color-surface)',
                borderWidth: '2px',
                borderStyle: 'solid',
                borderColor: 'var(--color-primary)'
              }}
            >
              <div
                className="text-xs font-semibold uppercase tracking-wide mb-2"
                style={{ color: 'var(--color-primary)' }}
              >
                {currentStep.pipeline} • {currentStep.category}
              </div>
              <h2 className="text-2xl font-bold mb-4" style={{ color: 'var(--color-text)' }}>
                {currentStep.title}
              </h2>

              <div className="space-y-4">
                {/* Reality Check Badge */}
                <div
                  className="p-3 rounded-lg border-2"
                  style={{
                    backgroundColor: 'var(--color-background)',
                    borderColor: 'var(--color-success)',
                    borderStyle: 'dashed'
                  }}
                >
                  <div className="flex items-start gap-2 mb-2">
                    <CheckCircle className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: 'var(--color-success)' }} />
                    <div className="text-xs font-bold uppercase tracking-wide" style={{ color: 'var(--color-success)' }}>
                      Accurate Real-World Simulation
                    </div>
                  </div>
                  <div className="text-xs leading-relaxed" style={{ color: 'var(--color-textMuted)' }}>
                    This demo accurately simulates real production behavior: {currentStep.workers.reduce((sum, w) => sum + w.count, 0)} parallel AI workers processing content through Claude/GPT-4 APIs with actual timing estimates based on production data.
                  </div>
                </div>

                {/* Error Scenario Badge */}
                {showErrorScenario && (currentStep.id === 'step7-format-verification' || currentStep.id === 'step8-fix-issues') && !hasTriggeredError && (
                  <div
                    className="p-3 rounded-lg border-2"
                    style={{
                      backgroundColor: 'var(--color-background)',
                      borderColor: 'var(--color-error)',
                      borderStyle: 'dashed'
                    }}
                  >
                    <div className="flex items-start gap-2 mb-2">
                      <Zap className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: 'var(--color-error)' }} />
                      <div className="text-xs font-bold uppercase tracking-wide" style={{ color: 'var(--color-error)' }}>
                        Error Scenario Active
                      </div>
                    </div>
                    <div className="text-xs leading-relaxed" style={{ color: 'var(--color-textMuted)' }}>
                      {currentStep.id === 'step7-format-verification'
                        ? 'Step 7 will detect 2 validation failures (citation format + HTML accessibility). Watch the self-healing system automatically trigger fixes in Step 8.'
                        : 'Fix workers are now launching to resolve the 2 issues found in Step 7. They will query 4 AIs, apply corrections, then re-verify until all issues pass.'}
                    </div>
                  </div>
                )}

                <div>
                  <div
                    className="text-sm font-semibold mb-1"
                    style={{ color: 'var(--color-text)' }}
                  >
                    What's Happening
                  </div>
                  <p
                    className="text-sm leading-relaxed"
                    style={{ color: 'var(--color-textMuted)' }}
                  >
                    {currentStep.description}
                  </p>
                </div>

                <div>
                  <div
                    className="text-sm font-semibold mb-1"
                    style={{ color: 'var(--color-text)' }}
                  >
                    Technical Details
                  </div>
                  <p
                    className="text-sm leading-relaxed"
                    style={{ color: 'var(--color-textMuted)' }}
                  >
                    {currentStep.technicalDetails}
                  </p>
                </div>

                <div>
                  <div
                    className="text-sm font-semibold mb-1"
                    style={{ color: 'var(--color-text)' }}
                  >
                    Why This Matters
                  </div>
                  <p
                    className="text-sm leading-relaxed"
                    style={{ color: 'var(--color-textMuted)' }}
                  >
                    {currentStep.whyItMatters}
                  </p>
                </div>

                {stepProgress === 100 && (
                  <div
                    className="p-4 rounded-lg"
                    style={{
                      backgroundColor: 'var(--color-success)',
                      color: 'white'
                    }}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle className="w-5 h-5" />
                      <div className="font-semibold">Step Complete</div>
                    </div>
                    <div className="text-sm opacity-90">
                      Output: {currentStep.output}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Micro Tasks */}
            {currentStep.microTasks && currentStep.microTasks.length > 0 && (
              <div
                className="rounded-xl p-6 flex-shrink-0 overflow-y-auto"
                style={{
                  backgroundColor: 'var(--color-surface)',
                  borderWidth: '1px',
                  borderStyle: 'solid',
                  borderColor: 'var(--color-border)',
                  maxHeight: '300px'
                }}
              >
                <div className="mb-4">
                  <h3 className="text-lg font-bold" style={{ color: 'var(--color-text)' }}>
                    Sub-Tasks
                  </h3>
                  <p className="text-xs mt-1" style={{ color: 'var(--color-textMuted)' }}>
                    High-level operations (each may use multiple AI workers shown on right)
                  </p>
                </div>
                <div className="space-y-2">
                  {currentStep.microTasks.map((task, idx) => {
                    const isCompleted = completedMicroTasks.has(idx);
                    const isActive = activeMicroTask === idx;

                    return (
                      <div
                        key={idx}
                        className="flex items-center gap-3 p-3 rounded-lg transition"
                        style={{
                          backgroundColor: isActive
                            ? 'var(--color-primary)'
                            : isCompleted
                            ? 'var(--color-success)'
                            : 'var(--color-background)',
                          opacity: isActive || isCompleted ? 1 : 0.5
                        }}
                      >
                        {isCompleted ? (
                          <CheckCircle
                            className="w-4 h-4 flex-shrink-0"
                            style={{ color: 'white' }}
                          />
                        ) : isActive ? (
                          <Loader
                            className="w-4 h-4 flex-shrink-0 animate-spin"
                            style={{ color: 'white' }}
                          />
                        ) : (
                          <Circle
                            className="w-4 h-4 flex-shrink-0"
                            style={{ color: 'var(--color-textMuted)' }}
                          />
                        )}
                        <div className="flex-1 min-w-0">
                          <div
                            className="text-sm font-medium"
                            style={{
                              color: isActive || isCompleted ? 'white' : 'var(--color-text)'
                            }}
                          >
                            {task.name}
                          </div>
                          {task.detail && (
                            <div
                              className="text-xs"
                              style={{
                                color: isActive || isCompleted
                                  ? 'rgba(255,255,255,0.8)'
                                  : 'var(--color-textMuted)'
                              }}
                            >
                              {isCompleted
                                ? (microTaskResults.get(idx) || task.detail)
                                : isActive
                                  ? task.detail + ` ${Math.floor(activeMicroTaskProgress)}%`
                                  : task.detail
                              }
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* System Log */}
            <div
              className="rounded-xl p-6 flex-1 overflow-hidden flex flex-col"
              style={{
                backgroundColor: 'var(--color-surface)',
                borderWidth: '1px',
                borderStyle: 'solid',
                borderColor: 'var(--color-border)',
                minHeight: '450px',
                maxHeight: '650px'
              }}
            >
              <div className="flex items-center justify-between mb-4 flex-shrink-0">
                <h3 className="text-lg font-bold" style={{ color: 'var(--color-text)' }}>
                  Production Console
                </h3>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                  <div className="text-xs font-semibold" style={{ color: 'var(--color-textMuted)' }}>
                    LIVE
                  </div>
                </div>
              </div>
              <div
                className="font-mono text-xs p-4 rounded-lg overflow-y-auto flex-1"
                style={{
                  backgroundColor: '#0a0a0a',
                  color: '#e5e5e5',
                  lineHeight: '1.5',
                  boxShadow: 'inset 0 2px 8px rgba(0,0,0,0.3)'
                }}
              >
                {logLines.map((line, idx) => {
                  // Parse log line for better formatting
                  const isSuccess = line.includes('✓') || line.includes('complete') || line.includes('Success');
                  const isProgress = line.includes('Progress:');
                  const isPercentage = line.includes('%') && !isProgress;
                  const isThroughput = line.includes('Throughput:') || line.includes('tokens/sec');
                  const isMemory = line.includes('Memory:') || line.includes('CPU:');
                  const isAPI = line.includes('API calls');
                  const isStatus = line.includes('active •') || line.includes('completed •');
                  const isInfo = line.includes('[INFO]');
                  const isLaunching = line.includes('Launching') || line.includes('Starting') || line.includes('Initializing');
                  const isWorker = line.includes('worker') || line.includes('Worker');
                  const isError = line.includes('Error') || line.includes('Failed');

                  return (
                    <div
                      key={idx}
                      className="whitespace-pre-wrap font-bold"
                      style={{
                        color: isError
                          ? '#ef4444'
                          : isSuccess
                          ? '#22c55e'
                          : isProgress
                          ? '#3b82f6'
                          : isThroughput
                          ? '#f59e0b'
                          : isMemory
                          ? '#10b981'
                          : isAPI
                          ? '#8b5cf6'
                          : isStatus
                          ? '#06b6d4'
                          : isPercentage
                          ? '#ec4899'
                          : isLaunching
                          ? '#06b6d4'
                          : isWorker
                          ? '#a855f7'
                          : isInfo
                          ? '#94a3b8'
                          : '#e5e5e5',
                        marginBottom: '0.25rem'
                      }}
                    >
                      {line}
                    </div>
                  );
                })}
                {logLines.length === 0 && (
                  <div className="opacity-50 italic font-normal" style={{ color: '#71717a' }}>
                    $ Waiting for pipeline to start...
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right: AI Workers */}
          <div className="col-span-4">
            <div
              className="rounded-xl p-6 sticky top-4 flex flex-col"
              style={{
                backgroundColor: 'var(--color-surface)',
                borderWidth: '1px',
                borderStyle: 'solid',
                borderColor: 'var(--color-border)',
                maxHeight: 'calc(100vh - 120px)'
              }}
            >
              <div className="mb-4 flex-shrink-0 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Cpu className="w-5 h-5" style={{ color: 'var(--color-primary)' }} />
                    <h3 className="text-lg font-bold" style={{ color: 'var(--color-text)' }}>
                      AI Workers
                    </h3>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-semibold" style={{ color: 'var(--color-text)' }}>
                      {activeWorkers} Active
                    </div>
                    <div className="text-xs" style={{ color: 'var(--color-textMuted)' }}>
                      {completedWorkers} Complete
                    </div>
                  </div>
                </div>

                {/* Real-time Stats */}
                <div
                  className="px-3 py-2 rounded text-center"
                  style={{
                    backgroundColor: 'var(--color-background)',
                    borderWidth: '1px',
                    borderStyle: 'solid',
                    borderColor: 'var(--color-border)'
                  }}
                >
                  <div className="text-xs" style={{ color: 'var(--color-textMuted)' }}>Estimated Time Remaining</div>
                  <div className="text-lg font-bold" style={{ color: 'var(--color-text)' }}>
                    {Math.ceil((100 - stepProgress) / 100 * (currentStep.duration / 1000))}s
                  </div>
                </div>
              </div>

              <div className="space-y-3 overflow-y-auto flex-1">
                {aiWorkers.map((worker) => (
                  <div
                    key={worker.id}
                    className="p-3 rounded-lg transition-all duration-300"
                    style={{
                      backgroundColor: worker.status === 'complete'
                        ? 'var(--color-success)'
                        : worker.status === 'processing'
                        ? 'var(--color-primary)'
                        : 'var(--color-background)',
                      borderWidth: '2px',
                      borderStyle: 'solid',
                      borderColor: worker.status === 'querying' && worker.progress < 10
                        ? '#ef4444'
                        : worker.status === 'complete'
                        ? 'var(--color-success)'
                        : worker.status === 'processing'
                        ? 'var(--color-primary)'
                        : 'var(--color-border)',
                      transform: worker.status === 'processing' ? 'scale(1.02)' : 'scale(1)',
                      boxShadow: worker.status === 'processing'
                        ? '0 4px 12px rgba(0,0,0,0.15)'
                        : 'none'
                    }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        {worker.status === 'complete' ? (
                          <CheckCircle className="w-4 h-4" style={{ color: 'white' }} />
                        ) : (
                          <Loader className="w-4 h-4 animate-spin" style={{
                            color: worker.status === 'processing' ? 'white' : 'var(--color-textMuted)'
                          }} />
                        )}
                        <span
                          className="text-xs font-semibold"
                          style={{
                            color: worker.status === 'complete' || worker.status === 'processing'
                              ? 'white'
                              : 'var(--color-text)'
                          }}
                        >
                          {worker.type} #{worker.instanceNumber}
                        </span>
                      </div>
                      <span
                        className="text-xs font-medium"
                        style={{
                          color: worker.status === 'complete' || worker.status === 'processing'
                            ? 'rgba(255,255,255,0.9)'
                            : 'var(--color-primary)'
                        }}
                      >
                        {Math.round(worker.progress)}%
                      </span>
                    </div>

                    <div
                      className="h-1.5 rounded-full overflow-hidden mb-2"
                      style={{ backgroundColor: 'rgba(0,0,0,0.2)' }}
                    >
                      <div
                        className="h-full transition-all duration-300"
                        style={{
                          width: `${worker.progress}%`,
                          backgroundColor: worker.status === 'complete'
                            ? 'white'
                            : worker.status === 'processing'
                            ? 'rgba(255,255,255,0.8)'
                            : 'var(--color-primary)'
                        }}
                      />
                    </div>

                    <div
                      className="text-xs"
                      style={{
                        color: worker.status === 'complete' || worker.status === 'processing'
                          ? 'rgba(255,255,255,0.8)'
                          : 'var(--color-textMuted)'
                      }}
                    >
                      {worker.currentTask}
                    </div>
                  </div>
                ))}
              </div>

              {totalAIWorkers > aiWorkers.length && (
                <div
                  className="mt-3 text-xs text-center p-2 rounded flex-shrink-0"
                  style={{
                    backgroundColor: 'var(--color-background)',
                    color: 'var(--color-textMuted)'
                  }}
                >
                  + {totalAIWorkers - aiWorkers.length} more workers running in parallel
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
