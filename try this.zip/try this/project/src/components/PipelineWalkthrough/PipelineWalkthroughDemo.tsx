import { useState, useEffect, useRef } from 'react';
import { CheckCircle, Circle, Loader, Play, Pause, SkipForward, RotateCcw, AlertTriangle, CheckCheck } from 'lucide-react';
import { PipelineDemo, PipelineStep, MicroTask } from '../../config/pipelineWalkthroughData';

interface PipelineWalkthroughDemoProps {
  demo: PipelineDemo;
  onComplete?: () => void;
}

interface ErrorEvent {
  id: string;
  message: string;
  status: 'detecting' | 'fixing' | 'fixed';
}

export function PipelineWalkthroughDemo({ demo, onComplete }: PipelineWalkthroughDemoProps) {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [microTaskStatuses, setMicroTaskStatuses] = useState<MicroTask[]>([]);
  const [researchSources, setResearchSources] = useState<string[]>([]);
  const [activeSourceIndex, setActiveSourceIndex] = useState(0);
  const [fadeState, setFadeState] = useState<'in' | 'out'>('in');
  const [errorEvent, setErrorEvent] = useState<ErrorEvent | null>(null);
  const [isRetrying, setIsRetrying] = useState(false);
  const [logOutput, setLogOutput] = useState<string[]>([]);

  const startTimeRef = useRef<number>(Date.now());
  const errorCheckRef = useRef<NodeJS.Timeout | null>(null);

  const currentStep = demo.steps[currentStepIndex];
  const totalSteps = demo.steps.length;
  const overallProgress = ((currentStepIndex + (progress / 100)) / totalSteps) * 100;

  const allSteps = demo.steps;
  const visibleStepCount = 5;
  const startIndex = Math.max(0, Math.min(currentStepIndex, allSteps.length - visibleStepCount));
  const visibleSteps = allSteps.slice(startIndex, startIndex + visibleStepCount);

  useEffect(() => {
    if (currentStep.microTasks) {
      setMicroTaskStatuses(currentStep.microTasks.map(t => ({ ...t })));
      const sources = currentStep.microTasks
        .filter(t => t.detail)
        .map(t => t.detail!);
      setResearchSources(sources);
      setActiveSourceIndex(0);
    } else {
      setMicroTaskStatuses([]);
      setResearchSources([]);
    }
    setFadeState('out');
    setLogOutput([]);
    setTimeout(() => setFadeState('in'), 300);

    if (errorCheckRef.current) {
      clearInterval(errorCheckRef.current);
    }

    const shouldShowError = Math.random() > 0.7 && currentStepIndex > 0 && !isRetrying;
    if (shouldShowError) {
      const errorMessages = [
        'API rate limit exceeded - switching to backup provider',
        'Content quality below threshold - initiating automatic revision',
        'Source verification failed - re-checking citations',
        'Consensus score below 90% - triggering review cycle'
      ];
      const randomError = errorMessages[Math.floor(Math.random() * errorMessages.length)];
      const errorTriggerPoint = 75 + Math.random() * 10;
      let hasTriggered = false;

      errorCheckRef.current = setInterval(() => {
        if (progress >= errorTriggerPoint && !hasTriggered && !errorEvent) {
          hasTriggered = true;
          setErrorEvent({ id: Date.now().toString(), message: randomError, status: 'detecting' });
          setIsPlaying(false);

          setTimeout(() => {
            setErrorEvent(prev => prev ? { ...prev, status: 'fixing' } : null);
            setTimeout(() => {
              setErrorEvent(prev => prev ? { ...prev, status: 'fixed' } : null);
              setTimeout(() => {
                setErrorEvent(null);
                setIsRetrying(true);
                setIsPlaying(true);
              }, 1500);
            }, 2000);
          }, 1500);
        }
      }, 100);
    }

    return () => {
      if (errorCheckRef.current) {
        clearInterval(errorCheckRef.current);
      }
    };
  }, [currentStepIndex, currentStep, progress, errorEvent, isRetrying]);

  useEffect(() => {
    if (!isPlaying) return;

    const baseDuration = 8000;
    const hasManyMicroTasks = currentStep.microTasks && currentStep.microTasks.length > 5;
    const duration = hasManyMicroTasks ? 4000 : baseDuration;

    startTimeRef.current = Date.now();

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTimeRef.current;
      const newProgress = Math.min((elapsed / duration) * 100, 100);
      setProgress(newProgress);

      if (researchSources.length > 0 && newProgress < 100) {
        const sourceIndex = Math.floor((newProgress / 100) * researchSources.length);
        if (sourceIndex !== activeSourceIndex && sourceIndex < researchSources.length) {
          setActiveSourceIndex(sourceIndex);
        }
      }

      if (currentStep.microTasks && currentStep.microTasks.length > 0) {
        const totalTasks = currentStep.microTasks.length;
        const tasksToComplete = Math.floor((newProgress / 100) * totalTasks);

        setMicroTaskStatuses(prev =>
          prev.map((task, index) => {
            if (index < tasksToComplete) {
              return { ...task, status: 'completed' as const };
            } else if (index === tasksToComplete) {
              return { ...task, status: 'in_progress' as const };
            }
            return task;
          })
        );
      }

      if (currentStep.logLines && currentStep.logLines.length > 0) {
        const logIndex = Math.min(
          Math.floor((newProgress / 100) * currentStep.logLines.length),
          currentStep.logLines.length - 1
        );
        if (logIndex >= 0 && logIndex < currentStep.logLines.length) {
          const currentLog = currentStep.logLines[logIndex];
          setLogOutput(prev => {
            if (!prev.includes(currentLog)) {
              return [...prev, currentLog];
            }
            return prev;
          });
        }
      }

      if (newProgress >= 100) {
        clearInterval(interval);
        setIsPlaying(false);

        if (currentStepIndex < totalSteps - 1) {
          setTimeout(() => {
            setProgress(0);
            setTimeout(() => {
              setCurrentStepIndex(currentStepIndex + 1);
              setIsRetrying(false);
              setIsPlaying(true);
            }, 300);
          }, 800);
        } else {
          setTimeout(() => {
            onComplete?.();
          }, 2000);
        }
      }
    }, 50);

    return () => clearInterval(interval);
  }, [isPlaying, currentStepIndex, currentStep, totalSteps, onComplete, researchSources.length, activeSourceIndex]);

  const handlePlayPause = () => {
    if (!isPlaying) {
      startTimeRef.current = Date.now();
    }
    setIsPlaying(!isPlaying);
  };

  const handleNext = () => {
    if (currentStepIndex < totalSteps - 1) {
      setCurrentStepIndex(currentStepIndex + 1);
      setProgress(0);
      setIsRetrying(false);
    }
  };

  const handleReset = () => {
    setCurrentStepIndex(0);
    setProgress(0);
    setIsPlaying(false);
    setIsRetrying(false);
  };


  const activeTask = microTaskStatuses.find(t => t.status === 'in_progress');
  const completedTasks = microTaskStatuses.filter(t => t.status === 'completed').length;
  const pendingTasks = microTaskStatuses.filter(t => t.status === 'pending').length;
  const totalWorkers = currentStep.workers.reduce((sum, w) => sum + w.count, 0);

  return (
    <div className="h-screen flex flex-col items-center justify-center relative overflow-hidden" style={{ backgroundColor: 'var(--color-background)' }}>
      <div className="absolute inset-0 opacity-5 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full blur-3xl" style={{ backgroundColor: 'var(--color-primary)' }} />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full blur-3xl" style={{ backgroundColor: 'var(--color-accent)' }} />
      </div>

      <div className="w-full max-w-5xl relative z-10" style={{ height: '70vh', maxHeight: '700px' }}>
        <div className="h-2 w-full mb-6 rounded-full overflow-hidden relative" style={{ backgroundColor: 'var(--color-surface)' }}>
          <div
            className="h-full transition-all duration-300 ease-out relative"
            style={{
              width: `${overallProgress}%`,
              background: `linear-gradient(90deg, var(--color-primary), var(--color-accent))`,
              boxShadow: `0 0 20px var(--color-primary)`
            }}
          >
            <div className="absolute inset-0 opacity-30" style={{
              background: 'linear-gradient(90deg, transparent, white, transparent)',
              animation: 'shimmer 2s infinite'
            }} />
          </div>
        </div>

        <div className="h-full flex gap-4">
          <div className="w-72 flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold truncate" style={{ color: 'var(--color-text)' }}>
                {currentStep.pipeline}
              </h2>
              <div className="flex gap-1.5">
                <button
                  onClick={handlePlayPause}
                  className="p-1.5 rounded-lg"
                  style={{ backgroundColor: 'var(--color-primary)', color: 'var(--color-background)' }}
                >
                  {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                </button>
                <button
                  onClick={handleNext}
                  disabled={currentStepIndex >= totalSteps - 1}
                  className="p-1.5 rounded-lg"
                  style={{
                    backgroundColor: 'var(--color-accent)',
                    color: 'var(--color-background)',
                    opacity: currentStepIndex >= totalSteps - 1 ? 0.3 : 1
                  }}
                >
                  <SkipForward className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={handleReset}
                  className="p-1.5 rounded-lg"
                  style={{
                    backgroundColor: 'var(--color-surface)',
                    color: 'var(--color-text)',
                    borderWidth: '1px',
                    borderStyle: 'solid',
                    borderColor: 'var(--color-border)'
                  }}
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div
              className="flex-1 rounded-lg p-3 overflow-hidden"
              style={{
                backgroundColor: 'var(--color-surface)',
                borderWidth: '1px',
                borderStyle: 'solid',
                borderColor: 'var(--color-border)'
              }}
            >
              <div
                className="text-sm font-semibold uppercase tracking-wide mb-3"
                style={{ color: 'var(--color-textMuted)' }}
              >
                Pipeline Steps
              </div>

              <div className="space-y-3 relative" style={{
                transition: 'transform 500ms ease-out',
                transform: `translateY(-${(currentStepIndex - startIndex) * 72}px)`
              }}>
                {visibleSteps.map((step, index) => {
                  const actualIndex = startIndex + index;
                  const isCompleted = actualIndex < currentStepIndex;
                  const isActive = actualIndex === currentStepIndex;
                  const isPending = actualIndex > currentStepIndex;

                  return (
                    <div
                      key={step.id}
                      className="flex items-start gap-3 p-3 rounded-lg transition-all duration-500"
                      style={{
                        opacity: isPending ? 0.5 : 1,
                        backgroundColor: isActive ? 'var(--color-background)' : 'transparent',
                        borderWidth: isActive ? '2px' : '1px',
                        borderStyle: 'solid',
                        borderColor: isActive ? 'var(--color-primary)' : 'transparent'
                      }}
                    >
                      <div className="flex-shrink-0">
                        {isCompleted ? (
                          <CheckCircle className="w-4 h-4" style={{ color: 'var(--color-success)' }} />
                        ) : isActive ? (
                          <Loader className="w-4 h-4 animate-spin" style={{ color: 'var(--color-primary)' }} />
                        ) : (
                          <Circle className="w-4 h-4" style={{ color: 'var(--color-textMuted)' }} />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div
                          className="font-semibold text-sm leading-tight"
                          style={{
                            color: isActive ? 'var(--color-primary)' : 'var(--color-text)',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            display: '-webkit-box',
                            WebkitLineClamp: 2,
                            WebkitBoxOrient: 'vertical'
                          }}
                        >
                          {step.title}
                        </div>
                        {isActive && (
                          <div className="text-sm mt-1.5" style={{ color: 'var(--color-textMuted)' }}>
                            {Math.round(progress)}% complete
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="flex-1 flex flex-col gap-3">
            {errorEvent && (
              <div
                className="rounded-lg p-3 animate-slide-down"
                style={{
                  backgroundColor:
                    errorEvent.status === 'fixed' ? 'rgba(34, 197, 94, 0.1)' :
                    errorEvent.status === 'fixing' ? 'rgba(251, 146, 60, 0.1)' :
                    'rgba(239, 68, 68, 0.1)',
                  borderWidth: '1px',
                  borderStyle: 'solid',
                  borderColor:
                    errorEvent.status === 'fixed' ? 'var(--color-success)' :
                    errorEvent.status === 'fixing' ? 'var(--color-accent)' :
                    'var(--color-error)'
                }}
              >
                <div className="flex items-center gap-2">
                  {errorEvent.status === 'fixed' ? (
                    <CheckCheck className="w-4 h-4 flex-shrink-0" style={{ color: 'var(--color-success)' }} />
                  ) : errorEvent.status === 'fixing' ? (
                    <Loader className="w-4 h-4 flex-shrink-0 animate-spin" style={{ color: 'var(--color-accent)' }} />
                  ) : (
                    <AlertTriangle className="w-4 h-4 flex-shrink-0" style={{ color: 'var(--color-error)' }} />
                  )}
                  <div className="flex-1">
                    <div className="font-semibold text-xs" style={{ color: 'var(--color-text)' }}>
                      {errorEvent.status === 'fixed' ? 'Fixed - Retrying step:' : errorEvent.status === 'fixing' ? 'Auto-fixing:' : 'Error detected:'}
                    </div>
                    <div className="text-xs" style={{ color: 'var(--color-textMuted)' }}>
                      {errorEvent.message}
                      {errorEvent.status === 'fixing' && ' - Re-processing...'}
                      {errorEvent.status === 'fixed' && ' - Continuing...'}
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div
              className="rounded-lg p-3"
              style={{
                backgroundColor: 'var(--color-surface)',
                borderWidth: '1px',
                borderStyle: 'solid',
                borderColor: 'var(--color-border)'
              }}
            >
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium" style={{ color: 'var(--color-textMuted)' }}>
                    Step Progress
                  </span>
                  <span className="text-xl font-bold" style={{ color: 'var(--color-primary)' }}>
                    {Math.round(progress)}%
                  </span>
                </div>
                <div
                  className="h-3 rounded-full overflow-hidden relative"
                  style={{ backgroundColor: 'var(--color-background)' }}
                >
                  <div
                    className="h-full transition-all duration-300 ease-out relative"
                    style={{
                      width: `${progress}%`,
                      background: `linear-gradient(90deg, var(--color-primary), var(--color-accent))`,
                      boxShadow: `0 0 10px var(--color-accent)`
                    }}
                  >
                    <div className="absolute inset-0 opacity-30" style={{
                      background: 'linear-gradient(90deg, transparent, white, transparent)',
                      animation: 'shimmer 2s infinite'
                    }} />
                  </div>
                </div>
              </div>

              <div>
                <div
                  className="text-sm font-semibold uppercase tracking-wide mb-3"
                  style={{ color: 'var(--color-textMuted)' }}
                >
                  Active Workers: {totalWorkers}
                </div>
                <div className="space-y-1.5">
                  {currentStep.workers.map((worker, index) => (
                    <div
                      key={index}
                      className="flex items-center gap-2 p-2 rounded-lg relative overflow-hidden"
                      style={{ backgroundColor: 'var(--color-background)' }}
                    >
                      <div className="absolute inset-0 opacity-10" style={{
                        background: `linear-gradient(90deg, transparent, var(--color-primary), transparent)`,
                        animation: 'shimmer 3s infinite',
                        animationDelay: `${index * 0.3}s`
                      }} />
                      <Loader className="w-4 h-4 animate-spin flex-shrink-0 relative z-10" style={{ color: 'var(--color-primary)' }} />
                      <span className="flex-1 font-medium text-sm relative z-10" style={{ color: 'var(--color-text)' }}>
                        {worker.type}
                      </span>
                      <span
                        className="px-2 py-1 rounded-full text-sm font-semibold relative z-10"
                        style={{
                          backgroundColor: 'var(--color-primary)',
                          color: 'var(--color-background)',
                          boxShadow: '0 0 10px var(--color-primary)',
                          animation: 'pulse-glow 2s infinite'
                        }}
                      >
                        × {worker.count}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div
              className="flex-1 rounded-lg p-4 transition-opacity duration-300 overflow-hidden flex flex-col"
              style={{
                backgroundColor: 'var(--color-surface)',
                borderWidth: '1px',
                borderStyle: 'solid',
                borderColor: 'var(--color-border)',
                opacity: fadeState === 'in' ? 1 : 0.3
              }}
            >
              <div className="text-center mb-6">
                <div
                  className="text-sm font-semibold uppercase tracking-wider mb-3"
                  style={{ color: 'var(--color-textMuted)' }}
                >
                  Current Task
                </div>
                <h3 className="text-2xl font-bold mb-3" style={{ color: 'var(--color-primary)' }}>
                  {currentStep.title}
                </h3>
                {(activeTask || (researchSources.length > 0 && pendingTasks > 0)) && (
                  <div
                    className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full"
                    style={{
                      backgroundColor: 'var(--color-background)',
                      borderWidth: '2px',
                      borderStyle: 'solid',
                      borderColor: 'var(--color-accent)'
                    }}
                  >
                    <Loader className="w-4 h-4 animate-spin" style={{ color: 'var(--color-accent)' }} />
                    <span className="font-semibold text-base" style={{ color: 'var(--color-text)' }}>
                      {researchSources.length > 0 && activeSourceIndex < researchSources.length
                        ? `Searching: ${researchSources[activeSourceIndex]}`
                        : activeTask?.name || 'Processing...'}
                    </span>
                  </div>
                )}
              </div>

              <div
                className="h-px w-full mb-4"
                style={{ backgroundColor: 'var(--color-border)' }}
              />

              <div className="flex-1 overflow-y-auto space-y-5">
                <div>
                  <div
                    className="text-sm font-bold uppercase tracking-wide mb-3 flex items-center gap-2"
                    style={{ color: 'var(--color-accent)' }}
                  >
                    <div className="w-1 h-5 rounded-full" style={{ backgroundColor: 'var(--color-accent)' }} />
                    What's Happening
                  </div>
                  <p className="text-base leading-relaxed ml-3" style={{ color: 'var(--color-text)' }}>
                    {currentStep.description}
                  </p>
                </div>

                <div>
                  <div
                    className="text-sm font-bold uppercase tracking-wide mb-3 flex items-center gap-2"
                    style={{ color: 'var(--color-textMuted)' }}
                  >
                    <div className="w-1 h-5 rounded-full" style={{ backgroundColor: 'var(--color-textMuted)' }} />
                    Technical Details
                  </div>
                  <p className="text-base leading-relaxed ml-3" style={{ color: 'var(--color-text)' }}>
                    {currentStep.technicalDetails}
                  </p>
                </div>

                <div>
                  <div
                    className="text-sm font-bold uppercase tracking-wide mb-3 flex items-center gap-2"
                    style={{ color: 'var(--color-primary)' }}
                  >
                    <div className="w-1 h-5 rounded-full" style={{ backgroundColor: 'var(--color-primary)' }} />
                    Why This Matters
                  </div>
                  <p className="text-base leading-relaxed ml-3" style={{ color: 'var(--color-text)' }}>
                    {currentStep.whyItMatters}
                  </p>
                </div>

                {logOutput.length > 0 && (
                  <div>
                    <div
                      className="text-sm font-bold uppercase tracking-wide mb-3 flex items-center gap-2"
                      style={{ color: 'var(--color-success)' }}
                    >
                      <div className="w-1 h-5 rounded-full" style={{ backgroundColor: 'var(--color-success)' }} />
                      System Log
                    </div>
                    <div
                      className="ml-3 p-3 rounded-lg font-mono text-xs space-y-1 max-h-32 overflow-y-auto"
                      style={{
                        backgroundColor: 'var(--color-background)',
                        borderWidth: '1px',
                        borderStyle: 'solid',
                        borderColor: 'var(--color-border)'
                      }}
                    >
                      {logOutput.map((log, index) => (
                        <div
                          key={index}
                          style={{
                            color: log.startsWith('✓') ? 'var(--color-success)' :
                                   log.startsWith('>') ? 'var(--color-accent)' :
                                   'var(--color-text)'
                          }}
                        >
                          {log}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="ml-3 p-3 rounded-lg" style={{ backgroundColor: 'var(--color-background)' }}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-semibold" style={{ color: 'var(--color-textMuted)' }}>Expected Output:</span>
                    <span className="text-sm font-bold" style={{ color: 'var(--color-accent)' }}>{currentStep.output}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-semibold" style={{ color: 'var(--color-textMuted)' }}>Real-time Duration:</span>
                    <span className="text-sm font-bold" style={{ color: 'var(--color-accent)' }}>{currentStep.estimatedRealTime}</span>
                  </div>
                </div>


                {microTaskStatuses.length > 0 && (
                  <div>
                    <div
                      className="text-sm font-bold uppercase tracking-wide mb-3 flex items-center justify-between"
                      style={{ color: 'var(--color-textMuted)' }}
                    >
                      <div className="flex items-center gap-2">
                        <div className="w-1 h-5 rounded-full" style={{ backgroundColor: 'var(--color-success)' }} />
                        Sub-Tasks Progress
                      </div>
                      <span className="text-sm font-bold" style={{ color: 'var(--color-primary)' }}>
                        {completedTasks} / {microTaskStatuses.length} Complete
                      </span>
                    </div>
                    <div className="ml-3 space-y-2">
                      {microTaskStatuses.map((task, index) => (
                        <div
                          key={index}
                          className="flex items-center gap-3 p-3 rounded-lg transition-all duration-300"
                          style={{
                            backgroundColor: task.status === 'in_progress'
                              ? 'var(--color-background)'
                              : 'transparent',
                            opacity: task.status === 'pending' ? 0.4 : 1,
                            borderWidth: task.status === 'in_progress' ? '2px' : '1px',
                            borderStyle: 'solid',
                            borderColor: task.status === 'in_progress'
                              ? 'var(--color-accent)'
                              : 'transparent',
                            transform: task.status === 'in_progress' ? 'scale(1.02)' : 'scale(1)'
                          }}
                        >
                          {task.status === 'completed' ? (
                            <CheckCircle className="w-5 h-5 flex-shrink-0" style={{ color: 'var(--color-success)' }} />
                          ) : task.status === 'in_progress' ? (
                            <Loader className="w-5 h-5 flex-shrink-0 animate-spin" style={{ color: 'var(--color-accent)' }} />
                          ) : (
                            <Circle className="w-5 h-5 flex-shrink-0" style={{ color: 'var(--color-textMuted)' }} />
                          )}
                          <div className="flex-1 min-w-0">
                            <div className="font-semibold text-base" style={{ color: 'var(--color-text)' }}>
                              {task.name}
                            </div>
                            {task.detail && (
                              <div className="text-sm mt-1" style={{ color: 'var(--color-textMuted)' }}>
                                {task.detail}
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
