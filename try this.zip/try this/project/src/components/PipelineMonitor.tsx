import { useState, useEffect } from 'react';
import { Activity, AlertCircle, CheckCircle, Clock, Zap, FileText, AlertTriangle, Info } from 'lucide-react';

interface LogEntry {
  id: string;
  timestamp: Date;
  level: 'info' | 'success' | 'warning' | 'error';
  phase: string;
  message: string;
  details?: any;
}

interface PipelineStatus {
  pipelineId: string;
  subject: string;
  phase: string;
  progress: number;
  status: 'pending' | 'running' | 'completed' | 'error';
  currentStep: string;
  aisUsed: number;
  totalAis: number;
  tokensUsed: number;
  qualityScore: number;
  startTime: Date;
  estimatedCompletion?: Date;
  errors: number;
  warnings: number;
}

export function PipelineMonitor() {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [pipelines, setPipelines] = useState<PipelineStatus[]>([]);
  const [selectedPipeline, setSelectedPipeline] = useState<string | null>(null);
  const [autoScroll, setAutoScroll] = useState(true);
  const [filterLevel, setFilterLevel] = useState<string>('all');

  useEffect(() => {
    const mockPipeline: PipelineStatus = {
      pipelineId: 'pipe-001',
      subject: 'Photosynthesis - Biology',
      phase: 'generation',
      progress: 65,
      status: 'running',
      currentStep: 'AI #4 (Gemini Pro) writing chapter 3',
      aisUsed: 8,
      totalAis: 15,
      tokensUsed: 45230,
      qualityScore: 0.92,
      startTime: new Date(Date.now() - 5 * 60 * 1000),
      estimatedCompletion: new Date(Date.now() + 3 * 60 * 1000),
      errors: 0,
      warnings: 2,
    };

    setPipelines([mockPipeline]);

    const addLog = (level: LogEntry['level'], phase: string, message: string, details?: any) => {
      const newLog: LogEntry = {
        id: `log-${Date.now()}-${Math.random()}`,
        timestamp: new Date(),
        level,
        phase,
        message,
        details,
      };
      setLogs(prev => [newLog, ...prev].slice(0, 500));
    };

    const interval = setInterval(() => {
      const messages = [
        { level: 'info' as const, phase: 'research', message: 'o4-mini-deep-research completed topic analysis' },
        { level: 'success' as const, phase: 'generation', message: 'GPT-5.1 generated section: Introduction' },
        { level: 'info' as const, phase: 'generation', message: 'Claude 3.5 Sonnet generating chapter 2...', details: { tokens: 1250 } },
        { level: 'warning' as const, phase: 'verification', message: 'Gemini Flash detected potential factual issue in paragraph 3' },
        { level: 'info' as const, phase: 'verification', message: 'DeepSeek-V3 verifying logic and reasoning' },
        { level: 'success' as const, phase: 'verification', message: 'Consensus reached: 92% quality score' },
        { level: 'info' as const, phase: 'refinement', message: 'GPT-5 Pro refining based on feedback' },
        { level: 'error' as const, phase: 'generation', message: 'Perplexity API rate limit reached, switching to backup' },
        { level: 'success' as const, phase: 'generation', message: 'Failover successful: Using Gemini Pro as backup' },
        { level: 'info' as const, phase: 'polish', message: 'Final readability enhancement in progress' },
      ];

      const randomMessage = messages[Math.floor(Math.random() * messages.length)];
      addLog(randomMessage.level, randomMessage.phase, randomMessage.message, randomMessage.details);

      setPipelines(prev => prev.map(p => ({
        ...p,
        progress: Math.min(p.progress + Math.random() * 5, 100),
        tokensUsed: p.tokensUsed + Math.floor(Math.random() * 500),
        aisUsed: Math.min(p.aisUsed + (Math.random() > 0.7 ? 1 : 0), p.totalAis),
      })));
    }, 3000);

    addLog('info', 'system', 'Pipeline monitoring started');
    addLog('info', 'research', 'Beginning multi-AI research phase with 7 models');

    return () => clearInterval(interval);
  }, []);

  const filteredLogs = logs.filter(log =>
    filterLevel === 'all' || log.level === filterLevel
  ).filter(log =>
    !selectedPipeline || log.phase === selectedPipeline
  );

  const getLevelIcon = (level: string) => {
    switch (level) {
      case 'success': return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'error': return <AlertCircle className="w-4 h-4 text-red-600" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-yellow-600" />;
      default: return <Info className="w-4 h-4 text-blue-600" />;
    }
  };

  const getLevelBg = (level: string) => {
    switch (level) {
      case 'success': return 'bg-green-50 border-green-200';
      case 'error': return 'bg-red-50 border-red-200';
      case 'warning': return 'bg-yellow-50 border-yellow-200';
      default: return 'bg-blue-50 border-blue-200';
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {pipelines.map(pipeline => (
          <div key={pipeline.pipelineId} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="font-bold text-gray-900">{pipeline.subject}</h3>
                <p className="text-sm text-gray-600 mt-1">Pipeline: {pipeline.pipelineId}</p>
              </div>
              <div className={`px-3 py-1 rounded-full text-xs font-medium ${
                pipeline.status === 'running' ? 'bg-blue-100 text-blue-700' :
                pipeline.status === 'completed' ? 'bg-green-100 text-green-700' :
                pipeline.status === 'error' ? 'bg-red-100 text-red-700' :
                'bg-gray-100 text-gray-700'
              }`}>
                {pipeline.status}
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <div className="flex items-center justify-between text-sm mb-1">
                  <span className="text-gray-600">Progress</span>
                  <span className="font-medium text-gray-900">{pipeline.progress.toFixed(0)}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-blue-600 h-2 rounded-full transition-all"
                    style={{ width: `${pipeline.progress}%` }}
                  />
                </div>
              </div>

              <div className="text-sm">
                <div className="flex items-center gap-2 text-gray-600 mb-1">
                  <Activity className="w-4 h-4" />
                  <span className="font-medium">Current Phase:</span>
                  <span className="text-gray-900">{pipeline.phase}</span>
                </div>
                <p className="text-xs text-gray-500 ml-6">{pipeline.currentStep}</p>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-3 border-t border-gray-200">
                <div>
                  <div className="text-xs text-gray-500">AIs Used</div>
                  <div className="text-lg font-bold text-gray-900">{pipeline.aisUsed}/{pipeline.totalAis}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-500">Quality</div>
                  <div className="text-lg font-bold text-gray-900">{(pipeline.qualityScore * 100).toFixed(0)}%</div>
                </div>
                <div>
                  <div className="text-xs text-gray-500">Tokens</div>
                  <div className="text-lg font-bold text-gray-900">{pipeline.tokensUsed.toLocaleString()}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-500">Issues</div>
                  <div className="text-lg font-bold text-gray-900">
                    <span className="text-red-600">{pipeline.errors}</span>/
                    <span className="text-yellow-600">{pipeline.warnings}</span>
                  </div>
                </div>
              </div>

              {pipeline.estimatedCompletion && (
                <div className="flex items-center gap-2 text-xs text-gray-600 pt-3 border-t border-gray-200">
                  <Clock className="w-4 h-4" />
                  <span>Est. completion: {pipeline.estimatedCompletion.toLocaleTimeString()}</span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <FileText className="w-6 h-6 text-gray-700" />
            <h2 className="text-xl font-bold text-gray-900">Real-Time Activity Logs</h2>
            <span className="px-3 py-1 bg-green-100 text-green-700 text-xs font-medium rounded-full">
              Live
            </span>
          </div>

          <div className="flex items-center gap-3">
            <select
              value={selectedPipeline || 'all'}
              onChange={(e) => setSelectedPipeline(e.target.value === 'all' ? null : e.target.value)}
              className="px-3 py-1.5 border border-gray-300 rounded-lg text-sm"
            >
              <option value="all">All Phases</option>
              <option value="research">Research</option>
              <option value="generation">Generation</option>
              <option value="verification">Verification</option>
              <option value="refinement">Refinement</option>
              <option value="polish">Polish</option>
            </select>

            <select
              value={filterLevel}
              onChange={(e) => setFilterLevel(e.target.value)}
              className="px-3 py-1.5 border border-gray-300 rounded-lg text-sm"
            >
              <option value="all">All Levels</option>
              <option value="info">Info</option>
              <option value="success">Success</option>
              <option value="warning">Warning</option>
              <option value="error">Error</option>
            </select>

            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={autoScroll}
                onChange={(e) => setAutoScroll(e.target.checked)}
                className="rounded"
              />
              Auto-scroll
            </label>
          </div>
        </div>

        <div className="space-y-2 max-h-[600px] overflow-y-auto">
          {filteredLogs.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <Activity className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>No logs to display</p>
            </div>
          ) : (
            filteredLogs.map(log => (
              <div
                key={log.id}
                className={`border rounded-lg p-3 ${getLevelBg(log.level)}`}
              >
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 mt-0.5">
                    {getLevelIcon(log.level)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-medium text-gray-900 uppercase">
                        {log.phase}
                      </span>
                      <span className="text-xs text-gray-500">
                        {log.timestamp.toLocaleTimeString()}
                      </span>
                    </div>
                    <p className="text-sm text-gray-900">{log.message}</p>
                    {log.details && (
                      <pre className="mt-2 text-xs bg-white bg-opacity-50 rounded p-2 overflow-x-auto">
                        {JSON.stringify(log.details, null, 2)}
                      </pre>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
