import { useTheme } from '../contexts/ThemeContext';

export function ThemeDecorations() {
  const { currentTheme } = useTheme();

  if (currentTheme !== 'spring-garden') {
    return null;
  }

  return (
    <>
      <div
        className="fixed top-0 left-0 w-64 h-64 pointer-events-none opacity-20"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 200'%3E%3Cg fill='%2385C88A' opacity='0.6'%3E%3Cpath d='M50 80c0-8 6-15 15-15s15 7 15 15-7 15-15 15-15-7-15-15zm-5-10c-3-3-3-8 0-11s8-3 11 0 3 8 0 11-8 3-11 0zm30 0c3-3 8-3 11 0s3 8 0 11-8 3-11 0-3-8 0-11zm-15 25c3-3 8-3 11 0s3 8 0 11-8 3-11 0-3-8 0-11zm0-40c3-3 8-3 11 0s3 8 0 11-8 3-11 0-3-8 0-11z'/%3E%3C/g%3E%3C/svg%3E")`,
          backgroundSize: 'contain',
          backgroundRepeat: 'no-repeat',
        }}
      />

      <div
        className="fixed top-10 right-10 w-48 h-48 pointer-events-none opacity-15"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 200'%3E%3Cg fill='%2385C88A' opacity='0.5'%3E%3Ccircle cx='100' cy='80' r='8'/%3E%3Ccircle cx='120' cy='90' r='6'/%3E%3Ccircle cx='80' cy='90' r='6'/%3E%3Ccircle cx='110' cy='105' r='5'/%3E%3Ccircle cx='90' cy='105' r='5'/%3E%3Cpath d='M100 90v30' stroke='%2385C88A' stroke-width='2' fill='none'/%3E%3C/g%3E%3C/svg%3E")`,
          backgroundSize: 'contain',
          backgroundRepeat: 'no-repeat',
        }}
      />

      <div
        className="fixed bottom-0 left-20 w-56 h-56 pointer-events-none opacity-15"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 200'%3E%3Cg fill='%2385C88A' opacity='0.6'%3E%3Cpath d='M100 120c0-10 8-18 18-18s18 8 18 18-8 18-18 18-18-8-18-18zm-10-5c-4-4-4-10 0-14s10-4 14 0 4 10 0 14-10 4-14 0zm40 0c4-4 10-4 14 0s4 10 0 14-10 4-14 0-4-10 0-14zm-20 30c4-4 10-4 14 0s4 10 0 14-10 4-14 0-4-10 0-14zm0-50c4-4 10-4 14 0s4 10 0 14-10 4-14 0-4-10 0-14z'/%3E%3C/g%3E%3C/svg%3E")`,
          backgroundSize: 'contain',
          backgroundRepeat: 'no-repeat',
        }}
      />

      <div
        className="fixed bottom-10 right-0 w-44 h-44 pointer-events-none opacity-20"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 200'%3E%3Cg fill='%2385C88A' opacity='0.5'%3E%3Cpath d='M80 100c0-6 5-11 11-11s11 5 11 11-5 11-11 11-11-5-11-11zm-5-8c-2-2-2-6 0-8s6-2 8 0 2 6 0 8-6 2-8 0zm22 0c2-2 6-2 8 0s2 6 0 8-6 2-8 0-2-6 0-8zm-11 18c2-2 6-2 8 0s2 6 0 8-6 2-8 0-2-6 0-8zm0-28c2-2 6-2 8 0s2 6 0 8-6 2-8 0-2-6 0-8z'/%3E%3C/g%3E%3C/svg%3E")`,
          backgroundSize: 'contain',
          backgroundRepeat: 'no-repeat',
        }}
      />
    </>
  );
}
