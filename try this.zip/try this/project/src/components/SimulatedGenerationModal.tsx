import { useEffect, useState, useRef } from 'react';
import { X, CheckCircle } from 'lucide-react';

interface SimulatedGenerationModalProps {
  isOpen: boolean;
  onClose: () => void;
  prompt: string;
}

interface Worker {
  id: string;
  workerId: number;
  progress: number;
  status: 'pending' | 'processing' | 'complete';
}

interface TaskStep {
  id: string;
  name: string;
  categoryIcon: string;
  categoryName: string;
  estimatedTime: number;
  workers: Worker[];
  status: 'pending' | 'processing' | 'complete';
}

interface Category {
  id: string;
  name: string;
  icon: string;
  type: 'process' | 'item';
  steps: TaskStep[];
}

const READING_LEVELS = ['Kindergarten', 'Elementary', 'Middle School'];
const FORMATS = ['PDF', 'EPUB', 'HTML', 'Audio'];

const generateCategories = (selectedLevels: string[], selectedAddons: string[]): Category[] => {
  const categories: Category[] = [];
  const numChapters = 4;

  const createWorkers = (count: number) => {
    return Array.from({ length: count }, (_, i) => ({
      id: `worker_${i + 1}`,
      workerId: i + 1,
      progress: 0,
      status: 'pending' as const,
    }));
  };

  const masterBookSteps: TaskStep[] = [];
  masterBookSteps.push({
    id: 'initial_research',
    name: 'Research Topic',
    categoryIcon: '📖',
    categoryName: 'Master Book',
    estimatedTime: 8,
    workers: createWorkers(3),
    status: 'pending',
  });
  masterBookSteps.push({
    id: 'outline_create',
    name: 'Create Outline',
    categoryIcon: '📖',
    categoryName: 'Master Book',
    estimatedTime: 4,
    workers: createWorkers(2),
    status: 'pending',
  });

  for (let ch = 1; ch <= numChapters; ch++) {
    masterBookSteps.push({
      id: `ch${ch}_write`,
      name: `Chapter ${ch}: Write Content`,
      categoryIcon: '📖',
      categoryName: 'Master Book',
      estimatedTime: 6,
      workers: createWorkers(3),
      status: 'pending',
    });
    masterBookSteps.push({
      id: `ch${ch}_verify`,
      name: `Chapter ${ch}: Verify Quality`,
      categoryIcon: '📖',
      categoryName: 'Master Book',
      estimatedTime: 3,
      workers: createWorkers(1),
      status: 'pending',
    });
  }

  masterBookSteps.push({
    id: 'master_finalize',
    name: 'Finalize Master Book',
    categoryIcon: '📖',
    categoryName: 'Master Book',
    estimatedTime: 3,
    workers: createWorkers(1),
    status: 'pending',
  });

  categories.push({
    id: 'master_book',
    name: 'Master Book',
    icon: '📖',
    type: 'process',
    steps: masterBookSteps,
  });

  selectedLevels.forEach((level, levelIdx) => {
    const icon = levelIdx === 0 ? '👶' : levelIdx === 1 ? '📚' : '🎓';
    const levelSteps: TaskStep[] = [];
    levelSteps.push({
      id: `${level}_adapt`,
      name: 'Adapt Content for Reading Level',
      categoryIcon: icon,
      categoryName: `${level} Edition`,
      estimatedTime: 5,
      workers: createWorkers(2),
      status: 'pending',
    });

    FORMATS.forEach(format => {
      levelSteps.push({
        id: `${level}_${format}`,
        name: `Generate ${format} Format`,
        categoryIcon: icon,
        categoryName: `${level} Edition`,
        estimatedTime: format === 'Audio' ? 6 : 3,
        workers: createWorkers(1),
        status: 'pending',
      });
    });

    levelSteps.push({
      id: `${level}_qc`,
      name: 'Quality Check',
      categoryIcon: icon,
      categoryName: `${level} Edition`,
      estimatedTime: 2,
      workers: createWorkers(1),
      status: 'pending',
    });

    categories.push({
      id: `book_${level}`,
      name: `${level} Edition`,
      icon,
      type: 'item',
      steps: levelSteps,
    });
  });

  selectedAddons.forEach((addon, idx) => {
    const icon = idx === 0 ? '🎯' : '📝';
    const addonSteps: TaskStep[] = [];
    addonSteps.push({
      id: `${addon}_research`,
      name: 'Research Requirements',
      categoryIcon: icon,
      categoryName: addon,
      estimatedTime: 4,
      workers: createWorkers(2),
      status: 'pending',
    });

    const itemCount = 6;
    for (let i = 1; i <= itemCount; i++) {
      addonSteps.push({
        id: `${addon}_item${i}_gen`,
        name: `Generate Item ${i}`,
        categoryIcon: icon,
        categoryName: addon,
        estimatedTime: 3,
        workers: createWorkers(1),
        status: 'pending',
      });
    }

    addonSteps.push({
      id: `${addon}_package`,
      name: 'Package Files',
      categoryIcon: icon,
      categoryName: addon,
      estimatedTime: 2,
      workers: createWorkers(1),
      status: 'pending',
    });

    categories.push({
      id: `addon_${addon}`,
      name: addon,
      icon,
      type: 'item',
      steps: addonSteps,
    });
  });

  categories.push({
    id: 'finalization',
    name: 'Finalization',
    icon: '✅',
    type: 'process',
    steps: [
      {
        id: 'qa_full',
        name: 'Complete Quality Assurance',
        categoryIcon: '✅',
        categoryName: 'Finalization',
        estimatedTime: 5,
        workers: createWorkers(2),
        status: 'pending',
      },
      {
        id: 'package_all',
        name: 'Package All Files',
        categoryIcon: '✅',
        categoryName: 'Finalization',
        estimatedTime: 3,
        workers: createWorkers(1),
        status: 'pending',
      },
      {
        id: 'upload',
        name: 'Upload to Storage',
        categoryIcon: '✅',
        categoryName: 'Finalization',
        estimatedTime: 4,
        workers: createWorkers(1),
        status: 'pending',
      },
    ],
  });

  return categories;
};

export function SimulatedGenerationModal({ isOpen, onClose, prompt }: SimulatedGenerationModalProps) {
  const [workerCount, setWorkerCount] = useState(4);
  const [categories, setCategories] = useState<Category[]>([]);
  const [allSteps, setAllSteps] = useState<TaskStep[]>([]);
  const [isComplete, setIsComplete] = useState(false);
  const [totalProgress, setTotalProgress] = useState(0);
  const processStartedRef = useRef(false);

  useEffect(() => {
    if (!isOpen) {
      setCategories([]);
      setAllSteps([]);
      setIsComplete(false);
      setTotalProgress(0);
      processStartedRef.current = false;
      return;
    }

    if (processStartedRef.current) return;
    processStartedRef.current = true;

    const selectedLevels = READING_LEVELS;
    const addons = ['Activity Pack', 'Worksheet Set'];
    const selectedAddons = addons;

    const allCategories = generateCategories(selectedLevels, selectedAddons);
    setCategories(allCategories);

    const steps = allCategories.flatMap(cat => cat.steps);
    setAllSteps(steps);

    const intervals: NodeJS.Timeout[] = [];
    const timeouts: NodeJS.Timeout[] = [];
    const totalSteps = steps.length;
    let completedSteps = 0;
    let currentStepIndex = 0;
    const workerCountRef = { current: workerCount };

    const processNextStep = () => {
      if (currentStepIndex >= steps.length) {
        setIsComplete(true);
        setTotalProgress(100);
        return;
      }

      const step = steps[currentStepIndex];
      const progressInterval = 100;
      const startTime = Date.now();
      let progressAccumulator = 0;

      const interval = setInterval(() => {
        const currentWorkers = workerCountRef.current;
        const workersNeeded = step.workers.length;
        const workersAvailable = Math.min(workersNeeded, currentWorkers);
        const speedMultiplier = currentWorkers / workersNeeded;
        const adjustedDuration = (step.estimatedTime * 1000) / speedMultiplier;

        progressAccumulator += (progressInterval / adjustedDuration) * 100;
        const progress = Math.min(progressAccumulator, 100);

        setAllSteps(prev =>
          prev.map(s =>
            s.id === step.id
              ? {
                  ...s,
                  status: 'processing',
                  workers: s.workers.map((w, idx) =>
                    idx < workersAvailable
                      ? {
                          ...w,
                          status: 'processing',
                          progress: Math.min(progress, 100),
                        }
                      : { ...w, status: 'pending', progress: 0 }
                  ),
                }
              : s
          )
        );

        if (progress >= 100) {
          clearInterval(interval);

          const finalWorkers = workerCountRef.current;
          const finalWorkersAvailable = Math.min(step.workers.length, finalWorkers);

          setAllSteps(prev =>
            prev.map(s =>
              s.id === step.id
                ? {
                    ...s,
                    status: 'complete',
                    workers: s.workers.map((w, idx) =>
                      idx < finalWorkersAvailable
                        ? {
                            ...w,
                            progress: 100,
                            status: 'complete',
                          }
                        : w
                    ),
                  }
                : s
            )
          );

          completedSteps++;
          setTotalProgress(Math.round((completedSteps / totalSteps) * 100));

          currentStepIndex++;
          const nextTimeout = setTimeout(() => processNextStep(), 300);
          timeouts.push(nextTimeout);
        }
      }, progressInterval);

      intervals.push(interval);
    };

    const startTimeout = setTimeout(() => processNextStep(), 1000);
    timeouts.push(startTimeout);

    return () => {
      intervals.forEach(i => clearInterval(i));
      timeouts.forEach(t => clearTimeout(t));
    };
  }, [isOpen]);

  const workerCountRef = useRef(workerCount);
  useEffect(() => {
    workerCountRef.current = workerCount;
  }, [workerCount]);

  if (!isOpen) return null;

  const processCategories = categories.filter(cat => cat.type === 'process');
  const itemCategories = categories.filter(cat => cat.type === 'item');
  const processingSteps = allSteps.filter(s => s.status === 'processing');

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ backgroundColor: 'rgba(0, 0, 0, 0.9)' }}
      onClick={onClose}
    >
      <div
        className="rounded-xl relative w-full max-w-6xl max-h-[90vh] overflow-hidden flex flex-col"
        style={{
          backgroundColor: 'var(--color-surface)',
          borderWidth: '2px',
          borderStyle: 'solid',
          borderColor: 'var(--color-primary)',
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-md transition hover:bg-opacity-10 z-10"
          style={{ color: 'var(--color-textSecondary)' }}
        >
          <X className="w-5 h-5" />
        </button>

        <div className="p-6 border-b" style={{ borderColor: 'var(--color-border)' }}>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-2xl font-bold" style={{ color: 'var(--color-text)' }}>
                {isComplete ? 'Generation Complete!' : 'Book Generation Process'}
              </h2>
              <p className="text-sm mt-1" style={{ color: 'var(--color-textMuted)' }}>
                {prompt || 'Educational Content'}
              </p>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold" style={{ color: 'var(--color-primary)' }}>
                {totalProgress}%
              </div>
            </div>
          </div>

          <div className="mb-3">
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-semibold" style={{ color: 'var(--color-text)' }}>
                Workers: {workerCount}
              </label>
            </div>
            <input
              type="range"
              min="1"
              max="8"
              value={workerCount}
              onChange={(e) => setWorkerCount(Number(e.target.value))}
              className="w-full h-2 rounded-lg appearance-none cursor-pointer"
              style={{
                background: `linear-gradient(to right, var(--color-primary) 0%, var(--color-primary) ${((workerCount - 1) / 7) * 100}%, var(--color-border) ${((workerCount - 1) / 7) * 100}%, var(--color-border) 100%)`,
              }}
            />
          </div>
        </div>

        <div className="flex-1 flex overflow-hidden">
          <div
            className="w-72 border-r overflow-y-auto"
            style={{ borderColor: 'var(--color-border)', backgroundColor: 'var(--color-background)' }}
          >
            <div className="p-4">
              <h3 className="text-xs font-bold mb-3 uppercase tracking-wide" style={{ color: 'var(--color-textSecondary)' }}>
                Process Steps
              </h3>
              {processCategories.map(category => {
                const categorySteps = allSteps.filter(s => s.categoryName === category.name);
                const allComplete = categorySteps.every(s => s.status === 'complete');
                const hasProcessing = categorySteps.some(s => s.status === 'processing');

                return (
                  <div
                    key={category.id}
                    className="mb-2 px-3 py-2 rounded-lg"
                    style={{
                      backgroundColor: allComplete ? 'var(--color-success)' : hasProcessing ? 'var(--color-primary)' : 'transparent',
                      color: allComplete || hasProcessing ? 'var(--color-background)' : 'var(--color-text)',
                    }}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-lg">{category.icon}</span>
                      <span className="font-semibold text-sm">{category.name}</span>
                      {allComplete && <span className="ml-auto">✓</span>}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="border-t p-4" style={{ borderColor: 'var(--color-border)' }}>
              <h3 className="text-xs font-bold mb-3 uppercase tracking-wide" style={{ color: 'var(--color-textSecondary)' }}>
                Items & Add-ons
              </h3>
              {itemCategories.map(category => {
                const categorySteps = allSteps.filter(s => s.categoryName === category.name);
                const allComplete = categorySteps.every(s => s.status === 'complete');
                const hasProcessing = categorySteps.some(s => s.status === 'processing');

                return (
                  <div
                    key={category.id}
                    className="mb-2 px-3 py-2 rounded-lg"
                    style={{
                      backgroundColor: allComplete ? 'var(--color-success)' : hasProcessing ? 'var(--color-primary)' : 'transparent',
                      color: allComplete || hasProcessing ? 'var(--color-background)' : 'var(--color-text)',
                    }}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-lg">{category.icon}</span>
                      <span className="font-semibold text-sm">{category.name}</span>
                      {allComplete && <span className="ml-auto">✓</span>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="flex-1 flex items-center justify-center p-8">
            {isComplete ? (
              <div className="text-center">
                <CheckCircle className="w-24 h-24 mx-auto mb-4" style={{ color: 'var(--color-success)' }} />
                <h3 className="text-3xl font-bold mb-2" style={{ color: 'var(--color-text)' }}>
                  All Complete!
                </h3>
                <p className="text-lg mb-6" style={{ color: 'var(--color-textMuted)' }}>
                  Your book has been generated successfully
                </p>
                <button
                  onClick={onClose}
                  className="px-8 py-3 rounded-lg font-semibold transition"
                  style={{
                    backgroundColor: 'var(--color-primary)',
                    color: 'var(--color-background)',
                  }}
                >
                  Close
                </button>
              </div>
            ) : processingSteps.length > 0 ? (
              <div className="w-full max-w-2xl min-h-[300px]">
                {processingSteps.map(step => {
                  const activeWorkers = step.workers.filter(w => w.status === 'processing');

                  return (
                    <div
                      key={step.id}
                      className="border-2 rounded-lg p-6"
                      style={{
                        borderColor: 'var(--color-accent)',
                        backgroundColor: 'var(--color-surfaceHover)',
                      }}
                    >
                      <div className="flex items-center gap-3 mb-4">
                        <span className="text-3xl">{step.categoryIcon}</span>
                        <div>
                          <div className="text-xs" style={{ color: 'var(--color-textMuted)' }}>
                            {step.categoryName}
                          </div>
                          <div className="text-lg font-bold" style={{ color: 'var(--color-text)' }}>
                            {step.name}
                          </div>
                        </div>
                      </div>

                      <div className="space-y-3">
                        {activeWorkers.map(worker => (
                          <div key={worker.id}>
                            <div className="flex items-center justify-between text-sm mb-1" style={{ color: 'var(--color-textMuted)' }}>
                              <span>Worker {worker.workerId}</span>
                              <span>{Math.round(worker.progress)}%</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div
                                className="h-2 rounded-full transition-all duration-100"
                                style={{
                                  width: `${worker.progress}%`,
                                  backgroundColor: 'var(--color-accent)',
                                }}
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center">
                <div className="animate-pulse mb-4">
                  <div
                    className="w-16 h-16 rounded-full mx-auto flex items-center justify-center"
                    style={{ backgroundColor: 'var(--color-primary)' }}
                  >
                    <span className="text-3xl" style={{ color: 'var(--color-background)' }}>⟳</span>
                  </div>
                </div>
                <h3 className="text-xl font-bold mb-2" style={{ color: 'var(--color-text)' }}>
                  Starting...
                </h3>
              </div>
            )}
          </div>
        </div>

        <div className="p-4 border-t" style={{ borderColor: 'var(--color-border)', backgroundColor: 'var(--color-background)' }}>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div
              className="h-3 rounded-full transition-all duration-300"
              style={{
                width: `${totalProgress}%`,
                backgroundColor: 'var(--color-primary)',
              }}
            />
          </div>
          <div className="flex justify-between mt-2 text-xs" style={{ color: 'var(--color-textMuted)' }}>
            <span>Overall Progress</span>
            <span>{totalProgress}%</span>
          </div>
        </div>
      </div>
    </div>
  );
}
