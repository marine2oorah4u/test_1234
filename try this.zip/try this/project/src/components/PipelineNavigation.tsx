import {
  BookOpen,
  BookMarked,
  Accessibility,
  FileType,
  Puzzle,
  GraduationCap,
  Sparkles,
  BookTemplate,
  Languages,
  PlayCircle,
  Package
} from 'lucide-react';

interface Pipeline {
  id: string;
  name: string;
  icon: React.ElementType;
  description: string;
}

export const PIPELINES: Pipeline[] = [
  {
    id: 'base-book',
    name: 'Base Book',
    icon: BookOpen,
    description: 'Foundation book generation',
  },
  {
    id: 'reading-levels',
    name: 'Reading Levels',
    icon: BookMarked,
    description: '7 adaptive difficulty levels',
  },
  {
    id: 'disability-adaptations',
    name: 'Accessibility',
    icon: Accessibility,
    description: '40 disability adaptations',
  },
  {
    id: 'format-conversions',
    name: 'Formats',
    icon: FileType,
    description: 'Multiple file formats',
  },
  {
    id: 'educational-addons',
    name: 'Addons',
    icon: Puzzle,
    description: 'Learning enhancements',
  },
  {
    id: 'educator-packages',
    name: 'Educator',
    icon: GraduationCap,
    description: 'Teacher resources',
  },
  {
    id: 'interactive-elements',
    name: 'Interactive',
    icon: Sparkles,
    description: 'Engagement features',
  },
  {
    id: 'binder-books',
    name: 'Binder',
    icon: BookTemplate,
    description: 'Physical print editions',
  },
  {
    id: 'translations',
    name: 'Translations',
    icon: Languages,
    description: '1,000+ languages',
  },
  {
    id: 'online-courses',
    name: 'Courses',
    icon: PlayCircle,
    description: 'Structured learning',
  },
  {
    id: 'special-collections',
    name: 'Collections',
    icon: Package,
    description: 'Curated bundles',
  },
];

interface PipelineNavigationProps {
  activePipeline: string;
  onPipelineChange: (pipelineId: string) => void;
}

export function PipelineNavigation({ activePipeline, onPipelineChange }: PipelineNavigationProps) {
  return (
    <div className="mb-6">
      <div
        className="rounded-xl shadow-sm border overflow-x-auto"
        style={{
          backgroundColor: 'var(--color-surface)',
          borderColor: 'var(--color-border)',
        }}
      >
        <div className="flex border-b" style={{ borderColor: 'var(--color-border)' }}>
          {PIPELINES.map((pipeline) => {
            const Icon = pipeline.icon;
            const isActive = activePipeline === pipeline.id;

            return (
              <button
                key={pipeline.id}
                onClick={() => onPipelineChange(pipeline.id)}
                className="flex items-center gap-2 px-4 py-3 transition-all whitespace-nowrap border-b-2"
                style={{
                  borderBottomColor: isActive ? 'var(--color-primary)' : 'transparent',
                  backgroundColor: isActive ? 'var(--color-surfaceHover)' : 'transparent',
                  color: isActive ? 'var(--color-primary)' : 'var(--color-textMuted)',
                  fontWeight: isActive ? '600' : '400',
                }}
                onMouseEnter={(e) => {
                  if (!isActive) {
                    e.currentTarget.style.color = 'var(--color-text)';
                  }
                }}
                onMouseLeave={(e) => {
                  if (!isActive) {
                    e.currentTarget.style.color = 'var(--color-textMuted)';
                  }
                }}
              >
                <Icon className="w-4 h-4" />
                <span className="text-sm">{pipeline.name}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
