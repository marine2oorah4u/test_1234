import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import {
  BookOpen,
  LayoutDashboard,
  Settings,
  FileText,
  Activity,
  LogOut,
  Menu,
  X,
  Plus,
  Code,
  Key,
  Cloud,
  Monitor,
  Shield,
  Workflow,
  Eye,
  UserCheck,
  Award,
  Zap,
  Globe
} from 'lucide-react';
import { ThemeSelector } from './ThemeSelector';

interface DashboardLayoutProps {
  children: React.ReactNode;
  currentPage: string;
  onNavigate: (page: string) => void;
}

export function DashboardLayout({ children, currentPage, onNavigate }: DashboardLayoutProps) {
  const { signOut } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const navigation = [
    { name: 'Overview', icon: LayoutDashboard, page: 'overview' },
    { name: 'Pipelines', icon: Workflow, page: 'pipelines' },
    { name: 'Generate Book', icon: Plus, page: 'generate' },
    { name: 'Scouts System', icon: Award, page: 'scouts' },
    { name: 'Books Library', icon: FileText, page: 'library' },
    { name: 'Language Support', icon: Globe, page: 'languages' },
    { name: 'API Services', icon: Settings, page: 'api-services' },
    { name: 'API Keys', icon: Key, page: 'api-keys' },
    { name: 'Usage Monitor', icon: Activity, page: 'usage' },
    { name: 'Stress Testing', icon: Zap, page: 'stress-test' },
    { name: 'Load Balancing', icon: Cloud, page: 'load-balancing' },
    { name: 'System Monitor', icon: Monitor, page: 'monitor' },
    { name: 'System Diagnostics', icon: Code, page: 'diagnostics' },
    { name: 'Admin Roles', icon: Shield, page: 'admin-roles' },
    { name: 'User Approvals', icon: UserCheck, page: 'user-approvals' },
  ];

  const handleSignOut = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  return (
    <div
      className="min-h-screen relative"
      style={{
        backgroundColor: 'var(--color-background)',
      }}
    >
      {/* Background wallpaper layer */}
      <div
        className="fixed inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: 'var(--bg-wallpaper)',
          zIndex: 0,
        }}
      />
      {/* Content layer */}
      <div className="relative" style={{ zIndex: 2 }}>
      <div
        className="lg:hidden fixed top-0 left-0 right-0 px-4 py-3 z-50 flex items-center justify-between backdrop-blur-md"
        style={{
          backgroundColor: 'var(--color-surface)',
          borderBottom: '1px solid var(--color-border)',
        }}
      >
        <div className="flex items-center gap-2">
          <div
            className="p-2 rounded-lg"
            style={{ backgroundColor: 'var(--color-primary)' }}
          >
            <BookOpen className="w-5 h-5" style={{ color: 'var(--color-background)' }} />
          </div>
          <span className="font-semibold" style={{ color: 'var(--color-text)' }}>Admin Dashboard</span>
        </div>
        <div className="flex items-center gap-2">
          <ThemeSelector />
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 rounded-lg"
            style={{
              color: 'var(--color-text)',
              backgroundColor: 'var(--color-surfaceHover)',
            }}
          >
            {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      <div className="flex pt-14 lg:pt-0">
        <aside
          className={`
            fixed lg:static inset-y-0 left-0 z-40
            w-64 border-r backdrop-blur-md
            transform transition-transform duration-300 ease-in-out
            ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
          `}
          style={{
            backgroundColor: 'var(--color-surface)',
            borderColor: 'var(--color-border)',
          }}
        >
          <div className="h-full flex flex-col">
            <div
              className="hidden lg:flex items-center gap-2 px-6 py-5 border-b"
              style={{ borderColor: 'var(--color-border)' }}
            >
              <div
                className="p-2 rounded-lg"
                style={{ backgroundColor: 'var(--color-primary)' }}
              >
                <BookOpen className="w-6 h-6" style={{ color: 'var(--color-background)' }} />
              </div>
              <div>
                <h1 className="font-bold" style={{ color: 'var(--color-text)' }}>EduGen AI</h1>
                <p className="text-xs" style={{ color: 'var(--color-textMuted)' }}>Admin Dashboard</p>
              </div>
            </div>

            <nav className="flex-1 px-4 py-6 space-y-1 overflow-y-auto">
              {navigation.map((item) => {
                const Icon = item.icon;
                const isActive = currentPage === item.page;
                return (
                  <button
                    key={item.name}
                    onClick={() => {
                      onNavigate(item.page);
                      setSidebarOpen(false);
                    }}
                    className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-all"
                    style={{
                      backgroundColor: isActive ? 'var(--color-primary)' : 'transparent',
                      color: isActive ? 'var(--color-background)' : 'var(--color-text)',
                    }}
                    onMouseEnter={(e) => {
                      if (!isActive) {
                        e.currentTarget.style.backgroundColor = 'var(--color-surfaceHover)';
                      }
                    }}
                    onMouseLeave={(e) => {
                      if (!isActive) {
                        e.currentTarget.style.backgroundColor = 'transparent';
                      }
                    }}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="font-medium">{item.name}</span>
                  </button>
                );
              })}
            </nav>

            <div className="border-t p-4 space-y-3" style={{ borderColor: 'var(--color-border)' }}>
              <button
                onClick={() => onNavigate('demo-home')}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all"
                style={{
                  backgroundColor: 'var(--color-secondary)',
                  color: 'var(--color-background)'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = 'var(--color-secondaryHover)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'var(--color-secondary)';
                }}
              >
                <Eye className="w-5 h-5" />
                <span className="font-medium">View Demo Site</span>
              </button>
              <div>
                <ThemeSelector />
              </div>
              <button
                onClick={handleSignOut}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all"
                style={{ color: 'var(--color-text)' }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = 'var(--color-surfaceHover)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'transparent';
                }}
              >
                <LogOut className="w-5 h-5" />
                <span className="font-medium">Sign Out</span>
              </button>
            </div>
          </div>
        </aside>

        {sidebarOpen && (
          <div
            className="fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        <main className="flex-1 overflow-auto">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            {children}
          </div>
        </main>
      </div>
      </div>
    </div>
  );
}
