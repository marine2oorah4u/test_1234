import React from 'react';
import { CheckCircle, Star, Construction, Volume2, Video, MessageSquare, Globe } from 'lucide-react';

interface LanguageCardProps {
  languageCode: string;
  languageName: string;
  nativeName: string;
  qualityTier: 1 | 2 | 3;
  qualityStatus: 'complete' | 'improving' | 'beta';
  hasTextTranslation: boolean;
  hasVoiceNarration: boolean;
  hasVideoNarration: boolean;
  hasAITutorVoice: boolean;
  hasCulturalAdaptation: boolean;
  hasRoboticVoiceAvailable: boolean;
  voiceQuality: 'excellent' | 'good' | 'robotic' | 'unavailable';
  speakersInMillions?: number;
  onSelect: () => void;
}

export function LanguageCard({
  languageCode,
  languageName,
  nativeName,
  qualityTier,
  qualityStatus,
  hasTextTranslation,
  hasVoiceNarration,
  hasVideoNarration,
  hasAITutorVoice,
  hasCulturalAdaptation,
  hasRoboticVoiceAvailable,
  voiceQuality,
  speakersInMillions,
  onSelect
}: LanguageCardProps) {
  const getStatusBadge = () => {
    switch (qualityTier) {
      case 1:
        return {
          icon: CheckCircle,
          text: 'Fully Available',
          className: 'bg-green-100 text-green-700 border-green-200'
        };
      case 2:
        return {
          icon: Star,
          text: 'High Quality - Continuously Improving',
          className: 'bg-blue-100 text-blue-700 border-blue-200'
        };
      case 3:
        return {
          icon: Construction,
          text: 'Beta Quality - Active Development',
          className: 'bg-orange-100 text-orange-700 border-orange-200'
        };
    }
  };

  const badge = getStatusBadge();
  const BadgeIcon = badge.icon;

  const voiceStatusText = hasVoiceNarration
    ? `${voiceQuality} quality`
    : hasRoboticVoiceAvailable
    ? 'Automated available'
    : 'Coming soon';

  return (
    <button
      onClick={onSelect}
      className="w-full text-left bg-white rounded-xl border border-gray-200 hover:border-blue-400 hover:shadow-lg transition-all p-6 group"
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <span className="text-3xl">{getFlagEmoji(languageCode)}</span>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                {languageName}
              </h3>
              <p className="text-sm text-gray-600">{nativeName}</p>
            </div>
          </div>
          {speakersInMillions && (
            <p className="text-xs text-gray-500 flex items-center gap-1">
              <Globe className="w-3 h-3" />
              {speakersInMillions}M speakers
            </p>
          )}
        </div>
      </div>

      {/* Status Badge */}
      <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium border mb-4 ${badge.className}`}>
        <BadgeIcon className="w-4 h-4" />
        <span>{badge.text}</span>
      </div>

      {/* Features Grid */}
      <div className="grid grid-cols-2 gap-2 mb-4">
        <FeatureIndicator
          icon={MessageSquare}
          label="Text Lessons"
          available={hasTextTranslation}
          status="Available"
        />
        <FeatureIndicator
          icon={Volume2}
          label="Audio"
          available={hasVoiceNarration || hasRoboticVoiceAvailable}
          status={voiceStatusText}
        />
        <FeatureIndicator
          icon={Video}
          label="Video"
          available={hasVideoNarration}
          status={hasVideoNarration ? 'Available' : 'Coming soon'}
        />
        <FeatureIndicator
          icon={MessageSquare}
          label="AI Tutor"
          available={hasAITutorVoice}
          status={hasAITutorVoice ? 'Voice enabled' : 'Text only'}
        />
      </div>

      {/* Quality Message */}
      {qualityTier === 2 && (
        <p className="text-xs text-blue-700 bg-blue-50 rounded-lg p-2">
          High quality with minor improvements ongoing
        </p>
      )}
      {qualityTier === 3 && (
        <p className="text-xs text-orange-700 bg-orange-50 rounded-lg p-2">
          Active development - quality improving continuously
        </p>
      )}
    </button>
  );
}

interface FeatureIndicatorProps {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  available: boolean;
  status: string;
}

function FeatureIndicator({ icon: Icon, label, available, status }: FeatureIndicatorProps) {
  return (
    <div className={`flex items-start gap-2 p-2 rounded-lg ${available ? 'bg-gray-50' : 'bg-gray-50'}`}>
      <Icon className={`w-4 h-4 mt-0.5 flex-shrink-0 ${available ? 'text-green-600' : 'text-gray-400'}`} />
      <div className="min-w-0 flex-1">
        <p className={`text-xs font-medium ${available ? 'text-gray-900' : 'text-gray-500'}`}>
          {label}
        </p>
        <p className={`text-xs ${available ? 'text-gray-600' : 'text-gray-400'}`}>
          {status}
        </p>
      </div>
    </div>
  );
}

// Helper function to get flag emoji (simplified version)
function getFlagEmoji(languageCode: string): string {
  const flagMap: Record<string, string> = {
    en: '🇬🇧', es: '🇪🇸', fr: '🇫🇷', de: '🇩🇪', it: '🇮🇹', pt: '🇵🇹',
    ja: '🇯🇵', ko: '🇰🇷', zh: '🇨🇳', ar: '🇸🇦', hi: '🇮🇳', ru: '🇷🇺',
    tr: '🇹🇷', pl: '🇵🇱', nl: '🇳🇱', sv: '🇸🇪', no: '🇳🇴', da: '🇩🇰',
    fi: '🇫🇮', cs: '🇨🇿', el: '🇬🇷', he: '🇮🇱', th: '🇹🇭', vi: '🇻🇳',
    id: '🇮🇩', ms: '🇲🇾', tl: '��🇭', bn: '🇧🇩', ur: '🇵🇰', ta: '🇮🇳',
    te: '🇮🇳', mr: '🇮🇳', gu: '🇮🇳', kn: '🇮🇳', ml: '🇮🇳', pa: '🇮🇳',
    uk: '🇺🇦', ro: '🇷🇴', hu: '🇭🇺', bg: '🇧🇬', hr: '🇭🇷', sk: '🇸🇰',
    lt: '🇱🇹', lv: '🇱🇻', et: '🇪🇪', sl: '🇸🇮', sw: '🇰🇪', am: '🇪🇹',
    ha: '🇳🇬', yo: '🇳🇬', ig: '🇳🇬', zu: '🇿🇦', xh: '🇿🇦', fa: '🇮🇷',
    ps: '🇦🇫', ku: '🇮🇶', az: '🇦🇿', kk: '🇰🇿', uz: '🇺🇿', ky: '🇰🇬'
  };
  return flagMap[languageCode] || '🌐';
}
