import { Palette } from 'lucide-react';
import { useState, useEffect, useRef } from 'react';
import { getThemesByCategory } from '../config/themes';
import { useTheme } from '../contexts/ThemeContext';

export function DemoThemeSelector() {
  const [isOpen, setIsOpen] = useState(false);
  const { currentTheme, setTheme } = useTheme();
  const popupRef = useRef<HTMLDivElement>(null);

  const demoThemes = getThemesByCategory('demo');


  return (
    <div className="fixed bottom-6 right-6 z-50">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-14 h-14 rounded-full shadow-lg flex items-center justify-center transition"
        style={{
          backgroundColor: 'var(--color-primary)',
          color: 'var(--color-background)',
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.backgroundColor = 'var(--color-primaryHover)';
          e.currentTarget.style.transform = 'scale(1.1)';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.backgroundColor = 'var(--color-primary)';
          e.currentTarget.style.transform = 'scale(1)';
        }}
      >
        <Palette className="w-6 h-6" />
      </button>

      {isOpen && (
        <>
          <div
            className="fixed inset-0 z-40"
            onClick={() => setIsOpen(false)}
          />
          <div
            ref={popupRef}
            className="fixed w-80 rounded-xl shadow-2xl p-4 max-h-[70vh] overflow-y-auto z-50"
            style={{
              backgroundColor: 'var(--color-surface)',
              border: '2px solid var(--color-border)',
              right: '1.5rem',
              bottom: '5rem',
            }}
          >
          <h3 className="font-semibold mb-3" style={{ color: 'var(--color-text)' }}>
            Choose Your Theme
          </h3>
          <div className="grid grid-cols-2 gap-3">
            {demoThemes.map((theme) => (
              <button
                key={theme.id}
                onClick={() => {
                  setTheme(theme.id);
                  setIsOpen(false);
                }}
                className="relative overflow-hidden rounded-lg p-3 transition text-left"
                style={{
                  backgroundColor: currentTheme === theme.id ? 'var(--color-primary)' : 'var(--color-surfaceHover)',
                  borderWidth: '2px',
                  borderStyle: 'solid',
                  borderColor: currentTheme === theme.id ? 'var(--color-primary)' : 'var(--color-border)',
                }}
              >
                <div
                  className="w-full h-12 rounded mb-2"
                  style={{
                    background: `linear-gradient(135deg, ${theme.colors.primary}, ${theme.colors.accent})`,
                  }}
                />
                <div className="text-sm font-medium" style={{ color: currentTheme === theme.id ? 'var(--color-background)' : 'var(--color-text)' }}>
                  {theme.name}
                </div>
              </button>
            ))}
          </div>
        </div>
        </>
      )}
    </div>
  );
}
