import { LayoutDashboard } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface BackToAdminButtonProps {
  onNavigate: (page: string) => void;
}

export function BackToAdminButton({ onNavigate }: BackToAdminButtonProps) {
  const { isAdmin } = useAuth();

  if (!isAdmin) return null;

  return (
    <div className="fixed top-4 right-4 z-50">
      <button
        onClick={() => onNavigate('overview')}
        className="flex items-center gap-2 px-4 py-2 rounded-lg transition backdrop-blur-md shadow-lg"
        style={{
          backgroundColor: 'rgba(var(--color-primary-rgb, 139, 21, 56), 0.9)',
          color: 'var(--color-text)',
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.backgroundColor = 'rgba(var(--color-primary-rgb, 139, 21, 56), 1)';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.backgroundColor = 'rgba(var(--color-primary-rgb, 139, 21, 56), 0.9)';
        }}
      >
        <LayoutDashboard className="w-4 h-4" />
        <span className="font-medium">Back to Admin</span>
      </button>
    </div>
  );
}
