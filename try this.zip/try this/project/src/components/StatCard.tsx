import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: number;
  icon: LucideIcon;
  colorType: 'primary' | 'success' | 'warning' | 'error';
}

export const StatCard: React.FC<StatCardProps> = ({ title, value, icon: Icon, colorType }) => {
  const getColor = () => {
    switch (colorType) {
      case 'primary':
        return 'var(--color-primary)';
      case 'success':
        return 'var(--color-success)';
      case 'warning':
        return 'var(--color-warning)';
      case 'error':
        return 'var(--color-error)';
      default:
        return 'var(--color-primary)';
    }
  };

  return (
    <div
      className="rounded-xl shadow-sm border p-6 transition-all duration-300 hover:shadow-lg"
      style={{
        backgroundColor: 'var(--color-surface)',
        borderColor: 'var(--color-border)',
      }}
    >
      <div className="flex items-center justify-between mb-4">
        <div
          className="p-3 rounded-lg"
          style={{ backgroundColor: getColor() }}
        >
          <Icon className="w-6 h-6" style={{ color: 'var(--color-background)' }} />
        </div>
      </div>
      <div>
        <p className="text-sm mb-1" style={{ color: 'var(--color-textMuted)' }}>
          {title}
        </p>
        <p className="text-3xl font-bold" style={{ color: 'var(--color-text)' }}>
          {value}
        </p>
      </div>
    </div>
  );
};
