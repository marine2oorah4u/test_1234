import React, { useState } from 'react';
import { Volume2, VolumeX, AlertTriangle } from 'lucide-react';

interface VoiceQualitySelectorProps {
  languageCode: string;
  languageName: string;
  voiceQuality: 'excellent' | 'good' | 'robotic' | 'unavailable';
  hasRoboticVoiceAvailable: boolean;
  roboticVoiceProvider?: string;
  currentlyEnabled: boolean;
  onToggle: (enabled: boolean) => void;
}

export function VoiceQualitySelector({
  languageCode,
  languageName,
  voiceQuality,
  hasRoboticVoiceAvailable,
  roboticVoiceProvider,
  currentlyEnabled,
  onToggle
}: VoiceQualitySelectorProps) {
  const [showWarning, setShowWarning] = useState(false);

  // High quality voice - no selector needed
  if (voiceQuality === 'excellent' || voiceQuality === 'good') {
    return (
      <div className="flex items-center gap-2 text-sm text-green-600">
        <Volume2 className="w-4 h-4" />
        <span>Audio available ({voiceQuality} quality)</span>
      </div>
    );
  }

  // No voice available at all
  if (voiceQuality === 'unavailable' && !hasRoboticVoiceAvailable) {
    return (
      <div className="flex items-center gap-2 text-sm text-gray-500">
        <VolumeX className="w-4 h-4" />
        <span>Audio coming soon - Text-based learning available</span>
      </div>
    );
  }

  // Robotic voice available - show option
  const handleEnableClick = () => {
    if (!currentlyEnabled) {
      setShowWarning(true);
    } else {
      onToggle(false);
    }
  };

  const confirmEnable = () => {
    onToggle(true);
    setShowWarning(false);
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <VolumeX className="w-4 h-4" />
          <span>High-quality audio not yet available</span>
        </div>

        {hasRoboticVoiceAvailable && (
          <button
            onClick={handleEnableClick}
            className={`px-3 py-1 text-sm rounded-lg transition-colors ${
              currentlyEnabled
                ? 'bg-orange-100 text-orange-700 hover:bg-orange-200'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            {currentlyEnabled ? 'Disable automated voice' : 'Enable automated voice?'}
          </button>
        )}
      </div>

      {currentlyEnabled && (
        <div className="flex items-start gap-2 p-3 bg-orange-50 border border-orange-200 rounded-lg">
          <AlertTriangle className="w-5 h-5 text-orange-600 mt-0.5 flex-shrink-0" />
          <div className="text-sm text-orange-800">
            <p className="font-medium mb-1">Automated voice active</p>
            <p className="text-orange-700">
              This uses {roboticVoiceProvider || 'automated'} text-to-speech which may sound robotic.
              We recommend text-based learning for the best experience.
            </p>
          </div>
        </div>
      )}

      {showWarning && !currentlyEnabled && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6">
            <div className="flex items-start gap-3 mb-4">
              <AlertTriangle className="w-6 h-6 text-orange-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  Audio Quality Notice
                </h3>
                <p className="text-gray-700 mb-3">
                  This language uses automated voice synthesis which may sound robotic or unnatural.
                </p>
                <p className="text-gray-700 mb-4">
                  <strong>We recommend text-based learning</strong> for a better experience.
                  High-quality audio will be added as AI voice models improve.
                </p>
                <div className="bg-gray-50 rounded-lg p-3 text-sm text-gray-600">
                  <p className="font-medium mb-1">What you'll get:</p>
                  <ul className="list-disc list-inside space-y-1">
                    <li>Automated voice narration (robotic quality)</li>
                    <li>All text content available</li>
                    <li>Interactive elements work normally</li>
                    <li>Can disable anytime</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setShowWarning(false)}
                className="flex-1 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors font-medium"
              >
                Keep text-only
              </button>
              <button
                onClick={confirmEnable}
                className="flex-1 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors font-medium"
              >
                Enable anyway
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
