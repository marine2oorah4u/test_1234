import { X, Info } from 'lucide-react';
import { useState } from 'react';
import { useAccessibility } from '../contexts/AccessibilityContext';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  numBooks: number;
  setNumBooks: (num: number) => void;
}

interface TooltipProps {
  text: string;
  children: React.ReactNode;
}

function Tooltip({ text, children }: TooltipProps) {
  const [show, setShow] = useState(false);

  return (
    <div className="relative inline-block">
      <div
        onMouseEnter={() => setShow(true)}
        onMouseLeave={() => setShow(false)}
      >
        {children}
      </div>
      {show && (
        <div
          className="absolute px-3 py-2 text-xs rounded-lg shadow-2xl font-medium pointer-events-none -top-2 right-full mr-2"
          style={{
            backgroundColor: 'var(--color-background)',
            borderWidth: '2px',
            borderStyle: 'solid',
            borderColor: 'var(--color-primary)',
            color: 'var(--color-text)',
            boxShadow: '0 10px 40px rgba(0,0,0,0.3)',
            zIndex: 10000,
            whiteSpace: 'nowrap',
            minWidth: 'max-content',
          }}
        >
          {text}
        </div>
      )}
    </div>
  );
}

interface OptionCardProps {
  title: string;
  tooltip?: string;
  checked?: boolean;
  disabled?: boolean;
  isDemo?: boolean;
}

function OptionCard({ title, tooltip, checked = true, disabled = true, isDemo = true }: OptionCardProps) {
  return (
    <div
      className="rounded-lg p-3 flex items-center justify-between group hover:shadow-md transition-all"
      style={{
        backgroundColor: isDemo ? 'var(--color-surfaceHover)' : 'var(--color-surface)',
        borderWidth: '1px',
        borderStyle: 'solid',
        borderColor: 'var(--color-border)',
        opacity: disabled ? 0.6 : 1,
      }}
    >
      <label className={`flex items-center gap-2 text-sm flex-1 ${disabled ? 'cursor-not-allowed' : 'cursor-pointer'}`}>
        <input type="checkbox" disabled={disabled} checked={checked} className="rounded" />
        <span style={{ color: 'var(--color-text)' }}>{title}</span>
      </label>
      {tooltip && (
        <Tooltip text={tooltip}>
          <Info className="w-4 h-4" style={{ color: 'var(--color-textSecondary)' }} />
        </Tooltip>
      )}
    </div>
  );
}

export function SettingsModal({ isOpen, onClose, numBooks, setNumBooks }: SettingsModalProps) {
  const { settings, updateTextSize, updateTextBold, updateHighContrast, updateLargeButtons, updateScreenReaderMode, updateDyslexiaFont, updateColorBlindMode, updateReducedMotion, speak } = useAccessibility();

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ backgroundColor: 'rgba(0, 0, 0, 0.7)' }}
      onClick={onClose}
    >
      <div
        className="rounded-lg relative max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col"
        style={{
          backgroundColor: 'var(--color-surface)',
          borderWidth: '2px',
          borderStyle: 'solid',
          borderColor: 'var(--color-primary)',
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b" style={{ borderColor: 'var(--color-border)' }}>
          <button
            onClick={onClose}
            className="absolute top-6 right-6 p-2 rounded-md transition hover:bg-opacity-10"
            style={{ color: 'var(--color-textSecondary)' }}
          >
            <X className="w-6 h-6" />
          </button>

          <div className="flex items-center gap-3 mb-4">
            <h3 className="text-2xl font-semibold" style={{ color: 'var(--color-text)' }}>
              Settings
            </h3>
            <span
              className="px-3 py-1 rounded text-xs font-bold uppercase tracking-wide"
              style={{
                backgroundColor: 'var(--color-warning)',
                color: 'var(--color-background)',
              }}
            >
              Demo Mode
            </span>
          </div>

          <p className="text-sm" style={{ color: 'var(--color-textSecondary)' }}>
            Configure accessibility settings for better usability
          </p>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
            <div className="space-y-6">
              <div className="p-4 rounded-lg" style={{ backgroundColor: 'var(--color-background)' }}>
                <p className="text-sm mb-4" style={{ color: 'var(--color-textSecondary)' }}>
                  These accessibility options are available now in the demo:
                </p>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: 'var(--color-text)' }}>
                      Text Size: {settings.textSize}px
                    </label>
                    <input
                      type="range"
                      min="12"
                      max="24"
                      value={settings.textSize}
                      onChange={(e) => updateTextSize(Number(e.target.value))}
                      className="w-full"
                    />
                    <div className="flex justify-between text-xs mt-1" style={{ color: 'var(--color-textMuted)' }}>
                      <span>12px</span>
                      <span>24px</span>
                    </div>
                  </div>

                  <div>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.textBold}
                        onChange={(e) => updateTextBold(e.target.checked)}
                        className="rounded"
                      />
                      <span className="text-sm" style={{ color: 'var(--color-text)' }}>
                        Bold Text
                      </span>
                    </label>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-lg font-semibold mb-3" style={{ color: 'var(--color-text)' }}>
                  Additional Options
                </h4>
                <div className="space-y-3">
                  <div
                    className="rounded-lg p-3 flex items-center justify-between group hover:shadow-md transition-all"
                    style={{
                      backgroundColor: 'var(--color-surface)',
                      borderWidth: '1px',
                      borderStyle: 'solid',
                      borderColor: 'var(--color-border)',
                    }}
                  >
                    <label className="flex items-center gap-2 text-sm flex-1 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.highContrast}
                        onChange={(e) => updateHighContrast(e.target.checked)}
                        className="rounded"
                      />
                      <span style={{ color: 'var(--color-text)' }}>High Contrast Mode</span>
                    </label>
                    <Tooltip text="Increases contrast with pure black background and white borders - helps users with visual impairments see content more clearly">
                      <Info className="w-4 h-4 opacity-50 group-hover:opacity-100 transition-opacity" style={{ color: 'var(--color-textSecondary)' }} />
                    </Tooltip>
                  </div>

                  <div
                    className="rounded-lg p-3 flex items-center justify-between group hover:shadow-md transition-all"
                    style={{
                      backgroundColor: 'var(--color-surface)',
                      borderWidth: '1px',
                      borderStyle: 'solid',
                      borderColor: 'var(--color-border)',
                    }}
                  >
                    <label className="flex items-center gap-2 text-sm flex-1 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.largeButtons}
                        onChange={(e) => updateLargeButtons(e.target.checked)}
                        className="rounded"
                      />
                      <span style={{ color: 'var(--color-text)' }}>Large Buttons</span>
                    </label>
                    <Tooltip text="Makes all buttons bigger (minimum 48px height) for easier clicking and tapping - great for touch screens and motor accessibility">
                      <Info className="w-4 h-4 opacity-50 group-hover:opacity-100 transition-opacity" style={{ color: 'var(--color-textSecondary)' }} />
                    </Tooltip>
                  </div>

                  <div
                    className="rounded-lg p-3 flex items-center justify-between group hover:shadow-md transition-all"
                    style={{
                      backgroundColor: 'var(--color-surface)',
                      borderWidth: '1px',
                      borderStyle: 'solid',
                      borderColor: 'var(--color-border)',
                    }}
                  >
                    <label className="flex items-center gap-2 text-sm flex-1 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.screenReaderMode}
                        onChange={(e) => updateScreenReaderMode(e.target.checked)}
                        className="rounded"
                      />
                      <span style={{ color: 'var(--color-text)' }}>Keyboard Navigation Mode</span>
                    </label>
                    <Tooltip text="Shows visible focus outlines when navigating with keyboard (Tab key) so you always know where you are on the page - essential for keyboard-only users">
                      <Info className="w-4 h-4 opacity-50 group-hover:opacity-100 transition-opacity" style={{ color: 'var(--color-textSecondary)' }} />
                    </Tooltip>
                  </div>

                  <div
                    className="rounded-lg p-3 flex items-center justify-between group hover:shadow-md transition-all"
                    style={{
                      backgroundColor: 'var(--color-surface)',
                      borderWidth: '1px',
                      borderStyle: 'solid',
                      borderColor: 'var(--color-border)',
                    }}
                  >
                    <div className="flex items-center gap-3 flex-1">
                      <span className="text-sm" style={{ color: 'var(--color-text)' }}>Text-to-Speech Voice Reader</span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          speak('This is a test of the text to speech reader. It can read any text aloud using your browser\'s built-in voice capabilities.');
                        }}
                        className="px-4 py-2 rounded text-xs font-semibold transition hover:opacity-90"
                        style={{
                          backgroundColor: 'var(--color-accent)',
                          color: 'var(--color-background)',
                        }}
                      >
                        Test Voice
                      </button>
                    </div>
                    <Tooltip text="Built-in text-to-speech voice reader - click the test button to hear it speak. Future versions will read text automatically as you navigate">
                      <Info className="w-4 h-4 opacity-50 group-hover:opacity-100 transition-opacity" style={{ color: 'var(--color-textSecondary)' }} />
                    </Tooltip>
                  </div>

                  <div
                    className="rounded-lg p-3 flex items-center justify-between group hover:shadow-md transition-all"
                    style={{
                      backgroundColor: 'var(--color-surface)',
                      borderWidth: '1px',
                      borderStyle: 'solid',
                      borderColor: 'var(--color-border)',
                    }}
                  >
                    <label className="flex items-center gap-2 text-sm flex-1 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.dyslexiaFont}
                        onChange={(e) => updateDyslexiaFont(e.target.checked)}
                        className="rounded"
                      />
                      <span style={{ color: 'var(--color-text)' }}>Dyslexia-Friendly Font</span>
                    </label>
                    <Tooltip text="Uses Comic Sans font with extra letter spacing and line height - proven to help with dyslexia and reading difficulties">
                      <Info className="w-4 h-4 opacity-50 group-hover:opacity-100 transition-opacity" style={{ color: 'var(--color-textSecondary)' }} />
                    </Tooltip>
                  </div>

                  <div
                    className="rounded-lg p-3 flex items-center justify-between group hover:shadow-md transition-all"
                    style={{
                      backgroundColor: 'var(--color-surface)',
                      borderWidth: '1px',
                      borderStyle: 'solid',
                      borderColor: 'var(--color-border)',
                    }}
                  >
                    <label className="flex items-center gap-2 text-sm flex-1 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.colorBlindMode}
                        onChange={(e) => updateColorBlindMode(e.target.checked)}
                        className="rounded"
                      />
                      <span style={{ color: 'var(--color-text)' }}>Color Blind Mode</span>
                    </label>
                    <Tooltip text="Adjusts color saturation and uses color-blind safe palette (blues, oranges, teals) - helps users with deuteranopia and protanopia">
                      <Info className="w-4 h-4 opacity-50 group-hover:opacity-100 transition-opacity" style={{ color: 'var(--color-textSecondary)' }} />
                    </Tooltip>
                  </div>

                  <div
                    className="rounded-lg p-3 flex items-center justify-between group hover:shadow-md transition-all"
                    style={{
                      backgroundColor: 'var(--color-surface)',
                      borderWidth: '1px',
                      borderStyle: 'solid',
                      borderColor: 'var(--color-border)',
                    }}
                  >
                    <label className="flex items-center gap-2 text-sm flex-1 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.reducedMotion}
                        onChange={(e) => updateReducedMotion(e.target.checked)}
                        className="rounded"
                      />
                      <span style={{ color: 'var(--color-text)' }}>Reduced Motion</span>
                    </label>
                    <Tooltip text="Removes all animations and transitions - essential for users with vestibular disorders or motion sensitivity">
                      <Info className="w-4 h-4 opacity-50 group-hover:opacity-100 transition-opacity" style={{ color: 'var(--color-textSecondary)' }} />
                    </Tooltip>
                  </div>
                </div>
              </div>
            </div>
        </div>

        <div className="p-4 border-t" style={{ borderColor: 'var(--color-border)', backgroundColor: 'var(--color-background)' }}>
          <p className="text-xs text-center" style={{ color: 'var(--color-textMuted)' }}>
            Accessibility settings are fully functional in demo mode.
          </p>
        </div>
      </div>
    </div>
  );
}
