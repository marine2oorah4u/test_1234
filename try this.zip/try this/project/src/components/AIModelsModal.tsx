import { X, Sparkles, Image as ImageIcon, MessageSquare, Mic, Video, Brain, Info, AlertCircle } from 'lucide-react';
import { useState, useEffect } from 'react';
import {
  type ModelInfo,
  type ModelTier,
  CONTENT_MODELS,
  IMAGE_MODELS,
  AUDIO_MODELS,
  VIDEO_MODELS,
  INTERACTIVE_MODELS,
  ASSESSMENT_MODELS,
  CATEGORY_TOKEN_POOLS
} from '../config/aiModels';

const getTierColor = (tier: ModelTier): string => {
  switch (tier) {
    case 'budget': return '#6b7280'; // gray
    case 'standard': return '#3b82f6'; // blue
    case 'professional': return '#8b5cf6'; // violet (not purple)
    case 'premium': return '#10b981'; // green
  }
};

const getTierLabel = (tier: ModelTier): string => {
  switch (tier) {
    case 'budget': return 'Budget';
    case 'standard': return 'Standard';
    case 'professional': return 'Professional';
    case 'premium': return 'Premium';
  }
};

interface AIModelsModalProps {
  isOpen: boolean;
  onClose: () => void;
  numBooks?: number;
  setNumBooks?: (num: number) => void;
}

interface ModelOptionProps extends ModelInfo {
  selected?: boolean;
  onClick: () => void;
  available: boolean;
}

function ModelOption({ name, provider, recommended, selected, onClick, available, tokensNeeded, tier }: ModelOptionProps) {
  return (
    <button
      onClick={onClick}
      className="w-full text-left p-4 rounded-lg border-2 transition-all hover:shadow-md relative"
      style={{
        borderColor: selected ? getTierColor(tier) : 'var(--color-border)',
        backgroundColor: selected ? 'var(--color-surfaceHover)' : 'var(--color-surface)',
        opacity: available ? 1 : 0.5,
      }}
    >
      <div className="flex items-center justify-between mb-1">
        <div className="flex items-center gap-2">
          <h5 className="font-semibold text-sm" style={{ color: 'var(--color-text)' }}>
            {name}
          </h5>
          <span
            className="px-1.5 py-0.5 rounded text-xs font-semibold"
            style={{
              backgroundColor: getTierColor(tier),
              color: 'white',
            }}
          >
            {getTierLabel(tier)}
          </span>
        </div>
        {recommended && (
          <span
            className="px-2 py-0.5 rounded text-xs font-bold"
            style={{
              backgroundColor: 'var(--color-accent)',
              color: 'var(--color-background)',
            }}
          >
            BEST
          </span>
        )}
      </div>
      <p className="text-xs mb-2" style={{ color: 'var(--color-textSecondary)' }}>
        {provider}
      </p>
      <div className="flex items-center justify-between text-xs">
        <span style={{ color: 'var(--color-textMuted)' }}>
          Needs: {tokensNeeded.toLocaleString()}
        </span>
      </div>
    </button>
  );
}


export function AIModelsModal({ isOpen, onClose, numBooks = 1, setNumBooks }: AIModelsModalProps) {
  const [activeCategory, setActiveCategory] = useState<'content' | 'images' | 'audio' | 'video' | 'interactive' | 'assessment'>('content');
  const [selectedModel, setSelectedModel] = useState<ModelInfo | null>(CONTENT_MODELS[0]);
  const [modelsWithTokens, setModelsWithTokens] = useState<ModelInfo[]>(CONTENT_MODELS);
  const [selectedModels, setSelectedModels] = useState({
    content: CONTENT_MODELS[0],
    images: IMAGE_MODELS[0],
    audio: AUDIO_MODELS[0],
    video: VIDEO_MODELS[0],
    interactive: INTERACTIVE_MODELS[0],
    assessment: ASSESSMENT_MODELS[0],
  });

  const getCategoryModels = (category: string): ModelInfo[] => {
    switch (category) {
      case 'content':
        return CONTENT_MODELS;
      case 'images':
        return IMAGE_MODELS;
      case 'audio':
        return AUDIO_MODELS;
      case 'video':
        return VIDEO_MODELS;
      case 'interactive':
        return INTERACTIVE_MODELS;
      case 'assessment':
        return ASSESSMENT_MODELS;
      default:
        return CONTENT_MODELS;
    }
  };

  useEffect(() => {
    const currentModels = getCategoryModels(activeCategory);
    const updatedModels = currentModels.map(model => ({
      ...model,
      tokensNeeded: model.tokensNeeded,
    }));
    setModelsWithTokens(updatedModels);
    setSelectedModel(selectedModels[activeCategory] || updatedModels[0]);
  }, [numBooks, activeCategory]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ backgroundColor: 'rgba(0, 0, 0, 0.7)' }}
      onClick={onClose}
    >
      <div
        className="rounded-xl shadow-2xl flex flex-col overflow-hidden"
        style={{
          backgroundColor: 'var(--color-background)',
          width: '95%',
          height: '90vh',
          borderWidth: '3px',
          borderStyle: 'solid',
          borderColor: 'var(--color-accent)',
          maxWidth: '1200px',
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <div
          className="px-6 py-3 flex items-center justify-between border-b"
          style={{
            backgroundColor: 'var(--color-warning)',
            borderColor: 'var(--color-border)',
          }}
        >
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4" style={{ color: 'var(--color-background)' }} />
            <p className="text-xs font-semibold" style={{ color: 'var(--color-background)' }}>
              Demo preview mode - Model selections are for demonstration only
            </p>
          </div>
        </div>

        <div className="flex flex-1 overflow-hidden">
          <div className="w-64 border-r p-6 overflow-y-auto" style={{ borderColor: 'var(--color-border)', backgroundColor: 'var(--color-background)' }}>
            <div className="mb-6">
              <h3 className="text-xl font-bold mb-1" style={{ color: 'var(--color-text)' }}>
                AI Services & Providers
              </h3>
              <p className="text-xs" style={{ color: 'var(--color-textSecondary)' }}>
                Select a service to see available providers
              </p>
            </div>

            {setNumBooks && (
              <div className="mb-6 p-3 rounded-lg" style={{ backgroundColor: 'var(--color-surface)' }}>
                <label className="block text-xs font-semibold mb-2" style={{ color: 'var(--color-text)' }}>
                  Books: {numBooks}
                </label>
                <input
                  type="range"
                  min="1"
                  max="10000"
                  value={Math.min(numBooks, 10000)}
                  onChange={(e) => setNumBooks(Number(e.target.value))}
                  className="w-full mb-2"
                />
                <input
                  type="number"
                  min="1"
                  max="999999"
                  value={numBooks}
                  onChange={(e) => {
                    const val = parseInt(e.target.value) || 1;
                    setNumBooks(Math.min(999999, Math.max(1, val)));
                  }}
                  className="w-full px-2 py-1 rounded-md border text-xs text-left"
                  style={{
                    backgroundColor: 'var(--color-background)',
                    borderColor: 'var(--color-border)',
                    color: 'var(--color-text)',
                  }}
                />
                <p className="text-xs mt-1" style={{ color: 'var(--color-textMuted)' }}>
                  Adjusts token estimates
                </p>
              </div>
            )}

            <div className="mb-6 p-4 rounded-lg" style={{ backgroundColor: 'var(--color-primary)', borderWidth: '2px', borderStyle: 'solid', borderColor: 'var(--color-accent)' }}>
              <h4 className="text-xs font-bold mb-3" style={{ color: 'var(--color-background)' }}>
                TOKEN USAGE BREAKDOWN
              </h4>
              <div className="space-y-2 text-xs" style={{ color: 'var(--color-background)' }}>
                <div className="flex justify-between">
                  <span>Content Generation:</span>
                  <span className="font-bold">{(selectedModels.content.tokensNeeded * numBooks).toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Image Prompts:</span>
                  <span className="font-bold">{(selectedModels.images.tokensNeeded * numBooks).toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Audio Scripts:</span>
                  <span className="font-bold">{(selectedModels.audio.tokensNeeded * numBooks).toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Video Planning:</span>
                  <span className="font-bold">{(selectedModels.video.tokensNeeded * numBooks).toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Interactive Elements:</span>
                  <span className="font-bold">{(selectedModels.interactive.tokensNeeded * numBooks).toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Assessments:</span>
                  <span className="font-bold">{(selectedModels.assessment.tokensNeeded * numBooks).toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Add-ons (8 types):</span>
                  <span className="font-bold">{(5110 * numBooks).toLocaleString()}</span>
                </div>
                <div className="pt-2 mt-2 border-t flex justify-between font-bold text-sm" style={{ borderColor: 'var(--color-accent)' }}>
                  <span>TOTAL ESTIMATE:</span>
                  <span>{((selectedModels.content.tokensNeeded + selectedModels.images.tokensNeeded + selectedModels.audio.tokensNeeded + selectedModels.video.tokensNeeded + selectedModels.interactive.tokensNeeded + selectedModels.assessment.tokensNeeded + 5110) * numBooks).toLocaleString()}</span>
                </div>
              </div>
              <p className="text-xs mt-2" style={{ color: 'var(--color-background)', opacity: 0.8 }}>
                Based on selected models for {numBooks} {numBooks === 1 ? 'book' : 'books'} • Varies by model choice
              </p>
            </div>

            <div className="space-y-2">
              <button
                onClick={() => setActiveCategory('content')}
                className="w-full text-left px-3 py-2 rounded-lg transition flex flex-col gap-0.5 text-sm font-medium"
                style={{
                  backgroundColor: activeCategory === 'content' ? 'var(--color-primary)' : 'transparent',
                  color: activeCategory === 'content' ? 'var(--color-background)' : 'var(--color-text)',
                }}
              >
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4" />
                  <span>Content Generation</span>
                </div>
              </button>
              <button
                onClick={() => setActiveCategory('images')}
                className="w-full text-left px-3 py-2 rounded-lg transition flex flex-col gap-0.5 text-sm font-medium"
                style={{
                  backgroundColor: activeCategory === 'images' ? 'var(--color-primary)' : 'transparent',
                  color: activeCategory === 'images' ? 'var(--color-background)' : 'var(--color-text)',
                }}
              >
                <div className="flex items-center gap-2">
                  <ImageIcon className="w-4 h-4" />
                  <span>Image Generation</span>
                </div>
              </button>
              <button
                onClick={() => setActiveCategory('audio')}
                className="w-full text-left px-3 py-2 rounded-lg transition flex flex-col gap-0.5 text-sm font-medium"
                style={{
                  backgroundColor: activeCategory === 'audio' ? 'var(--color-primary)' : 'transparent',
                  color: activeCategory === 'audio' ? 'var(--color-background)' : 'var(--color-text)',
                }}
              >
                <div className="flex items-center gap-2">
                  <Mic className="w-4 h-4" />
                  <span>Audio/Voice</span>
                </div>
              </button>
              <button
                onClick={() => setActiveCategory('video')}
                className="w-full text-left px-3 py-2 rounded-lg transition flex flex-col gap-0.5 text-sm font-medium"
                style={{
                  backgroundColor: activeCategory === 'video' ? 'var(--color-primary)' : 'transparent',
                  color: activeCategory === 'video' ? 'var(--color-background)' : 'var(--color-text)',
                }}
              >
                <div className="flex items-center gap-2">
                  <Video className="w-4 h-4" />
                  <span>Video</span>
                </div>
              </button>
              <button
                onClick={() => setActiveCategory('interactive')}
                className="w-full text-left px-3 py-2 rounded-lg transition flex flex-col gap-0.5 text-sm font-medium"
                style={{
                  backgroundColor: activeCategory === 'interactive' ? 'var(--color-primary)' : 'transparent',
                  color: activeCategory === 'interactive' ? 'var(--color-background)' : 'var(--color-text)',
                }}
              >
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-4 h-4" />
                  <span>Interactive/Tutoring</span>
                </div>
              </button>
              <button
                onClick={() => setActiveCategory('assessment')}
                className="w-full text-left px-3 py-2 rounded-lg transition flex flex-col gap-0.5 text-sm font-medium"
                style={{
                  backgroundColor: activeCategory === 'assessment' ? 'var(--color-primary)' : 'transparent',
                  color: activeCategory === 'assessment' ? 'var(--color-background)' : 'var(--color-text)',
                }}
              >
                <div className="flex items-center gap-2">
                  <Brain className="w-4 h-4" />
                  <span>Assessment</span>
                </div>
              </button>
            </div>
          </div>

          <div className="flex-1 flex flex-col overflow-hidden">
            <div className="p-6 border-b flex items-center justify-between" style={{ borderColor: 'var(--color-border)' }}>
              <div>
                <h4 className="text-2xl font-bold" style={{ color: 'var(--color-text)' }}>
                  {activeCategory === 'content' && 'Content Generation'}
                  {activeCategory === 'images' && 'Image Generation'}
                  {activeCategory === 'audio' && 'Audio & Voice'}
                  {activeCategory === 'video' && 'Video Generation'}
                  {activeCategory === 'interactive' && 'Interactive & Tutoring'}
                  {activeCategory === 'assessment' && 'Assessment Tools'}
                </h4>
                <p className="text-xs mt-1" style={{ color: 'var(--color-textSecondary)' }}>
                  Click a provider to view detailed information and pricing
                </p>
              </div>
              <button
                onClick={onClose}
                className="p-2 rounded-md transition hover:bg-opacity-10"
                style={{ color: 'var(--color-textSecondary)' }}
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto">
              <div className="grid grid-cols-2 gap-4 p-6">
                <div className="space-y-3">
                  {modelsWithTokens.map((model, index) => (
                    <ModelOption
                      key={index}
                      {...model}
                      selected={selectedModel?.name === model.name}
                      onClick={() => {
                        setSelectedModel(model);
                        setSelectedModels(prev => ({
                          ...prev,
                          [activeCategory]: model
                        }));
                      }}
                      available={CATEGORY_TOKEN_POOLS[activeCategory] >= model.tokensNeeded}
                    />
                  ))}
                </div>

                {selectedModel && (
                  <div
                    className="rounded-lg p-8 overflow-y-auto sticky top-0"
                    style={{
                      backgroundColor: 'var(--color-background)',
                      borderWidth: '3px',
                      borderStyle: 'solid',
                      borderColor: getTierColor(selectedModel.tier),
                      minHeight: '600px',
                      maxHeight: '800px',
                    }}
                  >
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <h5 className="text-xl font-bold" style={{ color: 'var(--color-text)' }}>
                              {selectedModel.name}
                            </h5>
                            <span
                              className="px-2 py-1 rounded text-sm font-bold"
                              style={{
                                backgroundColor: getTierColor(selectedModel.tier),
                                color: 'white',
                              }}
                            >
                              {getTierLabel(selectedModel.tier).toUpperCase()}
                            </span>
                          </div>
                          <p className="text-sm" style={{ color: 'var(--color-textSecondary)' }}>
                            {selectedModel.provider}
                          </p>
                        </div>
                        {selectedModel.recommended && (
                          <span
                            className="px-3 py-1.5 rounded text-sm font-bold"
                            style={{
                              backgroundColor: 'var(--color-accent)',
                              color: 'var(--color-background)',
                            }}
                          >
                            BEST CHOICE
                          </span>
                        )}
                      </div>

                      <p className="text-sm mb-4" style={{ color: 'var(--color-textSecondary)' }}>
                        {selectedModel.description}
                      </p>

                      <div className="grid grid-cols-2 gap-4 mb-4">
                        <div>
                          <p className="text-xs font-semibold mb-1" style={{ color: 'var(--color-textMuted)' }}>
                            Context Window
                          </p>
                          <p className="text-sm font-bold" style={{ color: 'var(--color-text)' }}>
                            {selectedModel.contextWindow}
                          </p>
                        </div>
                        <div>
                          <p className="text-xs font-semibold mb-1" style={{ color: 'var(--color-textMuted)' }}>
                            Input Cost
                          </p>
                          <p className="text-sm font-bold" style={{ color: 'var(--color-text)' }}>
                            {selectedModel.inputCostPer1M}/1M
                          </p>
                        </div>
                      </div>

                      <div className="mb-4 p-3 rounded-lg" style={{ backgroundColor: CATEGORY_TOKEN_POOLS[activeCategory] >= selectedModel.tokensNeeded ? 'rgba(34, 197, 94, 0.1)' : 'rgba(239, 68, 68, 0.1)' }}>
                        <p className="text-xs font-semibold mb-1" style={{ color: 'var(--color-textMuted)' }}>
                          Token Usage for {numBooks} {numBooks === 1 ? 'Book' : 'Books'}
                        </p>
                        <div className="flex justify-between items-end mb-2">
                          <div className="text-right">
                            <p className="text-lg font-bold" style={{ color: 'var(--color-text)' }}>
                              {selectedModel.tokensNeeded.toLocaleString()}
                            </p>
                            <p className="text-xs" style={{ color: 'var(--color-textSecondary)' }}>
                              tokens needed
                            </p>
                          </div>
                        </div>
                        <div className="pt-2 border-t" style={{ borderColor: 'var(--color-border)' }}>
                          <p className="text-xs" style={{ color: 'var(--color-textMuted)' }}>
                            <strong>Total for all categories:</strong> Estimated {(() => {
                              const contentTokens = 50000 * numBooks;
                              const imageTokens = 100 * numBooks;
                              const audioTokens = 5000 * numBooks;
                              const videoTokens = 10 * numBooks;
                              const interactiveTokens = 30000 * numBooks;
                              const assessmentTokens = 20000 * numBooks;
                              return (contentTokens + imageTokens + audioTokens + videoTokens + interactiveTokens + assessmentTokens).toLocaleString();
                            })()} tokens needed for complete book generation
                          </p>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div>
                          <h6 className="text-sm font-bold mb-2 flex items-center gap-1" style={{ color: 'var(--color-success)' }}>
                            <span className="text-lg">+</span> Strengths
                          </h6>
                          <ul className="space-y-1">
                            {selectedModel.strengths.map((strength, idx) => (
                              <li key={idx} className="text-xs flex items-start gap-2" style={{ color: 'var(--color-textSecondary)' }}>
                                <span style={{ color: 'var(--color-success)' }}>•</span>
                                <span>{strength}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div>
                          <h6 className="text-sm font-bold mb-2 flex items-center gap-1" style={{ color: 'var(--color-error)' }}>
                            <span className="text-lg">-</span> Weaknesses
                          </h6>
                          <ul className="space-y-1">
                            {selectedModel.weaknesses.map((weakness, idx) => (
                              <li key={idx} className="text-xs flex items-start gap-2" style={{ color: 'var(--color-textSecondary)' }}>
                                <span style={{ color: 'var(--color-error)' }}>•</span>
                                <span>{weakness}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div>
                          <h6 className="text-sm font-bold mb-2 flex items-center gap-1" style={{ color: 'var(--color-primary)' }}>
                            <Info className="w-4 h-4" /> Best For
                          </h6>
                          <ul className="space-y-1">
                            {selectedModel.bestFor.map((use, idx) => (
                              <li key={idx} className="text-xs flex items-start gap-2" style={{ color: 'var(--color-textSecondary)' }}>
                                <span style={{ color: 'var(--color-primary)' }}>•</span>
                                <span>{use}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
