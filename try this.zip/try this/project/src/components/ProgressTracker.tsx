import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { CheckCircle, Clock, Loader2 } from 'lucide-react';

interface ProgressTrackerProps {
  bookId: string;
}

interface QueueItem {
  status: string;
  progress_stage: string;
  progress_percentage: number;
  estimated_completion: string | null;
}

const STAGES = [
  { id: 'initializing', label: 'Initializing' },
  { id: 'research', label: 'Research & Planning' },
  { id: 'outline', label: 'Creating Outline' },
  { id: 'writing', label: 'Writing Content' },
  { id: 'adapting', label: 'Adapting Reading Levels' },
  { id: 'formats', label: 'Converting Formats' },
  { id: 'audio', label: 'Generating Audio' },
  { id: 'video', label: 'Creating Video' },
  { id: 'interactive', label: 'Building Interactive Content' },
  { id: 'finalizing', label: 'Finalizing' },
];

export function ProgressTracker({ bookId }: ProgressTrackerProps) {
  const [progress, setProgress] = useState<QueueItem | null>(null);

  useEffect(() => {
    loadProgress();

    const subscription = supabase
      .channel(`progress_${bookId}`)
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'generation_queue',
        filter: `book_id=eq.${bookId}`
      }, () => {
        loadProgress();
      })
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [bookId]);

  const loadProgress = async () => {
    try {
      const { data, error } = await supabase
        .from('generation_queue')
        .select('status, progress_stage, progress_percentage, estimated_completion')
        .eq('book_id', bookId)
        .single();

      if (error) throw error;
      setProgress(data);
    } catch (error) {
      console.error('Error loading progress:', error);
    }
  };

  if (!progress) {
    return (
      <div className="flex items-center justify-center p-4">
        <Loader2 className="w-6 h-6 text-blue-600 animate-spin" />
      </div>
    );
  }

  const currentStageIndex = STAGES.findIndex(s => s.id === progress.progress_stage);

  return (
    <div className="bg-gray-50 rounded-lg p-6">
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-gray-700">Overall Progress</span>
          <span className="text-sm font-bold text-gray-900">{progress.progress_percentage}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
          <div
            className="bg-blue-600 h-full rounded-full transition-all duration-500 ease-out relative overflow-hidden"
            style={{ width: `${progress.progress_percentage}%` }}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent opacity-30 animate-[shimmer_2s_infinite]"></div>
          </div>
        </div>
      </div>

      {progress.estimated_completion && (
        <div className="mb-6 flex items-center gap-2 text-sm text-gray-600">
          <Clock className="w-4 h-4" />
          <span>
            Estimated completion: {new Date(progress.estimated_completion).toLocaleTimeString()}
          </span>
        </div>
      )}

      <div className="space-y-3">
        {STAGES.map((stage, index) => {
          const isCompleted = index < currentStageIndex;
          const isCurrent = index === currentStageIndex;
          const isPending = index > currentStageIndex;

          return (
            <div
              key={stage.id}
              className={`flex items-center gap-3 ${
                isPending ? 'opacity-50' : ''
              }`}
            >
              <div className={`flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center ${
                isCompleted
                  ? 'bg-green-100'
                  : isCurrent
                  ? 'bg-blue-100'
                  : 'bg-gray-200'
              }`}>
                {isCompleted ? (
                  <CheckCircle className="w-4 h-4 text-green-600" />
                ) : isCurrent ? (
                  <Loader2 className="w-4 h-4 text-blue-600 animate-spin" />
                ) : (
                  <div className="w-2 h-2 rounded-full bg-gray-400"></div>
                )}
              </div>
              <span className={`text-sm ${
                isCompleted
                  ? 'text-gray-900 font-medium'
                  : isCurrent
                  ? 'text-blue-700 font-semibold'
                  : 'text-gray-600'
              }`}>
                {stage.label}
              </span>
              {isCurrent && (
                <span className="ml-auto text-xs text-blue-600 animate-pulse">
                  In progress...
                </span>
              )}
            </div>
          );
        })}
      </div>

      <div className="mt-6 pt-6 border-t border-gray-200">
        <p className="text-xs text-gray-600 text-center">
          You can leave this page. We'll continue processing in the background.
        </p>
      </div>

      <style>{`
        @keyframes shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
      `}</style>
    </div>
  );
}
