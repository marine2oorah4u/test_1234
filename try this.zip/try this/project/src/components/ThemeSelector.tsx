import React, { useState, useEffect, useRef } from 'react';
import { Palette, Check } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

export const ThemeSelector: React.FC = () => {
  const { currentTheme, availableThemes, setTheme } = useTheme();
  const [isOpen, setIsOpen] = useState(false);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const [modalPosition, setModalPosition] = useState({ top: 0, left: 0 });
  const popupRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen && buttonRef.current) {
      const rect = buttonRef.current.getBoundingClientRect();
      const modalWidth = 400;
      const modalMaxHeight = 600;
      const windowWidth = window.innerWidth;
      const windowHeight = window.innerHeight;
      const padding = 16;
      const gap = 8;

      let left = rect.left;
      if (left + modalWidth > windowWidth - padding) {
        left = windowWidth - modalWidth - padding;
      }
      if (left < padding) {
        left = padding;
      }

      let calculatedTop = rect.bottom + gap;
      const spaceBelow = windowHeight - rect.bottom - gap - padding;
      const spaceAbove = rect.top - gap - padding;

      if (spaceBelow < modalMaxHeight && spaceAbove > spaceBelow) {
        calculatedTop = rect.top - modalMaxHeight - gap;
        if (calculatedTop < padding) {
          calculatedTop = padding;
        }
      }

      setModalPosition({
        top: calculatedTop,
        left: left,
      });
    }
  }, [isOpen]);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        setIsOpen(false);
      }
    };

    const handleClickOutside = (e: MouseEvent) => {
      if (isOpen && popupRef.current && buttonRef.current &&
          !popupRef.current.contains(e.target as Node) &&
          !buttonRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('keydown', handleEscape);
      document.addEventListener('mousedown', handleClickOutside);
      return () => {
        document.removeEventListener('keydown', handleEscape);
        document.removeEventListener('mousedown', handleClickOutside);
      };
    }
  }, [isOpen]);

  return (
    <>
      <button
        ref={buttonRef}
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-300"
        style={{
          backgroundColor: 'var(--color-surface)',
          color: 'var(--color-text)',
          border: '2px solid var(--color-border)',
        }}
      >
        <Palette size={20} />
        <span className="hidden sm:inline">Theme</span>
      </button>

      {isOpen && (
        <>
          <div
            className="fixed inset-0 z-[9998]"
            onClick={() => setIsOpen(false)}
          />
          <div
            ref={popupRef}
            className="fixed w-[400px] max-w-[calc(100vw-2rem)] rounded-xl shadow-2xl z-[9999] overflow-hidden flex flex-col"
            style={{
              backgroundColor: 'var(--color-surface)',
              border: '2px solid var(--color-border)',
              maxHeight: '600px',
              top: `${modalPosition.top}px`,
              left: `${modalPosition.left}px`,
            }}
          >
            <div
              className="px-4 py-3 border-b"
              style={{
                borderColor: 'var(--color-border)',
                color: 'var(--color-text)',
              }}
            >
              <h3 className="font-semibold text-lg">Choose Your Theme</h3>
              <p
                className="text-sm mt-1"
                style={{ color: 'var(--color-textMuted)' }}
              >
                Select a theme that inspires you
              </p>
            </div>

            <div className="flex-1 overflow-y-auto p-2">
              <div className="grid grid-cols-2 gap-2">
                {availableThemes.map((theme) => (
                  <button
                    key={theme.id}
                    onClick={() => {
                      setTheme(theme.id);
                    }}
                    className="relative p-3 rounded-lg transition-all duration-300 hover:scale-105"
                    style={{
                      backgroundColor: theme.colors.surface,
                      border: `2px solid ${
                        currentTheme.id === theme.id
                          ? theme.colors.accent
                          : theme.colors.border
                      }`,
                    }}
                  >
                    <div className="flex flex-col gap-2">
                      <div
                        className="h-16 rounded-md"
                        style={{
                          background: theme.patterns?.backgroundImage || theme.colors.background,
                        }}
                      />
                      <div className="flex items-center justify-between">
                        <span
                          className="text-sm font-medium"
                          style={{ color: theme.colors.text }}
                        >
                          {theme.name}
                        </span>
                        {currentTheme.id === theme.id && (
                          <div
                            className="flex items-center justify-center w-5 h-5 rounded-full"
                            style={{ backgroundColor: theme.colors.accent }}
                          >
                            <Check size={14} style={{ color: theme.colors.background }} />
                          </div>
                        )}
                      </div>
                      <div className="flex gap-1">
                        <div
                          className="h-3 flex-1 rounded-full"
                          style={{ backgroundColor: theme.colors.primary }}
                        />
                        <div
                          className="h-3 flex-1 rounded-full"
                          style={{ backgroundColor: theme.colors.secondary }}
                        />
                        <div
                          className="h-3 flex-1 rounded-full"
                          style={{ backgroundColor: theme.colors.accent }}
                        />
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </>
      )}
    </>
  );
};
