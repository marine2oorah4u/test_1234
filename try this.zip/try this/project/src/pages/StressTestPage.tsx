import { useState, useEffect, useRef } from 'react';
import { supabase } from '../lib/supabase';
import {
  Play,
  Square,
  Activity,
  Zap,
  Clock,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Database,
  Cpu,
  HardDrive
} from 'lucide-react';

interface StressTestConfig {
  testType: 'load' | 'concurrent' | 'endurance' | 'spike';
  duration: number;
  requestsPerSecond: number;
  maxConcurrent: number;
  targetEndpoint: string;
}

interface StressTestMetrics {
  totalRequests: number;
  successfulRequests: number;
  failedRequests: number;
  avgResponseTime: number;
  maxResponseTime: number;
  minResponseTime: number;
  requestsPerSecond: number;
  currentLoad: number;
  errors: Array<{ message: string; count: number }>;
  responseTimes: number[];
}

export function StressTestPage() {
  const [isRunning, setIsRunning] = useState(false);
  const [config, setConfig] = useState<StressTestConfig>({
    testType: 'load',
    duration: 60,
    requestsPerSecond: 10,
    maxConcurrent: 50,
    targetEndpoint: 'simple',
  });
  const [metrics, setMetrics] = useState<StressTestMetrics>({
    totalRequests: 0,
    successfulRequests: 0,
    failedRequests: 0,
    avgResponseTime: 0,
    maxResponseTime: 0,
    minResponseTime: Infinity,
    requestsPerSecond: 0,
    currentLoad: 0,
    errors: [],
    responseTimes: [],
  });
  const [elapsedTime, setElapsedTime] = useState(0);
  const [currentBatch, setCurrentBatch] = useState(0);
  const testRunningRef = useRef(false);
  const startTimeRef = useRef<number>(0);

  const callStressTestEndpoint = async (complexity: number = 1): Promise<{ success: boolean; responseTime: number; error?: string }> => {
    const startTime = performance.now();

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('No active session');
      }

      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/stress-test-endpoint`;
      const response = await fetch(
        `${apiUrl}?type=${config.targetEndpoint}&complexity=${complexity}`,
        {
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
        }
      );

      const endTime = performance.now();
      const responseTime = endTime - startTime;

      if (!response.ok) {
        const errorData = await response.json();
        return {
          success: false,
          responseTime,
          error: errorData.error || 'Request failed',
        };
      }

      await response.json();
      return {
        success: true,
        responseTime,
      };
    } catch (error: any) {
      const endTime = performance.now();
      return {
        success: false,
        responseTime: endTime - startTime,
        error: error.message || 'Unknown error',
      };
    }
  };

  const executeBatch = async (batchSize: number) => {
    const promises = [];
    const complexity = config.targetEndpoint === 'simple' ? 1 :
                      config.targetEndpoint === 'database' ? 5 :
                      config.targetEndpoint === 'compute' ? 3 : 2;

    for (let i = 0; i < batchSize; i++) {
      promises.push(callStressTestEndpoint(complexity));
    }

    const results = await Promise.allSettled(promises);

    return results.map(result => {
      if (result.status === 'fulfilled') {
        return result.value;
      }
      return {
        success: false,
        responseTime: 0,
        error: 'Request failed',
      };
    });
  };

  const runStressTest = async () => {
    testRunningRef.current = true;
    startTimeRef.current = Date.now();
    let requestsThisSecond = 0;
    let lastSecondTimestamp = Date.now();

    while (testRunningRef.current && elapsedTime < config.duration) {
      const now = Date.now();

      if (now - lastSecondTimestamp >= 1000) {
        setMetrics(prev => ({
          ...prev,
          requestsPerSecond: requestsThisSecond,
        }));
        requestsThisSecond = 0;
        lastSecondTimestamp = now;
      }

      const batchSize = Math.min(
        config.requestsPerSecond,
        config.maxConcurrent - currentBatch
      );

      if (batchSize > 0) {
        setCurrentBatch(prev => prev + batchSize);

        const results = await executeBatch(batchSize);

        setCurrentBatch(prev => prev - batchSize);
        requestsThisSecond += results.length;

        const successCount = results.filter(r => r.success).length;
        const failCount = results.length - successCount;
        const responseTimes = results.map(r => r.responseTime);
        const errors = results
          .filter(r => !r.success && r.error)
          .map(r => r.error!);

        setMetrics(prev => {
          const allResponseTimes = [...prev.responseTimes, ...responseTimes];
          const validTimes = allResponseTimes.filter(t => t > 0);

          const newErrors = [...prev.errors];
          errors.forEach(errorMsg => {
            const existing = newErrors.find(e => e.message === errorMsg);
            if (existing) {
              existing.count++;
            } else {
              newErrors.push({ message: errorMsg, count: 1 });
            }
          });

          return {
            totalRequests: prev.totalRequests + results.length,
            successfulRequests: prev.successfulRequests + successCount,
            failedRequests: prev.failedRequests + failCount,
            avgResponseTime: validTimes.length > 0
              ? Math.round(validTimes.reduce((a, b) => a + b, 0) / validTimes.length)
              : 0,
            maxResponseTime: Math.max(prev.maxResponseTime, ...responseTimes),
            minResponseTime: Math.min(
              prev.minResponseTime === Infinity ? 0 : prev.minResponseTime,
              ...responseTimes.filter(t => t > 0)
            ),
            requestsPerSecond: prev.requestsPerSecond,
            currentLoad: (currentBatch / config.maxConcurrent) * 100,
            errors: newErrors,
            responseTimes: allResponseTimes.slice(-1000),
          };
        });
      }

      await new Promise(resolve => setTimeout(resolve, 100));
    }

    testRunningRef.current = false;
    setIsRunning(false);
  };

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRunning) {
      interval = setInterval(() => {
        const elapsed = Math.floor((Date.now() - startTimeRef.current) / 1000);
        setElapsedTime(elapsed);

        if (elapsed >= config.duration) {
          testRunningRef.current = false;
          setIsRunning(false);
        }
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRunning, config.duration]);

  const handleStart = async () => {
    setIsRunning(true);
    setElapsedTime(0);
    setCurrentBatch(0);
    setMetrics({
      totalRequests: 0,
      successfulRequests: 0,
      failedRequests: 0,
      avgResponseTime: 0,
      maxResponseTime: 0,
      minResponseTime: Infinity,
      requestsPerSecond: 0,
      currentLoad: 0,
      errors: [],
      responseTimes: [],
    });

    runStressTest();
  };

  const handleStop = () => {
    testRunningRef.current = false;
    setIsRunning(false);
  };

  const successRate = metrics.totalRequests > 0
    ? ((metrics.successfulRequests / metrics.totalRequests) * 100).toFixed(1)
    : '0.0';

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold mb-2" style={{ color: 'var(--color-text)' }}>
              Stress Testing
            </h1>
            <p style={{ color: 'var(--color-textMuted)' }}>
              Test system performance with real requests to edge functions
            </p>
          </div>
          <div className="flex gap-3">
            {!isRunning ? (
              <button
                onClick={handleStart}
                className="flex items-center gap-2 px-6 py-3 rounded-lg transition-all"
                style={{
                  backgroundColor: 'var(--color-primary)',
                  color: 'var(--color-background)',
                }}
              >
                <Play className="w-5 h-5" />
                Start Test
              </button>
            ) : (
              <button
                onClick={handleStop}
                className="flex items-center gap-2 px-6 py-3 rounded-lg transition-all"
                style={{
                  backgroundColor: 'var(--color-error)',
                  color: 'var(--color-background)',
                }}
              >
                <Square className="w-5 h-5" />
                Stop Test
              </button>
            )}
          </div>
        </div>

        {isRunning && (
          <div
            className="p-4 rounded-lg border mb-6"
            style={{
              backgroundColor: 'var(--color-surface)',
              borderColor: 'var(--color-border)',
            }}
          >
            <div className="flex items-center gap-3 mb-2">
              <Activity className="w-5 h-5 animate-pulse" style={{ color: 'var(--color-primary)' }} />
              <span className="font-semibold" style={{ color: 'var(--color-text)' }}>
                Test Running: {elapsedTime}s / {config.duration}s
              </span>
              <span className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
                ({currentBatch} concurrent requests)
              </span>
            </div>
            <div className="w-full h-2 rounded-full" style={{ backgroundColor: 'var(--color-border)' }}>
              <div
                className="h-2 rounded-full transition-all"
                style={{
                  backgroundColor: 'var(--color-primary)',
                  width: `${(elapsedTime / config.duration) * 100}%`,
                }}
              />
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <div
          className="p-6 rounded-lg border"
          style={{
            backgroundColor: 'var(--color-surface)',
            borderColor: 'var(--color-border)',
          }}
        >
          <div className="mb-4">
            <label className="block mb-2 font-semibold" style={{ color: 'var(--color-text)' }}>
              Test Type
            </label>
            <select
              value={config.testType}
              onChange={(e) => setConfig({ ...config, testType: e.target.value as any })}
              disabled={isRunning}
              className="w-full px-4 py-2 rounded-lg border"
              style={{
                backgroundColor: 'var(--color-background)',
                borderColor: 'var(--color-border)',
                color: 'var(--color-text)',
              }}
            >
              <option value="load">Load Test</option>
              <option value="concurrent">Concurrent Users</option>
              <option value="endurance">Endurance Test</option>
              <option value="spike">Spike Test</option>
            </select>
          </div>

          <div className="mb-4">
            <label className="block mb-2 font-semibold" style={{ color: 'var(--color-text)' }}>
              Duration (seconds)
            </label>
            <input
              type="number"
              value={config.duration}
              onChange={(e) => setConfig({ ...config, duration: parseInt(e.target.value) })}
              disabled={isRunning}
              min="10"
              max="300"
              className="w-full px-4 py-2 rounded-lg border"
              style={{
                backgroundColor: 'var(--color-background)',
                borderColor: 'var(--color-border)',
                color: 'var(--color-text)',
              }}
            />
          </div>

          <div className="mb-4">
            <label className="block mb-2 font-semibold" style={{ color: 'var(--color-text)' }}>
              Requests per Second
            </label>
            <input
              type="number"
              value={config.requestsPerSecond}
              onChange={(e) => setConfig({ ...config, requestsPerSecond: parseInt(e.target.value) })}
              disabled={isRunning}
              min="1"
              max="100"
              className="w-full px-4 py-2 rounded-lg border"
              style={{
                backgroundColor: 'var(--color-background)',
                borderColor: 'var(--color-border)',
                color: 'var(--color-text)',
              }}
            />
          </div>

          <div className="mb-4">
            <label className="block mb-2 font-semibold" style={{ color: 'var(--color-text)' }}>
              Max Concurrent
            </label>
            <input
              type="number"
              value={config.maxConcurrent}
              onChange={(e) => setConfig({ ...config, maxConcurrent: parseInt(e.target.value) })}
              disabled={isRunning}
              min="1"
              max="100"
              className="w-full px-4 py-2 rounded-lg border"
              style={{
                backgroundColor: 'var(--color-background)',
                borderColor: 'var(--color-border)',
                color: 'var(--color-text)',
              }}
            />
          </div>

          <div className="mb-4">
            <label className="block mb-2 font-semibold" style={{ color: 'var(--color-text)' }}>
              Target Endpoint
            </label>
            <select
              value={config.targetEndpoint}
              onChange={(e) => setConfig({ ...config, targetEndpoint: e.target.value })}
              disabled={isRunning}
              className="w-full px-4 py-2 rounded-lg border"
              style={{
                backgroundColor: 'var(--color-background)',
                borderColor: 'var(--color-border)',
                color: 'var(--color-text)',
              }}
            >
              <option value="simple">Simple (Fast)</option>
              <option value="database">Database Query</option>
              <option value="compute">CPU Intensive</option>
              <option value="memory">Memory Test</option>
            </select>
          </div>
        </div>

        <div className="lg:col-span-2 grid grid-cols-2 md:grid-cols-3 gap-4">
          <div
            className="p-4 rounded-lg border"
            style={{
              backgroundColor: 'var(--color-surface)',
              borderColor: 'var(--color-border)',
            }}
          >
            <div className="flex items-center gap-2 mb-2">
              <Database className="w-5 h-5" style={{ color: 'var(--color-primary)' }} />
              <span className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
                Total Requests
              </span>
            </div>
            <div className="text-2xl font-bold" style={{ color: 'var(--color-text)' }}>
              {metrics.totalRequests.toLocaleString()}
            </div>
          </div>

          <div
            className="p-4 rounded-lg border"
            style={{
              backgroundColor: 'var(--color-surface)',
              borderColor: 'var(--color-border)',
            }}
          >
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="w-5 h-5" style={{ color: 'var(--color-success)' }} />
              <span className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
                Successful
              </span>
            </div>
            <div className="text-2xl font-bold" style={{ color: 'var(--color-success)' }}>
              {metrics.successfulRequests.toLocaleString()}
            </div>
          </div>

          <div
            className="p-4 rounded-lg border"
            style={{
              backgroundColor: 'var(--color-surface)',
              borderColor: 'var(--color-border)',
            }}
          >
            <div className="flex items-center gap-2 mb-2">
              <XCircle className="w-5 h-5" style={{ color: 'var(--color-error)' }} />
              <span className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
                Failed
              </span>
            </div>
            <div className="text-2xl font-bold" style={{ color: 'var(--color-error)' }}>
              {metrics.failedRequests.toLocaleString()}
            </div>
          </div>

          <div
            className="p-4 rounded-lg border"
            style={{
              backgroundColor: 'var(--color-surface)',
              borderColor: 'var(--color-border)',
            }}
          >
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-5 h-5" style={{ color: 'var(--color-primary)' }} />
              <span className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
                Success Rate
              </span>
            </div>
            <div className="text-2xl font-bold" style={{ color: 'var(--color-text)' }}>
              {successRate}%
            </div>
          </div>

          <div
            className="p-4 rounded-lg border"
            style={{
              backgroundColor: 'var(--color-surface)',
              borderColor: 'var(--color-border)',
            }}
          >
            <div className="flex items-center gap-2 mb-2">
              <Clock className="w-5 h-5" style={{ color: 'var(--color-primary)' }} />
              <span className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
                Avg Response
              </span>
            </div>
            <div className="text-2xl font-bold" style={{ color: 'var(--color-text)' }}>
              {metrics.avgResponseTime}ms
            </div>
          </div>

          <div
            className="p-4 rounded-lg border"
            style={{
              backgroundColor: 'var(--color-surface)',
              borderColor: 'var(--color-border)',
            }}
          >
            <div className="flex items-center gap-2 mb-2">
              <Zap className="w-5 h-5" style={{ color: 'var(--color-primary)' }} />
              <span className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
                Req/Second
              </span>
            </div>
            <div className="text-2xl font-bold" style={{ color: 'var(--color-text)' }}>
              {metrics.requestsPerSecond.toFixed(1)}
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <div
          className="p-6 rounded-lg border"
          style={{
            backgroundColor: 'var(--color-surface)',
            borderColor: 'var(--color-border)',
          }}
        >
          <h3 className="text-lg font-semibold mb-4" style={{ color: 'var(--color-text)' }}>
            Response Times
          </h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span style={{ color: 'var(--color-textMuted)' }}>Average:</span>
              <span className="font-semibold" style={{ color: 'var(--color-text)' }}>
                {metrics.avgResponseTime}ms
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span style={{ color: 'var(--color-textMuted)' }}>Maximum:</span>
              <span className="font-semibold" style={{ color: 'var(--color-text)' }}>
                {metrics.maxResponseTime}ms
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span style={{ color: 'var(--color-textMuted)' }}>Minimum:</span>
              <span className="font-semibold" style={{ color: 'var(--color-text)' }}>
                {metrics.minResponseTime === Infinity ? 0 : metrics.minResponseTime}ms
              </span>
            </div>
          </div>
        </div>

        <div
          className="p-6 rounded-lg border"
          style={{
            backgroundColor: 'var(--color-surface)',
            borderColor: 'var(--color-border)',
          }}
        >
          <h3 className="text-lg font-semibold mb-4" style={{ color: 'var(--color-text)' }}>
            Load Status
          </h3>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-2">
                <div className="flex items-center gap-2">
                  <Cpu className="w-4 h-4" style={{ color: 'var(--color-textMuted)' }} />
                  <span style={{ color: 'var(--color-textMuted)' }}>Concurrent Load:</span>
                </div>
                <span className="font-semibold" style={{ color: 'var(--color-text)' }}>
                  {metrics.currentLoad.toFixed(1)}%
                </span>
              </div>
              <div className="w-full h-2 rounded-full" style={{ backgroundColor: 'var(--color-border)' }}>
                <div
                  className="h-2 rounded-full transition-all"
                  style={{
                    backgroundColor: metrics.currentLoad > 80 ? 'var(--color-error)' : 'var(--color-primary)',
                    width: `${metrics.currentLoad}%`,
                  }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-2">
                <div className="flex items-center gap-2">
                  <HardDrive className="w-4 h-4" style={{ color: 'var(--color-textMuted)' }} />
                  <span style={{ color: 'var(--color-textMuted)' }}>Active Requests:</span>
                </div>
                <span className="font-semibold" style={{ color: 'var(--color-text)' }}>
                  {currentBatch} / {config.maxConcurrent}
                </span>
              </div>
              <div className="w-full h-2 rounded-full" style={{ backgroundColor: 'var(--color-border)' }}>
                <div
                  className="h-2 rounded-full transition-all"
                  style={{
                    backgroundColor: currentBatch > config.maxConcurrent * 0.8 ? 'var(--color-error)' : 'var(--color-primary)',
                    width: `${(currentBatch / config.maxConcurrent) * 100}%`,
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {metrics.errors.length > 0 && (
        <div
          className="p-6 rounded-lg border"
          style={{
            backgroundColor: 'var(--color-surface)',
            borderColor: 'var(--color-border)',
          }}
        >
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle className="w-5 h-5" style={{ color: 'var(--color-error)' }} />
            <h3 className="text-lg font-semibold" style={{ color: 'var(--color-text)' }}>
              Errors Detected
            </h3>
          </div>
          <div className="space-y-2">
            {metrics.errors.map((error, idx) => (
              <div
                key={idx}
                className="flex justify-between items-center p-3 rounded"
                style={{ backgroundColor: 'var(--color-background)' }}
              >
                <span style={{ color: 'var(--color-text)' }}>{error.message}</span>
                <span
                  className="px-3 py-1 rounded text-sm font-semibold"
                  style={{
                    backgroundColor: 'var(--color-error)',
                    color: 'var(--color-background)',
                  }}
                >
                  {error.count}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
