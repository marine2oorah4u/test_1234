import { ArrowLeft, Cpu, Check, X, Zap, Brain, DollarSign, Globe } from 'lucide-react';
import { useState } from 'react';

interface DemoComparePageProps {
  onBack: () => void;
  onSignUp: () => void;
}

const AI_MODELS = [
  {
    id: 'gpt4',
    name: 'GPT-4',
    provider: 'OpenAI',
    current: true,
    icon: '🤖',
    tagline: 'Industry-leading language model with exceptional reasoning',
    description: 'GPT-4 is OpenAI\'s most advanced system, producing safer and more useful responses. It can solve difficult problems with greater accuracy thanks to its broader general knowledge and advanced reasoning capabilities.',
    specs: {
      contextWindow: '128K tokens (~300 pages)',
      speed: 'Medium (2-5 sec response)',
      training: 'Trained through September 2021',
      multimodal: 'Text + Images (input)',
      costPer1M: '$30 input / $60 output',
      languages: '50+ languages',
    },
    strengths: [
      'Exceptional reasoning and problem-solving',
      'Excellent at following complex instructions',
      'Strong performance on educational content',
      'Reliable factual accuracy',
      'Great for technical documentation',
    ],
    weaknesses: [
      'Higher cost compared to alternatives',
      'Moderate speed',
      'Knowledge cutoff in 2021',
      'Occasional verbosity',
    ],
    bestFor: [
      'Educational content generation',
      'Technical documentation',
      'Complex reasoning tasks',
      'Multi-step problem solving',
    ],
  },
  {
    id: 'claude',
    name: 'Claude 3.5 Sonnet',
    provider: 'Anthropic',
    current: false,
    icon: '🧠',
    tagline: 'Balanced performance with extended context and strong safety',
    description: 'Claude 3.5 Sonnet is Anthropic\'s most intelligent model yet, with significant improvements in coding, multilingual understanding, and visual reasoning. It combines strong performance with industry-leading safety features.',
    specs: {
      contextWindow: '200K tokens (~500 pages)',
      speed: 'Fast (1-3 sec response)',
      training: 'Trained through April 2024',
      multimodal: 'Text + Images + PDFs',
      costPer1M: '$15 input / $75 output',
      languages: '50+ languages',
    },
    strengths: [
      'Massive 200K context window',
      'Excellent at analysis and reasoning',
      'Strong creative writing capabilities',
      'Better knowledge recency (Apr 2024)',
      'Superior safety and alignment',
    ],
    weaknesses: [
      'Less widely adopted than GPT-4',
      'Occasionally more conservative',
      'Output costs can be higher',
    ],
    bestFor: [
      'Long-form content generation',
      'Research and analysis',
      'Creative writing projects',
      'Working with large documents',
    ],
  },
  {
    id: 'gemini',
    name: 'Gemini 1.5 Pro',
    provider: 'Google',
    current: false,
    icon: '✨',
    tagline: 'Massive context window with multimodal capabilities',
    description: 'Gemini 1.5 Pro is Google\'s most capable model, offering breakthrough long-context understanding with the ability to process up to 1 million tokens. It excels at multimodal tasks and has strong multilingual capabilities.',
    specs: {
      contextWindow: '1M tokens (~1,500 pages)',
      speed: 'Very Fast (<1-2 sec response)',
      training: 'Trained through Nov 2023',
      multimodal: 'Text + Images + Audio + Video',
      costPer1M: '$7 input / $21 output',
      languages: '100+ languages',
    },
    strengths: [
      'Unprecedented 1M token context window',
      'Fastest response times',
      'Most cost-effective option',
      'Excellent multilingual support',
      'Strong multimodal capabilities',
    ],
    weaknesses: [
      'Less refined creative writing',
      'Occasional inconsistency',
      'Newer model with less testing',
    ],
    bestFor: [
      'Processing very long documents',
      'Multilingual content',
      'High-volume generation',
      'Budget-conscious projects',
    ],
  },
  {
    id: 'llama',
    name: 'Llama 3.1 (405B)',
    provider: 'Meta',
    current: false,
    icon: '🦙',
    tagline: 'Open-source powerhouse with no API costs',
    description: 'Llama 3.1 is Meta\'s most capable open-source model, rivaling closed-source alternatives in many tasks. It offers full control and customization without API costs, though it requires self-hosting infrastructure.',
    specs: {
      contextWindow: '128K tokens (~300 pages)',
      speed: 'Very Fast (0.5-2 sec response)',
      training: 'Trained through December 2023',
      multimodal: 'Text only (multimodal coming)',
      costPer1M: '$0 (self-hosted)',
      languages: '40+ languages',
    },
    strengths: [
      'Completely open-source',
      'No API costs (self-hosted)',
      'Full control and customization',
      'Strong performance for open model',
      'Active community support',
    ],
    weaknesses: [
      'Requires infrastructure to host',
      'Less capable than leading closed models',
      'Limited multimodal support',
      'More complex to deploy',
    ],
    bestFor: [
      'Self-hosted applications',
      'Custom fine-tuning needs',
      'Privacy-sensitive projects',
      'High-volume cost optimization',
    ],
  },
];

export function DemoComparePage({ onBack, onSignUp }: DemoComparePageProps) {
  const [selectedModel, setSelectedModel] = useState('gpt4');

  const currentModel = AI_MODELS.find(m => m.id === selectedModel) || AI_MODELS[0];

  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--color-background)' }}>
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 px-4 py-2 rounded-lg transition"
            style={{
              backgroundColor: 'var(--color-surface)',
              color: 'var(--color-text)',
            }}
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </button>

          <button
            onClick={onSignUp}
            className="flex items-center gap-2 px-6 py-3 rounded-lg transition font-semibold"
            style={{
              backgroundColor: 'var(--color-primary)',
              color: 'var(--color-background)',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = 'var(--color-primaryHover)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'var(--color-primary)';
            }}
          >
            Request Demo Access
          </button>
        </div>

        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Cpu className="w-10 h-10" style={{ color: 'var(--color-primary)' }} />
            <h1 className="text-4xl font-bold" style={{ color: 'var(--color-text)' }}>
              Behind the Scenes
            </h1>
          </div>
          <p className="text-lg" style={{ color: 'var(--color-textMuted)' }}>
            The AI technology powering your educational content generation
          </p>
        </div>

        <div className="grid md:grid-cols-4 gap-3 mb-12">
          {AI_MODELS.map((model) => (
            <button
              key={model.id}
              onClick={() => setSelectedModel(model.id)}
              className="relative p-4 rounded-xl border transition text-left"
              style={{
                backgroundColor: selectedModel === model.id ? 'var(--color-primary)' : 'var(--color-surface)',
                borderColor: selectedModel === model.id ? 'var(--color-primary)' : model.current ? 'var(--color-accent)' : 'var(--color-border)',
                borderWidth: model.current ? '2px' : '1px',
                color: selectedModel === model.id ? 'var(--color-background)' : 'var(--color-text)',
              }}
            >
              {model.current && (
                <div
                  className="absolute -top-2 -right-2 px-2 py-0.5 rounded-full text-xs font-bold"
                  style={{
                    backgroundColor: 'var(--color-accent)',
                    color: 'var(--color-background)',
                  }}
                >
                  CURRENT
                </div>
              )}
              <div className="text-3xl mb-2">{model.icon}</div>
              <div className="font-bold mb-1">{model.name}</div>
              <div className="text-xs opacity-80">{model.provider}</div>
            </button>
          ))}
        </div>

        <div
          className="rounded-2xl p-8 border mb-8"
          style={{
            backgroundColor: 'var(--color-surface)',
            borderColor: 'var(--color-border)',
          }}
        >
          <div className="flex items-start gap-6 mb-6">
            <div className="text-6xl">{currentModel.icon}</div>
            <div className="flex-1">
              <h2 className="text-3xl font-bold mb-2" style={{ color: 'var(--color-text)' }}>
                {currentModel.name}
              </h2>
              <p className="text-lg mb-4" style={{ color: 'var(--color-primary)' }}>
                {currentModel.tagline}
              </p>
              <p className="text-base leading-relaxed" style={{ color: 'var(--color-textSecondary)' }}>
                {currentModel.description}
              </p>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <div
              className="p-4 rounded-lg"
              style={{
                backgroundColor: 'var(--color-background)',
              }}
            >
              <div className="flex items-center gap-2 mb-2">
                <Brain className="w-5 h-5" style={{ color: 'var(--color-primary)' }} />
                <span className="text-sm font-semibold" style={{ color: 'var(--color-textMuted)' }}>
                  Context Window
                </span>
              </div>
              <p className="font-bold" style={{ color: 'var(--color-text)' }}>
                {currentModel.specs.contextWindow}
              </p>
            </div>

            <div
              className="p-4 rounded-lg"
              style={{
                backgroundColor: 'var(--color-background)',
              }}
            >
              <div className="flex items-center gap-2 mb-2">
                <Zap className="w-5 h-5" style={{ color: 'var(--color-accent)' }} />
                <span className="text-sm font-semibold" style={{ color: 'var(--color-textMuted)' }}>
                  Response Speed
                </span>
              </div>
              <p className="font-bold" style={{ color: 'var(--color-text)' }}>
                {currentModel.specs.speed}
              </p>
            </div>

            <div
              className="p-4 rounded-lg"
              style={{
                backgroundColor: 'var(--color-background)',
              }}
            >
              <div className="flex items-center gap-2 mb-2">
                <DollarSign className="w-5 h-5" style={{ color: 'var(--color-success)' }} />
                <span className="text-sm font-semibold" style={{ color: 'var(--color-textMuted)' }}>
                  Cost per 1M Tokens
                </span>
              </div>
              <p className="font-bold text-sm" style={{ color: 'var(--color-text)' }}>
                {currentModel.specs.costPer1M}
              </p>
            </div>

            <div
              className="p-4 rounded-lg"
              style={{
                backgroundColor: 'var(--color-background)',
              }}
            >
              <div className="flex items-center gap-2 mb-2">
                <Cpu className="w-5 h-5" style={{ color: 'var(--color-secondary)' }} />
                <span className="text-sm font-semibold" style={{ color: 'var(--color-textMuted)' }}>
                  Capabilities
                </span>
              </div>
              <p className="font-bold text-sm" style={{ color: 'var(--color-text)' }}>
                {currentModel.specs.multimodal}
              </p>
            </div>

            <div
              className="p-4 rounded-lg"
              style={{
                backgroundColor: 'var(--color-background)',
              }}
            >
              <div className="flex items-center gap-2 mb-2">
                <Globe className="w-5 h-5" style={{ color: 'var(--color-warning)' }} />
                <span className="text-sm font-semibold" style={{ color: 'var(--color-textMuted)' }}>
                  Languages
                </span>
              </div>
              <p className="font-bold" style={{ color: 'var(--color-text)' }}>
                {currentModel.specs.languages}
              </p>
            </div>

            <div
              className="p-4 rounded-lg"
              style={{
                backgroundColor: 'var(--color-background)',
              }}
            >
              <div className="flex items-center gap-2 mb-2">
                <Cpu className="w-5 h-5" style={{ color: 'var(--color-textMuted)' }} />
                <span className="text-sm font-semibold" style={{ color: 'var(--color-textMuted)' }}>
                  Training Data
                </span>
              </div>
              <p className="font-bold text-sm" style={{ color: 'var(--color-text)' }}>
                {currentModel.specs.training}
              </p>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-bold mb-3 flex items-center gap-2" style={{ color: 'var(--color-text)' }}>
                <Check className="w-5 h-5" style={{ color: 'var(--color-success)' }} />
                Strengths
              </h3>
              <ul className="space-y-2">
                {currentModel.strengths.map((strength, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm">
                    <Check className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: 'var(--color-success)' }} />
                    <span style={{ color: 'var(--color-textSecondary)' }}>{strength}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-bold mb-3 flex items-center gap-2" style={{ color: 'var(--color-text)' }}>
                <X className="w-5 h-5" style={{ color: 'var(--color-error)' }} />
                Limitations
              </h3>
              <ul className="space-y-2">
                {currentModel.weaknesses.map((weakness, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm">
                    <X className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: 'var(--color-error)' }} />
                    <span style={{ color: 'var(--color-textSecondary)' }}>{weakness}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="mt-6 pt-6" style={{ borderTop: '1px solid var(--color-border)' }}>
            <h3 className="text-lg font-bold mb-3" style={{ color: 'var(--color-text)' }}>
              Best Use Cases
            </h3>
            <div className="flex flex-wrap gap-2">
              {currentModel.bestFor.map((useCase, i) => (
                <span
                  key={i}
                  className="px-3 py-1.5 rounded-lg text-sm font-medium"
                  style={{
                    backgroundColor: 'var(--color-background)',
                    color: 'var(--color-primary)',
                    borderWidth: '1px',
                    borderStyle: 'solid',
                    borderColor: 'var(--color-primary)',
                  }}
                >
                  {useCase}
                </span>
              ))}
            </div>
          </div>
        </div>

        <div
          className="rounded-2xl p-8 text-center"
          style={{
            background: `linear-gradient(135deg, var(--color-surface), var(--color-surfaceHover))`,
            borderWidth: '2px',
            borderStyle: 'solid',
            borderColor: 'var(--color-primary)',
          }}
        >
          <Cpu className="w-12 h-12 mx-auto mb-4" style={{ color: 'var(--color-primary)' }} />
          <h2 className="text-2xl font-bold mb-3" style={{ color: 'var(--color-text)' }}>
            Multi-Model AI Approach
          </h2>
          <p className="text-base mb-6 max-w-2xl mx-auto" style={{ color: 'var(--color-textMuted)' }}>
            We leverage multiple AI models to provide the best content generation experience. Each model is selected based on its strengths for specific content types and tasks.
          </p>
          <button
            onClick={onSignUp}
            className="px-8 py-3 rounded-lg font-bold transition"
            style={{
              backgroundColor: 'var(--color-primary)',
              color: 'var(--color-background)',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = 'var(--color-primaryHover)';
              e.currentTarget.style.transform = 'scale(1.05)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'var(--color-primary)';
              e.currentTarget.style.transform = 'scale(1)';
            }}
          >
            Request Demo Access
          </button>
        </div>
      </div>
    </div>
  );
}
