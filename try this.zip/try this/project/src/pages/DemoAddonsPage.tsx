import { useState } from 'react';
import { ArrowLeft, Package, ChevronRight } from 'lucide-react';
import { ADDON_TYPES, ALL_ADDON_TYPES } from '../config/addons';
import { BackToAdminButton } from '../components/BackToAdminButton';

interface DemoAddonsPageProps {
  onBack: () => void;
  onNavigate?: (page: string) => void;
}

const CORE_ADDONS = ALL_ADDON_TYPES.map(type => ADDON_TYPES[type]);

const ADDON_DETAILS: Record<string, {
  purpose: string;
  howUsed: string;
  whoBenefits: string;
  examples: string[];
}> = {
  'activity-packs': {
    purpose: 'Hands-on learning activities that reinforce concepts through practical application and engagement.',
    howUsed: 'Teachers assign activities as in-class work or homework. Students complete activities to practice and apply what they learned.',
    whoBenefits: 'Teachers seeking engaging classroom activities, students who learn by doing, homeschool parents',
    examples: [
      'Science experiments with step-by-step instructions',
      'Math problem-solving challenges',
      'Historical event timeline creation',
      'Creative writing prompts',
      'Art and craft projects',
      'Group discussion activities'
    ]
  },
  'worksheets': {
    purpose: 'Practice sheets with exercises that help students master concepts through repetition and application.',
    howUsed: 'Used for independent practice, homework assignments, or classroom assessments. Students complete exercises to reinforce learning.',
    whoBenefits: 'Teachers needing ready-made practice materials, students requiring additional practice, tutors',
    examples: [
      'Fill-in-the-blank exercises',
      'Multiple choice questions',
      'Short answer problems',
      'Diagram labeling activities',
      'Matching exercises',
      'Problem-solving scenarios'
    ]
  },
  'quizzes': {
    purpose: 'Assessment tools to measure understanding and identify areas needing more attention.',
    howUsed: 'Given as formative assessments during learning or summative assessments after completing topics.',
    whoBenefits: 'Teachers for progress monitoring, students for self-assessment, parents tracking learning',
    examples: [
      'Chapter review quizzes',
      'Unit assessments',
      'Quick comprehension checks',
      'Vocabulary tests',
      'Concept application questions',
      'Mixed review assessments'
    ]
  },
  'answer-keys': {
    purpose: 'Complete solutions that enable self-checking, independent learning, and efficient grading.',
    howUsed: 'Teachers use for quick grading. Students use for self-correction and understanding mistakes.',
    whoBenefits: 'Teachers saving grading time, students learning from mistakes, homeschool parents',
    examples: [
      'Step-by-step solutions',
      'Explanation of correct answers',
      'Common mistakes highlighted',
      'Alternative solution methods',
      'Grading rubrics',
      'Point allocation guides'
    ]
  },
  'lesson-plans': {
    purpose: 'Structured teaching guides that help educators deliver effective, organized instruction.',
    howUsed: 'Teachers follow lesson plans to structure class time, introduce concepts, and guide activities.',
    whoBenefits: 'Teachers planning instruction, substitute teachers, new educators, homeschool parents',
    examples: [
      'Learning objectives and goals',
      'Step-by-step teaching sequence',
      'Discussion questions',
      'Activity instructions',
      'Time allocations',
      'Assessment strategies'
    ]
  },
  'presentation-slides': {
    purpose: 'Visual teaching aids that enhance presentations and keep students engaged during lessons.',
    howUsed: 'Displayed during instruction to illustrate concepts, show examples, and guide discussions.',
    whoBenefits: 'Teachers presenting material, students reviewing content, remote learning educators',
    examples: [
      'Key concept slides with visuals',
      'Example problems with solutions',
      'Discussion prompts',
      'Summary slides',
      'Interactive review questions',
      'Visual diagrams and charts'
    ]
  },
  'study-guides': {
    purpose: 'Comprehensive review materials that summarize key concepts for efficient studying and test preparation.',
    howUsed: 'Students use for review before tests. Teachers provide as study materials. Parents use to help with homework.',
    whoBenefits: 'Students preparing for exams, parents helping with homework, tutors planning sessions',
    examples: [
      'Chapter summaries',
      'Key vocabulary lists',
      'Important formulas and rules',
      'Concept maps',
      'Practice questions',
      'Review tips and strategies'
    ]
  },
  'career-guides': {
    purpose: 'Career exploration materials connecting academic content to real-world professions and applications.',
    howUsed: 'Used in career education, guidance counseling, and to show students practical applications of their learning.',
    whoBenefits: 'Students exploring careers, guidance counselors, vocational educators, parents discussing future plans',
    examples: [
      'Related career paths and descriptions',
      'Required education and skills',
      'Day-in-the-life scenarios',
      'Industry insights',
      'Salary and job outlook information',
      'How subject applies to careers'
    ]
  }
};

export function DemoAddonsPage({ onBack, onNavigate }: DemoAddonsPageProps) {
  const [selectedAddon, setSelectedAddon] = useState<string | null>(null);
  const selected = selectedAddon ? CORE_ADDONS.find(a => a.id === selectedAddon) : null;
  const details = selectedAddon ? ADDON_DETAILS[selectedAddon] : null;

  if (selected && details) {
    return (
      <div className="min-h-screen" style={{ backgroundColor: 'var(--color-background)' }}>
        {onNavigate && <BackToAdminButton onNavigate={onNavigate} />}
        <div className="max-w-5xl mx-auto px-6 py-8">
          <div className="flex items-center mb-8">
            <button
              onClick={() => setSelectedAddon(null)}
              className="flex items-center gap-2 px-4 py-2 rounded-lg transition"
              style={{
                backgroundColor: 'var(--color-surface)',
                color: 'var(--color-text)',
              }}
            >
              <ArrowLeft className="w-5 h-5" />
              Back to Add-ons
            </button>
          </div>

          <div
            className="rounded-2xl p-8 mb-8"
            style={{
              backgroundColor: 'var(--color-surface)',
              borderWidth: '2px',
              borderStyle: 'solid',
              borderColor: 'var(--color-primary)',
            }}
          >
            <div className="flex items-start gap-4 mb-6">
              <div className="text-6xl">{selected.icon}</div>
              <div>
                <h1 className="text-3xl font-bold mb-2" style={{ color: 'var(--color-text)' }}>
                  {selected.name}
                </h1>
                <p className="text-lg" style={{ color: 'var(--color-textMuted)' }}>
                  {selected.description}
                </p>
              </div>
            </div>

            <div className="space-y-6">
              <div
                className="rounded-lg p-5"
                style={{
                  backgroundColor: 'var(--color-background)',
                  borderWidth: '1px',
                  borderStyle: 'solid',
                  borderColor: 'var(--color-border)',
                }}
              >
                <h3 className="text-lg font-bold mb-3" style={{ color: 'var(--color-primary)' }}>
                  Purpose
                </h3>
                <p className="text-sm" style={{ color: 'var(--color-textSecondary)' }}>
                  {details.purpose}
                </p>
              </div>

              <div
                className="rounded-lg p-5"
                style={{
                  backgroundColor: 'var(--color-background)',
                  borderWidth: '1px',
                  borderStyle: 'solid',
                  borderColor: 'var(--color-border)',
                }}
              >
                <h3 className="text-lg font-bold mb-3" style={{ color: 'var(--color-accent)' }}>
                  How It's Used
                </h3>
                <p className="text-sm" style={{ color: 'var(--color-textSecondary)' }}>
                  {details.howUsed}
                </p>
              </div>

              <div
                className="rounded-lg p-5"
                style={{
                  backgroundColor: 'var(--color-background)',
                  borderWidth: '1px',
                  borderStyle: 'solid',
                  borderColor: 'var(--color-border)',
                }}
              >
                <h3 className="text-lg font-bold mb-3" style={{ color: 'var(--color-success)' }}>
                  Who Benefits
                </h3>
                <p className="text-sm" style={{ color: 'var(--color-textSecondary)' }}>
                  {details.whoBenefits}
                </p>
              </div>

              <div
                className="rounded-lg p-5"
                style={{
                  backgroundColor: 'var(--color-background)',
                  borderWidth: '1px',
                  borderStyle: 'solid',
                  borderColor: 'var(--color-border)',
                }}
              >
                <h3 className="text-lg font-bold mb-3" style={{ color: 'var(--color-text)' }}>
                  What's Included
                </h3>
                <ul className="space-y-2">
                  {selected.features.map((feature: string, idx: number) => (
                    <li key={idx} className="flex items-start gap-2 text-sm">
                      <span style={{ color: 'var(--color-primary)' }}>•</span>
                      <span style={{ color: 'var(--color-textSecondary)' }}>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div
                className="rounded-lg p-5"
                style={{
                  backgroundColor: 'var(--color-background)',
                  borderWidth: '1px',
                  borderStyle: 'solid',
                  borderColor: 'var(--color-border)',
                }}
              >
                <h3 className="text-lg font-bold mb-3" style={{ color: 'var(--color-secondary)' }}>
                  Examples
                </h3>
                <ul className="space-y-2">
                  {details.examples.map((example, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-sm">
                      <span style={{ color: 'var(--color-primary)' }}>•</span>
                      <span style={{ color: 'var(--color-textSecondary)' }}>{example}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--color-background)' }}>
      {onNavigate && <BackToAdminButton onNavigate={onNavigate} />}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex items-center mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 px-4 py-2 rounded-lg transition"
            style={{
              backgroundColor: 'var(--color-surface)',
              color: 'var(--color-text)',
            }}
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </button>
        </div>

        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Package className="w-10 h-10" style={{ color: 'var(--color-accent)' }} />
            <h1 className="text-4xl font-bold" style={{ color: 'var(--color-text)' }}>
              Educational Add-ons
            </h1>
          </div>
          <p className="text-lg" style={{ color: 'var(--color-textMuted)' }}>
            8 educational supplements generated for each reading level
          </p>
          <p className="text-sm mt-2" style={{ color: 'var(--color-textSecondary)' }}>
            Click on any add-on to view detailed information
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {CORE_ADDONS.map((addon) => (
            <button
              key={addon.id}
              onClick={() => setSelectedAddon(addon.id)}
              className="rounded-xl p-6 border transition text-left"
              style={{
                backgroundColor: 'var(--color-surface)',
                borderColor: 'var(--color-border)',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-4px)';
                e.currentTarget.style.borderColor = 'var(--color-primary)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.borderColor = 'var(--color-border)';
              }}
            >
              <div className="text-4xl mb-4">{addon.icon}</div>

              <h3 className="text-xl font-bold mb-2" style={{ color: 'var(--color-text)' }}>
                {addon.name}
              </h3>

              <p className="text-sm mb-4" style={{ color: 'var(--color-textMuted)' }}>
                {addon.description}
              </p>

              <div className="flex items-center gap-2 text-sm font-semibold" style={{ color: 'var(--color-primary)' }}>
                View Details
                <ChevronRight className="w-4 h-4" />
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
