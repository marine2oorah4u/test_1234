import { ArrowLeft, Target, Zap, Rocket } from 'lucide-react';

interface DemoRoadmapPageProps {
  onBack: () => void;
}

const TIER_1_GOALS = [
  'Create a comprehensive educational content generation system',
  'Generate books for 24 subject areas at 8 reading levels each',
  'Provide 8 educational supplements per book (worksheets, quizzes, lesson plans, etc.)',
  'Make content accessible with 40 disability-specific adaptations',
  'Support multiple formats (PDF, EPUB, Audio, Braille, etc.)',
  'Enable translation to 100+ languages',
  'Build a scalable, automated generation pipeline',
  'Ensure quality and accuracy through validation systems',
];

const TIER_2_FIRST_GRANT = [
  'Set up AI API access (OpenAI, Anthropic, Google)',
  'Implement core content generation for 1-3 subject groups',
  'Build basic add-on generation (worksheets, quizzes, answer keys)',
  'Create PDF and EPUB format conversion',
  'Develop audio synthesis for audiobooks',
  'Set up cloud storage and database infrastructure',
  'Build quality validation and review system',
  'Generate first 50-100 books as proof of concept',
  'Test with small group of educators and students',
  'Gather feedback and iterate on quality',
];

const TIER_3_FULL_IMPLEMENTATION = [
  'Expand to all 24 subject groups',
  'Complete all 8 educational add-on types',
  'Implement full disability adaptation system (40 profiles)',
  'Add image generation for illustrations and diagrams',
  'Build multi-language translation pipeline',
  'Create interactive web-based learning platform',
  'Develop video content generation from books',
  'Add professional textbook design and formatting',
  'Build educator collaboration and customization tools',
  'Create student progress tracking and analytics',
  'Establish content review and update system',
  'Scale infrastructure for thousands of books',
];

export function DemoRoadmapPage({ onBack }: DemoRoadmapPageProps) {
  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--color-background)' }}>
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex items-center mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 px-4 py-2 rounded-lg transition"
            style={{
              backgroundColor: 'var(--color-surface)',
              color: 'var(--color-text)',
            }}
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </button>
        </div>

        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Rocket className="w-10 h-10" style={{ color: 'var(--color-primary)' }} />
            <h1 className="text-4xl font-bold" style={{ color: 'var(--color-text)' }}>
              Development Roadmap
            </h1>
          </div>
          <p className="text-lg max-w-3xl mx-auto" style={{ color: 'var(--color-textMuted)' }}>
            Implementation plan from initial goals to full system
          </p>
        </div>

        <div className="space-y-8">
          <div
            className="rounded-2xl p-8 border-2"
            style={{
              backgroundColor: 'var(--color-surface)',
              borderColor: 'var(--color-primary)',
            }}
          >
            <div className="flex items-center gap-3 mb-6">
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center"
                style={{
                  backgroundColor: 'var(--color-primary)',
                  color: 'var(--color-background)',
                }}
              >
                <Target className="w-7 h-7" />
              </div>
              <div>
                <h2 className="text-2xl font-bold" style={{ color: 'var(--color-text)' }}>
                  Tier 1: Overall Goals
                </h2>
                <p className="text-sm" style={{ color: 'var(--color-textSecondary)' }}>
                  What the system aims to accomplish
                </p>
              </div>
            </div>
            <ul className="space-y-3">
              {TIER_1_GOALS.map((item, i) => (
                <li key={i} className="flex items-start gap-3">
                  <span
                    className="flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold mt-0.5"
                    style={{
                      backgroundColor: 'var(--color-primary)',
                      color: 'var(--color-background)',
                    }}
                  >
                    {i + 1}
                  </span>
                  <span style={{ color: 'var(--color-textSecondary)' }}>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          <div
            className="rounded-2xl p-8 border-2"
            style={{
              backgroundColor: 'var(--color-surface)',
              borderColor: 'var(--color-accent)',
            }}
          >
            <div className="flex items-center gap-3 mb-6">
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center"
                style={{
                  backgroundColor: 'var(--color-accent)',
                  color: 'var(--color-background)',
                }}
              >
                <Zap className="w-7 h-7" />
              </div>
              <div>
                <h2 className="text-2xl font-bold" style={{ color: 'var(--color-text)' }}>
                  Tier 2: First Grant Implementation
                </h2>
                <p className="text-sm" style={{ color: 'var(--color-textSecondary)' }}>
                  Initial development with first funding
                </p>
              </div>
            </div>
            <ul className="space-y-3">
              {TIER_2_FIRST_GRANT.map((item, i) => (
                <li key={i} className="flex items-start gap-3">
                  <span
                    className="flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold mt-0.5"
                    style={{
                      backgroundColor: 'var(--color-accent)',
                      color: 'var(--color-background)',
                    }}
                  >
                    {i + 1}
                  </span>
                  <span style={{ color: 'var(--color-textSecondary)' }}>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          <div
            className="rounded-2xl p-8 border-2"
            style={{
              backgroundColor: 'var(--color-surface)',
              borderColor: 'var(--color-secondary)',
            }}
          >
            <div className="flex items-center gap-3 mb-6">
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center"
                style={{
                  backgroundColor: 'var(--color-secondary)',
                  color: 'var(--color-background)',
                }}
              >
                <Rocket className="w-7 h-7" />
              </div>
              <div>
                <h2 className="text-2xl font-bold" style={{ color: 'var(--color-text)' }}>
                  Tier 3: Full System Implementation
                </h2>
                <p className="text-sm" style={{ color: 'var(--color-textSecondary)' }}>
                  Complete platform with all features
                </p>
              </div>
            </div>
            <ul className="space-y-3">
              {TIER_3_FULL_IMPLEMENTATION.map((item, i) => (
                <li key={i} className="flex items-start gap-3">
                  <span
                    className="flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold mt-0.5"
                    style={{
                      backgroundColor: 'var(--color-secondary)',
                      color: 'var(--color-background)',
                    }}
                  >
                    {i + 1}
                  </span>
                  <span style={{ color: 'var(--color-textSecondary)' }}>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div
          className="rounded-2xl p-8 mt-12"
          style={{
            backgroundColor: 'var(--color-surface)',
            borderWidth: '1px',
            borderStyle: 'solid',
            borderColor: 'var(--color-border)',
          }}
        >
          <h2 className="text-2xl font-bold mb-6 text-center" style={{ color: 'var(--color-text)' }}>
            Implementation Approach
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-5xl font-bold mb-2" style={{ color: 'var(--color-primary)' }}>
                Phase 1
              </div>
              <div className="text-sm font-semibold mb-2" style={{ color: 'var(--color-text)' }}>
                Proof of Concept
              </div>
              <p className="text-xs" style={{ color: 'var(--color-textSecondary)' }}>
                Demonstrate core generation capability with 1-3 subject groups and basic features
              </p>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold mb-2" style={{ color: 'var(--color-accent)' }}>
                Phase 2
              </div>
              <div className="text-sm font-semibold mb-2" style={{ color: 'var(--color-text)' }}>
                Expansion
              </div>
              <p className="text-xs" style={{ color: 'var(--color-textSecondary)' }}>
                Add more subject groups, improve quality, gather feedback, and refine the system
              </p>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold mb-2" style={{ color: 'var(--color-secondary)' }}>
                Phase 3
              </div>
              <div className="text-sm font-semibold mb-2" style={{ color: 'var(--color-text)' }}>
                Full Scale
              </div>
              <p className="text-xs" style={{ color: 'var(--color-textSecondary)' }}>
                Complete all 24 subject groups, advanced features, and full accessibility support
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
