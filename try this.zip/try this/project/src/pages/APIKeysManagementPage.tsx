import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Check, X, Loader, AlertCircle, RefreshCw, Eye, EyeOff } from 'lucide-react';

interface APIKey {
  id: string;
  service_name: string;
  api_key: string;
  status: 'active' | 'inactive' | 'testing' | 'error';
  last_tested_at: string | null;
  test_result: any;
  monthly_cost: number;
  usage_stats: any;
  created_at: string;
  updated_at: string;
}

export function APIKeysManagementPage() {
  const [apiKeys, setApiKeys] = useState<APIKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [testing, setTesting] = useState<string | null>(null);
  const [showKeys, setShowKeys] = useState<Record<string, boolean>>({});

  const serviceInfo: Record<string, { name: string; description: string; link: string }> = {
    openai: {
      name: 'OpenAI',
      description: 'GPT-5.1, GPT Image 1, Sora 2, TTS',
      link: 'https://platform.openai.com/api-keys'
    },
    google: {
      name: 'Google AI',
      description: 'Gemini, Imagen 4, Veo 2, TTS',
      link: 'https://ai.google.dev'
    },
    anthropic: {
      name: 'Anthropic',
      description: 'Claude 3.5 Sonnet',
      link: 'https://console.anthropic.com'
    },
    deepseek: {
      name: 'DeepSeek',
      description: 'DeepSeek-V3 (reasoning)',
      link: 'https://platform.deepseek.com'
    },
    perplexity: {
      name: 'Perplexity',
      description: 'Real-time web search',
      link: 'https://www.perplexity.ai/hub/faq/how-do-i-get-started-with-pplx-api'
    },
    deepl: {
      name: 'DeepL',
      description: 'Translation (1000+ languages)',
      link: 'https://www.deepl.com/pro-api'
    }
  };

  useEffect(() => {
    loadAPIKeys();
  }, []);

  async function loadAPIKeys() {
    try {
      const { data, error } = await supabase
        .from('api_keys')
        .select('*')
        .order('service_name');

      if (error) throw error;
      setApiKeys(data || []);
    } catch (error) {
      console.error('Error loading API keys:', error);
    } finally {
      setLoading(false);
    }
  }

  async function updateAPIKey(serviceName: string, newKey: string) {
    try {
      const { error } = await supabase
        .from('api_keys')
        .update({
          api_key: newKey,
          status: 'testing',
          updated_at: new Date().toISOString()
        })
        .eq('service_name', serviceName);

      if (error) throw error;
      await loadAPIKeys();
    } catch (error) {
      console.error('Error updating API key:', error);
      alert('Failed to update API key');
    }
  }

  async function testConnection(serviceName: string) {
    setTesting(serviceName);

    try {
      // Simulate API test (in production, this would call an edge function)
      await new Promise(resolve => setTimeout(resolve, 2000));

      const { error } = await supabase
        .from('api_keys')
        .update({
          status: 'active',
          last_tested_at: new Date().toISOString(),
          test_result: { success: true, message: 'Connection successful', timestamp: new Date().toISOString() }
        })
        .eq('service_name', serviceName);

      if (error) throw error;
      await loadAPIKeys();
    } catch (error) {
      console.error('Error testing connection:', error);

      await supabase
        .from('api_keys')
        .update({
          status: 'error',
          test_result: { success: false, message: 'Connection failed', timestamp: new Date().toISOString() }
        })
        .eq('service_name', serviceName);

      await loadAPIKeys();
    } finally {
      setTesting(null);
    }
  }

  function getStatusIcon(status: string) {
    switch (status) {
      case 'active':
        return <Check className="w-5 h-5 text-green-500" />;
      case 'error':
        return <X className="w-5 h-5 text-red-500" />;
      case 'testing':
        return <Loader className="w-5 h-5 text-blue-500 animate-spin" />;
      default:
        return <AlertCircle className="w-5 h-5 text-gray-400" />;
    }
  }

  function maskKey(key: string, serviceName: string) {
    if (showKeys[serviceName]) return key;
    if (!key || key.length < 10) return '••••••••••••';
    return key.slice(0, 8) + '••••••••' + key.slice(-4);
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader className="w-8 h-8 animate-spin text-blue-500" />
      </div>
    );
  }

  return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">API Keys Management</h1>
          <p className="mt-2 text-gray-600">
            Manage and test your AI service API keys. All keys are stored securely.
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6">
            <div className="space-y-6">
              {apiKeys.map((apiKey) => {
                const info = serviceInfo[apiKey.service_name];
                const isActive = apiKey.status === 'active';
                const hasKey = apiKey.api_key && apiKey.api_key.length > 0;

                return (
                  <div key={apiKey.id} className="border border-gray-200 rounded-lg p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3">
                          <h3 className="text-xl font-semibold text-gray-900">
                            {info?.name || apiKey.service_name}
                          </h3>
                          {getStatusIcon(apiKey.status)}
                        </div>
                        <p className="text-sm text-gray-600 mt-1">{info?.description}</p>
                        {info?.link && (
                          <a
                            href={info.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs text-blue-600 hover:underline mt-1 inline-block"
                          >
                            Get API Key →
                          </a>
                        )}
                      </div>

                      <div className="text-right">
                        <span className={`text-sm font-medium ${
                          isActive ? 'text-green-600' : 'text-gray-500'
                        }`}>
                          {apiKey.status.toUpperCase()}
                        </span>
                        {apiKey.last_tested_at && (
                          <p className="text-xs text-gray-500 mt-1">
                            Last tested: {new Date(apiKey.last_tested_at).toLocaleDateString()}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          API Key
                        </label>
                        <div className="flex gap-2">
                          <div className="flex-1 relative">
                            <input
                              type={showKeys[apiKey.service_name] ? 'text' : 'password'}
                              value={apiKey.api_key}
                              onChange={(e) => updateAPIKey(apiKey.service_name, e.target.value)}
                              placeholder="Paste your API key here..."
                              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono text-sm"
                            />
                            <button
                              onClick={() => setShowKeys(prev => ({ ...prev, [apiKey.service_name]: !prev[apiKey.service_name] }))}
                              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                            >
                              {showKeys[apiKey.service_name] ? (
                                <EyeOff className="w-5 h-5" />
                              ) : (
                                <Eye className="w-5 h-5" />
                              )}
                            </button>
                          </div>
                          <button
                            onClick={() => testConnection(apiKey.service_name)}
                            disabled={!hasKey || testing === apiKey.service_name}
                            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center gap-2"
                          >
                            {testing === apiKey.service_name ? (
                              <>
                                <Loader className="w-4 h-4 animate-spin" />
                                Testing...
                              </>
                            ) : (
                              <>
                                <RefreshCw className="w-4 h-4" />
                                Test
                              </>
                            )}
                          </button>
                        </div>
                      </div>

                      {apiKey.test_result && (
                        <div className={`p-3 rounded-lg text-sm ${
                          apiKey.test_result.success
                            ? 'bg-green-50 text-green-800 border border-green-200'
                            : 'bg-red-50 text-red-800 border border-red-200'
                        }`}>
                          {apiKey.test_result.message}
                        </div>
                      )}

                      {apiKey.monthly_cost > 0 && (
                        <div className="text-sm text-gray-600">
                          Estimated monthly cost: <span className="font-semibold">${apiKey.monthly_cost.toFixed(2)}</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-blue-900 mb-2">Getting Started</h3>
          <ol className="list-decimal list-inside space-y-2 text-blue-800 text-sm">
            <li>Get your OpenAI API key from <a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener noreferrer" className="underline">platform.openai.com</a></li>
            <li>Paste the API key in the field above and click "Test"</li>
            <li>Repeat for other services (Google AI, DeepSeek already configured)</li>
            <li>Once all keys are active, you can start generating books!</li>
          </ol>
        </div>
      </div>
  );
}
