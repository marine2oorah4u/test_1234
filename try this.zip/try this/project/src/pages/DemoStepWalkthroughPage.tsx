import { useState } from 'react';
import { ArrowLeft, ArrowRight, Check, Shield } from 'lucide-react';
import { BackToAdminButton } from '../components/BackToAdminButton';

interface DemoStepWalkthroughPageProps {
  onBack: () => void;
  onNavigate?: (page: string) => void;
}

interface Step {
  id: number;
  title: string;
  description: string;
  why: string;
  how: string;
  who: string;
  technicalDetails: string[];
  qualityChecks: string[];
  outputs: string[];
}

const GENERATION_STEPS: Step[] = [
  {
    id: 1,
    title: 'Content Generation',
    description: 'Generate base educational content at multiple reading levels',
    why: 'Different learners need content at appropriate complexity levels to effectively learn. A kindergartener cannot use the same textbook as a graduate student. Each reading level needs vocabulary, sentence structure, and concepts matched to that age group. This ensures comprehension and engagement at every level.',
    how: 'AI models analyze the topic and generate content tailored to each reading level. For a topic like "Photosynthesis," the kindergarten version uses simple words and basic concepts ("Plants make food from sunlight"), while the PhD version includes detailed biochemical pathways and research applications. The AI adjusts vocabulary, sentence complexity, example difficulty, and concept depth for each level.',
    who: 'Students of all ages benefit - from young children (ages 5-6) learning foundational concepts, to elementary students (7-11) building on basics, middle and high school students (12-18) preparing for college, undergraduate and graduate students deepening expertise, PhD candidates conducting research, and professionals needing reference materials in their field.',
    technicalDetails: [
      'AI analyzes target reading level requirements (Flesch-Kincaid, Lexile measures)',
      'Vocabulary selected from age-appropriate word lists',
      'Sentence structure adjusted for complexity (simple → compound → complex)',
      'Concepts introduced progressively with appropriate prerequisites',
      'Examples matched to life experience of target age group',
      'Visual aids and formatting adapted to reading level',
      'Length and chapter structure scaled appropriately',
      'Cross-references and supplementary material tailored to level'
    ],
    qualityChecks: [
      'Reading level verification using multiple algorithms',
      'Vocabulary appropriateness checked against grade-level lists',
      'Concept progression validated for logical flow',
      'Fact-checking against authoritative sources',
      'Consistency in terminology and definitions across chapters',
      'Age-appropriateness of examples and scenarios',
      'Alignment with educational standards for that grade level'
    ],
    outputs: [
      '8 complete books at different reading levels (Kindergarten through Professional)',
      'Each book fully self-contained with appropriate detail for that level',
      'Age-appropriate vocabulary and sentence structure',
      'Progressive complexity scaling from basic to advanced',
      'Aligned learning objectives per level',
      'Appropriate chapter length and structure for age group',
      'Examples relevant to target age group life experience',
      'Supplementary explanations where needed for that level'
    ]
  },
  {
    id: 2,
    title: 'Educational Supplements',
    description: 'Create supporting materials for each book at each reading level',
    why: 'Reading alone is not sufficient for learning. Students need practice exercises to reinforce concepts, assessments to measure understanding, and varied activities to engage different learning styles. Teachers need ready-to-use materials to save preparation time. Research shows that varied practice and active learning significantly improve retention and understanding.',
    how: 'For each of the 8 books generated, AI creates 8 different supplement types. Each supplement is tailored to the reading level of its book. Elementary worksheets use simple questions and visual aids; high school quizzes test deeper understanding; college-level study guides include complex applications. The AI ensures supplements align with the book content and reinforce key concepts through varied activities.',
    who: 'Teachers benefit from ready-made lesson materials saving hours of preparation time. Students get structured practice matching their level. Homeschool parents receive complete educational packages. Tutors have assessment tools to identify gaps. Students can self-study with answer keys for independent learning. Special education teachers get appropriately leveled materials.',
    technicalDetails: [
      'Activity packs: 10-15 hands-on activities per book (experiments, projects, creative tasks)',
      'Worksheets: 20-30 pages of exercises with varied question types',
      'Quizzes: 5-10 assessments covering each major topic',
      'Answer keys: Complete solutions with explanations',
      'Study guides: Chapter summaries, key terms, review questions',
      'Visual guides: Diagrams, flowcharts, infographics explaining concepts',
      'Video scripts: 8-12 video lesson scripts with visual cues',
      'Lesson plans: 10-15 detailed lesson plans with objectives, activities, assessments'
    ],
    qualityChecks: [
      'Supplements align with book content and learning objectives',
      'Question difficulty matches book reading level',
      'Answer keys verified for accuracy',
      'Activities are age-appropriate and achievable',
      'Assessment questions cover all key concepts',
      'Materials are practical for classroom use',
      'Time estimates for activities are realistic'
    ],
    outputs: [
      '64 total supplement packages (8 supplements × 8 reading levels)',
      'Activity packs with hands-on exercises and projects',
      'Worksheet sets for practice and homework',
      'Quiz packs with assessment questions and rubrics',
      'Complete answer keys with step-by-step solutions',
      'Study guides with summaries and review questions',
      'Visual guides with diagrams and concept maps',
      'Video scripts for creating video lessons',
      'Lesson plans with objectives, procedures, and assessments'
    ]
  },
  {
    id: 3,
    title: 'Format Conversion',
    description: 'Convert all content into multiple accessible formats',
    why: 'People consume content in different ways based on device preference, accessibility needs, and usage context. A student might read PDF on laptop, EPUB on tablet, listen to audiobook while commuting, and use large print if visually impaired. Providing multiple formats ensures everyone can access the content in their preferred way. No single format works for everyone.',
    how: 'Automated conversion tools transform the base content into each format while maintaining quality and proper formatting. PDF conversion preserves layout and pagination. EPUB conversion creates reflowable text optimized for e-readers. Audiobook synthesis uses natural-sounding AI voices with proper pronunciation and pacing. Braille conversion follows Grade 2 Braille standards. Each format is optimized for its intended use case.',
    who: 'Print readers use PDFs for studying with notes. E-reader users prefer EPUB for portable reading. Audiobook listeners include commuters, visually impaired students, and auditory learners. Students with low vision need large print. Blind students use Braille. Teachers want DOCX for customization. Online learners use interactive HTML. Binder users organize printed materials.',
    technicalDetails: [
      'PDF: Print-optimized layout with proper pagination, headers, page numbers',
      'EPUB: Reflowable text with proper metadata, table of contents, bookmarks',
      'Audiobook: MP3 files with chapter markers, proper pacing, natural voices',
      'Large print: 18-24pt font with high contrast and clear formatting',
      'Braille: Grade 2 Braille with proper contractions and formatting codes',
      'Interactive HTML: Responsive web format with navigation, search, bookmarks',
      'DOCX: Editable format with styles, formatting, and structure preserved',
      'Binder format: 3-hole punch margins, section dividers, indexing'
    ],
    qualityChecks: [
      'All formats tested on target devices/software',
      'Text formatting and structure preserved across formats',
      'Images and diagrams properly embedded and sized',
      'Audiobook pronunciation verified for technical terms',
      'Braille conversion checked for accuracy',
      'EPUB validates against EPUB standards',
      'PDF renders correctly at different zoom levels',
      'File sizes optimized for distribution'
    ],
    outputs: [
      '80 format variants per book (8 reading levels × 10 formats)',
      'PDF for print and digital reading with proper layout',
      'EPUB for e-readers and tablets with reflowable text',
      'Audiobook with professional AI narration and pacing',
      'Large print editions for visual accessibility',
      'Braille files for blind readers',
      'Interactive HTML for web browsers',
      'DOCX files for educator customization',
      'Binder-ready formats with proper margins',
      'Mobile-optimized versions for smartphones',
      'Accessible formats meeting WCAG standards'
    ]
  },
  {
    id: 4,
    title: 'Disability Adaptations',
    description: 'Create specialized versions for 40 specific disability profiles',
    why: 'Standard educational materials often fail students with disabilities. A student with autism may struggle with abstract language. ADHD students need content broken into smaller chunks. Dyslexic students benefit from specific fonts and spacing. Visual impairments require high contrast. Each disability has specific accommodation needs based on research and best practices. One-size-fits-all does not work for accessibility.',
    how: 'Content is modified with research-based accommodations for each disability. Autism adaptations add visual supports, concrete examples, and predictable structure. ADHD versions use shorter sections, frequent summaries, and attention-grabbing elements. Dyslexia modifications use OpenDyslexic font, wider spacing, and avoid similar-looking letters. Each adaptation follows evidence-based practices for that specific condition.',
    who: 'Students with autism spectrum disorder who need visual structure and concrete explanations. ADHD students who struggle with focus and need frequent breaks. Dyslexic students who need specialized typography. Students with visual impairments needing high contrast. Deaf students who need visual-based content. Students with cognitive disabilities needing simplified language. Students with physical disabilities needing accessible digital formats. And 33 more disability profiles.',
    technicalDetails: [
      'Autism: Visual schedules, social stories, concrete examples, predictable structure',
      'ADHD: Chunked content, frequent summaries, attention cues, minimal distractions',
      'Dyslexia: OpenDyslexic font, 1.5-2x line spacing, cream background, phonetic guides',
      'Visual impairment: High contrast (4.5:1 minimum), large text, screen reader optimization',
      'Hearing impairment: All audio transcribed, visual alerts, video captions',
      'Cognitive disabilities: Simplified language, step-by-step instructions, memory aids',
      'Physical disabilities: Keyboard navigation, voice control support, switch access',
      'Anxiety disorders: Calming colors, positive reinforcement, stress-reduction techniques',
      'And 32 more specialized adaptations for specific conditions'
    ],
    qualityChecks: [
      'Adaptations follow research-based best practices',
      'Accessibility features tested with assistive technology',
      'Content readability verified for target disability',
      'Visual elements appropriately modified or described',
      'Interactive elements work with accessibility tools',
      'Compliance with ADA and Section 508 standards',
      'Review by special education professionals (when possible)'
    ],
    outputs: [
      '320 adapted versions per book (8 levels × 40 disability profiles)',
      'Autism-adapted versions with visual supports',
      'ADHD-friendly versions with chunked content',
      'Dyslexia-optimized typography and formatting',
      'High-contrast versions for low vision',
      'Visual-focused versions for hearing impairments',
      'Simplified versions for cognitive disabilities',
      'Motor-accessible digital formats',
      'Anxiety-reduced versions with calming design',
      'Versions for 32 additional disability profiles',
      'Each maintaining educational content while adding accommodations'
    ]
  },
  {
    id: 5,
    title: 'Storage & Organization',
    description: 'Store all generated content with metadata and organization',
    why: 'With thousands of files generated (8 reading levels × 8 supplements × 10 formats × 40 disability adaptations = 25,600+ files per book subject), proper organization is critical. Users need to quickly find exactly the version they need. Storage must be reliable to prevent data loss. Metadata enables searching and filtering. Proper organization makes the massive content library actually usable.',
    how: 'Cloud storage systems organize files hierarchically by subject, reading level, supplement type, format, and disability adaptation. Each file has metadata tags for easy search and filtering. Database tracks all versions and relationships. Backup systems prevent data loss. CDN enables fast global access. File naming follows consistent conventions for easy identification.',
    who: 'System administrators managing the content library. Content managers adding and updating materials. Teachers searching for specific materials. Students browsing available books. Developers building applications on the content. Anyone needing reliable access to educational materials.',
    technicalDetails: [
      'Hierarchical storage: subject/level/type/format/adaptation/',
      'Metadata: title, author, subject, grade level, format, disability, ISBN, tags',
      'Database indexing for fast search and retrieval',
      'CDN distribution for fast global downloads',
      'Redundant storage across multiple availability zones',
      'Automated backup every 24 hours with 30-day retention',
      'Version control for content updates',
      'Access logs and usage analytics'
    ],
    qualityChecks: [
      'All files successfully uploaded and accessible',
      'File integrity verification (checksums)',
      'Metadata complete and accurate for all files',
      'Search functionality returns correct results',
      'Download speeds meet performance requirements',
      'Backup systems tested and verified',
      'Storage redundancy confirmed across zones'
    ],
    outputs: [
      'Organized file structure by subject/level/format/adaptation',
      'Searchable metadata for all content',
      'Database tracking all versions and relationships',
      'Fast CDN-based content delivery',
      'Automated backup and redundancy systems',
      'Version tracking for updates',
      'Usage analytics and access logs',
      'API for programmatic access to content'
    ]
  },
  {
    id: 6,
    title: 'Distribution Ready',
    description: 'Package content for user access and distribution',
    why: 'Generated content is useless if users cannot easily access it. Content must be packaged in intuitive ways - complete book bundles, subject collections, grade-level libraries. Users need simple download options, streaming access for audio, and web viewing for HTML. Distribution system must handle thousands of concurrent users. The goal is making world-class educational content easily accessible to everyone.',
    how: 'Content is organized into logical packages based on user needs. Complete bundles include all supplements and formats for a book. Subject collections group related materials. Grade-level libraries contain everything for that level. Web platform provides browsing, search, preview, download, and streaming. Authentication ensures proper access. Analytics track usage to improve the system.',
    who: 'Individual students downloading materials for personal learning. Teachers accessing classroom materials for lesson planning. Schools licensing bulk content for all students. Libraries providing digital resources to patrons. Researchers using materials for studies. Organizations distributing content to underserved communities. Anyone seeking accessible educational resources.',
    technicalDetails: [
      'Complete book packages: Book + 8 supplements + 10 formats = 90+ files',
      'Reading level bundles: All books at specific level',
      'Subject collections: Related books grouped by topic',
      'Disability-specific libraries: All content with specific adaptations',
      'Web platform with browse, search, preview, download, stream',
      'Authentication and access control',
      'Download manager for large files',
      'Streaming server for audio/video content',
      'API for third-party integrations'
    ],
    qualityChecks: [
      'All packages contain correct and complete files',
      'Download links tested and functional',
      'Streaming services working correctly',
      'Access permissions enforced properly',
      'Platform handles high concurrent user load',
      'Mobile apps function correctly',
      'Search returns accurate relevant results',
      'User interface is intuitive and accessible'
    ],
    outputs: [
      'Complete learning packages ready for distribution',
      'Web platform for browsing and accessing content',
      'Mobile apps for iOS and Android',
      'API for third-party integration',
      'Bulk download options for schools',
      'Streaming access for audiobooks',
      'Web reader for HTML content',
      'Customizable access permissions',
      'Usage analytics and reporting',
      'User accounts and libraries',
      'Recommendation engine for discovering content'
    ]
  }
];

export function DemoStepWalkthroughPage({ onBack, onNavigate }: DemoStepWalkthroughPageProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const step = GENERATION_STEPS[currentStep];
  const isFirstStep = currentStep === 0;
  const isLastStep = currentStep === GENERATION_STEPS.length - 1;

  const handleNext = () => {
    if (!isLastStep) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (!isFirstStep) {
      setCurrentStep(currentStep - 1);
    }
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--color-background)' }}>
      {onNavigate && <BackToAdminButton onNavigate={onNavigate} />}
      <div className="max-w-5xl mx-auto px-6 py-8">
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 px-4 py-2 rounded-lg transition"
            style={{
              backgroundColor: 'var(--color-surface)',
              color: 'var(--color-text)',
            }}
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </button>

          <div className="text-sm font-medium" style={{ color: 'var(--color-textSecondary)' }}>
            Step {currentStep + 1} of {GENERATION_STEPS.length}
          </div>
        </div>

        <div className="mb-8">
          <div className="flex gap-2">
            {GENERATION_STEPS.map((s, idx) => (
              <div
                key={s.id}
                className="flex-1 h-2 rounded-full transition-all"
                style={{
                  backgroundColor: idx <= currentStep ? 'var(--color-primary)' : 'var(--color-border)',
                }}
              />
            ))}
          </div>
        </div>

        <div
          className="rounded-2xl p-8 mb-8"
          style={{
            backgroundColor: 'var(--color-surface)',
            borderWidth: '2px',
            borderStyle: 'solid',
            borderColor: 'var(--color-primary)',
          }}
        >
          <div className="mb-6">
            <div
              className="inline-block px-4 py-2 rounded-lg text-sm font-bold mb-4"
              style={{
                backgroundColor: 'var(--color-primary)',
                color: 'var(--color-background)',
              }}
            >
              Step {step.id}
            </div>
            <h1 className="text-3xl font-bold mb-3" style={{ color: 'var(--color-text)' }}>
              {step.title}
            </h1>
            <p className="text-lg" style={{ color: 'var(--color-textSecondary)' }}>
              {step.description}
            </p>
          </div>

          <div className="space-y-6">
            <div
              className="rounded-lg p-5"
              style={{
                backgroundColor: 'var(--color-background)',
                borderWidth: '1px',
                borderStyle: 'solid',
                borderColor: 'var(--color-border)',
              }}
            >
              <h3 className="text-lg font-bold mb-2" style={{ color: 'var(--color-accent)' }}>
                Why This Step?
              </h3>
              <p className="text-sm" style={{ color: 'var(--color-textSecondary)' }}>
                {step.why}
              </p>
            </div>

            <div
              className="rounded-lg p-5"
              style={{
                backgroundColor: 'var(--color-background)',
                borderWidth: '1px',
                borderStyle: 'solid',
                borderColor: 'var(--color-border)',
              }}
            >
              <h3 className="text-lg font-bold mb-2" style={{ color: 'var(--color-secondary)' }}>
                How It Works
              </h3>
              <p className="text-sm" style={{ color: 'var(--color-textSecondary)' }}>
                {step.how}
              </p>
            </div>

            <div
              className="rounded-lg p-5"
              style={{
                backgroundColor: 'var(--color-background)',
                borderWidth: '1px',
                borderStyle: 'solid',
                borderColor: 'var(--color-border)',
              }}
            >
              <h3 className="text-lg font-bold mb-2" style={{ color: 'var(--color-success)' }}>
                Who Benefits
              </h3>
              <p className="text-sm" style={{ color: 'var(--color-textSecondary)' }}>
                {step.who}
              </p>
            </div>

            <div
              className="rounded-lg p-5"
              style={{
                backgroundColor: 'var(--color-background)',
                borderWidth: '1px',
                borderStyle: 'solid',
                borderColor: 'var(--color-border)',
              }}
            >
              <h3 className="text-lg font-bold mb-3" style={{ color: 'var(--color-text)' }}>
                Technical Details
              </h3>
              <ul className="space-y-2">
                {step.technicalDetails.map((detail, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-sm">
                    <span style={{ color: 'var(--color-primary)' }}>•</span>
                    <span style={{ color: 'var(--color-textSecondary)' }}>{detail}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div
              className="rounded-lg p-5"
              style={{
                backgroundColor: 'var(--color-background)',
                borderWidth: '1px',
                borderStyle: 'solid',
                borderColor: 'var(--color-warning)',
              }}
            >
              <div className="flex items-center gap-2 mb-3">
                <Shield className="w-5 h-5" style={{ color: 'var(--color-warning)' }} />
                <h3 className="text-lg font-bold" style={{ color: 'var(--color-warning)' }}>
                  Quality Validation (This Step)
                </h3>
              </div>
              <ul className="space-y-2">
                {step.qualityChecks.map((check, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-sm">
                    <Check className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: 'var(--color-warning)' }} />
                    <span style={{ color: 'var(--color-textSecondary)' }}>{check}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div
              className="rounded-lg p-5"
              style={{
                backgroundColor: 'var(--color-background)',
                borderWidth: '1px',
                borderStyle: 'solid',
                borderColor: 'var(--color-border)',
              }}
            >
              <h3 className="text-lg font-bold mb-3" style={{ color: 'var(--color-text)' }}>
                Outputs Created
              </h3>
              <ul className="space-y-2">
                {step.outputs.map((output, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-sm">
                    <Check className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: 'var(--color-primary)' }} />
                    <span style={{ color: 'var(--color-textSecondary)' }}>{output}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <button
            onClick={handlePrevious}
            disabled={isFirstStep}
            className="flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition disabled:opacity-40 disabled:cursor-not-allowed"
            style={{
              backgroundColor: 'var(--color-surface)',
              color: 'var(--color-text)',
              borderWidth: '1px',
              borderStyle: 'solid',
              borderColor: 'var(--color-border)',
            }}
          >
            <ArrowLeft className="w-5 h-5" />
            Previous
          </button>

          {isLastStep ? (
            <button
              onClick={onBack}
              className="flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition"
              style={{
                backgroundColor: 'var(--color-success)',
                color: 'var(--color-background)',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.opacity = '0.9';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.opacity = '1';
              }}
            >
              <Check className="w-5 h-5" />
              Complete
            </button>
          ) : (
            <button
              onClick={handleNext}
              className="flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition"
              style={{
                backgroundColor: 'var(--color-primary)',
                color: 'var(--color-background)',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = 'var(--color-primaryHover)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'var(--color-primary)';
              }}
            >
              Continue
              <ArrowRight className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
