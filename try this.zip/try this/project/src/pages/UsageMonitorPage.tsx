import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Activity, TrendingUp, AlertTriangle, DollarSign, Zap } from 'lucide-react';

interface ServiceUsage {
  service_name: string;
  total_tokens: number;
  total_requests: number;
  total_cost: number;
  avg_response_time: number;
}

export function UsageMonitorPage() {
  const [usage, setUsage] = useState<ServiceUsage[]>([]);
  const [loading, setLoading] = useState(true);
  const [totalCost, setTotalCost] = useState(0);
  const [totalTokens, setTotalTokens] = useState(0);

  useEffect(() => {
    loadUsageData();
  }, []);

  const loadUsageData = async () => {
    try {
      const { data: usageData, error } = await supabase
        .from('api_usage')
        .select(`
          tokens_used,
          requests_count,
          cost,
          response_time_avg,
          api_services (
            service_name
          )
        `);

      if (error) throw error;

      const aggregated: Record<string, ServiceUsage> = {};
      let totalCostSum = 0;
      let totalTokensSum = 0;

      usageData?.forEach((record: any) => {
        const serviceName = record.api_services?.service_name || 'Unknown';
        if (!aggregated[serviceName]) {
          aggregated[serviceName] = {
            service_name: serviceName,
            total_tokens: 0,
            total_requests: 0,
            total_cost: 0,
            avg_response_time: 0,
          };
        }

        aggregated[serviceName].total_tokens += record.tokens_used || 0;
        aggregated[serviceName].total_requests += record.requests_count || 0;
        aggregated[serviceName].total_cost += Number(record.cost) || 0;
        aggregated[serviceName].avg_response_time = record.response_time_avg || 0;

        totalCostSum += Number(record.cost) || 0;
        totalTokensSum += record.tokens_used || 0;
      });

      setUsage(Object.values(aggregated));
      setTotalCost(totalCostSum);
      setTotalTokens(totalTokensSum);
    } catch (error) {
      console.error('Error loading usage data:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(2)}M`;
    } else if (num >= 1000) {
      return `${(num / 1000).toFixed(2)}K`;
    }
    return num.toFixed(0);
  };

  const formatCurrency = (amount: number) => {
    return `$${amount.toFixed(2)}`;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Activity className="w-8 h-8 text-blue-600 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Usage Monitor</h1>
        <p className="text-gray-600 mt-1">Track API usage, tokens, and costs</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 rounded-lg bg-blue-600">
              <Zap className="w-6 h-6 text-white" />
            </div>
          </div>
          <p className="text-sm text-gray-600 mb-1">Total Tokens Used</p>
          <p className="text-3xl font-bold text-gray-900">{formatNumber(totalTokens)}</p>
          <p className="text-xs text-gray-500 mt-2">All services combined</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 rounded-lg bg-green-600">
              <DollarSign className="w-6 h-6 text-white" />
            </div>
          </div>
          <p className="text-sm text-gray-600 mb-1">Total Cost</p>
          <p className="text-3xl font-bold text-gray-900">{formatCurrency(totalCost)}</p>
          <p className="text-xs text-gray-500 mt-2">Current billing period</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 rounded-lg bg-purple-600">
              <TrendingUp className="w-6 h-6 text-white" />
            </div>
          </div>
          <p className="text-sm text-gray-600 mb-1">Active Services</p>
          <p className="text-3xl font-bold text-gray-900">{usage.length}</p>
          <p className="text-xs text-gray-500 mt-2">Currently in use</p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
          <h2 className="text-lg font-semibold text-gray-900">Service Breakdown</h2>
        </div>

        {usage.length === 0 ? (
          <div className="p-12 text-center">
            <Activity className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No usage data yet</h3>
            <p className="text-gray-600">
              Usage statistics will appear here after generating your first book
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Service
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Tokens Used
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Requests
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Avg Response
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Cost
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {usage.map((service) => (
                  <tr key={service.service_name} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="font-medium text-gray-900">{service.service_name}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-gray-700">
                      {formatNumber(service.total_tokens)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-gray-700">
                      {service.total_requests.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-gray-700">
                      {service.avg_response_time}ms
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="font-medium text-gray-900">
                        {formatCurrency(service.total_cost)}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-6 h-6 text-yellow-600 flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="font-semibold text-yellow-900 mb-1">Budget Monitoring</h3>
            <p className="text-sm text-yellow-800">
              Set up budget alerts and usage limits in the API Services section to avoid unexpected costs.
              The system will automatically switch to backup services when limits are reached.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
