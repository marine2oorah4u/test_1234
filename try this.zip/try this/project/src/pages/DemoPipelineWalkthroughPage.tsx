import { useState } from 'react';
import { ArrowLeft, Play, Sparkles } from 'lucide-react';
import { TimelineDemo } from '../components/PipelineWalkthrough/TimelineDemo';
import { completeBookDemo } from '../config/completeBookPipeline';
import { BackToAdminButton } from '../components/BackToAdminButton';

interface DemoPipelineWalkthroughPageProps {
  onBack: () => void;
  onNavigate?: (page: string) => void;
}

export function DemoPipelineWalkthroughPage({ onBack, onNavigate }: DemoPipelineWalkthroughPageProps) {
  const [showDemo, setShowDemo] = useState(false);

  if (showDemo) {
    return (
      <TimelineDemo
        demo={completeBookDemo}
        onComplete={() => {
          setShowDemo(false);
        }}
      />
    );
  }

  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--color-background)' }}>
      {onNavigate && <BackToAdminButton onNavigate={onNavigate} />}
      <div className="max-w-6xl mx-auto px-6 py-12">
        {/* Header */}
        <button
          onClick={onBack}
          className="flex items-center gap-2 mb-8 transition"
          style={{ color: 'var(--color-textMuted)' }}
          onMouseEnter={(e) => {
            e.currentTarget.style.color = 'var(--color-text)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.color = 'var(--color-textMuted)';
          }}
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Demo
        </button>

        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Play className="w-12 h-12" style={{ color: 'var(--color-primary)' }} />
            <h1 className="text-5xl font-bold" style={{ color: 'var(--color-text)' }}>
              Pipeline Walkthroughs
            </h1>
          </div>
          <p className="text-xl max-w-3xl mx-auto" style={{ color: 'var(--color-textMuted)' }}>
            Watch step-by-step as our AI workers collaborate to generate a single book section.
            See real worker counts, timing, and understand exactly how the pipeline works.
          </p>
        </div>

        {/* Demo Selection Card */}
        <div className="max-w-2xl mx-auto mb-12">
          <button
            onClick={() => setShowDemo(true)}
            className="text-left p-8 rounded-2xl transition transform hover:scale-105 w-full"
            style={{
              backgroundColor: 'var(--color-surface)',
              borderWidth: '2px',
              borderStyle: 'solid',
              borderColor: 'var(--color-border)'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = 'var(--color-primary)';
              e.currentTarget.style.backgroundColor = 'var(--color-surfaceHover)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = 'var(--color-border)';
              e.currentTarget.style.backgroundColor = 'var(--color-surface)';
            }}
          >
            <div className="flex items-start gap-6">
              <Sparkles className="w-16 h-16 flex-shrink-0" style={{ color: 'var(--color-primary)' }} />
              <div className="flex-1">
                <h3 className="text-3xl font-bold mb-3" style={{ color: 'var(--color-text)' }}>
                  Complete Book Generation Pipeline
                </h3>
                <p className="mb-4 text-lg leading-relaxed" style={{ color: 'var(--color-textMuted)' }}>
                  Watch all 18 steps from research to publication. See how 84 sections become 12 chapters and finally one complete book in 75-90 minutes.
                </p>
                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div className="p-3 rounded-lg" style={{ backgroundColor: 'var(--color-background)' }}>
                    <div className="text-sm" style={{ color: 'var(--color-textMuted)' }}>Steps</div>
                    <div className="text-xl font-bold" style={{ color: 'var(--color-primary)' }}>
                      18
                    </div>
                  </div>
                  <div className="p-3 rounded-lg" style={{ backgroundColor: 'var(--color-background)' }}>
                    <div className="text-sm" style={{ color: 'var(--color-textMuted)' }}>Duration</div>
                    <div className="text-xl font-bold" style={{ color: 'var(--color-accent)' }}>
                      ~2.5 min
                    </div>
                  </div>
                  <div className="p-3 rounded-lg" style={{ backgroundColor: 'var(--color-background)' }}>
                    <div className="text-sm" style={{ color: 'var(--color-textMuted)' }}>Workers</div>
                    <div className="text-xl font-bold" style={{ color: 'var(--color-success)' }}>
                      240+ AIs
                    </div>
                  </div>
                </div>
                <div className="px-6 py-3 rounded-lg text-center font-semibold text-lg" style={{ backgroundColor: 'var(--color-primary)', color: 'var(--color-background)' }}>
                  Start Demo →
                </div>
              </div>
            </div>
          </button>
        </div>

        {/* Information Section */}
        <div
          className="p-8 rounded-2xl"
          style={{
            backgroundColor: 'var(--color-surface)',
            borderWidth: '1px',
            borderStyle: 'solid',
            borderColor: 'var(--color-border)'
          }}
        >
          <h2 className="text-2xl font-bold mb-4" style={{ color: 'var(--color-text)' }}>
            What You'll Learn
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold mb-2" style={{ color: 'var(--color-primary)' }}>
                How AI Models Collaborate
              </h3>
              <p className="text-sm leading-relaxed" style={{ color: 'var(--color-textMuted)' }}>
                See GPT-4, Claude, Gemini, and Llama work together. Each AI has unique strengths that combine for superior results.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2" style={{ color: 'var(--color-accent)' }}>
                Quality Assurance Process
              </h3>
              <p className="text-sm leading-relaxed" style={{ color: 'var(--color-textMuted)' }}>
                Every piece of content goes through 4-AI verification. Nothing passes without unanimous approval.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2" style={{ color: 'var(--color-secondary)' }}>
                Parallel Processing Power
              </h3>
              <p className="text-sm leading-relaxed" style={{ color: 'var(--color-textMuted)' }}>
                Multiple pipelines run simultaneously. One topic generates thousands of resources in hours, not months.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2" style={{ color: 'var(--color-success)' }}>
                Accessibility First Design
              </h3>
              <p className="text-sm leading-relaxed" style={{ color: 'var(--color-textMuted)' }}>
                Every feature considers all learners. Disability adaptations, reading levels, and formats built-in from day one.
              </p>
            </div>
          </div>
        </div>

        {/* Controls Info */}
        <div className="mt-8 text-center">
          <p className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
            Each demo includes play/pause controls, speed adjustment (0.5x - 5x), and the ability to jump to any section.
            Terminal output shows real-time system logs for technical insight.
          </p>
        </div>
      </div>
    </div>
  );
}
