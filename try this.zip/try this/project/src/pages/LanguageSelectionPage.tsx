import React, { useState, useEffect } from 'react';
import { Search, Filter, Globe, TrendingUp } from 'lucide-react';
import { LanguageCard } from '../components/LanguageCard';
import { VoiceQualitySelector } from '../components/VoiceQualitySelector';
import { supabase } from '../lib/supabase';

interface Language {
  id: string;
  language_code: string;
  language_name_english: string;
  language_name_native: string;
  quality_tier: 1 | 2 | 3;
  quality_status: 'complete' | 'improving' | 'beta';
  has_text_translation: boolean;
  has_voice_narration: boolean;
  has_video_narration: boolean;
  has_ai_tutor_voice: boolean;
  has_cultural_adaptation: boolean;
  has_robotic_voice_available: boolean;
  voice_quality: 'excellent' | 'good' | 'robotic' | 'unavailable';
  robotic_voice_provider?: string;
  total_speakers_millions?: number;
}

export function LanguageSelectionPage() {
  const [languages, setLanguages] = useState<Language[]>([]);
  const [filteredLanguages, setFilteredLanguages] = useState<Language[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterTier, setFilterTier] = useState<'all' | 1 | 2 | 3>('all');
  const [selectedLanguage, setSelectedLanguage] = useState<Language | null>(null);
  const [roboticVoiceEnabled, setRoboticVoiceEnabled] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadLanguages();
  }, []);

  useEffect(() => {
    filterLanguages();
  }, [languages, searchQuery, filterTier]);

  const loadLanguages = async () => {
    try {
      const { data, error } = await supabase
        .from('supported_languages')
        .select('*')
        .eq('is_active', true)
        .order('display_order', { ascending: true });

      if (error) throw error;
      setLanguages(data || []);
    } catch (error) {
      console.error('Error loading languages:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterLanguages = () => {
    let filtered = languages;

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        lang =>
          lang.language_name_english.toLowerCase().includes(query) ||
          lang.language_name_native.toLowerCase().includes(query) ||
          lang.language_code.toLowerCase().includes(query)
      );
    }

    // Tier filter
    if (filterTier !== 'all') {
      filtered = filtered.filter(lang => lang.quality_tier === filterTier);
    }

    setFilteredLanguages(filtered);
  };

  const handleLanguageSelect = (language: Language) => {
    setSelectedLanguage(language);
    // Load user's existing preference for this language
    loadUserVoicePreference(language.id);
  };

  const loadUserVoicePreference = async (languageId: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('user_language_voice_preferences')
        .select('enable_robotic_voice')
        .eq('user_id', user.id)
        .eq('language_id', languageId)
        .maybeSingle();

      if (data) {
        setRoboticVoiceEnabled(data.enable_robotic_voice);
      } else {
        setRoboticVoiceEnabled(false);
      }
    } catch (error) {
      console.error('Error loading voice preference:', error);
    }
  };

  const handleVoiceToggle = async (enabled: boolean) => {
    if (!selectedLanguage) return;

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase
        .from('user_language_voice_preferences')
        .upsert({
          user_id: user.id,
          language_id: selectedLanguage.id,
          enable_robotic_voice: enabled,
          preference_set_at: new Date().toISOString()
        });

      if (error) throw error;
      setRoboticVoiceEnabled(enabled);
    } catch (error) {
      console.error('Error saving voice preference:', error);
    }
  };

  const getTierStats = () => {
    return {
      tier1: languages.filter(l => l.quality_tier === 1).length,
      tier2: languages.filter(l => l.quality_tier === 2).length,
      tier3: languages.filter(l => l.quality_tier === 3).length,
      total: languages.length
    };
  };

  const stats = getTierStats();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <Globe className="w-12 h-12 text-blue-600 animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Loading languages...</p>
        </div>
      </div>
    );
  }

  if (selectedLanguage) {
    return (
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="max-w-4xl mx-auto">
          <button
            onClick={() => setSelectedLanguage(null)}
            className="mb-6 text-blue-600 hover:text-blue-700 font-medium"
          >
            ← Back to language selection
          </button>

          <div className="bg-white rounded-xl shadow-sm p-8">
            <div className="flex items-center gap-4 mb-6">
              <span className="text-5xl">{selectedLanguage.language_code === 'en' ? '🇬🇧' : '🌐'}</span>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">
                  {selectedLanguage.language_name_english}
                </h1>
                <p className="text-xl text-gray-600">{selectedLanguage.language_name_native}</p>
              </div>
            </div>

            <div className="mb-8">
              <VoiceQualitySelector
                languageCode={selectedLanguage.language_code}
                languageName={selectedLanguage.language_name_english}
                voiceQuality={selectedLanguage.voice_quality}
                hasRoboticVoiceAvailable={selectedLanguage.has_robotic_voice_available}
                roboticVoiceProvider={selectedLanguage.robotic_voice_provider}
                currentlyEnabled={roboticVoiceEnabled}
                onToggle={handleVoiceToggle}
              />
            </div>

            <div className="border-t pt-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Available Features</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FeatureItem label="Text Lessons" available={selectedLanguage.has_text_translation} />
                <FeatureItem label="Audio Narration" available={selectedLanguage.has_voice_narration || roboticVoiceEnabled} />
                <FeatureItem label="Video Lessons" available={selectedLanguage.has_video_narration} />
                <FeatureItem label="AI Tutor" available={selectedLanguage.has_ai_tutor_voice} />
                <FeatureItem label="Cultural Adaptation" available={selectedLanguage.has_cultural_adaptation} />
                <FeatureItem label="Interactive Quizzes" available={true} />
              </div>
            </div>

            <button className="w-full mt-8 bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors font-semibold">
              Start Learning in {selectedLanguage.language_name_english}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="flex items-center gap-3 mb-4">
            <Globe className="w-8 h-8 text-blue-600" />
            <h1 className="text-3xl font-bold text-gray-900">Choose Your Language</h1>
          </div>
          <p className="text-gray-600 mb-6">
            Learn in {stats.total} languages with varying levels of AI quality and features
          </p>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <StatBox label="Total Languages" value={stats.total} color="gray" />
            <StatBox label="Fully Available" value={stats.tier1} color="green" />
            <StatBox label="High Quality" value={stats.tier2} color="blue" />
            <StatBox label="Beta" value={stats.tier3} color="orange" />
          </div>

          {/* Search and Filters */}
          <div className="flex gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search languages..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <select
              value={filterTier}
              onChange={e => setFilterTier(e.target.value as any)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">All Tiers</option>
              <option value={1}>Tier 1 - Fully Available</option>
              <option value={2}>Tier 2 - High Quality</option>
              <option value={3}>Tier 3 - Beta</option>
            </select>
          </div>
        </div>
      </div>

      {/* Language Grid */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {filteredLanguages.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-500">No languages found matching your criteria</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredLanguages.map(language => (
              <LanguageCard
                key={language.id}
                languageCode={language.language_code}
                languageName={language.language_name_english}
                nativeName={language.language_name_native}
                qualityTier={language.quality_tier}
                qualityStatus={language.quality_status}
                hasTextTranslation={language.has_text_translation}
                hasVoiceNarration={language.has_voice_narration}
                hasVideoNarration={language.has_video_narration}
                hasAITutorVoice={language.has_ai_tutor_voice}
                hasCulturalAdaptation={language.has_cultural_adaptation}
                hasRoboticVoiceAvailable={language.has_robotic_voice_available}
                voiceQuality={language.voice_quality}
                speakersInMillions={language.total_speakers_millions}
                onSelect={() => handleLanguageSelect(language)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function StatBox({ label, value, color }: { label: string; value: number; color: string }) {
  const colors = {
    gray: 'bg-gray-100 text-gray-700',
    green: 'bg-green-100 text-green-700',
    blue: 'bg-blue-100 text-blue-700',
    orange: 'bg-orange-100 text-orange-700'
  };

  return (
    <div className={`${colors[color as keyof typeof colors]} rounded-lg p-4`}>
      <p className="text-2xl font-bold">{value}</p>
      <p className="text-sm">{label}</p>
    </div>
  );
}

function FeatureItem({ label, available }: { label: string; available: boolean }) {
  return (
    <div className="flex items-center gap-2">
      <div className={`w-2 h-2 rounded-full ${available ? 'bg-green-500' : 'bg-gray-300'}`} />
      <span className={available ? 'text-gray-900' : 'text-gray-500'}>{label}</span>
    </div>
  );
}
