import { ArrowLeft, Target, Heart, Lightbulb, TrendingUp } from 'lucide-react';

interface DemoAboutPageProps {
  onBack: () => void;
}

export function DemoAboutPage({ onBack }: DemoAboutPageProps) {
  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--color-background)', fontFamily: 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif' }}>
      <div className="max-w-4xl mx-auto px-6 py-8">
        <div className="flex items-center mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 px-4 py-2 rounded-lg transition"
            style={{
              backgroundColor: 'var(--color-surface)',
              color: 'var(--color-text)',
            }}
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </button>
        </div>

        <div className="space-y-8">
          <div>
            <h1 className="text-4xl font-bold mb-6" style={{ color: 'var(--color-text)' }}>
              About This Project
            </h1>
            <div
              className="rounded-2xl p-8"
              style={{
                backgroundColor: 'var(--color-surface)',
                borderWidth: '2px',
                borderStyle: 'solid',
                borderColor: 'var(--color-primary)',
              }}
            >
              <p className="text-base mb-4" style={{ color: 'var(--color-textSecondary)' }}>
                Through my work with international scouting programs, I discovered something that changed my perspective entirely:
                the global gap in educational content is far larger than most people realize. While working with Scout associations
                around the world, I saw firsthand how some countries have abundant learning materials while others have almost none.
                One conversation led to another, one project opened doors to the next, and gradually I understood the scale of need
                for accessible educational content worldwide.
              </p>
              <p className="text-base mb-4" style={{ color: 'var(--color-textSecondary)' }}>
                As I explored ways to help, I realized we're living in a unique moment in history. AI technology has reached a point
                where it can generate quality educational content at scale. We can now create comprehensive textbooks, automatically
                produce worksheets and assessments, convert materials into accessible formats, and adapt content for different learning
                needs—all in a fraction of the time and cost of traditional publishing. This isn't science fiction; it's possible today.
              </p>
              <p className="text-base" style={{ color: 'var(--color-textSecondary)' }}>
                This project is a global knowledge library covering every learnable subject imaginable, made freely available to everyone.
                It's ambitious, perhaps even audacious for someone like me to attempt. But when you recognize both the enormous need and
                the unprecedented opportunity created by current AI capabilities, it becomes impossible not to try.
              </p>
            </div>
          </div>

          <div>
            <div className="flex items-center gap-3 mb-6">
              <Target className="w-8 h-8" style={{ color: 'var(--color-primary)' }} />
              <h2 className="text-3xl font-bold" style={{ color: 'var(--color-text)' }}>
                My Goals & What I Hope to Accomplish
              </h2>
            </div>
            <div className="space-y-4">
              <div
                className="rounded-lg p-6"
                style={{
                  backgroundColor: 'var(--color-surface)',
                  borderWidth: '1px',
                  borderStyle: 'solid',
                  borderColor: 'var(--color-border)',
                }}
              >
                <h3 className="text-xl font-bold mb-3" style={{ color: 'var(--color-accent)' }}>
                  Immediate Goal: Launch & Validation
                </h3>
                <p className="text-sm" style={{ color: 'var(--color-textSecondary)' }}>
                  The first milestone is securing funding and resources to begin full-scale production. Once that's in place,
                  I aim to have the content generation engine running daily within six months, producing high-quality educational
                  materials across core subject areas. The system is designed; it needs execution. If I can demonstrate consistent
                  output quality and show real educators finding value in the materials, that validates the entire approach and
                  opens the door to scaling rapidly.
                </p>
              </div>

              <div
                className="rounded-lg p-6"
                style={{
                  backgroundColor: 'var(--color-surface)',
                  borderWidth: '1px',
                  borderStyle: 'solid',
                  borderColor: 'var(--color-border)',
                }}
              >
                <h3 className="text-xl font-bold mb-3" style={{ color: 'var(--color-secondary)' }}>
                  Medium-Term Goal: Full English Library
                </h3>
                <p className="text-sm" style={{ color: 'var(--color-textSecondary)' }}>
                  Within the first year, complete the English-language library across all 24 subject areas with comprehensive
                  accessibility adaptations. This means thousands of books covering academic subjects, life skills, job training,
                  and specialized topics—all available in multiple formats for different reading levels and learning needs. Students
                  with autism get visual supports. ADHD learners get attention-friendly chunked content. Dyslexic students get properly
                  formatted text. Blind students get Braille. No one gets left behind. This phase establishes the foundation for
                  everything that follows.
                </p>
              </div>

              <div
                className="rounded-lg p-6"
                style={{
                  backgroundColor: 'var(--color-surface)',
                  borderWidth: '1px',
                  borderStyle: 'solid',
                  borderColor: 'var(--color-border)',
                }}
              >
                <h3 className="text-xl font-bold mb-3" style={{ color: 'var(--color-success)' }}>
                  Long-Term Goal: Global Free Access
                </h3>
                <p className="text-sm" style={{ color: 'var(--color-textSecondary)' }}>
                  The ultimate vision is simple but profound: quality educational content freely available to anyone, anywhere.
                  Students in under-resourced schools access the same materials as wealthy districts. Homeschool parents access
                  professional curriculum without prohibitive costs. Adult learners changing careers find training materials in
                  formats that work for them. Special education teachers have properly adapted content for every student. Education
                  transcends the limitations of money, geography, and circumstance. That's the mission. That's what success looks like.
                </p>
              </div>
            </div>
          </div>

          <div>
            <div className="flex items-center gap-3 mb-6">
              <Heart className="w-8 h-8" style={{ color: 'var(--color-primary)' }} />
              <h2 className="text-3xl font-bold" style={{ color: 'var(--color-text)' }}>
                Why This Matters to Me
              </h2>
            </div>
            <div
              className="rounded-lg p-6"
              style={{
                backgroundColor: 'var(--color-surface)',
                borderWidth: '1px',
                borderStyle: 'solid',
                borderColor: 'var(--color-border)',
              }}
            >
              <p className="text-sm mb-4" style={{ color: 'var(--color-textSecondary)' }}>
                My involvement in Wood Badge and international scouting work gave me a window into educational inequality I hadn't
                fully appreciated before. When you're helping Scout associations in countries that lack basic educational materials—not
                specialized content, just foundational learning resources—you begin to see how vast the problem is. These aren't
                isolated cases; this is the reality for countless communities worldwide.
              </p>
              <p className="text-sm mb-4" style={{ color: 'var(--color-textSecondary)' }}>
                What frustrates me isn't that the problem exists—it's that we now have the tools to solve it, yet we're not moving
                fast enough. AI can generate content. Text-to-speech technology creates audiobooks. Format conversion is reliable.
                Cloud storage is affordable. Every piece needed to build a comprehensive, accessible, global educational library
                exists today. The only question is whether we'll actually build it.
              </p>
              <p className="text-sm" style={{ color: 'var(--color-textSecondary)' }}>
                If this succeeds, it will serve everyone—students without resources, teachers without materials, adults seeking to
                learn new skills, individuals with disabilities needing adapted content, and communities anywhere in the world that
                lack access to quality education. That potential keeps me working on this every day.
              </p>
            </div>
          </div>

          <div>
            <div className="flex items-center gap-3 mb-6">
              <TrendingUp className="w-8 h-8" style={{ color: 'var(--color-primary)' }} />
              <h2 className="text-3xl font-bold" style={{ color: 'var(--color-text)' }}>
                Potential Future Plans (If This Works)
              </h2>
            </div>
            <div className="space-y-4">
              <div
                className="rounded-lg p-6"
                style={{
                  backgroundColor: 'var(--color-surface)',
                  borderWidth: '1px',
                  borderStyle: 'solid',
                  borderColor: 'var(--color-border)',
                }}
              >
                <h3 className="text-lg font-bold mb-2" style={{ color: 'var(--color-text)' }}>
                  Multi-Language Translation
                </h3>
                <p className="text-sm" style={{ color: 'var(--color-textSecondary)' }}>
                  Translate all content into 100+ languages with AI verification and cultural adaptation. This would make educational
                  materials accessible globally, not just in English-speaking countries. Every book could be available in Spanish,
                  Mandarin, Arabic, Hindi, and dozens of other languages.
                </p>
              </div>

              <div
                className="rounded-lg p-6"
                style={{
                  backgroundColor: 'var(--color-surface)',
                  borderWidth: '1px',
                  borderStyle: 'solid',
                  borderColor: 'var(--color-border)',
                }}
              >
                <h3 className="text-lg font-bold mb-2" style={{ color: 'var(--color-text)' }}>
                  Interactive Learning Platform
                </h3>
                <p className="text-sm" style={{ color: 'var(--color-textSecondary)' }}>
                  Build a web platform where students can access interactive versions of books with embedded quizzes, AI tutoring,
                  progress tracking, and adaptive learning paths. Transform static books into dynamic learning experiences.
                </p>
              </div>

              <div
                className="rounded-lg p-6"
                style={{
                  backgroundColor: 'var(--color-surface)',
                  borderWidth: '1px',
                  borderStyle: 'solid',
                  borderColor: 'var(--color-border)',
                }}
              >
                <h3 className="text-lg font-bold mb-2" style={{ color: 'var(--color-text)' }}>
                  Video Content Generation
                </h3>
                <p className="text-sm" style={{ color: 'var(--color-textSecondary)' }}>
                  Convert books into video lessons with AI narration, animated diagrams, and visual explanations. Some students
                  learn better from video than text. Make every book available as a video course.
                </p>
              </div>

              <div
                className="rounded-lg p-6"
                style={{
                  backgroundColor: 'var(--color-surface)',
                  borderWidth: '1px',
                  borderStyle: 'solid',
                  borderColor: 'var(--color-border)',
                }}
              >
                <h3 className="text-lg font-bold mb-2" style={{ color: 'var(--color-text)' }}>
                  Partnerships with Schools & Libraries
                </h3>
                <p className="text-sm" style={{ color: 'var(--color-textSecondary)' }}>
                  Work with schools, libraries, and educational organizations to distribute content where it's most needed. Provide
                  bulk access for school districts. Make content available through public libraries. Partner with nonprofits serving
                  underserved communities.
                </p>
              </div>

              <div
                className="rounded-lg p-6"
                style={{
                  backgroundColor: 'var(--color-surface)',
                  borderWidth: '1px',
                  borderStyle: 'solid',
                  borderColor: 'var(--color-border)',
                }}
              >
                <h3 className="text-lg font-bold mb-2" style={{ color: 'var(--color-text)' }}>
                  Custom Content Generation
                </h3>
                <p className="text-sm" style={{ color: 'var(--color-textSecondary)' }}>
                  Allow educators to request custom books on specific topics not yet in the library. Enable teachers to customize
                  existing content for their specific curriculum needs. Make the generation system available as a tool, not just
                  a library.
                </p>
              </div>
            </div>
          </div>

          <div
            className="rounded-2xl p-8 text-center"
            style={{
              backgroundColor: 'var(--color-surface)',
              borderWidth: '2px',
              borderStyle: 'solid',
              borderColor: 'var(--color-primary)',
            }}
          >
            <Lightbulb className="w-16 h-16 mx-auto mb-4" style={{ color: 'var(--color-primary)' }} />
            <h2 className="text-2xl font-bold mb-4" style={{ color: 'var(--color-text)' }}>
              The Bottom Line
            </h2>
            <p className="text-base max-w-2xl mx-auto" style={{ color: 'var(--color-textSecondary)' }}>
              I never imagined I'd be the person to attempt something this ambitious. But through my work in international scouting,
              I saw the need. Through following AI development, I recognized the opportunity. And somewhere along the way, I realized
              that if not now, when? If not me, who? This is the right technology at the right moment to solve a problem that affects
              millions. That's why I'm pursuing funding and partnerships—to turn this vision into reality as quickly as possible.
              Education shouldn't be limited by borders, economics, or accessibility barriers. Let's change that.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
