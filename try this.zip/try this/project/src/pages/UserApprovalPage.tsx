import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { UserCheck, UserX, Clock, Mail, Calendar, CheckCircle, XCircle, AlertCircle } from 'lucide-react';

interface UserApproval {
  id: string;
  user_id: string;
  email: string;
  status: 'pending' | 'approved' | 'rejected';
  approved_by: string | null;
  approved_at: string | null;
  rejected_at: string | null;
  rejection_reason: string | null;
  requested_at: string;
  created_at: string;
}

export function UserApprovalPage() {
  const [approvals, setApprovals] = useState<UserApproval[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('pending');
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [rejectingUserId, setRejectingUserId] = useState<string | null>(null);

  useEffect(() => {
    loadApprovals();
  }, [filter]);

  const loadApprovals = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('user_approvals')
        .select('*')
        .order('requested_at', { ascending: false });

      if (filter !== 'all') {
        query = query.eq('status', filter);
      }

      const { data, error } = await query;

      if (error) throw error;
      setApprovals(data || []);
    } catch (error) {
      console.error('Error loading approvals:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (userId: string) => {
    setActionLoading(userId);
    try {
      const { error } = await supabase
        .from('user_approvals')
        .update({
          status: 'approved',
          approved_at: new Date().toISOString(),
          approved_by: (await supabase.auth.getUser()).data.user?.id,
        })
        .eq('user_id', userId);

      if (error) throw error;

      await loadApprovals();
    } catch (error) {
      console.error('Error approving user:', error);
      alert('Failed to approve user');
    } finally {
      setActionLoading(null);
    }
  };

  const handleReject = async (userId: string) => {
    if (!rejectionReason.trim()) {
      alert('Please provide a reason for rejection');
      return;
    }

    setActionLoading(userId);
    try {
      const { error } = await supabase
        .from('user_approvals')
        .update({
          status: 'rejected',
          rejected_at: new Date().toISOString(),
          rejection_reason: rejectionReason,
          approved_by: (await supabase.auth.getUser()).data.user?.id,
        })
        .eq('user_id', userId);

      if (error) throw error;

      setRejectionReason('');
      setRejectingUserId(null);
      await loadApprovals();
    } catch (error) {
      console.error('Error rejecting user:', error);
      alert('Failed to reject user');
    } finally {
      setActionLoading(null);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="w-5 h-5 text-yellow-500" />;
      case 'approved':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'rejected':
        return <XCircle className="w-5 h-5 text-red-500" />;
      default:
        return <AlertCircle className="w-5 h-5 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'approved':
        return 'bg-green-100 text-green-800 border-green-300';
      case 'rejected':
        return 'bg-red-100 text-red-800 border-red-300';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold" style={{ color: 'var(--color-text)' }}>
            User Approvals
          </h1>
          <p className="mt-2 opacity-70" style={{ color: 'var(--color-text)' }}>
            Manage user account approval requests
          </p>
        </div>
      </div>

      <div className="flex gap-2">
        {(['all', 'pending', 'approved', 'rejected'] as const).map((status) => (
          <button
            key={status}
            onClick={() => setFilter(status)}
            className="px-4 py-2 rounded-lg font-medium capitalize transition"
            style={{
              backgroundColor: filter === status ? 'var(--color-primary)' : 'var(--color-surface)',
              color: filter === status ? 'white' : 'var(--color-text)',
              opacity: filter === status ? 1 : 0.7,
            }}
          >
            {status}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="text-center py-12">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-4 border-solid border-current border-r-transparent" style={{ color: 'var(--color-primary)' }}></div>
        </div>
      ) : approvals.length === 0 ? (
        <div className="text-center py-12 rounded-xl" style={{ backgroundColor: 'var(--color-surface)' }}>
          <UserCheck className="w-16 h-16 mx-auto mb-4 opacity-50" style={{ color: 'var(--color-text)' }} />
          <p className="text-lg opacity-70" style={{ color: 'var(--color-text)' }}>
            No {filter !== 'all' ? filter : ''} approval requests
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {approvals.map((approval) => (
            <div
              key={approval.id}
              className="p-6 rounded-xl border-2"
              style={{
                backgroundColor: 'var(--color-surface)',
                borderColor: 'var(--color-border)',
              }}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    {getStatusIcon(approval.status)}
                    <div>
                      <div className="flex items-center gap-3">
                        <h3 className="text-lg font-semibold" style={{ color: 'var(--color-text)' }}>
                          {approval.email}
                        </h3>
                        <span
                          className={`px-3 py-1 rounded-full text-sm font-medium border ${getStatusColor(approval.status)}`}
                        >
                          {approval.status}
                        </span>
                      </div>
                      <div className="flex items-center gap-4 mt-2 text-sm opacity-70" style={{ color: 'var(--color-text)' }}>
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          <span>Requested: {formatDate(approval.requested_at)}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {approval.status === 'approved' && approval.approved_at && (
                    <div className="text-sm opacity-70 mt-2" style={{ color: 'var(--color-text)' }}>
                      Approved on {formatDate(approval.approved_at)}
                    </div>
                  )}

                  {approval.status === 'rejected' && (
                    <div className="mt-3 p-3 rounded-lg bg-red-50 border border-red-200">
                      <p className="text-sm font-medium text-red-900">Rejection Reason:</p>
                      <p className="text-sm text-red-800 mt-1">{approval.rejection_reason}</p>
                      {approval.rejected_at && (
                        <p className="text-xs text-red-600 mt-2">
                          Rejected on {formatDate(approval.rejected_at)}
                        </p>
                      )}
                    </div>
                  )}
                </div>

                {approval.status === 'pending' && (
                  <div className="flex gap-2 ml-4">
                    {rejectingUserId === approval.user_id ? (
                      <div className="flex gap-2">
                        <input
                          type="text"
                          placeholder="Reason for rejection..."
                          value={rejectionReason}
                          onChange={(e) => setRejectionReason(e.target.value)}
                          className="px-3 py-2 rounded-lg border"
                          style={{
                            borderColor: 'var(--color-border)',
                            backgroundColor: 'var(--color-background)',
                            color: 'var(--color-text)',
                          }}
                        />
                        <button
                          onClick={() => handleReject(approval.user_id)}
                          disabled={actionLoading === approval.user_id}
                          className="px-4 py-2 rounded-lg font-medium transition flex items-center gap-2 bg-red-600 text-white hover:bg-red-700 disabled:opacity-50"
                        >
                          <UserX className="w-4 h-4" />
                          Confirm
                        </button>
                        <button
                          onClick={() => {
                            setRejectingUserId(null);
                            setRejectionReason('');
                          }}
                          className="px-4 py-2 rounded-lg font-medium transition"
                          style={{
                            backgroundColor: 'var(--color-surface)',
                            color: 'var(--color-text)',
                          }}
                        >
                          Cancel
                        </button>
                      </div>
                    ) : (
                      <>
                        <button
                          onClick={() => handleApprove(approval.user_id)}
                          disabled={actionLoading === approval.user_id}
                          className="px-4 py-2 rounded-lg font-medium transition flex items-center gap-2 bg-green-600 text-white hover:bg-green-700 disabled:opacity-50"
                        >
                          <UserCheck className="w-4 h-4" />
                          Approve
                        </button>
                        <button
                          onClick={() => setRejectingUserId(approval.user_id)}
                          disabled={actionLoading === approval.user_id}
                          className="px-4 py-2 rounded-lg font-medium transition flex items-center gap-2 bg-red-600 text-white hover:bg-red-700 disabled:opacity-50"
                        >
                          <UserX className="w-4 h-4" />
                          Reject
                        </button>
                      </>
                    )}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
