import { useState } from 'react';
import { TokenTracker } from '../components/TokenTracker';
import { PipelineMonitor } from '../components/PipelineMonitor';
import { Activity, Zap, Eye } from 'lucide-react';

type ViewMode = 'overview' | 'tokens' | 'pipelines';

export function ComprehensiveMonitorPage() {
  const [viewMode, setViewMode] = useState<ViewMode>('overview');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
            <h1 className="text-3xl font-bold text-gray-900">Comprehensive System Monitor</h1>
            <p className="text-gray-600 mt-2">Real-time tracking of all AI operations, token usage, and pipeline execution</p>
          </div>
        </div>

        <div className="flex gap-2 border-b border-gray-200">
          <button
            onClick={() => setViewMode('overview')}
            className={`px-6 py-3 font-medium border-b-2 transition-colors ${
              viewMode === 'overview'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            <div className="flex items-center gap-2">
              <Eye className="w-4 h-4" />
              Overview
            </div>
          </button>
          <button
            onClick={() => setViewMode('tokens')}
            className={`px-6 py-3 font-medium border-b-2 transition-colors ${
              viewMode === 'tokens'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4" />
              Token Tracking
            </div>
          </button>
          <button
            onClick={() => setViewMode('pipelines')}
            className={`px-6 py-3 font-medium border-b-2 transition-colors ${
              viewMode === 'pipelines'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4" />
              Pipeline Activity
            </div>
          </button>
        </div>

        {viewMode === 'overview' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <Zap className="w-5 h-5 text-yellow-600" />
                  Token Usage Summary
                </h2>
                <TokenTracker compact />
              </div>

              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <Activity className="w-5 h-5 text-blue-600" />
                  Active Pipelines
                </h2>
                <div className="space-y-3">
                  <div className="border-l-4 border-blue-600 bg-blue-50 p-3 rounded-r">
                    <div className="font-medium text-blue-900">Photosynthesis - Biology</div>
                    <div className="text-sm text-blue-700 mt-1">Generation phase: 65% complete</div>
                  </div>
                  <div className="border-l-4 border-green-600 bg-green-50 p-3 rounded-r">
                    <div className="font-medium text-green-900">Ancient Egypt - History</div>
                    <div className="text-sm text-green-700 mt-1">Verification phase: 92% quality</div>
                  </div>
                  <div className="border-l-4 border-purple-600 bg-purple-50 p-3 rounded-r">
                    <div className="font-medium text-purple-900">Python Basics - CS</div>
                    <div className="text-sm text-purple-700 mt-1">Polish phase: 98% complete</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl shadow-lg p-6 text-white">
              <h3 className="text-2xl font-bold mb-2">System Operating Normally</h3>
              <p className="text-blue-100 mb-4">
                All AI models are healthy and responding. No critical issues detected.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-white bg-opacity-20 rounded-lg p-3">
                  <div className="text-3xl font-bold">12</div>
                  <div className="text-sm text-blue-100">Active AI Models</div>
                </div>
                <div className="bg-white bg-opacity-20 rounded-lg p-3">
                  <div className="text-3xl font-bold">3</div>
                  <div className="text-sm text-blue-100">Running Pipelines</div>
                </div>
                <div className="bg-white bg-opacity-20 rounded-lg p-3">
                  <div className="text-3xl font-bold">98%</div>
                  <div className="text-sm text-blue-100">System Health</div>
                </div>
                <div className="bg-white bg-opacity-20 rounded-lg p-3">
                  <div className="text-3xl font-bold">$12.45</div>
                  <div className="text-sm text-blue-100">Today's Cost</div>
                </div>
              </div>
            </div>

            <PipelineMonitor />
          </div>
        )}

        {viewMode === 'tokens' && (
          <div>
            <TokenTracker />
          </div>
        )}

        {viewMode === 'pipelines' && (
          <div>
            <PipelineMonitor />
          </div>
        )}
    </div>
  );
}
