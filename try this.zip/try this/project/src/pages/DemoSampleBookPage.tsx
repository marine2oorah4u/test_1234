import { ArrowLeft, BookOpen, Check, Download, FileText, Headphones, Eye } from 'lucide-react';

interface DemoSampleBookPageProps {
  onBack: () => void;
}

const SAMPLE_BOOK = {
  title: 'Introduction to Solar System',
  subject: 'Astronomy',
  description: 'A comprehensive guide exploring our solar system, planets, and celestial bodies',
};

const READING_LEVELS = [
  { level: 'Kindergarten', wordCount: '500', pages: 8, complexity: 'Very Simple' },
  { level: 'Elementary', wordCount: '1,200', pages: 16, complexity: 'Simple' },
  { level: 'Middle School', wordCount: '3,500', pages: 28, complexity: 'Moderate' },
  { level: 'High School', wordCount: '6,000', pages: 42, complexity: 'Advanced' },
  { level: 'Bachelors', wordCount: '12,000', pages: 85, complexity: 'Academic' },
  { level: 'Masters', wordCount: '18,000', pages: 120, complexity: 'Graduate' },
  { level: 'PhD', wordCount: '25,000', pages: 180, complexity: 'Research' },
  { level: 'Professional', wordCount: '30,000', pages: 220, complexity: 'Reference' },
];

const EDUCATIONAL_ADDONS = [
  { name: 'Activity Pack', icon: '🎨', items: '25 hands-on activities' },
  { name: 'Worksheet Set', icon: '📝', items: '30 practice worksheets' },
  { name: 'Quiz Pack', icon: '❓', items: '50 quiz questions' },
  { name: 'Answer Key', icon: '✅', items: 'Complete solutions' },
  { name: 'Study Guide', icon: '📚', items: 'Chapter summaries' },
  { name: 'Lesson Plans', icon: '🎯', items: '8 lesson plans' },
  { name: 'Presentation Slides', icon: '📊', items: '45 slides' },
  { name: 'Career Guide', icon: '💼', items: 'Career pathways' },
];

const FORMATS = [
  { name: 'PDF (Print)', icon: '📄', desc: 'High-quality print version' },
  { name: 'PDF (Digital)', icon: '💻', desc: 'Screen-optimized version' },
  { name: 'EPUB', icon: '📱', desc: 'E-reader compatible' },
  { name: 'Audiobook', icon: '🎧', desc: 'Professional narration' },
  { name: 'Large Print', icon: '🔍', desc: '18pt font version' },
  { name: 'Braille', icon: '⠃', desc: 'Grade 2 Braille' },
  { name: 'Interactive HTML', icon: '🌐', desc: 'Web-based version' },
  { name: 'DOCX', icon: '📝', desc: 'Editable format' },
];

const DISABILITY_SAMPLES = [
  { name: 'Autism Spectrum', adaptations: 'Visual schedules, reduced sensory elements, clear structure' },
  { name: 'ADHD', adaptations: 'Shorter sections, frequent breaks, high engagement' },
  { name: 'Dyslexia', adaptations: 'OpenDyslexic font, increased spacing, color overlays' },
  { name: 'Visual Impairment', adaptations: 'High contrast, tactile graphics, audio descriptions' },
  { name: 'Deaf/Hard of Hearing', adaptations: 'Visual content emphasis, no audio dependencies' },
  { name: 'Physical Disabilities', adaptations: 'Digital-first format, voice navigation' },
];

const LANGUAGE_SAMPLES = [
  '🇪🇸 Spanish', '🇫🇷 French', '🇩🇪 German', '🇨🇳 Mandarin',
  '🇯🇵 Japanese', '🇸🇦 Arabic', '🇮🇳 Hindi', '🇷🇺 Russian',
];

export function DemoSampleBookPage({ onBack }: DemoSampleBookPageProps) {
  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--color-background)' }}>
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 px-4 py-2 rounded-lg transition"
            style={{
              backgroundColor: 'var(--color-surface)',
              color: 'var(--color-text)',
            }}
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </button>
        </div>

        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <BookOpen className="w-10 h-10" style={{ color: 'var(--color-primary)' }} />
            <h1 className="text-4xl font-bold" style={{ color: 'var(--color-text)' }}>
              Sample Book Showcase
            </h1>
          </div>
          <p className="text-lg max-w-3xl mx-auto" style={{ color: 'var(--color-textMuted)' }}>
            See everything that gets generated for a single book topic
          </p>
        </div>

        <div
          className="rounded-2xl p-8 mb-12 text-center"
          style={{
            background: `linear-gradient(135deg, var(--color-surface), var(--color-surfaceHover))`,
            borderWidth: '2px',
            borderStyle: 'solid',
            borderColor: 'var(--color-primary)',
          }}
        >
          <h2 className="text-3xl font-bold mb-2" style={{ color: 'var(--color-text)' }}>
            {SAMPLE_BOOK.title}
          </h2>
          <p className="text-lg mb-2" style={{ color: 'var(--color-accent)' }}>
            {SAMPLE_BOOK.subject}
          </p>
          <p className="text-base max-w-2xl mx-auto" style={{ color: 'var(--color-textSecondary)' }}>
            {SAMPLE_BOOK.description}
          </p>
        </div>

        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-3" style={{ color: 'var(--color-text)' }}>
            <FileText className="w-7 h-7" style={{ color: 'var(--color-primary)' }} />
            8 Reading Levels
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {READING_LEVELS.map((level) => (
              <div
                key={level.level}
                className="rounded-lg p-5 border transition"
                style={{
                  backgroundColor: 'var(--color-surface)',
                  borderColor: 'var(--color-border)',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = 'var(--color-primary)';
                  e.currentTarget.style.transform = 'translateY(-4px)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = 'var(--color-border)';
                  e.currentTarget.style.transform = 'translateY(0)';
                }}
              >
                <h3 className="font-bold mb-3 text-lg" style={{ color: 'var(--color-text)' }}>
                  {level.level}
                </h3>
                <div className="space-y-1 text-sm" style={{ color: 'var(--color-textSecondary)' }}>
                  <div className="flex justify-between">
                    <span>Words:</span>
                    <span className="font-semibold">{level.wordCount}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Pages:</span>
                    <span className="font-semibold">{level.pages}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Level:</span>
                    <span className="font-semibold">{level.complexity}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-3" style={{ color: 'var(--color-text)' }}>
            <Check className="w-7 h-7" style={{ color: 'var(--color-accent)' }} />
            8 Educational Add-ons per Level
          </h2>
          <p className="text-sm mb-6" style={{ color: 'var(--color-textMuted)' }}>
            Each reading level includes all 8 educational supplements (64 total add-ons for this book)
          </p>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {EDUCATIONAL_ADDONS.map((addon) => (
              <div
                key={addon.name}
                className="rounded-lg p-4 border"
                style={{
                  backgroundColor: 'var(--color-surface)',
                  borderColor: 'var(--color-border)',
                }}
              >
                <div className="text-3xl mb-2">{addon.icon}</div>
                <h3 className="font-bold mb-1" style={{ color: 'var(--color-text)' }}>
                  {addon.name}
                </h3>
                <p className="text-xs" style={{ color: 'var(--color-textSecondary)' }}>
                  {addon.items}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-3" style={{ color: 'var(--color-text)' }}>
            <Download className="w-7 h-7" style={{ color: 'var(--color-secondary)' }} />
            10+ Format Options
          </h2>
          <p className="text-sm mb-6" style={{ color: 'var(--color-textMuted)' }}>
            Every reading level available in multiple formats
          </p>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {FORMATS.map((format) => (
              <div
                key={format.name}
                className="rounded-lg p-4 border"
                style={{
                  backgroundColor: 'var(--color-surface)',
                  borderColor: 'var(--color-border)',
                }}
              >
                <div className="text-3xl mb-2">{format.icon}</div>
                <h3 className="font-bold mb-1" style={{ color: 'var(--color-text)' }}>
                  {format.name}
                </h3>
                <p className="text-xs" style={{ color: 'var(--color-textSecondary)' }}>
                  {format.desc}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-3" style={{ color: 'var(--color-text)' }}>
            <Eye className="w-7 h-7" style={{ color: 'var(--color-success)' }} />
            40 Disability Adaptations Available
          </h2>
          <p className="text-sm mb-6" style={{ color: 'var(--color-textMuted)' }}>
            Specialized versions adapted for specific disabilities (showing 6 examples)
          </p>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {DISABILITY_SAMPLES.map((disability) => (
              <div
                key={disability.name}
                className="rounded-lg p-4 border"
                style={{
                  backgroundColor: 'var(--color-surface)',
                  borderColor: 'var(--color-border)',
                }}
              >
                <h3 className="font-bold mb-2" style={{ color: 'var(--color-text)' }}>
                  {disability.name}
                </h3>
                <p className="text-xs" style={{ color: 'var(--color-textSecondary)' }}>
                  {disability.adaptations}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-3" style={{ color: 'var(--color-text)' }}>
            <span className="text-3xl">🌍</span>
            100+ Language Translations
          </h2>
          <p className="text-sm mb-6" style={{ color: 'var(--color-textMuted)' }}>
            Every version can be translated into 100+ languages (showing 8 examples)
          </p>
          <div className="flex flex-wrap gap-3">
            {LANGUAGE_SAMPLES.map((lang) => (
              <div
                key={lang}
                className="px-4 py-2 rounded-lg border font-medium"
                style={{
                  backgroundColor: 'var(--color-surface)',
                  borderColor: 'var(--color-border)',
                  color: 'var(--color-text)',
                }}
              >
                {lang}
              </div>
            ))}
            <div
              className="px-4 py-2 rounded-lg border font-medium"
              style={{
                backgroundColor: 'var(--color-surface)',
                borderColor: 'var(--color-primary)',
                color: 'var(--color-primary)',
              }}
            >
              + 92 more languages
            </div>
          </div>
        </div>

        <div
          className="rounded-2xl p-10 text-center"
          style={{
            background: `linear-gradient(135deg, var(--color-surface), var(--color-surfaceHover))`,
            borderWidth: '2px',
            borderStyle: 'solid',
            borderColor: 'var(--color-accent)',
          }}
        >
          <h2 className="text-3xl font-bold mb-4" style={{ color: 'var(--color-text)' }}>
            Total Generated Assets
          </h2>
          <p className="text-base mb-8 max-w-2xl mx-auto" style={{ color: 'var(--color-textMuted)' }}>
            For this single book topic, the system generates:
          </p>
          <div className="grid md:grid-cols-4 gap-6 max-w-4xl mx-auto">
            <div className="p-4 rounded-lg" style={{ backgroundColor: 'var(--color-background)' }}>
              <div className="text-4xl font-bold mb-1" style={{ color: 'var(--color-primary)' }}>
                8
              </div>
              <div className="text-sm font-medium" style={{ color: 'var(--color-textSecondary)' }}>
                Reading Levels
              </div>
            </div>
            <div className="p-4 rounded-lg" style={{ backgroundColor: 'var(--color-background)' }}>
              <div className="text-4xl font-bold mb-1" style={{ color: 'var(--color-accent)' }}>
                64
              </div>
              <div className="text-sm font-medium" style={{ color: 'var(--color-textSecondary)' }}>
                Educational Add-ons
              </div>
            </div>
            <div className="p-4 rounded-lg" style={{ backgroundColor: 'var(--color-background)' }}>
              <div className="text-4xl font-bold mb-1" style={{ color: 'var(--color-secondary)' }}>
                80+
              </div>
              <div className="text-sm font-medium" style={{ color: 'var(--color-textSecondary)' }}>
                Format Variants
              </div>
            </div>
            <div className="p-4 rounded-lg" style={{ backgroundColor: 'var(--color-background)' }}>
              <div className="text-4xl font-bold mb-1" style={{ color: 'var(--color-success)' }}>
                320
              </div>
              <div className="text-sm font-medium" style={{ color: 'var(--color-textSecondary)' }}>
                Disability Adaptations
              </div>
            </div>
          </div>
          <p className="text-sm mt-6" style={{ color: 'var(--color-textMuted)' }}>
            Each of these can be translated into 100+ languages, creating thousands of unique educational resources from a single topic
          </p>
        </div>
      </div>
    </div>
  );
}
