import { useState } from 'react';
import {
  Award,
  BookOpen,
  Shield,
  Users,
  FileText,
  Palette,
  Download,
  CheckCircle,
  AlertCircle,
  Loader
} from 'lucide-react';
import {
  scoutContentTypes,
  meritBadgeCategories,
  scoutRanks,
  scoutPrograms,
  scoutDesignThemes,
  scoutOutputFormats,
  scoutWorkflowSteps,
  type ScoutContentType,
  type ScoutsGenerationWorkflow
} from '../config/scoutsPipeline';

export function ScoutsGenerationPage() {
  const [step, setStep] = useState(1);
  const [selectedContentType, setSelectedContentType] = useState<ScoutContentType | null>(null);
  const [category, setCategory] = useState('');
  const [requirements, setRequirements] = useState<Record<string, any>>({});
  const [designTheme, setDesignTheme] = useState('classic-scout');
  const [selectedFormats, setSelectedFormats] = useState<string[]>(['pdf-print']);
  const [generating, setGenerating] = useState(false);
  const [currentWorkflowStep, setCurrentWorkflowStep] = useState(0);

  const totalSteps = 5;

  const handleContentTypeSelect = (contentType: ScoutContentType) => {
    setSelectedContentType(contentType);
    setStep(2);
  };

  const handleFormatToggle = (formatId: string) => {
    setSelectedFormats(prev =>
      prev.includes(formatId)
        ? prev.filter(f => f !== formatId)
        : [...prev, formatId]
    );
  };

  const handleGenerate = async () => {
    if (!selectedContentType) return;

    setGenerating(true);
    setCurrentWorkflowStep(0);

    for (let i = 0; i < scoutWorkflowSteps.length; i++) {
      setCurrentWorkflowStep(i);
      await new Promise(resolve => setTimeout(resolve, 2000));
    }

    setGenerating(false);
    alert('Scout content generated successfully!');
  };

  const estimateTokens = () => {
    if (!selectedContentType) return 0;
    return selectedContentType.estimatedPages * 500 * selectedFormats.length;
  };

  const estimateCost = () => {
    return (estimateTokens() / 1000) * 0.015;
  };

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-4">
          <div
            className="p-3 rounded-lg"
            style={{ backgroundColor: 'var(--color-primary)' }}
          >
            <Shield className="w-8 h-8" style={{ color: 'var(--color-background)' }} />
          </div>
          <div>
            <h1 className="text-3xl font-bold" style={{ color: 'var(--color-text)' }}>
              Scouts Content Generation
            </h1>
            <p style={{ color: 'var(--color-textMuted)' }}>
              Create merit badges, handbooks, training materials, and more
            </p>
          </div>
        </div>

        <div
          className="p-4 rounded-lg border mb-6"
          style={{
            backgroundColor: 'var(--color-surface)',
            borderColor: 'var(--color-border)',
          }}
        >
          <div className="flex items-center gap-2 mb-2">
            <AlertCircle className="w-5 h-5" style={{ color: 'var(--color-warning)' }} />
            <span className="font-semibold" style={{ color: 'var(--color-text)' }}>
              Admin Only Feature
            </span>
          </div>
          <p style={{ color: 'var(--color-textMuted)' }}>
            Scout content generation is restricted to administrators. All generated materials
            follow official scouting guidelines and standards.
          </p>
        </div>

        <div className="flex gap-2 mb-6">
          {Array.from({ length: totalSteps }, (_, i) => (
            <div
              key={i}
              className="flex-1 h-2 rounded-full"
              style={{
                backgroundColor:
                  step > i ? 'var(--color-primary)' : 'var(--color-border)',
              }}
            />
          ))}
        </div>
      </div>

      {step === 1 && (
        <div>
          <h2 className="text-2xl font-bold mb-4" style={{ color: 'var(--color-text)' }}>
            Select Content Type
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {scoutContentTypes.map((contentType) => (
              <button
                key={contentType.id}
                onClick={() => handleContentTypeSelect(contentType)}
                className="p-6 rounded-lg border text-left transition-all hover:scale-105"
                style={{
                  backgroundColor: 'var(--color-surface)',
                  borderColor: 'var(--color-border)',
                }}
              >
                <div className="flex items-start gap-3 mb-3">
                  {contentType.category === 'merit-badge' && (
                    <Award className="w-6 h-6" style={{ color: 'var(--color-primary)' }} />
                  )}
                  {contentType.category === 'handbook' && (
                    <BookOpen className="w-6 h-6" style={{ color: 'var(--color-primary)' }} />
                  )}
                  {contentType.category === 'training' && (
                    <Users className="w-6 h-6" style={{ color: 'var(--color-primary)' }} />
                  )}
                  {contentType.category === 'insignia' && (
                    <Shield className="w-6 h-6" style={{ color: 'var(--color-primary)' }} />
                  )}
                  {contentType.category === 'resource' && (
                    <FileText className="w-6 h-6" style={{ color: 'var(--color-primary)' }} />
                  )}
                  <div className="flex-1">
                    <h3 className="font-semibold mb-1" style={{ color: 'var(--color-text)' }}>
                      {contentType.name}
                    </h3>
                    <p className="text-sm mb-2" style={{ color: 'var(--color-textMuted)' }}>
                      {contentType.description}
                    </p>
                    <div className="flex items-center gap-3 text-xs">
                      <span
                        className="px-2 py-1 rounded"
                        style={{
                          backgroundColor: 'var(--color-primary)',
                          color: 'var(--color-background)',
                        }}
                      >
                        {contentType.estimatedPages} pages
                      </span>
                      <span style={{ color: 'var(--color-textMuted)' }}>
                        {contentType.difficultyLevel}
                      </span>
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {step === 2 && selectedContentType && (
        <div>
          <h2 className="text-2xl font-bold mb-4" style={{ color: 'var(--color-text)' }}>
            Content Details
          </h2>
          <div
            className="p-6 rounded-lg border mb-6"
            style={{
              backgroundColor: 'var(--color-surface)',
              borderColor: 'var(--color-border)',
            }}
          >
            <div className="mb-4">
              <label className="block mb-2 font-semibold" style={{ color: 'var(--color-text)' }}>
                Content Name
              </label>
              <input
                type="text"
                placeholder="e.g., Camping Merit Badge"
                className="w-full px-4 py-2 rounded-lg border"
                style={{
                  backgroundColor: 'var(--color-background)',
                  borderColor: 'var(--color-border)',
                  color: 'var(--color-text)',
                }}
                onChange={(e) =>
                  setRequirements({ ...requirements, name: e.target.value })
                }
              />
            </div>

            {selectedContentType.category === 'merit-badge' && (
              <div className="mb-4">
                <label className="block mb-2 font-semibold" style={{ color: 'var(--color-text)' }}>
                  Badge Category
                </label>
                <select
                  className="w-full px-4 py-2 rounded-lg border"
                  style={{
                    backgroundColor: 'var(--color-background)',
                    borderColor: 'var(--color-border)',
                    color: 'var(--color-text)',
                  }}
                  onChange={(e) => setCategory(e.target.value)}
                  value={category}
                >
                  <option value="">Select category...</option>
                  {meritBadgeCategories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {selectedContentType.category === 'handbook' && (
              <div className="mb-4">
                <label className="block mb-2 font-semibold" style={{ color: 'var(--color-text)' }}>
                  Scout Program
                </label>
                <select
                  className="w-full px-4 py-2 rounded-lg border"
                  style={{
                    backgroundColor: 'var(--color-background)',
                    borderColor: 'var(--color-border)',
                    color: 'var(--color-text)',
                  }}
                  onChange={(e) =>
                    setRequirements({ ...requirements, program: e.target.value })
                  }
                >
                  <option value="">Select program...</option>
                  {scoutPrograms.map((program) => (
                    <option key={program} value={program}>
                      {program}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div className="mb-4">
              <label className="block mb-2 font-semibold" style={{ color: 'var(--color-text)' }}>
                Additional Details
              </label>
              <textarea
                rows={4}
                placeholder="Provide specific requirements, objectives, or special instructions..."
                className="w-full px-4 py-2 rounded-lg border"
                style={{
                  backgroundColor: 'var(--color-background)',
                  borderColor: 'var(--color-border)',
                  color: 'var(--color-text)',
                }}
                onChange={(e) =>
                  setRequirements({ ...requirements, details: e.target.value })
                }
              />
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setStep(1)}
                className="px-6 py-2 rounded-lg"
                style={{
                  backgroundColor: 'var(--color-surface)',
                  color: 'var(--color-text)',
                  border: '1px solid var(--color-border)',
                }}
              >
                Back
              </button>
              <button
                onClick={() => setStep(3)}
                className="px-6 py-2 rounded-lg"
                style={{
                  backgroundColor: 'var(--color-primary)',
                  color: 'var(--color-background)',
                }}
              >
                Continue
              </button>
            </div>
          </div>
        </div>
      )}

      {step === 3 && (
        <div>
          <h2 className="text-2xl font-bold mb-4" style={{ color: 'var(--color-text)' }}>
            Design Theme
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
            {scoutDesignThemes.map((theme) => (
              <button
                key={theme.id}
                onClick={() => setDesignTheme(theme.id)}
                className="p-6 rounded-lg border text-left transition-all"
                style={{
                  backgroundColor:
                    designTheme === theme.id
                      ? 'var(--color-primary)'
                      : 'var(--color-surface)',
                  borderColor:
                    designTheme === theme.id
                      ? 'var(--color-primary)'
                      : 'var(--color-border)',
                  color:
                    designTheme === theme.id
                      ? 'var(--color-background)'
                      : 'var(--color-text)',
                }}
              >
                <div className="flex items-center gap-2 mb-3">
                  <Palette className="w-5 h-5" />
                  <h3 className="font-semibold">{theme.name}</h3>
                </div>
                <p className="text-sm mb-3 opacity-90">{theme.description}</p>
                <div className="flex gap-2">
                  {theme.colors.map((color, idx) => (
                    <div
                      key={idx}
                      className="w-8 h-8 rounded"
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </button>
            ))}
          </div>
          <div className="flex gap-3">
            <button
              onClick={() => setStep(2)}
              className="px-6 py-2 rounded-lg"
              style={{
                backgroundColor: 'var(--color-surface)',
                color: 'var(--color-text)',
                border: '1px solid var(--color-border)',
              }}
            >
              Back
            </button>
            <button
              onClick={() => setStep(4)}
              className="px-6 py-2 rounded-lg"
              style={{
                backgroundColor: 'var(--color-primary)',
                color: 'var(--color-background)',
              }}
            >
              Continue
            </button>
          </div>
        </div>
      )}

      {step === 4 && (
        <div>
          <h2 className="text-2xl font-bold mb-4" style={{ color: 'var(--color-text)' }}>
            Output Formats
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            {scoutOutputFormats.map((format) => (
              <button
                key={format.id}
                onClick={() => handleFormatToggle(format.id)}
                className="p-4 rounded-lg border text-left transition-all"
                style={{
                  backgroundColor: selectedFormats.includes(format.id)
                    ? 'var(--color-primary)'
                    : 'var(--color-surface)',
                  borderColor: selectedFormats.includes(format.id)
                    ? 'var(--color-primary)'
                    : 'var(--color-border)',
                  color: selectedFormats.includes(format.id)
                    ? 'var(--color-background)'
                    : 'var(--color-text)',
                }}
              >
                <div className="flex items-center gap-3">
                  {selectedFormats.includes(format.id) ? (
                    <CheckCircle className="w-5 h-5" />
                  ) : (
                    <Download className="w-5 h-5" />
                  )}
                  <div>
                    <h3 className="font-semibold">{format.name}</h3>
                    <p className="text-sm opacity-90">{format.description}</p>
                  </div>
                </div>
              </button>
            ))}
          </div>
          <div className="flex gap-3">
            <button
              onClick={() => setStep(3)}
              className="px-6 py-2 rounded-lg"
              style={{
                backgroundColor: 'var(--color-surface)',
                color: 'var(--color-text)',
                border: '1px solid var(--color-border)',
              }}
            >
              Back
            </button>
            <button
              onClick={() => setStep(5)}
              className="px-6 py-2 rounded-lg"
              style={{
                backgroundColor: 'var(--color-primary)',
                color: 'var(--color-background)',
              }}
            >
              Continue
            </button>
          </div>
        </div>
      )}

      {step === 5 && (
        <div>
          <h2 className="text-2xl font-bold mb-4" style={{ color: 'var(--color-text)' }}>
            Review & Generate
          </h2>
          <div
            className="p-6 rounded-lg border mb-6"
            style={{
              backgroundColor: 'var(--color-surface)',
              borderColor: 'var(--color-border)',
            }}
          >
            <h3 className="text-lg font-semibold mb-4" style={{ color: 'var(--color-text)' }}>
              Generation Summary
            </h3>
            <div className="space-y-3 mb-6">
              <div className="flex justify-between">
                <span style={{ color: 'var(--color-textMuted)' }}>Content Type:</span>
                <span style={{ color: 'var(--color-text)' }}>{selectedContentType?.name}</span>
              </div>
              <div className="flex justify-between">
                <span style={{ color: 'var(--color-textMuted)' }}>Design Theme:</span>
                <span style={{ color: 'var(--color-text)' }}>
                  {scoutDesignThemes.find((t) => t.id === designTheme)?.name}
                </span>
              </div>
              <div className="flex justify-between">
                <span style={{ color: 'var(--color-textMuted)' }}>Output Formats:</span>
                <span style={{ color: 'var(--color-text)' }}>
                  {selectedFormats.length} selected
                </span>
              </div>
              <div className="flex justify-between">
                <span style={{ color: 'var(--color-textMuted)' }}>Estimated Tokens:</span>
                <span style={{ color: 'var(--color-text)' }}>
                  {estimateTokens().toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between">
                <span style={{ color: 'var(--color-textMuted)' }}>Estimated Cost:</span>
                <span style={{ color: 'var(--color-text)' }}>
                  ${estimateCost().toFixed(2)}
                </span>
              </div>
            </div>

            {generating && (
              <div className="mb-6">
                <div className="flex items-center gap-3 mb-3">
                  <Loader className="w-5 h-5 animate-spin" style={{ color: 'var(--color-primary)' }} />
                  <span className="font-semibold" style={{ color: 'var(--color-text)' }}>
                    {scoutWorkflowSteps[currentWorkflowStep]?.name}
                  </span>
                </div>
                <div className="w-full h-2 rounded-full" style={{ backgroundColor: 'var(--color-border)' }}>
                  <div
                    className="h-2 rounded-full transition-all"
                    style={{
                      backgroundColor: 'var(--color-primary)',
                      width: `${((currentWorkflowStep + 1) / scoutWorkflowSteps.length) * 100}%`,
                    }}
                  />
                </div>
              </div>
            )}

            <div className="flex gap-3">
              <button
                onClick={() => setStep(4)}
                disabled={generating}
                className="px-6 py-2 rounded-lg"
                style={{
                  backgroundColor: 'var(--color-surface)',
                  color: 'var(--color-text)',
                  border: '1px solid var(--color-border)',
                  opacity: generating ? 0.5 : 1,
                }}
              >
                Back
              </button>
              <button
                onClick={handleGenerate}
                disabled={generating}
                className="px-6 py-2 rounded-lg flex items-center gap-2"
                style={{
                  backgroundColor: 'var(--color-primary)',
                  color: 'var(--color-background)',
                  opacity: generating ? 0.5 : 1,
                }}
              >
                {generating ? (
                  <>
                    <Loader className="w-5 h-5 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <CheckCircle className="w-5 h-5" />
                    Generate Content
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
