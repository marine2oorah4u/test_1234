import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import {
  Workflow, Plus, Edit2, Trash2, Copy, Save, X,
  ChevronDown, ChevronRight, Settings, Play
} from 'lucide-react';

interface WorkflowTemplate {
  id: string;
  name: string;
  category: string;
  subcategory?: string;
  description?: string;
  estimated_tokens: number;
  estimated_cost: number;
  estimated_duration_minutes: number;
}

interface WorkflowStep {
  id: string;
  workflow_template_id: string;
  step_number: number;
  name: string;
  description?: string;
  step_type: string;
  prompt_template?: string;
  system_instructions?: string;
  estimated_tokens: number;
  min_quality_threshold: number;
  max_retries: number;
}

export function WorkflowEditorPage() {
  const [workflows, setWorkflows] = useState<WorkflowTemplate[]>([]);
  const [selectedWorkflow, setSelectedWorkflow] = useState<string | null>(null);
  const [steps, setSteps] = useState<WorkflowStep[]>([]);
  const [expandedSteps, setExpandedSteps] = useState<Set<string>>(new Set());
  const [editingStep, setEditingStep] = useState<WorkflowStep | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadWorkflows();
  }, []);

  useEffect(() => {
    if (selectedWorkflow) {
      loadSteps(selectedWorkflow);
    }
  }, [selectedWorkflow]);

  const loadWorkflows = async () => {
    try {
      const { data, error } = await supabase
        .from('workflow_templates')
        .select('*')
        .eq('is_active', true)
        .order('category', { ascending: true });

      if (error) throw error;
      setWorkflows(data || []);
    } catch (err) {
      console.error('Error loading workflows:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadSteps = async (workflowId: string) => {
    try {
      const { data, error } = await supabase
        .from('workflow_steps')
        .select('*')
        .eq('workflow_template_id', workflowId)
        .order('step_number', { ascending: true });

      if (error) throw error;
      setSteps(data || []);
    } catch (err) {
      console.error('Error loading steps:', err);
    }
  };

  const createWorkflow = async () => {
    const name = prompt('Enter workflow name:');
    if (!name) return;

    const category = prompt('Enter category (e.g., addon, base_book, format_conversion):');
    if (!category) return;

    try {
      const { data, error } = await supabase
        .from('workflow_templates')
        .insert({
          name,
          category,
          description: '',
          estimated_tokens: 0,
          estimated_cost: 0,
          estimated_duration_minutes: 0,
        })
        .select()
        .single();

      if (error) throw error;
      loadWorkflows();
      setSelectedWorkflow(data.id);
    } catch (err: any) {
      alert('Error creating workflow: ' + err.message);
    }
  };

  const deleteWorkflow = async (id: string) => {
    if (!confirm('Delete this workflow and all its steps?')) return;

    try {
      const { error } = await supabase
        .from('workflow_templates')
        .delete()
        .eq('id', id);

      if (error) throw error;
      loadWorkflows();
      if (selectedWorkflow === id) {
        setSelectedWorkflow(null);
        setSteps([]);
      }
    } catch (err: any) {
      alert('Error deleting workflow: ' + err.message);
    }
  };

  const addStep = async () => {
    if (!selectedWorkflow) return;

    const name = prompt('Enter step name:');
    if (!name) return;

    const stepType = prompt('Enter step type (research, generation, verification, refinement, formatting):');
    if (!stepType) return;

    try {
      const maxStep = steps.length > 0 ? Math.max(...steps.map(s => s.step_number)) : 0;

      const { error } = await supabase
        .from('workflow_steps')
        .insert({
          workflow_template_id: selectedWorkflow,
          step_number: maxStep + 1,
          name,
          step_type: stepType,
          description: '',
          prompt_template: '',
          system_instructions: '',
          estimated_tokens: 0,
          min_quality_threshold: 0.80,
          max_retries: 3,
        });

      if (error) throw error;
      loadSteps(selectedWorkflow);
    } catch (err: any) {
      alert('Error adding step: ' + err.message);
    }
  };

  const saveStep = async (step: WorkflowStep) => {
    try {
      const { error } = await supabase
        .from('workflow_steps')
        .update({
          name: step.name,
          description: step.description,
          prompt_template: step.prompt_template,
          system_instructions: step.system_instructions,
          estimated_tokens: step.estimated_tokens,
          min_quality_threshold: step.min_quality_threshold,
          max_retries: step.max_retries,
        })
        .eq('id', step.id);

      if (error) throw error;
      setEditingStep(null);
      loadSteps(selectedWorkflow!);
    } catch (err: any) {
      alert('Error saving step: ' + err.message);
    }
  };

  const deleteStep = async (id: string) => {
    if (!confirm('Delete this step?')) return;

    try {
      const { error} = await supabase
        .from('workflow_steps')
        .delete()
        .eq('id', id);

      if (error) throw error;
      loadSteps(selectedWorkflow!);
    } catch (err: any) {
      alert('Error deleting step: ' + err.message);
    }
  };

  const toggleStepExpanded = (id: string) => {
    const newExpanded = new Set(expandedSteps);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedSteps(newExpanded);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Workflow className="w-12 h-12 text-blue-600 animate-pulse" />
      </div>
    );
  }

  const selectedWorkflowData = workflows.find(w => w.id === selectedWorkflow);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Workflow Editor</h1>
          <p className="text-gray-600 mt-2">Configure every step of every pipeline and addon</p>
        </div>
          <button
            onClick={createWorkflow}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
          >
            <Plus className="w-4 h-4" />
            New Workflow
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <h2 className="font-bold text-gray-900 mb-4">Workflows</h2>
            <div className="space-y-2">
              {workflows.map(workflow => (
                <button
                  key={workflow.id}
                  onClick={() => setSelectedWorkflow(workflow.id)}
                  className={`w-full text-left px-4 py-3 rounded-lg transition ${
                    selectedWorkflow === workflow.id
                      ? 'bg-blue-50 border-2 border-blue-600'
                      : 'bg-gray-50 border-2 border-transparent hover:bg-gray-100'
                  }`}
                >
                  <div className="font-medium text-gray-900">{workflow.name}</div>
                  <div className="text-xs text-gray-500 mt-1">{workflow.category}</div>
                  <div className="flex items-center justify-between mt-2 text-xs text-gray-600">
                    <span>{workflow.estimated_tokens.toLocaleString()} tokens</span>
                    <span>${workflow.estimated_cost.toFixed(2)}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div className="lg:col-span-2 space-y-4">
            {selectedWorkflowData ? (
              <>
                <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h2 className="text-2xl font-bold text-gray-900">{selectedWorkflowData.name}</h2>
                      <p className="text-sm text-gray-600 mt-1">{selectedWorkflowData.category}</p>
                    </div>
                    <button
                      onClick={() => deleteWorkflow(selectedWorkflowData.id)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <div className="text-gray-600">Est. Tokens</div>
                      <div className="font-medium text-gray-900">{selectedWorkflowData.estimated_tokens.toLocaleString()}</div>
                    </div>
                    <div>
                      <div className="text-gray-600">Est. Cost</div>
                      <div className="font-medium text-gray-900">${selectedWorkflowData.estimated_cost.toFixed(2)}</div>
                    </div>
                    <div>
                      <div className="text-gray-600">Est. Duration</div>
                      <div className="font-medium text-gray-900">{selectedWorkflowData.estimated_duration_minutes} min</div>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-bold text-gray-900">Pipeline Steps ({steps.length})</h3>
                    <button
                      onClick={addStep}
                      className="flex items-center gap-2 px-3 py-1.5 bg-green-600 text-white rounded-lg hover:bg-green-700 transition text-sm"
                    >
                      <Plus className="w-4 h-4" />
                      Add Step
                    </button>
                  </div>

                  <div className="space-y-3">
                    {steps.map(step => (
                      <div key={step.id} className="border border-gray-200 rounded-lg">
                        <div
                          className="flex items-center justify-between p-4 cursor-pointer hover:bg-gray-50"
                          onClick={() => toggleStepExpanded(step.id)}
                        >
                          <div className="flex items-center gap-3">
                            {expandedSteps.has(step.id) ? (
                              <ChevronDown className="w-5 h-5 text-gray-400" />
                            ) : (
                              <ChevronRight className="w-5 h-5 text-gray-400" />
                            )}
                            <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-bold text-sm">
                              {step.step_number}
                            </div>
                            <div>
                              <div className="font-medium text-gray-900">{step.name}</div>
                              <div className="text-xs text-gray-500">{step.step_type}</div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setEditingStep(step);
                              }}
                              className="p-1.5 text-blue-600 hover:bg-blue-50 rounded"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                deleteStep(step.id);
                              }}
                              className="p-1.5 text-red-600 hover:bg-red-50 rounded"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>

                        {expandedSteps.has(step.id) && (
                          <div className="border-t border-gray-200 p-4 bg-gray-50 space-y-3">
                            <div>
                              <div className="text-xs font-medium text-gray-700 mb-1">Description</div>
                              <div className="text-sm text-gray-600">{step.description || 'No description'}</div>
                            </div>
                            <div>
                              <div className="text-xs font-medium text-gray-700 mb-1">Prompt Template</div>
                              <div className="text-sm text-gray-600 font-mono bg-white p-2 rounded border border-gray-200">
                                {step.prompt_template || 'No prompt template'}
                              </div>
                            </div>
                            <div className="grid grid-cols-3 gap-3 text-sm">
                              <div>
                                <div className="text-xs text-gray-600">Tokens</div>
                                <div className="font-medium">{step.estimated_tokens}</div>
                              </div>
                              <div>
                                <div className="text-xs text-gray-600">Quality</div>
                                <div className="font-medium">{(step.min_quality_threshold * 100).toFixed(0)}%</div>
                              </div>
                              <div>
                                <div className="text-xs text-gray-600">Retries</div>
                                <div className="font-medium">{step.max_retries}</div>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </>
            ) : (
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-12 text-center text-gray-500">
                <Workflow className="w-16 h-16 mx-auto mb-4 opacity-50" />
                <p>Select a workflow to view and edit its steps</p>
              </div>
            )}
          </div>
        </div>

      {editingStep && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-900">Edit Step</h3>
              <button
                onClick={() => setEditingStep(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Step Name</label>
                <input
                  type="text"
                  value={editingStep.name}
                  onChange={(e) => setEditingStep({ ...editingStep, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea
                  value={editingStep.description || ''}
                  onChange={(e) => setEditingStep({ ...editingStep, description: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  rows={3}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Prompt Template</label>
                <textarea
                  value={editingStep.prompt_template || ''}
                  onChange={(e) => setEditingStep({ ...editingStep, prompt_template: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg font-mono text-sm"
                  rows={6}
                  placeholder="Enter the AI prompt template for this step..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">System Instructions</label>
                <textarea
                  value={editingStep.system_instructions || ''}
                  onChange={(e) => setEditingStep({ ...editingStep, system_instructions: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg font-mono text-sm"
                  rows={4}
                  placeholder="Enter system instructions for the AI..."
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Est. Tokens</label>
                  <input
                    type="number"
                    value={editingStep.estimated_tokens}
                    onChange={(e) => setEditingStep({ ...editingStep, estimated_tokens: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Quality Threshold</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    max="1"
                    value={editingStep.min_quality_threshold}
                    onChange={(e) => setEditingStep({ ...editingStep, min_quality_threshold: parseFloat(e.target.value) || 0.8 })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Max Retries</label>
                  <input
                    type="number"
                    value={editingStep.max_retries}
                    onChange={(e) => setEditingStep({ ...editingStep, max_retries: parseInt(e.target.value) || 3 })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  />
                </div>
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setEditingStep(null)}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition"
              >
                Cancel
              </button>
              <button
                onClick={() => saveStep(editingStep)}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition flex items-center justify-center gap-2"
              >
                <Save className="w-4 h-4" />
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
