import { useState } from 'react';
import { PipelineNavigation, PIPELINES } from '../components/PipelineNavigation';
import {
  Settings,
  Play,
  Pause,
  GitBranch,
  CheckSquare,
  FileOutput,
  Save,
  RefreshCw,
  Info
} from 'lucide-react';

export function PipelineManagementPage() {
  const [activePipeline, setActivePipeline] = useState('base-book');

  const currentPipeline = PIPELINES.find(p => p.id === activePipeline);

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2" style={{ color: 'var(--color-text)' }}>
          Pipeline Management
        </h1>
        <p style={{ color: 'var(--color-textMuted)' }}>
          Configure and manage content generation pipelines
        </p>
      </div>

      <PipelineNavigation
        activePipeline={activePipeline}
        onPipelineChange={setActivePipeline}
      />

      {currentPipeline && (
        <>
          <div
            className="rounded-xl shadow-sm border p-6"
            style={{
              backgroundColor: 'var(--color-surface)',
              borderColor: 'var(--color-border)',
            }}
          >
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-center gap-3">
                <div
                  className="p-3 rounded-lg"
                  style={{
                    backgroundColor: 'var(--color-primary)',
                    opacity: 0.1,
                  }}
                >
                  <currentPipeline.icon
                    className="w-6 h-6"
                    style={{ color: 'var(--color-primary)', opacity: 1 }}
                  />
                </div>
                <div>
                  <h2 className="text-2xl font-bold" style={{ color: 'var(--color-text)' }}>
                    {currentPipeline.name}
                  </h2>
                  <p style={{ color: 'var(--color-textMuted)' }}>
                    {currentPipeline.description}
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  className="px-4 py-2 rounded-lg flex items-center gap-2 transition-all"
                  style={{
                    backgroundColor: 'var(--color-primary)',
                    color: 'var(--color-background)',
                  }}
                >
                  <Play className="w-4 h-4" />
                  Run Pipeline
                </button>
                <button
                  className="px-4 py-2 rounded-lg border transition-all"
                  style={{
                    borderColor: 'var(--color-border)',
                    color: 'var(--color-text)',
                  }}
                >
                  <Settings className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div
                className="p-4 rounded-lg border"
                style={{
                  backgroundColor: 'var(--color-background)',
                  borderColor: 'var(--color-border)',
                }}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
                    Status
                  </span>
                  <div
                    className="w-2 h-2 rounded-full"
                    style={{ backgroundColor: 'var(--color-success)' }}
                  />
                </div>
                <div className="text-lg font-semibold" style={{ color: 'var(--color-text)' }}>
                  Ready
                </div>
              </div>

              <div
                className="p-4 rounded-lg border"
                style={{
                  backgroundColor: 'var(--color-background)',
                  borderColor: 'var(--color-border)',
                }}
              >
                <div className="text-sm mb-2" style={{ color: 'var(--color-textMuted)' }}>
                  Last Run
                </div>
                <div className="text-lg font-semibold" style={{ color: 'var(--color-text)' }}>
                  Never
                </div>
              </div>

              <div
                className="p-4 rounded-lg border"
                style={{
                  backgroundColor: 'var(--color-background)',
                  borderColor: 'var(--color-border)',
                }}
              >
                <div className="text-sm mb-2" style={{ color: 'var(--color-textMuted)' }}>
                  Total Runs
                </div>
                <div className="text-lg font-semibold" style={{ color: 'var(--color-text)' }}>
                  0
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div
              className="rounded-xl shadow-sm border p-6"
              style={{
                backgroundColor: 'var(--color-surface)',
                borderColor: 'var(--color-border)',
              }}
            >
              <div className="flex items-center gap-2 mb-4">
                <Settings className="w-5 h-5" style={{ color: 'var(--color-primary)' }} />
                <h3 className="text-lg font-bold" style={{ color: 'var(--color-text)' }}>
                  Configuration
                </h3>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--color-text)' }}>
                    Pipeline Mode
                  </label>
                  <select
                    className="w-full px-4 py-2 rounded-lg border"
                    style={{
                      backgroundColor: 'var(--color-background)',
                      borderColor: 'var(--color-border)',
                      color: 'var(--color-text)',
                    }}
                  >
                    <option>Standard</option>
                    <option>High Quality</option>
                    <option>Fast</option>
                    <option>Cost Optimized</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--color-text)' }}>
                    AI Model Selection
                  </label>
                  <select
                    className="w-full px-4 py-2 rounded-lg border"
                    style={{
                      backgroundColor: 'var(--color-background)',
                      borderColor: 'var(--color-border)',
                      color: 'var(--color-text)',
                    }}
                  >
                    <option>Auto-Select Best</option>
                    <option>GPT-4 Priority</option>
                    <option>Claude Priority</option>
                    <option>Cost Optimized Mix</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--color-text)' }}>
                    Quality Threshold
                  </label>
                  <input
                    type="range"
                    min="1"
                    max="100"
                    defaultValue="80"
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs mt-1" style={{ color: 'var(--color-textMuted)' }}>
                    <span>Fast</span>
                    <span>Balanced</span>
                    <span>Maximum</span>
                  </div>
                </div>

                <div className="flex items-center justify-between p-3 rounded-lg" style={{ backgroundColor: 'var(--color-background)' }}>
                  <span className="text-sm" style={{ color: 'var(--color-text)' }}>Enable Auto-Retry</span>
                  <input type="checkbox" defaultChecked className="w-4 h-4" />
                </div>

                <div className="flex items-center justify-between p-3 rounded-lg" style={{ backgroundColor: 'var(--color-background)' }}>
                  <span className="text-sm" style={{ color: 'var(--color-text)' }}>Parallel Processing</span>
                  <input type="checkbox" defaultChecked className="w-4 h-4" />
                </div>

                <button
                  className="w-full px-4 py-3 rounded-lg flex items-center justify-center gap-2 transition-all"
                  style={{
                    backgroundColor: 'var(--color-primary)',
                    color: 'var(--color-background)',
                  }}
                >
                  <Save className="w-4 h-4" />
                  Save Configuration
                </button>
              </div>
            </div>

            <div
              className="rounded-xl shadow-sm border p-6"
              style={{
                backgroundColor: 'var(--color-surface)',
                borderColor: 'var(--color-border)',
              }}
            >
              <div className="flex items-center gap-2 mb-4">
                <GitBranch className="w-5 h-5" style={{ color: 'var(--color-primary)' }} />
                <h3 className="text-lg font-bold" style={{ color: 'var(--color-text)' }}>
                  Workflow Steps
                </h3>
              </div>
              <div className="space-y-3">
                {[
                  { step: 1, name: 'Input Validation', status: 'configured' },
                  { step: 2, name: 'Research & Context', status: 'configured' },
                  { step: 3, name: 'Content Generation', status: 'configured' },
                  { step: 4, name: 'Quality Review', status: 'configured' },
                  { step: 5, name: 'Formatting', status: 'configured' },
                  { step: 6, name: 'Output Generation', status: 'configured' },
                ].map((item) => (
                  <div
                    key={item.step}
                    className="flex items-center justify-between p-3 rounded-lg border"
                    style={{
                      backgroundColor: 'var(--color-background)',
                      borderColor: 'var(--color-border)',
                    }}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold"
                        style={{
                          backgroundColor: 'var(--color-primary)',
                          color: 'var(--color-background)',
                        }}
                      >
                        {item.step}
                      </div>
                      <span className="font-medium" style={{ color: 'var(--color-text)' }}>
                        {item.name}
                      </span>
                    </div>
                    <CheckSquare className="w-5 h-5" style={{ color: 'var(--color-success)' }} />
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div
            className="rounded-xl shadow-sm border p-6"
            style={{
              backgroundColor: 'var(--color-surface)',
              borderColor: 'var(--color-border)',
            }}
          >
            <div className="flex items-center gap-2 mb-4">
              <FileOutput className="w-5 h-5" style={{ color: 'var(--color-primary)' }} />
              <h3 className="text-lg font-bold" style={{ color: 'var(--color-text)' }}>
                Output Specifications
              </h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--color-text)' }}>
                  Output Format
                </label>
                <select
                  className="w-full px-4 py-2 rounded-lg border"
                  style={{
                    backgroundColor: 'var(--color-background)',
                    borderColor: 'var(--color-border)',
                    color: 'var(--color-text)',
                  }}
                >
                  <option>JSON</option>
                  <option>Markdown</option>
                  <option>HTML</option>
                  <option>PDF</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--color-text)' }}>
                  Storage Location
                </label>
                <select
                  className="w-full px-4 py-2 rounded-lg border"
                  style={{
                    backgroundColor: 'var(--color-background)',
                    borderColor: 'var(--color-border)',
                    color: 'var(--color-text)',
                  }}
                >
                  <option>Supabase Storage</option>
                  <option>Local Cache</option>
                  <option>Both</option>
                </select>
              </div>
            </div>
          </div>

          <div
            className="rounded-xl border p-4 flex items-start gap-3"
            style={{
              backgroundColor: 'var(--color-background)',
              borderColor: 'var(--color-primary)',
            }}
          >
            <Info className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: 'var(--color-primary)' }} />
            <div>
              <div className="font-semibold mb-1" style={{ color: 'var(--color-text)' }}>
                Pipeline Blueprint
              </div>
              <p className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
                This pipeline is configured and ready to run. Each step has been validated and AI models are assigned.
                Click "Run Pipeline" to start generation or adjust settings above to customize behavior.
              </p>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
