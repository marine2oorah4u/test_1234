import { useState } from 'react';
import { ArrowLeft, Server, Database, Cpu, Mic, Image as ImageIcon, Globe, HardDrive } from 'lucide-react';

interface DemoResourcesPageProps {
  onBack: () => void;
}

type ResourceCategory = 'ai-apis' | 'cloud-storage' | 'audio' | 'image' | 'compute' | 'database';

interface ResourceOption {
  name: string;
  tier: string;
  cost: string;
  specs: string[];
  performance: 'Basic' | 'Standard' | 'Professional' | 'Enterprise';
  notes: string;
}

interface Resource {
  id: ResourceCategory;
  title: string;
  icon: any;
  description: string;
  why: string;
  options: ResourceOption[];
}

const RESOURCES: Resource[] = [
  {
    id: 'ai-apis',
    title: 'AI Content Generation APIs',
    icon: Cpu,
    description: 'APIs for generating book content, summaries, and educational materials',
    why: 'AI models are needed to generate high-quality educational content at scale. Different models have different strengths for various content types.',
    options: [
      {
        name: 'OpenAI GPT-3.5',
        tier: 'Basic',
        cost: '$0.002 per 1K tokens',
        specs: ['4K context window', 'Fast response', 'Good for simple content'],
        performance: 'Standard',
        notes: 'Cost-effective for basic content generation. Good starting point for proof of concept.'
      },
      {
        name: 'OpenAI GPT-4',
        tier: 'Professional',
        cost: '$0.03 per 1K tokens',
        specs: ['8K-32K context', 'High accuracy', 'Complex reasoning'],
        performance: 'Professional',
        notes: 'Better quality content, more accurate. Recommended for production use. Higher cost but better results.'
      },
      {
        name: 'Anthropic Claude 3 Haiku',
        tier: 'Standard',
        cost: '$0.25 per MTok',
        specs: ['200K context', 'Fast', 'Good comprehension'],
        performance: 'Standard',
        notes: 'Excellent for large context processing. Fast and cost-effective for supplementary materials.'
      },
      {
        name: 'Anthropic Claude 3 Sonnet',
        tier: 'Professional',
        cost: '$3 per MTok',
        specs: ['200K context', 'High quality', 'Nuanced understanding'],
        performance: 'Professional',
        notes: 'Best balance of cost and quality. Excellent for educational content requiring nuance.'
      },
      {
        name: 'Google Gemini 1.5 Pro',
        tier: 'Professional',
        cost: '$7 per MTok',
        specs: ['1M+ context', 'Multimodal', 'Advanced reasoning'],
        performance: 'Enterprise',
        notes: 'Massive context window allows processing entire textbooks. Best for complex, interconnected content.'
      }
    ]
  },
  {
    id: 'cloud-storage',
    title: 'Cloud Storage',
    icon: HardDrive,
    description: 'Storage for generated books, PDFs, audio files, and all content',
    why: 'Books and educational materials need reliable, scalable storage with fast access for downloads and streaming.',
    options: [
      {
        name: 'AWS S3 Standard',
        tier: 'Standard',
        cost: '$0.023 per GB/month',
        specs: ['99.99% availability', 'Unlimited storage', 'Fast retrieval'],
        performance: 'Standard',
        notes: 'Industry standard. Reliable and scalable. Good for frequently accessed content.'
      },
      {
        name: 'AWS S3 Intelligent-Tiering',
        tier: 'Professional',
        cost: '$0.023-0.00099 per GB',
        specs: ['Auto cost optimization', 'Same performance', 'Automatic archiving'],
        performance: 'Professional',
        notes: 'Automatically moves data to cheaper tiers when not accessed. Best for mixed access patterns.'
      },
      {
        name: 'Google Cloud Storage',
        tier: 'Standard',
        cost: '$0.020 per GB/month',
        specs: ['99.99% availability', 'Global CDN', 'Strong consistency'],
        performance: 'Standard',
        notes: 'Slightly cheaper than S3. Excellent CDN integration for global distribution.'
      },
      {
        name: 'Cloudflare R2',
        tier: 'Professional',
        cost: '$0.015 per GB/month',
        specs: ['No egress fees', 'Global network', 'S3 compatible'],
        performance: 'Professional',
        notes: 'Zero egress costs makes it very cost-effective for downloads. Best for high-traffic distribution.'
      },
      {
        name: 'Backblaze B2',
        tier: 'Basic',
        cost: '$0.005 per GB/month',
        specs: ['Lowest cost', 'Good reliability', 'S3 compatible'],
        performance: 'Basic',
        notes: 'Most affordable option. Good for archival and backup. Lower performance than major clouds.'
      }
    ]
  },
  {
    id: 'audio',
    title: 'Audio Synthesis (Text-to-Speech)',
    icon: Mic,
    description: 'Converting book text into high-quality audiobooks',
    why: 'Audiobooks are essential for accessibility and learning preferences. Quality narration improves comprehension and engagement.',
    options: [
      {
        name: 'Amazon Polly Standard',
        tier: 'Basic',
        cost: '$4 per 1M characters',
        specs: ['Multiple voices', 'SSML support', 'Good quality'],
        performance: 'Standard',
        notes: 'Cost-effective for basic audiobooks. Clear voice but less natural than neural.'
      },
      {
        name: 'Amazon Polly Neural',
        tier: 'Professional',
        cost: '$16 per 1M characters',
        specs: ['Natural voices', 'Expressive', 'Multiple languages'],
        performance: 'Professional',
        notes: 'Much more natural sounding. Best for professional audiobook quality. 4x cost but significantly better.'
      },
      {
        name: 'Google Cloud TTS Standard',
        tier: 'Standard',
        cost: '$4 per 1M characters',
        specs: ['WaveNet voices', 'Good naturalness', 'Many languages'],
        performance: 'Standard',
        notes: 'Similar to Polly Standard. Good language variety.'
      },
      {
        name: 'Google Cloud TTS WaveNet',
        tier: 'Professional',
        cost: '$16 per 1M characters',
        specs: ['Highest quality', 'Very natural', 'Emotional range'],
        performance: 'Professional',
        notes: 'Top-tier quality. Nearly indistinguishable from human narration in many cases.'
      },
      {
        name: 'ElevenLabs',
        tier: 'Enterprise',
        cost: '$30-300 per 1M characters',
        specs: ['Ultra-realistic', 'Voice cloning', 'Emotion control'],
        performance: 'Enterprise',
        notes: 'Highest quality available. Best for premium audiobooks. Expensive but exceptional results.'
      }
    ]
  },
  {
    id: 'image',
    title: 'Image Generation',
    icon: ImageIcon,
    description: 'Creating diagrams, illustrations, and visual aids',
    why: 'Visual content helps learning and understanding. Diagrams and illustrations make complex concepts accessible.',
    options: [
      {
        name: 'DALL-E 2',
        tier: 'Standard',
        cost: '$0.020 per image',
        specs: ['1024x1024 max', 'Good quality', 'Fast generation'],
        performance: 'Standard',
        notes: 'Reliable for educational diagrams. Good balance of cost and quality.'
      },
      {
        name: 'DALL-E 3',
        tier: 'Professional',
        cost: '$0.040-0.120 per image',
        specs: ['1792x1024 max', 'High quality', 'Better accuracy'],
        performance: 'Professional',
        notes: 'Superior image quality and prompt adherence. Best for detailed educational illustrations.'
      },
      {
        name: 'Midjourney',
        tier: 'Professional',
        cost: '$10-60 per month',
        specs: ['Artistic style', 'High quality', 'Limited commercial'],
        performance: 'Professional',
        notes: 'Excellent for artistic illustrations. Subscription model. Check licensing for educational use.'
      },
      {
        name: 'Stable Diffusion',
        tier: 'Basic',
        cost: 'Self-hosted compute cost',
        specs: ['Open source', 'Customizable', 'One-time setup'],
        performance: 'Standard',
        notes: 'Most cost-effective for high volume. Requires technical setup and GPU infrastructure.'
      },
      {
        name: 'Adobe Firefly',
        tier: 'Professional',
        cost: '$0.06 per image',
        specs: ['Commercial safe', 'High quality', 'Integration tools'],
        performance: 'Professional',
        notes: 'Trained only on licensed content. Best for avoiding copyright issues. Higher cost but legally safe.'
      }
    ]
  },
  {
    id: 'compute',
    title: 'Compute Infrastructure (VMs/Servers)',
    icon: Server,
    description: 'Processing power for generation workflows and API hosting',
    why: 'Backend processing is needed to coordinate AI services, convert formats, and manage the generation pipeline.',
    options: [
      {
        name: 'AWS EC2 t3.medium',
        tier: 'Basic',
        cost: '$0.0416 per hour (~$30/mo)',
        specs: ['2 vCPU', '4 GB RAM', 'Burstable'],
        performance: 'Basic',
        notes: 'Good for light workloads and development. Can handle small-scale generation.'
      },
      {
        name: 'AWS EC2 c6i.2xlarge',
        tier: 'Professional',
        cost: '$0.34 per hour (~$250/mo)',
        specs: ['8 vCPU', '16 GB RAM', 'Compute optimized'],
        performance: 'Professional',
        notes: 'Recommended for production. Handles concurrent generation and format conversion efficiently.'
      },
      {
        name: 'Google Cloud E2',
        tier: 'Standard',
        cost: '$0.033 per hour (~$24/mo)',
        specs: ['2 vCPU', '8 GB RAM', 'Cost-optimized'],
        performance: 'Standard',
        notes: 'Slightly cheaper than AWS. Good for moderate workloads.'
      },
      {
        name: 'DigitalOcean Droplet',
        tier: 'Basic',
        cost: '$24 per month',
        specs: ['2 vCPU', '4 GB RAM', 'Simple pricing'],
        performance: 'Basic',
        notes: 'Simplest to set up. Fixed monthly cost. Good for getting started quickly.'
      },
      {
        name: 'AWS Lambda Serverless',
        tier: 'Professional',
        cost: 'Pay per use (~$0.20 per 1M requests)',
        specs: ['Auto-scaling', 'No idle cost', 'Scales to zero'],
        performance: 'Professional',
        notes: 'Most cost-effective at scale. Only pay for actual usage. Best for variable workloads.'
      }
    ]
  },
  {
    id: 'database',
    title: 'Database',
    icon: Database,
    description: 'Storing metadata, user data, and content organization',
    why: 'A database manages book metadata, user accounts, generation tracking, and content organization.',
    options: [
      {
        name: 'Supabase Free',
        tier: 'Basic',
        cost: 'Free',
        specs: ['500 MB database', '1 GB file storage', '50K monthly users'],
        performance: 'Basic',
        notes: 'Perfect for development and early testing. No cost to get started.'
      },
      {
        name: 'Supabase Pro',
        tier: 'Standard',
        cost: '$25 per month',
        specs: ['8 GB database', '100 GB storage', 'Daily backups'],
        performance: 'Standard',
        notes: 'Good for production. Includes auth, storage, and real-time features. Best value for small-medium projects.'
      },
      {
        name: 'AWS RDS PostgreSQL',
        tier: 'Professional',
        cost: '$30-500 per month',
        specs: ['Flexible size', 'Automatic backups', 'High availability'],
        performance: 'Professional',
        notes: 'Enterprise-grade reliability. Scales to any size. More complex but very robust.'
      },
      {
        name: 'PlanetScale',
        tier: 'Professional',
        cost: '$39 per month',
        specs: ['10 GB storage', 'Branching', 'Automatic scaling'],
        performance: 'Professional',
        notes: 'Modern serverless MySQL. Great for development workflow with branching. No connection limits.'
      },
      {
        name: 'MongoDB Atlas',
        tier: 'Standard',
        cost: '$0-57 per month',
        specs: ['Flexible schema', 'Free tier available', 'Good for unstructured data'],
        performance: 'Standard',
        notes: 'Good if content structure varies. Free tier available. Flexible but different query model.'
      }
    ]
  }
];

function PerformanceBadge({ level }: { level: string }) {
  const colors: Record<string, string> = {
    'Basic': 'var(--color-textMuted)',
    'Standard': 'var(--color-accent)',
    'Professional': 'var(--color-primary)',
    'Enterprise': 'var(--color-secondary)',
  };

  return (
    <span
      className="px-2 py-1 rounded text-xs font-semibold"
      style={{
        backgroundColor: colors[level] || 'var(--color-textMuted)',
        color: 'var(--color-background)',
      }}
    >
      {level}
    </span>
  );
}

export function DemoResourcesPage({ onBack }: DemoResourcesPageProps) {
  const [selectedCategory, setSelectedCategory] = useState<ResourceCategory>('ai-apis');
  const resource = RESOURCES.find(r => r.id === selectedCategory)!;

  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--color-background)' }}>
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex items-center mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 px-4 py-2 rounded-lg transition"
            style={{
              backgroundColor: 'var(--color-surface)',
              color: 'var(--color-text)',
            }}
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </button>
        </div>

        <div className="mb-12">
          <h1 className="text-4xl font-bold mb-4" style={{ color: 'var(--color-text)' }}>
            What I Need to Be Successful
          </h1>
          <div
            className="rounded-lg p-6 mb-6"
            style={{
              backgroundColor: 'var(--color-surface)',
              borderWidth: '2px',
              borderStyle: 'solid',
              borderColor: 'var(--color-primary)',
            }}
          >
            <h3 className="text-lg font-bold mb-3" style={{ color: 'var(--color-text)' }}>
              My Goal
            </h3>
            <p className="text-sm mb-4" style={{ color: 'var(--color-textSecondary)' }}>
              My goal is to create a comprehensive educational content generation system that makes learning accessible to everyone.
              I want to build a library of educational books covering 24 subject areas, available at 8 different reading levels,
              with complete educational supplements, in multiple formats, and adapted for 40 different disability profiles. This
              would give students, teachers, and learners everywhere access to quality educational materials tailored to their specific needs.
            </p>
            <h3 className="text-lg font-bold mb-3" style={{ color: 'var(--color-text)' }}>
              What I Need
            </h3>
            <p className="text-sm" style={{ color: 'var(--color-textSecondary)' }}>
              Rather than direct funding, what I need are the specific services and infrastructure to make this work. I need AI APIs
              to generate the content, cloud storage to host thousands of books, audio synthesis services for audiobooks, image generation
              for illustrations and diagrams, compute resources to process and convert everything, and database services to organize it all.
              Below is a comparison of available options for each service, showing what's available at different price points and performance levels.
            </p>
          </div>
        </div>

        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4" style={{ color: 'var(--color-text)' }}>
            Service Categories
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
            {RESOURCES.map((res) => {
              const Icon = res.icon;
              const isSelected = selectedCategory === res.id;
              return (
                <button
                  key={res.id}
                  onClick={() => setSelectedCategory(res.id)}
                  className="p-4 rounded-lg transition text-center"
                  style={{
                    backgroundColor: isSelected ? 'var(--color-primary)' : 'var(--color-surface)',
                    borderWidth: '2px',
                    borderStyle: 'solid',
                    borderColor: isSelected ? 'var(--color-primary)' : 'var(--color-border)',
                    color: isSelected ? 'var(--color-background)' : 'var(--color-text)',
                  }}
                >
                  <Icon className="w-6 h-6 mx-auto mb-2" />
                  <div className="text-xs font-semibold">{res.title.split(' ')[0]}</div>
                </button>
              );
            })}
          </div>
        </div>

        <div
          className="rounded-2xl p-8 mb-8"
          style={{
            backgroundColor: 'var(--color-surface)',
            borderWidth: '2px',
            borderStyle: 'solid',
            borderColor: 'var(--color-primary)',
          }}
        >
          <div className="flex items-start gap-4 mb-6">
            <div
              className="p-3 rounded-lg"
              style={{
                backgroundColor: 'var(--color-primary)',
                color: 'var(--color-background)',
              }}
            >
              <resource.icon className="w-8 h-8" />
            </div>
            <div className="flex-1">
              <h2 className="text-2xl font-bold mb-2" style={{ color: 'var(--color-text)' }}>
                {resource.title}
              </h2>
              <p className="text-sm mb-4" style={{ color: 'var(--color-textSecondary)' }}>
                {resource.description}
              </p>
              <div
                className="rounded-lg p-4"
                style={{
                  backgroundColor: 'var(--color-background)',
                  borderWidth: '1px',
                  borderStyle: 'solid',
                  borderColor: 'var(--color-border)',
                }}
              >
                <h4 className="text-sm font-bold mb-2" style={{ color: 'var(--color-text)' }}>
                  Why This is Needed
                </h4>
                <p className="text-sm" style={{ color: 'var(--color-textSecondary)' }}>
                  {resource.why}
                </p>
              </div>
            </div>
          </div>

          <h3 className="text-xl font-bold mb-4" style={{ color: 'var(--color-text)' }}>
            Available Options
          </h3>
          <div className="space-y-4">
            {resource.options.map((option, idx) => (
              <div
                key={idx}
                className="rounded-lg p-5"
                style={{
                  backgroundColor: 'var(--color-background)',
                  borderWidth: '1px',
                  borderStyle: 'solid',
                  borderColor: 'var(--color-border)',
                }}
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h4 className="text-lg font-bold mb-1" style={{ color: 'var(--color-text)' }}>
                      {option.name}
                    </h4>
                    <div className="flex items-center gap-2 mb-2">
                      <PerformanceBadge level={option.performance} />
                      <span className="text-sm font-semibold" style={{ color: 'var(--color-accent)' }}>
                        {option.cost}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="mb-3">
                  <div className="text-xs font-semibold uppercase tracking-wide mb-2" style={{ color: 'var(--color-textSecondary)' }}>
                    Specifications:
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {option.specs.map((spec, i) => (
                      <span
                        key={i}
                        className="px-2 py-1 rounded text-xs"
                        style={{
                          backgroundColor: 'var(--color-surface)',
                          color: 'var(--color-textSecondary)',
                        }}
                      >
                        {spec}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="text-sm" style={{ color: 'var(--color-textSecondary)' }}>
                  {option.notes}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
