import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Settings, Plus, Edit, Trash2, Activity, CheckCircle, XCircle, ExternalLink } from 'lucide-react';

interface APIService {
  id: string;
  service_name: string;
  provider: string;
  purpose: string;
  is_active: boolean;
  priority_order: number;
  model_name: string | null;
  created_at: string;
}

export function APIServicesPage() {
  const [services, setServices] = useState<APIService[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);

  useEffect(() => {
    loadServices();
  }, []);

  const loadServices = async () => {
    try {
      const { data, error } = await supabase
        .from('api_services')
        .select('*')
        .order('priority_order', { ascending: true });

      if (error) throw error;
      setServices(data || []);
    } catch (error) {
      console.error('Error loading services:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleServiceStatus = async (serviceId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('api_services')
        .update({ is_active: !currentStatus })
        .eq('id', serviceId);

      if (error) throw error;
      loadServices();
    } catch (error) {
      console.error('Error toggling service:', error);
    }
  };

  const getPurposeStyle = (purpose: string) => {
    const styles: Record<string, { backgroundColor: string; color: string }> = {
      text_generation: { backgroundColor: 'var(--color-primary)', color: 'var(--color-background)' },
      audio: { backgroundColor: 'var(--color-accent)', color: 'var(--color-background)' },
      video: { backgroundColor: 'var(--color-secondary)', color: 'var(--color-background)' },
      research: { backgroundColor: 'var(--color-success)', color: 'var(--color-background)' },
      image: { backgroundColor: 'var(--color-warning)', color: 'var(--color-background)' },
    };
    return styles[purpose] || { backgroundColor: 'var(--color-surface)', color: 'var(--color-text)' };
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Activity className="w-8 h-8 animate-spin" style={{ color: 'var(--color-primary)' }} />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold" style={{ color: 'var(--color-text)' }}>
            API Services
          </h1>
          <p className="mt-1" style={{ color: 'var(--color-textMuted)' }}>
            Manage AI providers and API configurations
          </p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg transition"
          style={{
            backgroundColor: 'var(--color-primary)',
            color: 'var(--color-background)',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.backgroundColor = 'var(--color-primaryHover)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.backgroundColor = 'var(--color-primary)';
          }}
        >
          <Plus className="w-5 h-5" />
          Add Service
        </button>
      </div>

      <div
        className="rounded-xl shadow-sm border overflow-hidden"
        style={{
          backgroundColor: 'var(--color-surface)',
          borderColor: 'var(--color-border)',
        }}
      >
        <div
          className="px-6 py-4 border-b"
          style={{
            borderColor: 'var(--color-border)',
            backgroundColor: 'var(--color-surfaceHover)',
          }}
        >
          <h2 className="text-lg font-semibold" style={{ color: 'var(--color-text)' }}>
            Active Services
          </h2>
        </div>

        <div className="divide-y" style={{ borderColor: 'var(--color-border)' }}>
          {services.length === 0 ? (
            <div className="p-12 text-center">
              <Settings className="w-12 h-12 mx-auto mb-4" style={{ color: 'var(--color-textMuted)' }} />
              <h3 className="text-lg font-semibold mb-2" style={{ color: 'var(--color-text)' }}>
                No API services configured
              </h3>
              <p className="mb-6" style={{ color: 'var(--color-textMuted)' }}>
                Add your first AI service to start generating content
              </p>
              <button
                onClick={() => setShowAddModal(true)}
                className="px-4 py-2 rounded-lg transition"
                style={{
                  backgroundColor: 'var(--color-primary)',
                  color: 'var(--color-background)',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = 'var(--color-primaryHover)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'var(--color-primary)';
                }}
              >
                Add Your First Service
              </button>
            </div>
          ) : (
            services.map((service) => (
              <div
                key={service.id}
                className="p-6 transition"
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = 'var(--color-surfaceHover)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'transparent';
                }}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-semibold" style={{ color: 'var(--color-text)' }}>
                        {service.service_name}
                      </h3>
                      <span
                        className="px-2 py-1 text-xs font-medium rounded"
                        style={getPurposeStyle(service.purpose)}
                      >
                        {service.purpose.replace('_', ' ')}
                      </span>
                      {service.is_active ? (
                        <CheckCircle className="w-5 h-5" style={{ color: 'var(--color-success)' }} />
                      ) : (
                        <XCircle className="w-5 h-5" style={{ color: 'var(--color-textMuted)' }} />
                      )}
                    </div>
                    <div className="space-y-1 text-sm" style={{ color: 'var(--color-textMuted)' }}>
                      <p>Provider: <span className="font-medium" style={{ color: 'var(--color-text)' }}>{service.provider}</span></p>
                      {service.model_name && (
                        <p>Model: <span className="font-medium" style={{ color: 'var(--color-text)' }}>{service.model_name}</span></p>
                      )}
                      <p>Priority: <span className="font-medium" style={{ color: 'var(--color-text)' }}>#{service.priority_order}</span></p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => toggleServiceStatus(service.id, service.is_active)}
                      className="px-3 py-1.5 text-sm font-medium rounded-lg transition"
                      style={{
                        backgroundColor: service.is_active ? 'var(--color-surfaceHover)' : 'var(--color-success)',
                        color: service.is_active ? 'var(--color-text)' : 'var(--color-background)',
                      }}
                    >
                      {service.is_active ? 'Disable' : 'Enable'}
                    </button>
                    <button
                      className="p-2 rounded-lg transition"
                      style={{ color: 'var(--color-text)' }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.backgroundColor = 'var(--color-surfaceHover)';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.backgroundColor = 'transparent';
                      }}
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      className="p-2 rounded-lg transition"
                      style={{ color: 'var(--color-error)' }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.backgroundColor = 'var(--color-error)';
                        e.currentTarget.style.color = 'var(--color-background)';
                        e.currentTarget.style.opacity = '0.8';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.backgroundColor = 'transparent';
                        e.currentTarget.style.color = 'var(--color-error)';
                        e.currentTarget.style.opacity = '1';
                      }}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      <div
        className="border rounded-xl p-6"
        style={{
          background: `linear-gradient(135deg, var(--color-surface), var(--color-surfaceHover))`,
          borderColor: 'var(--color-border)',
        }}
      >
        <h3 className="font-semibold mb-2 flex items-center gap-2" style={{ color: 'var(--color-text)' }}>
          <ExternalLink className="w-5 h-5" />
          Quick Setup Links
        </h3>
        <div className="space-y-2 text-sm">
          <a
            href="https://platform.openai.com/api-keys"
            target="_blank"
            rel="noopener noreferrer"
            className="block hover:underline"
            style={{ color: 'var(--color-primary)' }}
          >
            OpenAI API Keys →
          </a>
          <a
            href="https://console.anthropic.com/settings/keys"
            target="_blank"
            rel="noopener noreferrer"
            className="block hover:underline"
            style={{ color: 'var(--color-primary)' }}
          >
            Anthropic Claude API Keys →
          </a>
          <a
            href="https://elevenlabs.io/app/settings/api-keys"
            target="_blank"
            rel="noopener noreferrer"
            className="block hover:underline"
            style={{ color: 'var(--color-primary)' }}
          >
            ElevenLabs Voice API Keys →
          </a>
        </div>
      </div>

      <div
        className="rounded-xl shadow-sm border p-6"
        style={{
          backgroundColor: 'var(--color-surface)',
          borderColor: 'var(--color-border)',
        }}
      >
        <h2 className="text-xl font-bold mb-4" style={{ color: 'var(--color-text)' }}>
          Auto-Failover Configuration
        </h2>
        <p className="mb-6" style={{ color: 'var(--color-textMuted)' }}>
          Services are prioritized by their priority order. If a service fails or reaches its limit,
          the system automatically switches to the next available service.
        </p>
        <div className="space-y-3">
          <div
            className="flex items-center justify-between p-4 rounded-lg"
            style={{ backgroundColor: 'var(--color-surfaceHover)' }}
          >
            <div>
              <div className="font-medium" style={{ color: 'var(--color-text)' }}>Automatic Failover</div>
              <div className="text-sm" style={{ color: 'var(--color-textMuted)' }}>Switch to backup service on failure</div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" defaultChecked />
              <div
                className="w-11 h-6 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all"
                style={{
                  backgroundColor: 'var(--color-border)',
                }}
              ></div>
            </label>
          </div>
          <div
            className="flex items-center justify-between p-4 rounded-lg"
            style={{ backgroundColor: 'var(--color-surfaceHover)' }}
          >
            <div>
              <div className="font-medium" style={{ color: 'var(--color-text)' }}>Usage Alerts</div>
              <div className="text-sm" style={{ color: 'var(--color-textMuted)' }}>Notify when approaching limits</div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" defaultChecked />
              <div
                className="w-11 h-6 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all"
                style={{
                  backgroundColor: 'var(--color-border)',
                }}
              ></div>
            </label>
          </div>
        </div>
      </div>
    </div>
  );
}
