import { ArrowLeft, BookOpen, Check, Layers, Sparkles, GitBranch } from 'lucide-react';

interface DemoSystemOverviewPageProps {
  onBack: () => void;
}

const SUBJECT_GROUPS = [
  { id: 1, name: 'Mathematics', color: '#3b82f6', examples: 'Algebra, Calculus, Statistics' },
  { id: 2, name: 'Language Arts', color: '#10b981', examples: 'Grammar, Literature, Writing' },
  { id: 3, name: 'History & Social Studies', color: '#f59e0b', examples: 'World History, Geography, Civics' },
  { id: 4, name: 'Science', color: '#8b5cf6', examples: 'Biology, Chemistry, Physics' },
  { id: 5, name: 'Foreign Languages', color: '#ec4899', examples: 'Spanish, French, Mandarin' },
  { id: 6, name: 'Computer Science', color: '#06b6d4', examples: 'Programming, AI, Data Science' },
  { id: 7, name: 'Arts', color: '#f97316', examples: 'Visual Arts, Music, Theater' },
  { id: 8, name: 'Physical Education & Health', color: '#84cc16', examples: 'Fitness, Nutrition, Wellness' },
  { id: 9, name: 'Employment & Job Skills', color: '#6366f1', examples: 'Career Planning, Resume Writing' },
  { id: 10, name: 'Business', color: '#14b8a6', examples: 'Marketing, Finance, Management' },
  { id: 11, name: 'Money Management', color: '#22c55e', examples: 'Budgeting, Investing, Taxes' },
  { id: 12, name: 'Transportation', color: '#0ea5e9', examples: 'Driving, Public Transit, Safety' },
  { id: 13, name: 'Home Management', color: '#a855f7', examples: 'Cooking, Cleaning, Maintenance' },
  { id: 14, name: 'Personal Care', color: '#f43f5e', examples: 'Hygiene, Grooming, Health' },
  { id: 15, name: 'Social Skills', color: '#eab308', examples: 'Communication, Relationships' },
  { id: 16, name: 'Recreation', color: '#06b6d4', examples: 'Hobbies, Sports, Entertainment' },
  { id: 17, name: 'Self-Determination', color: '#8b5cf6', examples: 'Goal Setting, Decision Making' },
  { id: 18, name: 'Safety & Emergency', color: '#dc2626', examples: 'First Aid, Emergency Response' },
  { id: 19, name: 'Legal & Advocacy', color: '#7c3aed', examples: 'Rights, Legal Basics, Advocacy' },
  { id: 20, name: 'Technology & Digital', color: '#3b82f6', examples: 'Digital Literacy, Online Safety' },
  { id: 21, name: 'Environmental Awareness', color: '#10b981', examples: 'Sustainability, Conservation' },
  { id: 22, name: 'Community Participation', color: '#f59e0b', examples: 'Volunteering, Civic Engagement' },
  { id: 23, name: 'Spiritual & Cultural', color: '#ec4899', examples: 'Cultural Practices, Beliefs' },
  { id: 24, name: 'Transition Planning', color: '#06b6d4', examples: 'Life Transitions, Planning' },
];

const GENERATION_OUTPUTS = [
  { label: '8 Reading Levels', value: '8', icon: '📚' },
  { label: 'Educational Add-ons', value: '8', icon: '📝' },
  { label: 'Format Options', value: '10+', icon: '📄' },
  { label: 'Disability Adaptations', value: '40', icon: '♿' },
  { label: 'Language Options', value: '100+', icon: '🌍' },
];

export function DemoSystemOverviewPage({ onBack }: DemoSystemOverviewPageProps) {
  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--color-background)' }}>
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 px-4 py-2 rounded-lg transition"
            style={{
              backgroundColor: 'var(--color-surface)',
              color: 'var(--color-text)',
            }}
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </button>
        </div>

        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Layers className="w-10 h-10" style={{ color: 'var(--color-primary)' }} />
            <h1 className="text-4xl font-bold" style={{ color: 'var(--color-text)' }}>
              Complete System Overview
            </h1>
          </div>
          <p className="text-lg max-w-3xl mx-auto" style={{ color: 'var(--color-textMuted)' }}>
            A comprehensive view of all 24 subject groups and the complete generation pipeline for each
          </p>
        </div>

        <div
          className="rounded-2xl p-8 mb-12"
          style={{
            background: `linear-gradient(135deg, var(--color-surface), var(--color-surfaceHover))`,
            borderWidth: '2px',
            borderStyle: 'solid',
            borderColor: 'var(--color-primary)',
          }}
        >
          <h2 className="text-2xl font-bold mb-6 text-center" style={{ color: 'var(--color-text)' }}>
            Per Book Generation Output
          </h2>
          <div className="grid md:grid-cols-5 gap-6">
            {GENERATION_OUTPUTS.map((output) => (
              <div
                key={output.label}
                className="text-center p-4 rounded-lg"
                style={{
                  backgroundColor: 'var(--color-background)',
                  borderWidth: '1px',
                  borderStyle: 'solid',
                  borderColor: 'var(--color-border)',
                }}
              >
                <div className="text-4xl mb-2">{output.icon}</div>
                <div className="text-3xl font-bold mb-1" style={{ color: 'var(--color-primary)' }}>
                  {output.value}
                </div>
                <div className="text-sm font-medium" style={{ color: 'var(--color-textSecondary)' }}>
                  {output.label}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mb-12">
          <div className="flex items-center gap-3 mb-6">
            <GitBranch className="w-8 h-8" style={{ color: 'var(--color-accent)' }} />
            <h2 className="text-2xl font-bold" style={{ color: 'var(--color-text)' }}>
              Generation Pipeline Process
            </h2>
          </div>

          <div className="grid md:grid-cols-4 gap-4 mb-8">
            {[
              { step: '1', title: 'Content Generation', desc: 'AI creates base content for all reading levels', color: 'var(--color-primary)' },
              { step: '2', title: 'Add-ons Creation', desc: 'Generate worksheets, quizzes, and educational materials', color: 'var(--color-accent)' },
              { step: '3', title: 'Format Conversion', desc: 'Convert to PDF, EPUB, Audio, and other formats', color: 'var(--color-secondary)' },
              { step: '4', title: 'Adaptations', desc: 'Create disability-specific and language adaptations', color: 'var(--color-success)' },
            ].map((phase) => (
              <div
                key={phase.step}
                className="p-6 rounded-xl border-2 transition"
                style={{
                  backgroundColor: 'var(--color-surface)',
                  borderColor: phase.color,
                }}
              >
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center text-xl font-bold mb-3"
                  style={{
                    backgroundColor: phase.color,
                    color: 'var(--color-background)',
                  }}
                >
                  {phase.step}
                </div>
                <h3 className="text-lg font-bold mb-2" style={{ color: 'var(--color-text)' }}>
                  {phase.title}
                </h3>
                <p className="text-sm" style={{ color: 'var(--color-textSecondary)' }}>
                  {phase.desc}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="mb-12">
          <div className="flex items-center gap-3 mb-6">
            <BookOpen className="w-8 h-8" style={{ color: 'var(--color-primary)' }} />
            <h2 className="text-2xl font-bold" style={{ color: 'var(--color-text)' }}>
              24 Subject Groups
            </h2>
          </div>
          <p className="text-sm mb-6" style={{ color: 'var(--color-textMuted)' }}>
            Each subject group goes through the complete generation pipeline, creating comprehensive educational materials
          </p>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {SUBJECT_GROUPS.map((group) => (
              <div
                key={group.id}
                className="rounded-lg p-4 border transition"
                style={{
                  backgroundColor: 'var(--color-surface)',
                  borderColor: 'var(--color-border)',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = group.color;
                  e.currentTarget.style.transform = 'translateY(-2px)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = 'var(--color-border)';
                  e.currentTarget.style.transform = 'translateY(0)';
                }}
              >
                <div className="flex items-center gap-2 mb-2">
                  <div
                    className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold"
                    style={{
                      backgroundColor: group.color,
                      color: 'white',
                    }}
                  >
                    {group.id}
                  </div>
                  <h3 className="font-bold" style={{ color: 'var(--color-text)' }}>
                    {group.name}
                  </h3>
                </div>
                <p className="text-xs" style={{ color: 'var(--color-textSecondary)' }}>
                  {group.examples}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div
          className="rounded-2xl p-8 text-center"
          style={{
            background: `linear-gradient(135deg, var(--color-surface), var(--color-surfaceHover))`,
            borderWidth: '2px',
            borderStyle: 'solid',
            borderColor: 'var(--color-accent)',
          }}
        >
          <Sparkles className="w-12 h-12 mx-auto mb-4" style={{ color: 'var(--color-accent)' }} />
          <h2 className="text-2xl font-bold mb-3" style={{ color: 'var(--color-text)' }}>
            Scale and Scope
          </h2>
          <p className="text-base mb-6 max-w-2xl mx-auto" style={{ color: 'var(--color-textMuted)' }}>
            Every subject group creates books for 8 reading levels, with 8 educational add-ons each, in 10+ formats,
            with 40 disability adaptations available, and support for 100+ languages.
          </p>
          <div className="grid md:grid-cols-3 gap-4 max-w-3xl mx-auto">
            <div className="p-4 rounded-lg" style={{ backgroundColor: 'var(--color-background)' }}>
              <div className="text-3xl font-bold mb-1" style={{ color: 'var(--color-primary)' }}>
                192
              </div>
              <div className="text-sm font-medium" style={{ color: 'var(--color-textSecondary)' }}>
                Base Books (24 groups × 8 levels)
              </div>
            </div>
            <div className="p-4 rounded-lg" style={{ backgroundColor: 'var(--color-background)' }}>
              <div className="text-3xl font-bold mb-1" style={{ color: 'var(--color-accent)' }}>
                1,536
              </div>
              <div className="text-sm font-medium" style={{ color: 'var(--color-textSecondary)' }}>
                With Educational Add-ons
              </div>
            </div>
            <div className="p-4 rounded-lg" style={{ backgroundColor: 'var(--color-background)' }}>
              <div className="text-3xl font-bold mb-1" style={{ color: 'var(--color-secondary)' }}>
                7,680
              </div>
              <div className="text-sm font-medium" style={{ color: 'var(--color-textSecondary)' }}>
                With Disability Adaptations
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
