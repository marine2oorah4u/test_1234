import { useState } from 'react';
import { supabase } from '../lib/supabase';
import { startBookGeneration } from '../lib/bookGeneration';
import { Plus, BookOpen, Sparkles, CheckCircle } from 'lucide-react';
import { useNavigate } from '../hooks/useNavigate';

const READING_LEVELS = [
  { value: 'phd', label: 'PhD Level' },
  { value: 'masters', label: 'Masters Level' },
  { value: 'bachelors', label: 'Bachelors Level' },
  { value: 'high_school', label: 'High School' },
  { value: 'middle_school', label: 'Middle School' },
  { value: 'elementary', label: 'Elementary' },
  { value: 'kindergarten', label: 'Kindergarten' },
];

const FORMATS = [
  { value: 'pdf', label: 'PDF' },
  { value: 'epub', label: 'EPUB' },
  { value: 'html', label: 'HTML/Web' },
  { value: 'audio', label: 'Audio Book' },
  { value: 'video', label: 'Video' },
  { value: 'docx', label: 'Word Document' },
  { value: 'markdown', label: 'Markdown' },
  { value: 'latex', label: 'LaTeX' },
];

export function GenerateBookPage() {
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [selectedLevels, setSelectedLevels] = useState<string[]>(['high_school']);
  const [selectedFormats, setSelectedFormats] = useState<string[]>(['pdf', 'epub', 'html']);
  const [isDemo, setIsDemo] = useState(true);
  const [maxQualityMode, setMaxQualityMode] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [generationId, setGenerationId] = useState<string | null>(null);
  const navigate = useNavigate();

  const toggleLevel = (level: string) => {
    setSelectedLevels(prev =>
      prev.includes(level)
        ? prev.filter(l => l !== level)
        : [...prev, level]
    );
  };

  const toggleFormat = (format: string) => {
    setSelectedFormats(prev =>
      prev.includes(format)
        ? prev.filter(f => f !== format)
        : [...prev, format]
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (selectedLevels.length === 0) {
        throw new Error('Please select at least one reading level');
      }
      if (selectedFormats.length === 0) {
        throw new Error('Please select at least one format');
      }

      const { data: book, error: bookError } = await supabase
        .from('books')
        .insert({
          title: `${subject} - Educational Guide`,
          subject,
          description,
          is_demo: isDemo,
          status: 'pending',
        })
        .select()
        .single();

      if (bookError) {
        console.error('Book creation error:', bookError);
        throw new Error(`Failed to create book: ${bookError.message} (Code: ${bookError.code})`);
      }

      const versionInserts = selectedLevels.flatMap(level =>
        selectedFormats.map(format => ({
          book_id: book.id,
          reading_level: level,
          format_type: format,
          status: 'pending' as const,
        }))
      );

      const { error: versionsError } = await supabase
        .from('book_versions')
        .insert(versionInserts);

      if (versionsError) throw versionsError;

      const { data: queue, error: queueError } = await supabase
        .from('generation_queue')
        .insert({
          book_id: book.id,
          status: 'queued',
          progress_stage: 'initializing',
          progress_percentage: 0,
          generation_config: {
            levels: selectedLevels,
            formats: selectedFormats,
            is_demo: isDemo,
            max_quality_mode: maxQualityMode,
          },
        })
        .select()
        .single();

      if (queueError) throw queueError;

      setGenerationId(queue.id);

      try {
        await startBookGeneration(queue.id);
      } catch (err) {
        console.error('Failed to start background generation:', err);
        await supabase
          .from('generation_queue')
          .update({ status: 'failed', error_log: { error: err instanceof Error ? err.message : 'Unknown error' } })
          .eq('id', queue.id);

        throw new Error('Failed to start generation worker: ' + (err instanceof Error ? err.message : 'Unknown error'));
      }

      setTimeout(() => {
        navigate('library');
      }, 2000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to start generation');
      setLoading(false);
    }
  };

  if (generationId) {
    return (
      <div className="max-w-2xl mx-auto">
        <div
          className="rounded-xl shadow-sm border p-12 text-center"
          style={{
            backgroundColor: 'var(--color-surface)',
            borderColor: 'var(--color-border)',
          }}
        >
          <div
            className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6"
            style={{ backgroundColor: 'var(--color-success)', opacity: 0.2 }}
          >
            <CheckCircle className="w-10 h-10" style={{ color: 'var(--color-success)' }} />
          </div>
          <h2 className="text-2xl font-bold mb-2" style={{ color: 'var(--color-text)' }}>
            Generation Started!
          </h2>
          <p className="mb-6" style={{ color: 'var(--color-textMuted)' }}>
            Your book is now in the generation queue. The system will create all formats and reading levels automatically.
          </p>
          <p className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
            Redirecting to library...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold" style={{ color: 'var(--color-text)' }}>
          Generate New Book
        </h1>
        <p className="mt-1" style={{ color: 'var(--color-textMuted)' }}>
          Create AI-powered educational content in multiple formats
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div
          className="rounded-xl shadow-sm border p-6"
          style={{
            backgroundColor: 'var(--color-surface)',
            borderColor: 'var(--color-border)',
          }}
        >
          <h2 className="text-xl font-bold mb-6 flex items-center gap-2" style={{ color: 'var(--color-text)' }}>
            <BookOpen className="w-6 h-6" style={{ color: 'var(--color-primary)' }} />
            Book Details
          </h2>

          <div className="space-y-4">
            <div>
              <label htmlFor="subject" className="block text-sm font-medium mb-1" style={{ color: 'var(--color-text)' }}>
                Subject / Topic *
              </label>
              <input
                id="subject"
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full px-4 py-2 border rounded-lg outline-none transition"
                style={{
                  backgroundColor: 'var(--color-background)',
                  borderColor: 'var(--color-border)',
                  color: 'var(--color-text)',
                }}
                placeholder="e.g., Photosynthesis, Ancient Egypt, Python Programming"
                required
              />
            </div>

            <div>
              <label htmlFor="description" className="block text-sm font-medium mb-1" style={{ color: 'var(--color-text)' }}>
                Description (Optional)
              </label>
              <textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full px-4 py-2 border rounded-lg outline-none transition resize-none"
                style={{
                  backgroundColor: 'var(--color-background)',
                  borderColor: 'var(--color-border)',
                  color: 'var(--color-text)',
                }}
                rows={3}
                placeholder="Additional details or specific requirements..."
              />
            </div>

            <div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isDemo}
                  onChange={(e) => setIsDemo(e.target.checked)}
                  className="w-4 h-4 rounded"
                  style={{ accentColor: 'var(--color-primary)' }}
                />
                <span className="text-sm" style={{ color: 'var(--color-text)' }}>Generate as demo version</span>
              </label>
              <p className="text-xs mt-1 ml-6" style={{ color: 'var(--color-textMuted)' }}>
                Demo versions use budget AI models and basic features
              </p>
            </div>

            {!isDemo && (
              <div className="border-l-4 border-purple-600 bg-purple-50 p-4 rounded-r-lg">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={maxQualityMode}
                    onChange={(e) => setMaxQualityMode(e.target.checked)}
                    className="w-4 h-4 rounded"
                    style={{ accentColor: '#9333ea' }}
                  />
                  <span className="text-sm font-medium text-purple-900 flex items-center gap-2">
                    <Sparkles className="w-4 h-4" />
                    Maximum Quality Mode (Unlimited Tokens)
                  </span>
                </label>
                <p className="text-xs mt-2 ml-6 text-purple-800">
                  Uses 10+ AI models with multi-perspective consensus, verification, and iterative refinement.
                  Target: 95%+ quality. Cost: $2-$10 per book (or FREE with educational grants).
                </p>
                {maxQualityMode && (
                  <div className="mt-3 ml-6 space-y-1 text-xs text-purple-700">
                    <p>✓ 7-10 AIs for research</p>
                    <p>✓ 5-10 AIs generate independently, best parts merged</p>
                    <p>✓ 12+ AIs verify accuracy and quality</p>
                    <p>✓ Iterative refinement until 95%+ quality</p>
                    <p>✓ Multi-cloud load balancing</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        <div
          className="rounded-xl shadow-sm border p-6"
          style={{
            backgroundColor: 'var(--color-surface)',
            borderColor: 'var(--color-border)',
          }}
        >
          <h2 className="text-xl font-bold mb-4" style={{ color: 'var(--color-text)' }}>Reading Levels</h2>
          <p className="text-sm mb-4" style={{ color: 'var(--color-textMuted)' }}>Select which reading levels to generate</p>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {READING_LEVELS.map((level) => (
              <button
                key={level.value}
                type="button"
                onClick={() => toggleLevel(level.value)}
                className="px-4 py-3 rounded-lg border-2 transition text-sm font-medium"
                style={{
                  borderColor: selectedLevels.includes(level.value) ? 'var(--color-primary)' : 'var(--color-border)',
                  backgroundColor: selectedLevels.includes(level.value) ? 'var(--color-primary)' : 'var(--color-surface)',
                  color: selectedLevels.includes(level.value) ? 'var(--color-background)' : 'var(--color-text)',
                }}
              >
                {level.label}
              </button>
            ))}
          </div>
        </div>

        <div
          className="rounded-xl shadow-sm border p-6"
          style={{
            backgroundColor: 'var(--color-surface)',
            borderColor: 'var(--color-border)',
          }}
        >
          <h2 className="text-xl font-bold mb-4" style={{ color: 'var(--color-text)' }}>Output Formats</h2>
          <p className="text-sm mb-4" style={{ color: 'var(--color-textMuted)' }}>Choose which formats to generate</p>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {FORMATS.map((format) => (
              <button
                key={format.value}
                type="button"
                onClick={() => toggleFormat(format.value)}
                className="px-4 py-3 rounded-lg border-2 transition text-sm font-medium"
                style={{
                  borderColor: selectedFormats.includes(format.value) ? 'var(--color-primary)' : 'var(--color-border)',
                  backgroundColor: selectedFormats.includes(format.value) ? 'var(--color-primary)' : 'var(--color-surface)',
                  color: selectedFormats.includes(format.value) ? 'var(--color-background)' : 'var(--color-text)',
                }}
              >
                {format.label}
              </button>
            ))}
          </div>
        </div>

        {error && (
          <div
            className="border rounded-lg p-4"
            style={{
              backgroundColor: 'var(--color-error)',
              borderColor: 'var(--color-error)',
              color: 'var(--color-background)',
              opacity: 0.9,
            }}
          >
            {error}
          </div>
        )}

        <div className="flex gap-4">
          <button
            type="submit"
            disabled={loading}
            className="flex-1 flex items-center justify-center gap-2 px-6 py-3 font-medium rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed"
            style={{
              backgroundColor: 'var(--color-primary)',
              color: 'var(--color-background)',
            }}
            onMouseEnter={(e) => {
              if (!loading) {
                e.currentTarget.style.backgroundColor = 'var(--color-primaryHover)';
              }
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'var(--color-primary)';
            }}
          >
            {loading ? (
              <>Processing...</>
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                Generate Book
              </>
            )}
          </button>
        </div>
      </form>

      <div
        className="border rounded-xl p-6"
        style={{
          background: `linear-gradient(135deg, var(--color-surface), var(--color-surfaceHover))`,
          borderColor: 'var(--color-border)',
        }}
      >
        <h3 className="font-semibold mb-2" style={{ color: 'var(--color-text)' }}>What happens next?</h3>
        <ul className="space-y-2 text-sm" style={{ color: 'var(--color-textSecondary)' }}>
          <li className="flex items-start gap-2">
            <span className="mt-0.5" style={{ color: 'var(--color-accent)' }}>•</span>
            <span>AI researches and generates comprehensive content on your topic</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="mt-0.5" style={{ color: 'var(--color-accent)' }}>•</span>
            <span>Content is adapted to all selected reading levels</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="mt-0.5" style={{ color: 'var(--color-accent)' }}>•</span>
            <span>Multiple formats are created automatically (PDF, EPUB, audio, etc.)</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="mt-0.5" style={{ color: 'var(--color-accent)' }}>•</span>
            <span>Interactive lessons, quizzes, and exercises are generated</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="mt-0.5" style={{ color: 'var(--color-accent)' }}>•</span>
            <span>You can monitor progress in real-time from the library page</span>
          </li>
        </ul>
      </div>
    </div>
  );
}
