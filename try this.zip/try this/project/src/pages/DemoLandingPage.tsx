import { BookOpen, Sparkles, Play, ArrowRight, CheckCircle, LayoutDashboard } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface DemoLandingPageProps {
  onExploreDemo: () => void;
  onSignUp: () => void;
  onNavigate?: (page: string) => void;
}

export function DemoLandingPage({ onExploreDemo, onSignUp, onNavigate }: DemoLandingPageProps) {
  const { user } = useAuth();

  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--color-background)' }}>
      {user && onNavigate && (
        <div className="fixed top-4 right-4 z-50">
          <button
            onClick={() => onNavigate('overview')}
            className="flex items-center gap-2 px-4 py-2 rounded-lg transition backdrop-blur-md"
            style={{
              backgroundColor: 'rgba(var(--color-primary-rgb, 139, 21, 56), 0.9)',
              color: 'var(--color-text)',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = 'rgba(var(--color-primary-rgb, 139, 21, 56), 1)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'rgba(var(--color-primary-rgb, 139, 21, 56), 0.9)';
            }}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span className="font-medium">Back to Admin</span>
          </button>
        </div>
      )}
      <div className="max-w-6xl mx-auto px-6 py-12">
        <header className="text-center mb-16">
          <div className="flex items-center justify-center gap-3 mb-6">
            <BookOpen className="w-12 h-12" style={{ color: 'var(--color-primary)' }} />
            <h1 className="text-5xl font-bold" style={{ color: 'var(--color-text)' }}>
              OwlCraft
            </h1>
          </div>
          <p className="text-xl mb-8" style={{ color: 'var(--color-textMuted)' }}>
            Generate comprehensive educational content in any format, for any reading level
          </p>
          <div className="flex items-center justify-center gap-4">
            <button
              onClick={onExploreDemo}
              className="flex items-center gap-2 px-10 py-5 rounded-lg transition text-xl font-bold"
              style={{
                backgroundColor: 'var(--color-primary)',
                color: 'var(--color-background)',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = 'var(--color-primaryHover)';
                e.currentTarget.style.transform = 'scale(1.05)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'var(--color-primary)';
                e.currentTarget.style.transform = 'scale(1)';
              }}
            >
              <Play className="w-6 h-6" />
              View Demo
            </button>
          </div>
        </header>

        <div
          className="rounded-2xl p-10 mb-16"
          style={{
            background: `linear-gradient(135deg, var(--color-surface), var(--color-surfaceHover))`,
            borderWidth: '1px',
            borderStyle: 'solid',
            borderColor: 'var(--color-border)',
          }}
        >
          <h2 className="text-3xl font-bold mb-8 text-center" style={{ color: 'var(--color-text)' }}>
            What's Included Per Book
          </h2>

          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-6xl font-bold mb-3" style={{ color: 'var(--color-primary)' }}>
                8
              </div>
              <h4 className="font-semibold mb-2 text-lg" style={{ color: 'var(--color-text)' }}>
                Reading Levels
              </h4>
              <p className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
                Kindergarten to PhD
              </p>
            </div>

            <div className="text-center">
              <div className="text-6xl font-bold mb-3" style={{ color: 'var(--color-accent)' }}>
                8
              </div>
              <h4 className="font-semibold mb-2 text-lg" style={{ color: 'var(--color-text)' }}>
                Output Formats
              </h4>
              <p className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
                PDF, EPUB, Audio & more
              </p>
            </div>

            <div className="text-center">
              <div className="text-6xl font-bold mb-3" style={{ color: 'var(--color-secondary)' }}>
                8
              </div>
              <h4 className="font-semibold mb-2 text-lg" style={{ color: 'var(--color-text)' }}>
                Auto Add-ons
              </h4>
              <p className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
                Worksheets, quizzes & activities
              </p>
            </div>

            <div className="text-center">
              <div className="text-6xl font-bold mb-3" style={{ color: 'var(--color-success)' }}>
                14
              </div>
              <h4 className="font-semibold mb-2 text-lg" style={{ color: 'var(--color-text)' }}>
                Interactive Features
              </h4>
              <p className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
                6 available, 8 coming soon
              </p>
            </div>
          </div>
        </div>

        <div
          className="rounded-2xl p-8 mb-12"
          style={{
            background: `linear-gradient(135deg, var(--color-surface), var(--color-surfaceHover))`,
            borderWidth: '1px',
            borderStyle: 'solid',
            borderColor: 'var(--color-border)',
          }}
        >
          <h2 className="text-3xl font-bold mb-6 text-center" style={{ color: 'var(--color-text)' }}>
            How It Works
          </h2>
          <div className="grid md:grid-cols-4 gap-6">
            <div className="text-center">
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold"
                style={{
                  backgroundColor: 'var(--color-primary)',
                  color: 'var(--color-background)',
                }}
              >
                1
              </div>
              <h4 className="font-semibold mb-2" style={{ color: 'var(--color-text)' }}>
                Choose Topic
              </h4>
              <p className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
                Enter any subject you want to learn about
              </p>
            </div>

            <div className="text-center">
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold"
                style={{
                  backgroundColor: 'var(--color-accent)',
                  color: 'var(--color-background)',
                }}
              >
                2
              </div>
              <h4 className="font-semibold mb-2" style={{ color: 'var(--color-text)' }}>
                Select Options
              </h4>
              <p className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
                Pick reading levels and output formats
              </p>
            </div>

            <div className="text-center">
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold"
                style={{
                  backgroundColor: 'var(--color-secondary)',
                  color: 'var(--color-background)',
                }}
              >
                3
              </div>
              <h4 className="font-semibold mb-2" style={{ color: 'var(--color-text)' }}>
                AI Generates
              </h4>
              <p className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
                Watch as AI creates comprehensive content
              </p>
            </div>

            <div className="text-center">
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold"
                style={{
                  backgroundColor: 'var(--color-success)',
                  color: 'var(--color-background)',
                }}
              >
                4
              </div>
              <h4 className="font-semibold mb-2" style={{ color: 'var(--color-text)' }}>
                Download & Share
              </h4>
              <p className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
                Get your books in all selected formats
              </p>
            </div>
          </div>
        </div>

        <div className="text-center">
          <h2 className="text-3xl font-bold mb-4" style={{ color: 'var(--color-text)' }}>
            Ready to Create?
          </h2>
          <p className="text-lg mb-8" style={{ color: 'var(--color-textMuted)' }}>
            Start generating AI-powered educational content in seconds
          </p>
          <button
            onClick={onExploreDemo}
            className="px-10 py-5 rounded-lg transition text-xl font-bold"
            style={{
              backgroundColor: 'var(--color-primary)',
              color: 'var(--color-background)',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = 'var(--color-primaryHover)';
              e.currentTarget.style.transform = 'scale(1.05)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'var(--color-primary)';
              e.currentTarget.style.transform = 'scale(1)';
            }}
          >
            Try the Demo Now
          </button>
        </div>
      </div>
    </div>
  );
}
