import { useState, useEffect } from 'react';
import { Activity, Cloud, Zap, TrendingUp, AlertCircle, CheckCircle, Server, Globe } from 'lucide-react';
import { maximumQualityOrchestrator } from '../lib/maximumQualityOrchestrator';
import { AI_MODELS, CLOUD_LOCATIONS } from '../config/maximumQualityModels';

export function LoadBalancingDashboard() {
  const [loadStatus, setLoadStatus] = useState<any>(null);
  const [refreshInterval, setRefreshInterval] = useState(5000);

  useEffect(() => {
    const loadData = () => {
      const status = maximumQualityOrchestrator.getLoadBalancingStatus();
      setLoadStatus(status);
    };

    loadData();
    const interval = setInterval(loadData, refreshInterval);

    return () => clearInterval(interval);
  }, [refreshInterval]);

  if (!loadStatus) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Activity className="w-12 h-12 text-blue-600 mx-auto mb-4 animate-pulse" />
          <p className="text-gray-600">Loading load balancing data...</p>
        </div>
      </div>
    );
  }

  const totalModels = loadStatus.models.length;
  const healthyModels = loadStatus.models.filter((m: any) => m.health === 'healthy').length;
  const totalLocations = loadStatus.locations.length;
  const avgLoad = loadStatus.locations.reduce((sum: number, l: any) => sum + l.load, 0) / totalLocations;

  return (
    <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Load Balancing Dashboard</h1>
            <p className="text-gray-600 mt-2">Multi-cloud AI resource optimization and monitoring</p>
          </div>
          <div className="flex items-center gap-3">
            <select
              value={refreshInterval}
              onChange={(e) => setRefreshInterval(Number(e.target.value))}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value={1000}>1 second</option>
              <option value={5000}>5 seconds</option>
              <option value={10000}>10 seconds</option>
              <option value={30000}>30 seconds</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <Server className="w-8 h-8 text-blue-600" />
              <span className="text-sm text-gray-500">AI Models</span>
            </div>
            <div className="text-3xl font-bold text-gray-900">{healthyModels}/{totalModels}</div>
            <p className="text-sm text-gray-600 mt-1">Healthy models</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <Cloud className="w-8 h-8 text-green-600" />
              <span className="text-sm text-gray-500">Cloud Locations</span>
            </div>
            <div className="text-3xl font-bold text-gray-900">{totalLocations}</div>
            <p className="text-sm text-gray-600 mt-1">Active regions</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <TrendingUp className="w-8 h-8 text-yellow-600" />
              <span className="text-sm text-gray-500">Avg Load</span>
            </div>
            <div className="text-3xl font-bold text-gray-900">{avgLoad.toFixed(1)}%</div>
            <p className="text-sm text-gray-600 mt-1">Across all clouds</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <Zap className="w-8 h-8 text-purple-600" />
              <span className="text-sm text-gray-500">Status</span>
            </div>
            <div className="text-3xl font-bold text-green-600">Optimal</div>
            <p className="text-sm text-gray-600 mt-1">System health</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">AI Model Status</h2>
              <Activity className="w-5 h-5 text-gray-400" />
            </div>
            <div className="space-y-4">
              {loadStatus.models.slice(0, 8).map((model: any) => {
                const modelConfig = AI_MODELS[model.id];
                const usagePercent = (model.usage.tokens / modelConfig.maxTPM) * 100;

                return (
                  <div key={model.id} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {model.health === 'healthy' ? (
                          <CheckCircle className="w-4 h-4 text-green-600" />
                        ) : (
                          <AlertCircle className="w-4 h-4 text-yellow-600" />
                        )}
                        <span className="font-medium text-gray-900">{modelConfig.name}</span>
                        <span className="text-xs text-gray-500">({modelConfig.provider})</span>
                      </div>
                      <span className="text-sm font-medium text-gray-700">{usagePercent.toFixed(1)}%</span>
                    </div>
                    <div className="w-full bg-gray-100 rounded-full h-2">
                      <div
                        className={`h-2 rounded-full transition-all ${
                          usagePercent > 80 ? 'bg-red-600' : usagePercent > 60 ? 'bg-yellow-600' : 'bg-green-600'
                        }`}
                        style={{ width: `${Math.min(usagePercent, 100)}%` }}
                      />
                    </div>
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span>{model.usage.tokens.toLocaleString()} / {modelConfig.maxTPM.toLocaleString()} tokens</span>
                      <span>{model.usage.requests} requests</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Cloud Location Status</h2>
              <Globe className="w-5 h-5 text-gray-400" />
            </div>
            <div className="space-y-6">
              {loadStatus.locations.map((location: any) => {
                const locationConfig = CLOUD_LOCATIONS.find(l => l.id === location.id);
                if (!locationConfig) return null;

                return (
                  <div key={location.id} className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium text-gray-900">{locationConfig.provider.toUpperCase()}</h3>
                        <p className="text-sm text-gray-500">{locationConfig.region}</p>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-medium text-gray-900">{location.load.toFixed(1)}%</div>
                        <div className="text-xs text-gray-500">Load</div>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="text-xs text-gray-500 mb-1">Token Quota</div>
                        <div className="w-full bg-gray-100 rounded-full h-2">
                          <div
                            className={`h-2 rounded-full ${
                              location.quotaUsed > 80 ? 'bg-red-600' : location.quotaUsed > 60 ? 'bg-yellow-600' : 'bg-blue-600'
                            }`}
                            style={{ width: `${Math.min(location.quotaUsed, 100)}%` }}
                          />
                        </div>
                        <div className="text-xs text-gray-500 mt-1">{location.quotaUsed.toFixed(1)}% used</div>
                      </div>
                      <div>
                        <div className="text-xs text-gray-500 mb-1">Capacity</div>
                        <div className="w-full bg-gray-100 rounded-full h-2">
                          <div
                            className={`h-2 rounded-full ${
                              location.load > 80 ? 'bg-red-600' : location.load > 60 ? 'bg-yellow-600' : 'bg-green-600'
                            }`}
                            style={{ width: `${Math.min(location.load, 100)}%` }}
                          />
                        </div>
                        <div className="text-xs text-gray-500 mt-1">{location.load.toFixed(1)}% load</div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Load Balancing Strategies</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="border border-gray-200 rounded-lg p-4">
              <h3 className="font-medium text-gray-900 mb-2">Round Robin</h3>
              <p className="text-sm text-gray-600">Distributes requests evenly across all available models</p>
              <div className="mt-3 px-3 py-1 bg-blue-50 text-blue-700 text-xs font-medium rounded-full inline-block">
                Active
              </div>
            </div>
            <div className="border border-gray-200 rounded-lg p-4">
              <h3 className="font-medium text-gray-900 mb-2">Least Used</h3>
              <p className="text-sm text-gray-600">Routes to models with lowest current usage</p>
              <div className="mt-3 px-3 py-1 bg-green-50 text-green-700 text-xs font-medium rounded-full inline-block">
                Active
              </div>
            </div>
            <div className="border border-gray-200 rounded-lg p-4">
              <h3 className="font-medium text-gray-900 mb-2">Quality Based</h3>
              <p className="text-sm text-gray-600">Prioritizes models with highest quality scores</p>
              <div className="mt-3 px-3 py-1 bg-purple-50 text-purple-700 text-xs font-medium rounded-full inline-block">
                Active
              </div>
            </div>
            <div className="border border-gray-200 rounded-lg p-4">
              <h3 className="font-medium text-gray-900 mb-2">Fastest</h3>
              <p className="text-sm text-gray-600">Routes to models with lowest latency</p>
              <div className="mt-3 px-3 py-1 bg-yellow-50 text-yellow-700 text-xs font-medium rounded-full inline-block">
                Active
              </div>
            </div>
          </div>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
          <div className="flex items-start gap-4">
            <Cloud className="w-6 h-6 text-blue-600 flex-shrink-0 mt-1" />
            <div>
              <h3 className="font-bold text-blue-900 mb-2">Multi-Cloud Optimization</h3>
              <p className="text-blue-800 mb-4">
                The system automatically distributes work across {totalLocations} cloud locations and {totalModels} AI models
                to ensure optimal performance, cost efficiency, and reliability.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-white rounded-lg p-3">
                  <div className="text-sm text-gray-600 mb-1">Automatic Failover</div>
                  <div className="font-bold text-gray-900">Enabled</div>
                </div>
                <div className="bg-white rounded-lg p-3">
                  <div className="text-sm text-gray-600 mb-1">Smart Routing</div>
                  <div className="font-bold text-gray-900">Active</div>
                </div>
                <div className="bg-white rounded-lg p-3">
                  <div className="text-sm text-gray-600 mb-1">Cost Optimization</div>
                  <div className="font-bold text-gray-900">Optimized</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
  );
}
