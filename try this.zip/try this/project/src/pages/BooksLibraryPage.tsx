import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { BookOpen, Download, Eye, Clock, CheckCircle, XCircle, Activity, Trash2 } from 'lucide-react';
import { ProgressTracker } from '../components/ProgressTracker';

interface Book {
  id: string;
  title: string;
  subject: string;
  description: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  is_demo: boolean;
  created_at: string;
  completed_at: string | null;
}

interface BookVersion {
  id: string;
  book_id: string;
  reading_level: string;
  format_type: string;
  file_url: string | null;
  word_count: number | null;
  status: string;
}

export function BooksLibraryPage() {
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedBook, setSelectedBook] = useState<string | null>(null);
  const [bookVersions, setBookVersions] = useState<Record<string, BookVersion[]>>({});

  useEffect(() => {
    loadBooks();

    const subscription = supabase
      .channel('books_changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'books' }, () => {
        loadBooks();
      })
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const loadBooks = async () => {
    try {
      const { data, error } = await supabase
        .from('books')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setBooks(data || []);

      // Load versions for completed books
      const completedBookIds = (data || [])
        .filter(b => b.status === 'completed')
        .map(b => b.id);

      if (completedBookIds.length > 0) {
        const { data: versions } = await supabase
          .from('book_versions')
          .select('*')
          .in('book_id', completedBookIds);

        if (versions) {
          const versionsByBook = versions.reduce((acc, version) => {
            if (!acc[version.book_id]) {
              acc[version.book_id] = [];
            }
            acc[version.book_id].push(version);
            return acc;
          }, {} as Record<string, BookVersion[]>);

          setBookVersions(versionsByBook);
        }
      }
    } catch (error) {
      console.error('Error loading books:', error);
    } finally {
      setLoading(false);
    }
  };

  const deleteBook = async (bookId: string) => {
    if (!confirm('Are you sure you want to delete this book? This cannot be undone.')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('books')
        .delete()
        .eq('id', bookId);

      if (error) throw error;
      loadBooks();
    } catch (error) {
      console.error('Error deleting book:', error);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-5 h-5" style={{ color: 'var(--color-success)' }} />;
      case 'processing':
      case 'pending':
        return <Clock className="w-5 h-5 animate-pulse" style={{ color: 'var(--color-warning)' }} />;
      case 'failed':
        return <XCircle className="w-5 h-5" style={{ color: 'var(--color-error)' }} />;
      default:
        return <Activity className="w-5 h-5" style={{ color: 'var(--color-textMuted)' }} />;
    }
  };

  const getStatusStyle = (status: string) => {
    switch (status) {
      case 'completed':
        return { backgroundColor: 'var(--color-success)', color: 'var(--color-background)', opacity: 0.9 };
      case 'processing':
      case 'pending':
        return { backgroundColor: 'var(--color-warning)', color: 'var(--color-background)', opacity: 0.9 };
      case 'failed':
        return { backgroundColor: 'var(--color-error)', color: 'var(--color-background)', opacity: 0.9 };
      default:
        return { backgroundColor: 'var(--color-surface)', color: 'var(--color-text)' };
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Activity className="w-8 h-8 animate-spin" style={{ color: 'var(--color-primary)' }} />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold" style={{ color: 'var(--color-text)' }}>Books Library</h1>
          <p className="mt-1" style={{ color: 'var(--color-textMuted)' }}>View and manage all generated books</p>
        </div>
      </div>

      {books.length === 0 ? (
        <div
          className="rounded-xl shadow-sm border p-12 text-center"
          style={{
            backgroundColor: 'var(--color-surface)',
            borderColor: 'var(--color-border)',
          }}
        >
          <BookOpen className="w-16 h-16 mx-auto mb-4" style={{ color: 'var(--color-textMuted)' }} />
          <h2 className="text-2xl font-bold mb-2" style={{ color: 'var(--color-text)' }}>No books yet</h2>
          <p className="mb-6" style={{ color: 'var(--color-textMuted)' }}>
            Generate your first AI-powered educational book to get started
          </p>
          <button
            onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: { page: 'generate' } }))}
            className="px-6 py-3 font-medium rounded-lg transition"
            style={{
              backgroundColor: 'var(--color-primary)',
              color: 'var(--color-background)',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = 'var(--color-primaryHover)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'var(--color-primary)';
            }}
          >
            Generate Your First Book
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6">
          {books.map((book) => (
            <div
              key={book.id}
              className="rounded-xl shadow-sm border overflow-hidden hover:shadow-lg transition"
              style={{
                backgroundColor: 'var(--color-surface)',
                borderColor: 'var(--color-border)',
              }}
            >
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-xl font-bold" style={{ color: 'var(--color-text)' }}>{book.title}</h3>
                      {book.is_demo && (
                        <span
                          className="px-2 py-1 text-xs font-medium rounded"
                          style={{
                            backgroundColor: 'var(--color-accent)',
                            color: 'var(--color-background)',
                          }}
                        >
                          DEMO
                        </span>
                      )}
                      <span className="px-2 py-1 text-xs font-medium rounded" style={getStatusStyle(book.status)}>
                        {book.status}
                      </span>
                    </div>
                    <p style={{ color: 'var(--color-textMuted)' }} className="mb-2">Subject: <span className="font-medium" style={{ color: 'var(--color-text)' }}>{book.subject}</span></p>
                    {book.description && (
                      <p className="text-sm" style={{ color: 'var(--color-textMuted)' }}>{book.description}</p>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    {getStatusIcon(book.status)}
                  </div>
                </div>

                <div className="flex items-center gap-4 text-sm mb-4" style={{ color: 'var(--color-textMuted)' }}>
                  <span>Created: {new Date(book.created_at).toLocaleDateString()}</span>
                  {book.completed_at && (
                    <span>Completed: {new Date(book.completed_at).toLocaleDateString()}</span>
                  )}
                </div>

                {(book.status === 'processing' || book.status === 'pending') && (
                  <div className="mb-4">
                    <button
                      onClick={() => setSelectedBook(selectedBook === book.id ? null : book.id)}
                      className="text-sm font-medium"
                      style={{ color: 'var(--color-primary)' }}
                    >
                      {selectedBook === book.id ? 'Hide Progress' : 'Show Progress'}
                    </button>
                    {selectedBook === book.id && (
                      <div className="mt-4">
                        <ProgressTracker bookId={book.id} />
                      </div>
                    )}
                  </div>
                )}

                <div className="flex items-center gap-3 pt-4 border-t" style={{ borderColor: 'var(--color-border)' }}>
                  {book.status === 'completed' && bookVersions[book.id] && (
                    <>
                      <div className="flex flex-wrap gap-2">
                        {bookVersions[book.id]
                          .filter(v => v.file_url)
                          .map((version) => (
                            <a
                              key={version.id}
                              href={version.file_url!}
                              download
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center gap-2 px-4 py-2 rounded-lg transition text-sm"
                              style={{
                                backgroundColor: 'var(--color-primary)',
                                color: 'var(--color-background)',
                              }}
                              onMouseEnter={(e) => {
                                e.currentTarget.style.backgroundColor = 'var(--color-primaryHover)';
                              }}
                              onMouseLeave={(e) => {
                                e.currentTarget.style.backgroundColor = 'var(--color-primary)';
                              }}
                            >
                              <Download className="w-4 h-4" />
                              {version.format_type.toUpperCase()} - {version.reading_level}
                            </a>
                          ))}
                        {bookVersions[book.id].filter(v => v.file_url).length === 0 && (
                          <span className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
                            No files available yet
                          </span>
                        )}
                      </div>
                    </>
                  )}
                  <button
                    onClick={() => deleteBook(book.id)}
                    className="ml-auto flex items-center gap-2 px-4 py-2 rounded-lg transition text-sm"
                    style={{
                      backgroundColor: 'var(--color-error)',
                      color: 'var(--color-background)',
                      opacity: 0.8,
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.opacity = '1';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.opacity = '0.8';
                    }}
                  >
                    <Trash2 className="w-4 h-4" />
                    Delete
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
