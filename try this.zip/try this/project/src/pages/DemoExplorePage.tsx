import { useState } from 'react';
import { BookOpen, Download, Eye, Star, ArrowLeft, Sparkles, Play } from 'lucide-react';
import { SimulatedGenerationModal } from '../components/SimulatedGenerationModal';

interface DemoExplorePageProps {
  onBack: () => void;
  onSignUp: () => void;
}

const SAMPLE_BOOKS = [
  {
    id: '1',
    title: 'The Solar System - Educational Guide',
    subject: 'Astronomy',
    description: 'A comprehensive guide to our solar system, including planets, moons, and celestial mechanics',
    readingLevel: 'High School',
    format: 'PDF',
    pages: 42,
    thumbnail: '🌌',
  },
  {
    id: '2',
    title: 'Ancient Egypt - Educational Guide',
    subject: 'History',
    description: 'Explore the fascinating world of ancient Egypt, from pyramids to pharaohs',
    readingLevel: 'Middle School',
    format: 'EPUB',
    pages: 38,
    thumbnail: '🏛️',
  },
  {
    id: '3',
    title: 'Photosynthesis - Educational Guide',
    subject: 'Biology',
    description: 'Understanding how plants convert sunlight into energy through photosynthesis',
    readingLevel: 'Elementary',
    format: 'Interactive',
    pages: 25,
    thumbnail: '🌱',
  },
  {
    id: '4',
    title: 'Python Programming - Educational Guide',
    subject: 'Computer Science',
    description: 'Learn Python programming from basics to advanced concepts with hands-on examples',
    readingLevel: 'Bachelors',
    format: 'Video Series',
    pages: 156,
    thumbnail: '💻',
  },
];

export function DemoExplorePage({ onBack, onSignUp }: DemoExplorePageProps) {
  const [showSimulation, setShowSimulation] = useState(false);
  const [selectedBook, setSelectedBook] = useState<string | null>(null);

  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--color-background)' }}>
      <div className="max-w-6xl mx-auto px-6 py-8">
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 px-4 py-2 rounded-lg transition"
            style={{
              backgroundColor: 'var(--color-surface)',
              color: 'var(--color-text)',
            }}
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </button>

          <button
            onClick={onSignUp}
            className="flex items-center gap-2 px-6 py-3 rounded-lg transition font-semibold"
            style={{
              backgroundColor: 'var(--color-primary)',
              color: 'var(--color-background)',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = 'var(--color-primaryHover)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'var(--color-primary)';
            }}
          >
            <Sparkles className="w-5 h-5" />
            Request Demo Access
          </button>
        </div>

        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-3" style={{ color: 'var(--color-text)' }}>
            Sample Generated Books
          </h1>
          <p className="text-lg" style={{ color: 'var(--color-textMuted)' }}>
            Explore examples of AI-generated educational content. Request demo access to see the full system in action!
          </p>
        </div>

        <div
          className="rounded-xl p-6 mb-8"
          style={{
            background: `linear-gradient(135deg, var(--color-surface), var(--color-surfaceHover))`,
            borderWidth: '1px',
            borderStyle: 'solid',
            borderColor: 'var(--color-border)',
          }}
        >
          <div className="flex items-center gap-3 mb-4">
            <Star className="w-6 h-6" style={{ color: 'var(--color-accent)' }} />
            <h2 className="text-xl font-bold" style={{ color: 'var(--color-text)' }}>
              Demo Mode Features
            </h2>
          </div>
          <ul className="space-y-2" style={{ color: 'var(--color-textSecondary)' }}>
            <li className="flex items-start gap-2">
              <span style={{ color: 'var(--color-accent)' }}>•</span>
              <span>Browse pre-generated sample books across various subjects</span>
            </li>
            <li className="flex items-start gap-2">
              <span style={{ color: 'var(--color-accent)' }}>•</span>
              <span>Preview different reading levels and formats</span>
            </li>
            <li className="flex items-start gap-2">
              <span style={{ color: 'var(--color-accent)' }}>•</span>
              <span>Experience our beautiful theme system</span>
            </li>
            <li className="flex items-start gap-2">
              <span style={{ color: 'var(--color-accent)' }}>•</span>
              <span>Request demo access to see the full generation system!</span>
            </li>
          </ul>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {SAMPLE_BOOKS.map((book) => (
            <div
              key={book.id}
              className="rounded-xl shadow-sm border overflow-hidden transition cursor-pointer"
              style={{
                backgroundColor: 'var(--color-surface)',
                borderColor: 'var(--color-border)',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-4px)';
                e.currentTarget.style.boxShadow = '0 12px 24px rgba(0,0,0,0.1)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = '';
              }}
              onClick={() => setSelectedBook(selectedBook === book.id ? null : book.id)}
            >
              <div
                className="h-32 flex items-center justify-center text-6xl"
                style={{
                  background: `linear-gradient(135deg, var(--color-primary), var(--color-accent))`,
                }}
              >
                {book.thumbnail}
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2" style={{ color: 'var(--color-text)' }}>
                  {book.title}
                </h3>
                <p className="text-sm mb-3" style={{ color: 'var(--color-textMuted)' }}>
                  {book.description}
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                  <span
                    className="px-3 py-1 text-xs font-medium rounded-full"
                    style={{
                      backgroundColor: 'var(--color-primary)',
                      color: 'var(--color-background)',
                    }}
                  >
                    {book.subject}
                  </span>
                  <span
                    className="px-3 py-1 text-xs font-medium rounded-full"
                    style={{
                      backgroundColor: 'var(--color-accent)',
                      color: 'var(--color-background)',
                    }}
                  >
                    {book.readingLevel}
                  </span>
                  <span
                    className="px-3 py-1 text-xs font-medium rounded-full"
                    style={{
                      backgroundColor: 'var(--color-secondary)',
                      color: 'var(--color-background)',
                    }}
                  >
                    {book.format}
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm" style={{ color: 'var(--color-textMuted)' }}>
                  <span>{book.pages} pages</span>
                  <div className="flex gap-2">
                    <button
                      className="p-2 rounded-lg transition"
                      style={{ color: 'var(--color-primary)' }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.backgroundColor = 'var(--color-surfaceHover)';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.backgroundColor = 'transparent';
                      }}
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    <button
                      className="p-2 rounded-lg transition"
                      style={{ color: 'var(--color-primary)' }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.backgroundColor = 'var(--color-surfaceHover)';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.backgroundColor = 'transparent';
                      }}
                    >
                      <Download className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <div
            className="rounded-2xl p-12"
            style={{
              backgroundColor: 'var(--color-surface)',
              borderWidth: '2px',
              borderStyle: 'solid',
              borderColor: 'var(--color-primary)',
            }}
          >
            <Sparkles className="w-16 h-16 mx-auto mb-4" style={{ color: 'var(--color-primary)' }} />
            <h2 className="text-3xl font-bold mb-4" style={{ color: 'var(--color-text)' }}>
              Example Books Showcase
            </h2>
            <p className="text-lg mb-6" style={{ color: 'var(--color-textMuted)' }}>
              These are sample books demonstrating the variety of topics, formats, and reading levels available. Explore the Generate page to create your own content.
            </p>
            <button
              onClick={() => setShowSimulation(true)}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition"
              style={{
                backgroundColor: 'var(--color-accent)',
                color: 'var(--color-background)',
              }}
            >
              <Play className="w-5 h-5" />
              Watch Generation Demo
            </button>
          </div>
        </div>
      </div>

      <SimulatedGenerationModal
        isOpen={showSimulation}
        onClose={() => setShowSimulation(false)}
        prompt="Sample Educational Book"
      />
    </div>
  );
}
