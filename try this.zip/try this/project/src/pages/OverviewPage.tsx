import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import {
  BookOpen, Activity, Clock, CheckCircle, AlertTriangle,
  Zap, DollarSign, Database, Server, TrendingUp,
  FileText, ChevronRight
} from 'lucide-react';
import { StatCard } from '../components/StatCard';

interface Stats {
  totalBooks: number;
  completedBooks: number;
  processingBooks: number;
  failedBooks: number;
}

interface RecentBook {
  id: string;
  title: string;
  subject: string;
  status: string;
  created_at: string;
}

interface SystemStatus {
  aiModels: { active: number; total: number };
  activePipelines: number;
  queuedJobs: number;
  todayCost: number;
}

export function OverviewPage() {
  const [stats, setStats] = useState<Stats>({
    totalBooks: 0,
    completedBooks: 0,
    processingBooks: 0,
    failedBooks: 0,
  });
  const [recentBooks, setRecentBooks] = useState<RecentBook[]>([]);
  const [systemStatus, setSystemStatus] = useState<SystemStatus>({
    aiModels: { active: 12, total: 12 },
    activePipelines: 3,
    queuedJobs: 7,
    todayCost: 12.45,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const { data: books } = await supabase
        .from('books')
        .select('id, title, subject, status, created_at')
        .order('created_at', { ascending: false })
        .limit(5);

      if (books) {
        setRecentBooks(books);
        setStats({
          totalBooks: books.length,
          completedBooks: books.filter(b => b.status === 'completed').length,
          processingBooks: books.filter(b => b.status === 'processing' || b.status === 'pending').length,
          failedBooks: books.filter(b => b.status === 'failed').length,
        });
      }
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const statCards = [
    {
      title: 'Total Books',
      value: stats.totalBooks,
      icon: BookOpen,
      colorType: 'primary' as const,
    },
    {
      title: 'Completed',
      value: stats.completedBooks,
      icon: CheckCircle,
      colorType: 'success' as const,
    },
    {
      title: 'Processing',
      value: stats.processingBooks,
      icon: Clock,
      colorType: 'warning' as const,
    },
    {
      title: 'Failed',
      value: stats.failedBooks,
      icon: AlertTriangle,
      colorType: 'error' as const,
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'var(--color-success)';
      case 'processing':
      case 'pending':
        return 'var(--color-warning)';
      case 'failed':
        return 'var(--color-error)';
      default:
        return 'var(--color-textMuted)';
    }
  };

  const getStatusText = (status: string) => {
    return status.charAt(0).toUpperCase() + status.slice(1);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Activity className="w-8 h-8 animate-spin" style={{ color: 'var(--color-primary)' }} />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold" style={{ color: 'var(--color-text)' }}>
          System Overview
        </h1>
        <p className="mt-1" style={{ color: 'var(--color-textMuted)' }}>
          Current status and recent activity
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((card) => (
          <StatCard
            key={card.title}
            title={card.title}
            value={card.value}
            icon={card.icon}
            colorType={card.colorType}
          />
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div
          className="rounded-xl shadow-sm border p-6"
          style={{
            backgroundColor: 'var(--color-surface)',
            borderColor: 'var(--color-border)',
          }}
        >
          <div className="flex items-center gap-2 mb-4">
            <Server className="w-5 h-5" style={{ color: 'var(--color-primary)' }} />
            <h2 className="text-lg font-bold" style={{ color: 'var(--color-text)' }}>
              System Status
            </h2>
          </div>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span style={{ color: 'var(--color-textMuted)' }}>AI Models</span>
              <span className="font-semibold" style={{ color: 'var(--color-success)' }}>
                {systemStatus.aiModels.active}/{systemStatus.aiModels.total} Active
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span style={{ color: 'var(--color-textMuted)' }}>Active Pipelines</span>
              <span className="font-semibold" style={{ color: 'var(--color-text)' }}>
                {systemStatus.activePipelines}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span style={{ color: 'var(--color-textMuted)' }}>Queued Jobs</span>
              <span className="font-semibold" style={{ color: 'var(--color-text)' }}>
                {systemStatus.queuedJobs}
              </span>
            </div>
          </div>
        </div>

        <div
          className="rounded-xl shadow-sm border p-6"
          style={{
            backgroundColor: 'var(--color-surface)',
            borderColor: 'var(--color-border)',
          }}
        >
          <div className="flex items-center gap-2 mb-4">
            <DollarSign className="w-5 h-5" style={{ color: 'var(--color-warning)' }} />
            <h2 className="text-lg font-bold" style={{ color: 'var(--color-text)' }}>
              Today's Usage
            </h2>
          </div>
          <div className="space-y-3">
            <div>
              <div className="text-3xl font-bold mb-1" style={{ color: 'var(--color-text)' }}>
                ${systemStatus.todayCost.toFixed(2)}
              </div>
              <div className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
                API costs today
              </div>
            </div>
            <div className="flex items-center gap-2 text-sm" style={{ color: 'var(--color-success)' }}>
              <TrendingUp className="w-4 h-4" />
              <span>Within budget</span>
            </div>
          </div>
        </div>

        <div
          className="rounded-xl shadow-sm border p-6"
          style={{
            backgroundColor: 'var(--color-surface)',
            borderColor: 'var(--color-border)',
          }}
        >
          <div className="flex items-center gap-2 mb-4">
            <Database className="w-5 h-5" style={{ color: 'var(--color-primary)' }} />
            <h2 className="text-lg font-bold" style={{ color: 'var(--color-text)' }}>
              Storage
            </h2>
          </div>
          <div className="space-y-3">
            <div>
              <div className="text-3xl font-bold mb-1" style={{ color: 'var(--color-text)' }}>
                {stats.totalBooks}
              </div>
              <div className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
                Books generated
              </div>
            </div>
            <div className="w-full h-2 rounded-full" style={{ backgroundColor: 'var(--color-border)' }}>
              <div
                className="h-2 rounded-full"
                style={{
                  backgroundColor: 'var(--color-primary)',
                  width: '23%',
                }}
              />
            </div>
            <div className="text-xs" style={{ color: 'var(--color-textMuted)' }}>
              23% of storage used
            </div>
          </div>
        </div>
      </div>

      <div
        className="rounded-xl shadow-sm border p-6"
        style={{
          backgroundColor: 'var(--color-surface)',
          borderColor: 'var(--color-border)',
        }}
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold" style={{ color: 'var(--color-text)' }}>
            Recent Books
          </h2>
          <button
            className="text-sm flex items-center gap-1 hover:underline"
            style={{ color: 'var(--color-primary)' }}
          >
            View All
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
        {recentBooks.length === 0 ? (
          <div className="text-center py-12" style={{ color: 'var(--color-textMuted)' }}>
            <FileText className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>No books generated yet</p>
            <p className="text-sm mt-1">Start by generating your first book</p>
          </div>
        ) : (
          <div className="space-y-3">
            {recentBooks.map((book) => (
              <div
                key={book.id}
                className="flex items-center justify-between p-4 rounded-lg border transition-all hover:shadow-md"
                style={{
                  borderColor: 'var(--color-border)',
                  backgroundColor: 'var(--color-background)',
                }}
              >
                <div className="flex items-center gap-3 flex-1 min-w-0">
                  <div
                    className="flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center"
                    style={{
                      backgroundColor: 'var(--color-primary)',
                      opacity: 0.1,
                    }}
                  >
                    <BookOpen
                      className="w-5 h-5"
                      style={{ color: 'var(--color-primary)', opacity: 1 }}
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold truncate" style={{ color: 'var(--color-text)' }}>
                      {book.title}
                    </div>
                    <div className="text-sm flex items-center gap-2">
                      <span style={{ color: 'var(--color-textMuted)' }}>
                        {book.subject}
                      </span>
                      <span style={{ color: 'var(--color-border)' }}>•</span>
                      <span style={{ color: 'var(--color-textMuted)' }}>
                        {new Date(book.created_at).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                </div>
                <div
                  className="px-3 py-1 rounded-full text-xs font-medium"
                  style={{
                    backgroundColor: getStatusColor(book.status),
                    color: 'var(--color-background)',
                    opacity: 0.9,
                  }}
                >
                  {getStatusText(book.status)}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div
        className="rounded-xl shadow-sm border p-6"
        style={{
          backgroundColor: 'var(--color-surface)',
          borderColor: 'var(--color-border)',
        }}
      >
        <h2 className="text-xl font-bold mb-4" style={{ color: 'var(--color-text)' }}>
          Quick Actions
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button
            className="p-4 border-2 border-dashed rounded-lg transition-all text-left hover:border-opacity-100"
            style={{
              borderColor: 'var(--color-border)',
              color: 'var(--color-text)',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = 'var(--color-primary)';
              e.currentTarget.style.backgroundColor = 'var(--color-surfaceHover)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = 'var(--color-border)';
              e.currentTarget.style.backgroundColor = 'transparent';
            }}
          >
            <div className="font-semibold mb-1" style={{ color: 'var(--color-text)' }}>
              Generate New Book
            </div>
            <div className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
              Start base book generation
            </div>
          </button>
          <button
            className="p-4 border-2 border-dashed rounded-lg transition-all text-left hover:border-opacity-100"
            style={{
              borderColor: 'var(--color-border)',
              color: 'var(--color-text)',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = 'var(--color-primary)';
              e.currentTarget.style.backgroundColor = 'var(--color-surfaceHover)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = 'var(--color-border)';
              e.currentTarget.style.backgroundColor = 'transparent';
            }}
          >
            <div className="font-semibold mb-1" style={{ color: 'var(--color-text)' }}>
              Monitor Pipelines
            </div>
            <div className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
              View active generation jobs
            </div>
          </button>
          <button
            className="p-4 border-2 border-dashed rounded-lg transition-all text-left hover:border-opacity-100"
            style={{
              borderColor: 'var(--color-border)',
              color: 'var(--color-text)',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = 'var(--color-primary)';
              e.currentTarget.style.backgroundColor = 'var(--color-surfaceHover)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = 'var(--color-border)';
              e.currentTarget.style.backgroundColor = 'transparent';
            }}
          >
            <div className="font-semibold mb-1" style={{ color: 'var(--color-text)' }}>
              Check API Keys
            </div>
            <div className="text-sm" style={{ color: 'var(--color-textMuted)' }}>
              Verify AI service status
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}
