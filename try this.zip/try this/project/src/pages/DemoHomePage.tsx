import { useState } from 'react';
import { BookOpen, Sparkles, ArrowRight, Settings, Cpu, LogIn, LogOut, User } from 'lucide-react';
import { SettingsModal } from '../components/SettingsModal';
import { AIModelsModal } from '../components/AIModelsModal';
import { BackToAdminButton } from '../components/BackToAdminButton';
import { useAuth } from '../contexts/AuthContext';

interface DemoHomePageProps {
  onNavigate: (page: string) => void;
  onSignUp: () => void;
}

const placeholderPrompts = [
  "Generate a comprehensive guide about...",
  "Create an educational book about...",
  "Build a learning resource on...",
  "Develop course content for...",
  "Design study materials about...",
];

export function DemoHomePage({ onNavigate, onSignUp }: DemoHomePageProps) {
  const { user, signOut } = useAuth();
  const [prompt, setPrompt] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [showAIModels, setShowAIModels] = useState(false);
  const [placeholder] = useState(() => placeholderPrompts[Math.floor(Math.random() * placeholderPrompts.length)]);
  const [numBooks, setNumBooks] = useState(1);

  const handleSignOut = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  const handleGenerate = () => {
    if (prompt.trim()) {
      onSignUp();
    }
  };

  const handleWatchDemo = () => {
    onNavigate('walkthrough');
  };

  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: 'var(--color-background)' }}>
      <BackToAdminButton onNavigate={onNavigate} />
      <header
        className="border-b"
        style={{
          backgroundColor: 'var(--color-surface)',
          borderColor: 'var(--color-border)',
        }}
      >
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className="p-2 rounded-lg"
              style={{ backgroundColor: 'var(--color-primary)' }}
            >
              <BookOpen className="w-6 h-6" style={{ color: 'var(--color-background)' }} />
            </div>
            <h1 className="text-xl font-bold" style={{ color: 'var(--color-text)' }}>
              OwlCraft
            </h1>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            <button
              onClick={() => onNavigate('about')}
              className="text-sm font-medium transition"
              style={{ color: 'var(--color-textSecondary)' }}
              onMouseEnter={(e) => {
                e.currentTarget.style.color = 'var(--color-text)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.color = 'var(--color-textSecondary)';
              }}
            >
              About
            </button>
            <button
              onClick={() => onNavigate('step-walkthrough')}
              className="text-sm font-medium transition"
              style={{ color: 'var(--color-textSecondary)' }}
              onMouseEnter={(e) => {
                e.currentTarget.style.color = 'var(--color-text)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.color = 'var(--color-textSecondary)';
              }}
            >
              Walkthrough
            </button>
            <button
              onClick={() => onNavigate('addons')}
              className="text-sm font-medium transition"
              style={{ color: 'var(--color-textSecondary)' }}
              onMouseEnter={(e) => {
                e.currentTarget.style.color = 'var(--color-text)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.color = 'var(--color-textSecondary)';
              }}
            >
              Add-ons
            </button>
            <button
              onClick={() => onNavigate('resources')}
              className="text-sm font-medium transition"
              style={{ color: 'var(--color-textSecondary)' }}
              onMouseEnter={(e) => {
                e.currentTarget.style.color = 'var(--color-text)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.color = 'var(--color-textSecondary)';
              }}
            >
              Resources
            </button>
            <button
              onClick={() => onNavigate('roadmap')}
              className="text-sm font-medium transition"
              style={{ color: 'var(--color-textSecondary)' }}
              onMouseEnter={(e) => {
                e.currentTarget.style.color = 'var(--color-text)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.color = 'var(--color-textSecondary)';
              }}
            >
              Roadmap
            </button>
            <button
              onClick={() => onNavigate('walkthrough')}
              className="text-sm font-medium transition"
              style={{ color: 'var(--color-textSecondary)' }}
              onMouseEnter={(e) => {
                e.currentTarget.style.color = 'var(--color-text)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.color = 'var(--color-textSecondary)';
              }}
            >
              Pipeline Demo
            </button>
            {user ? (
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg" style={{ backgroundColor: 'rgba(var(--color-primary-rgb, 139, 21, 56), 0.1)' }}>
                  <User className="w-4 h-4" style={{ color: 'var(--color-primary)' }} />
                  <span className="text-sm font-medium" style={{ color: 'var(--color-text)' }}>
                    {user.email}
                  </span>
                </div>
                <button
                  onClick={handleSignOut}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition"
                  style={{
                    backgroundColor: 'var(--color-surface)',
                    color: 'var(--color-text)',
                    border: '1px solid var(--color-border)',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.opacity = '0.8';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.opacity = '1';
                  }}
                >
                  <LogOut className="w-4 h-4" />
                  Sign Out
                </button>
              </div>
            ) : (
              <button
                onClick={onSignUp}
                className="flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition"
                style={{
                  backgroundColor: 'var(--color-primary)',
                  color: 'var(--color-background)',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.opacity = '0.9';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.opacity = '1';
                }}
              >
                <LogIn className="w-4 h-4" />
                Admin Login
              </button>
            )}
          </nav>

          <button
            onClick={onSignUp}
            className="md:hidden flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition"
            style={{
              backgroundColor: 'var(--color-primary)',
              color: 'var(--color-background)',
            }}
          >
            <LogIn className="w-4 h-4" />
            Login
          </button>
        </div>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center px-6 py-12">
        <div className="w-full max-w-5xl mx-auto text-center space-y-10">
          <div className="space-y-4">
            <h1 className="text-5xl md:text-6xl font-bold" style={{ color: 'var(--color-text)' }}>
              What will you <span style={{ color: 'var(--color-primary)' }}>create</span> today?
            </h1>
            <p className="text-xl max-w-2xl mx-auto" style={{ color: 'var(--color-textMuted)' }}>
              Generate comprehensive educational content in any format, for any reading level
            </p>
          </div>

          <div className="w-full max-w-2xl mx-auto">
            <div
              className="rounded-xl shadow-sm border"
              style={{
                backgroundColor: 'var(--color-surface)',
                borderColor: 'var(--color-border)',
              }}
            >
              <div className="p-4 flex flex-col min-h-[140px]">
                <div className="flex-1 flex items-center justify-center">
                  <textarea
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    onFocus={(e) => {
                      e.target.style.textAlign = 'left';
                      if (e.target.placeholder) {
                        e.target.placeholder = '';
                      }
                    }}
                    onBlur={(e) => {
                      if (!prompt) {
                        e.target.style.textAlign = 'center';
                        e.target.placeholder = placeholder;
                      }
                    }}
                    placeholder={placeholder}
                    className="w-full resize-none focus:outline-none text-base font-medium placeholder:text-center"
                    style={{
                      backgroundColor: 'transparent',
                      color: 'var(--color-text)',
                      textAlign: prompt ? 'left' : 'center',
                    }}
                    rows={2}
                  />
                </div>
                <div className="flex items-center justify-between pt-2">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setShowAIModels(true)}
                      className="p-1.5 rounded-lg transition flex items-center gap-1.5 text-sm"
                      style={{
                        color: showAIModels ? 'var(--color-primary)' : 'var(--color-textSecondary)',
                      }}
                      title="AI service providers"
                    >
                      <Cpu className="w-4 h-4" />
                      <span>AI Services</span>
                    </button>
                    <button
                      onClick={() => setShowSettings(true)}
                      className="p-1.5 rounded-lg transition flex items-center gap-1.5 text-sm"
                      style={{
                        color: showSettings ? 'var(--color-primary)' : 'var(--color-textSecondary)',
                      }}
                      title="Generation settings"
                    >
                      <Settings className="w-4 h-4" />
                      <span>Settings</span>
                    </button>
                    <button
                      onClick={handleWatchDemo}
                      className="p-1.5 rounded-lg transition flex items-center gap-1.5 text-sm"
                      style={{
                        color: 'var(--color-accent)',
                      }}
                      title="Watch generation demo"
                    >
                      <Sparkles className="w-4 h-4" />
                      <span>Watch Demo</span>
                    </button>
                  </div>
                  <button
                    onClick={handleGenerate}
                    disabled={!prompt.trim()}
                    className="px-5 py-2.5 rounded-lg font-medium transition flex items-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed"
                    style={{
                      backgroundColor: prompt.trim() ? 'var(--color-primary)' : 'var(--color-surfaceHover)',
                      color: prompt.trim() ? 'var(--color-background)' : 'var(--color-textMuted)',
                    }}
                    onMouseEnter={(e) => {
                      if (prompt.trim()) {
                        e.currentTarget.style.backgroundColor = 'var(--color-primaryHover)';
                      }
                    }}
                    onMouseLeave={(e) => {
                      if (prompt.trim()) {
                        e.currentTarget.style.backgroundColor = 'var(--color-primary)';
                      }
                    }}
                  >
                    Generate
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-12">
            <h2 className="text-2xl font-bold mb-6 text-center" style={{ color: 'var(--color-text)' }}>
              What's Included Per Book
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 max-w-7xl mx-auto">
              <div
                className="rounded-lg p-4"
                style={{
                  backgroundColor: 'var(--color-surface)',
                  borderWidth: '1px',
                  borderStyle: 'solid',
                  borderColor: 'var(--color-border)',
                }}
              >
                <div className="flex items-center gap-2 mb-3">
                  <div className="text-3xl font-bold" style={{ color: 'var(--color-primary)' }}>8</div>
                  <h3 className="text-base font-semibold" style={{ color: 'var(--color-text)' }}>
                    Reading Levels
                  </h3>
                </div>
                <p className="text-xs mb-2 font-semibold" style={{ color: 'var(--color-success)' }}>✓ Included</p>
                <ul className="space-y-1 text-xs font-medium" style={{ color: 'var(--color-textSecondary)' }}>
                  <li>• Kindergarten (5-6 years)</li>
                  <li>• Elementary (7-11 years)</li>
                  <li>• Middle School (12-14 years)</li>
                  <li>• High School (15-18 years)</li>
                  <li>• Bachelors/College</li>
                  <li>• Masters/Graduate</li>
                  <li>• PhD/Research</li>
                  <li>• Professional Edition</li>
                </ul>
              </div>


              <div
                className="rounded-lg p-4"
                style={{
                  backgroundColor: 'var(--color-surface)',
                  borderWidth: '1px',
                  borderStyle: 'solid',
                  borderColor: 'var(--color-border)',
                }}
              >
                <div className="flex items-center gap-2 mb-3">
                  <div className="text-3xl font-bold" style={{ color: 'var(--color-secondary)' }}>24</div>
                  <h3 className="text-base font-semibold" style={{ color: 'var(--color-text)' }}>
                    Subject Groups
                  </h3>
                </div>
                <p className="text-xs mb-2 font-semibold" style={{ color: 'var(--color-success)' }}>✓ Included</p>
                <ul className="space-y-1 text-xs font-medium" style={{ color: 'var(--color-textSecondary)' }}>
                  <li>• Academic Subjects</li>
                  <li>• Life Skills</li>
                  <li>• Professional Development</li>
                  <li>• Specialized Topics</li>
                  <li>• All with Custom Workflows</li>
                  <li>• Pipeline Visualizations</li>
                  <li>• Generation Tracking</li>
                  <li>• Quality Validation</li>
                </ul>
              </div>

              <div
                className="rounded-lg p-4"
                style={{
                  backgroundColor: 'var(--color-surface)',
                  borderWidth: '1px',
                  borderStyle: 'solid',
                  borderColor: 'var(--color-border)',
                }}
              >
                <div className="flex items-center gap-2 mb-3">
                  <div className="text-3xl font-bold" style={{ color: 'var(--color-accent)' }}>8</div>
                  <h3 className="text-base font-semibold" style={{ color: 'var(--color-text)' }}>
                    Educational Add-ons
                  </h3>
                </div>
                <p className="text-xs mb-2 font-semibold" style={{ color: 'var(--color-success)' }}>✓ Included</p>
                <ul className="space-y-1 text-xs font-medium" style={{ color: 'var(--color-textSecondary)' }}>
                  <li>• Activity Pack</li>
                  <li>• Worksheet Set</li>
                  <li>• Quiz Pack</li>
                  <li>• Answer Key</li>
                  <li>• Study Guide</li>
                  <li>• Visual Guide</li>
                  <li>• Video Scripts</li>
                  <li>• Lesson Plans</li>
                </ul>
              </div>

              <div
                className="rounded-lg p-4"
                style={{
                  backgroundColor: 'var(--color-surface)',
                  borderWidth: '1px',
                  borderStyle: 'solid',
                  borderColor: 'var(--color-border)',
                }}
              >
                <div className="flex items-center gap-2 mb-3">
                  <div className="text-3xl font-bold" style={{ color: 'var(--color-secondary)' }}>40</div>
                  <h3 className="text-base font-semibold" style={{ color: 'var(--color-text)' }}>
                    Disability Adaptations
                  </h3>
                </div>
                <p className="text-xs mb-2 font-semibold" style={{ color: 'var(--color-success)' }}>✓ Included</p>
                <ul className="space-y-1 text-xs font-medium" style={{ color: 'var(--color-textSecondary)' }}>
                  <li>• Autism Spectrum Disorder</li>
                  <li>• ADHD</li>
                  <li>• Learning Disabilities</li>
                  <li>• Visual & Hearing Impairments</li>
                  <li>• Physical Disabilities</li>
                  <li>• Developmental Conditions</li>
                  <li>• Behavioral Disorders</li>
                  <li>• And 33 more...</li>
                </ul>
              </div>

              <div
                className="rounded-lg p-4"
                style={{
                  backgroundColor: 'var(--color-surface)',
                  borderWidth: '1px',
                  borderStyle: 'solid',
                  borderColor: 'var(--color-border)',
                }}
              >
                <div className="flex items-center gap-2 mb-3">
                  <div className="text-3xl font-bold" style={{ color: 'var(--color-primary)' }}>10+</div>
                  <h3 className="text-base font-semibold" style={{ color: 'var(--color-text)' }}>
                    Format Options
                  </h3>
                </div>
                <p className="text-xs mb-2 font-semibold" style={{ color: 'var(--color-success)' }}>✓ Included</p>
                <ul className="space-y-1 text-xs font-medium" style={{ color: 'var(--color-textSecondary)' }}>
                  <li>• PDF (Print & Digital)</li>
                  <li>• EPUB (E-readers)</li>
                  <li>• Audiobook</li>
                  <li>• Large Print</li>
                  <li>• Braille</li>
                  <li>• Interactive HTML</li>
                  <li>• Binder Format</li>
                  <li>• Online Course</li>
                </ul>
              </div>

              <div
                className="rounded-lg p-4"
                style={{
                  backgroundColor: 'var(--color-surface)',
                  borderWidth: '1px',
                  borderStyle: 'solid',
                  borderColor: 'var(--color-border)',
                }}
              >
                <div className="flex items-center gap-2 mb-3">
                  <div className="text-3xl font-bold" style={{ color: 'var(--color-warning)' }}>100+</div>
                  <h3 className="text-base font-semibold" style={{ color: 'var(--color-text)' }}>
                    Languages
                  </h3>
                </div>
                <p className="text-xs mb-2 font-semibold" style={{ color: 'var(--color-success)' }}>✓ Included</p>
                <ul className="space-y-1 text-xs font-medium" style={{ color: 'var(--color-textSecondary)' }}>
                  <li>• Spanish</li>
                  <li>• French</li>
                  <li>• German</li>
                  <li>• Mandarin Chinese</li>
                  <li>• Japanese</li>
                  <li>• Arabic</li>
                  <li>• Hindi</li>
                  <li>• And 93+ more...</li>
                </ul>
              </div>
            </div>

          </div>
        </div>
      </main>

      <footer
        className="border-t py-6"
        style={{
          backgroundColor: 'var(--color-surface)',
          borderColor: 'var(--color-border)',
        }}
      >
        <div className="max-w-7xl mx-auto px-6 text-center text-sm" style={{ color: 'var(--color-textMuted)' }}>
          Educational content generation engine for various topics and formats.
        </div>
      </footer>

      <SettingsModal
        isOpen={showSettings}
        onClose={() => setShowSettings(false)}
        numBooks={numBooks}
        setNumBooks={setNumBooks}
      />

      <AIModelsModal
        isOpen={showAIModels}
        onClose={() => setShowAIModels(false)}
        numBooks={numBooks}
        setNumBooks={setNumBooks}
      />
    </div>
  );
}
