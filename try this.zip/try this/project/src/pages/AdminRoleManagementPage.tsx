import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Shield, User, Eye, Crown, Plus, Trash2, CheckCircle, AlertCircle } from 'lucide-react';

interface UserRole {
  id: string;
  user_id: string;
  role: 'admin' | 'user' | 'viewer';
  granted_at: string;
  user_email?: string;
}

export function AdminRoleManagementPage() {
  const [roles, setRoles] = useState<UserRole[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedUser, setSelectedUser] = useState('');
  const [selectedRole, setSelectedRole] = useState<'admin' | 'user' | 'viewer'>('user');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);

      const { data: rolesData, error: rolesError } = await supabase
        .from('user_roles')
        .select('*')
        .order('granted_at', { ascending: false });

      if (rolesError) throw rolesError;

      const { data: { users: usersData }, error: usersError } = await supabase.auth.admin.listUsers();

      if (usersError) throw usersError;

      const rolesWithEmails = rolesData?.map(role => ({
        ...role,
        user_email: usersData?.find(u => u.id === role.user_id)?.email || 'Unknown',
      })) || [];

      setRoles(rolesWithEmails);
      setUsers(usersData || []);
    } catch (err) {
      console.error('Error loading data:', err);
      setError('Note: Admin functions require Supabase service role key. Role management will be available in production.');
    } finally {
      setLoading(false);
    }
  };

  const grantRole = async () => {
    if (!selectedUser || !selectedRole) {
      setError('Please select a user and role');
      return;
    }

    try {
      setError('');
      setSuccess('');

      const { error: insertError } = await supabase
        .from('user_roles')
        .insert({
          user_id: selectedUser,
          role: selectedRole,
        });

      if (insertError) throw insertError;

      setSuccess(`Successfully granted ${selectedRole} role`);
      setShowAddModal(false);
      setSelectedUser('');
      setSelectedRole('user');
      loadData();
    } catch (err: any) {
      setError(err.message || 'Failed to grant role');
    }
  };

  const revokeRole = async (roleId: string) => {
    if (!confirm('Are you sure you want to revoke this role?')) return;

    try {
      setError('');
      setSuccess('');

      const { error: deleteError } = await supabase
        .from('user_roles')
        .delete()
        .eq('id', roleId);

      if (deleteError) throw deleteError;

      setSuccess('Role revoked successfully');
      loadData();
    } catch (err: any) {
      setError(err.message || 'Failed to revoke role');
    }
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'admin': return <Crown className="w-5 h-5 text-yellow-600" />;
      case 'user': return <User className="w-5 h-5 text-blue-600" />;
      case 'viewer': return <Eye className="w-5 h-5 text-gray-600" />;
      default: return <User className="w-5 h-5 text-gray-600" />;
    }
  };

  const getRoleBadge = (role: string) => {
    const styles = {
      admin: 'bg-yellow-100 text-yellow-800 border-yellow-300',
      user: 'bg-blue-100 text-blue-800 border-blue-300',
      viewer: 'bg-gray-100 text-gray-800 border-gray-300',
    };
    return styles[role as keyof typeof styles] || styles.viewer;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Shield className="w-12 h-12 text-blue-600 mx-auto mb-4 animate-pulse" />
          <p className="text-gray-600">Loading role management...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
            <h1 className="text-3xl font-bold text-gray-900">Admin Role Management</h1>
            <p className="text-gray-600 mt-2">Manage user permissions and access levels</p>
          </div>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
          >
            <Plus className="w-4 h-4" />
            Grant Role
          </button>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-red-900 font-medium">Error</p>
              <p className="text-red-700 text-sm mt-1">{error}</p>
            </div>
          </div>
        )}

        {success && (
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <p className="text-green-900">{success}</p>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-yellow-100 rounded-lg">
                <Crown className="w-6 h-6 text-yellow-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-900">
                  {roles.filter(r => r.role === 'admin').length}
                </div>
                <div className="text-sm text-gray-600">Administrators</div>
              </div>
            </div>
            <p className="text-xs text-gray-500 mt-3">Full system access and control</p>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-blue-100 rounded-lg">
                <User className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-900">
                  {roles.filter(r => r.role === 'user').length}
                </div>
                <div className="text-sm text-gray-600">Regular Users</div>
              </div>
            </div>
            <p className="text-xs text-gray-500 mt-3">Standard access for content creation</p>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-gray-100 rounded-lg">
                <Eye className="w-6 h-6 text-gray-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-900">
                  {roles.filter(r => r.role === 'viewer').length}
                </div>
                <div className="text-sm text-gray-600">Viewers</div>
              </div>
            </div>
            <p className="text-xs text-gray-500 mt-3">Read-only access to content</p>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="border-b border-gray-200 p-6">
            <h2 className="text-xl font-bold text-gray-900">User Roles</h2>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    User
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Role
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Granted
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {roles.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="px-6 py-12 text-center text-gray-500">
                      <Shield className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>No roles assigned yet</p>
                      <p className="text-sm mt-1">Grant roles to users to manage permissions</p>
                    </td>
                  </tr>
                ) : (
                  roles.map(role => (
                    <tr key={role.id} className="hover:bg-gray-50 transition">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white font-medium">
                            {role.user_email?.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <div className="font-medium text-gray-900">{role.user_email}</div>
                            <div className="text-xs text-gray-500">{role.user_id.substring(0, 8)}...</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          {getRoleIcon(role.role)}
                          <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getRoleBadge(role.role)}`}>
                            {role.role.toUpperCase()}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600">
                        {new Date(role.granted_at).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <button
                          onClick={() => revokeRole(role.id)}
                          className="text-red-600 hover:text-red-800 transition"
                          title="Revoke role"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Grant Role to User</h3>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Select User
                </label>
                <select
                  value={selectedUser}
                  onChange={(e) => setSelectedUser(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Choose a user...</option>
                  {users.map(user => (
                    <option key={user.id} value={user.id}>
                      {user.email}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Select Role
                </label>
                <div className="space-y-2">
                  {['admin', 'user', 'viewer'].map(role => (
                    <label key={role} className="flex items-center gap-3 p-3 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50">
                      <input
                        type="radio"
                        name="role"
                        value={role}
                        checked={selectedRole === role}
                        onChange={(e) => setSelectedRole(e.target.value as any)}
                        className="w-4 h-4"
                      />
                      <div className="flex items-center gap-2 flex-1">
                        {getRoleIcon(role)}
                        <div>
                          <div className="font-medium text-gray-900 capitalize">{role}</div>
                          <div className="text-xs text-gray-500">
                            {role === 'admin' && 'Full system access'}
                            {role === 'user' && 'Standard user access'}
                            {role === 'viewer' && 'Read-only access'}
                          </div>
                        </div>
                      </div>
                    </label>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <button
                onClick={() => {
                  setShowAddModal(false);
                  setSelectedUser('');
                  setSelectedRole('user');
                  setError('');
                }}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition"
              >
                Cancel
              </button>
              <button
                onClick={grantRole}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
              >
                Grant Role
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
