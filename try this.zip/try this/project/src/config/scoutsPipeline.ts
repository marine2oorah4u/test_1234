export interface ScoutContentType {
  id: string;
  name: string;
  description: string;
  category: 'merit-badge' | 'handbook' | 'insignia' | 'training' | 'program' | 'resource';
  estimatedPages: number;
  difficultyLevel: 'beginner' | 'intermediate' | 'advanced';
  requiredFields: string[];
}

export interface ScoutMeritBadge {
  id: string;
  name: string;
  category: string;
  requirements: string[];
  estimatedCompletionTime: string;
  skillLevel: 'beginner' | 'intermediate' | 'advanced';
  relatedBadges: string[];
}

export interface ScoutHandbook {
  id: string;
  name: string;
  type: 'scout' | 'cub-scout' | 'venture' | 'sea-scout' | 'leader';
  edition: string;
  sections: string[];
  pageCount: number;
}

export interface ScoutInsignia {
  id: string;
  name: string;
  type: 'patch' | 'badge' | 'ribbon' | 'pin' | 'emblem';
  category: string;
  placement: string;
  colors: string[];
  dimensions: string;
}

export interface ScoutTraining {
  id: string;
  name: string;
  type: 'youth' | 'adult' | 'leader' | 'specialist';
  duration: string;
  topics: string[];
  prerequisites: string[];
  certificationLevel?: string;
}

export const scoutContentTypes: ScoutContentType[] = [
  {
    id: 'merit-badge-booklet',
    name: 'Merit Badge Booklet',
    description: 'Complete merit badge requirements booklet with worksheets',
    category: 'merit-badge',
    estimatedPages: 24,
    difficultyLevel: 'intermediate',
    requiredFields: ['badge_name', 'category', 'requirements', 'resources'],
  },
  {
    id: 'merit-badge-counselor-guide',
    name: 'Merit Badge Counselor Guide',
    description: 'Guide for counselors teaching merit badge requirements',
    category: 'merit-badge',
    estimatedPages: 16,
    difficultyLevel: 'advanced',
    requiredFields: ['badge_name', 'teaching_tips', 'assessment_criteria'],
  },
  {
    id: 'scout-handbook',
    name: 'Scout Handbook',
    description: 'Complete handbook for scouts with skills and knowledge',
    category: 'handbook',
    estimatedPages: 200,
    difficultyLevel: 'beginner',
    requiredFields: ['rank', 'sections', 'skills', 'activities'],
  },
  {
    id: 'leader-handbook',
    name: 'Leader Handbook',
    description: 'Comprehensive guide for scout leaders',
    category: 'handbook',
    estimatedPages: 150,
    difficultyLevel: 'advanced',
    requiredFields: ['leadership_type', 'responsibilities', 'best_practices'],
  },
  {
    id: 'insignia-guide',
    name: 'Insignia & Uniform Guide',
    description: 'Visual guide to proper insignia placement and uniform standards',
    category: 'insignia',
    estimatedPages: 32,
    difficultyLevel: 'beginner',
    requiredFields: ['uniform_type', 'insignia_types', 'placement_diagrams'],
  },
  {
    id: 'training-syllabus',
    name: 'Training Syllabus',
    description: 'Complete training program with lesson plans and activities',
    category: 'training',
    estimatedPages: 48,
    difficultyLevel: 'advanced',
    requiredFields: ['training_name', 'objectives', 'lessons', 'assessments'],
  },
  {
    id: 'program-guide',
    name: 'Program Activity Guide',
    description: 'Collection of program activities and games',
    category: 'program',
    estimatedPages: 64,
    difficultyLevel: 'intermediate',
    requiredFields: ['activity_type', 'age_range', 'materials', 'instructions'],
  },
  {
    id: 'advancement-workbook',
    name: 'Rank Advancement Workbook',
    description: 'Workbook for tracking and completing rank requirements',
    category: 'resource',
    estimatedPages: 40,
    difficultyLevel: 'beginner',
    requiredFields: ['rank_name', 'requirements', 'tracking_sheets'],
  },
  {
    id: 'camping-guide',
    name: 'Camping & Outdoor Guide',
    description: 'Comprehensive guide to camping skills and outdoor activities',
    category: 'resource',
    estimatedPages: 80,
    difficultyLevel: 'intermediate',
    requiredFields: ['skills', 'safety', 'equipment', 'activities'],
  },
];

export const meritBadgeCategories = [
  'Arts & Crafts',
  'Business & Communication',
  'Citizenship & Community',
  'Environment & Conservation',
  'Health & Safety',
  'Outdoor Skills',
  'Science & Technology',
  'Sports & Recreation',
  'Trades & Vocations',
];

export const scoutRanks = [
  'Scout',
  'Tenderfoot',
  'Second Class',
  'First Class',
  'Star',
  'Life',
  'Eagle',
];

export const scoutPrograms = [
  'Cub Scouts (K-5th grade)',
  'Scouts BSA (11-17 years)',
  'Venturing (14-20 years)',
  'Sea Scouts (14-20 years)',
  'Exploring (10-20 years)',
];

export const leadershipPositions = [
  'Patrol Leader',
  'Senior Patrol Leader',
  'Scoutmaster',
  'Assistant Scoutmaster',
  'Committee Chair',
  'Merit Badge Counselor',
  'Den Leader',
  'Cubmaster',
];

export const scoutSkillCategories = [
  'First Aid & Safety',
  'Camping & Hiking',
  'Cooking & Nutrition',
  'Pioneering & Lashing',
  'Navigation & Orienteering',
  'Fire Building',
  'Knots & Rope Work',
  'Wildlife & Nature',
  'Leadership & Teamwork',
  'Citizenship & Service',
  'Emergency Preparedness',
  'Physical Fitness',
];

export const scoutWorkflowSteps = [
  {
    id: 'content-selection',
    name: 'Select Content Type',
    description: 'Choose what type of scout material to create',
    estimatedTime: '5 minutes',
  },
  {
    id: 'requirements-input',
    name: 'Input Requirements',
    description: 'Provide specific requirements and details',
    estimatedTime: '15 minutes',
  },
  {
    id: 'style-customization',
    name: 'Customize Style',
    description: 'Choose design theme and layout preferences',
    estimatedTime: '10 minutes',
  },
  {
    id: 'ai-generation',
    name: 'AI Generation',
    description: 'System generates content using multiple AI models',
    estimatedTime: '30-60 minutes',
  },
  {
    id: 'review-edit',
    name: 'Review & Edit',
    description: 'Review generated content and make adjustments',
    estimatedTime: '20 minutes',
  },
  {
    id: 'graphics-generation',
    name: 'Graphics Generation',
    description: 'Generate diagrams, illustrations, and insignia graphics',
    estimatedTime: '15-30 minutes',
  },
  {
    id: 'format-export',
    name: 'Format & Export',
    description: 'Generate final files in multiple formats',
    estimatedTime: '10 minutes',
  },
  {
    id: 'quality-check',
    name: 'Quality Assurance',
    description: 'Automated quality checks and compliance verification',
    estimatedTime: '5 minutes',
  },
];

export const scoutOutputFormats = [
  {
    id: 'pdf-print',
    name: 'PDF (Print Ready)',
    description: 'High-quality PDF optimized for printing',
  },
  {
    id: 'pdf-digital',
    name: 'PDF (Digital)',
    description: 'Interactive PDF with hyperlinks and bookmarks',
  },
  {
    id: 'workbook-fillable',
    name: 'Fillable Workbook',
    description: 'PDF with fillable form fields for tracking progress',
  },
  {
    id: 'presentation',
    name: 'Presentation Slides',
    description: 'PowerPoint/Slides for teaching and presentations',
  },
  {
    id: 'web-interactive',
    name: 'Interactive Web Version',
    description: 'HTML version with interactive elements',
  },
  {
    id: 'mobile-app',
    name: 'Mobile App Package',
    description: 'Content packaged for mobile app integration',
  },
  {
    id: 'print-booklet',
    name: 'Print Booklet Layout',
    description: 'Formatted for saddle-stitch or perfect binding',
  },
];

export const scoutDesignThemes = [
  {
    id: 'classic-scout',
    name: 'Classic Scout',
    description: 'Traditional scout aesthetic with earth tones',
    colors: ['#003F87', '#CE1126', '#FFD700', '#8B4513'],
  },
  {
    id: 'modern-adventure',
    name: 'Modern Adventure',
    description: 'Contemporary design with bold colors',
    colors: ['#E74C3C', '#3498DB', '#2ECC71', '#F39C12'],
  },
  {
    id: 'outdoor-explorer',
    name: 'Outdoor Explorer',
    description: 'Nature-inspired with forest and sky colors',
    colors: ['#2C5F2D', '#87CEEB', '#8B4513', '#FFD700'],
  },
  {
    id: 'eagle-scout',
    name: 'Eagle Scout Premium',
    description: 'Professional design for high-level materials',
    colors: ['#003F87', '#C41E3A', '#FFD700', '#1C1C1C'],
  },
  {
    id: 'patrol-friendly',
    name: 'Patrol Friendly',
    description: 'Fun and engaging for younger scouts',
    colors: ['#FF6B6B', '#4ECDC4', '#FFE66D', '#95E1D3'],
  },
];

export interface ScoutsGenerationWorkflow {
  contentType: string;
  category: string;
  requirements: Record<string, any>;
  designTheme: string;
  outputFormats: string[];
  aiModels: {
    contentGeneration: string[];
    graphicsGeneration: string[];
    qualityReview: string[];
  };
  estimatedTokens: number;
  estimatedCost: number;
  estimatedTime: string;
}

export const scoutsPipelineConfig = {
  id: 'scouts',
  name: 'Scouts System',
  description: 'Merit badges, handbooks, training materials, and scout-specific content',
  adminOnly: true,
  supportedContentTypes: scoutContentTypes,
  categories: meritBadgeCategories,
  ranks: scoutRanks,
  programs: scoutPrograms,
  workflowSteps: scoutWorkflowSteps,
  outputFormats: scoutOutputFormats,
  designThemes: scoutDesignThemes,
  features: {
    meritBadgeCreation: true,
    handbookGeneration: true,
    insigniaDesign: true,
    trainingMaterialCreation: true,
    uniformGuides: true,
    activityPlanning: true,
    advancementTracking: true,
  },
  integrations: {
    scoutingOrg: false, // Future: Official BSA integration
    meritBadgeDatabase: true,
    rankRequirementsDb: true,
    insigniaLibrary: true,
  },
};
