export interface MicroTask {
  name: string;
  status: 'pending' | 'in_progress' | 'completed';
  detail?: string;
}

export interface PipelineStep {
  id: string;
  category: string;
  pipeline: string;
  title: string;
  description: string;
  technicalDetails: string;
  whyItMatters: string;
  workers: { type: string; count: number }[];
  duration: number; // in milliseconds for demo timing
  estimatedRealTime: string;
  output: string;
  logLines: string[];
  microTasks?: MicroTask[];
}

export interface PipelineDemo {
  id: string;
  name: string;
  description: string;
  totalDuration: number;
  steps: PipelineStep[];
}

// Demo 1: Complete System Overview (All 11 Pipelines)
const completeSystemSteps: PipelineStep[] = [
  // PIPELINE 1: Master Reference Book
  {
    id: 'p1-research',
    category: 'Pipeline 1: Master Book',
    pipeline: 'Master Reference Book Generation',
    title: 'Research Phase - Multi-AI Collaboration',
    description: 'Four AI models simultaneously research the topic "Introduction to Photosynthesis" from multiple authoritative sources.',
    technicalDetails: 'GPT-4 focuses on scientific accuracy, Claude handles comprehensiveness, Gemini cross-references facts, and Llama identifies visual opportunities.',
    whyItMatters: 'Multiple AI models ensure accuracy and comprehensiveness. Each AI has different strengths - combining them creates superior content.',
    workers: [
      { type: 'GPT-4', count: 1 },
      { type: 'Claude', count: 1 },
      { type: 'Gemini', count: 1 },
      { type: 'Llama', count: 1 }
    ],
    duration: 4000,
    estimatedRealTime: '2-3 minutes',
    output: 'Research synthesis with 50+ citations',
    logLines: [
      '> Initializing research phase...',
      '> GPT-4: Scanning scientific databases...',
      '> Claude: Verifying source credibility...',
      '> Gemini: Cross-referencing facts...',
      '> Llama: Identifying diagram opportunities...',
      '✓ Research complete: 50+ citations gathered'
    ],
    microTasks: [
      { name: 'GPT-4: Search Wikipedia', status: 'pending', detail: 'en.wikipedia.org/wiki/Photosynthesis' },
      { name: 'GPT-4: Search Khan Academy', status: 'pending', detail: 'khanacademy.org/biology' },
      { name: 'GPT-4: Search Nature.com journals', status: 'pending', detail: 'nature.com/subjects/photosynthesis' },
      { name: 'Claude: Search NCBI database', status: 'pending', detail: 'ncbi.nlm.nih.gov/pubmed' },
      { name: 'Claude: Search ScienceDirect', status: 'pending', detail: 'sciencedirect.com' },
      { name: 'Claude: Verify source credibility', status: 'pending', detail: 'Cross-checking 50+ sources' },
      { name: 'Gemini: Cross-reference facts', status: 'pending', detail: 'Validating scientific claims' },
      { name: 'Gemini: Check for contradictions', status: 'pending', detail: 'Ensuring consistency' },
      { name: 'Llama: Identify diagram opportunities', status: 'pending', detail: 'Finding visual concepts' },
      { name: 'Llama: Map concept relationships', status: 'pending', detail: 'Creating visual structure' },
      { name: 'All Workers: Quality check', status: 'pending', detail: 'Final validation' },
      { name: 'All Workers: Compile synthesis', status: 'pending', detail: 'Merging 50+ citations' }
    ]
  },
  {
    id: 'p1-outline',
    category: 'Pipeline 1: Master Book',
    pipeline: 'Master Reference Book Generation',
    title: 'Outline Generation - 84 Section Structure',
    description: 'AI generates a comprehensive 84-section outline covering all aspects of the topic with logical progression.',
    technicalDetails: 'GPT-4 creates the master outline structure with 7 chapters, each containing 12 sections, ensuring complete topic coverage.',
    whyItMatters: 'A detailed outline ensures nothing is missed and content flows logically. This structure becomes the foundation for all adaptations.',
    workers: [{ type: 'GPT-4', count: 1 }],
    duration: 3000,
    estimatedRealTime: '1-2 minutes',
    output: '84-section detailed outline',
    logLines: [
      '> Generating master outline...',
      '> Creating chapter structure...',
      '> Chapter 1: Introduction (12 sections)',
      '> Chapter 2: Light Reactions (12 sections)',
      '> Chapter 3: Calvin Cycle (12 sections)',
      '> Chapters 4-7: Generated...',
      '✓ 84-section outline complete'
    ]
  },
  {
    id: 'p1-generate',
    category: 'Pipeline 1: Master Book',
    pipeline: 'Master Reference Book Generation',
    title: 'Content Generation - Chapter 1, Section 1',
    description: 'Four AI models collaborate to generate the first section with approximately 3,500 words of comprehensive content.',
    technicalDetails: 'GPT-4 writes primary content, Claude ensures accuracy, Llama adds visual descriptions, Gemini fact-checks. All work in parallel.',
    whyItMatters: 'Parallel processing by specialized AIs produces high-quality content faster than sequential generation. Each AI validates the others.',
    workers: [
      { type: 'GPT-4', count: 1 },
      { type: 'Claude', count: 1 },
      { type: 'Gemini', count: 1 },
      { type: 'Llama', count: 1 }
    ],
    duration: 5000,
    estimatedRealTime: '2-3 minutes per section',
    output: '3,487 words with citations',
    logLines: [
      '> Starting section 1 generation...',
      '> GPT-4: Writing primary content...',
      '> Claude: Ensuring scientific accuracy...',
      '> Llama: Adding visual descriptions...',
      '> Gemini: Cross-checking facts...',
      '> Section draft complete (3,487 words)',
      '> Running quality check...',
      '✓ Quality score: 94/100 - PASS'
    ]
  },
  {
    id: 'p1-verify',
    category: 'Pipeline 1: Master Book',
    pipeline: 'Master Reference Book Generation',
    title: 'Verification - 4-AI Consensus Check',
    description: 'All four AI models independently review the section for accuracy, completeness, and quality.',
    technicalDetails: 'Each AI scores the content on 10 criteria. If consensus score is below 90/100, automatic revision loop triggers.',
    whyItMatters: 'Human-level quality control at machine scale. No content passes without unanimous AI approval.',
    workers: [
      { type: 'GPT-4', count: 1 },
      { type: 'Claude', count: 1 },
      { type: 'Gemini', count: 1 },
      { type: 'Llama', count: 1 }
    ],
    duration: 3000,
    estimatedRealTime: '30-60 seconds',
    output: 'Verification scores and approval',
    logLines: [
      '> Running verification protocols...',
      '> GPT-4 verification: 95/100',
      '> Claude verification: 93/100',
      '> Gemini verification: 94/100',
      '> Llama verification: 92/100',
      '> Consensus score: 94/100',
      '✓ Section verified and approved'
    ]
  },
  {
    id: 'p1-parallel-generation',
    category: 'Pipeline 1: Master Book',
    pipeline: 'Master Reference Book Generation',
    title: 'Parallel Generation - All 84 Sections',
    description: 'System spawns 84 parallel worker threads, each generating one section simultaneously. This is where the real scale happens.',
    technicalDetails: '84 workers run in parallel. Each has 4 AI models (GPT-4, Claude, Gemini, Llama) = 336 AI instances working simultaneously.',
    whyItMatters: 'What would take 7 hours sequentially (84 sections × 5 min each) completes in just 5 minutes through massive parallelization.',
    workers: [
      { type: 'GPT-4', count: 84 },
      { type: 'Claude', count: 84 },
      { type: 'Gemini', count: 84 },
      { type: 'Llama', count: 84 }
    ],
    duration: 6000,
    estimatedRealTime: '5-7 minutes',
    output: '84 sections, ~295,000 words total',
    logLines: [
      '> Launching 84 parallel workers...',
      '> Worker pool initialized: 336 AI instances',
      '> Progress: 12/84 sections (14%)...',
      '> Progress: 42/84 sections (50%)...',
      '> Progress: 67/84 sections (80%)...',
      '> Progress: 84/84 sections (100%)',
      '> Aggregating all sections...',
      '✓ Complete book generated: 295,487 words'
    ],
    microTasks: [
      { name: 'Chapter 1: Sections 1-12', status: 'pending', detail: '42,143 words' },
      { name: 'Chapter 2: Sections 13-24', status: 'pending', detail: '41,892 words' },
      { name: 'Chapter 3: Sections 25-36', status: 'pending', detail: '43,256 words' },
      { name: 'Chapter 4: Sections 37-48', status: 'pending', detail: '42,011 words' },
      { name: 'Chapter 5: Sections 49-60', status: 'pending', detail: '41,734 words' },
      { name: 'Chapter 6: Sections 61-72', status: 'pending', detail: '42,567 words' },
      { name: 'Chapter 7: Sections 73-84', status: 'pending', detail: '41,884 words' },
      { name: 'Compile complete book', status: 'pending' }
    ]
  },
  {
    id: 'p1-final-verification',
    category: 'Pipeline 1: Master Book',
    pipeline: 'Master Reference Book Generation',
    title: 'Final Book Verification & Assembly',
    description: 'Complete book undergoes final quality checks, consistency verification, and assembly into master reference document.',
    technicalDetails: 'Cross-section consistency checks, citation validation, index generation, table of contents, metadata embedding.',
    whyItMatters: 'Ensures the 84 sections flow coherently as a single comprehensive work. Catches any inconsistencies between sections.',
    workers: [
      { type: 'GPT-4', count: 1 },
      { type: 'Claude', count: 1 }
    ],
    duration: 3000,
    estimatedRealTime: '2-3 minutes',
    output: 'Master Reference Book (complete)',
    logLines: [
      '> Running final book verification...',
      '> Cross-section consistency: PASS',
      '> Citation validation: 847 citations verified',
      '> Generating table of contents...',
      '> Building index: 2,341 entries',
      '> Embedding metadata...',
      '✓ Master Reference Book complete'
    ]
  },

  // PIPELINE 2: Reading Level Adaptations
  {
    id: 'p2-adapt',
    category: 'Pipeline 2: Reading Levels',
    pipeline: 'Reading Level Adaptations',
    title: 'Adapting to 7 Reading Levels',
    description: 'Master content is adapted to 7 reading levels from Kindergarten to PhD, maintaining accuracy while adjusting complexity.',
    technicalDetails: 'Specialized prompts for each level: Kindergarten (simple words), Elementary (basic concepts), Middle School (more detail), High School (comprehensive), College (technical), Graduate (advanced), PhD (expert).',
    whyItMatters: 'Same topic accessible to everyone. A 5-year-old and a doctoral student can both learn photosynthesis at their level.',
    workers: [
      { type: 'GPT-4', count: 7 },
      { type: 'Claude', count: 7 }
    ],
    duration: 4000,
    estimatedRealTime: '3-5 minutes per level',
    output: '7 versions of full book',
    logLines: [
      '> Starting reading level adaptations...',
      '> Kindergarten: Simplifying language...',
      '> Elementary: Basic concepts...',
      '> Middle School: Adding details...',
      '> High School: Comprehensive version...',
      '> College: Technical terminology...',
      '> Graduate: Advanced concepts...',
      '> PhD: Expert-level analysis...',
      '✓ All 7 levels generated'
    ]
  },

  // PIPELINE 3: Disability Adaptations
  {
    id: 'p3-dyslexia',
    category: 'Pipeline 3: Disabilities',
    pipeline: 'Disability Adaptations',
    title: 'Dyslexia-Friendly Version',
    description: 'Content is reformatted with dyslexia-friendly typography, spacing, and structure.',
    technicalDetails: 'OpenDyslexic font, 1.5x line spacing, increased margins, color overlays, shorter paragraphs, visual anchors.',
    whyItMatters: '10-20% of people have dyslexia. Specialized formatting dramatically improves reading comprehension.',
    workers: [{ type: 'Formatting Engine', count: 1 }],
    duration: 2000,
    estimatedRealTime: '1-2 minutes',
    output: 'Dyslexia-optimized PDF',
    logLines: [
      '> Applying dyslexia adaptations...',
      '> Font: Switching to OpenDyslexic...',
      '> Spacing: Increasing to 1.5x...',
      '> Paragraphs: Breaking into chunks...',
      '> Color: Adding beige overlay...',
      '✓ Dyslexia version complete'
    ]
  },
  {
    id: 'p3-visual',
    category: 'Pipeline 3: Disabilities',
    pipeline: 'Disability Adaptations',
    title: 'Visual Impairment Adaptations',
    description: 'Creating large print, high contrast, and audio versions for visually impaired learners.',
    technicalDetails: 'Large print (18pt+ font), high contrast colors, screen reader optimization, full audio narration with text-to-speech.',
    whyItMatters: '253 million people worldwide have visual impairments. Multiple formats ensure accessibility for all vision levels.',
    workers: [
      { type: 'Formatting Engine', count: 1 },
      { type: 'Text-to-Speech', count: 1 }
    ],
    duration: 3000,
    estimatedRealTime: '2-3 minutes',
    output: 'Large print PDF + Audio files',
    logLines: [
      '> Creating visual impairment versions...',
      '> Large Print: 18pt font, high contrast...',
      '> Audio: Generating narration...',
      '> TTS: Converting 50,000 words...',
      '> Duration: 3 hours 42 minutes',
      '✓ Visual accessibility complete'
    ]
  },

  // PIPELINE 4: Format Conversions
  {
    id: 'p4-formats',
    category: 'Pipeline 4: Formats',
    pipeline: 'Format Conversions',
    title: 'Converting to 8 Output Formats',
    description: 'Master content is converted to PDF, EPUB, MOBI, Audio, Video, Interactive Web, Braille, and Large Print.',
    technicalDetails: 'Parallel conversion engines for each format. PDF via LaTeX, EPUB via Pandoc, Audio via TTS, Video via slide generation.',
    whyItMatters: 'People learn differently. Some prefer reading, others listening. Multiple formats maximize accessibility.',
    workers: [{ type: 'Conversion Workers', count: 8 }],
    duration: 4000,
    estimatedRealTime: '5-10 minutes',
    output: '8 different file formats',
    logLines: [
      '> Starting format conversions...',
      '> PDF: Rendering with LaTeX...',
      '> EPUB: Converting for e-readers...',
      '> Audio: Generating 3hr 42min...',
      '> Video: Creating slides + narration...',
      '> Web: Building interactive version...',
      '> Braille: Converting to Grade 2...',
      '✓ All 8 formats complete'
    ]
  },

  // PIPELINE 5: Educational Add-ons
  {
    id: 'p5-worksheets',
    category: 'Pipeline 5: Add-ons',
    pipeline: 'Educational Add-ons',
    title: 'Auto-Generating Worksheets & Activities',
    description: 'AI creates 8 types of educational materials: worksheets, quizzes, flashcards, discussion questions, projects, assessments, study guides, and lab activities.',
    technicalDetails: 'Each add-on generated by specialized prompts. Worksheets have 10-15 problems, quizzes have 20-30 questions, flashcards have 50+ terms.',
    whyItMatters: 'Educators need supporting materials. Auto-generation saves hundreds of hours of prep work.',
    workers: [{ type: 'GPT-4', count: 8 }],
    duration: 5000,
    estimatedRealTime: '10-15 minutes',
    output: '8 complete educational packages',
    logLines: [
      '> Generating educational add-ons...',
      '> Worksheets: Creating 12 practice sets...',
      '> Quizzes: Generating 240 questions...',
      '> Flashcards: Making 436 cards...',
      '> Discussion: Writing 50 questions...',
      '> Projects: Designing 8 activities...',
      '> Assessments: Creating tests...',
      '✓ All add-ons generated'
    ]
  },

  // PIPELINE 6: Educator Packages
  {
    id: 'p6-lesson',
    category: 'Pipeline 6: Educators',
    pipeline: 'Educator Packages',
    title: 'Creating Lesson Plans & Teaching Guides',
    description: 'Complete teaching packages with lesson plans, pacing guides, answer keys, grading rubrics, and teaching tips.',
    technicalDetails: 'Lesson plans follow standard format: objectives, materials, procedure, assessment. Aligned to educational standards.',
    whyItMatters: 'Teachers need ready-to-use materials. Complete packages reduce prep time from hours to minutes.',
    workers: [{ type: 'GPT-4', count: 1 }],
    duration: 3000,
    estimatedRealTime: '5-10 minutes',
    output: 'Complete educator package',
    logLines: [
      '> Building educator packages...',
      '> Lesson plans: 84 lessons created...',
      '> Pacing guide: 12-week schedule...',
      '> Answer keys: All solutions included...',
      '> Rubrics: Grading standards defined...',
      '> Tips: Teaching strategies added...',
      '✓ Educator package complete'
    ]
  },

  // PIPELINE 7: Interactive Elements
  {
    id: 'p7-interactive',
    category: 'Pipeline 7: Interactive',
    pipeline: 'Interactive Elements',
    title: 'Building Interactive Learning Features',
    description: 'Creating VR environments, AR experiences, educational games, simulations, and AI tutoring for hands-on learning.',
    technicalDetails: 'VR via Unity/WebXR, AR via marker-based tracking, games use educational game design principles, AI tutor uses fine-tuned models.',
    whyItMatters: 'Interactive learning increases retention by 75%. Students learn by doing, not just reading.',
    workers: [
      { type: 'Unity Engine', count: 1 },
      { type: 'AR Generator', count: 1 },
      { type: 'Game Engine', count: 1 },
      { type: 'AI Tutor', count: 1 }
    ],
    duration: 4000,
    estimatedRealTime: '20-30 minutes',
    output: '6 interactive experiences',
    logLines: [
      '> Creating interactive elements...',
      '> VR: Building 3D chloroplast model...',
      '> AR: Generating plant markers...',
      '> Games: Creating photosynthesis puzzle...',
      '> Simulations: Building light reactions...',
      '> AI Tutor: Training on content...',
      '✓ Interactive features ready'
    ]
  },

  // PIPELINE 8: Binder Books
  {
    id: 'p8-binder',
    category: 'Pipeline 8: Binder Books',
    pipeline: 'Binder-Ready Books',
    title: 'Creating Print-and-Bind Versions',
    description: 'Formatting content for 3-ring binders with proper margins, hole punches, and section dividers.',
    technicalDetails: 'Wider left margins for binding, section dividers every chapter, page numbers positioned for visibility, durable paper recommendations.',
    whyItMatters: 'Many learners prefer physical books. Binder format allows updates, note-taking, and organization.',
    workers: [{ type: 'Layout Engine', count: 1 }],
    duration: 2000,
    estimatedRealTime: '2-3 minutes',
    output: 'Print-ready binder PDF',
    logLines: [
      '> Formatting for binder printing...',
      '> Margins: Adding 1.5" left margin...',
      '> Dividers: Creating 7 section tabs...',
      '> Pages: Adjusting for hole punches...',
      '> Print specs: Letter size, duplex...',
      '✓ Binder version ready'
    ]
  },

  // PIPELINE 9: Translations
  {
    id: 'p9-translate',
    category: 'Pipeline 9: Translations',
    pipeline: 'Multi-Language Translation',
    title: 'Translating to 100+ Languages',
    description: 'Master content translated to major world languages and indigenous languages using AI translation with human review.',
    technicalDetails: 'GPT-4 and Claude handle translation, maintaining technical accuracy. Cultural adaptation for context. Supports right-to-left languages.',
    whyItMatters: '75% of people do not speak English. Education should be accessible in native languages.',
    workers: [
      { type: 'GPT-4 Translation', count: 10 },
      { type: 'Claude Translation', count: 10 }
    ],
    duration: 5000,
    estimatedRealTime: '10-20 minutes per language',
    output: '100+ language versions',
    logLines: [
      '> Starting translation pipeline...',
      '> Spanish: Translating 50,000 words...',
      '> Mandarin: Converting terminology...',
      '> Arabic: RTL formatting applied...',
      '> Swahili: Cultural adaptation...',
      '> Navajo: Indigenous language support...',
      '> Progress: 100 languages complete',
      '✓ All translations finished'
    ]
  },

  // PIPELINE 10: Online Courses
  {
    id: 'p10-course',
    category: 'Pipeline 10: Courses',
    pipeline: 'Online Course Packaging',
    title: 'Building Complete Online Course',
    description: 'Converting content into structured online course with modules, videos, assignments, and progress tracking.',
    technicalDetails: 'LMS-compatible format (SCORM/xAPI), video lectures generated from content, automated grading, discussion prompts.',
    whyItMatters: 'Online learning is growing rapidly. Course format enables self-paced learning with tracking.',
    workers: [
      { type: 'Course Builder', count: 1 },
      { type: 'Video Generator', count: 1 }
    ],
    duration: 4000,
    estimatedRealTime: '30-45 minutes',
    output: 'Complete online course package',
    logLines: [
      '> Building online course...',
      '> Modules: Creating 7 course modules...',
      '> Videos: Generating 84 lectures...',
      '> Assignments: Creating 28 tasks...',
      '> Quizzes: Module assessments ready...',
      '> Progress: Tracking system enabled...',
      '✓ Course ready for LMS'
    ]
  },

  // PIPELINE 11: Special Collections
  {
    id: 'p11-special',
    category: 'Pipeline 11: Collections',
    pipeline: 'Special Collections',
    title: 'Creating Themed Collections & Series',
    description: 'Grouping related content into curated collections like "Complete Biology Series" or "Essential Math Skills".',
    technicalDetails: 'Metadata tagging for discovery, collection pages with progression paths, bundle packaging for downloads.',
    whyItMatters: 'Learners need clear paths through subjects. Collections provide structure and progression.',
    workers: [{ type: 'Collection Manager', count: 1 }],
    duration: 2000,
    estimatedRealTime: '5-10 minutes',
    output: 'Curated collections with metadata',
    logLines: [
      '> Creating special collections...',
      '> Biology Series: Grouping 24 topics...',
      '> Math Skills: Progressive path defined...',
      '> STEM Bundle: 156 books packaged...',
      '> Metadata: Tags and categories added...',
      '> Discovery: Search optimization ready...',
      '✓ Collections published'
    ]
  },

  // Final Summary
  {
    id: 'complete',
    category: 'System Complete',
    pipeline: 'All Pipelines',
    title: 'Generation Complete - Full System Output',
    description: 'All 11 pipelines have completed successfully. One topic has been transformed into thousands of learning resources.',
    technicalDetails: 'From one master book: 7 reading levels × 8 formats × 40 disability adaptations × 100 languages × 8 add-ons × interactive features = 1,792,000+ individual files generated.',
    whyItMatters: 'This is the power of AI-driven education at scale. One generation creates accessible learning for millions of people worldwide.',
    workers: [{ type: 'All Systems', count: 50 }],
    duration: 3000,
    estimatedRealTime: 'Total: 2-3 hours per topic',
    output: '1,792,000+ files ready for distribution',
    logLines: [
      '> ═══════════════════════════════════════',
      '> GENERATION COMPLETE',
      '> ═══════════════════════════════════════',
      '> Master books: 1',
      '> Reading levels: 7',
      '> Formats: 8',
      '> Disability versions: 40',
      '> Languages: 100',
      '> Add-ons: 8 types',
      '> Interactive features: 6',
      '> Total files: 1,792,000+',
      '> Storage used: 2.3 TB',
      '> Ready for distribution: YES',
      '> ═══════════════════════════════════════',
      '✓ System ready for next topic'
    ]
  }
];

// Demo 2: Pipeline 1 Deep Dive (Master Book Generation - Every Step)
const pipeline1DeepDiveSteps: PipelineStep[] = [
  {
    id: 'p1d-init',
    category: 'Initialization',
    pipeline: 'Pipeline 1 Deep Dive',
    title: 'System Initialization',
    description: 'Preparing the generation system for "Introduction to Photosynthesis" - PhD level master reference book.',
    technicalDetails: 'Allocating 4 AI model instances, setting up storage buckets, initializing verification system, loading educational standards.',
    whyItMatters: 'Proper setup ensures smooth generation. All resources must be ready before starting.',
    workers: [{ type: 'System Controller', count: 1 }],
    duration: 2000,
    estimatedRealTime: '10-15 seconds',
    output: 'System ready for generation',
    logLines: [
      '> Initializing OwlCraft generation system...',
      '> Loading AI models: GPT-4, Claude, Gemini, Llama',
      '> Storage: Allocating 5GB bucket',
      '> Verification: 4-AI consensus enabled',
      '> Standards: Loading NGSS science standards',
      '✓ System initialized successfully'
    ]
  },
  {
    id: 'p1d-research-1',
    category: 'Research Phase',
    pipeline: 'Pipeline 1 Deep Dive',
    title: 'Research Phase: Literature Review',
    description: 'GPT-4 conducts comprehensive literature review of photosynthesis research from peer-reviewed scientific journals.',
    technicalDetails: 'Searches PubMed, Google Scholar, and scientific databases for latest photosynthesis research. Filters for peer-reviewed, high-impact articles.',
    whyItMatters: 'Current, accurate information from credible sources forms the foundation of quality educational content.',
    workers: [{ type: 'GPT-4', count: 1 }],
    duration: 3000,
    estimatedRealTime: '1-2 minutes',
    output: '127 relevant scientific papers identified',
    logLines: [
      '> GPT-4: Starting literature review...',
      '> Searching PubMed database...',
      '> Found 1,243 photosynthesis papers',
      '> Filtering for relevance and impact...',
      '> Selected 127 high-quality sources',
      '> Impact factors: 3.5 - 42.0',
      '✓ Literature review complete'
    ]
  },
  {
    id: 'p1d-research-2',
    category: 'Research Phase',
    pipeline: 'Pipeline 1 Deep Dive',
    title: 'Research Phase: Fact Verification',
    description: 'Claude cross-references all facts and claims across multiple authoritative sources to ensure accuracy.',
    technicalDetails: 'Verifies each major claim against 3+ independent sources. Flags any conflicting information for additional review.',
    whyItMatters: 'Scientific accuracy is non-negotiable. Multiple-source verification catches errors and outdated information.',
    workers: [{ type: 'Claude', count: 1 }],
    duration: 3500,
    estimatedRealTime: '1-2 minutes',
    output: '856 facts verified, 3 flagged for review',
    logLines: [
      '> Claude: Verifying facts...',
      '> Cross-referencing 856 statements...',
      '> Source 1 confirmed: 854 facts',
      '> Source 2 confirmed: 853 facts',
      '> Source 3 confirmed: 856 facts',
      '> Flagged 3 for additional review',
      '> Resolving discrepancies...',
      '✓ All facts verified and corrected'
    ]
  },
  {
    id: 'p1d-research-3',
    category: 'Research Phase',
    pipeline: 'Pipeline 1 Deep Dive',
    title: 'Research Phase: Visual Content Planning',
    description: 'Llama identifies opportunities for diagrams, charts, and visual representations to enhance understanding.',
    technicalDetails: 'Analyzes content for complex concepts that benefit from visualization. Plans diagram types: flowcharts, molecular diagrams, process illustrations.',
    whyItMatters: 'Visual learners need diagrams. Complex processes like photosynthesis are clearer with illustrations.',
    workers: [{ type: 'Llama', count: 1 }],
    duration: 2500,
    estimatedRealTime: '30-60 seconds',
    output: '47 visual opportunities identified',
    logLines: [
      '> Llama: Planning visual content...',
      '> Analyzing for visual opportunities...',
      '> Chloroplast structure: 3D diagram',
      '> Light reactions: Animated flowchart',
      '> Calvin cycle: Process illustration',
      '> Identified 47 total visuals needed',
      '✓ Visual content plan complete'
    ]
  },
  {
    id: 'p1d-research-4',
    category: 'Research Phase',
    pipeline: 'Pipeline 1 Deep Dive',
    title: 'Research Phase: Synthesis & Citation',
    description: 'Gemini synthesizes all research into a coherent knowledge base with proper citations in scientific format.',
    technicalDetails: 'Creates citation database in APA format. Links each fact to source. Builds knowledge graph showing relationships between concepts.',
    whyItMatters: 'Proper citations allow verification and further study. Knowledge graph ensures logical content organization.',
    workers: [{ type: 'Gemini', count: 1 }],
    duration: 3000,
    estimatedRealTime: '1-2 minutes',
    output: 'Knowledge base with 127 citations',
    logLines: [
      '> Gemini: Synthesizing research...',
      '> Building knowledge graph...',
      '> Linking concepts: 342 connections',
      '> Formatting citations: APA style',
      '> Created bibliography: 127 sources',
      '> Knowledge base: 42,000 words',
      '✓ Research synthesis complete'
    ]
  },
  {
    id: 'p1d-outline-1',
    category: 'Outline Creation',
    pipeline: 'Pipeline 1 Deep Dive',
    title: 'Creating Master Outline Structure',
    description: 'GPT-4 designs comprehensive 7-chapter, 84-section outline covering all aspects of photosynthesis.',
    technicalDetails: 'Each chapter has 12 sections. Logical progression from basics to advanced. Aligned with graduate-level curriculum standards.',
    whyItMatters: 'Detailed outline ensures complete coverage and logical flow. This structure guides all subsequent content generation.',
    workers: [{ type: 'GPT-4', count: 1 }],
    duration: 4000,
    estimatedRealTime: '2-3 minutes',
    output: '7 chapters, 84 sections outlined',
    logLines: [
      '> GPT-4: Creating master outline...',
      '> Chapter 1: Introduction & Fundamentals',
      '> Chapter 2: Light-Dependent Reactions',
      '> Chapter 3: Calvin Cycle Mechanics',
      '> Chapter 4: Regulation & Control',
      '> Chapter 5: Evolutionary Perspectives',
      '> Chapter 6: Environmental Factors',
      '> Chapter 7: Applications & Future Research',
      '> Total sections: 84',
      '✓ Master outline complete'
    ]
  },
  {
    id: 'p1d-gen-1-1',
    category: 'Content Generation',
    pipeline: 'Pipeline 1 Deep Dive',
    title: 'Chapter 1, Section 1: Introduction',
    description: 'Generating the opening section: "What is Photosynthesis?" - approximately 3,500 words with citations.',
    technicalDetails: 'GPT-4 writes primary content, Claude ensures accuracy, Llama adds visual cues, Gemini validates citations. All work in parallel.',
    whyItMatters: 'First section sets the tone. Multiple AIs ensure quality from the start.',
    workers: [
      { type: 'GPT-4', count: 1 },
      { type: 'Claude', count: 1 },
      { type: 'Llama', count: 1 },
      { type: 'Gemini', count: 1 }
    ],
    duration: 5000,
    estimatedRealTime: '2-3 minutes',
    output: '3,487 words, 12 citations, 2 diagrams',
    logLines: [
      '> Generating Section 1.1...',
      '> GPT-4: Writing primary content...',
      '> Word count: 3,487',
      '> Claude: Verifying scientific accuracy...',
      '> Llama: Adding diagram descriptions...',
      '> Gemini: Validating 12 citations...',
      '✓ Section 1.1 draft complete'
    ]
  },
  {
    id: 'p1d-verify-1-1',
    category: 'Verification',
    pipeline: 'Pipeline 1 Deep Dive',
    title: 'Section Verification: 4-AI Consensus',
    description: 'All four AI models independently score Section 1.1 on 10 quality criteria. Consensus score must be 90+.',
    technicalDetails: 'Each AI evaluates: accuracy, completeness, clarity, citations, structure, readability, technical depth, visual aids, flow, and engagement.',
    whyItMatters: 'No content passes without unanimous AI approval. This ensures consistent PhD-level quality.',
    workers: [
      { type: 'GPT-4', count: 1 },
      { type: 'Claude', count: 1 },
      { type: 'Gemini', count: 1 },
      { type: 'Llama', count: 1 }
    ],
    duration: 3000,
    estimatedRealTime: '30-60 seconds',
    output: 'Consensus score: 94/100 - APPROVED',
    logLines: [
      '> Running verification protocols...',
      '> GPT-4 scoring...',
      '>   Accuracy: 10/10, Completeness: 9/10',
      '>   Overall: 95/100',
      '> Claude scoring...',
      '>   Accuracy: 10/10, Citations: 9/10',
      '>   Overall: 93/100',
      '> Gemini scoring: 94/100',
      '> Llama scoring: 92/100',
      '> Consensus: 94/100',
      '✓ Section approved - moving to next'
    ]
  }
];

// Demo 3: Pipeline 7 Deep Dive (Interactive Elements)
const pipeline7DeepDiveSteps: PipelineStep[] = [
  {
    id: 'p7d-init',
    category: 'Initialization',
    pipeline: 'Pipeline 7: Interactive Features',
    title: 'Interactive System Initialization',
    description: 'Preparing VR, AR, game engines, and AI tutor systems for photosynthesis interactive learning experiences.',
    technicalDetails: 'Loading Unity engine for VR/3D, AR.js for augmented reality, Phaser for educational games, fine-tuned GPT for AI tutoring.',
    whyItMatters: 'Interactive elements require specialized tools. Each learning modality needs different technology.',
    workers: [
      { type: 'Unity Engine', count: 1 },
      { type: 'AR System', count: 1 },
      { type: 'Game Engine', count: 1 },
      { type: 'AI Tutor', count: 1 }
    ],
    duration: 3000,
    estimatedRealTime: '1-2 minutes',
    output: 'All interactive systems online',
    logLines: [
      '> Initializing interactive systems...',
      '> Unity Engine: Loaded (VR ready)',
      '> AR.js: Loaded (marker tracking enabled)',
      '> Phaser: Loaded (game engine ready)',
      '> GPT-4 Tutor: Fine-tuned model loaded',
      '✓ All systems operational'
    ]
  },
  {
    id: 'p7d-vr-1',
    category: 'VR Development',
    pipeline: 'Pipeline 7: Interactive Features',
    title: 'VR: 3D Chloroplast Model Creation',
    description: 'Building detailed 3D model of chloroplast interior with thylakoids, stroma, and molecular machinery.',
    technicalDetails: 'High-poly 3D models created in Unity. Scientifically accurate based on electron microscopy. Interactive labels and hotspots.',
    whyItMatters: 'VR allows students to "walk inside" cellular structures. Understanding spatial relationships improves comprehension.',
    workers: [{ type: 'Unity 3D Artist', count: 1 }],
    duration: 4000,
    estimatedRealTime: '10-15 minutes',
    output: '3D chloroplast model (12,000 polygons)',
    logLines: [
      '> Unity: Creating 3D chloroplast...',
      '> Building outer membrane structure...',
      '> Adding thylakoid stacks...',
      '> Modeling ATP synthase molecules...',
      '> Creating stroma environment...',
      '> Adding interactive labels...',
      '> Polygons: 12,000',
      '✓ 3D model complete'
    ]
  },
  {
    id: 'p7d-vr-2',
    category: 'VR Development',
    pipeline: 'Pipeline 7: Interactive Features',
    title: 'VR: Light Reaction Animation',
    description: 'Creating animated simulation of light reactions with electron flow and photon absorption.',
    technicalDetails: 'Particle systems for electrons, shader effects for photons, animated molecular movements. Real-time at 60fps.',
    whyItMatters: 'Static diagrams cannot show dynamic processes. Animation reveals how photosynthesis actually works.',
    workers: [{ type: 'Unity Animator', count: 1 }],
    duration: 5000,
    estimatedRealTime: '15-20 minutes',
    output: 'Animated light reaction sequence',
    logLines: [
      '> Creating light reaction animation...',
      '> Photon absorption: Particle effects',
      '> Electron transport: Flow animation',
      '> ATP synthase: Rotation mechanics',
      '> Water splitting: H2O → H+ + O2',
      '> NADP+ reduction: Animation complete',
      '> Frame rate: 60fps maintained',
      '✓ Animation ready'
    ]
  },
  {
    id: 'p7d-ar-1',
    category: 'AR Development',
    pipeline: 'Pipeline 7: Interactive Features',
    title: 'AR: Plant Leaf Marker System',
    description: 'Creating AR markers that trigger 3D overlays when scanning real plant leaves with smartphone.',
    technicalDetails: 'Marker-based AR using AR.js. QR codes + natural feature tracking. Shows cross-section when scanning leaf.',
    whyItMatters: 'AR bridges physical and digital learning. Students can explore real plants with digital annotations.',
    workers: [{ type: 'AR Developer', count: 1 }],
    duration: 3500,
    estimatedRealTime: '10-15 minutes',
    output: '24 AR markers + 3D overlays',
    logLines: [
      '> Creating AR marker system...',
      '> Designing 24 unique markers...',
      '> Leaf cross-section: 3D overlay',
      '> Chloroplast zoom: Interactive view',
      '> Stomata function: Animation trigger',
      '> Marker tracking: 30fps stable',
      '✓ AR system ready'
    ]
  },
  {
    id: 'p7d-game-1',
    category: 'Game Development',
    pipeline: 'Pipeline 7: Interactive Features',
    title: 'Educational Game: Photosynthesis Puzzle',
    description: 'Building drag-and-drop game where students assemble light reactions by placing molecules in correct order.',
    technicalDetails: 'Phaser game engine. Drag-and-drop mechanics. Real-time validation. Progressive difficulty. Scoring system.',
    whyItMatters: 'Games make learning fun and memorable. Puzzle-solving reinforces understanding of process steps.',
    workers: [{ type: 'Game Developer', count: 1 }],
    duration: 4500,
    estimatedRealTime: '20-25 minutes',
    output: 'Interactive puzzle game (12 levels)',
    logLines: [
      '> Building photosynthesis puzzle game...',
      '> Creating drag-and-drop mechanics...',
      '> Level 1: Basic light absorption',
      '> Level 6: Complete electron transport',
      '> Level 12: Full light reactions',
      '> Scoring: Points + time bonuses',
      '> Hints: Available after 2 minutes',
      '✓ Game complete with 12 levels'
    ]
  },
  {
    id: 'p7d-sim-1',
    category: 'Simulation',
    pipeline: 'Pipeline 7: Interactive Features',
    title: 'Interactive Simulation: Environmental Factors',
    description: 'Building simulation where students adjust light, CO2, temperature, and water to see effects on photosynthesis rate.',
    technicalDetails: 'Real-time graph updates. Scientifically accurate response curves. Sliders for each variable. Save/compare experiments.',
    whyItMatters: 'Simulations allow experimentation impossible in classrooms. Students discover relationships through exploration.',
    workers: [{ type: 'Simulation Engine', count: 1 }],
    duration: 4000,
    estimatedRealTime: '15-20 minutes',
    output: 'Interactive environmental simulator',
    logLines: [
      '> Building environmental simulation...',
      '> Light intensity: 0-2000 μmol/m²/s',
      '> CO2 concentration: 0-2000 ppm',
      '> Temperature: 0-45°C',
      '> Water availability: 0-100%',
      '> Real-time graphing: Enabled',
      '> Response curves: Scientifically accurate',
      '✓ Simulation ready'
    ]
  },
  {
    id: 'p7d-tutor-1',
    category: 'AI Tutor',
    pipeline: 'Pipeline 7: Interactive Features',
    title: 'AI Tutor Training',
    description: 'Training personalized AI tutor on photosynthesis content to answer student questions and provide hints.',
    technicalDetails: 'Fine-tuned GPT-4 on all book content. Programmed to ask Socratic questions. Adjusts difficulty to student level.',
    whyItMatters: 'Personal tutors dramatically improve learning outcomes. AI tutor available 24/7 for every student.',
    workers: [{ type: 'GPT-4 Fine-tuning', count: 1 }],
    duration: 5000,
    estimatedRealTime: '30-45 minutes',
    output: 'Trained AI tutor model',
    logLines: [
      '> Training AI tutor on content...',
      '> Loading 50,000 words of content...',
      '> Training on 1,200 Q&A pairs...',
      '> Socratic questioning: Enabled',
      '> Difficulty adaptation: Active',
      '> Response time: <2 seconds',
      '> Accuracy: 97% on test questions',
      '✓ AI tutor ready'
    ]
  },
  {
    id: 'p7d-complete',
    category: 'Deployment',
    pipeline: 'Pipeline 7: Interactive Features',
    title: 'Interactive Features Complete',
    description: 'All interactive learning experiences are built, tested, and ready for student use.',
    technicalDetails: 'VR scene (WebXR), AR markers (AR.js), Games (HTML5), Simulations (WebGL), AI Tutor (API). All web-based, no installation required.',
    whyItMatters: 'Interactive features transform passive reading into active learning. Engagement increases retention by 75%.',
    workers: [{ type: 'All Systems', count: 6 }],
    duration: 3000,
    estimatedRealTime: 'Total: 2-3 hours per topic',
    output: '6 interactive experiences ready',
    logLines: [
      '> ═══════════════════════════════════════',
      '> INTERACTIVE FEATURES COMPLETE',
      '> ═══════════════════════════════════════',
      '> VR Experiences: 2 (chloroplast, reactions)',
      '> AR Markers: 24 (plant identification)',
      '> Educational Games: 1 (12 levels)',
      '> Simulations: 1 (environmental factors)',
      '> AI Tutor: 1 (trained and ready)',
      '> 3D Models: 47 objects',
      '> Animations: 23 sequences',
      '> Web-based: No installation required',
      '> Browser support: Chrome, Firefox, Safari',
      '> ═══════════════════════════════════════',
      '✓ Ready for student engagement'
    ]
  }
];

export const pipelineDemos: PipelineDemo[] = [
  {
    id: 'complete-system',
    name: 'Complete System Overview',
    description: 'Watch all 11 pipelines transform one topic into 1.7+ million learning resources',
    totalDuration: completeSystemSteps.reduce((sum, step) => sum + step.duration, 0),
    steps: completeSystemSteps
  },
  {
    id: 'pipeline-1-deep-dive',
    name: 'Pipeline 1: Master Book Deep Dive',
    description: 'Detailed walkthrough of PhD-level master reference book generation',
    totalDuration: pipeline1DeepDiveSteps.reduce((sum, step) => sum + step.duration, 0),
    steps: pipeline1DeepDiveSteps
  },
  {
    id: 'pipeline-7-deep-dive',
    name: 'Pipeline 7: Interactive Features Deep Dive',
    description: 'See how VR, AR, games, simulations, and AI tutors are created',
    totalDuration: pipeline7DeepDiveSteps.reduce((sum, step) => sum + step.duration, 0),
    steps: pipeline7DeepDiveSteps
  }
];
