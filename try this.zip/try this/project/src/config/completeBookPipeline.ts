export interface MicroTask {
  name: string;
  status: 'pending' | 'in_progress' | 'completed';
  detail?: string;
}

export interface PipelineStep {
  id: string;
  category: string;
  pipeline: string;
  title: string;
  description: string;
  technicalDetails: string;
  whyItMatters: string;
  workers: { type: string; count: number }[];
  duration: number;
  estimatedRealTime: string;
  output: string;
  logLines: string[];
  microTasks?: MicroTask[];
}

export interface PipelineDemo {
  id: string;
  name: string;
  description: string;
  totalDuration: number;
  steps: PipelineStep[];
}

// Complete Book Generation - All 18 Steps
const completeBookSteps: PipelineStep[] = [
  // SECTION PIPELINE (Steps 1-9) - Runs 84 times in parallel
  {
    id: 'step1-research',
    category: 'Section Pipeline',
    pipeline: 'Step 1 of 18',
    title: 'Research Phase',
    description: '5 research workers launch in parallel. Each queries 4 AI models (GPT-4, Claude, Gemini, Perplexity) simultaneously to gather authoritative sources.',
    technicalDetails: '5 workers × 4 models = 20 AI instances. Each worker queries all 4 models in parallel, receives responses in ~30 seconds, then Claude synthesizes the results. Total: ~50 seconds per worker.',
    whyItMatters: 'Parallel research across multiple AIs ensures comprehensive, unbiased coverage. What would take 4 minutes sequentially takes just 50 seconds. This runs for all 84 sections simultaneously.',
    workers: [
      { type: 'GPT-4', count: 5 },
      { type: 'Claude', count: 5 },
      { type: 'Gemini', count: 5 },
      { type: 'Perplexity', count: 5 }
    ],
    duration: 15000,
    estimatedRealTime: '2-5 minutes',
    output: '5 research packets (65 total citations)',
    logLines: [
      '> Launching 5 research workers for section...',
      '> Worker 1-5: Querying GPT-4, Claude, Gemini, Perplexity...',
      '> All 20 AI queries running in parallel...',
      '> T+00:30 - Responses received from all models',
      '> Claude synthesizing research...',
      '> Worker 1: Complete (12 citations)',
      '> Worker 2: Complete (15 citations)',
      '> Worker 3: Complete (11 citations)',
      '> Worker 4: Complete (13 citations)',
      '> Worker 5: Complete (14 citations)',
      '> Launching 5 verification workers...',
      '> All verifiers: PASS',
      '✓ Research complete: 65 citations ready'
    ],
    microTasks: [
      { name: 'Worker 1: Scientific databases', status: 'pending', detail: 'Querying 4 AIs...' },
      { name: 'Worker 2: Academic journals', status: 'pending', detail: 'Querying 4 AIs...' },
      { name: 'Worker 3: Textbook references', status: 'pending', detail: 'Querying 4 AIs...' },
      { name: 'Worker 4: Research papers', status: 'pending', detail: 'Querying 4 AIs...' },
      { name: 'Worker 5: Expert sources', status: 'pending', detail: 'Querying 4 AIs...' }
    ]
  },
  {
    id: 'step2-content',
    category: 'Section Pipeline',
    pipeline: 'Step 2 of 18',
    title: 'Content Creation',
    description: '5 content writers generate comprehensive text in parallel. Each queries 4 AI models to write content, then GPT-4 synthesizes the best version from all outputs.',
    technicalDetails: '5 writers × 4 models = 20 AI instances. Each produces ~700 words. GPT-4 synthesizes results, combining strengths from all versions. Target: 3,500 words total with academic rigor.',
    whyItMatters: 'Multiple independent drafts ensure quality and catch errors. The synthesis process combines the best explanations, examples, and phrasing from all 20 AI outputs.',
    workers: [
      { type: 'GPT-4', count: 5 },
      { type: 'Claude', count: 5 },
      { type: 'Gemini', count: 5 },
      { type: 'Perplexity', count: 5 }
    ],
    duration: 15000,
    estimatedRealTime: '3-7 minutes',
    output: '5 content versions (3,487 words)',
    logLines: [
      '> Launching 5 content writers...',
      '> Each writer querying 4 AI models...',
      '> 20 AI instances generating content...',
      '> Writer 1: Draft complete (724 words)',
      '> Writer 2: Draft complete (698 words)',
      '> Writer 3: Draft complete (712 words)',
      '> Writer 4: Draft complete (689 words)',
      '> Writer 5: Draft complete (701 words)',
      '> GPT-4 synthesizing best content...',
      '> Launching 5 verification workers...',
      '> Verification scores: 94, 96, 93, 95, 97',
      '✓ Content approved: 3,487 words'
    ],
    microTasks: [
      { name: 'GPT-4 Worker 1: Introduction', status: 'pending', detail: 'Writing opening section...' },
      { name: 'GPT-4 Worker 2: Core concepts', status: 'pending', detail: 'Explaining fundamentals...' },
      { name: 'GPT-4 Worker 3: Detailed explanation', status: 'pending', detail: 'Deep dive analysis...' },
      { name: 'GPT-4 Worker 4: Examples', status: 'pending', detail: 'Creating illustrations...' },
      { name: 'GPT-4 Worker 5: Summary', status: 'pending', detail: 'Key takeaways...' },
      { name: 'Claude: Verify scientific accuracy', status: 'pending', detail: 'Checking all 5 versions...' },
      { name: 'Gemini: Cross-check facts', status: 'pending', detail: 'Validating claims...' },
      { name: 'Perplexity: Research validation', status: 'pending', detail: 'Verifying citations...' },
      { name: 'All Workers: Compare versions', status: 'pending', detail: 'Finding best elements...' },
      { name: 'Final: Synthesize content', status: 'pending', detail: 'Merging final text...' }
    ]
  },
  {
    id: 'step3-merge',
    category: 'Section Pipeline',
    pipeline: 'Step 3 of 18',
    title: 'Merge & Combine',
    description: '5 merger workers combine the best elements from each content version into a unified, coherent final text.',
    technicalDetails: 'Each merger queries 4 AIs with all 5 content versions. They propose ideal combinations, then Claude selects and refines the best merged approach.',
    whyItMatters: 'Combining strengths from 5 independent versions creates higher quality than any single version alone. Ensures consistency and removes redundancy.',
    workers: [
      { type: 'GPT-4', count: 5 },
      { type: 'Claude', count: 5 },
      { type: 'Gemini', count: 5 },
      { type: 'Perplexity', count: 5 }
    ],
    duration: 15000,
    estimatedRealTime: '2-4 minutes',
    output: 'Unified content (3,487 words)',
    logLines: [
      '> Launching 5 merger workers...',
      '> Analyzing 5 content versions...',
      '> Each merger querying 4 AIs...',
      '> Merger 1: Proposal complete',
      '> Merger 2: Proposal complete',
      '> Merger 3: Proposal complete',
      '> Merger 4: Proposal complete',
      '> Merger 5: Proposal complete',
      '> Claude selecting best merge approach...',
      '> Launching 5 verifiers...',
      '> Coherence check: PASS',
      '✓ Merge complete: Final text unified'
    ]
  },
  {
    id: 'step4-media-identify',
    category: 'Section Pipeline',
    pipeline: 'Step 4 of 18',
    title: 'Identify Media Needs',
    description: '3 analyzer workers scan content to identify where images, diagrams, or charts would enhance understanding.',
    technicalDetails: 'Each analyzer queries 4 AIs to find complex concepts, processes, comparisons, or examples that benefit from visual representation. Generates ~10-12 placeholders per section.',
    whyItMatters: 'Strategic image placement dramatically improves comprehension and retention. Visual learners especially benefit. Identifies optimal locations before media search.',
    workers: [
      { type: 'GPT-4', count: 3 },
      { type: 'Claude', count: 3 },
      { type: 'Gemini', count: 3 },
      { type: 'Perplexity', count: 3 }
    ],
    duration: 15000,
    estimatedRealTime: '1-2 minutes',
    output: '12 media placeholders identified',
    logLines: [
      '> Launching 3 media analyzers...',
      '> Scanning content for visual opportunities...',
      '> Analyzer 1: Found 4 placeholder locations',
      '> Analyzer 2: Found 4 placeholder locations',
      '> Analyzer 3: Found 4 placeholder locations',
      '> Consolidating placeholder list...',
      '> Launching 3 verifiers...',
      '✓ Analysis complete: 12 placeholders'
    ],
    microTasks: [
      { name: 'Diagram: Process overview', status: 'pending' },
      { name: 'Photo: Real-world example', status: 'pending' },
      { name: 'Chart: Data comparison', status: 'pending' },
      { name: 'Illustration: Key concept', status: 'pending' },
      { name: 'Graph: Statistical data', status: 'pending' },
      { name: 'Photo: Equipment/tools', status: 'pending' },
      { name: 'Diagram: System flow', status: 'pending' },
      { name: 'Photo: Historical context', status: 'pending' },
      { name: 'Chart: Timeline', status: 'pending' },
      { name: 'Illustration: Abstract concept', status: 'pending' },
      { name: 'Photo: Case study', status: 'pending' },
      { name: 'Diagram: Flowchart', status: 'pending' }
    ]
  },
  {
    id: 'step5-media-search',
    category: 'Section Pipeline',
    pipeline: 'Step 5 of 18',
    title: 'Media Search',
    description: 'Massive parallel search: For each of 12 placeholders, 5 search workers launch. Each queries 4 AIs to search stock libraries. 60 workers total running simultaneously.',
    technicalDetails: '60 workers × 4 models = 240 AI instances searching Adobe Stock, Unsplash, Pexels in parallel. Each finds 8-12 candidates, synthesizes top 3. Completes in ~45 seconds.',
    whyItMatters: 'This is the most worker-intensive step. Massive parallelization finds perfect images quickly while maintaining quality. What would take hours happens in under a minute.',
    workers: [
      { type: 'GPT-4', count: 60 },
      { type: 'Claude', count: 60 },
      { type: 'Gemini', count: 60 },
      { type: 'Perplexity', count: 60 }
    ],
    duration: 15000,
    estimatedRealTime: '3-8 minutes',
    output: '36 image candidates (3 per placeholder)',
    logLines: [
      '> Launching 60 image search workers...',
      '> 240 AI instances searching stock libraries...',
      '> Searching Adobe Stock, Unsplash, Pexels...',
      '> Progress: 20/60 workers complete (33%)...',
      '> Progress: 40/60 workers complete (67%)...',
      '> Progress: 60/60 workers complete (100%)',
      '> Scoring and ranking all candidates...',
      '> Launching 36 verification workers...',
      '> Checking quality, relevance, licensing...',
      '✓ Search complete: 36 top candidates'
    ]
  },
  {
    id: 'step6-media-insert',
    category: 'Section Pipeline',
    pipeline: 'Step 6 of 18',
    title: 'Media Insertion',
    description: '3 insertion workers embed approved images into content with proper formatting, captions, and figure references.',
    technicalDetails: 'Inserts 12 images at placeholder locations, adds descriptive captions, creates figure references in text, adjusts text flow around images.',
    whyItMatters: 'Professional formatting with proper captions and references maintains academic quality standards. Images are integrated seamlessly into the narrative.',
    workers: [
      { type: 'Formatting Engine', count: 3 }
    ],
    duration: 15000,
    estimatedRealTime: '1-2 minutes',
    output: 'Content with 12 embedded images',
    logLines: [
      '> Launching 3 insertion workers...',
      '> Inserting images at placeholder locations...',
      '> Adding captions and references...',
      '> Adjusting text flow around images...',
      '> Launching 3 verifiers...',
      '✓ All 12 images inserted and verified'
    ]
  },
  {
    id: 'step7-format-verify',
    category: 'Section Pipeline',
    pipeline: 'Step 7 of 18',
    title: 'Format Verification',
    description: '5 format verifiers perform comprehensive checks on layout, formatting, image quality, headings, spacing, HTML structure, and WCAG compliance.',
    technicalDetails: 'Each verifier queries 4 AIs to check: headings, spacing, HTML structure, WCAG accessibility, page breaks, citations, index entries, PDF rendering.',
    whyItMatters: 'Ensures every section meets academic and accessibility standards. Catches formatting issues before they compound in the full book.',
    workers: [
      { type: 'GPT-4', count: 5 },
      { type: 'Claude', count: 5 },
      { type: 'Gemini', count: 5 },
      { type: 'Perplexity', count: 5 }
    ],
    duration: 15000,
    estimatedRealTime: '1-2 minutes',
    output: 'Format validation report',
    logLines: [
      '> Launching 5 format verifiers...',
      '> Checking PDF rendering quality...',
      '> Validating HTML structure...',
      '> Verifying WCAG compliance...',
      '> Checking citations and references...',
      '> Validating page layout...',
      '✓ Format verification: PASS'
    ]
  },
  {
    id: 'step8-fix-issues',
    category: 'Section Pipeline',
    pipeline: 'Step 8 of 18',
    title: 'Fix Issues (If Needed)',
    description: 'If Step 7 found issues: 3 fix workers launch, query 4 AIs for solutions, apply corrections, then loop back to Step 7 for re-verification.',
    technicalDetails: 'Automated fix loop continues until all issues resolved. Each iteration: 3 workers × 4 AIs = 12 fix proposals, best one applied.',
    whyItMatters: 'Self-healing system ensures no broken content reaches the final book. Fully automated with no human intervention required.',
    workers: [
      { type: 'GPT-4', count: 3 },
      { type: 'Claude', count: 3 },
      { type: 'Gemini', count: 3 },
      { type: 'Perplexity', count: 3 }
    ],
    duration: 15000,
    estimatedRealTime: '0-4 minutes (only if issues found)',
    output: 'All issues resolved',
    logLines: [
      '> No issues detected in Step 7',
      '> Skipping fix phase',
      '✓ Section ready for final approval'
    ],
    microTasks: [
      { name: 'Worker 1: Fix citation format', status: 'pending', detail: 'Querying 4 AIs...' },
      { name: 'Worker 2: Fix HTML accessibility', status: 'pending', detail: 'Querying 4 AIs...' },
      { name: 'Worker 3: Validate fixes', status: 'pending', detail: 'Querying 4 AIs...' }
    ]
  },
  {
    id: 'step9-section-approval',
    category: 'Section Pipeline',
    pipeline: 'Step 9 of 18',
    title: 'Final Section Approval',
    description: '5 final verifiers perform comprehensive quality check. Each queries 4 AIs for consensus. Section must score 95+ to pass.',
    technicalDetails: 'Final consensus check across all 4 AIs. Verifies: content quality, research accuracy, format correctness, accessibility compliance, overall completeness.',
    whyItMatters: 'Last quality gate before section is marked complete. Only publication-ready content passes. This happens for all 84 sections in parallel.',
    workers: [
      { type: 'GPT-4', count: 5 },
      { type: 'Claude', count: 5 },
      { type: 'Gemini', count: 5 },
      { type: 'Perplexity', count: 5 }
    ],
    duration: 15000,
    estimatedRealTime: '1-2 minutes',
    output: 'Section marked COMPLETE',
    logLines: [
      '> Launching 5 final verifiers...',
      '> Final consensus check across 4 AIs...',
      '> Overall quality scores: 96, 97, 95, 98, 96',
      '> Section completeness: VERIFIED',
      '✓ Section marked COMPLETE',
      '> NOTE: This runs for all 84 sections in parallel!'
    ]
  },

  // CHAPTER PIPELINE (Steps 10-11) - Runs 12 times in parallel
  {
    id: 'step10-chapter-review',
    category: 'Chapter Pipeline',
    pipeline: 'Step 10 of 18',
    title: 'Chapter Review',
    description: 'Once all 7 sections in a chapter complete: 5 chapter reviewers check flow, coherence, and transitions between sections.',
    technicalDetails: '5 reviewers × 4 AIs × 12 chapters = 240 AI instances running in parallel. Each reviews flow between 7 sections in one chapter.',
    whyItMatters: 'Ensures chapters read as unified works, not separate sections. Verifies smooth transitions and consistent narrative throughout.',
    workers: [
      { type: 'GPT-4', count: 5 },
      { type: 'Claude', count: 5 },
      { type: 'Gemini', count: 5 },
      { type: 'Perplexity', count: 5 }
    ],
    duration: 15000,
    estimatedRealTime: '5-8 minutes',
    output: '12 chapter reviews completed',
    logLines: [
      '> All 7 sections in chapter complete',
      '> Launching 5 chapter reviewers...',
      '> Reviewing flow between sections...',
      '> Checking coherence and consistency...',
      '> Verifying transitions...',
      '> Synthesis complete for chapter',
      '> Launching 5 verifiers...',
      '> Chapter quality score: 95/100',
      '✓ Chapter review: PASS',
      '> Runs for all 12 chapters in parallel'
    ]
  },
  {
    id: 'step11-chapter-finalize',
    category: 'Chapter Pipeline',
    pipeline: 'Step 11 of 18',
    title: 'Chapter Finalized',
    description: 'All 12 chapters marked complete. Chapter metadata generated, index entries created.',
    technicalDetails: 'Generates metadata for each chapter: title, summary, key concepts, learning objectives, index entries. Creates chapter-level navigation.',
    whyItMatters: 'Completes chapter-level organization. Metadata enables search, discovery, and recommendation features.',
    workers: [
      { type: 'Metadata Engine', count: 12 }
    ],
    duration: 15000,
    estimatedRealTime: '1-2 minutes',
    output: 'All 12 chapters finalized',
    logLines: [
      '> All 12 chapters complete',
      '> Generating chapter metadata...',
      '> Creating index entries...',
      '> Building chapter navigation...',
      '✓ All chapters finalized and ready for book assembly'
    ]
  },

  // BOOK PIPELINE (Steps 12-18)
  {
    id: 'step12-book-review',
    category: 'Book Pipeline',
    pipeline: 'Step 12 of 18',
    title: 'Full Book Review',
    description: '5 book reviewers check overall coherence across all 12 chapters. Verify table of contents, index, and bibliography completeness.',
    technicalDetails: '5 reviewers × 4 AIs = 20 instances reviewing entire 84-section book. Checks: flow between chapters, consistent terminology, complete cross-references.',
    whyItMatters: 'Final quality check ensures book reads as cohesive whole. Catches inconsistencies that span multiple chapters.',
    workers: [
      { type: 'GPT-4', count: 5 },
      { type: 'Claude', count: 5 },
      { type: 'Gemini', count: 5 },
      { type: 'Perplexity', count: 5 }
    ],
    duration: 15000,
    estimatedRealTime: '8-12 minutes',
    output: 'Book-level quality report',
    logLines: [
      '> Launching 5 book reviewers...',
      '> Reviewing all 12 chapters...',
      '> Checking overall coherence...',
      '> Verifying table of contents...',
      '> Checking index completeness...',
      '> Verifying bibliography...',
      '> Synthesis of review results...',
      '> Book quality score: 96/100',
      '✓ Full book review: PASS'
    ]
  },
  {
    id: 'step13-certification',
    category: 'Book Pipeline',
    pipeline: 'Step 13 of 18',
    title: 'Final Certification',
    description: '5 certifiers perform final QA on all aspects: academic standards, citations, accessibility, reading level verification.',
    technicalDetails: 'Comprehensive certification: academic rigor, citation accuracy, WCAG AAA compliance, reading level consistency, completeness verification.',
    whyItMatters: 'Certification ensures book meets all academic, accessibility, and quality standards. Production-ready guarantee.',
    workers: [
      { type: 'GPT-4', count: 5 },
      { type: 'Claude', count: 5 },
      { type: 'Gemini', count: 5 },
      { type: 'Perplexity', count: 5 }
    ],
    duration: 15000,
    estimatedRealTime: '3-5 minutes',
    output: 'Certification granted',
    logLines: [
      '> Launching 5 certifiers...',
      '> Academic standards: PASS',
      '> Citation accuracy: PASS',
      '> WCAG compliance: AAA',
      '> Reading level: Verified',
      '> Completeness: 100%',
      '✓ Certification granted - Book production-ready'
    ]
  },
  {
    id: 'step14-upload',
    category: 'Book Pipeline',
    pipeline: 'Step 14 of 18',
    title: 'Upload to Storage',
    description: '3 uploaders run in parallel: Primary storage (Supabase), backup storage, and long-term archive. All versions uploaded with checksum verification.',
    technicalDetails: 'Uploads PDF, EPUB, HTML versions to 3 locations simultaneously. Generates checksums for integrity verification. Creates public URLs.',
    whyItMatters: 'Triple redundancy ensures data safety. Checksum verification catches any corruption. Public URLs enable instant access.',
    workers: [
      { type: 'Uploader', count: 3 }
    ],
    duration: 15000,
    estimatedRealTime: '2-5 minutes',
    output: 'All versions uploaded to 3 locations',
    logLines: [
      '> Launching 3 uploaders...',
      '> Uploader 1: Supabase storage (PDF, EPUB, HTML)',
      '> Uploader 2: Backup storage',
      '> Uploader 3: Archive storage',
      '> Generating checksums...',
      '> Creating public URLs...',
      '✓ All uploads complete and verified'
    ]
  },
  {
    id: 'step15-deploy',
    category: 'Book Pipeline',
    pipeline: 'Step 15 of 18',
    title: 'Deploy to Web / CDN',
    description: 'Deploy to production website and CDN. Generate preview thumbnails. Distribute to global edge caching locations.',
    technicalDetails: 'Pushes to production website, distributes to CDN edge servers worldwide. Generates preview images and thumbnails for browsing.',
    whyItMatters: 'Global CDN ensures fast access from anywhere. Edge caching provides sub-second load times. Preview images enable browsing.',
    workers: [
      { type: 'Deployment Engine', count: 1 }
    ],
    duration: 15000,
    estimatedRealTime: '2-3 minutes',
    output: 'Book live on CDN globally',
    logLines: [
      '> Deploying to production website...',
      '> Distributing to CDN edge servers...',
      '> Generating preview thumbnails...',
      '> Verifying deployment across regions...',
      '> Checking CDN cache population...',
      '✓ Book deployed and accessible globally'
    ]
  },
  {
    id: 'step16-verify-uploads',
    category: 'Book Pipeline',
    pipeline: 'Step 16 of 18',
    title: 'Verify Uploads',
    description: '5 verifiers download each version, check integrity with checksums, verify all URLs are live and accessible.',
    technicalDetails: 'Downloads from all 3 storage locations, verifies checksums match originals, tests all public URLs for accessibility.',
    whyItMatters: 'Final verification ensures uploads succeeded and files are accessible. Catches any corruption or access issues.',
    workers: [
      { type: 'Verifier', count: 5 }
    ],
    duration: 15000,
    estimatedRealTime: '1-2 minutes',
    output: 'All uploads verified',
    logLines: [
      '> Launching 5 verifiers...',
      '> Downloading from all storage locations...',
      '> Verifying checksums...',
      '> Testing all URLs...',
      '> Checking accessibility...',
      '✓ All uploads verified - Files accessible'
    ]
  },
  {
    id: 'step17-metadata',
    category: 'Book Pipeline',
    pipeline: 'Step 17 of 18',
    title: 'Metadata & Catalog',
    description: 'Generate comprehensive metadata, add to search index, create catalog entry, generate recommendation links.',
    technicalDetails: 'Creates metadata: title, author, subject, topics, reading level, keywords, categories. Indexes in search engine. Links to related books.',
    whyItMatters: 'Metadata enables discovery through search and recommendations. Catalog integration makes book findable by students and educators.',
    workers: [
      { type: 'Metadata Engine', count: 1 }
    ],
    duration: 15000,
    estimatedRealTime: '1-2 minutes',
    output: 'Book in catalog and searchable',
    logLines: [
      '> Generating comprehensive metadata...',
      '> Adding to search index...',
      '> Creating catalog entry...',
      '> Updating subject area catalog...',
      '> Generating recommendation links...',
      '✓ Book cataloged and searchable'
    ]
  },
  {
    id: 'step18-complete',
    category: 'Book Pipeline',
    pipeline: 'Step 18 of 18',
    title: 'Mark Complete',
    description: 'Final confirmation: Book status set to LIVE. Write completion logs, update analytics, send webhooks, trigger downstream pipelines.',
    technicalDetails: 'Updates database status, logs completion event, updates analytics dashboard, sends webhooks to downstream systems for adaptations/translations.',
    whyItMatters: 'Signals completion to entire system. Triggers Pipeline 2-11 to begin creating adaptations, translations, and educational add-ons.',
    workers: [
      { type: 'Completion Engine', count: 1 }
    ],
    duration: 15000,
    estimatedRealTime: '1 minute',
    output: 'Book LIVE - Pipeline complete',
    logLines: [
      '> Setting book status: LIVE',
      '> Writing completion logs...',
      '> Updating analytics dashboard...',
      '> Sending completion webhooks...',
      '> Triggering downstream pipelines...',
      '> Pipeline 2: Reading level adaptations',
      '> Pipeline 3: Disability adaptations',
      '> Pipeline 4: Format conversions',
      '> Pipelines 5-11: Educational add-ons',
      '✓ BOOK GENERATION COMPLETE',
      '✓ Total time: 75-90 minutes',
      '✓ 84 sections → 12 chapters → 1 complete book',
      '✓ Ready for 1.7M+ derivative products'
    ]
  }
];

export const completeBookDemo: PipelineDemo = {
  id: 'complete-book-pipeline',
  name: 'Complete Book Generation Pipeline',
  description: 'All 18 steps from research to publication. See the full process: 84 sections → 12 chapters → 1 complete book in 75-90 minutes.',
  totalDuration: 144000, // 18 steps × 8 seconds each
  steps: completeBookSteps
};
