import { AddonType } from '../lib/database.types';

export interface WorkflowWorker {
  role: string;
  description: string;
}

export interface WorkflowStep {
  id: string;
  name: string;
  description: string;
  explanation: string;
  workers: WorkflowWorker[];
  verificationWorkers?: WorkflowWorker[];
  estimatedTime: number;
  outputFiles?: string[];
  iterativeQuality?: boolean; // If true, this step includes 2-3 quality passes with auto-fix
  maxIterations?: number; // Max times this step will re-run for quality (default: 20)
  canRunParallel?: boolean; // If true, can run in parallel with other parallel steps
}

export interface AddonWorkflow {
  addonType: AddonType;
  name: string;
  icon: string;
  overview: string;
  steps: WorkflowStep[];
}

export const ADDON_WORKFLOWS: Record<AddonType, AddonWorkflow> = {
  activity_pack: {
    addonType: 'activity_pack',
    name: 'Activity Pack',
    icon: '🎯',
    overview: 'Generates comprehensive hands-on activities with learning objectives, standards alignment, differentiation, assessments, and educator resources',
    steps: [
      {
        id: 'load_master_book',
        name: 'Load Master Book Content',
        description: 'Loading generated master book into context',
        explanation: 'System loads the complete master book content into AI context for analysis. This ensures all subsequent steps have access to the full book content.',
        workers: [
          { role: 'Content Loader', description: 'Loads master book from storage' },
          { role: 'Context Manager', description: 'Prepares content for AI processing' }
        ],
        estimatedTime: 2,
        outputFiles: ['master_book_loaded.json'],
        canRunParallel: false
      },
      {
        id: 'analyze_chapters',
        name: 'Multi-AI Chapter Analysis',
        description: 'Analyzing chapters using 3 AI models for comprehensive insights',
        explanation: 'Three different AI models independently analyze each chapter to identify key concepts and learning opportunities. A synthesis team combines findings to create the most comprehensive analysis possible.',
        workers: [
          { role: 'GPT-4 Content Analyzer', description: 'Analyzes chapters using GPT-4' },
          { role: 'Claude Content Analyzer', description: 'Analyzes chapters using Claude' },
          { role: 'Gemini Content Analyzer', description: 'Analyzes chapters using Gemini' },
          { role: 'Analysis Synthesizer', description: 'Combines insights from all 3 AI models' },
          { role: 'Consensus Validator', description: 'Identifies agreements and conflicts between models' },
          { role: 'Learning Objective Mapper', description: 'Creates comprehensive educational goals' },
          { role: 'Cross-Reference Builder', description: 'Maps activities to book chapters and concepts' },
          { role: 'Auto-Fix Agent', description: 'Identifies gaps and adds missing analysis' }
        ],
        verificationWorkers: [
          { role: 'Coverage Verifier', description: 'Ensures all chapters are analyzed' },
          { role: 'Gap Detector', description: 'Finds missing opportunities' },
          { role: 'Cross-Reference Validator', description: 'Verifies chapter-activity links' },
          { role: 'Quality Validator', description: 'Confirms analysis quality' },
          { role: 'Multi-Model Validator', description: 'Confirms synthesis captured all insights' }
        ],
        estimatedTime: 18,
        outputFiles: ['chapter_analysis.json', 'activity_opportunities.json', 'cross_references.json', 'verification_log.json', 'ai_consensus_report.json'],
        iterativeQuality: true,
        maxIterations: 15
      },
      {
        id: 'align_standards',
        name: 'Multi-AI Standards Alignment',
        description: 'Mapping to standards using multiple AI research agents',
        explanation: 'Three AI models independently research educational standards to ensure no relevant standards are missed. A synthesis team combines findings to create the most comprehensive standards alignment possible.',
        workers: [
          { role: 'GPT-4 Standards Researcher', description: 'Researches standards using GPT-4' },
          { role: 'Claude Standards Researcher', description: 'Researches standards using Claude' },
          { role: 'Gemini Standards Researcher', description: 'Researches standards using Gemini' },
          { role: 'Standards Synthesizer', description: 'Combines findings from all 3 AI models' },
          { role: 'Conflict Resolver', description: 'Resolves discrepancies between models' },
          { role: 'Alignment Mapper', description: 'Maps activities to specific standards' },
          { role: 'Documentation Specialist', description: 'Formats standards documentation' }
        ],
        verificationWorkers: [
          { role: 'Standards Validator', description: 'Validates standard references are correct' },
          { role: 'Coverage Check', description: 'Ensures comprehensive standard coverage' },
          { role: 'Consensus Validator', description: 'Confirms all AI findings were considered' }
        ],
        estimatedTime: 14,
        outputFiles: ['standards_alignment.json', 'standards_documentation.json', 'standards_consensus.json'],
        iterativeQuality: true,
        maxIterations: 12
      },
      {
        id: 'design_activities',
        name: 'Design Activity Concepts',
        description: 'Creating age-appropriate activity concepts with learning objectives',
        explanation: 'Workers design specific activities that align with learning objectives and standards. Each activity includes clear learning objectives, is engaging, educational, age-appropriate, and safe. Iterative quality checks refine concepts until they meet all criteria.',
        workers: [
          { role: 'Activity Designer', description: 'Creates activity concepts and structures' },
          { role: 'Learning Objective Writer', description: 'Writes clear, measurable learning objectives' },
          { role: 'Age Appropriateness Specialist', description: 'Ensures activities match reading level' },
          { role: 'Safety Consultant', description: 'Reviews activities for safety concerns' },
          { role: 'Refinement Agent', description: 'Improves activities based on feedback' }
        ],
        verificationWorkers: [
          { role: 'Pedagogical Reviewer', description: 'Validates educational value' },
          { role: 'Objective Quality Check', description: 'Ensures objectives are measurable' },
          { role: 'Safety Validator', description: 'Confirms all activities are safe' },
          { role: 'Engagement Checker', description: 'Ensures activities are engaging' }
        ],
        estimatedTime: 16,
        outputFiles: ['activity_concepts.json', 'learning_objectives.json', 'refinement_log.json'],
        iterativeQuality: true,
        maxIterations: 20
      },
      {
        id: 'create_differentiation',
        name: 'Create Differentiation Strategies',
        description: 'Designing tiered versions and in-activity variations',
        explanation: 'Workers create multiple difficulty levels for each activity including in-activity modifications and separate tiered versions for diverse learners. This ensures all students can access the content at their level.',
        workers: [
          { role: 'Differentiation Specialist', description: 'Creates tiered activity versions' },
          { role: 'Modification Designer', description: 'Adds in-activity variations' },
          { role: 'Support Strategist', description: 'Creates scaffolding for struggling learners' },
          { role: 'Extension Designer', description: 'Creates challenges for advanced learners' }
        ],
        verificationWorkers: [
          { role: 'Accessibility Validator', description: 'Ensures all levels are accessible' },
          { role: 'Differentiation Quality', description: 'Validates appropriate difficulty range' }
        ],
        estimatedTime: 12,
        outputFiles: ['differentiated_activities.json', 'tiered_versions.json', 'modifications.json'],
        iterativeQuality: true,
        maxIterations: 12
      },
      {
        id: 'write_instructions',
        name: 'Write Detailed Instructions',
        description: 'Creating complete step-by-step instructions with time estimates and troubleshooting',
        explanation: 'Workers write clear, detailed instructions including materials needed, preparation steps, execution steps, time estimates, expected outcomes, and troubleshooting tips for common issues. Multiple review cycles ensure instructions are crystal clear.',
        workers: [
          { role: 'Technical Writer', description: 'Writes clear step-by-step instructions' },
          { role: 'Materials Specialist', description: 'Creates detailed materials lists' },
          { role: 'Time Estimation Expert', description: 'Estimates activity duration' },
          { role: 'Troubleshooting Writer', description: 'Documents common mistakes and fixes' },
          { role: 'Clarity Enhancer', description: 'Simplifies complex instructions' }
        ],
        verificationWorkers: [
          { role: 'Clarity Checker', description: 'Ensures instructions are understandable' },
          { role: 'Completeness Validator', description: 'Confirms all steps are included' },
          { role: 'Time Accuracy Check', description: 'Validates time estimates are realistic' },
          { role: 'Ambiguity Detector', description: 'Finds and fixes unclear language' }
        ],
        estimatedTime: 18,
        outputFiles: ['activity_instructions.json', 'time_estimates.json', 'troubleshooting_guide.json', 'clarity_report.json'],
        iterativeQuality: true,
        maxIterations: 12
      },
      {
        id: 'create_safety_guidelines',
        name: 'Create Safety Guidelines',
        description: 'Documenting safety protocols and precautions',
        explanation: 'Workers create comprehensive safety guidelines for activities that require them, including materials safety, supervision requirements, and emergency procedures.',
        workers: [
          { role: 'Safety Expert', description: 'Writes safety protocols and warnings' },
          { role: 'Risk Assessment Agent', description: 'Identifies potential hazards' },
          { role: 'Age Safety Specialist', description: 'Ensures age-appropriate safety measures' }
        ],
        verificationWorkers: [
          { role: 'Safety Compliance Check', description: 'Validates all safety protocols' }
        ],
        estimatedTime: 8,
        outputFiles: ['safety_guidelines.json', 'risk_assessment.json'],
        iterativeQuality: true,
        maxIterations: 10
      },
      {
        id: 'create_assessments',
        name: 'Create Assessment Rubrics',
        description: 'Designing assessment rubrics and success criteria',
        explanation: 'Workers create detailed assessment rubrics and success criteria that help educators evaluate student learning during activities. Multiple types of assessment are included.',
        workers: [
          { role: 'Rubric Designer', description: 'Creates scoring rubrics' },
          { role: 'Success Criteria Writer', description: 'Defines clear success indicators' },
          { role: 'Assessment Strategist', description: 'Designs formative and summative assessments' }
        ],
        verificationWorkers: [
          { role: 'Rubric Quality Check', description: 'Validates rubric clarity and fairness' },
          { role: 'Criteria Validator', description: 'Ensures criteria are measurable' }
        ],
        estimatedTime: 10,
        outputFiles: ['assessment_rubrics.json', 'success_criteria.json', 'assessment_methods.json'],
        iterativeQuality: true,
        maxIterations: 12
      },
      {
        id: 'accessibility_review',
        name: 'Accessibility Review',
        description: 'Reviewing and enhancing accessibility for all learners',
        explanation: 'Workers review all activities for accessibility and add practical modifications for diverse learners including sensory, motor, cognitive, and language considerations.',
        workers: [
          { role: 'Accessibility Specialist', description: 'Reviews activities for accessibility' },
          { role: 'Accommodation Designer', description: 'Creates practical accommodations' },
          { role: 'Universal Design Expert', description: 'Applies universal design principles' }
        ],
        verificationWorkers: [
          { role: 'Accessibility Validator', description: 'Validates accessibility compliance' },
          { role: 'Accommodation Quality', description: 'Ensures accommodations are practical' }
        ],
        estimatedTime: 9,
        outputFiles: ['accessibility_review.json', 'accommodations.json'],
        iterativeQuality: true,
        maxIterations: 10
      },
      {
        id: 'search_images',
        name: 'Search for Activity Images',
        description: 'Finding high-quality images from multiple sources',
        explanation: 'Multiple workers search different image sources (Pexels, Unsplash, stock libraries) for relevant activity images. Each placeholder gets 2-3 candidate images.',
        workers: [
          { role: 'Pexels Search Agent', description: 'Searches Pexels for activity images' },
          { role: 'Unsplash Search Agent', description: 'Searches Unsplash for activity images' },
          { role: 'Stock Library Agent', description: 'Searches stock photo libraries' },
          { role: 'Image Metadata Collector', description: 'Gathers attribution info' }
        ],
        estimatedTime: 10,
        outputFiles: ['image_candidates.json', 'image_metadata.json'],
        canRunParallel: true
      },
      {
        id: 'select_images',
        name: 'Select Best Images',
        description: 'AI selects most appropriate image for each placeholder',
        explanation: 'AI reviews candidate images and selects the best fit for each activity based on relevance, quality, and educational value.',
        workers: [
          { role: 'Image Selection AI', description: 'Chooses best image for each placeholder' },
          { role: 'Quality Assessor', description: 'Ensures image quality standards' }
        ],
        verificationWorkers: [
          { role: 'Relevance Checker', description: 'Confirms images match content' }
        ],
        estimatedTime: 8,
        outputFiles: ['selected_images.json'],
        iterativeQuality: true,
        maxIterations: 8
      },
      {
        id: 'create_visuals',
        name: 'Generate Activity Diagrams',
        description: 'Creating visual aids and diagrams for activities',
        explanation: 'Workers generate custom diagrams, illustrations, and visual guides using image generation AI to help users understand each activity setup and execution.',
        workers: [
          { role: 'DALL-E Image Generator', description: 'Generates custom illustrations' },
          { role: 'Diagram Designer', description: 'Creates instructional diagrams' },
          { role: 'Layout Specialist', description: 'Ensures visual clarity and organization' }
        ],
        verificationWorkers: [
          { role: 'Visual Quality Check', description: 'Ensures diagrams are clear' }
        ],
        estimatedTime: 12,
        outputFiles: ['activity_diagrams/', 'generated_visuals/'],
        iterativeQuality: true,
        maxIterations: 10
      },
      {
        id: 'insert_images',
        name: 'Insert Images into Layout',
        description: 'Placing images without breaking document flow',
        explanation: 'Workers carefully insert selected images into document placeholders, adjusting layout and text flow to maintain professional appearance.',
        workers: [
          { role: 'Layout Engine', description: 'Inserts images into placeholders' },
          { role: 'Flow Adjuster', description: 'Adjusts text flow around images' },
          { role: 'Pagination Manager', description: 'Prevents awkward page breaks' }
        ],
        verificationWorkers: [
          { role: 'Layout Validator', description: 'Ensures clean layout' }
        ],
        estimatedTime: 8,
        outputFiles: ['layout_with_images.json']
      },
      {
        id: 'create_attribution',
        name: 'Create Image Attribution Glossary',
        description: 'Compiling image credits for glossary',
        explanation: 'Workers create a comprehensive glossary listing all image sources, photographers, and required attributions.',
        workers: [
          { role: 'Attribution Compiler', description: 'Creates attribution list' },
          { role: 'Legal Compliance', description: 'Ensures proper attribution format' }
        ],
        estimatedTime: 4,
        outputFiles: ['image_attributions.json', 'glossary_section.json']
      },
      {
        id: 'create_materials_guide',
        name: 'Multi-AI Materials Sourcing Research',
        description: 'Researching materials using multiple AI search agents',
        explanation: 'Three AI models independently research vendors, pricing, and alternatives to find the most comprehensive sourcing options. Results are synthesized to provide educators with maximum choices.',
        workers: [
          { role: 'GPT-4 Sourcing Researcher', description: 'Researches vendors using GPT-4' },
          { role: 'Claude Sourcing Researcher', description: 'Researches vendors using Claude' },
          { role: 'Gemini Sourcing Researcher', description: 'Researches vendors using Gemini' },
          { role: 'Sourcing Synthesizer', description: 'Combines all vendor findings' },
          { role: 'Price Comparison Agent', description: 'Compares pricing across all findings' },
          { role: 'Alternative Finder', description: 'Suggests budget alternatives' },
          { role: 'Substitution Specialist', description: 'Identifies material substitutions' }
        ],
        verificationWorkers: [
          { role: 'Resource Validator', description: 'Validates vendor recommendations' },
          { role: 'Pricing Accuracy Check', description: 'Verifies pricing information' }
        ],
        estimatedTime: 12,
        outputFiles: ['materials_sourcing_guide.json', 'vendor_consensus.json'],
        iterativeQuality: true,
        maxIterations: 10
      },
      {
        id: 'create_parent_templates',
        name: 'Create Parent Communication Templates',
        description: 'Designing letters and home activity suggestions',
        explanation: 'Workers create template letters for parents explaining what students are learning, plus "try at home" activity suggestions to reinforce learning.',
        workers: [
          { role: 'Communication Writer', description: 'Writes parent letter templates' },
          { role: 'Home Activity Designer', description: 'Creates at-home extension activities' },
          { role: 'Family Engagement Specialist', description: 'Designs family involvement strategies' }
        ],
        verificationWorkers: [
          { role: 'Clarity Checker', description: 'Ensures parent-friendly language' }
        ],
        estimatedTime: 8,
        outputFiles: ['parent_templates.json', 'home_activities.json'],
        iterativeQuality: true,
        maxIterations: 10
      },
      {
        id: 'pilot_simulation',
        name: 'Pilot Testing Simulation',
        description: 'Simulating activity implementation and gathering feedback',
        explanation: 'Workers simulate running each activity to identify potential issues, unclear instructions, and areas for improvement. Multiple rounds refine activities based on simulated feedback.',
        workers: [
          { role: 'Implementation Simulator', description: 'Simulates running activities' },
          { role: 'Issue Identifier', description: 'Identifies potential problems' },
          { role: 'Feedback Generator', description: 'Generates simulated educator feedback' },
          { role: 'Refinement Agent', description: 'Applies improvements based on feedback' }
        ],
        verificationWorkers: [
          { role: 'Readiness Validator', description: 'Confirms activities are classroom-ready' }
        ],
        estimatedTime: 12,
        outputFiles: ['pilot_simulation.json', 'refinement_log.json'],
        iterativeQuality: true,
        maxIterations: 15
      },
      {
        id: 'auto_save_progress',
        name: 'Auto-Save Progress',
        description: 'Saving work in progress to prevent data loss',
        explanation: 'System continuously saves all work to database and cloud storage, ensuring no progress is lost.',
        workers: [
          { role: 'Auto-Save Manager', description: 'Saves progress every 30 seconds' },
          { role: 'Database Writer', description: 'Writes to Supabase database' }
        ],
        estimatedTime: 2,
        outputFiles: ['progress_checkpoint.json'],
        canRunParallel: true
      },
      {
        id: 'compile_educator_packet',
        name: 'Compile Educator Resource Packet',
        description: 'Assembling materials guide and parent templates',
        explanation: 'Workers compile the materials sourcing guide and parent communication templates into a separate educator resource document.',
        workers: [
          { role: 'Document Compiler', description: 'Assembles educator resources' },
          { role: 'PDF Generator', description: 'Creates PDF document' }
        ],
        verificationWorkers: [
          { role: 'Completeness Check', description: 'Verifies all resources included' }
        ],
        estimatedTime: 5,
        outputFiles: ['educator_resource_packet.pdf']
      },
      {
        id: 'compile_pack',
        name: 'Compile Activity Pack',
        description: 'Assembling all activities into a cohesive document',
        explanation: 'Workers compile all activities with learning objectives, instructions, differentiation, assessments, safety guidelines, troubleshooting, cross-references, standards alignment, visuals, and attribution glossary into a professionally formatted PDF document.',
        workers: [
          { role: 'Document Compiler', description: 'Assembles all components into final format' },
          { role: 'Standards Integrator', description: 'Adds standards alignment documentation' },
          { role: 'Cross-Reference Integrator', description: 'Adds chapter cross-references' },
          { role: 'Glossary Integrator', description: 'Adds image attribution glossary' },
          { role: 'PDF Generator', description: 'Converts to PDF with proper formatting' }
        ],
        verificationWorkers: [
          { role: 'Completeness Check', description: 'Verifies all components included' }
        ],
        estimatedTime: 9,
        outputFiles: ['activity_pack.pdf', 'activity_pack_metadata.json']
      },
      {
        id: 'quality_check',
        name: 'Multi-Pass Quality Check',
        description: 'Comprehensive review with multiple verification passes',
        explanation: 'Multiple verification workers review the entire pack 2-3 times for completeness, accuracy, clarity, quality, safety, accessibility, and standards alignment. Auto-fix agents correct any issues found and process repeats until quality threshold is met.',
        workers: [
          { role: 'Auto-Fix Agent', description: 'Automatically corrects detected issues' },
          { role: 'Issue Logger', description: 'Documents all fixes made' }
        ],
        verificationWorkers: [
          { role: 'Completeness Checker', description: 'Verifies all activities and features included' },
          { role: 'Standards Validator', description: 'Validates standards alignment accuracy' },
          { role: 'Differentiation Check', description: 'Ensures all differentiation is present' },
          { role: 'Assessment Validator', description: 'Validates rubrics and success criteria' },
          { role: 'Accuracy Reviewer', description: 'Checks for errors and inconsistencies' },
          { role: 'Quality Assurance', description: 'Overall quality and polish review' },
          { role: 'Safety Validator', description: 'Final safety review' },
          { role: 'Accessibility Check', description: 'Validates accessibility features' },
          { role: 'Cross-Reference Check', description: 'Validates chapter links' },
          { role: 'Attribution Checker', description: 'Verifies all image credits included' }
        ],
        estimatedTime: 16,
        outputFiles: ['quality_report.json', 'fixes_applied.json'],
        iterativeQuality: true,
        maxIterations: 20
      },
      {
        id: 'create_backups',
        name: 'Create Multi-Location Backups',
        description: 'Backing up to 5+ secure locations for maximum safety',
        explanation: 'System creates multiple redundant backups across different storage providers and geographic locations. Each backup is verified for integrity to ensure no data loss.',
        workers: [
          { role: 'Supabase Storage Agent', description: 'Backs up to Supabase primary storage bucket' },
          { role: 'AWS S3 Backup Agent', description: 'Backs up to Amazon S3 bucket (US-East)' },
          { role: 'Google Cloud Storage Agent', description: 'Backs up to GCS bucket (US-Central)' },
          { role: 'Azure Blob Agent', description: 'Backs up to Azure Blob Storage (Europe)' },
          { role: 'Cloudflare R2 Agent', description: 'Backs up to Cloudflare R2 (Global CDN)' },
          { role: 'Local Archive Manager', description: 'Creates local database archive copy' },
          { role: 'Backup Integrity Verifier', description: 'Verifies checksums for all backups' }
        ],
        verificationWorkers: [
          { role: 'Backup Completeness Check', description: 'Ensures all locations have complete files' },
          { role: 'Integrity Validator', description: 'Validates file integrity across all backups' }
        ],
        estimatedTime: 6,
        outputFiles: ['backup_manifest.json', 'integrity_checksums.json', 'backup_locations.json'],
        iterativeQuality: true,
        maxIterations: 8
      },
      {
        id: 'create_archives',
        name: 'Create Long-Term Archives',
        description: 'Creating immutable long-term archives with version history',
        explanation: 'System creates permanent archival copies with version history, metadata tags, and retrieval documentation for future access.',
        workers: [
          { role: 'Version Archive Manager', description: 'Creates versioned archive with timestamp' },
          { role: 'Metadata Tagger', description: 'Tags archive with searchable metadata' },
          { role: 'Glacier Archive Agent', description: 'Stores in AWS Glacier for long-term cold storage' },
          { role: 'Archive Index Builder', description: 'Creates searchable archive index' },
          { role: 'Retrieval Documentation', description: 'Documents how to retrieve archive' }
        ],
        verificationWorkers: [
          { role: 'Archive Accessibility Test', description: 'Verifies archive can be retrieved' }
        ],
        estimatedTime: 5,
        outputFiles: ['archive_manifest.json', 'archive_index.json', 'retrieval_guide.json'],
        canRunParallel: true
      },
      {
        id: 'publish_upload',
        name: 'Upload to Distribution',
        description: 'Publishing finished product to delivery platform',
        explanation: 'System uploads the completed activity pack to the distribution platform where users can access it.',
        workers: [
          { role: 'Upload Manager', description: 'Uploads to distribution platform' },
          { role: 'CDN Distributor', description: 'Distributes to CDN for fast access' },
          { role: 'Metadata Publisher', description: 'Publishes product metadata' }
        ],
        verificationWorkers: [
          { role: 'Upload Verifier', description: 'Confirms successful upload' },
          { role: 'Accessibility Tester', description: 'Verifies file is accessible' }
        ],
        estimatedTime: 5,
        outputFiles: ['distribution_manifest.json', 'cdn_urls.json']
      }
    ]
  },

  worksheet_set: {
    addonType: 'worksheet_set',
    name: 'Worksheet Set',
    icon: '📝',
    overview: 'Generates comprehensive practice worksheet sets with multi-AI content analysis, rigorous answer validation, and professional print-ready layouts',
    steps: [
      {
        id: 'load_master_book',
        name: 'Load Master Book Content',
        description: 'Loading generated master book into context',
        explanation: 'System loads the complete master book content into AI context for analysis.',
        workers: [
          { role: 'Content Loader', description: 'Loads master book from storage' },
          { role: 'Context Manager', description: 'Prepares content for AI processing' }
        ],
        estimatedTime: 2,
        outputFiles: ['master_book_loaded.json'],
        canRunParallel: false
      },
      {
        id: 'analyze_content',
        name: 'Multi-AI Content Analysis',
        description: 'Analyzing content using 3 AI models for complete concept coverage',
        explanation: 'Three AI models independently analyze each chapter to identify concepts needing practice reinforcement. Synthesis ensures no concept is missed.',
        workers: [
          { role: 'GPT-4 Content Analyzer', description: 'Identifies concepts using GPT-4' },
          { role: 'Claude Content Analyzer', description: 'Identifies concepts using Claude' },
          { role: 'Gemini Content Analyzer', description: 'Identifies concepts using Gemini' },
          { role: 'Concept Synthesizer', description: 'Combines findings from all 3 models' },
          { role: 'Skill Mapper', description: 'Maps concepts to practice skills' },
          { role: 'Practice Opportunity Finder', description: 'Identifies all practice opportunities' },
          { role: 'Gap Finder', description: 'Identifies missed practice opportunities' }
        ],
        verificationWorkers: [
          { role: 'Coverage Verifier', description: 'Ensures comprehensive coverage' },
          { role: 'Quality Validator', description: 'Confirms analysis quality' },
          { role: 'Consensus Validator', description: 'Confirms all AI insights captured' }
        ],
        estimatedTime: 14,
        outputFiles: ['content_analysis.json', 'verification_log.json', 'concept_consensus.json'],
        iterativeQuality: true,
        maxIterations: 12
      },
      {
        id: 'design_exercises',
        name: 'Design Exercise Types',
        description: 'Planning variety of exercise formats for each chapter',
        explanation: 'Workers determine the mix of exercise types (fill-in-blank, matching, short answer, etc.) appropriate for each chapter. Iterative refinement ensures optimal variety and difficulty.',
        workers: [
          { role: 'Exercise Designer', description: 'Plans exercise types and formats' },
          { role: 'Difficulty Calibrator', description: 'Ensures appropriate difficulty progression' },
          { role: 'Variety Optimizer', description: 'Ensures diverse exercise types' }
        ],
        verificationWorkers: [
          { role: 'Balance Checker', description: 'Validates exercise type distribution' }
        ],
        estimatedTime: 10,
        outputFiles: ['exercise_plan.json'],
        iterativeQuality: true,
        maxIterations: 10
      },
      {
        id: 'generate_questions',
        name: 'Multi-AI Question Generation & Validation',
        description: 'Creating questions using 3 AI models with triple answer validation',
        explanation: 'Three AI models independently generate questions and answers. Each answer is validated by all 3 models to ensure 100% accuracy. Any discrepancies trigger expert review.',
        workers: [
          { role: 'GPT-4 Question Generator', description: 'Generates questions using GPT-4' },
          { role: 'Claude Question Generator', description: 'Generates questions using Claude' },
          { role: 'Gemini Question Generator', description: 'Generates questions using Gemini' },
          { role: 'Question Synthesizer', description: 'Combines best questions from all models' },
          { role: 'GPT-4 Answer Validator', description: 'Validates all answers using GPT-4' },
          { role: 'Claude Answer Validator', description: 'Validates all answers using Claude' },
          { role: 'Gemini Answer Validator', description: 'Validates all answers using Gemini' },
          { role: 'Consensus Answer Key Builder', description: 'Creates answer key from consensus' },
          { role: 'Distractor Designer', description: 'Creates plausible wrong answers for multiple choice' },
          { role: 'Clarity Enhancer', description: 'Improves question wording' },
          { role: 'Discrepancy Resolver', description: 'Resolves answer conflicts between models' }
        ],
        verificationWorkers: [
          { role: 'Triple Accuracy Check', description: 'Verifies all 3 AIs agree on answers' },
          { role: 'Mathematical Proof Validator', description: 'Validates mathematical solutions' },
          { role: 'Conceptual Correctness', description: 'Ensures conceptually sound questions' },
          { role: 'Answer Key Triple-Check', description: 'Final answer key validation' },
          { role: 'Question Quality', description: 'Ensures questions are fair and clear' },
          { role: 'Ambiguity Detector', description: 'Finds and fixes ambiguous questions' }
        ],
        estimatedTime: 24,
        outputFiles: ['questions.json', 'answer_key.json', 'validation_log.json', 'consensus_report.json'],
        iterativeQuality: true,
        maxIterations: 20
      },
      {
        id: 'search_images',
        name: 'Search for Worksheet Images',
        description: 'Finding relevant images from multiple sources',
        explanation: 'Multiple workers search different image sources for educational images to enhance worksheets.',
        workers: [
          { role: 'Pexels Search Agent', description: 'Searches Pexels for educational images' },
          { role: 'Unsplash Search Agent', description: 'Searches Unsplash for worksheet images' },
          { role: 'Stock Library Agent', description: 'Searches stock photo libraries' },
          { role: 'Image Metadata Collector', description: 'Gathers attribution info' }
        ],
        estimatedTime: 8,
        outputFiles: ['image_candidates.json', 'image_metadata.json'],
        canRunParallel: true
      },
      {
        id: 'select_images',
        name: 'Select Best Images',
        description: 'AI selects most appropriate images',
        explanation: 'AI reviews candidate images and selects the best fit for each worksheet section.',
        workers: [
          { role: 'Image Selection AI', description: 'Chooses best images' },
          { role: 'Educational Value Assessor', description: 'Ensures images support learning' }
        ],
        verificationWorkers: [
          { role: 'Relevance Checker', description: 'Confirms image relevance' }
        ],
        estimatedTime: 6,
        outputFiles: ['selected_images.json'],
        iterativeQuality: true,
        maxIterations: 8
      },
      {
        id: 'create_layouts',
        name: 'Design Worksheet Layouts',
        description: 'Creating printable layouts for each worksheet',
        explanation: 'Workers design the visual layout of each worksheet, ensuring proper spacing, readability, and print-friendliness. Images are integrated seamlessly.',
        workers: [
          { role: 'Layout Designer', description: 'Creates worksheet page layouts' },
          { role: 'Typography Specialist', description: 'Ensures readable fonts and spacing' },
          { role: 'Image Integrator', description: 'Inserts images into layouts' },
          { role: 'Print Optimizer', description: 'Ensures printer-friendly design' }
        ],
        verificationWorkers: [
          { role: 'Layout Validator', description: 'Checks layout quality' }
        ],
        estimatedTime: 10,
        outputFiles: ['layouts/'],
        iterativeQuality: true,
        maxIterations: 8
      },
      {
        id: 'create_attribution',
        name: 'Create Image Attribution',
        description: 'Compiling image credits',
        explanation: 'Workers create attribution list for all images used in worksheets.',
        workers: [
          { role: 'Attribution Compiler', description: 'Creates attribution list' },
          { role: 'Legal Compliance', description: 'Ensures proper attribution format' }
        ],
        estimatedTime: 3,
        outputFiles: ['image_attributions.json']
      },
      {
        id: 'organize_difficulty',
        name: 'Organize by Difficulty',
        description: 'Arranging exercises in progressive difficulty order',
        explanation: 'Workers organize exercises within each worksheet so difficulty gradually increases, building confidence.',
        workers: [
          { role: 'Difficulty Organizer', description: 'Orders exercises by difficulty level' },
          { role: 'Flow Optimizer', description: 'Ensures smooth progression' }
        ],
        verificationWorkers: [
          { role: 'Progression Validator', description: 'Confirms appropriate difficulty curve' }
        ],
        estimatedTime: 5,
        outputFiles: ['organized_exercises.json'],
        iterativeQuality: true,
        maxIterations: 8
      },
      {
        id: 'auto_save_progress',
        name: 'Auto-Save Progress',
        description: 'Saving work in progress to prevent data loss',
        explanation: 'System continuously saves all work to database and cloud storage.',
        workers: [
          { role: 'Auto-Save Manager', description: 'Saves progress every 30 seconds' },
          { role: 'Database Writer', description: 'Writes to Supabase database' }
        ],
        estimatedTime: 2,
        outputFiles: ['progress_checkpoint.json'],
        canRunParallel: true
      },
      {
        id: 'compile_set',
        name: 'Compile Worksheet Set',
        description: 'Assembling all worksheets and answer keys',
        explanation: 'Workers compile all worksheets into a complete set with table of contents, answer key section, and image attributions.',
        workers: [
          { role: 'Document Compiler', description: 'Assembles worksheets and answer key' },
          { role: 'TOC Generator', description: 'Creates table of contents' },
          { role: 'Attribution Integrator', description: 'Adds image credits section' },
          { role: 'PDF Generator', description: 'Creates final PDF document' }
        ],
        verificationWorkers: [
          { role: 'Completeness Check', description: 'Verifies all components included' }
        ],
        estimatedTime: 7,
        outputFiles: ['worksheet_set.pdf', 'worksheet_metadata.json']
      },
      {
        id: 'quality_check',
        name: 'Multi-Pass Quality Check',
        description: 'Comprehensive review with multiple verification passes',
        explanation: 'Multiple verification workers review the entire set 2-3 times. Auto-fix agents correct issues and process repeats until quality threshold is met.',
        workers: [
          { role: 'Auto-Fix Agent', description: 'Automatically corrects detected issues' },
          { role: 'Issue Logger', description: 'Documents all fixes made' }
        ],
        verificationWorkers: [
          { role: 'Answer Verification', description: 'Triple-checks all answer keys' },
          { role: 'Print Quality Check', description: 'Ensures print-friendly formatting' },
          { role: 'Completeness Reviewer', description: 'Verifies all chapters covered' },
          { role: 'Question Quality', description: 'Reviews question clarity' },
          { role: 'Attribution Checker', description: 'Verifies all image credits' }
        ],
        estimatedTime: 12,
        outputFiles: ['quality_report.json', 'fixes_applied.json'],
        iterativeQuality: true,
        maxIterations: 20
      },
      {
        id: 'create_backups',
        name: 'Create Multi-Location Backups',
        description: 'Backing up to 5+ secure locations for maximum safety',
        explanation: 'System creates multiple redundant backups across different storage providers and geographic locations. Each backup is verified for integrity.',
        workers: [
          { role: 'Supabase Storage Agent', description: 'Backs up to Supabase primary storage bucket' },
          { role: 'AWS S3 Backup Agent', description: 'Backs up to Amazon S3 bucket (US-East)' },
          { role: 'Google Cloud Storage Agent', description: 'Backs up to GCS bucket (US-Central)' },
          { role: 'Azure Blob Agent', description: 'Backs up to Azure Blob Storage (Europe)' },
          { role: 'Cloudflare R2 Agent', description: 'Backs up to Cloudflare R2 (Global CDN)' },
          { role: 'Local Archive Manager', description: 'Creates local database archive copy' },
          { role: 'Backup Integrity Verifier', description: 'Verifies checksums for all backups' }
        ],
        verificationWorkers: [
          { role: 'Backup Completeness Check', description: 'Ensures all locations have complete files' },
          { role: 'Integrity Validator', description: 'Validates file integrity across all backups' }
        ],
        estimatedTime: 6,
        outputFiles: ['backup_manifest.json', 'integrity_checksums.json', 'backup_locations.json'],
        iterativeQuality: true,
        maxIterations: 8,
        canRunParallel: true
      },
      {
        id: 'create_archives',
        name: 'Create Long-Term Archives',
        description: 'Creating immutable long-term archives with version history',
        explanation: 'System creates permanent archival copies with version history, metadata tags, and retrieval documentation for future access.',
        workers: [
          { role: 'Version Archive Manager', description: 'Creates versioned archive with timestamp' },
          { role: 'Metadata Tagger', description: 'Tags archive with searchable metadata' },
          { role: 'Glacier Archive Agent', description: 'Stores in AWS Glacier for long-term cold storage' },
          { role: 'Archive Index Builder', description: 'Creates searchable archive index' },
          { role: 'Retrieval Documentation', description: 'Documents how to retrieve archive' }
        ],
        verificationWorkers: [
          { role: 'Archive Accessibility Test', description: 'Verifies archive can be retrieved' }
        ],
        estimatedTime: 5,
        outputFiles: ['archive_manifest.json', 'archive_index.json', 'retrieval_guide.json'],
        canRunParallel: true
      },
      {
        id: 'publish_upload',
        name: 'Upload to Distribution',
        description: 'Publishing finished product to delivery platform',
        explanation: 'System uploads the completed worksheet set to distribution platform.',
        workers: [
          { role: 'Upload Manager', description: 'Uploads to distribution platform' },
          { role: 'CDN Distributor', description: 'Distributes to CDN for fast access' },
          { role: 'Metadata Publisher', description: 'Publishes product metadata' }
        ],
        verificationWorkers: [
          { role: 'Upload Verifier', description: 'Confirms successful upload' },
          { role: 'Accessibility Tester', description: 'Verifies file is accessible' }
        ],
        estimatedTime: 5,
        outputFiles: ['distribution_manifest.json', 'cdn_urls.json']
      }
    ]
  },

  quiz_pack: {
    addonType: 'quiz_pack',
    name: 'Quiz Pack',
    icon: '✅',
    overview: 'Generates comprehensive assessment quizzes with multi-AI question generation, triple answer validation, and professional scoring rubrics',
    steps: [
      {
        id: 'load_master_book',
        name: 'Load Master Book Content',
        description: 'Loading generated master book into context',
        explanation: 'System loads the complete master book content into AI context for analysis.',
        workers: [
          { role: 'Content Loader', description: 'Loads master book from storage' },
          { role: 'Context Manager', description: 'Prepares content for AI processing' }
        ],
        estimatedTime: 2,
        outputFiles: ['master_book_loaded.json'],
        canRunParallel: false
      },
      {
        id: 'analyze_objectives',
        name: 'Analyze Learning Objectives',
        description: 'Identifying key learning objectives from each chapter',
        explanation: 'Workers extract the most important learning objectives and concepts from each chapter that should be assessed. Multiple passes ensure comprehensive coverage.',
        workers: [
          { role: 'Objective Analyzer', description: 'Identifies key learning objectives' },
          { role: 'Assessment Mapper', description: 'Maps objectives to question types' },
          { role: 'Gap Detector', description: 'Finds missed objectives' }
        ],
        verificationWorkers: [
          { role: 'Coverage Validator', description: 'Ensures all key objectives included' }
        ],
        estimatedTime: 9,
        outputFiles: ['learning_objectives.json', 'coverage_report.json'],
        iterativeQuality: true,
        maxIterations: 12
      },
      {
        id: 'design_quizzes',
        name: 'Design Quiz Structure',
        description: 'Planning quiz format and question distribution',
        explanation: 'Workers determine the structure of each quiz: number of questions, question types, point values, and time estimates. Iterative refinement ensures optimal assessment design.',
        workers: [
          { role: 'Quiz Designer', description: 'Plans quiz structure and format' },
          { role: 'Assessment Specialist', description: 'Ensures valid assessment design' },
          { role: 'Balance Optimizer', description: 'Optimizes question type distribution' }
        ],
        verificationWorkers: [
          { role: 'Structure Validator', description: 'Validates quiz structure quality' }
        ],
        estimatedTime: 7,
        outputFiles: ['quiz_structure.json'],
        iterativeQuality: true,
        maxIterations: 10
      },
      {
        id: 'write_questions',
        name: 'Multi-AI Question Generation & Validation',
        description: 'Creating questions using 3 AI models with comprehensive validation',
        explanation: 'Three AI models independently generate quiz questions. Each answer is validated by all 3 models to ensure 100% accuracy. Best questions are selected through consensus scoring.',
        workers: [
          { role: 'GPT-4 Question Generator', description: 'Generates quiz questions using GPT-4' },
          { role: 'Claude Question Generator', description: 'Generates quiz questions using Claude' },
          { role: 'Gemini Question Generator', description: 'Generates quiz questions using Gemini' },
          { role: 'Question Synthesizer', description: 'Selects best questions from all models' },
          { role: 'GPT-4 Answer Validator', description: 'Validates all answers using GPT-4' },
          { role: 'Claude Answer Validator', description: 'Validates all answers using Claude' },
          { role: 'Gemini Answer Validator', description: 'Validates all answers using Gemini' },
          { role: 'Consensus Builder', description: 'Builds consensus on correct answers' },
          { role: 'Distractor Quality Checker', description: 'Ensures distractors are plausible' },
          { role: 'Question Refiner', description: 'Improves question clarity' },
          { role: 'Discrepancy Resolver', description: 'Resolves answer conflicts' }
        ],
        verificationWorkers: [
          { role: 'Triple Accuracy Check', description: 'Verifies all 3 AIs agree on answers' },
          { role: 'Question Validator', description: 'Ensures questions are clear and fair' },
          { role: 'Bias Checker', description: 'Checks for unfair bias' },
          { role: 'Ambiguity Detector', description: 'Finds and fixes ambiguous questions' },
          { role: 'Assessment Validity', description: 'Ensures questions assess stated objectives' }
        ],
        estimatedTime: 22,
        outputFiles: ['quiz_questions.json', 'validation_log.json', 'consensus_report.json'],
        iterativeQuality: true,
        maxIterations: 20
      },
      {
        id: 'create_answer_keys',
        name: 'Create Verified Answer Keys',
        description: 'Generating answer keys with triple AI validation',
        explanation: 'Answer keys are created with explanations and verified by all 3 AI models. Any disagreement triggers expert review to ensure 100% accuracy.',
        workers: [
          { role: 'Answer Key Compiler', description: 'Compiles consensus answer keys' },
          { role: 'Explanation Writer', description: 'Writes detailed explanations' },
          { role: 'GPT-4 Solution Checker', description: 'Validates solutions using GPT-4' },
          { role: 'Claude Solution Checker', description: 'Validates solutions using Claude' },
          { role: 'Gemini Solution Checker', description: 'Validates solutions using Gemini' },
          { role: 'Consensus Validator', description: 'Confirms all AIs agree on answers' },
          { role: 'Explanation Enhancer', description: 'Improves explanation clarity' }
        ],
        verificationWorkers: [
          { role: 'Triple Accuracy Verification', description: 'Final accuracy check by all 3 AIs' },
          { role: 'Answer Re-Validator', description: 'Additional validation pass' },
          { role: 'Explanation Quality', description: 'Ensures explanations are clear' },
          { role: 'Completeness Check', description: 'Ensures all questions have answers' }
        ],
        estimatedTime: 16,
        outputFiles: ['answer_keys.json', 'accuracy_report.json', 'consensus_log.json'],
        iterativeQuality: true,
        maxIterations: 20
      },
      {
        id: 'create_rubrics',
        name: 'Create Scoring Rubrics',
        description: 'Designing scoring rubrics and grading guidelines',
        explanation: 'Workers create detailed scoring rubrics that help teachers grade consistently and fairly.',
        workers: [
          { role: 'Rubric Designer', description: 'Creates scoring rubrics and guidelines' },
          { role: 'Fairness Validator', description: 'Ensures rubrics are fair and clear' }
        ],
        verificationWorkers: [
          { role: 'Rubric Quality Check', description: 'Validates rubric quality' }
        ],
        estimatedTime: 7,
        outputFiles: ['rubrics.json'],
        iterativeQuality: true,
        maxIterations: 10
      },
      {
        id: 'auto_save_progress',
        name: 'Auto-Save Progress',
        description: 'Saving work in progress to prevent data loss',
        explanation: 'System continuously saves all work to database and cloud storage.',
        workers: [
          { role: 'Auto-Save Manager', description: 'Saves progress every 30 seconds' },
          { role: 'Database Writer', description: 'Writes to Supabase database' }
        ],
        estimatedTime: 2,
        outputFiles: ['progress_checkpoint.json'],
        canRunParallel: true
      },
      {
        id: 'format_quizzes',
        name: 'Format Quiz Documents',
        description: 'Creating professional quiz layouts',
        explanation: 'Workers format each quiz into a clean, professional layout ready for printing or digital distribution.',
        workers: [
          { role: 'Layout Designer', description: 'Creates quiz page layouts' },
          { role: 'Typography Specialist', description: 'Ensures readable formatting' },
          { role: 'Print Optimizer', description: 'Optimizes for printing' },
          { role: 'PDF Generator', description: 'Generates PDF files' }
        ],
        verificationWorkers: [
          { role: 'Layout Validator', description: 'Validates layout quality' }
        ],
        estimatedTime: 8,
        outputFiles: ['quizzes/', 'quiz_metadata.json']
      },
      {
        id: 'quality_check',
        name: 'Multi-Pass Quality Check',
        description: 'Comprehensive review with multiple verification passes',
        explanation: 'Multiple verification workers review all quizzes 2-3 times. Auto-fix agents correct issues and process repeats until quality threshold is met.',
        workers: [
          { role: 'Auto-Fix Agent', description: 'Automatically corrects detected issues' },
          { role: 'Issue Logger', description: 'Documents all fixes made' }
        ],
        verificationWorkers: [
          { role: 'Content Validator', description: 'Checks alignment with chapters' },
          { role: 'Answer Verification', description: 'Triple-checks all answer keys' },
          { role: 'Difficulty Balance', description: 'Ensures appropriate difficulty' },
          { role: 'Question Quality', description: 'Reviews question clarity' },
          { role: 'Rubric Validation', description: 'Validates scoring rubrics' }
        ],
        estimatedTime: 14,
        outputFiles: ['quality_report.json', 'fixes_applied.json'],
        iterativeQuality: true,
        maxIterations: 20
      },
      {
        id: 'create_backups',
        name: 'Create Redundant Backups',
        description: 'Backing up to multiple secure locations',
        explanation: 'System creates multiple backups in different locations for data safety.',
        workers: [
          { role: 'Primary Backup Agent', description: 'Backs up to primary cloud storage' },
          { role: 'Secondary Backup Agent', description: 'Backs up to secondary location' },
          { role: 'Archive Manager', description: 'Creates long-term archive copy' }
        ],
        estimatedTime: 4,
        outputFiles: ['backup_manifest.json'],
        canRunParallel: true
      },
      {
        id: 'publish_upload',
        name: 'Upload to Distribution',
        description: 'Publishing finished product to delivery platform',
        explanation: 'System uploads the completed quiz pack to distribution platform.',
        workers: [
          { role: 'Upload Manager', description: 'Uploads to distribution platform' },
          { role: 'CDN Distributor', description: 'Distributes to CDN for fast access' },
          { role: 'Metadata Publisher', description: 'Publishes product metadata' }
        ],
        verificationWorkers: [
          { role: 'Upload Verifier', description: 'Confirms successful upload' },
          { role: 'Accessibility Tester', description: 'Verifies file is accessible' }
        ],
        estimatedTime: 5,
        outputFiles: ['distribution_manifest.json', 'cdn_urls.json']
      }
    ]
  },

  answer_key: {
    addonType: 'answer_key',
    name: 'Answer Key',
    icon: '🔑',
    overview: 'Generates complete solutions with multi-AI validation, ensuring 100% accuracy through triple verification',
    steps: [
      {
        id: 'load_master_book',
        name: 'Load Master Book Content',
        description: 'Loading generated master book into context',
        explanation: 'System loads the complete master book content into AI context for analysis.',
        workers: [
          { role: 'Content Loader', description: 'Loads master book from storage' },
          { role: 'Context Manager', description: 'Prepares content for AI processing' }
        ],
        estimatedTime: 2,
        outputFiles: ['master_book_loaded.json'],
        canRunParallel: false
      },
      {
        id: 'identify_problems',
        name: 'Identify All Problems',
        description: 'Cataloging every problem and exercise in the book',
        explanation: 'Workers scan through the entire book identifying every problem, exercise, and question that needs a solution. Multiple passes ensure nothing is missed.',
        workers: [
          { role: 'Problem Cataloger', description: 'Identifies and catalogs all problems' },
          { role: 'Indexer', description: 'Creates organized index of problems' },
          { role: 'Gap Detector', description: 'Finds any missed problems' }
        ],
        verificationWorkers: [
          { role: 'Completeness Validator', description: 'Ensures all problems found' }
        ],
        estimatedTime: 10,
        outputFiles: ['problem_catalog.json', 'coverage_log.json'],
        iterativeQuality: true,
        maxIterations: 12
      },
      {
        id: 'solve_problems',
        name: 'Multi-AI Problem Solving & Validation',
        description: 'Solving problems using 3 AI models with triple verification',
        explanation: 'Three AI models independently solve every problem. Solutions are compared and any discrepancies trigger expert review. Only consensus solutions are included, ensuring 100% accuracy.',
        workers: [
          { role: 'GPT-4 Problem Solver', description: 'Solves all problems using GPT-4' },
          { role: 'Claude Problem Solver', description: 'Solves all problems using Claude' },
          { role: 'Gemini Problem Solver', description: 'Solves all problems using Gemini' },
          { role: 'Solution Comparator', description: 'Compares solutions across all 3 models' },
          { role: 'Consensus Builder', description: 'Builds consensus solutions' },
          { role: 'Discrepancy Resolver', description: 'Resolves solution conflicts' },
          { role: 'Solution Writer', description: 'Documents final solutions clearly' },
          { role: 'Alternative Methods Compiler', description: 'Shows alternative approaches from different AIs' },
          { role: 'Mathematical Proof Validator', description: 'Validates mathematical rigor' }
        ],
        verificationWorkers: [
          { role: 'Triple Solution Check', description: 'Verifies all 3 AIs agree on answers' },
          { role: 'Mathematical Accuracy', description: 'Validates mathematical correctness' },
          { role: 'Conceptual Correctness', description: 'Ensures conceptually sound solutions' },
          { role: 'Method Reviewer', description: 'Validates solution approaches' },
          { role: 'Final Consensus Check', description: 'Confirms consensus on all solutions' }
        ],
        estimatedTime: 30,
        outputFiles: ['solutions.json', 'accuracy_report.json', 'consensus_log.json', 'alternative_methods.json'],
        iterativeQuality: true,
        maxIterations: 25
      },
      {
        id: 'add_explanations',
        name: 'Add Detailed Explanations',
        description: 'Writing explanations for each solution step',
        explanation: 'Workers add clear explanations for each step, helping teachers understand the reasoning and common mistakes. Iterative refinement ensures clarity.',
        workers: [
          { role: 'Explanation Writer', description: 'Writes clear step explanations' },
          { role: 'Common Mistakes', description: 'Documents typical student errors' },
          { role: 'Clarity Enhancer', description: 'Improves explanation clarity' }
        ],
        verificationWorkers: [
          { role: 'Clarity Validator', description: 'Ensures explanations are clear' }
        ],
        estimatedTime: 14,
        outputFiles: ['detailed_solutions.json'],
        iterativeQuality: true,
        maxIterations: 12
      },
      {
        id: 'organize_by_section',
        name: 'Organize by Chapter & Section',
        description: 'Structuring answer key to match book organization',
        explanation: 'Workers organize all solutions to match the exact structure of the book for easy reference.',
        workers: [
          { role: 'Organizer', description: 'Structures solutions by chapter/section' },
          { role: 'Cross-Referencer', description: 'Adds cross-references to book pages' }
        ],
        verificationWorkers: [
          { role: 'Structure Validator', description: 'Validates organization matches book' }
        ],
        estimatedTime: 6,
        outputFiles: ['organized_solutions.json'],
        iterativeQuality: true,
        maxIterations: 8
      },
      {
        id: 'auto_save_progress',
        name: 'Auto-Save Progress',
        description: 'Saving work in progress to prevent data loss',
        explanation: 'System continuously saves all work to database and cloud storage.',
        workers: [
          { role: 'Auto-Save Manager', description: 'Saves progress every 30 seconds' },
          { role: 'Database Writer', description: 'Writes to Supabase database' }
        ],
        estimatedTime: 2,
        outputFiles: ['progress_checkpoint.json'],
        canRunParallel: true
      },
      {
        id: 'format_document',
        name: 'Format Answer Key Document',
        description: 'Creating professional, teacher-friendly layout',
        explanation: 'Workers format the answer key with clear typography, proper spacing, and easy-to-reference structure.',
        workers: [
          { role: 'Layout Designer', description: 'Creates professional layout' },
          { role: 'Typography Specialist', description: 'Ensures readable formatting' },
          { role: 'Navigation Builder', description: 'Adds bookmarks and navigation' },
          { role: 'PDF Generator', description: 'Generates final PDF' }
        ],
        verificationWorkers: [
          { role: 'Layout Validator', description: 'Validates layout quality' }
        ],
        estimatedTime: 8,
        outputFiles: ['answer_key.pdf', 'answer_key_metadata.json']
      },
      {
        id: 'quality_check',
        name: 'Multi-Pass Quality Check',
        description: 'Comprehensive review with multiple verification passes',
        explanation: 'Multiple verification workers review all solutions 2-3 times. Auto-fix agents correct issues and process repeats until quality threshold is met.',
        workers: [
          { role: 'Auto-Fix Agent', description: 'Automatically corrects detected issues' },
          { role: 'Issue Logger', description: 'Documents all fixes made' }
        ],
        verificationWorkers: [
          { role: 'Solution Validator', description: 'Re-checks all solutions' },
          { role: 'Completeness Check', description: 'Ensures no problems missed' },
          { role: 'Clarity Review', description: 'Ensures explanations are clear' },
          { role: 'Accuracy Validator', description: 'Final accuracy verification' },
          { role: 'Cross-Reference Check', description: 'Validates all references' }
        ],
        estimatedTime: 16,
        outputFiles: ['quality_report.json', 'fixes_applied.json'],
        iterativeQuality: true,
        maxIterations: 20
      },
      {
        id: 'create_backups',
        name: 'Create Redundant Backups',
        description: 'Backing up to multiple secure locations',
        explanation: 'System creates multiple backups in different locations for data safety.',
        workers: [
          { role: 'Primary Backup Agent', description: 'Backs up to primary cloud storage' },
          { role: 'Secondary Backup Agent', description: 'Backs up to secondary location' },
          { role: 'Archive Manager', description: 'Creates long-term archive copy' }
        ],
        estimatedTime: 4,
        outputFiles: ['backup_manifest.json'],
        canRunParallel: true
      },
      {
        id: 'publish_upload',
        name: 'Upload to Distribution',
        description: 'Publishing finished product to delivery platform',
        explanation: 'System uploads the completed answer key to distribution platform.',
        workers: [
          { role: 'Upload Manager', description: 'Uploads to distribution platform' },
          { role: 'CDN Distributor', description: 'Distributes to CDN for fast access' },
          { role: 'Metadata Publisher', description: 'Publishes product metadata' }
        ],
        verificationWorkers: [
          { role: 'Upload Verifier', description: 'Confirms successful upload' },
          { role: 'Accessibility Tester', description: 'Verifies file is accessible' }
        ],
        estimatedTime: 5,
        outputFiles: ['distribution_manifest.json', 'cdn_urls.json']
      }
    ]
  },

  lesson_plans: {
    addonType: 'lesson_plans',
    name: 'Lesson Plans',
    icon: '📚',
    overview: 'Generates structured lesson plans for teachers and educators with activities, assessments, and differentiation',
    steps: [
      {
        id: 'load_master_book',
        name: 'Load Master Book Content',
        description: 'Loading generated master book into context',
        explanation: 'System loads the complete master book content into AI context for analysis.',
        workers: [
          { role: 'Content Loader', description: 'Loads master book from storage' },
          { role: 'Context Manager', description: 'Prepares content for AI processing' }
        ],
        estimatedTime: 2,
        outputFiles: ['master_book_loaded.json'],
        canRunParallel: false
      },
      {
        id: 'analyze_chapters',
        name: 'Analyze Chapter Content',
        description: 'Breaking down each chapter into teachable units',
        explanation: 'Workers analyze chapters to identify key concepts, learning objectives, and natural lesson boundaries. Multiple passes ensure optimal lesson structure.',
        workers: [
          { role: 'Content Analyzer', description: 'Breaks content into lesson units' },
          { role: 'Objective Identifier', description: 'Defines learning objectives per lesson' },
          { role: 'Pedagogy Specialist', description: 'Ensures sound pedagogical structure' }
        ],
        verificationWorkers: [
          { role: 'Structure Validator', description: 'Validates lesson boundaries' }
        ],
        estimatedTime: 12,
        outputFiles: ['lesson_structure.json', 'validation_log.json'],
        iterativeQuality: true,
        maxIterations: 12
      },
      {
        id: 'design_lessons',
        name: 'Design Lesson Structure',
        description: 'Creating lesson frameworks with timing and flow',
        explanation: 'Workers design the structure of each lesson including timing, activities, and teaching strategies. Iterative refinement ensures practical, effective lessons.',
        workers: [
          { role: 'Lesson Designer', description: 'Creates lesson frameworks' },
          { role: 'Timing Specialist', description: 'Estimates time for each activity' },
          { role: 'Flow Optimizer', description: 'Ensures smooth lesson progression' }
        ],
        verificationWorkers: [
          { role: 'Practicality Checker', description: 'Ensures lessons are realistic' }
        ],
        estimatedTime: 14,
        outputFiles: ['lesson_frameworks.json'],
        iterativeQuality: true,
        maxIterations: 12
      },
      {
        id: 'write_objectives',
        name: 'Write Learning Objectives',
        description: 'Creating clear, measurable learning objectives',
        explanation: 'Workers write specific, measurable learning objectives using best practices (Bloom\'s taxonomy, etc.).',
        workers: [
          { role: 'Objective Writer', description: 'Writes measurable objectives' },
          { role: 'Standards Aligner', description: 'Aligns with educational standards' }
        ],
        verificationWorkers: [
          { role: 'Objective Validator', description: 'Ensures objectives are measurable' }
        ],
        estimatedTime: 7,
        outputFiles: ['objectives.json'],
        iterativeQuality: true,
        maxIterations: 10
      },
      {
        id: 'plan_activities',
        name: 'Plan Teaching Activities',
        description: 'Designing engaging activities for each lesson',
        explanation: 'Workers create detailed activity plans including materials, instructions, and engagement strategies. Multiple review cycles ensure activities are practical and engaging.',
        workers: [
          { role: 'Activity Planner', description: 'Designs lesson activities' },
          { role: 'Materials Specialist', description: 'Lists required materials' },
          { role: 'Engagement Expert', description: 'Adds engagement strategies' },
          { role: 'Activity Refiner', description: 'Improves activity quality' }
        ],
        verificationWorkers: [
          { role: 'Engagement Validator', description: 'Ensures activities are engaging' },
          { role: 'Feasibility Checker', description: 'Validates activities are doable' }
        ],
        estimatedTime: 16,
        outputFiles: ['activities.json', 'materials_lists.json', 'engagement_report.json'],
        iterativeQuality: true,
        maxIterations: 15
      },
      {
        id: 'create_assessments',
        name: 'Create Assessment Methods',
        description: 'Designing formative and summative assessments',
        explanation: 'Workers create various assessment methods to measure student learning during and after lessons.',
        workers: [
          { role: 'Assessment Designer', description: 'Creates assessment strategies' },
          { role: 'Rubric Creator', description: 'Develops assessment rubrics' }
        ],
        verificationWorkers: [
          { role: 'Assessment Validator', description: 'Validates assessment quality' }
        ],
        estimatedTime: 10,
        outputFiles: ['assessments.json'],
        iterativeQuality: true,
        maxIterations: 10
      },
      {
        id: 'add_differentiation',
        name: 'Add Differentiation Strategies',
        description: 'Creating modifications for diverse learners',
        explanation: 'Workers add strategies to support struggling learners and challenge advanced students.',
        workers: [
          { role: 'Differentiation Specialist', description: 'Creates support/extension strategies' },
          { role: 'Accessibility Expert', description: 'Adds accessibility accommodations' }
        ],
        verificationWorkers: [
          { role: 'Differentiation Validator', description: 'Validates strategy effectiveness' }
        ],
        estimatedTime: 11,
        outputFiles: ['differentiation.json'],
        iterativeQuality: true,
        maxIterations: 10
      },
      {
        id: 'write_discussion',
        name: 'Write Discussion Questions',
        description: 'Creating thought-provoking discussion prompts',
        explanation: 'Workers write discussion questions that promote critical thinking and classroom dialogue.',
        workers: [
          { role: 'Discussion Designer', description: 'Creates discussion questions' },
          { role: 'Critical Thinking Expert', description: 'Ensures questions promote deeper thinking' }
        ],
        verificationWorkers: [
          { role: 'Question Quality', description: 'Validates question effectiveness' }
        ],
        estimatedTime: 7,
        outputFiles: ['discussion_questions.json'],
        iterativeQuality: true,
        maxIterations: 10
      },
      {
        id: 'auto_save_progress',
        name: 'Auto-Save Progress',
        description: 'Saving work in progress to prevent data loss',
        explanation: 'System continuously saves all work to database and cloud storage.',
        workers: [
          { role: 'Auto-Save Manager', description: 'Saves progress every 30 seconds' },
          { role: 'Database Writer', description: 'Writes to Supabase database' }
        ],
        estimatedTime: 2,
        outputFiles: ['progress_checkpoint.json'],
        canRunParallel: true
      },
      {
        id: 'compile_plans',
        name: 'Compile Lesson Plan Document',
        description: 'Assembling all components into complete lesson plans',
        explanation: 'Workers compile all elements into professionally formatted, ready-to-use lesson plans.',
        workers: [
          { role: 'Document Compiler', description: 'Assembles complete lesson plans' },
          { role: 'TOC Generator', description: 'Creates table of contents' },
          { role: 'Navigation Builder', description: 'Adds navigation aids' },
          { role: 'PDF Generator', description: 'Creates final PDF document' }
        ],
        verificationWorkers: [
          { role: 'Completeness Check', description: 'Verifies all components included' }
        ],
        estimatedTime: 8,
        outputFiles: ['lesson_plans.pdf', 'lesson_plans_metadata.json']
      },
      {
        id: 'quality_check',
        name: 'Multi-Pass Quality Check',
        description: 'Comprehensive review with multiple verification passes',
        explanation: 'Multiple verification workers review all lesson plans 2-3 times. Auto-fix agents correct issues and process repeats until quality threshold is met.',
        workers: [
          { role: 'Auto-Fix Agent', description: 'Automatically corrects detected issues' },
          { role: 'Issue Logger', description: 'Documents all fixes made' }
        ],
        verificationWorkers: [
          { role: 'Educator Review', description: 'Reviews from teacher perspective' },
          { role: 'Completeness Check', description: 'Ensures all components included' },
          { role: 'Practicality Check', description: 'Ensures plans are realistic' },
          { role: 'Standards Alignment', description: 'Validates educational standards alignment' },
          { role: 'Activity Quality', description: 'Reviews activity effectiveness' }
        ],
        estimatedTime: 14,
        outputFiles: ['quality_report.json', 'fixes_applied.json'],
        iterativeQuality: true,
        maxIterations: 20
      },
      {
        id: 'create_backups',
        name: 'Create Redundant Backups',
        description: 'Backing up to multiple secure locations',
        explanation: 'System creates multiple backups in different locations for data safety.',
        workers: [
          { role: 'Primary Backup Agent', description: 'Backs up to primary cloud storage' },
          { role: 'Secondary Backup Agent', description: 'Backs up to secondary location' },
          { role: 'Archive Manager', description: 'Creates long-term archive copy' }
        ],
        estimatedTime: 4,
        outputFiles: ['backup_manifest.json'],
        canRunParallel: true
      },
      {
        id: 'publish_upload',
        name: 'Upload to Distribution',
        description: 'Publishing finished product to delivery platform',
        explanation: 'System uploads the completed lesson plans to distribution platform.',
        workers: [
          { role: 'Upload Manager', description: 'Uploads to distribution platform' },
          { role: 'CDN Distributor', description: 'Distributes to CDN for fast access' },
          { role: 'Metadata Publisher', description: 'Publishes product metadata' }
        ],
        verificationWorkers: [
          { role: 'Upload Verifier', description: 'Confirms successful upload' },
          { role: 'Accessibility Tester', description: 'Verifies file is accessible' }
        ],
        estimatedTime: 5,
        outputFiles: ['distribution_manifest.json', 'cdn_urls.json']
      }
    ]
  },

  presentation_slides: {
    addonType: 'presentation_slides',
    name: 'Presentation Slides',
    icon: '📊',
    overview: 'Generates PowerPoint-style slides covering key concepts with visuals and speaker notes',
    steps: [
      {
        id: 'load_master_book',
        name: 'Load Master Book Content',
        description: 'Loading generated master book into context',
        explanation: 'System loads the complete master book content into AI context for analysis.',
        workers: [
          { role: 'Content Loader', description: 'Loads master book from storage' },
          { role: 'Context Manager', description: 'Prepares content for AI processing' }
        ],
        estimatedTime: 2,
        outputFiles: ['master_book_loaded.json'],
        canRunParallel: false
      },
      {
        id: 'identify_key_concepts',
        name: 'Identify Key Concepts',
        description: 'Extracting the most important concepts from each chapter',
        explanation: 'Workers analyze each chapter to identify the key concepts that should be presented in slides. Multiple passes ensure comprehensive coverage.',
        workers: [
          { role: 'Content Analyzer', description: 'Identifies key concepts per chapter' },
          { role: 'Prioritizer', description: 'Ranks concepts by importance' },
          { role: 'Visual Potential Assessor', description: 'Identifies concepts that need visuals' }
        ],
        verificationWorkers: [
          { role: 'Coverage Validator', description: 'Ensures all key concepts identified' }
        ],
        estimatedTime: 9,
        outputFiles: ['key_concepts.json', 'coverage_report.json'],
        iterativeQuality: true,
        maxIterations: 12
      },
      {
        id: 'design_slide_flow',
        name: 'Design Slide Flow',
        description: 'Planning the narrative structure of the presentation',
        explanation: 'Workers design how concepts flow from slide to slide, creating a logical, engaging narrative. Iterative refinement ensures compelling flow.',
        workers: [
          { role: 'Flow Designer', description: 'Plans slide sequence and transitions' },
          { role: 'Story Architect', description: 'Ensures compelling narrative' },
          { role: 'Pacing Specialist', description: 'Optimizes presentation pacing' }
        ],
        verificationWorkers: [
          { role: 'Flow Validator', description: 'Validates narrative flow quality' }
        ],
        estimatedTime: 10,
        outputFiles: ['slide_structure.json'],
        iterativeQuality: true,
        maxIterations: 12
      },
      {
        id: 'create_content',
        name: 'Create Slide Content',
        description: 'Writing concise, impactful text for each slide',
        explanation: 'Workers create the text content for slides, keeping it concise and visually focused. Multiple review cycles ensure clarity and impact.',
        workers: [
          { role: 'Content Writer', description: 'Writes slide text content' },
          { role: 'Editor', description: 'Refines for clarity and conciseness' },
          { role: 'Impact Optimizer', description: 'Maximizes message impact' }
        ],
        verificationWorkers: [
          { role: 'Clarity Validator', description: 'Ensures content is clear' },
          { role: 'Conciseness Check', description: 'Validates brevity' }
        ],
        estimatedTime: 14,
        outputFiles: ['slide_content.json', 'content_review.json'],
        iterativeQuality: true,
        maxIterations: 15
      },
      {
        id: 'search_images',
        name: 'Search for Presentation Images',
        description: 'Finding high-quality images from multiple sources',
        explanation: 'Multiple workers search different image sources for professional presentation-quality images.',
        workers: [
          { role: 'Pexels Search Agent', description: 'Searches Pexels for presentation images' },
          { role: 'Unsplash Search Agent', description: 'Searches Unsplash for slide images' },
          { role: 'Stock Library Agent', description: 'Searches stock photo libraries' },
          { role: 'Image Metadata Collector', description: 'Gathers attribution info' }
        ],
        estimatedTime: 10,
        outputFiles: ['image_candidates.json', 'image_metadata.json'],
        canRunParallel: true
      },
      {
        id: 'select_images',
        name: 'Select Best Images',
        description: 'AI selects most appropriate images',
        explanation: 'AI reviews candidate images and selects the best fit for each slide based on professionalism and relevance.',
        workers: [
          { role: 'Image Selection AI', description: 'Chooses best images for slides' },
          { role: 'Professional Quality Assessor', description: 'Ensures presentation-quality images' }
        ],
        verificationWorkers: [
          { role: 'Relevance Checker', description: 'Confirms image relevance' }
        ],
        estimatedTime: 8,
        outputFiles: ['selected_images.json'],
        iterativeQuality: true,
        maxIterations: 10
      },
      {
        id: 'design_visuals',
        name: 'Design Visual Elements',
        description: 'Creating diagrams, charts, and illustrations',
        explanation: 'Workers create custom visual aids using AI image generation that help explain concepts and make slides engaging.',
        workers: [
          { role: 'DALL-E Image Generator', description: 'Generates custom illustrations' },
          { role: 'Diagram Designer', description: 'Creates diagrams and infographics' },
          { role: 'Chart Specialist', description: 'Creates data visualizations' }
        ],
        verificationWorkers: [
          { role: 'Visual Quality Check', description: 'Ensures visual quality' }
        ],
        estimatedTime: 14,
        outputFiles: ['visuals/', 'generated_visuals/'],
        iterativeQuality: true,
        maxIterations: 12
      },
      {
        id: 'create_attribution',
        name: 'Create Image Attribution',
        description: 'Compiling image credits',
        explanation: 'Workers create attribution list for all images used in presentation.',
        workers: [
          { role: 'Attribution Compiler', description: 'Creates attribution list' },
          { role: 'Legal Compliance', description: 'Ensures proper attribution format' }
        ],
        estimatedTime: 3,
        outputFiles: ['image_attributions.json']
      },
      {
        id: 'apply_design',
        name: 'Apply Professional Design',
        description: 'Applying consistent, professional visual design',
        explanation: 'Workers apply a cohesive design theme with consistent colors, fonts, and layout. Images are integrated seamlessly.',
        workers: [
          { role: 'Design System', description: 'Applies consistent visual theme' },
          { role: 'Layout Specialist', description: 'Ensures balanced, professional layouts' },
          { role: 'Image Integrator', description: 'Integrates images into slide layouts' },
          { role: 'Brand Consistency', description: 'Ensures consistent visual identity' }
        ],
        verificationWorkers: [
          { role: 'Design Quality Check', description: 'Validates design consistency' }
        ],
        estimatedTime: 12,
        outputFiles: ['styled_slides.json'],
        iterativeQuality: true,
        maxIterations: 10
      },
      {
        id: 'write_speaker_notes',
        name: 'Write Speaker Notes',
        description: 'Creating detailed notes for presenters',
        explanation: 'Workers write comprehensive speaker notes that help presenters explain each slide effectively.',
        workers: [
          { role: 'Speaker Notes Writer', description: 'Writes detailed presenter notes' },
          { role: 'Timing Advisor', description: 'Adds timing guidance' },
          { role: 'Delivery Tips', description: 'Adds presentation tips' }
        ],
        verificationWorkers: [
          { role: 'Notes Quality Check', description: 'Validates notes completeness' }
        ],
        estimatedTime: 12,
        outputFiles: ['speaker_notes.json'],
        iterativeQuality: true,
        maxIterations: 10
      },
      {
        id: 'add_discussion',
        name: 'Add Discussion Prompts',
        description: 'Adding interactive discussion questions',
        explanation: 'Workers add discussion prompts throughout the presentation to engage the audience.',
        workers: [
          { role: 'Engagement Designer', description: 'Creates discussion questions' },
          { role: 'Interaction Strategist', description: 'Plans audience engagement' }
        ],
        verificationWorkers: [
          { role: 'Engagement Validator', description: 'Validates question effectiveness' }
        ],
        estimatedTime: 6,
        outputFiles: ['discussion_prompts.json'],
        iterativeQuality: true,
        maxIterations: 8
      },
      {
        id: 'auto_save_progress',
        name: 'Auto-Save Progress',
        description: 'Saving work in progress to prevent data loss',
        explanation: 'System continuously saves all work to database and cloud storage.',
        workers: [
          { role: 'Auto-Save Manager', description: 'Saves progress every 30 seconds' },
          { role: 'Database Writer', description: 'Writes to Supabase database' }
        ],
        estimatedTime: 2,
        outputFiles: ['progress_checkpoint.json'],
        canRunParallel: true
      },
      {
        id: 'export_formats',
        name: 'Export Multiple Formats',
        description: 'Generating PowerPoint, PDF, and web formats',
        explanation: 'Workers export the presentation in multiple formats for different use cases, including image attributions.',
        workers: [
          { role: 'PPTX Exporter', description: 'Exports to PowerPoint format' },
          { role: 'PDF Exporter', description: 'Exports to PDF format' },
          { role: 'Web Exporter', description: 'Exports to HTML/web format' },
          { role: 'Attribution Integrator', description: 'Adds image credits to all formats' }
        ],
        verificationWorkers: [
          { role: 'Format Validator', description: 'Validates all export formats' }
        ],
        estimatedTime: 8,
        outputFiles: ['slides.pptx', 'slides.pdf', 'slides_web/', 'slides_metadata.json']
      },
      {
        id: 'quality_check',
        name: 'Multi-Pass Quality Check',
        description: 'Comprehensive review with multiple verification passes',
        explanation: 'Multiple verification workers review the entire presentation 2-3 times. Auto-fix agents correct issues and process repeats until quality threshold is met.',
        workers: [
          { role: 'Auto-Fix Agent', description: 'Automatically corrects detected issues' },
          { role: 'Issue Logger', description: 'Documents all fixes made' }
        ],
        verificationWorkers: [
          { role: 'Visual Quality', description: 'Checks visual design consistency' },
          { role: 'Content Accuracy', description: 'Verifies content is accurate' },
          { role: 'Flow Review', description: 'Ensures logical progression' },
          { role: 'Speaker Notes Quality', description: 'Validates speaker notes' },
          { role: 'Attribution Checker', description: 'Verifies all image credits' }
        ],
        estimatedTime: 14,
        outputFiles: ['quality_report.json', 'fixes_applied.json'],
        iterativeQuality: true,
        maxIterations: 20
      },
      {
        id: 'create_backups',
        name: 'Create Redundant Backups',
        description: 'Backing up to multiple secure locations',
        explanation: 'System creates multiple backups in different locations for data safety.',
        workers: [
          { role: 'Primary Backup Agent', description: 'Backs up to primary cloud storage' },
          { role: 'Secondary Backup Agent', description: 'Backs up to secondary location' },
          { role: 'Archive Manager', description: 'Creates long-term archive copy' }
        ],
        estimatedTime: 4,
        outputFiles: ['backup_manifest.json'],
        canRunParallel: true
      },
      {
        id: 'publish_upload',
        name: 'Upload to Distribution',
        description: 'Publishing finished product to delivery platform',
        explanation: 'System uploads the completed presentation to distribution platform.',
        workers: [
          { role: 'Upload Manager', description: 'Uploads to distribution platform' },
          { role: 'CDN Distributor', description: 'Distributes to CDN for fast access' },
          { role: 'Metadata Publisher', description: 'Publishes product metadata' }
        ],
        verificationWorkers: [
          { role: 'Upload Verifier', description: 'Confirms successful upload' },
          { role: 'Accessibility Tester', description: 'Verifies file is accessible' }
        ],
        estimatedTime: 5,
        outputFiles: ['distribution_manifest.json', 'cdn_urls.json']
      }
    ]
  },

  career_guide: {
    addonType: 'career_guide',
    name: 'Career Guide',
    icon: '💼',
    overview: 'Generates comprehensive career guide using multi-AI research for accurate salary data, requirements, and emerging career paths',
    steps: [
      {
        id: 'load_master_book',
        name: 'Load Master Book Content',
        description: 'Loading generated master book into context',
        explanation: 'System loads the complete master book content into AI context for analysis.',
        workers: [
          { role: 'Content Loader', description: 'Loads master book from storage' },
          { role: 'Context Manager', description: 'Prepares content for AI processing' }
        ],
        estimatedTime: 2,
        outputFiles: ['master_book_loaded.json'],
        canRunParallel: false
      },
      {
        id: 'identify_careers',
        name: 'Multi-AI Career Research',
        description: 'Researching careers using 3 AI models for complete coverage',
        explanation: 'Three AI models independently research career paths related to the subject. Each finds different careers and emerging opportunities. Synthesis creates the most comprehensive career list possible.',
        workers: [
          { role: 'GPT-4 Career Researcher', description: 'Researches careers using GPT-4' },
          { role: 'Claude Career Researcher', description: 'Researches careers using Claude' },
          { role: 'Gemini Career Researcher', description: 'Researches careers using Gemini' },
          { role: 'Career List Synthesizer', description: 'Combines all career findings' },
          { role: 'Industry Analyst', description: 'Analyzes industry trends' },
          { role: 'Emerging Careers Scout', description: 'Identifies new/emerging careers' },
          { role: 'Niche Career Finder', description: 'Finds less obvious career paths' }
        ],
        verificationWorkers: [
          { role: 'Coverage Validator', description: 'Ensures comprehensive career coverage' },
          { role: 'Consensus Validator', description: 'Confirms all AI findings included' }
        ],
        estimatedTime: 16,
        outputFiles: ['career_list.json', 'coverage_report.json', 'career_consensus.json'],
        iterativeQuality: true,
        maxIterations: 12
      },
      {
        id: 'research_requirements',
        name: 'Research Career Requirements',
        description: 'Gathering education and skill requirements for each career',
        explanation: 'Workers research the specific education, certifications, and skills needed for each career path. Iterative checks ensure accuracy.',
        workers: [
          { role: 'Requirements Researcher', description: 'Researches education requirements' },
          { role: 'Skills Analyst', description: 'Identifies required skills' },
          { role: 'Certification Specialist', description: 'Identifies required certifications' }
        ],
        verificationWorkers: [
          { role: 'Accuracy Validator', description: 'Validates requirement accuracy' }
        ],
        estimatedTime: 14,
        outputFiles: ['career_requirements.json'],
        iterativeQuality: true,
        maxIterations: 12
      },
      {
        id: 'gather_salary_data',
        name: 'Multi-AI Salary & Outlook Research',
        description: 'Gathering salary data using multiple AI research agents',
        explanation: 'Three AI models independently research salary ranges and job outlook. Data is cross-referenced and synthesized to provide the most accurate, up-to-date information.',
        workers: [
          { role: 'GPT-4 Salary Researcher', description: 'Researches salaries using GPT-4' },
          { role: 'Claude Salary Researcher', description: 'Researches salaries using Claude' },
          { role: 'Gemini Salary Researcher', description: 'Researches salaries using Gemini' },
          { role: 'Salary Data Synthesizer', description: 'Combines salary findings' },
          { role: 'Range Calculator', description: 'Calculates accurate salary ranges' },
          { role: 'Outlook Analyst', description: 'Researches job market trends' },
          { role: 'Growth Projector', description: 'Projects career growth potential' },
          { role: 'Geographic Adjuster', description: 'Provides geographic variations' }
        ],
        verificationWorkers: [
          { role: 'Data Accuracy Check', description: 'Validates salary data accuracy' },
          { role: 'Consensus Validator', description: 'Confirms data consensus' },
          { role: 'Currency Check', description: 'Validates data is current' }
        ],
        estimatedTime: 14,
        outputFiles: ['salary_outlook.json', 'salary_consensus.json', 'geographic_data.json'],
        iterativeQuality: true,
        maxIterations: 12
      },
      {
        id: 'conduct_interviews',
        name: 'Create Professional Profiles',
        description: 'Writing profiles of professionals in each career',
        explanation: 'Workers create compelling profiles of real or composite professionals to make careers relatable.',
        workers: [
          { role: 'Profile Writer', description: 'Writes professional profiles and interviews' },
          { role: 'Story Crafter', description: 'Makes profiles engaging and inspiring' }
        ],
        verificationWorkers: [
          { role: 'Inspiration Validator', description: 'Ensures profiles are motivating' }
        ],
        estimatedTime: 12,
        outputFiles: ['professional_profiles.json'],
        iterativeQuality: true,
        maxIterations: 10
      },
      {
        id: 'map_pathways',
        name: 'Map Career Pathways',
        description: 'Creating step-by-step paths to enter each career',
        explanation: 'Workers create clear, actionable pathways showing how to prepare for and enter each career.',
        workers: [
          { role: 'Pathway Mapper', description: 'Creates career entry pathways' },
          { role: 'Timeline Specialist', description: 'Adds realistic timelines' },
          { role: 'Alternative Route Planner', description: 'Identifies alternative paths' }
        ],
        verificationWorkers: [
          { role: 'Pathway Validator', description: 'Validates pathway accuracy' }
        ],
        estimatedTime: 9,
        outputFiles: ['career_pathways.json'],
        iterativeQuality: true,
        maxIterations: 10
      },
      {
        id: 'search_images',
        name: 'Search for Career Images',
        description: 'Finding professional career-related images',
        explanation: 'Multiple workers search different image sources for professional career images.',
        workers: [
          { role: 'Pexels Search Agent', description: 'Searches Pexels for career images' },
          { role: 'Unsplash Search Agent', description: 'Searches Unsplash for professional images' },
          { role: 'Stock Library Agent', description: 'Searches stock photo libraries' },
          { role: 'Image Metadata Collector', description: 'Gathers attribution info' }
        ],
        estimatedTime: 8,
        outputFiles: ['image_candidates.json', 'image_metadata.json'],
        canRunParallel: true
      },
      {
        id: 'select_images',
        name: 'Select Best Images',
        description: 'AI selects most appropriate images',
        explanation: 'AI reviews candidate images and selects the best fit for each career.',
        workers: [
          { role: 'Image Selection AI', description: 'Chooses best career images' },
          { role: 'Professional Quality Assessor', description: 'Ensures professional quality' }
        ],
        verificationWorkers: [
          { role: 'Relevance Checker', description: 'Confirms image relevance' }
        ],
        estimatedTime: 6,
        outputFiles: ['selected_images.json'],
        iterativeQuality: true,
        maxIterations: 8
      },
      {
        id: 'create_attribution',
        name: 'Create Image Attribution',
        description: 'Compiling image credits',
        explanation: 'Workers create attribution list for all images used in career guide.',
        workers: [
          { role: 'Attribution Compiler', description: 'Creates attribution list' },
          { role: 'Legal Compliance', description: 'Ensures proper attribution format' }
        ],
        estimatedTime: 3,
        outputFiles: ['image_attributions.json']
      },
      {
        id: 'compile_resources',
        name: 'Compile Resources',
        description: 'Gathering helpful resources for career exploration',
        explanation: 'Workers compile lists of resources like schools, certifications, professional organizations, and websites.',
        workers: [
          { role: 'Resource Compiler', description: 'Gathers relevant resources' },
          { role: 'Link Validator', description: 'Validates all resource links' }
        ],
        verificationWorkers: [
          { role: 'Resource Quality Check', description: 'Validates resource quality' }
        ],
        estimatedTime: 7,
        outputFiles: ['resources.json'],
        iterativeQuality: true,
        maxIterations: 8
      },
      {
        id: 'auto_save_progress',
        name: 'Auto-Save Progress',
        description: 'Saving work in progress to prevent data loss',
        explanation: 'System continuously saves all work to database and cloud storage.',
        workers: [
          { role: 'Auto-Save Manager', description: 'Saves progress every 30 seconds' },
          { role: 'Database Writer', description: 'Writes to Supabase database' }
        ],
        estimatedTime: 2,
        outputFiles: ['progress_checkpoint.json'],
        canRunParallel: true
      },
      {
        id: 'create_guide',
        name: 'Create Career Guide Document',
        description: 'Assembling all components into a complete guide',
        explanation: 'Workers compile all career information, images, and attributions into an inspiring, informative guide document.',
        workers: [
          { role: 'Document Compiler', description: 'Assembles complete career guide' },
          { role: 'Image Integrator', description: 'Integrates images into layout' },
          { role: 'Attribution Integrator', description: 'Adds image credits section' },
          { role: 'TOC Generator', description: 'Creates table of contents' },
          { role: 'PDF Generator', description: 'Creates final PDF' }
        ],
        verificationWorkers: [
          { role: 'Completeness Check', description: 'Verifies all components included' }
        ],
        estimatedTime: 9,
        outputFiles: ['career_guide.pdf', 'career_guide_metadata.json']
      },
      {
        id: 'quality_check',
        name: 'Multi-Pass Quality Check',
        description: 'Comprehensive review with multiple verification passes',
        explanation: 'Multiple verification workers review the entire guide 2-3 times. Auto-fix agents correct issues and process repeats until quality threshold is met.',
        workers: [
          { role: 'Auto-Fix Agent', description: 'Automatically corrects detected issues' },
          { role: 'Issue Logger', description: 'Documents all fixes made' }
        ],
        verificationWorkers: [
          { role: 'Accuracy Checker', description: 'Verifies all information is current' },
          { role: 'Completeness Review', description: 'Ensures comprehensive coverage' },
          { role: 'Inspiration Check', description: 'Ensures guide is motivating' },
          { role: 'Salary Data Validator', description: 'Validates salary accuracy' },
          { role: 'Attribution Checker', description: 'Verifies all image credits' }
        ],
        estimatedTime: 12,
        outputFiles: ['quality_report.json', 'fixes_applied.json'],
        iterativeQuality: true,
        maxIterations: 20
      },
      {
        id: 'create_backups',
        name: 'Create Redundant Backups',
        description: 'Backing up to multiple secure locations',
        explanation: 'System creates multiple backups in different locations for data safety.',
        workers: [
          { role: 'Primary Backup Agent', description: 'Backs up to primary cloud storage' },
          { role: 'Secondary Backup Agent', description: 'Backs up to secondary location' },
          { role: 'Archive Manager', description: 'Creates long-term archive copy' }
        ],
        estimatedTime: 4,
        outputFiles: ['backup_manifest.json'],
        canRunParallel: true
      },
      {
        id: 'publish_upload',
        name: 'Upload to Distribution',
        description: 'Publishing finished product to delivery platform',
        explanation: 'System uploads the completed career guide to distribution platform.',
        workers: [
          { role: 'Upload Manager', description: 'Uploads to distribution platform' },
          { role: 'CDN Distributor', description: 'Distributes to CDN for fast access' },
          { role: 'Metadata Publisher', description: 'Publishes product metadata' }
        ],
        verificationWorkers: [
          { role: 'Upload Verifier', description: 'Confirms successful upload' },
          { role: 'Accessibility Tester', description: 'Verifies file is accessible' }
        ],
        estimatedTime: 5,
        outputFiles: ['distribution_manifest.json', 'cdn_urls.json']
      }
    ]
  },

  study_guide: {
    addonType: 'study_guide',
    name: 'Study Guide',
    icon: '📖',
    overview: 'Generates comprehensive study materials with summaries, key terms, review questions, and study strategies',
    steps: [
      {
        id: 'load_master_book',
        name: 'Load Master Book Content',
        description: 'Loading generated master book into context',
        explanation: 'System loads the complete master book content into AI context for analysis.',
        workers: [
          { role: 'Content Loader', description: 'Loads master book from storage' },
          { role: 'Context Manager', description: 'Prepares content for AI processing' }
        ],
        estimatedTime: 2,
        outputFiles: ['master_book_loaded.json'],
        canRunParallel: false
      },
      {
        id: 'create_summaries',
        name: 'Create Chapter Summaries',
        description: 'Writing concise summaries of each chapter',
        explanation: 'Workers create clear, concise summaries that capture the essential content of each chapter. Multiple review passes ensure accuracy and completeness.',
        workers: [
          { role: 'Summary Writer', description: 'Writes chapter summaries' },
          { role: 'Content Distiller', description: 'Extracts key points' },
          { role: 'Conciseness Optimizer', description: 'Refines for brevity' }
        ],
        verificationWorkers: [
          { role: 'Accuracy Checker', description: 'Verifies summaries are accurate' },
          { role: 'Completeness Validator', description: 'Ensures all key points covered' }
        ],
        estimatedTime: 14,
        outputFiles: ['chapter_summaries.json', 'validation_log.json'],
        iterativeQuality: true,
        maxIterations: 12
      },
      {
        id: 'extract_key_terms',
        name: 'Extract Key Terms',
        description: 'Identifying and defining important terminology',
        explanation: 'Workers identify all important terms and create clear, student-friendly definitions. Iterative reviews ensure clarity.',
        workers: [
          { role: 'Term Extractor', description: 'Identifies key terminology' },
          { role: 'Definition Writer', description: 'Writes clear definitions' },
          { role: 'Example Provider', description: 'Adds usage examples' }
        ],
        verificationWorkers: [
          { role: 'Definition Validator', description: 'Validates definition accuracy' },
          { role: 'Clarity Checker', description: 'Ensures student-friendly language' }
        ],
        estimatedTime: 11,
        outputFiles: ['key_terms.json'],
        iterativeQuality: true,
        maxIterations: 12
      },
      {
        id: 'create_concept_maps',
        name: 'Create Concept Maps',
        description: 'Designing visual concept maps showing relationships',
        explanation: 'Workers create visual diagrams showing how concepts relate to each other using AI-generated graphics.',
        workers: [
          { role: 'Concept Mapper', description: 'Designs concept relationship diagrams' },
          { role: 'DALL-E Image Generator', description: 'Generates concept map visuals' },
          { role: 'Visual Designer', description: 'Creates visual layouts' },
          { role: 'Relationship Analyzer', description: 'Identifies concept connections' }
        ],
        verificationWorkers: [
          { role: 'Accuracy Validator', description: 'Validates concept relationships' }
        ],
        estimatedTime: 12,
        outputFiles: ['concept_maps/', 'generated_visuals/'],
        iterativeQuality: true,
        maxIterations: 10
      },
      {
        id: 'write_review_questions',
        name: 'Write Review Questions',
        description: 'Creating practice questions for self-assessment',
        explanation: 'Workers write review questions that help students test their understanding. Multiple verification passes ensure accuracy.',
        workers: [
          { role: 'Question Writer', description: 'Creates review questions' },
          { role: 'Answer Writer', description: 'Writes answers and explanations' },
          { role: 'Difficulty Calibrator', description: 'Ensures appropriate difficulty' }
        ],
        verificationWorkers: [
          { role: 'Answer Validator', description: 'Validates all answers' },
          { role: 'Question Quality', description: 'Ensures question clarity' }
        ],
        estimatedTime: 15,
        outputFiles: ['review_questions.json', 'validation_log.json'],
        iterativeQuality: true,
        maxIterations: 15
      },
      {
        id: 'add_study_strategies',
        name: 'Add Study Strategies',
        description: 'Including effective study tips and techniques',
        explanation: 'Workers add proven study strategies and memory techniques to help students learn effectively.',
        workers: [
          { role: 'Study Skills Expert', description: 'Adds study strategies and tips' },
          { role: 'Learning Styles Specialist', description: 'Adds strategies for different learning styles' }
        ],
        verificationWorkers: [
          { role: 'Strategy Validator', description: 'Validates strategy effectiveness' }
        ],
        estimatedTime: 7,
        outputFiles: ['study_strategies.json'],
        iterativeQuality: true,
        maxIterations: 8
      },
      {
        id: 'create_mnemonics',
        name: 'Create Memory Aids',
        description: 'Designing mnemonics and memory devices',
        explanation: 'Workers create mnemonics, acronyms, and other memory aids to help students remember key information.',
        workers: [
          { role: 'Mnemonic Creator', description: 'Creates memory aids and mnemonics' },
          { role: 'Creativity Specialist', description: 'Makes mnemonics memorable' }
        ],
        verificationWorkers: [
          { role: 'Memorability Check', description: 'Ensures aids are effective' }
        ],
        estimatedTime: 8,
        outputFiles: ['memory_aids.json'],
        iterativeQuality: true,
        maxIterations: 10
      },
      {
        id: 'search_images',
        name: 'Search for Study Aid Images',
        description: 'Finding relevant images for study materials',
        explanation: 'Multiple workers search different image sources for educational images.',
        workers: [
          { role: 'Pexels Search Agent', description: 'Searches Pexels for study images' },
          { role: 'Unsplash Search Agent', description: 'Searches Unsplash for educational images' },
          { role: 'Stock Library Agent', description: 'Searches stock photo libraries' },
          { role: 'Image Metadata Collector', description: 'Gathers attribution info' }
        ],
        estimatedTime: 8,
        outputFiles: ['image_candidates.json', 'image_metadata.json'],
        canRunParallel: true
      },
      {
        id: 'select_images',
        name: 'Select Best Images',
        description: 'AI selects most appropriate images',
        explanation: 'AI reviews candidate images and selects the best fit for study materials.',
        workers: [
          { role: 'Image Selection AI', description: 'Chooses best study images' },
          { role: 'Educational Value Assessor', description: 'Ensures images support learning' }
        ],
        verificationWorkers: [
          { role: 'Relevance Checker', description: 'Confirms image relevance' }
        ],
        estimatedTime: 6,
        outputFiles: ['selected_images.json'],
        iterativeQuality: true,
        maxIterations: 8
      },
      {
        id: 'create_quick_reference',
        name: 'Create Quick Reference Guides',
        description: 'Designing one-page reference sheets',
        explanation: 'Workers create condensed quick-reference sheets for rapid review before exams, integrating selected images.',
        workers: [
          { role: 'Reference Designer', description: 'Creates quick reference sheets' },
          { role: 'Image Integrator', description: 'Integrates images into reference sheets' },
          { role: 'Layout Optimizer', description: 'Optimizes for one-page format' }
        ],
        verificationWorkers: [
          { role: 'Usability Check', description: 'Validates reference sheet usability' }
        ],
        estimatedTime: 10,
        outputFiles: ['quick_references/'],
        iterativeQuality: true,
        maxIterations: 10
      },
      {
        id: 'create_attribution',
        name: 'Create Image Attribution',
        description: 'Compiling image credits',
        explanation: 'Workers create attribution list for all images used in study guide.',
        workers: [
          { role: 'Attribution Compiler', description: 'Creates attribution list' },
          { role: 'Legal Compliance', description: 'Ensures proper attribution format' }
        ],
        estimatedTime: 3,
        outputFiles: ['image_attributions.json']
      },
      {
        id: 'auto_save_progress',
        name: 'Auto-Save Progress',
        description: 'Saving work in progress to prevent data loss',
        explanation: 'System continuously saves all work to database and cloud storage.',
        workers: [
          { role: 'Auto-Save Manager', description: 'Saves progress every 30 seconds' },
          { role: 'Database Writer', description: 'Writes to Supabase database' }
        ],
        estimatedTime: 2,
        outputFiles: ['progress_checkpoint.json'],
        canRunParallel: true
      },
      {
        id: 'compile_guide',
        name: 'Compile Study Guide',
        description: 'Assembling all components into complete study guide',
        explanation: 'Workers compile all study materials, images, and attributions into a comprehensive, well-organized study guide.',
        workers: [
          { role: 'Document Compiler', description: 'Assembles complete study guide' },
          { role: 'TOC Generator', description: 'Creates table of contents' },
          { role: 'Attribution Integrator', description: 'Adds image credits section' },
          { role: 'Navigation Builder', description: 'Adds bookmarks and navigation' },
          { role: 'PDF Generator', description: 'Creates final PDF document' }
        ],
        verificationWorkers: [
          { role: 'Completeness Check', description: 'Verifies all components included' }
        ],
        estimatedTime: 9,
        outputFiles: ['study_guide.pdf', 'study_guide_metadata.json']
      },
      {
        id: 'quality_check',
        name: 'Multi-Pass Quality Check',
        description: 'Comprehensive review with multiple verification passes',
        explanation: 'Multiple verification workers review the entire guide 2-3 times. Auto-fix agents correct issues and process repeats until quality threshold is met.',
        workers: [
          { role: 'Auto-Fix Agent', description: 'Automatically corrects detected issues' },
          { role: 'Issue Logger', description: 'Documents all fixes made' }
        ],
        verificationWorkers: [
          { role: 'Student Perspective', description: 'Reviews from student viewpoint' },
          { role: 'Accuracy Review', description: 'Verifies all content is accurate' },
          { role: 'Usefulness Check', description: 'Ensures guide is practical' },
          { role: 'Question Accuracy', description: 'Validates all review questions' },
          { role: 'Attribution Checker', description: 'Verifies all image credits' }
        ],
        estimatedTime: 14,
        outputFiles: ['quality_report.json', 'fixes_applied.json'],
        iterativeQuality: true,
        maxIterations: 20
      },
      {
        id: 'create_backups',
        name: 'Create Redundant Backups',
        description: 'Backing up to multiple secure locations',
        explanation: 'System creates multiple backups in different locations for data safety.',
        workers: [
          { role: 'Primary Backup Agent', description: 'Backs up to primary cloud storage' },
          { role: 'Secondary Backup Agent', description: 'Backs up to secondary location' },
          { role: 'Archive Manager', description: 'Creates long-term archive copy' }
        ],
        estimatedTime: 4,
        outputFiles: ['backup_manifest.json'],
        canRunParallel: true
      },
      {
        id: 'publish_upload',
        name: 'Upload to Distribution',
        description: 'Publishing finished product to delivery platform',
        explanation: 'System uploads the completed study guide to distribution platform.',
        workers: [
          { role: 'Upload Manager', description: 'Uploads to distribution platform' },
          { role: 'CDN Distributor', description: 'Distributes to CDN for fast access' },
          { role: 'Metadata Publisher', description: 'Publishes product metadata' }
        ],
        verificationWorkers: [
          { role: 'Upload Verifier', description: 'Confirms successful upload' },
          { role: 'Accessibility Tester', description: 'Verifies file is accessible' }
        ],
        estimatedTime: 5,
        outputFiles: ['distribution_manifest.json', 'cdn_urls.json']
      }
    ]
  }
};

export function getAddonWorkflow(addonType: AddonType): AddonWorkflow {
  return ADDON_WORKFLOWS[addonType];
}

export function getAllAddonWorkflows(): AddonWorkflow[] {
  return Object.values(ADDON_WORKFLOWS);
}
