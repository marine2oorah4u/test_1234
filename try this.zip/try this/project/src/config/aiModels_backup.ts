export type ModelTier = 'budget' | 'standard' | 'professional' | 'premium';

export interface ModelInfo {
  name: string;
  provider: string;
  description: string;
  contextWindow: string;
  inputCostPer1M: string;
  outputCostPer1M: string;
  strengths: string[];
  weaknesses: string[];
  bestFor: string[];
  recommended?: boolean;
  tokensAvailable: number;
  tokensNeeded: number;
  tier: ModelTier;
}

export const CATEGORY_TOKEN_POOLS = {
  content: 500000,
  images: 10000,
  audio: 60000,
  video: 200,
  interactive: 400000,
  assessment: 400000,
};

export const CONTENT_MODELS: ModelInfo[] = [
  {
    name: 'GPT-3.5 Turbo',
    provider: 'OpenAI',
    description: 'Fast and cost-effective for simpler educational content and quick generation.',
    contextWindow: '16K tokens',
    inputCostPer1M: '$0.50',
    outputCostPer1M: '$1.50',
    strengths: [
      'Very fast generation',
      'Most cost-effective',
      'Good for simple content',
      'Reliable quality for basic material'
    ],
    weaknesses: [
      'Limited context window',
      'Less sophisticated reasoning',
      'Not suitable for advanced topics',
      'May lack depth'
    ],
    bestFor: [
      'Elementary level content',
      'Simple explanations',
      'Quick drafts',
      'High-volume basic content'
    ],
    tokensAvailable: 800000,
    tokensNeeded: 50000,
    tier: 'budget',
  },
  {
    name: 'Mixtral 8x7B',
    provider: 'Mistral AI',
    description: 'Open-source model with strong multilingual capabilities and good general performance.',
    contextWindow: '32K tokens',
    inputCostPer1M: '$0.70',
    outputCostPer1M: '$0.70',
    strengths: [
      'Excellent multilingual support',
      'Cost-effective',
      'Open-source flexibility',
      'Good general capabilities'
    ],
    weaknesses: [
      'Less powerful than top-tier models',
      'May require more prompt engineering',
      'Smaller context window'
    ],
    bestFor: [
      'Multilingual content',
      'International audiences',
      'Cost-sensitive projects',
      'Open-source requirements'
    ],
    tokensAvailable: 750000,
    tokensNeeded: 50000,
    tier: 'standard',
  },
  {
    name: 'Gemini Pro 1.5',
    provider: 'Google',
    description: 'Strong factual accuracy and real-world connections, particularly for STEM subjects.',
    contextWindow: '1M tokens',
    inputCostPer1M: '$3.50',
    outputCostPer1M: '$10.50',
    strengths: [
      'Massive context window',
      'Strong factual accuracy',
      'Excellent for current events',
      'Great STEM capabilities',
      'Good cost efficiency'
    ],
    weaknesses: [
      'Less creative than GPT models',
      'Can be overly factual',
      'Less polished prose'
    ],
    bestFor: [
      'STEM subjects',
      'Factual reference material',
      'Current events integration',
      'Technical documentation'
    ],
    tokensAvailable: 600000,
    tokensNeeded: 50000,
    tier: 'professional',
  },
  {
    name: 'GPT-4o',
    provider: 'OpenAI',
    description: 'Faster GPT-4 variant with multimodal capabilities and good balance of speed and quality.',
    contextWindow: '128K tokens',
    inputCostPer1M: '$5.00',
    outputCostPer1M: '$15.00',
    strengths: [
      'Faster than GPT-4 Turbo',
      'Better cost efficiency',
      'Multimodal understanding',
      'Good general quality'
    ],
    weaknesses: [
      'Slightly less capable than GPT-4 Turbo',
      'May lack depth on complex topics'
    ],
    bestFor: [
      'General educational content',
      'Mixed media content',
      'Elementary to high school level',
      'Quick turnaround projects'
    ],
    tokensAvailable: 450000,
    tokensNeeded: 50000,
    tier: 'professional',
  },
  {
    name: 'Claude 3.5 Sonnet',
    provider: 'Anthropic',
    description: 'Most balanced model for educational content with superior reasoning and instruction-following.',
    contextWindow: '200K tokens',
    inputCostPer1M: '$3.00',
    outputCostPer1M: '$15.00',
    strengths: [
      'Exceptional instruction following',
      'Strong reasoning and analysis',
      'Excellent for structured content',
      'Maintains consistency across long documents',
      'Great at academic writing style'
    ],
    weaknesses: [
      'More expensive than some alternatives',
      'May be overly verbose at times'
    ],
    bestFor: [
      'Structured lesson plans',
      'Academic papers',
      'Complex educational sequences',
      'Graduate and PhD-level content'
    ],
    recommended: true,
    tokensAvailable: 500000,
    tokensNeeded: 50000,
    tier: 'premium',
  },
  {
    name: 'GPT-4 Turbo',
    provider: 'OpenAI',
    description: 'Powerful model with strong creative and analytical capabilities for comprehensive content.',
    contextWindow: '128K tokens',
    inputCostPer1M: '$10.00',
    outputCostPer1M: '$30.00',
    strengths: [
      'Excellent creative writing',
      'Strong general knowledge',
      'Good at explanations',
      'Versatile across topics'
    ],
    weaknesses: [
      'Most expensive option',
      'Can be less consistent with complex instructions',
      'Sometimes adds unnecessary elaboration'
    ],
    bestFor: [
      'Research papers',
      'Creative educational content',
      'Complex multi-topic books',
      'High school to college level'
    ],
    tokensAvailable: 300000,
    tokensNeeded: 50000,
    tier: 'premium',
  },
];

export const IMAGE_MODELS: ModelInfo[] = [
  {
    name: 'DALL-E 3',
    provider: 'OpenAI',
    description: 'Highest quality educational illustrations with exceptional prompt understanding and detail.',
    contextWindow: 'N/A',
    inputCostPer1M: '$0.04/image',
    outputCostPer1M: 'Standard',
    strengths: [
      'Best prompt understanding',
      'Consistent character generation',
      'Excellent for educational diagrams',
      'High detail and accuracy',
      'Good text rendering in images'
    ],
    weaknesses: [
      'Higher cost per image',
      'Slower generation',
      'Content policy restrictions'
    ],
    bestFor: [
      'Educational illustrations',
      'Detailed diagrams',
      'Character consistency',
      'Professional book graphics'
    ],
    recommended: true,
    tokensAvailable: 10000,
    tokensNeeded: 100,
  },
  {
    name: 'Midjourney V6',
    provider: 'Midjourney',
    description: 'Exceptional artistic quality and photorealism for visually stunning book content.',
    contextWindow: 'N/A',
    inputCostPer1M: 'Subscription',
    outputCostPer1M: 'Based',
    strengths: [
      'Stunning visual quality',
      'Exceptional photorealism',
      'Great for book covers',
      'Artistic and creative',
      'Strong community and resources'
    ],
    weaknesses: [
      'Requires Discord interface',
      'Less precise control',
      'Subscription model only',
      'Cannot ensure consistency'
    ],
    bestFor: [
      'Book covers',
      'Artistic illustrations',
      'Concept art',
      'Marketing materials'
    ],
    tokensAvailable: 8000,
    tokensNeeded: 100,
  },
  {
    name: 'Stable Diffusion XL',
    provider: 'Stability AI',
    description: 'Fast, customizable open-source image generation with good quality and control.',
    contextWindow: 'N/A',
    inputCostPer1M: '$0.003/image',
    outputCostPer1M: 'Low cost',
    strengths: [
      'Very fast generation',
      'Highly customizable',
      'Open-source flexibility',
      'Cost-effective',
      'Can run locally'
    ],
    weaknesses: [
      'Requires technical setup',
      'Quality varies with settings',
      'Less consistent than DALL-E 3',
      'May need fine-tuning'
    ],
    bestFor: [
      'High-volume generation',
      'Custom style training',
      'Budget projects',
      'Rapid iteration'
    ],
    tokensAvailable: 15000,
    tokensNeeded: 100,
  },
  {
    name: 'Adobe Firefly',
    provider: 'Adobe',
    description: 'Commercially-safe image generation integrated with Adobe ecosystem.',
    contextWindow: 'N/A',
    inputCostPer1M: 'Credits',
    outputCostPer1M: 'Based',
    strengths: [
      'Commercially safe training data',
      'Adobe ecosystem integration',
      'Good editing capabilities',
      'Professional quality',
      'Safe for publishing'
    ],
    weaknesses: [
      'Requires Adobe subscription',
      'Less artistic than alternatives',
      'Limited community resources',
      'Fewer style options'
    ],
    bestFor: [
      'Commercial publishing',
      'Professional workflows',
      'Print-ready materials',
      'Corporate content'
    ],
    tokensAvailable: 12000,
    tokensNeeded: 100,
  },
  {
    name: 'Imagen 2',
    provider: 'Google',
    description: 'Google\'s image model with excellent photorealism and text rendering.',
    contextWindow: 'N/A',
    inputCostPer1M: 'Variable',
    outputCostPer1M: 'Pricing',
    strengths: [
      'Exceptional photorealism',
      'Great text in images',
      'Good at complex scenes',
      'Strong safety filters',
      'Google infrastructure'
    ],
    weaknesses: [
      'Limited availability',
      'Less artistic control',
      'Newer with fewer examples',
      'Restricted access'
    ],
    bestFor: [
      'Photorealistic content',
      'Text-heavy images',
      'Google Workspace integration',
      'Educational photography'
    ],
    tokensAvailable: 9000,
    tokensNeeded: 100,
  },
];

export const AUDIO_MODELS: ModelInfo[] = [
  {
    name: 'ElevenLabs Turbo',
    provider: 'ElevenLabs',
    description: 'Most natural-sounding voice synthesis with emotion and perfect for audiobook narration.',
    contextWindow: 'N/A',
    inputCostPer1M: '$0.30/1K chars',
    outputCostPer1M: 'Usage',
    strengths: [
      'Most natural-sounding voices',
      'Excellent emotion and inflection',
      'Multiple voice cloning options',
      'Great for long-form narration',
      'Professional audiobook quality'
    ],
    weaknesses: [
      'Most expensive audio option',
      'Requires good prompting',
      'Can be slow for large projects',
      'Usage limits on lower tiers'
    ],
    bestFor: [
      'Premium audiobooks',
      'Professional narration',
      'Emotional content',
      'Character voices'
    ],
    recommended: true,
    tokensAvailable: 50000,
    tokensNeeded: 5000,
  },
  {
    name: 'OpenAI TTS HD',
    provider: 'OpenAI',
    description: 'High-quality text-to-speech with natural voices and good consistency.',
    contextWindow: 'N/A',
    inputCostPer1M: '$15.00/1M chars',
    outputCostPer1M: 'Usage',
    strengths: [
      'Natural-sounding voices',
      'Consistent quality',
      'Good for educational content',
      'Multiple voice options',
      'Reliable performance'
    ],
    weaknesses: [
      'Less emotion than ElevenLabs',
      'Limited voice customization',
      'Cannot clone voices',
      'Premium pricing'
    ],
    bestFor: [
      'Educational narration',
      'Consistent voice work',
      'Professional content',
      'Long-form audio'
    ],
    tokensAvailable: 60000,
    tokensNeeded: 5000,
  },
  {
    name: 'Google Cloud TTS',
    provider: 'Google',
    description: 'Wide language support with Neural2 voices for multilingual educational content.',
    contextWindow: 'N/A',
    inputCostPer1M: '$16.00/1M chars',
    outputCostPer1M: 'Neural2',
    strengths: [
      'Excellent multilingual support',
      'Wide language coverage',
      'Good quality Neural2 voices',
      'Reliable infrastructure',
      'Strong language detection'
    ],
    weaknesses: [
      'Less natural than top competitors',
      'Variable quality across languages',
      'Limited emotional range',
      'Technical setup required'
    ],
    bestFor: [
      'Multilingual content',
      'International audiences',
      'Language learning materials',
      'Global distribution'
    ],
    tokensAvailable: 70000,
    tokensNeeded: 5000,
  },
  {
    name: 'Azure Neural TTS',
    provider: 'Microsoft',
    description: 'Natural-sounding voices with customizable speech patterns and good accessibility features.',
    contextWindow: 'N/A',
    inputCostPer1M: '$15.00/1M chars',
    outputCostPer1M: 'Neural',
    strengths: [
      'Natural neural voices',
      'Customizable SSML support',
      'Good accessibility features',
      'Enterprise integration',
      'Stable Microsoft infrastructure'
    ],
    weaknesses: [
      'Setup complexity',
      'Azure ecosystem required',
      'Less community resources',
      'Variable voice quality'
    ],
    bestFor: [
      'Enterprise projects',
      'Accessibility features',
      'Microsoft ecosystem',
      'Custom pronunciation needs'
    ],
    tokensAvailable: 65000,
    tokensNeeded: 5000,
  },
];

export const VIDEO_MODELS: ModelInfo[] = [
  {
    name: 'Synthesia',
    provider: 'Synthesia',
    description: 'AI avatar-based video lessons with customizable presenters for instructor-led content.',
    contextWindow: 'N/A',
    inputCostPer1M: 'Subscription',
    outputCostPer1M: 'Based',
    strengths: [
      'Professional AI avatars',
      'Multi-language support',
      'Easy to use interface',
      'Great for instructor videos',
      'Consistent quality'
    ],
    weaknesses: [
      'Subscription cost',
      'Limited creative control',
      'AI avatar limitations',
      'Requires good scripts'
    ],
    bestFor: [
      'Instructor-led lessons',
      'Professional presentations',
      'Training videos',
      'Course content'
    ],
    recommended: true,
    tokensAvailable: 200,
    tokensNeeded: 10,
  },
  {
    name: 'Runway Gen-2',
    provider: 'Runway',
    description: 'Advanced text-to-video and video editing AI for animated educational content.',
    contextWindow: 'N/A',
    inputCostPer1M: 'Credits',
    outputCostPer1M: 'Based',
    strengths: [
      'High-quality video generation',
      'Good for animations',
      'Creative flexibility',
      'Text-to-video capabilities',
      'Professional editing tools'
    ],
    weaknesses: [
      'Expensive per video',
      'Short video lengths',
      'Requires creative skills',
      'Learning curve'
    ],
    bestFor: [
      'Animated explanations',
      'Concept demonstrations',
      'Creative video content',
      'Short educational clips'
    ],
    tokensAvailable: 150,
    tokensNeeded: 10,
  },
  {
    name: 'D-ID',
    provider: 'D-ID',
    description: 'Talking head videos from text and images, perfect for quick video lessons.',
    contextWindow: 'N/A',
    inputCostPer1M: 'Credits',
    outputCostPer1M: 'Per video',
    strengths: [
      'Quick video generation',
      'Natural talking heads',
      'Multiple languages',
      'Easy to use',
      'Good for simple lessons'
    ],
    weaknesses: [
      'Limited avatar customization',
      'Basic video features',
      'Quality depends on input',
      'Can look artificial'
    ],
    bestFor: [
      'Quick video lessons',
      'Simple explanations',
      'Talking head content',
      'Rapid production'
    ],
    tokensAvailable: 180,
    tokensNeeded: 10,
  },
];

export const INTERACTIVE_MODELS: ModelInfo[] = [
  {
    name: 'GPT-4 Turbo',
    provider: 'OpenAI',
    description: 'Best conversational AI for interactive tutoring with excellent explanation capabilities.',
    contextWindow: '128K tokens',
    inputCostPer1M: '$10.00',
    outputCostPer1M: '$30.00',
    strengths: [
      'Excellent conversational ability',
      'Great at explaining concepts',
      'Patient and helpful',
      'Versatile knowledge',
      'Good at Q&A'
    ],
    weaknesses: [
      'Most expensive',
      'Can over-explain',
      'May be verbose',
      'Higher latency'
    ],
    bestFor: [
      'Interactive tutoring',
      'Complex Q&A',
      'Personalized learning',
      'Advanced topics'
    ],
    recommended: true,
    tokensAvailable: 300000,
    tokensNeeded: 30000,
  },
  {
    name: 'Claude 3.5 Sonnet',
    provider: 'Anthropic',
    description: 'Patient and thorough tutor with strong reasoning for Socratic teaching methods.',
    contextWindow: '200K tokens',
    inputCostPer1M: '$3.00',
    outputCostPer1M: '$15.00',
    strengths: [
      'Patient teaching style',
      'Strong reasoning',
      'Socratic method support',
      'Thorough explanations',
      'Good follow-up questions'
    ],
    weaknesses: [
      'Can be overly detailed',
      'May be too formal',
      'Longer responses',
      'Less casual tone'
    ],
    bestFor: [
      'Socratic teaching',
      'Deep learning',
      'Critical thinking',
      'Structured tutoring'
    ],
    tokensAvailable: 400000,
    tokensNeeded: 30000,
  },
  {
    name: 'Gemini Pro',
    provider: 'Google',
    description: 'Real-time information access for current topics and research support.',
    contextWindow: '32K tokens',
    inputCostPer1M: '$0.50',
    outputCostPer1M: '$1.50',
    strengths: [
      'Real-time information',
      'Great for current events',
      'Fast responses',
      'Cost-effective',
      'Good factual accuracy'
    ],
    weaknesses: [
      'Smaller context window',
      'Less creative',
      'Can be too factual',
      'Limited reasoning depth'
    ],
    bestFor: [
      'Current events',
      'Fact-checking',
      'Research assistance',
      'Quick answers'
    ],
    tokensAvailable: 500000,
    tokensNeeded: 30000,
  },
];

export const ASSESSMENT_MODELS: ModelInfo[] = [
  {
    name: 'Claude 3.5 Sonnet',
    provider: 'Anthropic',
    description: 'Excellent at generating well-structured quizzes with fair difficulty progression.',
    contextWindow: '200K tokens',
    inputCostPer1M: '$3.00',
    outputCostPer1M: '$15.00',
    strengths: [
      'Well-structured assessments',
      'Fair difficulty progression',
      'Strong evaluation capabilities',
      'Detailed rubrics',
      'Good question variety'
    ],
    weaknesses: [
      'Can be overly detailed',
      'May create complex questions',
      'Longer generation time',
      'Higher cost'
    ],
    bestFor: [
      'Comprehensive assessments',
      'Rubric creation',
      'Fair testing',
      'Multiple choice + essays'
    ],
    recommended: true,
    tokensAvailable: 400000,
    tokensNeeded: 20000,
  },
  {
    name: 'GPT-4 Turbo',
    provider: 'OpenAI',
    description: 'Creates diverse question types and detailed rubrics for comprehensive assessments.',
    contextWindow: '128K tokens',
    inputCostPer1M: '$10.00',
    outputCostPer1M: '$30.00',
    strengths: [
      'Diverse question types',
      'Creative assessments',
      'Detailed explanations',
      'Good rubric generation',
      'Varied difficulty levels'
    ],
    weaknesses: [
      'Most expensive',
      'Can be inconsistent',
      'May over-complicate',
      'Slower generation'
    ],
    bestFor: [
      'Creative assessments',
      'Diverse question types',
      'Advanced testing',
      'Comprehensive rubrics'
    ],
    tokensAvailable: 300000,
    tokensNeeded: 20000,
  },
  {
    name: 'Gemini Pro',
    provider: 'Google',
    description: 'Strong at factual questions and STEM assessments with accurate grading.',
    contextWindow: '32K tokens',
    inputCostPer1M: '$0.50',
    outputCostPer1M: '$1.50',
    strengths: [
      'Excellent factual questions',
      'Strong STEM assessment',
      'Accurate grading criteria',
      'Cost-effective',
      'Fast generation'
    ],
    weaknesses: [
      'Less creative questions',
      'Limited essay support',
      'Basic rubrics',
      'Smaller context'
    ],
    bestFor: [
      'STEM assessments',
      'Factual quizzes',
      'Standardized tests',
      'Quick generation'
    ],
    tokensAvailable: 500000,
    tokensNeeded: 20000,
  },
];
