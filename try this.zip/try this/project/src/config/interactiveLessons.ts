import { LessonType, ReadingLevel } from '../lib/database.types';

export interface InteractiveFeature {
  id: string;
  name: string;
  description: string;
  icon: string;
  phase: 1 | 2;
  status: 'available' | 'coming_soon';
  availableFor: ReadingLevel[];
}

export const PHASE_1_FEATURES: InteractiveFeature[] = [
  {
    id: 'quizzes',
    name: 'Interactive Quizzes',
    description: 'Multiple choice, true/false, and fill-in-the-blank questions with instant feedback',
    icon: '✅',
    phase: 1,
    status: 'available',
    availableFor: ['kindergarten', 'elementary', 'middle_school', 'high_school', 'bachelors', 'masters', 'phd', 'library']
  },
  {
    id: 'drag_drop',
    name: 'Drag-and-Drop Activities',
    description: 'Label diagrams, sequence events, categorize concepts, and build visual models',
    icon: '🎯',
    phase: 1,
    status: 'available',
    availableFor: ['kindergarten', 'elementary', 'middle_school', 'high_school', 'bachelors', 'masters', 'phd', 'library']
  },
  {
    id: 'games',
    name: 'Simple HTML5 Games',
    description: 'Memory matching, word search, crossword puzzles, and trivia games',
    icon: '🎮',
    phase: 1,
    status: 'available',
    availableFor: ['kindergarten', 'elementary', 'middle_school', 'high_school', 'bachelors', 'masters', 'phd', 'library']
  },
  {
    id: 'tts',
    name: 'Text-to-Speech',
    description: 'Browser-based reading aloud with adjustable speed and text highlighting',
    icon: '🔊',
    phase: 1,
    status: 'available',
    availableFor: ['kindergarten', 'elementary', 'middle_school', 'high_school', 'bachelors', 'masters', 'phd', 'library']
  },
  {
    id: 'ai_tutor',
    name: 'Basic AI Tutor Chat',
    description: 'Text-based Q&A about chapter content, hints, and explanations',
    icon: '🤖',
    phase: 1,
    status: 'available',
    availableFor: ['kindergarten', 'elementary', 'middle_school', 'high_school', 'bachelors', 'masters', 'phd', 'library']
  },
  {
    id: 'progress',
    name: 'Progress Dashboard',
    description: 'Track completed lessons, quiz scores, time spent, and achievements',
    icon: '📊',
    phase: 1,
    status: 'available',
    availableFor: ['kindergarten', 'elementary', 'middle_school', 'high_school', 'bachelors', 'masters', 'phd', 'library']
  }
];

export const PHASE_2_FEATURES: InteractiveFeature[] = [
  {
    id: 'simulations',
    name: 'Advanced Simulations',
    description: 'Physics sandbox, chemistry virtual lab, biology ecosystem builder, math visualization',
    icon: '🔬',
    phase: 2,
    status: 'coming_soon',
    availableFor: ['middle_school', 'high_school', 'bachelors', 'masters', 'phd']
  },
  {
    id: 'voice_tutor',
    name: 'Voice-Interactive AI Tutor',
    description: 'Speak naturally to AI with microphone support and human-like voice responses',
    icon: '🎙️',
    phase: 2,
    status: 'coming_soon',
    availableFor: ['kindergarten', 'elementary', 'middle_school', 'high_school', 'bachelors', 'masters', 'phd', 'library']
  },
  {
    id: 'video_lessons',
    name: 'Video Lessons with Avatar',
    description: 'AI-generated instructor with animated explanations and interactive questions',
    icon: '🎥',
    phase: 2,
    status: 'coming_soon',
    availableFor: ['kindergarten', 'elementary', 'middle_school', 'high_school', 'bachelors', 'masters', 'phd', 'library']
  },
  {
    id: 'adaptive_learning',
    name: 'Adaptive Learning Path',
    description: 'AI adjusts difficulty, personalizes recommendations, and customizes trajectory',
    icon: '🧠',
    phase: 2,
    status: 'coming_soon',
    availableFor: ['kindergarten', 'elementary', 'middle_school', 'high_school', 'bachelors', 'masters', 'phd', 'library']
  },
  {
    id: 'multiplayer',
    name: 'Multiplayer Learning Games',
    description: 'Compete with classmates, collaborative problem-solving, and team challenges',
    icon: '👥',
    phase: 2,
    status: 'coming_soon',
    availableFor: ['elementary', 'middle_school', 'high_school', 'bachelors']
  },
  {
    id: 'vr_ar',
    name: 'VR/AR Experiences',
    description: 'Virtual field trips, 3D model exploration, immersive simulations',
    icon: '🥽',
    phase: 2,
    status: 'coming_soon',
    availableFor: ['middle_school', 'high_school', 'bachelors', 'masters', 'phd']
  },
  {
    id: 'advanced_tutor',
    name: 'Advanced AI Tutor',
    description: 'Emotional intelligence, multiple teaching styles, Socratic questioning',
    icon: '🎓',
    phase: 2,
    status: 'coming_soon',
    availableFor: ['middle_school', 'high_school', 'bachelors', 'masters', 'phd', 'library']
  },
  {
    id: 'study_groups',
    name: 'Live Study Groups',
    description: 'Video chat, shared whiteboards, group projects, peer tutoring',
    icon: '💬',
    phase: 2,
    status: 'coming_soon',
    availableFor: ['high_school', 'bachelors', 'masters', 'phd']
  }
];

export const ALL_INTERACTIVE_FEATURES = [
  ...PHASE_1_FEATURES,
  ...PHASE_2_FEATURES
];

export interface LessonTypeConfig {
  id: LessonType;
  name: string;
  description: string;
  icon: string;
  difficulty: number;
  estimatedTime: number;
}

export const LESSON_TYPES: Record<LessonType, LessonTypeConfig> = {
  quiz: {
    id: 'quiz',
    name: 'Quiz',
    description: 'Multiple choice and short answer questions to test understanding',
    icon: '✅',
    difficulty: 2,
    estimatedTime: 10
  },
  exercise: {
    id: 'exercise',
    name: 'Exercise',
    description: 'Practice problems and activities to reinforce learning',
    icon: '📝',
    difficulty: 3,
    estimatedTime: 15
  },
  game: {
    id: 'game',
    name: 'Game',
    description: 'Fun, engaging games to make learning interactive',
    icon: '🎮',
    difficulty: 1,
    estimatedTime: 8
  },
  simulation: {
    id: 'simulation',
    name: 'Simulation',
    description: 'Interactive simulations to explore concepts hands-on',
    icon: '🔬',
    difficulty: 4,
    estimatedTime: 20
  },
  activity: {
    id: 'activity',
    name: 'Activity',
    description: 'Structured activities combining multiple learning modalities',
    icon: '🎯',
    difficulty: 3,
    estimatedTime: 12
  }
};

export function getPhase1Features(): InteractiveFeature[] {
  return PHASE_1_FEATURES;
}

export function getPhase2Features(): InteractiveFeature[] {
  return PHASE_2_FEATURES;
}

export function getAvailableFeaturesForLevel(level: ReadingLevel): InteractiveFeature[] {
  return ALL_INTERACTIVE_FEATURES.filter(feature =>
    feature.availableFor.includes(level)
  );
}

export function getFeaturesByStatus(status: 'available' | 'coming_soon'): InteractiveFeature[] {
  return ALL_INTERACTIVE_FEATURES.filter(feature => feature.status === status);
}

export function getLessonTypeConfig(type: LessonType): LessonTypeConfig {
  return LESSON_TYPES[type];
}
