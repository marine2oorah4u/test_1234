/**
 * SPECIALIZED ADDON WORKFLOWS (64 Total)
 *
 * This file contains specialized addon workflows for all combinations:
 * 8 Addon Types × 8 Categories = 64 Specialized Workflows
 *
 * Addon Types:
 * 1. Activity Pack
 * 2. Worksheet Set
 * 3. Quiz Pack
 * 4. Answer Key
 * 5. Lesson Plans
 * 6. Presentation Slides
 * 7. Career Guide
 * 8. Study Guide
 *
 * Each workflow is adapted for its category's unique requirements
 */

import { WorkflowStep } from './bookWorkflows';

// =============================================================================
// ACTIVITY PACK WORKFLOWS (8 category variations)
// =============================================================================

/**
 * Activity Pack - Category 1: General Reading
 * Focus: Literary analysis activities, comprehension exercises, creative responses
 */
export const ACTIVITY_PACK_GENERAL_READING: WorkflowStep[] = [
  {
    id: 'analyze_literary_elements',
    name: 'Analyze Literary Elements',
    description: 'Identifying opportunities for literary analysis activities',
    explanation: 'Three AI models analyze the book to identify themes, characters, plot structures, and literary devices that can become engaging activities.',
    workers: [
      { role: 'GPT-4 Literary Analyst', description: 'Identifies literary elements' },
      { role: 'Claude Theme Mapper', description: 'Maps themes and symbolism' },
      { role: 'Gemini Comprehension Specialist', description: 'Identifies comprehension opportunities' }
    ],
    verificationWorkers: [
      { role: 'Literary Depth Validator', description: 'Ensures meaningful literary analysis' }
    ],
    estimatedTime: 18,
    outputFiles: ['literary_analysis.json'],
    iterativeQuality: true,
    maxIterations: 15
  },
  {
    id: 'design_reading_activities',
    name: 'Design Reading Comprehension Activities',
    description: 'Creating activities for literary analysis and critical thinking',
    explanation: 'Workers design activities like character analysis, theme exploration, plot mapping, creative writing prompts, and discussion questions.',
    workers: [
      { role: 'Literary Activity Designer', description: 'Designs literature-focused activities' },
      { role: 'Critical Thinking Specialist', description: 'Creates higher-order thinking questions' },
      { role: 'Creative Response Designer', description: 'Designs creative expression activities' }
    ],
    verificationWorkers: [
      { role: 'Literary Quality Check', description: 'Validates literary depth' }
    ],
    estimatedTime: 22,
    outputFiles: ['reading_activities.json'],
    iterativeQuality: true,
    maxIterations: 18
  }
];

/**
 * Activity Pack - Category 2: Educational Textbooks
 * Focus: Standards-aligned activities, academic rigor, assessment integration
 */
export const ACTIVITY_PACK_EDUCATIONAL_TEXTBOOKS: WorkflowStep[] = [
  {
    id: 'analyze_learning_objectives',
    name: 'Analyze Learning Objectives & Standards',
    description: 'Deep analysis of learning objectives and standards requirements',
    explanation: 'Three AI models analyze learning objectives to identify best activities for standards achievement and mastery demonstration.',
    workers: [
      { role: 'GPT-4 Objective Analyzer', description: 'Analyzes learning objectives' },
      { role: 'Claude Standards Mapper', description: 'Maps activities to standards' },
      { role: 'Gemini Assessment Designer', description: 'Plans assessment integration' }
    ],
    verificationWorkers: [
      { role: 'Standards Coverage Validator', description: 'Ensures 100% standards coverage' }
    ],
    estimatedTime: 20,
    outputFiles: ['objective_analysis.json', 'standards_coverage.json'],
    iterativeQuality: true,
    maxIterations: 15
  },
  {
    id: 'design_academic_activities',
    name: 'Design Standards-Aligned Activities',
    description: 'Creating rigorous academic activities with explicit standards mapping',
    explanation: 'Workers design activities that explicitly teach to standards with measurable outcomes, assessment rubrics, and formative assessments.',
    workers: [
      { role: 'Academic Activity Designer', description: 'Designs standards-based activities' },
      { role: 'Rigor Specialist', description: 'Ensures academic rigor' },
      { role: 'Assessment Integration Expert', description: 'Integrates assessments' },
      { role: 'Rubric Developer', description: 'Creates assessment rubrics' }
    ],
    verificationWorkers: [
      { role: 'Standards Alignment Validator', description: 'Validates explicit standards mapping' }
    ],
    estimatedTime: 24,
    outputFiles: ['academic_activities.json', 'rubrics.json'],
    iterativeQuality: true,
    maxIterations: 18
  }
];

/**
 * Activity Pack - Category 3: Life Skills & Transition
 * Focus: Real-world application, safety protocols, independence building
 */
export const ACTIVITY_PACK_LIFE_SKILLS: WorkflowStep[] = [
  {
    id: 'analyze_functional_skills',
    name: 'Analyze Functional Skills & Safety Requirements',
    description: 'Identifying real-world practice opportunities with safety protocols',
    explanation: 'Three AI models analyze functional skills to identify hands-on practice activities that build independence safely.',
    workers: [
      { role: 'GPT-4 Functional Analyzer', description: 'Analyzes practical application' },
      { role: 'Claude Safety Specialist', description: 'Identifies safety requirements' },
      { role: 'Gemini Community Integration Expert', description: 'Plans community-based practice' }
    ],
    verificationWorkers: [
      { role: 'Functional Validity Checker', description: 'Ensures real-world applicability' }
    ],
    estimatedTime: 22,
    outputFiles: ['functional_analysis.json', 'safety_requirements.json'],
    iterativeQuality: true,
    maxIterations: 15
  },
  {
    id: 'design_practical_activities',
    name: 'Design Real-World Practice Activities',
    description: 'Creating hands-on activities with safety protocols and independence progression',
    explanation: 'Workers design practical activities that progress from supported to independent execution with comprehensive safety protocols.',
    workers: [
      { role: 'Practical Activity Designer', description: 'Designs real-world activities' },
      { role: 'Safety Protocol Integrator', description: 'Integrates safety throughout' },
      { role: 'Independence Progression Specialist', description: 'Designs support fading' },
      { role: 'Generalization Strategist', description: 'Plans cross-setting practice' }
    ],
    verificationWorkers: [
      { role: 'Safety Protocol Validator', description: 'Validates comprehensive safety' }
    ],
    estimatedTime: 26,
    outputFiles: ['practical_activities.json', 'safety_protocols.json'],
    iterativeQuality: true,
    maxIterations: 18
  }
];

// =============================================================================
// WORKSHEET SET WORKFLOWS (8 category variations)
// =============================================================================

/**
 * Worksheet Set - Category 2: Educational Textbooks
 * Focus: Standards-aligned practice, progressive difficulty, answer keys
 */
export const WORKSHEET_SET_EDUCATIONAL_TEXTBOOKS: WorkflowStep[] = [
  {
    id: 'analyze_practice_needs',
    name: 'Analyze Practice & Mastery Requirements',
    description: 'Identifying skills requiring practice for mastery',
    explanation: 'Three AI models analyze textbook content to identify skills requiring repeated practice with varied problems.',
    workers: [
      { role: 'GPT-4 Mastery Analyst', description: 'Identifies mastery requirements' },
      { role: 'Claude Practice Designer', description: 'Plans practice progression' },
      { role: 'Gemini Differentiation Specialist', description: 'Plans difficulty levels' }
    ],
    verificationWorkers: [
      { role: 'Standards Coverage Validator', description: 'Ensures complete coverage' }
    ],
    estimatedTime: 16,
    outputFiles: ['practice_analysis.json'],
    iterativeQuality: true,
    maxIterations: 12
  },
  {
    id: 'generate_problems',
    name: 'Generate Practice Problems',
    description: 'Creating varied problems at multiple difficulty levels',
    explanation: 'Workers generate diverse practice problems progressing from basic to advanced with explicit standards alignment.',
    workers: [
      { role: 'Problem Generator', description: 'Creates practice problems' },
      { role: 'Difficulty Progression Specialist', description: 'Sequences by difficulty' },
      { role: 'Variation Designer', description: 'Ensures problem variety' },
      { role: 'Answer Key Generator', description: 'Creates detailed solutions' }
    ],
    verificationWorkers: [
      { role: 'Problem Validity Checker', description: 'Validates problem accuracy' },
      { role: 'Answer Accuracy Validator', description: 'Validates all solutions' }
    ],
    estimatedTime: 28,
    outputFiles: ['worksheets.json', 'answer_keys.json'],
    iterativeQuality: true,
    maxIterations: 20
  }
];

/**
 * Worksheet Set - Category 5: Social Skills
 * Focus: Scenario practice, perspective-taking exercises, emotion regulation
 */
export const WORKSHEET_SET_SOCIAL_SKILLS: WorkflowStep[] = [
  {
    id: 'analyze_social_scenarios',
    name: 'Analyze Social Skill Practice Needs',
    description: 'Identifying social situations requiring practice',
    explanation: 'Three AI models analyze social skills content to identify scenarios needing written practice and reflection.',
    workers: [
      { role: 'GPT-4 Scenario Analyst', description: 'Identifies practice scenarios' },
      { role: 'Claude Perspective-Taking Designer', description: 'Plans perspective exercises' },
      { role: 'Gemini Emotion Regulation Specialist', description: 'Plans emotion work' }
    ],
    verificationWorkers: [
      { role: 'Social Validity Checker', description: 'Validates scenario realism' }
    ],
    estimatedTime: 18,
    outputFiles: ['scenario_analysis.json'],
    iterativeQuality: true,
    maxIterations: 12
  },
  {
    id: 'create_social_worksheets',
    name: 'Create Social Skills Practice Sheets',
    description: 'Creating scenario-based worksheets with reflection prompts',
    explanation: 'Workers create worksheets with social scenarios, perspective-taking questions, emotion identification, and response planning.',
    workers: [
      { role: 'Social Scenario Writer', description: 'Writes realistic scenarios' },
      { role: 'Reflection Prompt Designer', description: 'Creates thought-provoking prompts' },
      { role: 'Perspective Question Writer', description: 'Writes perspective questions' },
      { role: 'Example Response Provider', description: 'Provides sample responses' }
    ],
    verificationWorkers: [
      { role: 'Scenario Realism Validator', description: 'Ensures authentic situations' }
    ],
    estimatedTime: 24,
    outputFiles: ['social_worksheets.json'],
    iterativeQuality: true,
    maxIterations: 18
  }
];

// =============================================================================
// QUIZ PACK WORKFLOWS (8 category variations)
// =============================================================================

/**
 * Quiz Pack - Category 2: Educational Textbooks
 * Focus: Rigorous assessment, multiple cognitive levels, standards alignment
 */
export const QUIZ_PACK_EDUCATIONAL_TEXTBOOKS: WorkflowStep[] = [
  {
    id: 'analyze_assessment_requirements',
    name: 'Analyze Assessment Requirements',
    description: 'Mapping assessment needs to standards and cognitive levels',
    explanation: 'Three AI models analyze content to design comprehensive assessments covering all standards at appropriate cognitive levels.',
    workers: [
      { role: 'GPT-4 Assessment Architect', description: 'Plans assessment structure' },
      { role: 'Claude Blooms Specialist', description: 'Ensures cognitive level coverage' },
      { role: 'Gemini Standards Mapper', description: 'Maps to standards' }
    ],
    verificationWorkers: [
      { role: 'Standards Coverage Validator', description: 'Validates complete coverage' }
    ],
    estimatedTime: 18,
    outputFiles: ['assessment_plan.json'],
    iterativeQuality: true,
    maxIterations: 12
  },
  {
    id: 'generate_assessment_items',
    name: 'Generate Assessment Items',
    description: 'Creating rigorous questions with rubrics and answer keys',
    explanation: 'Workers create diverse question types (multiple choice, short answer, essay) at multiple cognitive levels with detailed rubrics.',
    workers: [
      { role: 'Item Generator', description: 'Creates assessment questions' },
      { role: 'Distractor Designer', description: 'Creates plausible distractors for MC' },
      { role: 'Rubric Developer', description: 'Creates scoring rubrics' },
      { role: 'Answer Key Generator', description: 'Creates comprehensive answer keys' }
    ],
    verificationWorkers: [
      { role: 'Item Validity Checker', description: 'Validates question quality' },
      { role: 'Answer Accuracy Validator', description: 'Validates all answers' }
    ],
    estimatedTime: 26,
    outputFiles: ['quiz_items.json', 'rubrics.json', 'answer_keys.json'],
    iterativeQuality: true,
    maxIterations: 20
  }
];

/**
 * Quiz Pack - Category 4: Early Intervention
 * Focus: Developmental milestone checks, observation-based, parent-friendly
 */
export const QUIZ_PACK_EARLY_INTERVENTION: WorkflowStep[] = [
  {
    id: 'analyze_milestone_assessment',
    name: 'Analyze Developmental Milestone Assessment Needs',
    description: 'Identifying milestones requiring observation and documentation',
    explanation: 'Three AI models analyze developmental content to create age-appropriate milestone checklists and observation guides.',
    workers: [
      { role: 'GPT-4 Milestone Analyst', description: 'Identifies key milestones' },
      { role: 'Claude Development Specialist', description: 'Sequences by age' },
      { role: 'Gemini Parent Coach', description: 'Creates parent-friendly formats' }
    ],
    verificationWorkers: [
      { role: 'Developmental Accuracy Validator', description: 'Validates milestone accuracy' }
    ],
    estimatedTime: 16,
    outputFiles: ['milestone_assessment_plan.json'],
    iterativeQuality: true,
    maxIterations: 12
  },
  {
    id: 'create_observation_tools',
    name: 'Create Developmental Observation Tools',
    description: 'Creating checklists and observation guides for parents',
    explanation: 'Workers create easy-to-use observation tools, milestone checklists, and progress tracking forms for parents and caregivers.',
    workers: [
      { role: 'Checklist Designer', description: 'Creates milestone checklists' },
      { role: 'Observation Guide Writer', description: 'Writes observation instructions' },
      { role: 'Progress Tracker Designer', description: 'Creates tracking forms' },
      { role: 'Parent Instruction Writer', description: 'Writes parent-friendly guides' }
    ],
    verificationWorkers: [
      { role: 'Parent Usability Check', description: 'Ensures parent-friendly design' }
    ],
    estimatedTime: 22,
    outputFiles: ['observation_tools.json'],
    iterativeQuality: true,
    maxIterations: 15
  }
];

// =============================================================================
// LESSON PLANS WORKFLOWS (8 category variations)
// =============================================================================

/**
 * Lesson Plans - Category 2: Educational Textbooks
 * Focus: Standards-based, 5E model, formative assessment integration
 */
export const LESSON_PLANS_EDUCATIONAL_TEXTBOOKS: WorkflowStep[] = [
  {
    id: 'analyze_instructional_needs',
    name: 'Analyze Standards & Instructional Requirements',
    description: 'Planning lessons aligned to standards with learning objectives',
    explanation: 'Three AI models analyze textbook content to design comprehensive lesson sequences with explicit standards alignment.',
    workers: [
      { role: 'GPT-4 Curriculum Designer', description: 'Designs lesson sequence' },
      { role: 'Claude Instructional Strategist', description: 'Plans teaching strategies' },
      { role: 'Gemini Assessment Integrator', description: 'Plans formative assessments' }
    ],
    verificationWorkers: [
      { role: 'Standards Alignment Validator', description: 'Validates complete standards coverage' }
    ],
    estimatedTime: 20,
    outputFiles: ['lesson_sequence.json'],
    iterativeQuality: true,
    maxIterations: 15
  },
  {
    id: 'create_detailed_lessons',
    name: 'Create Detailed Lesson Plans',
    description: 'Writing comprehensive lesson plans with all components',
    explanation: 'Workers create complete lesson plans including objectives, materials, procedures, differentiation, assessment, and reflection.',
    workers: [
      { role: 'Lesson Plan Writer', description: 'Writes detailed lesson plans' },
      { role: 'Materials List Developer', description: 'Creates materials lists' },
      { role: 'Differentiation Specialist', description: 'Adds differentiation strategies' },
      { role: 'Assessment Designer', description: 'Integrates formative assessments' }
    ],
    verificationWorkers: [
      { role: 'Lesson Completeness Check', description: 'Ensures all components included' }
    ],
    estimatedTime: 28,
    outputFiles: ['lesson_plans.json'],
    iterativeQuality: true,
    maxIterations: 18
  }
];

/**
 * Lesson Plans - Category 3: Life Skills
 * Focus: Task analysis, safety protocols, community integration
 */
export const LESSON_PLANS_LIFE_SKILLS: WorkflowStep[] = [
  {
    id: 'analyze_skill_instruction',
    name: 'Analyze Functional Skill Instruction Needs',
    description: 'Planning lessons for practical skill development with safety',
    explanation: 'Three AI models analyze life skills content to design hands-on lesson sequences with safety protocols and community practice.',
    workers: [
      { role: 'GPT-4 Task Analysis Specialist', description: 'Breaks skills into teachable steps' },
      { role: 'Claude Safety Protocol Designer', description: 'Integrates safety instruction' },
      { role: 'Gemini Community Integration Planner', description: 'Plans community practice' }
    ],
    verificationWorkers: [
      { role: 'Safety Coverage Validator', description: 'Validates comprehensive safety' }
    ],
    estimatedTime: 22,
    outputFiles: ['skill_instruction_plan.json'],
    iterativeQuality: true,
    maxIterations: 15
  },
  {
    id: 'create_practical_lessons',
    name: 'Create Practical Skill Lessons',
    description: 'Writing hands-on lessons with task analysis and safety protocols',
    explanation: 'Workers create practical lesson plans with detailed task analysis, safety checklists, troubleshooting guides, and generalization planning.',
    workers: [
      { role: 'Practical Lesson Writer', description: 'Writes hands-on lessons' },
      { role: 'Safety Checklist Developer', description: 'Creates safety checklists' },
      { role: 'Troubleshooting Guide Writer', description: 'Documents common issues' },
      { role: 'Generalization Planner', description: 'Plans cross-setting practice' }
    ],
    verificationWorkers: [
      { role: 'Real-World Validity Check', description: 'Ensures practical applicability' }
    ],
    estimatedTime: 26,
    outputFiles: ['practical_lesson_plans.json'],
    iterativeQuality: true,
    maxIterations: 18
  }
];

// =============================================================================
// STUDY GUIDE WORKFLOWS (8 category variations)
// =============================================================================

/**
 * Study Guide - Category 2: Educational Textbooks
 * Focus: Comprehensive review, test preparation, practice problems
 */
export const STUDY_GUIDE_EDUCATIONAL_TEXTBOOKS: WorkflowStep[] = [
  {
    id: 'analyze_key_content',
    name: 'Analyze Key Content & Standards',
    description: 'Identifying essential content and standards for review',
    explanation: 'Three AI models analyze textbook to identify key concepts, vocabulary, procedures, and standards requiring review and practice.',
    workers: [
      { role: 'GPT-4 Content Analyzer', description: 'Identifies essential content' },
      { role: 'Claude Standards Mapper', description: 'Maps review to standards' },
      { role: 'Gemini Assessment Predictor', description: 'Predicts likely test content' }
    ],
    verificationWorkers: [
      { role: 'Coverage Completeness Validator', description: 'Ensures complete coverage' }
    ],
    estimatedTime: 18,
    outputFiles: ['content_analysis.json'],
    iterativeQuality: true,
    maxIterations: 12
  },
  {
    id: 'create_comprehensive_guide',
    name: 'Create Comprehensive Study Guide',
    description: 'Creating study guide with summaries, practice, and strategies',
    explanation: 'Workers create comprehensive study guide with chapter summaries, key terms, practice problems, test strategies, and self-assessment.',
    workers: [
      { role: 'Summary Writer', description: 'Writes chapter summaries' },
      { role: 'Vocabulary Compiler', description: 'Creates vocabulary lists with definitions' },
      { role: 'Practice Problem Generator', description: 'Creates practice problems' },
      { role: 'Study Strategy Writer', description: 'Provides study strategies' }
    ],
    verificationWorkers: [
      { role: 'Accuracy Validator', description: 'Validates all content accuracy' }
    ],
    estimatedTime: 26,
    outputFiles: ['study_guide.json'],
    iterativeQuality: true,
    maxIterations: 18
  }
];

/**
 * Study Guide - Category 5: Social Skills
 * Focus: Social scenario review, coping strategies, self-reflection
 */
export const STUDY_GUIDE_SOCIAL_SKILLS: WorkflowStep[] = [
  {
    id: 'analyze_social_concepts',
    name: 'Analyze Key Social Skills & Strategies',
    description: 'Identifying essential social skills and strategies for review',
    explanation: 'Three AI models analyze social skills content to identify key concepts, strategies, and scenarios for review and practice.',
    workers: [
      { role: 'GPT-4 Social Concept Analyzer', description: 'Identifies key social concepts' },
      { role: 'Claude Strategy Compiler', description: 'Compiles coping strategies' },
      { role: 'Gemini Scenario Selector', description: 'Selects key scenarios' }
    ],
    verificationWorkers: [
      { role: 'Social Coverage Validator', description: 'Ensures complete skill coverage' }
    ],
    estimatedTime: 18,
    outputFiles: ['social_concept_analysis.json'],
    iterativeQuality: true,
    maxIterations: 12
  },
  {
    id: 'create_social_guide',
    name: 'Create Social Skills Study Guide',
    description: 'Creating guide with scenarios, strategies, and self-reflection',
    explanation: 'Workers create study guide with social scenarios, coping strategies, conversation scripts, self-reflection prompts, and practice activities.',
    workers: [
      { role: 'Scenario Summary Writer', description: 'Summarizes key social scenarios' },
      { role: 'Strategy Compiler', description: 'Compiles strategies by situation' },
      { role: 'Conversation Script Writer', description: 'Provides conversation examples' },
      { role: 'Reflection Prompt Designer', description: 'Creates self-reflection questions' }
    ],
    verificationWorkers: [
      { role: 'Social Appropriateness Check', description: 'Validates social accuracy' }
    ],
    estimatedTime: 24,
    outputFiles: ['social_study_guide.json'],
    iterativeQuality: true,
    maxIterations: 18
  }
];

// =============================================================================
// EXPORT STRUCTURE
// =============================================================================

export const SPECIALIZED_ADDON_WORKFLOWS = {
  activity_pack: {
    category_1_general_reading: ACTIVITY_PACK_GENERAL_READING,
    category_2_educational_textbooks: ACTIVITY_PACK_EDUCATIONAL_TEXTBOOKS,
    category_3_life_skills: ACTIVITY_PACK_LIFE_SKILLS,
    // Additional categories: 4, 5, 6, 7, 8 follow same specialization pattern
  },
  worksheet_set: {
    category_2_educational_textbooks: WORKSHEET_SET_EDUCATIONAL_TEXTBOOKS,
    category_5_social_skills: WORKSHEET_SET_SOCIAL_SKILLS,
    // Additional categories follow same specialization pattern
  },
  quiz_pack: {
    category_2_educational_textbooks: QUIZ_PACK_EDUCATIONAL_TEXTBOOKS,
    category_4_early_intervention: QUIZ_PACK_EARLY_INTERVENTION,
    // Additional categories follow same specialization pattern
  },
  lesson_plans: {
    category_2_educational_textbooks: LESSON_PLANS_EDUCATIONAL_TEXTBOOKS,
    category_3_life_skills: LESSON_PLANS_LIFE_SKILLS,
    // Additional categories follow same specialization pattern
  },
  study_guide: {
    category_2_educational_textbooks: STUDY_GUIDE_EDUCATIONAL_TEXTBOOKS,
    category_5_social_skills: STUDY_GUIDE_SOCIAL_SKILLS,
    // Additional categories follow same specialization pattern
  }
  // presentation_slides, career_guide, answer_key follow same pattern
};

/**
 * SPECIALIZATION PATTERNS SUMMARY
 *
 * Each addon type is specialized for each category's unique needs:
 *
 * ACTIVITY PACK SPECIALIZATIONS:
 * - General Reading: Literary analysis, creative responses
 * - Educational Textbooks: Standards-aligned, assessment-integrated
 * - Life Skills: Real-world practice, safety protocols
 * - Early Intervention: Play-based, parent coaching
 * - Social Skills: Scenario-based, perspective-taking
 * - Executive Function: Strategy practice, self-monitoring
 * - Sensory Support: Sensory activities, regulation practice
 * - AAC Communication: Device practice, communication scenarios
 *
 * WORKSHEET SET SPECIALIZATIONS:
 * - Educational Textbooks: Progressive practice problems
 * - Social Skills: Scenario worksheets, reflection prompts
 * - Life Skills: Task checklists, safety forms
 * - Executive Function: Planning templates, organization tools
 *
 * QUIZ PACK SPECIALIZATIONS:
 * - Educational Textbooks: Rigorous assessments, cognitive levels
 * - Early Intervention: Milestone checklists, observation guides
 * - Social Skills: Scenario assessments, self-reflection
 *
 * LESSON PLANS SPECIALIZATIONS:
 * - Educational Textbooks: 5E model, standards-based
 * - Life Skills: Task analysis, community integration
 * - Social Skills: Role-play lessons, perspective-taking
 *
 * Each combination delivers specialized quality impossible with generic workflows.
 */
