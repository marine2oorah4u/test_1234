export interface MicroTask {
  name: string;
  status: 'pending' | 'in_progress' | 'completed';
  detail?: string;
}

export interface PipelineStep {
  id: string;
  category: string;
  pipeline: string;
  title: string;
  description: string;
  technicalDetails: string;
  whyItMatters: string;
  workers: { type: string; count: number }[];
  duration: number;
  estimatedRealTime: string;
  output: string;
  logLines: string[];
  microTasks?: MicroTask[];
}

export interface PipelineDemo {
  id: string;
  name: string;
  description: string;
  totalDuration: number;
  steps: PipelineStep[];
}

// Demo: Pipeline 1 Deep Dive - Single Section Generation (Realistic Timeline)
const pipeline1DeepDive: PipelineStep[] = [
  {
    id: 'p1-step1-research',
    category: 'Step 1: Research',
    pipeline: 'Master Reference Book Generation',
    title: 'Research Phase: Literature Review',
    description: '5 research workers launch in parallel. Each queries 4 AI models (GPT-4, Claude, Gemini, Perplexity) simultaneously, gathering authoritative sources.',
    technicalDetails: '5 workers × 4 models = 20 AI instances working in parallel. Each worker completes in ~50 seconds, then synthesizes results.',
    whyItMatters: 'Parallel research across multiple AIs ensures comprehensive coverage. What would take 4 minutes sequentially takes just 50 seconds.',
    workers: [
      { type: 'GPT-4', count: 5 },
      { type: 'Claude', count: 5 },
      { type: 'Gemini', count: 5 },
      { type: 'Perplexity', count: 5 }
    ],
    duration: 5000,
    estimatedRealTime: '50 seconds',
    output: '5 research documents',
    logLines: [
      '> Launching 5 research workers...',
      '> Worker 1-5: Querying GPT-4, Claude, Gemini, Perplexity...',
      '> T+00:30 - All 20 AI queries complete',
      '> Workers synthesizing results...',
      '> Worker 1: Complete (12 citations)',
      '> Worker 2: Complete (15 citations)',
      '> Worker 3: Complete (11 citations)',
      '> Worker 4: Complete (13 citations)',
      '> Worker 5: Complete (14 citations)',
      '✓ Research phase complete: 65 total citations'
    ],
    microTasks: [
      { name: 'Worker 1: Scientific databases', status: 'pending', detail: '12 citations' },
      { name: 'Worker 2: Academic journals', status: 'pending', detail: '15 citations' },
      { name: 'Worker 3: Textbook references', status: 'pending', detail: '11 citations' },
      { name: 'Worker 4: Research papers', status: 'pending', detail: '13 citations' },
      { name: 'Worker 5: Expert sources', status: 'pending', detail: '14 citations' }
    ]
  },
  {
    id: 'p1-step1-verification',
    category: 'Step 1: Research',
    pipeline: 'Master Reference Book Generation',
    title: 'Research Phase: Fact Verification',
    description: 'Claude cross-references all facts and claims across multiple authoritative sources to ensure accuracy.',
    technicalDetails: 'Verifies each major claim against 3+ independent sources. Flags any conflicting information for additional review.',
    whyItMatters: 'Scientific accuracy is non-negotiable. Multiple-source verification catches errors and outdated information.',
    workers: [
      { type: 'Claude', count: 1 }
    ],
    duration: 3000,
    estimatedRealTime: '1-2 minutes',
    output: '856 facts verified, 3 flagged for review',
    logLines: [
      '> Starting fact verification...',
      '> Claude: Cross-referencing claims...',
      '> Verified: 856/859 facts',
      '> Flagged: 3 claims need additional sources',
      '✓ Verification complete'
    ]
  },
  {
    id: 'p1-step2-outline',
    category: 'Step 2: Outline',
    pipeline: 'Master Reference Book Generation',
    title: 'Creating Master Outline Structure',
    description: 'GPT-4 creates comprehensive outline with logical flow, covering all key concepts from research phase.',
    technicalDetails: 'Generates hierarchical structure: Main topics → Sub-topics → Key points. Ensures complete coverage with no gaps.',
    whyItMatters: 'A solid outline ensures nothing is missed and content flows logically. The foundation for quality content.',
    workers: [
      { type: 'GPT-4', count: 1 }
    ],
    duration: 3000,
    estimatedRealTime: '1-2 minutes',
    output: 'Detailed outline with 12 major sections',
    logLines: [
      '> Generating master outline...',
      '> GPT-4: Analyzing research synthesis...',
      '> Creating hierarchical structure...',
      '> Section 1: Introduction and Overview',
      '> Section 2: Historical Context',
      '> Sections 3-12: Generated...',
      '✓ Outline complete: 12 sections'
    ]
  },
  {
    id: 'p1-step3-content-ch1',
    category: 'Step 3: Content Generation',
    pipeline: 'Master Reference Book Generation',
    title: 'Chapter 1, Section 1: Introduction',
    description: 'Four AI models collaborate to write comprehensive introduction. GPT-4 drafts, Claude refines, Llama adds visuals, Gemini fact-checks.',
    technicalDetails: 'Parallel generation by all 4 models, then synthesis combines best elements. Target: ~3,500 words with academic rigor.',
    whyItMatters: 'Multiple AI perspectives produce superior content. Each AI has unique strengths that complement the others.',
    workers: [
      { type: 'GPT-4', count: 1 },
      { type: 'Claude', count: 1 },
      { type: 'Gemini', count: 1 },
      { type: 'Llama', count: 1 }
    ],
    duration: 5000,
    estimatedRealTime: '2-3 minutes',
    output: '3,487 words with citations',
    logLines: [
      '> Starting section 1 generation...',
      '> GPT-4: Writing primary content...',
      '> Claude: Ensuring scientific accuracy...',
      '> Llama: Adding visual descriptions...',
      '> Gemini: Cross-checking facts...',
      '> Section draft complete (3,487 words)',
      '> Running quality check...',
      '✓ Quality score: 94/100 - PASS'
    ]
  },
  {
    id: 'p1-step3-verify',
    category: 'Step 3: Content Generation',
    pipeline: 'Master Reference Book Generation',
    title: 'Section Verification: 4-AI Consensus',
    description: 'All four AI models independently review section for accuracy, completeness, and quality. Consensus required to proceed.',
    technicalDetails: 'Each AI scores on 10 criteria. If consensus score below 90/100, automatic revision loop triggers.',
    whyItMatters: 'Human-level quality control at machine scale. No content passes without unanimous AI approval.',
    workers: [
      { type: 'GPT-4', count: 1 },
      { type: 'Claude', count: 1 },
      { type: 'Gemini', count: 1 },
      { type: 'Llama', count: 1 }
    ],
    duration: 3000,
    estimatedRealTime: '30-60 seconds',
    output: 'Verification scores and approval',
    logLines: [
      '> Running verification protocols...',
      '> GPT-4 verification: 95/100',
      '> Claude verification: 93/100',
      '> Gemini verification: 94/100',
      '> Llama verification: 92/100',
      '> Consensus score: 94/100',
      '✓ Section verified and approved'
    ]
  },
  {
    id: 'p1-step4-synthesis',
    category: 'Step 4: Research & Synthesis',
    pipeline: 'Master Reference Book Generation',
    title: 'Research Phase: Synthesis & Citations',
    description: 'Gemini synthesizes all research into a coherent knowledge base with proper citations in scientific format.',
    technicalDetails: 'Creates citation database in APA format. Links each fact to source. Builds knowledge graph showing relationships between concepts.',
    whyItMatters: 'Proper citations allow verification and further study. Knowledge graph ensures logical content organization.',
    workers: [
      { type: 'Gemini', count: 1 }
    ],
    duration: 4000,
    estimatedRealTime: '1-2 minutes',
    output: 'Knowledge base with 65 linked citations',
    logLines: [
      '> Starting research synthesis...',
      '> Gemini: Creating citation database...',
      '> Building knowledge graph...',
      '> Linking facts to sources...',
      '> Formatting citations (APA)...',
      '✓ Synthesis complete: 65 citations linked'
    ]
  }
];

export const availableDemos: PipelineDemo[] = [
  {
    id: 'pipeline1-deep-dive',
    name: 'Pipeline 1 Deep Dive',
    description: 'See exactly how a single section is generated through 7 detailed steps with real worker counts and timing',
    totalDuration: 30000,
    steps: pipeline1DeepDive
  }
];
