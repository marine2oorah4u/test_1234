import { FormatType } from '../lib/database.types';

export interface WorkflowWorker {
  role: string;
  description: string;
}

export interface WorkflowStep {
  id: string;
  name: string;
  description: string;
  explanation: string;
  workers: WorkflowWorker[];
  verificationWorkers?: WorkflowWorker[];
  estimatedTime: number;
  outputFiles?: string[];
  iterativeQuality?: boolean;
  maxIterations?: number;
  canRunParallel?: boolean;
}

export interface BookWorkflow {
  formatType: FormatType | 'master';
  name: string;
  icon: string;
  overview: string;
  steps: WorkflowStep[];
}

export const BOOK_WORKFLOWS: Record<string, BookWorkflow> = {
  master_book: {
    formatType: 'master',
    name: 'Master Book',
    icon: '📖',
    overview: 'Generates the foundational master book content using multi-AI research, expert-level writing, and comprehensive fact-checking',
    steps: [
      {
        id: 'multi_ai_research',
        name: 'Multi-AI Research Phase',
        description: 'Researching topic using 3 AI models for comprehensive coverage',
        explanation: 'Three AI models independently research the book topic from different angles. GPT-4 focuses on breadth, Claude on depth and nuance, Gemini on latest information. Results are synthesized to create the most comprehensive research foundation possible.',
        workers: [
          { role: 'GPT-4 Research Agent', description: 'Conducts broad research using GPT-4' },
          { role: 'Claude Research Agent', description: 'Conducts deep research using Claude' },
          { role: 'Gemini Research Agent', description: 'Researches latest info using Gemini' },
          { role: 'Research Synthesizer', description: 'Combines findings from all 3 AI models' },
          { role: 'Source Evaluator', description: 'Evaluates source credibility' },
          { role: 'Fact Cross-Checker', description: 'Cross-checks facts across models' },
          { role: 'Gap Identifier', description: 'Identifies research gaps' },
          { role: 'Citation Compiler', description: 'Compiles all sources and citations' }
        ],
        verificationWorkers: [
          { role: 'Research Coverage Validator', description: 'Ensures comprehensive topic coverage' },
          { role: 'Source Quality Checker', description: 'Validates source credibility' },
          { role: 'Consensus Validator', description: 'Confirms all AI insights captured' },
          { role: 'Fact Accuracy Checker', description: 'Triple-checks all facts' }
        ],
        estimatedTime: 25,
        outputFiles: ['research_synthesis.json', 'sources.json', 'fact_database.json', 'consensus_report.json'],
        iterativeQuality: true,
        maxIterations: 15
      },
      {
        id: 'create_outline',
        name: 'Create Comprehensive Outline',
        description: 'Building detailed chapter and section structure',
        explanation: 'Workers create a detailed outline with chapter structure, learning objectives, key concepts per section, and narrative flow. Multiple iterations refine structure for optimal learning progression.',
        workers: [
          { role: 'Outline Architect', description: 'Creates overall book structure' },
          { role: 'Chapter Designer', description: 'Designs individual chapter structures' },
          { role: 'Learning Objective Writer', description: 'Defines learning objectives per chapter' },
          { role: 'Flow Optimizer', description: 'Ensures logical concept progression' },
          { role: 'Concept Mapper', description: 'Maps concept dependencies across chapters' }
        ],
        verificationWorkers: [
          { role: 'Structure Validator', description: 'Validates outline structure' },
          { role: 'Flow Checker', description: 'Ensures smooth progression' },
          { role: 'Coverage Verifier', description: 'Confirms all research topics included' }
        ],
        estimatedTime: 12,
        outputFiles: ['outline.json', 'chapter_structure.json', 'learning_objectives.json'],
        iterativeQuality: true,
        maxIterations: 12
      },
      {
        id: 'multi_ai_content_generation',
        name: 'Multi-AI Content Writing',
        description: 'Generating content using 3 AI models with consensus synthesis',
        explanation: 'Three AI models independently write each chapter. The best passages from each are combined, ensuring the final content has the breadth of GPT-4, depth of Claude, and clarity of Gemini. Synthesis creates superior content than any single model.',
        workers: [
          { role: 'GPT-4 Writer', description: 'Writes comprehensive content using GPT-4' },
          { role: 'Claude Writer', description: 'Writes detailed content using Claude' },
          { role: 'Gemini Writer', description: 'Writes clear content using Gemini' },
          { role: 'Content Synthesizer', description: 'Combines best elements from all 3 models' },
          { role: 'Style Harmonizer', description: 'Ensures consistent voice across synthesized content' },
          { role: 'Technical Accuracy Checker', description: 'Validates technical details' },
          { role: 'Clarity Enhancer', description: 'Improves readability and clarity' },
          { role: 'Example Generator', description: 'Adds relevant examples and illustrations' }
        ],
        verificationWorkers: [
          { role: 'Content Quality Validator', description: 'Ensures high-quality writing' },
          { role: 'Accuracy Triple-Check', description: 'Validates accuracy across all 3 models' },
          { role: 'Completeness Checker', description: 'Ensures all outline points covered' },
          { role: 'Coherence Validator', description: 'Checks for logical flow' }
        ],
        estimatedTime: 45,
        outputFiles: ['master_content.json', 'chapter_files/', 'synthesis_log.json'],
        iterativeQuality: true,
        maxIterations: 20
      },
      {
        id: 'fact_checking',
        name: 'Multi-AI Fact Verification',
        description: 'Triple-checking all facts using 3 independent AI models',
        explanation: 'Every factual claim is independently verified by all 3 AI models. Any discrepancies trigger expert review. Facts must pass consensus validation or be flagged for correction.',
        workers: [
          { role: 'GPT-4 Fact Checker', description: 'Verifies all facts using GPT-4' },
          { role: 'Claude Fact Checker', description: 'Verifies all facts using Claude' },
          { role: 'Gemini Fact Checker', description: 'Verifies all facts using Gemini' },
          { role: 'Consensus Validator', description: 'Identifies agreement and conflicts' },
          { role: 'Discrepancy Resolver', description: 'Resolves factual conflicts' },
          { role: 'Source Verifier', description: 'Validates against original sources' },
          { role: 'Citation Checker', description: 'Ensures proper citation for all facts' }
        ],
        verificationWorkers: [
          { role: 'Accuracy Certification', description: 'Certifies fact accuracy' },
          { role: 'Source Quality Check', description: 'Validates source reliability' },
          { role: 'Consensus Confirmation', description: 'Confirms all 3 AIs agree on facts' }
        ],
        estimatedTime: 20,
        outputFiles: ['fact_check_report.json', 'verified_facts.json', 'correction_log.json'],
        iterativeQuality: true,
        maxIterations: 15
      },
      {
        id: 'add_visuals',
        name: 'Add Diagrams and Visuals',
        description: 'Creating and integrating visual aids throughout content',
        explanation: 'Workers identify opportunities for visual learning aids, create diagrams, charts, and illustrations, and integrate them seamlessly into content.',
        workers: [
          { role: 'Visual Opportunity Identifier', description: 'Finds places needing visuals' },
          { role: 'Diagram Designer', description: 'Designs explanatory diagrams' },
          { role: 'Chart Creator', description: 'Creates data visualizations' },
          { role: 'Illustration Integrator', description: 'Integrates visuals into text' },
          { role: 'Alt Text Writer', description: 'Writes accessibility descriptions' }
        ],
        verificationWorkers: [
          { role: 'Visual Clarity Check', description: 'Ensures visuals are clear' },
          { role: 'Accessibility Validator', description: 'Validates accessibility features' }
        ],
        estimatedTime: 15,
        outputFiles: ['visual_elements/', 'diagram_specs.json', 'alt_text.json'],
        iterativeQuality: true,
        maxIterations: 10
      },
      {
        id: 'create_glossary',
        name: 'Build Comprehensive Glossary',
        description: 'Creating glossary of terms and concepts',
        explanation: 'Workers extract all key terms, write clear definitions, and organize alphabetically with cross-references.',
        workers: [
          { role: 'Term Extractor', description: 'Identifies all key terms' },
          { role: 'Definition Writer', description: 'Writes clear definitions' },
          { role: 'Cross-Reference Builder', description: 'Links related terms' },
          { role: 'Pronunciation Guide Writer', description: 'Adds pronunciation guides' }
        ],
        verificationWorkers: [
          { role: 'Definition Accuracy Check', description: 'Validates definitions' },
          { role: 'Completeness Validator', description: 'Ensures all terms included' }
        ],
        estimatedTime: 8,
        outputFiles: ['glossary.json', 'term_index.json'],
        iterativeQuality: true,
        maxIterations: 8
      },
      {
        id: 'create_index',
        name: 'Build Comprehensive Index',
        description: 'Creating detailed index of topics and concepts',
        explanation: 'Workers create a searchable index of all topics, concepts, and key terms with page references.',
        workers: [
          { role: 'Topic Indexer', description: 'Indexes all major topics' },
          { role: 'Reference Mapper', description: 'Maps page references' },
          { role: 'Cross-Reference Builder', description: 'Creates cross-references' },
          { role: 'Alphabetizer', description: 'Organizes alphabetically' }
        ],
        verificationWorkers: [
          { role: 'Index Completeness Check', description: 'Ensures comprehensive indexing' },
          { role: 'Reference Accuracy Validator', description: 'Validates page references' }
        ],
        estimatedTime: 6,
        outputFiles: ['index.json', 'topic_map.json'],
        iterativeQuality: true,
        maxIterations: 8
      },
      {
        id: 'quality_review',
        name: 'Multi-Pass Quality Review',
        description: 'Comprehensive review with auto-fix and multiple passes',
        explanation: 'Multiple verification workers review entire content 3-4 times. Auto-fix agents correct issues and process repeats until quality threshold met.',
        workers: [
          { role: 'Auto-Fix Agent', description: 'Automatically corrects detected issues' },
          { role: 'Grammar Corrector', description: 'Fixes grammar and syntax' },
          { role: 'Style Polisher', description: 'Polishes writing style' },
          { role: 'Consistency Enforcer', description: 'Ensures consistency throughout' }
        ],
        verificationWorkers: [
          { role: 'Content Quality Reviewer', description: 'Reviews overall content quality' },
          { role: 'Accuracy Final Check', description: 'Final fact accuracy verification' },
          { role: 'Readability Validator', description: 'Ensures appropriate reading level' },
          { role: 'Completeness Final Check', description: 'Confirms nothing missing' },
          { role: 'Professional Polish', description: 'Ensures professional quality' }
        ],
        estimatedTime: 18,
        outputFiles: ['quality_report.json', 'fixes_applied.json', 'final_review.json'],
        iterativeQuality: true,
        maxIterations: 25
      },
      {
        id: 'create_metadata',
        name: 'Generate Book Metadata',
        description: 'Creating comprehensive metadata and cataloging information',
        explanation: 'Workers generate ISBN-ready metadata, cataloging info, keywords, and classification data.',
        workers: [
          { role: 'Metadata Generator', description: 'Creates core metadata' },
          { role: 'Keyword Extractor', description: 'Extracts relevant keywords' },
          { role: 'Classification Specialist', description: 'Assigns classification codes' },
          { role: 'Description Writer', description: 'Writes book descriptions' }
        ],
        estimatedTime: 4,
        outputFiles: ['metadata.json', 'keywords.json', 'catalog_info.json']
      },
      {
        id: 'create_backups',
        name: 'Create Multi-Location Backups',
        description: 'Backing up to 5+ secure locations for maximum safety',
        explanation: 'System creates multiple redundant backups across different storage providers and geographic locations. Each backup is verified for integrity.',
        workers: [
          { role: 'Supabase Storage Agent', description: 'Backs up to Supabase primary storage bucket' },
          { role: 'AWS S3 Backup Agent', description: 'Backs up to Amazon S3 bucket (US-East)' },
          { role: 'Google Cloud Storage Agent', description: 'Backs up to GCS bucket (US-Central)' },
          { role: 'Azure Blob Agent', description: 'Backs up to Azure Blob Storage (Europe)' },
          { role: 'Cloudflare R2 Agent', description: 'Backs up to Cloudflare R2 (Global CDN)' },
          { role: 'Local Archive Manager', description: 'Creates local database archive copy' },
          { role: 'Backup Integrity Verifier', description: 'Verifies checksums for all backups' }
        ],
        verificationWorkers: [
          { role: 'Backup Completeness Check', description: 'Ensures all locations have complete files' },
          { role: 'Integrity Validator', description: 'Validates file integrity across all backups' }
        ],
        estimatedTime: 6,
        outputFiles: ['backup_manifest.json', 'integrity_checksums.json', 'backup_locations.json'],
        iterativeQuality: true,
        maxIterations: 8,
        canRunParallel: true
      },
      {
        id: 'finalize',
        name: 'Finalize Master Book',
        description: 'Final compilation and master book creation',
        explanation: 'System compiles all components into final master book format ready for adaptation to different reading levels.',
        workers: [
          { role: 'Master Compiler', description: 'Compiles all components' },
          { role: 'TOC Generator', description: 'Generates table of contents' },
          { role: 'Front Matter Creator', description: 'Creates title page, copyright, etc.' },
          { role: 'Back Matter Creator', description: 'Creates appendices, index, glossary' },
          { role: 'Final Formatter', description: 'Applies final formatting' }
        ],
        verificationWorkers: [
          { role: 'Completeness Final Validation', description: 'Ensures all parts included' },
          { role: 'Format Validation', description: 'Validates formatting is correct' }
        ],
        estimatedTime: 5,
        outputFiles: ['master_book.json', 'master_book.md', 'compilation_manifest.json']
      }
    ]
  },

  pdf: {
    formatType: 'pdf',
    name: 'PDF Book',
    icon: '📄',
    overview: 'Converts master book to professionally formatted PDF with print-ready layouts',
    steps: [
      {
        id: 'load_master',
        name: 'Load Master Book',
        description: 'Loading master book content',
        explanation: 'System loads the master book content for PDF conversion.',
        workers: [
          { role: 'Content Loader', description: 'Loads master book' }
        ],
        estimatedTime: 1,
        outputFiles: ['master_loaded.json'],
        canRunParallel: false
      },
      {
        id: 'design_layout',
        name: 'Design PDF Layout',
        description: 'Creating professional print layout',
        explanation: 'Workers design page layouts, typography, margins, and visual hierarchy for professional print quality.',
        workers: [
          { role: 'Layout Designer', description: 'Designs page layouts' },
          { role: 'Typography Specialist', description: 'Selects fonts and sizes' },
          { role: 'Margin Optimizer', description: 'Optimizes margins for printing' },
          { role: 'Visual Hierarchy Designer', description: 'Creates clear hierarchy' }
        ],
        verificationWorkers: [
          { role: 'Print Quality Checker', description: 'Ensures print readiness' }
        ],
        estimatedTime: 8,
        outputFiles: ['layout_specs.json', 'style_guide.json'],
        iterativeQuality: true,
        maxIterations: 10
      },
      {
        id: 'format_content',
        name: 'Format Content',
        description: 'Applying formatting to all content',
        explanation: 'Workers apply formatting, insert page breaks, handle widows/orphans, and ensure proper pagination.',
        workers: [
          { role: 'Content Formatter', description: 'Formats all text content' },
          { role: 'Pagination Specialist', description: 'Handles page breaks' },
          { role: 'Widow/Orphan Fixer', description: 'Fixes typography issues' },
          { role: 'Image Placer', description: 'Places images optimally' }
        ],
        verificationWorkers: [
          { role: 'Format Validator', description: 'Validates formatting' }
        ],
        estimatedTime: 10,
        outputFiles: ['formatted_content/', 'pagination_map.json'],
        iterativeQuality: true,
        maxIterations: 8
      },
      {
        id: 'generate_pdf',
        name: 'Generate PDF File',
        description: 'Converting to PDF format',
        explanation: 'System converts formatted content to final PDF with embedded fonts and optimized file size.',
        workers: [
          { role: 'PDF Generator', description: 'Generates PDF file' },
          { role: 'Font Embedder', description: 'Embeds required fonts' },
          { role: 'Compression Optimizer', description: 'Optimizes file size' },
          { role: 'Metadata Embedder', description: 'Embeds metadata' }
        ],
        verificationWorkers: [
          { role: 'PDF Validator', description: 'Validates PDF structure' },
          { role: 'Accessibility Checker', description: 'Checks PDF accessibility' }
        ],
        estimatedTime: 5,
        outputFiles: ['book.pdf', 'pdf_metadata.json']
      }
    ]
  },

  audio: {
    formatType: 'audio',
    name: 'Audio Book',
    icon: '🎧',
    overview: 'Converts master book to natural-sounding audio with multiple AI voices',
    steps: [
      {
        id: 'load_master',
        name: 'Load Master Book',
        description: 'Loading master book content',
        explanation: 'System loads the master book content for audio conversion.',
        workers: [
          { role: 'Content Loader', description: 'Loads master book' }
        ],
        estimatedTime: 1,
        outputFiles: ['master_loaded.json'],
        canRunParallel: false
      },
      {
        id: 'prepare_script',
        name: 'Prepare Narration Script',
        description: 'Adapting text for audio narration',
        explanation: 'Workers adapt written text for spoken narration, adding pronunciation guides, pacing notes, and emphasis markers.',
        workers: [
          { role: 'Script Adapter', description: 'Adapts text for narration' },
          { role: 'Pronunciation Guide Writer', description: 'Adds pronunciation guides' },
          { role: 'Pacing Specialist', description: 'Marks pacing and pauses' },
          { role: 'Emphasis Marker', description: 'Marks emphasis points' }
        ],
        verificationWorkers: [
          { role: 'Script Quality Check', description: 'Validates script quality' }
        ],
        estimatedTime: 8,
        outputFiles: ['narration_script.json', 'pronunciation_guide.json'],
        iterativeQuality: true,
        maxIterations: 10
      },
      {
        id: 'generate_audio',
        name: 'Generate Audio',
        description: 'Converting text to natural speech',
        explanation: 'AI generates natural-sounding narration using advanced text-to-speech models with proper intonation and pacing.',
        workers: [
          { role: 'TTS Generator', description: 'Generates speech audio' },
          { role: 'Voice Selector', description: 'Selects appropriate voice' },
          { role: 'Audio Quality Optimizer', description: 'Optimizes audio quality' },
          { role: 'Chapter Segmenter', description: 'Segments into chapters' }
        ],
        verificationWorkers: [
          { role: 'Audio Quality Check', description: 'Validates audio quality' },
          { role: 'Pronunciation Validator', description: 'Checks pronunciation' }
        ],
        estimatedTime: 20,
        outputFiles: ['audio_files/', 'audio_manifest.json'],
        iterativeQuality: true,
        maxIterations: 8
      },
      {
        id: 'add_music',
        name: 'Add Background Music',
        description: 'Adding subtle background music and effects',
        explanation: 'Workers add non-distracting background music and sound effects to enhance listening experience.',
        workers: [
          { role: 'Music Selector', description: 'Selects appropriate music' },
          { role: 'Audio Mixer', description: 'Mixes narration and music' },
          { role: 'Effect Integrator', description: 'Adds sound effects' },
          { role: 'Level Balancer', description: 'Balances audio levels' }
        ],
        verificationWorkers: [
          { role: 'Mix Quality Check', description: 'Validates audio mix' }
        ],
        estimatedTime: 6,
        outputFiles: ['mixed_audio_files/', 'mix_log.json'],
        iterativeQuality: true,
        maxIterations: 6
      },
      {
        id: 'create_audiobook',
        name: 'Create Final Audiobook',
        description: 'Compiling into final audiobook format',
        explanation: 'System compiles all audio into final audiobook with metadata, chapter markers, and proper encoding.',
        workers: [
          { role: 'Audiobook Compiler', description: 'Compiles final audiobook' },
          { role: 'Chapter Marker Creator', description: 'Adds chapter markers' },
          { role: 'Metadata Embedder', description: 'Embeds audiobook metadata' },
          { role: 'Format Converter', description: 'Converts to multiple formats' }
        ],
        verificationWorkers: [
          { role: 'Playback Validator', description: 'Tests playback quality' }
        ],
        estimatedTime: 4,
        outputFiles: ['audiobook.m4b', 'audiobook.mp3', 'audiobook_metadata.json']
      }
    ]
  },

  illustrated: {
    formatType: 'pdf',
    name: 'Illustrated Book',
    icon: '🎨',
    overview: 'Creates richly illustrated version with AI-generated images and professional layouts',
    steps: [
      {
        id: 'load_master',
        name: 'Load Master Book',
        description: 'Loading master book content',
        explanation: 'System loads the master book content for illustration.',
        workers: [
          { role: 'Content Loader', description: 'Loads master book' }
        ],
        estimatedTime: 1,
        outputFiles: ['master_loaded.json'],
        canRunParallel: false
      },
      {
        id: 'identify_illustrations',
        name: 'Identify Illustration Opportunities',
        description: 'Finding places for visual illustrations',
        explanation: 'Workers analyze content to identify optimal locations for illustrations that enhance understanding.',
        workers: [
          { role: 'Visual Opportunity Analyzer', description: 'Finds illustration needs' },
          { role: 'Concept Visualizer', description: 'Identifies visualizable concepts' },
          { role: 'Placement Optimizer', description: 'Determines optimal placement' }
        ],
        verificationWorkers: [
          { role: 'Coverage Validator', description: 'Ensures balanced illustration' }
        ],
        estimatedTime: 6,
        outputFiles: ['illustration_plan.json', 'placement_map.json'],
        iterativeQuality: true,
        maxIterations: 8
      },
      {
        id: 'generate_prompts',
        name: 'Create Image Generation Prompts',
        description: 'Writing detailed prompts for AI image generation',
        explanation: 'Workers write detailed, specific prompts for AI image generators ensuring consistency and quality.',
        workers: [
          { role: 'Prompt Engineer', description: 'Writes image generation prompts' },
          { role: 'Style Coordinator', description: 'Ensures consistent art style' },
          { role: 'Detail Specialist', description: 'Adds specific visual details' }
        ],
        verificationWorkers: [
          { role: 'Prompt Quality Check', description: 'Validates prompt clarity' }
        ],
        estimatedTime: 8,
        outputFiles: ['image_prompts.json', 'style_guide.json'],
        iterativeQuality: true,
        maxIterations: 10
      },
      {
        id: 'generate_images',
        name: 'Generate AI Images',
        description: 'Creating illustrations using multiple AI models',
        explanation: 'Multiple AI image generators create illustrations. Best results are selected through quality scoring.',
        workers: [
          { role: 'DALL-E Generator', description: 'Generates images using DALL-E' },
          { role: 'Midjourney Generator', description: 'Generates images using Midjourney' },
          { role: 'Stable Diffusion Generator', description: 'Generates images using Stable Diffusion' },
          { role: 'Image Selector', description: 'Selects best image for each spot' },
          { role: 'Image Enhancer', description: 'Enhances selected images' }
        ],
        verificationWorkers: [
          { role: 'Quality Validator', description: 'Validates image quality' },
          { role: 'Consistency Checker', description: 'Ensures style consistency' }
        ],
        estimatedTime: 25,
        outputFiles: ['illustrations/', 'image_metadata.json', 'selection_log.json'],
        iterativeQuality: true,
        maxIterations: 12
      },
      {
        id: 'design_layouts',
        name: 'Design Illustrated Layouts',
        description: 'Creating layouts integrating text and images',
        explanation: 'Workers design professional layouts that balance text and imagery for optimal visual impact.',
        workers: [
          { role: 'Layout Designer', description: 'Designs page layouts' },
          { role: 'Image Integrator', description: 'Integrates images with text' },
          { role: 'Typography Specialist', description: 'Handles text formatting' },
          { role: 'White Space Optimizer', description: 'Optimizes spacing' }
        ],
        verificationWorkers: [
          { role: 'Layout Quality Check', description: 'Validates layout quality' },
          { role: 'Print Readiness Check', description: 'Ensures print-ready' }
        ],
        estimatedTime: 12,
        outputFiles: ['layouts/', 'layout_specs.json'],
        iterativeQuality: true,
        maxIterations: 10
      },
      {
        id: 'create_illustrated_book',
        name: 'Compile Illustrated Book',
        description: 'Creating final illustrated book',
        explanation: 'System compiles all content and images into final illustrated book format.',
        workers: [
          { role: 'Book Compiler', description: 'Compiles final book' },
          { role: 'PDF Generator', description: 'Generates high-quality PDF' },
          { role: 'Metadata Embedder', description: 'Embeds metadata' }
        ],
        verificationWorkers: [
          { role: 'Final Quality Check', description: 'Final quality validation' }
        ],
        estimatedTime: 6,
        outputFiles: ['illustrated_book.pdf', 'book_metadata.json']
      }
    ]
  },

  interactive: {
    formatType: 'html',
    name: 'Interactive Book',
    icon: '💻',
    overview: 'Creates interactive web-based book with embedded exercises, quizzes, and multimedia',
    steps: [
      {
        id: 'load_master',
        name: 'Load Master Book',
        description: 'Loading master book content',
        explanation: 'System loads the master book content for interactive conversion.',
        workers: [
          { role: 'Content Loader', description: 'Loads master book' }
        ],
        estimatedTime: 1,
        outputFiles: ['master_loaded.json'],
        canRunParallel: false
      },
      {
        id: 'identify_interactions',
        name: 'Identify Interactive Opportunities',
        description: 'Finding places for interactive elements',
        explanation: 'Workers analyze content to identify opportunities for quizzes, exercises, simulations, and multimedia.',
        workers: [
          { role: 'Interaction Analyzer', description: 'Identifies interaction points' },
          { role: 'Quiz Opportunity Finder', description: 'Finds quiz opportunities' },
          { role: 'Exercise Designer', description: 'Plans interactive exercises' },
          { role: 'Multimedia Planner', description: 'Plans video/audio integration' }
        ],
        verificationWorkers: [
          { role: 'Coverage Validator', description: 'Ensures balanced interaction' }
        ],
        estimatedTime: 10,
        outputFiles: ['interaction_plan.json', 'element_map.json'],
        iterativeQuality: true,
        maxIterations: 10
      },
      {
        id: 'create_interactions',
        name: 'Create Interactive Elements',
        description: 'Building quizzes, exercises, and interactive content',
        explanation: 'Workers create all interactive elements including quizzes, drag-drop exercises, simulations, and more.',
        workers: [
          { role: 'Quiz Generator', description: 'Creates interactive quizzes' },
          { role: 'Exercise Builder', description: 'Builds interactive exercises' },
          { role: 'Simulation Developer', description: 'Creates simulations' },
          { role: 'Feedback Writer', description: 'Writes interactive feedback' },
          { role: 'Progress Tracker Builder', description: 'Creates progress tracking' }
        ],
        verificationWorkers: [
          { role: 'Interaction Quality Check', description: 'Tests all interactions' },
          { role: 'Answer Validation', description: 'Validates all answers' }
        ],
        estimatedTime: 20,
        outputFiles: ['interactive_elements/', 'quiz_database.json', 'exercises.json'],
        iterativeQuality: true,
        maxIterations: 15
      },
      {
        id: 'design_interface',
        name: 'Design Interactive Interface',
        description: 'Creating user interface and navigation',
        explanation: 'Workers design intuitive user interface with navigation, progress tracking, and accessibility features.',
        workers: [
          { role: 'UI Designer', description: 'Designs user interface' },
          { role: 'Navigation Builder', description: 'Creates navigation system' },
          { role: 'Progress Visualizer', description: 'Designs progress indicators' },
          { role: 'Accessibility Specialist', description: 'Ensures accessibility' }
        ],
        verificationWorkers: [
          { role: 'UX Validator', description: 'Validates user experience' },
          { role: 'Accessibility Check', description: 'Validates accessibility' }
        ],
        estimatedTime: 14,
        outputFiles: ['ui_components/', 'navigation_structure.json', 'styles.css'],
        iterativeQuality: true,
        maxIterations: 12
      },
      {
        id: 'integrate_multimedia',
        name: 'Integrate Multimedia',
        description: 'Adding videos, audio, and animations',
        explanation: 'Workers integrate videos, audio explanations, and animations throughout content.',
        workers: [
          { role: 'Video Integrator', description: 'Integrates video content' },
          { role: 'Audio Integrator', description: 'Integrates audio explanations' },
          { role: 'Animation Creator', description: 'Creates animations' },
          { role: 'Media Optimizer', description: 'Optimizes media loading' }
        ],
        verificationWorkers: [
          { role: 'Media Quality Check', description: 'Validates media quality' },
          { role: 'Performance Validator', description: 'Checks load performance' }
        ],
        estimatedTime: 12,
        outputFiles: ['media/', 'media_manifest.json', 'optimization_log.json'],
        iterativeQuality: true,
        maxIterations: 8
      },
      {
        id: 'build_web_app',
        name: 'Build Interactive Web App',
        description: 'Compiling into responsive web application',
        explanation: 'System compiles all elements into responsive, progressive web app that works offline.',
        workers: [
          { role: 'Web App Builder', description: 'Builds web application' },
          { role: 'Responsive Designer', description: 'Ensures mobile responsiveness' },
          { role: 'Offline Enabler', description: 'Adds offline functionality' },
          { role: 'Performance Optimizer', description: 'Optimizes performance' }
        ],
        verificationWorkers: [
          { role: 'Cross-Browser Validator', description: 'Tests across browsers' },
          { role: 'Mobile Validator', description: 'Tests on mobile devices' },
          { role: 'Performance Validator', description: 'Validates performance' }
        ],
        estimatedTime: 10,
        outputFiles: ['interactive_book/', 'manifest.json', 'service_worker.js'],
        iterativeQuality: true,
        maxIterations: 10
      }
    ]
  }
};
