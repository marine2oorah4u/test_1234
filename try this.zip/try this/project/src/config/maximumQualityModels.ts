export type CloudProvider = 'openai' | 'google' | 'anthropic' | 'deepseek' | 'perplexity' | 'mistral' | 'cohere' | 'groq';
export type TaskPhase = 'research' | 'generation' | 'verification' | 'refinement' | 'polish';
export type LoadBalanceStrategy = 'round-robin' | 'least-used' | 'fastest' | 'quality-based' | 'cost-optimized';

export interface AIModelConfig {
  id: string;
  name: string;
  provider: CloudProvider;
  apiEndpoint?: string;
  maxTokens: number;
  maxRPM: number;
  maxTPM: number;
  currentUsage: {
    tokens: number;
    requests: number;
    lastReset: Date;
  };
  quality: {
    accuracy: number;
    creativity: number;
    reasoning: number;
    consistency: number;
  };
  speed: {
    avgLatency: number;
    tokensPerSecond: number;
  };
  cost: {
    inputPer1M: number;
    outputPer1M: number;
  };
  strengths: string[];
  enabled: boolean;
  priority: number;
}

export interface PhaseConfig {
  phase: TaskPhase;
  description: string;
  minAIs: number;
  optimalAIs: number;
  maxAIs: number;
  consensusThreshold: number;
  primaryModels: string[];
  backupModels: string[];
  loadBalanceStrategy: LoadBalanceStrategy;
  qualityThreshold: number;
  maxRetries: number;
}

export interface CloudLocation {
  id: string;
  provider: string;
  region: string;
  endpoint: string;
  enabled: boolean;
  capacity: {
    maxConcurrent: number;
    currentLoad: number;
  };
  quotas: {
    tokensPerDay: number;
    tokensUsed: number;
    requestsPerMinute: number;
    requestsUsed: number;
  };
  priority: number;
  latency: number;
}

export const AI_MODELS: Record<string, AIModelConfig> = {
  'o4-mini-deep-research': {
    id: 'o4-mini-deep-research',
    name: 'o4-mini Deep Research',
    provider: 'openai',
    maxTokens: 128000,
    maxRPM: 10000,
    maxTPM: 2000000,
    currentUsage: { tokens: 0, requests: 0, lastReset: new Date() },
    quality: { accuracy: 98, creativity: 75, reasoning: 99, consistency: 97 },
    speed: { avgLatency: 3500, tokensPerSecond: 85 },
    cost: { inputPer1M: 3.5, outputPer1M: 14.0 },
    strengths: ['Deep research', 'Complex reasoning', 'Fact verification'],
    enabled: true,
    priority: 1,
  },
  'gpt-5.1': {
    id: 'gpt-5.1',
    name: 'GPT-5.1',
    provider: 'openai',
    maxTokens: 256000,
    maxRPM: 10000,
    maxTPM: 5000000,
    currentUsage: { tokens: 0, requests: 0, lastReset: new Date() },
    quality: { accuracy: 95, creativity: 92, reasoning: 94, consistency: 96 },
    speed: { avgLatency: 2000, tokensPerSecond: 150 },
    cost: { inputPer1M: 5.0, outputPer1M: 15.0 },
    strengths: ['Balanced quality', 'Fast generation', 'General purpose'],
    enabled: true,
    priority: 1,
  },
  'gpt-5-pro': {
    id: 'gpt-5-pro',
    name: 'GPT-5 Pro',
    provider: 'openai',
    maxTokens: 512000,
    maxRPM: 5000,
    maxTPM: 2000000,
    currentUsage: { tokens: 0, requests: 0, lastReset: new Date() },
    quality: { accuracy: 98, creativity: 96, reasoning: 97, consistency: 98 },
    speed: { avgLatency: 4000, tokensPerSecond: 100 },
    cost: { inputPer1M: 15.0, outputPer1M: 45.0 },
    strengths: ['Premium quality', 'Complex topics', 'PhD-level content'],
    enabled: true,
    priority: 1,
  },
  'gpt-5-mini': {
    id: 'gpt-5-mini',
    name: 'GPT-5-mini',
    provider: 'openai',
    maxTokens: 128000,
    maxRPM: 30000,
    maxTPM: 10000000,
    currentUsage: { tokens: 0, requests: 0, lastReset: new Date() },
    quality: { accuracy: 90, creativity: 85, reasoning: 88, consistency: 92 },
    speed: { avgLatency: 800, tokensPerSecond: 250 },
    cost: { inputPer1M: 0.5, outputPer1M: 1.5 },
    strengths: ['Very fast', 'High volume', 'Quick verification'],
    enabled: true,
    priority: 2,
  },
  'claude-3.5-sonnet': {
    id: 'claude-3.5-sonnet',
    name: 'Claude 3.5 Sonnet',
    provider: 'anthropic',
    maxTokens: 200000,
    maxRPM: 5000,
    maxTPM: 2000000,
    currentUsage: { tokens: 0, requests: 0, lastReset: new Date() },
    quality: { accuracy: 97, creativity: 90, reasoning: 98, consistency: 99 },
    speed: { avgLatency: 2500, tokensPerSecond: 120 },
    cost: { inputPer1M: 3.0, outputPer1M: 15.0 },
    strengths: ['Structured content', 'Academic writing', 'Instruction following'],
    enabled: true,
    priority: 1,
  },
  'gemini-pro-1.5': {
    id: 'gemini-pro-1.5',
    name: 'Gemini Pro 1.5',
    provider: 'google',
    maxTokens: 1000000,
    maxRPM: 10000,
    maxTPM: 5000000,
    currentUsage: { tokens: 0, requests: 0, lastReset: new Date() },
    quality: { accuracy: 96, creativity: 85, reasoning: 93, consistency: 95 },
    speed: { avgLatency: 2200, tokensPerSecond: 140 },
    cost: { inputPer1M: 3.5, outputPer1M: 10.5 },
    strengths: ['STEM subjects', 'Factual accuracy', 'Large context'],
    enabled: true,
    priority: 1,
  },
  'gemini-flash': {
    id: 'gemini-flash',
    name: 'Gemini Flash',
    provider: 'google',
    maxTokens: 1000000,
    maxRPM: 15000,
    maxTPM: 8000000,
    currentUsage: { tokens: 0, requests: 0, lastReset: new Date() },
    quality: { accuracy: 93, creativity: 82, reasoning: 90, consistency: 92 },
    speed: { avgLatency: 1200, tokensPerSecond: 200 },
    cost: { inputPer1M: 0.35, outputPer1M: 1.05 },
    strengths: ['Very fast', 'Fact checking', 'Cost effective'],
    enabled: true,
    priority: 2,
  },
  'deepseek-v3': {
    id: 'deepseek-v3',
    name: 'DeepSeek-V3',
    provider: 'deepseek',
    maxTokens: 128000,
    maxRPM: 10000,
    maxTPM: 4000000,
    currentUsage: { tokens: 0, requests: 0, lastReset: new Date() },
    quality: { accuracy: 95, creativity: 88, reasoning: 97, consistency: 94 },
    speed: { avgLatency: 1800, tokensPerSecond: 160 },
    cost: { inputPer1M: 0.27, outputPer1M: 1.10 },
    strengths: ['Logic verification', 'STEM reasoning', 'Math accuracy'],
    enabled: true,
    priority: 1,
  },
  'perplexity-pro': {
    id: 'perplexity-pro',
    name: 'Perplexity Pro',
    provider: 'perplexity',
    maxTokens: 128000,
    maxRPM: 5000,
    maxTPM: 1000000,
    currentUsage: { tokens: 0, requests: 0, lastReset: new Date() },
    quality: { accuracy: 97, creativity: 80, reasoning: 92, consistency: 90 },
    speed: { avgLatency: 3000, tokensPerSecond: 100 },
    cost: { inputPer1M: 5.0, outputPer1M: 5.0 },
    strengths: ['Real-time search', 'Current information', 'Citation-backed'],
    enabled: true,
    priority: 1,
  },
  'mistral-large': {
    id: 'mistral-large',
    name: 'Mistral Large',
    provider: 'mistral',
    maxTokens: 128000,
    maxRPM: 10000,
    maxTPM: 3000000,
    currentUsage: { tokens: 0, requests: 0, lastReset: new Date() },
    quality: { accuracy: 93, creativity: 87, reasoning: 91, consistency: 90 },
    speed: { avgLatency: 2000, tokensPerSecond: 130 },
    cost: { inputPer1M: 2.0, outputPer1M: 6.0 },
    strengths: ['Multilingual', 'European languages', 'Cost effective'],
    enabled: true,
    priority: 2,
  },
  'cohere-command-r-plus': {
    id: 'cohere-command-r-plus',
    name: 'Cohere Command R+',
    provider: 'cohere',
    maxTokens: 128000,
    maxRPM: 10000,
    maxTPM: 3000000,
    currentUsage: { tokens: 0, requests: 0, lastReset: new Date() },
    quality: { accuracy: 92, creativity: 86, reasoning: 90, consistency: 89 },
    speed: { avgLatency: 2200, tokensPerSecond: 125 },
    cost: { inputPer1M: 3.0, outputPer1M: 15.0 },
    strengths: ['RAG capabilities', 'Document understanding', 'Citations'],
    enabled: true,
    priority: 2,
  },
  'llama-3.3-70b': {
    id: 'llama-3.3-70b',
    name: 'Llama 3.3 70B',
    provider: 'groq',
    maxTokens: 32000,
    maxRPM: 30000,
    maxTPM: 14400000,
    currentUsage: { tokens: 0, requests: 0, lastReset: new Date() },
    quality: { accuracy: 90, creativity: 85, reasoning: 88, consistency: 87 },
    speed: { avgLatency: 600, tokensPerSecond: 300 },
    cost: { inputPer1M: 0.59, outputPer1M: 0.79 },
    strengths: ['Ultra fast', 'Open source', 'Alternative perspective'],
    enabled: true,
    priority: 3,
  },
};

export const MAXIMUM_QUALITY_PHASES: Record<TaskPhase, PhaseConfig> = {
  research: {
    phase: 'research',
    description: 'Deep research using multiple AI perspectives',
    minAIs: 3,
    optimalAIs: 7,
    maxAIs: 10,
    consensusThreshold: 0.80,
    primaryModels: [
      'o4-mini-deep-research',
      'perplexity-pro',
      'gemini-pro-1.5',
      'deepseek-v3',
      'gpt-5.1',
      'claude-3.5-sonnet',
      'gemini-flash',
    ],
    backupModels: [
      'mistral-large',
      'cohere-command-r-plus',
      'gpt-5-mini',
    ],
    loadBalanceStrategy: 'quality-based',
    qualityThreshold: 0.90,
    maxRetries: 3,
  },
  generation: {
    phase: 'generation',
    description: 'Multiple AIs write independently, merge best parts',
    minAIs: 3,
    optimalAIs: 5,
    maxAIs: 10,
    consensusThreshold: 0.75,
    primaryModels: [
      'gpt-5.1',
      'gpt-5-pro',
      'claude-3.5-sonnet',
      'gemini-pro-1.5',
      'deepseek-v3',
    ],
    backupModels: [
      'gpt-5-mini',
      'mistral-large',
      'llama-3.3-70b',
      'cohere-command-r-plus',
    ],
    loadBalanceStrategy: 'quality-based',
    qualityThreshold: 0.90,
    maxRetries: 3,
  },
  verification: {
    phase: 'verification',
    description: 'Multi-perspective verification for accuracy and quality',
    minAIs: 5,
    optimalAIs: 12,
    maxAIs: 15,
    consensusThreshold: 0.90,
    primaryModels: [
      'o4-mini-deep-research',
      'claude-3.5-sonnet',
      'deepseek-v3',
      'gemini-pro-1.5',
      'gpt-5.1',
      'gemini-flash',
      'perplexity-pro',
      'gpt-5-mini',
    ],
    backupModels: [
      'mistral-large',
      'cohere-command-r-plus',
      'llama-3.3-70b',
    ],
    loadBalanceStrategy: 'fastest',
    qualityThreshold: 0.95,
    maxRetries: 2,
  },
  refinement: {
    phase: 'refinement',
    description: 'Iterative improvements based on verification feedback',
    minAIs: 3,
    optimalAIs: 5,
    maxAIs: 7,
    consensusThreshold: 0.80,
    primaryModels: [
      'gpt-5-pro',
      'claude-3.5-sonnet',
      'gpt-5.1',
    ],
    backupModels: [
      'gemini-pro-1.5',
      'deepseek-v3',
      'mistral-large',
    ],
    loadBalanceStrategy: 'quality-based',
    qualityThreshold: 0.95,
    maxRetries: 3,
  },
  polish: {
    phase: 'polish',
    description: 'Final readability and engagement polish',
    minAIs: 3,
    optimalAIs: 3,
    maxAIs: 5,
    consensusThreshold: 0.85,
    primaryModels: [
      'gpt-5-pro',
      'claude-3.5-sonnet',
      'gemini-pro-1.5',
    ],
    backupModels: [
      'gpt-5.1',
      'mistral-large',
    ],
    loadBalanceStrategy: 'quality-based',
    qualityThreshold: 0.95,
    maxRetries: 2,
  },
};

export const CLOUD_LOCATIONS: CloudLocation[] = [
  {
    id: 'openai-us-east',
    provider: 'openai',
    region: 'us-east-1',
    endpoint: 'https://api.openai.com/v1',
    enabled: true,
    capacity: { maxConcurrent: 100, currentLoad: 0 },
    quotas: {
      tokensPerDay: 10000000,
      tokensUsed: 0,
      requestsPerMinute: 10000,
      requestsUsed: 0,
    },
    priority: 1,
    latency: 50,
  },
  {
    id: 'openai-eu-west',
    provider: 'openai',
    region: 'eu-west-1',
    endpoint: 'https://api.openai.com/v1',
    enabled: true,
    capacity: { maxConcurrent: 100, currentLoad: 0 },
    quotas: {
      tokensPerDay: 10000000,
      tokensUsed: 0,
      requestsPerMinute: 10000,
      requestsUsed: 0,
    },
    priority: 2,
    latency: 120,
  },
  {
    id: 'google-us-central',
    provider: 'google',
    region: 'us-central1',
    endpoint: 'https://generativelanguage.googleapis.com/v1',
    enabled: true,
    capacity: { maxConcurrent: 150, currentLoad: 0 },
    quotas: {
      tokensPerDay: 15000000,
      tokensUsed: 0,
      requestsPerMinute: 15000,
      requestsUsed: 0,
    },
    priority: 1,
    latency: 45,
  },
  {
    id: 'anthropic-us-east',
    provider: 'anthropic',
    region: 'us-east-1',
    endpoint: 'https://api.anthropic.com/v1',
    enabled: true,
    capacity: { maxConcurrent: 80, currentLoad: 0 },
    quotas: {
      tokensPerDay: 8000000,
      tokensUsed: 0,
      requestsPerMinute: 5000,
      requestsUsed: 0,
    },
    priority: 1,
    latency: 55,
  },
  {
    id: 'deepseek-asia',
    provider: 'deepseek',
    region: 'asia-east1',
    endpoint: 'https://api.deepseek.com/v1',
    enabled: true,
    capacity: { maxConcurrent: 120, currentLoad: 0 },
    quotas: {
      tokensPerDay: 12000000,
      tokensUsed: 0,
      requestsPerMinute: 10000,
      requestsUsed: 0,
    },
    priority: 1,
    latency: 180,
  },
];

export interface RoutingDecision {
  modelId: string;
  location: string;
  reason: string;
  estimatedCost: number;
  estimatedTime: number;
}

export class IntelligentModelRouter {
  private models: Record<string, AIModelConfig>;
  private locations: CloudLocation[];
  private usageHistory: Map<string, number[]> = new Map();

  constructor() {
    this.models = { ...AI_MODELS };
    this.locations = [...CLOUD_LOCATIONS];
  }

  selectModels(phase: PhaseConfig, numModels?: number): RoutingDecision[] {
    const targetCount = numModels || phase.optimalAIs;
    const availableModels = [...phase.primaryModels, ...phase.backupModels];
    const decisions: RoutingDecision[] = [];

    for (let i = 0; i < targetCount && i < availableModels.length; i++) {
      const modelId = availableModels[i];
      const model = this.models[modelId];

      if (!model || !model.enabled) continue;

      const location = this.selectLocation(model.provider);
      if (!location) continue;

      if (this.checkQuota(model, location)) {
        decisions.push({
          modelId,
          location: location.id,
          reason: this.getSelectionReason(model, phase, i < phase.primaryModels.length),
          estimatedCost: this.estimateCost(model, 50000),
          estimatedTime: model.speed.avgLatency + location.latency,
        });
      }
    }

    return decisions;
  }

  private selectLocation(provider: CloudProvider): CloudLocation | null {
    const providerLocations = this.locations
      .filter(loc => loc.enabled && loc.provider === provider)
      .sort((a, b) => {
        const aLoad = a.capacity.currentLoad / a.capacity.maxConcurrent;
        const bLoad = b.capacity.currentLoad / b.capacity.maxConcurrent;
        const aQuota = a.quotas.tokensUsed / a.quotas.tokensPerDay;
        const bQuota = b.quotas.tokensUsed / b.quotas.tokensPerDay;

        return (aLoad + aQuota) - (bLoad + bQuota);
      });

    return providerLocations[0] || null;
  }

  private checkQuota(model: AIModelConfig, location: CloudLocation): boolean {
    const tokenQuotaRemaining = location.quotas.tokensPerDay - location.quotas.tokensUsed;
    const rpmQuotaRemaining = location.quotas.requestsPerMinute - location.quotas.requestsUsed;

    return tokenQuotaRemaining > 50000 && rpmQuotaRemaining > 0;
  }

  private getSelectionReason(model: AIModelConfig, phase: PhaseConfig, isPrimary: boolean): string {
    if (!isPrimary) return 'Backup model selected due to primary unavailable';

    const topStrength = model.strengths[0];
    return `Selected for ${phase.phase}: ${topStrength}`;
  }

  private estimateCost(model: AIModelConfig, estimatedTokens: number): number {
    const inputTokens = estimatedTokens * 0.3;
    const outputTokens = estimatedTokens * 0.7;

    return (
      (inputTokens / 1000000) * model.cost.inputPer1M +
      (outputTokens / 1000000) * model.cost.outputPer1M
    );
  }

  recordUsage(modelId: string, tokens: number, location: string) {
    const model = this.models[modelId];
    if (model) {
      model.currentUsage.tokens += tokens;
      model.currentUsage.requests += 1;
    }

    const loc = this.locations.find(l => l.id === location);
    if (loc) {
      loc.quotas.tokensUsed += tokens;
      loc.quotas.requestsUsed += 1;
    }

    if (!this.usageHistory.has(modelId)) {
      this.usageHistory.set(modelId, []);
    }
    this.usageHistory.get(modelId)!.push(tokens);
  }

  getLoadBalancingStatus() {
    return {
      models: Object.values(this.models).map(m => ({
        id: m.id,
        usage: m.currentUsage,
        health: this.checkQuota(m, this.locations[0]) ? 'healthy' : 'limited',
      })),
      locations: this.locations.map(l => ({
        id: l.id,
        load: (l.capacity.currentLoad / l.capacity.maxConcurrent) * 100,
        quotaUsed: (l.quotas.tokensUsed / l.quotas.tokensPerDay) * 100,
      })),
    };
  }

  resetDailyQuotas() {
    this.locations.forEach(loc => {
      loc.quotas.tokensUsed = 0;
      loc.quotas.requestsUsed = 0;
    });

    Object.values(this.models).forEach(model => {
      model.currentUsage = { tokens: 0, requests: 0, lastReset: new Date() };
    });
  }
}

export const modelRouter = new IntelligentModelRouter();
