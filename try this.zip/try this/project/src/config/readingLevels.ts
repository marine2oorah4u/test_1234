import { ReadingLevel } from '../lib/database.types';

export interface ReadingLevelConfig {
  id: ReadingLevel;
  name: string;
  ageRange: string;
  description: string;
  fontSize: string;
  wordsPerPage: string;
  features: string[];
  visualDensity: 'very_high' | 'high' | 'medium' | 'low';
  illustrationFrequency: string;
  colorfulPages: boolean;
  designStyle: string;
  careerGuideAvailable: boolean;
  honorsAvailable: boolean;
  textbookAvailable: boolean;
}

export const READING_LEVELS: Record<ReadingLevel, ReadingLevelConfig> = {
  kindergarten: {
    id: 'kindergarten',
    name: 'Kindergarten',
    ageRange: '5-6 years',
    description: 'Early learning with colorful, engaging content designed for young children',
    fontSize: '24-28pt',
    wordsPerPage: '50-100',
    features: [
      'Large, clear fonts for easy reading',
      'Colorful themed pages (jungle, space, ocean, nature)',
      'Real stock photos and engaging illustrations',
      'Interactive elements and activities',
      'Rhythm, rhymes, and storytelling',
      'Safety notes with icon symbols',
      'Simple vocabulary',
      'Page backgrounds, patterns, and borders'
    ],
    visualDensity: 'very_high',
    illustrationFrequency: 'Every page',
    colorfulPages: true,
    designStyle: 'Playful and vibrant with themed backgrounds',
    careerGuideAvailable: false,
    honorsAvailable: true,
    textbookAvailable: false
  },
  elementary: {
    id: 'elementary',
    name: 'Elementary',
    ageRange: '7-11 years',
    description: 'Foundational education with visuals and interactive elements to maintain engagement',
    fontSize: '16-18pt',
    wordsPerPage: '200-400',
    features: [
      'Medium-large font for readability',
      'Visuals every 1-2 pages',
      'Colored text boxes for activities',
      'Fun facts with icons in sidebars',
      'Themed sections with color schemes',
      'Stock photos and simple diagrams',
      'Age-appropriate vocabulary',
      'Interactive questions'
    ],
    visualDensity: 'high',
    illustrationFrequency: 'Every 1-2 pages',
    colorfulPages: true,
    designStyle: 'Friendly and educational with colorful accents',
    careerGuideAvailable: false,
    honorsAvailable: true,
    textbookAvailable: false
  },
  middle_school: {
    id: 'middle_school',
    name: 'Middle School',
    ageRange: '12-14 years',
    description: 'Intermediate content with diagrams, infographics, and career introductions',
    fontSize: '14pt',
    wordsPerPage: '400-600',
    features: [
      'Standard readable font',
      'Diagrams, charts, and photos every 1-2 pages',
      'Infographics for complex concepts',
      'Colored section headers and dividers',
      'Career mentions (1 paragraph per chapter)',
      'Vocabulary lists with icons',
      'Reflection questions (2-3 per chapter)',
      'Real-world connections'
    ],
    visualDensity: 'medium',
    illustrationFrequency: 'Every 1-2 pages',
    colorfulPages: false,
    designStyle: 'Professional with structured layouts',
    careerGuideAvailable: true,
    honorsAvailable: true,
    textbookAvailable: true
  },
  high_school: {
    id: 'high_school',
    name: 'High School',
    ageRange: '15-18 years',
    description: 'Advanced secondary education with comprehensive analysis and career applications',
    fontSize: '12pt',
    wordsPerPage: '600-800',
    features: [
      'Standard academic font',
      'Data graphs, tables, and detailed diagrams',
      'Case studies integrated into content',
      'Career connections per chapter',
      'Real-world applications',
      'Chapter review questions',
      'Critical thinking exercises',
      'Professional formatting'
    ],
    visualDensity: 'medium',
    illustrationFrequency: 'Every 2-3 pages',
    colorfulPages: false,
    designStyle: 'Academic with professional appearance',
    careerGuideAvailable: true,
    honorsAvailable: true,
    textbookAvailable: true
  },
  bachelors: {
    id: 'bachelors',
    name: 'Bachelors (College)',
    ageRange: 'Undergraduate',
    description: 'University-level content with academic rigor and comprehensive coverage',
    fontSize: '11-12pt',
    wordsPerPage: '800-1200',
    features: [
      'Academic font style',
      'Dense data: graphs, charts, tables, statistical analysis',
      'Basic academic citations',
      'Problem sets and critical thinking questions',
      'Career applications',
      'Research methodologies introduction',
      'Case studies and analysis',
      'Professional references'
    ],
    visualDensity: 'low',
    illustrationFrequency: 'As needed for data',
    colorfulPages: false,
    designStyle: 'Academic textbook style',
    careerGuideAvailable: true,
    honorsAvailable: true,
    textbookAvailable: true
  },
  masters: {
    id: 'masters',
    name: 'Masters (Graduate)',
    ageRange: 'Graduate',
    description: 'Graduate-level theoretical and research-focused content with advanced methodologies',
    fontSize: '11pt',
    wordsPerPage: '1000-1500',
    features: [
      'Compact academic style',
      'Heavy research data and complex graphs',
      'Full academic citations',
      'Theory-heavy content',
      'Research methodologies',
      'Literature reviews',
      'Advanced problem sets',
      'Comparative analysis'
    ],
    visualDensity: 'low',
    illustrationFrequency: 'Data-driven only',
    colorfulPages: false,
    designStyle: 'Dense academic research style',
    careerGuideAvailable: false,
    honorsAvailable: true,
    textbookAvailable: true
  },
  phd: {
    id: 'phd',
    name: 'PhD (Research)',
    ageRange: 'Doctoral/Expert',
    description: 'Expert-level research content with original analysis and comprehensive citations',
    fontSize: '10-11pt',
    wordsPerPage: '1200-2000',
    features: [
      'Journal publication style',
      'Extensive data visualization',
      'Full citation apparatus',
      'Original research integration',
      'Theoretical frameworks',
      'Methodological discussions',
      'Research-level depth',
      'Peer-review quality'
    ],
    visualDensity: 'low',
    illustrationFrequency: 'Research data only',
    colorfulPages: false,
    designStyle: 'Academic journal style',
    careerGuideAvailable: false,
    honorsAvailable: true,
    textbookAvailable: true
  },
  library: {
    id: 'library',
    name: 'Library/Reference',
    ageRange: 'All levels',
    description: 'Comprehensive encyclopedia-style coverage with exhaustive detail and references',
    fontSize: '10pt',
    wordsPerPage: 'Dense (400-800+ pages)',
    features: [
      'Exhaustive subject coverage',
      'Academic references throughout',
      'Complete index and glossary',
      'Bibliography and cross-references',
      'Historical timeline',
      'Basic to advanced coverage',
      'Multiple perspectives',
      'Professional reference quality'
    ],
    visualDensity: 'low',
    illustrationFrequency: 'As needed',
    colorfulPages: false,
    designStyle: 'Encyclopedia reference style',
    careerGuideAvailable: false,
    honorsAvailable: false,
    textbookAvailable: false
  }
};

export const TEXTBOOK_GRADES: ReadingLevel[] = [
  'middle_school',
  'high_school',
  'bachelors',
  'masters',
  'phd'
];

export const CAREER_GUIDE_LEVELS: ReadingLevel[] = [
  'middle_school',
  'high_school',
  'bachelors'
];

export const ALL_READING_LEVELS: ReadingLevel[] = [
  'kindergarten',
  'elementary',
  'middle_school',
  'high_school',
  'bachelors',
  'masters',
  'phd',
  'library'
];

export function getReadingLevelConfig(level: ReadingLevel): ReadingLevelConfig {
  return READING_LEVELS[level];
}

export function supportsTextbookEdition(level: ReadingLevel): boolean {
  return TEXTBOOK_GRADES.includes(level);
}

export function supportsCareerGuide(level: ReadingLevel): boolean {
  return CAREER_GUIDE_LEVELS.includes(level);
}

export function supportsHonorsEdition(level: ReadingLevel): boolean {
  return level !== 'library';
}
