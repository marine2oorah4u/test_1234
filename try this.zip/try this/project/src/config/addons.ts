import { AddonType, ReadingLevel } from '../lib/database.types';

export interface AddonConfig {
  id: AddonType;
  name: string;
  description: string;
  icon: string;
  features: string[];
  estimatedPages: string;
  availableFor: ReadingLevel[];
}

export const ADDON_TYPES: Record<AddonType, AddonConfig> = {
  activity_pack: {
    id: 'activity_pack',
    name: 'Activity Pack',
    description: 'Comprehensive hands-on activities with complete educator support materials',
    icon: '🎯',
    features: [
      'Hands-on activities for each chapter',
      'Clear learning objectives per activity',
      'Educational standards alignment',
      'Complete step-by-step instructions',
      'Time estimates for each activity',
      'Detailed materials lists',
      'Troubleshooting tips and common mistakes',
      'Safety guidelines where applicable',
      'Assessment rubrics and success criteria',
      'Tiered differentiation (beginner/intermediate/advanced)',
      'In-activity variations for diverse learners',
      'Accessibility accommodations',
      'Cross-references to book chapters',
      'Materials sourcing guide (separate document)',
      'Parent communication templates (separate document)',
      'Extension activities for advanced learners',
      'Pilot-tested and refined',
      'Professional visuals and diagrams'
    ],
    estimatedPages: '40-80 pages + educator packet',
    availableFor: ['kindergarten', 'elementary', 'middle_school', 'high_school', 'bachelors', 'masters', 'phd', 'library']
  },
  worksheet_set: {
    id: 'worksheet_set',
    name: 'Worksheet Set',
    description: 'Practice worksheets with exercises organized by chapter',
    icon: '📝',
    features: [
      'Practice problems for each chapter',
      'Fill-in-the-blank exercises',
      'Matching activities',
      'Short answer questions',
      'Organized by difficulty',
      'Printable PDF format',
      'Answer key section included'
    ],
    estimatedPages: '30-50 pages',
    availableFor: ['kindergarten', 'elementary', 'middle_school', 'high_school', 'bachelors', 'masters', 'phd', 'library']
  },
  quiz_pack: {
    id: 'quiz_pack',
    name: 'Quiz Pack',
    description: 'Assessment quizzes for each chapter with answer keys',
    icon: '✅',
    features: [
      'Multiple choice questions',
      'True/false questions',
      'Short answer prompts',
      '10-20 questions per chapter',
      'Difficulty matches reading level',
      'Complete answer key',
      'Scoring rubrics included',
      'Time estimates provided'
    ],
    estimatedPages: '25-40 pages',
    availableFor: ['kindergarten', 'elementary', 'middle_school', 'high_school', 'bachelors', 'masters', 'phd', 'library']
  },
  answer_key: {
    id: 'answer_key',
    name: 'Answer Key',
    description: 'Complete solutions for all problems and exercises',
    icon: '🔑',
    features: [
      'Complete solutions for all problems',
      'Step-by-step explanations',
      'Organized by chapter and section',
      'Teacher-focused format',
      'Detailed working shown',
      'Alternative solution methods',
      'Common mistake warnings'
    ],
    estimatedPages: '20-60 pages',
    availableFor: ['kindergarten', 'elementary', 'middle_school', 'high_school', 'bachelors', 'masters', 'phd', 'library']
  },
  lesson_plans: {
    id: 'lesson_plans',
    name: 'Lesson Plans',
    description: 'Structured lesson plans for teachers and educators',
    icon: '📚',
    features: [
      'Detailed lesson objectives',
      'Materials needed lists',
      'Time estimates for activities',
      'Teaching strategies and tips',
      'Discussion questions',
      'Assessment methods',
      'Differentiation suggestions',
      'Extension activities'
    ],
    estimatedPages: '40-80 pages',
    availableFor: ['kindergarten', 'elementary', 'middle_school', 'high_school', 'bachelors', 'masters', 'phd', 'library']
  },
  presentation_slides: {
    id: 'presentation_slides',
    name: 'Presentation Slides',
    description: 'PowerPoint-style slides covering key concepts',
    icon: '📊',
    features: [
      'Key concepts from each chapter',
      'Visual aids and diagrams',
      'Summary points',
      'Discussion prompts',
      'Exportable graphics',
      'Speaker notes included',
      'Customizable templates',
      'Professional design'
    ],
    estimatedPages: '50-100 slides',
    availableFor: ['kindergarten', 'elementary', 'middle_school', 'high_school', 'bachelors', 'masters', 'phd', 'library']
  },
  career_guide: {
    id: 'career_guide',
    name: 'Career Guide',
    description: 'Career paths, skills, and opportunities related to the subject',
    icon: '💼',
    features: [
      'Career paths related to subject',
      'Required skills and education',
      'Salary ranges and job outlook',
      'Professional interviews and profiles',
      'Steps to enter the field',
      'Certification requirements',
      'Industry trends and future outlook',
      'Resources for further exploration'
    ],
    estimatedPages: '15-30 pages',
    availableFor: ['middle_school', 'high_school', 'bachelors']
  },
  study_guide: {
    id: 'study_guide',
    name: 'Study Guide',
    description: 'Comprehensive study materials with summaries and review questions',
    icon: '📖',
    features: [
      'Chapter summaries',
      'Key terms and definitions',
      'Review questions',
      'Concept maps',
      'Study tips and strategies',
      'Memory aids and mnemonics',
      'Practice test preparation',
      'Quick reference guides'
    ],
    estimatedPages: '30-60 pages',
    availableFor: ['kindergarten', 'elementary', 'middle_school', 'high_school', 'bachelors', 'masters', 'phd', 'library']
  }
};

export const ALL_ADDON_TYPES: AddonType[] = [
  'activity_pack',
  'worksheet_set',
  'quiz_pack',
  'answer_key',
  'lesson_plans',
  'presentation_slides',
  'career_guide',
  'study_guide'
];

export function getAddonConfig(type: AddonType): AddonConfig {
  return ADDON_TYPES[type];
}

export function getAddonsForReadingLevel(level: ReadingLevel): AddonType[] {
  return ALL_ADDON_TYPES.filter(addonType =>
    ADDON_TYPES[addonType].availableFor.includes(level)
  );
}

export function isAddonAvailableForLevel(addon: AddonType, level: ReadingLevel): boolean {
  return ADDON_TYPES[addon].availableFor.includes(level);
}

export function getTotalAddonsCount(level: ReadingLevel): number {
  return getAddonsForReadingLevel(level).length;
}
