/**
 * SPECIALIZED WORKFLOWS BY CATEGORY
 *
 * This file contains specialized workflows for the 5 active book categories:
 * - 5 Master Book Workflows (one per active category)
 * - 40 Addon Workflows (8 addons × 5 categories)
 *
 * REMOVED CATEGORIES:
 * - Category 1 (General Reading) - Not feasible due to copyright
 * - Category 7 (Sensory Support) - Merged into disability adaptations
 * - Category 8 (AAC Communication) - Merged into disability adaptations
 *
 * ACTIVE CATEGORIES:
 * 1. Educational Textbooks (K-12) - MAIN PRIORITY
 * 2. Life Skills & Transition (14-22)
 * 3. Early Intervention (0-5)
 * 4. Social Skills Curriculum
 * 5. Executive Function
 *
 * Each workflow is category-specific with specialized:
 * - AI expert personas
 * - Research focus areas
 * - Quality metrics
 * - Content structure requirements
 * - Disability adaptation integration points
 */

import { WorkflowStep, WorkflowWorker } from './bookWorkflows';

// =============================================================================
// ACTIVE CATEGORY WORKFLOWS
// =============================================================================

/**
 * REMOVED: Category 1 - General Reading Library
 * Reason: Not feasible due to copyright limitations on existing books
 * Focus: Educational content only (textbooks, life skills, etc.)
 */

// =============================================================================
// CATEGORY-SPECIFIC MASTER BOOK WORKFLOWS
// =============================================================================

/**
 * Category 2: Educational Textbooks (K-12) - MAIN PRIORITY
 * Focus: Academic standards, rigorous assessments, curriculum alignment
 * This is the foundation of the global library - every learnable subject
 */
export const MASTER_BOOK_EDUCATIONAL_TEXTBOOKS: WorkflowStep[] = [
  {
    id: 'standards_research',
    name: 'Academic Standards & Curriculum Research',
    description: 'Comprehensive research of educational standards, curriculum frameworks, and learning objectives',
    explanation: 'Three AI models independently research academic standards (Common Core, state standards, national frameworks) to ensure 100% alignment with educational requirements.',
    workers: [
      { role: 'GPT-4 Standards Researcher', description: 'Researches educational standards using GPT-4' },
      { role: 'Claude Curriculum Analyst', description: 'Analyzes curriculum frameworks using Claude' },
      { role: 'Gemini Learning Objectives Specialist', description: 'Maps learning objectives using Gemini' },
      { role: 'Standards Synthesizer', description: 'Combines findings from all 3 models' },
      { role: 'Curriculum Alignment Expert', description: 'Ensures complete standards coverage' },
      { role: 'Scope & Sequence Designer', description: 'Creates logical scope and sequence' }
    ],
    verificationWorkers: [
      { role: 'Standards Compliance Validator', description: 'Validates 100% standards alignment' },
      { role: 'Curriculum Coverage Check', description: 'Ensures complete curriculum coverage' },
      { role: 'Learning Objective Quality', description: 'Validates measurable objectives' }
    ],
    estimatedTime: 30,
    outputFiles: ['standards_research.json', 'curriculum_alignment.json', 'scope_sequence.json'],
    iterativeQuality: true,
    maxIterations: 15
  },
  {
    id: 'create_outline',
    name: 'Create Academic Chapter Structure',
    description: 'Building textbook structure with academic rigor and standards alignment',
    explanation: 'Workers create detailed textbook outline with explicit standards mapping, learning objectives, and assessment opportunities per chapter.',
    workers: [
      { role: 'Textbook Architect', description: 'Designs textbook structure' },
      { role: 'Standards Mapper', description: 'Maps standards to each chapter' },
      { role: 'Learning Objective Writer', description: 'Writes measurable learning objectives' },
      { role: 'Assessment Planner', description: 'Plans assessment opportunities' }
    ],
    verificationWorkers: [
      { role: 'Standards Coverage Validator', description: 'Confirms all standards covered' },
      { role: 'Academic Rigor Check', description: 'Validates appropriate academic level' }
    ],
    estimatedTime: 15,
    outputFiles: ['textbook_outline.json', 'standards_map.json', 'learning_objectives.json'],
    iterativeQuality: true,
    maxIterations: 12
  },
  {
    id: 'content_generation',
    name: 'Multi-AI Academic Content Generation',
    description: 'Generating rigorous academic content with standards alignment',
    explanation: 'Three AI models write textbook content with academic rigor, clear explanations, worked examples, and explicit standards alignment.',
    workers: [
      { role: 'GPT-4 Academic Writer', description: 'Writes comprehensive academic content' },
      { role: 'Claude Technical Specialist', description: 'Adds technical depth and accuracy' },
      { role: 'Gemini Clarity Expert', description: 'Ensures student comprehension' },
      { role: 'Content Synthesizer', description: 'Combines best elements' },
      { role: 'Example Generator', description: 'Creates worked examples' }
    ],
    verificationWorkers: [
      { role: 'Academic Accuracy Validator', description: 'Validates content accuracy' },
      { role: 'Standards Alignment Check', description: 'Confirms standards met' }
    ],
    estimatedTime: 50,
    outputFiles: ['textbook_content.json'],
    iterativeQuality: true,
    maxIterations: 20
  },
  {
    id: 'create_assessments',
    name: 'Create Rigorous Assessments',
    description: 'Generating formative and summative assessments aligned to standards',
    explanation: 'Workers create comprehensive assessment items at multiple cognitive levels (remember, understand, apply, analyze, evaluate, create) with rubrics and answer keys.',
    workers: [
      { role: 'Assessment Designer', description: 'Creates assessment items' },
      { role: 'Blooms Taxonomy Specialist', description: 'Ensures cognitive level variety' },
      { role: 'Rubric Developer', description: 'Creates scoring rubrics' },
      { role: 'Answer Key Generator', description: 'Creates detailed answer keys' }
    ],
    verificationWorkers: [
      { role: 'Assessment Validity Checker', description: 'Validates assessment alignment' },
      { role: 'Cognitive Level Validator', description: 'Ensures appropriate rigor' }
    ],
    estimatedTime: 20,
    outputFiles: ['assessments.json', 'rubrics.json', 'answer_keys.json'],
    iterativeQuality: true,
    maxIterations: 15
  }
];

/**
 * Category 3: Life Skills & Transition (14-22)
 * Focus: Practical independence, safety, real-world application
 */
export const MASTER_BOOK_LIFE_SKILLS: WorkflowStep[] = [
  {
    id: 'functional_skills_research',
    name: 'Functional Skills & Independence Research',
    description: 'Researching practical life skills, safety protocols, and community integration strategies',
    explanation: 'Three AI models research functional skills essential for independent living, including safety considerations, community resources, and generalization strategies.',
    workers: [
      { role: 'GPT-4 Life Skills Researcher', description: 'Researches practical life skills' },
      { role: 'Claude Safety Specialist', description: 'Analyzes safety protocols and considerations' },
      { role: 'Gemini Community Integration Expert', description: 'Researches community resources' },
      { role: 'Functional Skills Synthesizer', description: 'Combines all findings' },
      { role: 'Task Analysis Specialist', description: 'Breaks skills into steps' },
      { role: 'Generalization Strategist', description: 'Plans skill transfer strategies' }
    ],
    verificationWorkers: [
      { role: 'Functional Validity Checker', description: 'Ensures real-world applicability' },
      { role: 'Safety Protocol Validator', description: 'Validates all safety considerations' }
    ],
    estimatedTime: 28,
    outputFiles: ['life_skills_research.json', 'safety_protocols.json', 'community_resources.json'],
    iterativeQuality: true,
    maxIterations: 15
  },
  {
    id: 'create_outline',
    name: 'Create Independence Progression Structure',
    description: 'Building structure that progresses from dependent to independent skill execution',
    explanation: 'Workers create outline showing clear progression from full support to independence, with safety checkpoints and mastery criteria.',
    workers: [
      { role: 'Independence Progression Specialist', description: 'Designs independence levels' },
      { role: 'Safety Checkpoint Designer', description: 'Identifies safety verification points' },
      { role: 'Mastery Criteria Writer', description: 'Defines skill mastery criteria' }
    ],
    verificationWorkers: [
      { role: 'Progression Logic Validator', description: 'Validates logical progression' },
      { role: 'Safety Coverage Check', description: 'Ensures comprehensive safety' }
    ],
    estimatedTime: 14,
    outputFiles: ['independence_outline.json', 'safety_checkpoints.json', 'mastery_criteria.json'],
    iterativeQuality: true,
    maxIterations: 12
  },
  {
    id: 'content_generation',
    name: 'Multi-AI Practical Content Generation',
    description: 'Generating step-by-step practical content with safety emphasis',
    explanation: 'Three AI models write practical, action-oriented content with explicit safety protocols, troubleshooting guides, and real-world scenarios.',
    workers: [
      { role: 'GPT-4 Practical Writer', description: 'Writes clear step-by-step instructions' },
      { role: 'Claude Safety Integrator', description: 'Integrates safety protocols throughout' },
      { role: 'Gemini Scenario Creator', description: 'Creates realistic scenarios' },
      { role: 'Content Synthesizer', description: 'Combines best elements' },
      { role: 'Visual Support Designer', description: 'Plans visual aids for each step' }
    ],
    verificationWorkers: [
      { role: 'Practical Applicability Check', description: 'Validates real-world usability' },
      { role: 'Safety Integration Validator', description: 'Confirms safety throughout' }
    ],
    estimatedTime: 48,
    outputFiles: ['life_skills_content.json'],
    iterativeQuality: true,
    maxIterations: 20
  }
];

/**
 * Category 4: Early Intervention (0-5)
 * Focus: Developmental milestones, play-based learning, parent coaching
 */
export const MASTER_BOOK_EARLY_INTERVENTION: WorkflowStep[] = [
  {
    id: 'developmental_research',
    name: 'Developmental Milestones & Play-Based Learning Research',
    description: 'Researching early childhood development, milestones, and play-based learning strategies',
    explanation: 'Three AI models research developmental milestones, age-appropriate play activities, and parent coaching strategies for ages 0-5.',
    workers: [
      { role: 'GPT-4 Development Specialist', description: 'Researches developmental milestones' },
      { role: 'Claude Play Therapist', description: 'Analyzes play-based learning approaches' },
      { role: 'Gemini Parent Coach', description: 'Researches parent coaching strategies' },
      { role: 'Development Synthesizer', description: 'Combines all findings' },
      { role: 'Milestone Mapper', description: 'Maps skills to developmental stages' },
      { role: 'Sensory Integration Specialist', description: 'Integrates sensory considerations' }
    ],
    verificationWorkers: [
      { role: 'Developmental Accuracy Validator', description: 'Validates milestone accuracy' },
      { role: 'Age Appropriateness Check', description: 'Ensures age-appropriate activities' }
    ],
    estimatedTime: 26,
    outputFiles: ['developmental_research.json', 'milestones_map.json', 'play_strategies.json'],
    iterativeQuality: true,
    maxIterations: 15
  },
  {
    id: 'create_outline',
    name: 'Create Developmental Progression Structure',
    description: 'Building structure aligned with 0-5 developmental stages',
    explanation: 'Workers create outline organized by developmental stages with clear milestone targets and play-based activities.',
    workers: [
      { role: 'Developmental Stage Organizer', description: 'Organizes by age stages' },
      { role: 'Milestone Target Writer', description: 'Defines milestone targets' },
      { role: 'Play Activity Planner', description: 'Plans play-based activities' }
    ],
    verificationWorkers: [
      { role: 'Stage Progression Validator', description: 'Validates developmental sequence' }
    ],
    estimatedTime: 13,
    outputFiles: ['developmental_outline.json', 'milestone_targets.json'],
    iterativeQuality: true,
    maxIterations: 12
  },
  {
    id: 'content_generation',
    name: 'Multi-AI Early Childhood Content Generation',
    description: 'Generating developmentally appropriate content with parent coaching',
    explanation: 'Three AI models write content focused on play-based learning, parent-child interaction, and developmental milestone achievement.',
    workers: [
      { role: 'GPT-4 Early Childhood Writer', description: 'Writes developmental content' },
      { role: 'Claude Parent Coach Writer', description: 'Writes parent coaching guides' },
      { role: 'Gemini Play Activity Designer', description: 'Creates play activities' },
      { role: 'Content Synthesizer', description: 'Combines best elements' },
      { role: 'Visual Support Creator', description: 'Creates visual supports for young learners' }
    ],
    verificationWorkers: [
      { role: 'Developmental Appropriateness', description: 'Validates age appropriateness' },
      { role: 'Parent Accessibility Check', description: 'Ensures parent-friendly language' }
    ],
    estimatedTime: 44,
    outputFiles: ['early_intervention_content.json'],
    iterativeQuality: true,
    maxIterations: 20
  }
];

/**
 * Category 5: Social Skills Curriculum
 * Focus: Social scenarios, perspective-taking, emotion regulation
 */
export const MASTER_BOOK_SOCIAL_SKILLS: WorkflowStep[] = [
  {
    id: 'social_research',
    name: 'Social Skills & Scenario Research',
    description: 'Researching social skills development, perspective-taking, and emotion regulation strategies',
    explanation: 'Three AI models research social skills across contexts (school, community, workplace) with emphasis on perspective-taking and emotional understanding.',
    workers: [
      { role: 'GPT-4 Social Skills Researcher', description: 'Researches social skills across contexts' },
      { role: 'Claude Behavioral Psychologist', description: 'Analyzes social behavior patterns' },
      { role: 'Gemini Emotion Regulation Expert', description: 'Researches emotion regulation strategies' },
      { role: 'Social Skills Synthesizer', description: 'Combines all findings' },
      { role: 'Scenario Developer', description: 'Develops realistic social scenarios' },
      { role: 'Perspective-Taking Strategist', description: 'Plans perspective-taking activities' }
    ],
    verificationWorkers: [
      { role: 'Social Validity Checker', description: 'Validates social appropriateness' },
      { role: 'Context Coverage Validator', description: 'Ensures all contexts covered' }
    ],
    estimatedTime: 27,
    outputFiles: ['social_skills_research.json', 'scenarios.json', 'emotion_strategies.json'],
    iterativeQuality: true,
    maxIterations: 15
  },
  {
    id: 'create_outline',
    name: 'Create Social Skills Progression Structure',
    description: 'Building structure that progresses from basic to complex social situations',
    explanation: 'Workers create outline progressing from simple social interactions to complex social navigation with emotion regulation integrated throughout.',
    workers: [
      { role: 'Social Complexity Organizer', description: 'Organizes by complexity level' },
      { role: 'Scenario Progression Designer', description: 'Designs scenario progression' },
      { role: 'Emotion Integration Specialist', description: 'Integrates emotion regulation' }
    ],
    verificationWorkers: [
      { role: 'Progression Validator', description: 'Validates complexity progression' }
    ],
    estimatedTime: 13,
    outputFiles: ['social_skills_outline.json', 'scenario_progression.json'],
    iterativeQuality: true,
    maxIterations: 12
  },
  {
    id: 'content_generation',
    name: 'Multi-AI Social Skills Content Generation',
    description: 'Generating scenario-based content with perspective-taking emphasis',
    explanation: 'Three AI models write content using social stories, role-play scenarios, video modeling scripts, and perspective-taking exercises.',
    workers: [
      { role: 'GPT-4 Social Story Writer', description: 'Writes social stories' },
      { role: 'Claude Scenario Designer', description: 'Creates detailed social scenarios' },
      { role: 'Gemini Role-Play Developer', description: 'Develops role-play scripts' },
      { role: 'Content Synthesizer', description: 'Combines best elements' },
      { role: 'Perspective Exercise Creator', description: 'Creates perspective-taking exercises' }
    ],
    verificationWorkers: [
      { role: 'Social Appropriateness Check', description: 'Validates social accuracy' },
      { role: 'Scenario Realism Validator', description: 'Ensures realistic scenarios' }
    ],
    estimatedTime: 46,
    outputFiles: ['social_skills_content.json'],
    iterativeQuality: true,
    maxIterations: 20
  }
];

/**
 * Category 6: Executive Function & Self-Regulation
 * Focus: Planning, organization, task initiation, self-monitoring
 */
export const MASTER_BOOK_EXECUTIVE_FUNCTION: WorkflowStep[] = [
  {
    id: 'executive_function_research',
    name: 'Executive Function & Strategy Research',
    description: 'Researching executive function skills, cognitive strategies, and self-regulation techniques',
    explanation: 'Three AI models research executive function components (working memory, cognitive flexibility, inhibitory control) and evidence-based strategies for development.',
    workers: [
      { role: 'GPT-4 Cognitive Scientist', description: 'Researches executive function theory' },
      { role: 'Claude Strategy Specialist', description: 'Analyzes proven cognitive strategies' },
      { role: 'Gemini Self-Regulation Expert', description: 'Researches self-monitoring techniques' },
      { role: 'Executive Function Synthesizer', description: 'Combines all findings' },
      { role: 'Strategy Development Specialist', description: 'Develops practical strategies' },
      { role: 'Metacognition Expert', description: 'Plans metacognitive skill development' }
    ],
    verificationWorkers: [
      { role: 'Evidence-Based Practice Validator', description: 'Validates research backing' },
      { role: 'Strategy Effectiveness Check', description: 'Ensures proven effectiveness' }
    ],
    estimatedTime: 29,
    outputFiles: ['executive_function_research.json', 'strategies.json', 'self_regulation.json'],
    iterativeQuality: true,
    maxIterations: 15
  },
  {
    id: 'create_outline',
    name: 'Create Skill Progression Structure',
    description: 'Building structure progressing from basic to advanced executive function skills',
    explanation: 'Workers create outline organized by executive function domains with clear strategy progression and generalization planning.',
    workers: [
      { role: 'Skill Progression Organizer', description: 'Organizes by skill complexity' },
      { role: 'Strategy Sequence Designer', description: 'Sequences strategy introduction' },
      { role: 'Generalization Planner', description: 'Plans cross-context application' }
    ],
    verificationWorkers: [
      { role: 'Domain Coverage Validator', description: 'Ensures all EF domains covered' },
      { role: 'Progression Logic Check', description: 'Validates skill scaffolding' }
    ],
    estimatedTime: 14,
    outputFiles: ['executive_function_outline.json', 'strategy_sequence.json'],
    iterativeQuality: true,
    maxIterations: 12
  },
  {
    id: 'content_generation',
    name: 'Multi-AI Strategy Content Generation',
    description: 'Generating strategy-focused content with metacognitive emphasis',
    explanation: 'Three AI models write content teaching explicit strategies with metacognitive prompts, self-monitoring tools, and practice scenarios.',
    workers: [
      { role: 'GPT-4 Strategy Writer', description: 'Writes explicit strategy instruction' },
      { role: 'Claude Metacognitive Specialist', description: 'Adds metacognitive elements' },
      { role: 'Gemini Tool Designer', description: 'Creates organizational tools and templates' },
      { role: 'Content Synthesizer', description: 'Combines best elements' },
      { role: 'Practice Scenario Developer', description: 'Creates application scenarios' }
    ],
    verificationWorkers: [
      { role: 'Strategy Clarity Validator', description: 'Ensures clear strategy explanation' },
      { role: 'Tool Usability Check', description: 'Validates practical tool design' }
    ],
    estimatedTime: 47,
    outputFiles: ['executive_function_content.json'],
    iterativeQuality: true,
    maxIterations: 20
  }
];

/**
 * REMOVED: Category 7 - Sensory Support
 * Reason: Merged into disability adaptation system
 * Sensory support is now an adaptation layer applied to ANY book
 * See: disability_profiles.Sensory Processing Disorder
 */

/**
 * REMOVED: Category 8 - AAC & Communication
 * Reason: Merged into disability adaptation system
 * AAC/Communication support is now an adaptation layer applied to ANY book
 * See: disability_profiles.Speech/Language Impairments
 */

// Export only active category workflows (5 total)
export const SPECIALIZED_MASTER_WORKFLOWS = {
  category_2_educational_textbooks: MASTER_BOOK_EDUCATIONAL_TEXTBOOKS,
  category_3_life_skills: MASTER_BOOK_LIFE_SKILLS,
  category_4_early_intervention: MASTER_BOOK_EARLY_INTERVENTION,
  category_5_social_skills: MASTER_BOOK_SOCIAL_SKILLS,
  category_6_executive_function: MASTER_BOOK_EXECUTIVE_FUNCTION
};

// =============================================================================
// DEPRECATED - KEPT FOR REFERENCE ONLY
// =============================================================================

/**
 * @deprecated Category 7: Sensory Support - MERGED INTO DISABILITY ADAPTATIONS
 * Focus: Sensory processing, regulation strategies, environmental modifications
 */
const DEPRECATED_MASTER_BOOK_SENSORY_SUPPORT: WorkflowStep[] = [
  {
    id: 'sensory_research',
    name: 'Sensory Processing & Regulation Research',
    description: 'Researching sensory processing patterns, regulation strategies, and accommodations',
    explanation: 'Three AI models research sensory processing (8 sensory systems), regulation techniques, and environmental modifications across settings.',
    workers: [
      { role: 'GPT-4 Sensory Integration Specialist', description: 'Researches sensory processing theory' },
      { role: 'Claude Occupational Therapist', description: 'Analyzes sensory strategies from OT perspective' },
      { role: 'Gemini Environment Modification Expert', description: 'Researches environmental accommodations' },
      { role: 'Sensory Synthesizer', description: 'Combines all findings' },
      { role: 'Sensory Profile Analyst', description: 'Identifies sensory patterns' },
      { role: 'Regulation Strategy Developer', description: 'Develops regulation techniques' }
    ],
    verificationWorkers: [
      { role: 'Sensory Theory Validator', description: 'Validates sensory processing accuracy' },
      { role: 'Strategy Safety Check', description: 'Ensures safe regulation strategies' }
    ],
    estimatedTime: 28,
    outputFiles: ['sensory_research.json', 'regulation_strategies.json', 'accommodations.json'],
    iterativeQuality: true,
    maxIterations: 15
  },
  {
    id: 'create_outline',
    name: 'Create Sensory System Structure',
    description: 'Building structure organized by sensory systems and regulation needs',
    explanation: 'Workers create outline covering all 8 sensory systems with regulation strategies for hypo/hyper-sensitivity patterns.',
    workers: [
      { role: 'Sensory System Organizer', description: 'Organizes by sensory systems' },
      { role: 'Pattern-Based Designer', description: 'Addresses hypo/hyper patterns' },
      { role: 'Environment Integration Specialist', description: 'Plans environmental modifications' }
    ],
    verificationWorkers: [
      { role: 'System Coverage Validator', description: 'Ensures all 8 systems covered' },
      { role: 'Pattern Completeness Check', description: 'Validates both hypo and hyper addressed' }
    ],
    estimatedTime: 13,
    outputFiles: ['sensory_outline.json', 'system_coverage.json'],
    iterativeQuality: true,
    maxIterations: 12
  },
  {
    id: 'content_generation',
    name: 'Multi-AI Sensory Content Generation',
    description: 'Generating sensory-focused content with practical regulation strategies',
    explanation: 'Three AI models write content teaching sensory awareness, self-regulation, and environmental modifications with visual supports.',
    workers: [
      { role: 'GPT-4 Sensory Educator', description: 'Writes sensory education content' },
      { role: 'Claude Strategy Integrator', description: 'Integrates regulation strategies' },
      { role: 'Gemini Visual Designer', description: 'Creates visual regulation supports' },
      { role: 'Content Synthesizer', description: 'Combines best elements' },
      { role: 'Sensory Tool Creator', description: 'Designs sensory tools and aids' }
    ],
    verificationWorkers: [
      { role: 'Sensory Accuracy Validator', description: 'Validates sensory information' },
      { role: 'Strategy Practicality Check', description: 'Ensures strategies are practical' }
    ],
    estimatedTime: 45,
    outputFiles: ['sensory_content.json'],
    iterativeQuality: true,
    maxIterations: 20
  }
];

/**
 * @deprecated Category 8: AAC & Communication - MERGED INTO DISABILITY ADAPTATIONS
 * Focus: Alternative/augmentative communication, communication strategies, device training
 */
const DEPRECATED_MASTER_BOOK_AAC_COMMUNICATION: WorkflowStep[] = [
  {
    id: 'communication_research',
    name: 'AAC & Communication Strategy Research',
    description: 'Researching AAC systems, communication development, and multimodal strategies',
    explanation: 'Three AI models research AAC technology, communication development theory, and evidence-based communication strategies across modalities.',
    workers: [
      { role: 'GPT-4 AAC Specialist', description: 'Researches AAC systems and technology' },
      { role: 'Claude Speech-Language Pathologist', description: 'Analyzes communication development' },
      { role: 'Gemini Multimodal Strategist', description: 'Researches total communication approaches' },
      { role: 'Communication Synthesizer', description: 'Combines all findings' },
      { role: 'Device Training Specialist', description: 'Develops device training protocols' },
      { role: 'Communication Partner Trainer', description: 'Plans partner training strategies' }
    ],
    verificationWorkers: [
      { role: 'AAC Accuracy Validator', description: 'Validates AAC information accuracy' },
      { role: 'Evidence-Based Practice Check', description: 'Ensures research-backed strategies' }
    ],
    estimatedTime: 30,
    outputFiles: ['aac_research.json', 'communication_strategies.json', 'device_training.json'],
    iterativeQuality: true,
    maxIterations: 15
  },
  {
    id: 'create_outline',
    name: 'Create Communication Progression Structure',
    description: 'Building structure progressing from basic to advanced communication',
    explanation: 'Workers create outline organized by communication complexity with AAC system integration and partner training.',
    workers: [
      { role: 'Communication Progression Organizer', description: 'Organizes by communication complexity' },
      { role: 'AAC Integration Specialist', description: 'Integrates AAC systems throughout' },
      { role: 'Partner Training Designer', description: 'Plans communication partner training' }
    ],
    verificationWorkers: [
      { role: 'Modality Coverage Validator', description: 'Ensures all modalities addressed' },
      { role: 'Progression Logic Check', description: 'Validates communication scaffolding' }
    ],
    estimatedTime: 15,
    outputFiles: ['communication_outline.json', 'aac_integration.json'],
    iterativeQuality: true,
    maxIterations: 12
  },
  {
    id: 'content_generation',
    name: 'Multi-AI Communication Content Generation',
    description: 'Generating AAC-focused content with multimodal emphasis',
    explanation: 'Three AI models write content teaching AAC use, communication strategies, and partner training with visual supports and video modeling scripts.',
    workers: [
      { role: 'GPT-4 AAC Training Writer', description: 'Writes AAC device training content' },
      { role: 'Claude Communication Strategy Writer', description: 'Writes strategy instruction' },
      { role: 'Gemini Visual Support Designer', description: 'Creates visual communication supports' },
      { role: 'Content Synthesizer', description: 'Combines best elements' },
      { role: 'Video Script Developer', description: 'Creates video modeling scripts' }
    ],
    verificationWorkers: [
      { role: 'AAC Instruction Validator', description: 'Validates AAC training accuracy' },
      { role: 'Communication Strategy Check', description: 'Ensures effective strategies' }
    ],
    estimatedTime: 48,
    outputFiles: ['aac_communication_content.json'],
    iterativeQuality: true,
    maxIterations: 20
  }
];
