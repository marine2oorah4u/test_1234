export function useNavigate() {
  return (page: string) => {
    window.dispatchEvent(new CustomEvent('navigate', { detail: { page } }));
  };
}
