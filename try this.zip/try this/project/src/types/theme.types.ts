export type ThemeCategory = 'admin' | 'demo';

export interface ThemeColors {
  primary: string;
  primaryHover: string;
  secondary: string;
  secondaryHover: string;
  accent: string;
  accentHover: string;
  background: string;
  surface: string;
  surfaceHover: string;
  border: string;
  text: string;
  textMuted: string;
  textSecondary: string;
  success: string;
  warning: string;
  error: string;
  info: string;
}

export interface ThemePatterns {
  backgroundImage?: string;
  backgroundWallpaper?: string;
  backgroundSize?: string;
  backgroundPosition?: string;
  backgroundRepeat?: string;
  wallpaperOpacity?: number;
  borderStyle?: string;
  decorativeElements?: string[];
  overlayOpacity?: number;
}

export interface ThemeAnimations {
  transition: string;
  hoverEffect?: string;
  glowColor?: string;
}

export interface Theme {
  id: string;
  name: string;
  category: ThemeCategory;
  colors: ThemeColors;
  patterns?: ThemePatterns;
  animations: ThemeAnimations;
  fontFamily?: string;
}

export interface ThemeContextType {
  currentTheme: Theme;
  availableThemes: Theme[];
  setTheme: (themeId: string) => Promise<void>;
  loading: boolean;
}
