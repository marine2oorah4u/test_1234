import { AIModelConfig, PhaseConfig } from '../config/maximumQualityModels';

export interface AIResponse {
  modelId: string;
  content: string;
  confidence: number;
  metadata: {
    tokens: number;
    latency: number;
    timestamp: Date;
  };
}

export interface ConsensusResult {
  finalContent: string;
  confidenceScore: number;
  agreementLevel: number;
  participatingAIs: string[];
  conflicts: ConflictReport[];
  mergeStrategy: string;
  qualityMetrics: QualityMetrics;
}

export interface ConflictReport {
  section: string;
  disagreement: string;
  affectedModels: string[];
  resolution: string;
}

export interface QualityMetrics {
  accuracy: number;
  clarity: number;
  completeness: number;
  consistency: number;
  overallScore: number;
}

export interface VerificationResult {
  modelId: string;
  issues: Issue[];
  qualityScore: number;
  passed: boolean;
}

export interface Issue {
  type: 'factual' | 'grammar' | 'logic' | 'clarity' | 'accessibility';
  severity: 'low' | 'medium' | 'high' | 'critical';
  location: string;
  description: string;
  suggestion?: string;
}

export class MultiAIConsensus {
  async generateWithConsensus(
    prompt: string,
    phase: PhaseConfig,
    responses: AIResponse[]
  ): Promise<ConsensusResult> {
    if (responses.length < phase.minAIs) {
      throw new Error(`Insufficient AI responses. Got ${responses.length}, need ${phase.minAIs}`);
    }

    const agreements = this.findAgreements(responses);
    const conflicts = this.identifyConflicts(responses);
    const mergedContent = await this.mergeBestParts(responses, agreements, conflicts);
    const qualityMetrics = this.assessQuality(mergedContent, responses);

    return {
      finalContent: mergedContent,
      confidenceScore: this.calculateConfidence(agreements, responses.length),
      agreementLevel: agreements.length / responses.length,
      participatingAIs: responses.map(r => r.modelId),
      conflicts,
      mergeStrategy: this.determineMergeStrategy(phase, conflicts.length),
      qualityMetrics,
    };
  }

  async verifyWithConsensus(
    content: string,
    phase: PhaseConfig,
    verifications: VerificationResult[]
  ): Promise<{
    passed: boolean;
    overallQuality: number;
    consensusIssues: Issue[];
    needsRefinement: boolean;
  }> {
    const consensusIssues = this.aggregateIssues(verifications, phase.consensusThreshold);
    const overallQuality = this.calculateOverallQuality(verifications);
    const passed = overallQuality >= phase.qualityThreshold;
    const needsRefinement = !passed && overallQuality >= 0.70;

    return {
      passed,
      overallQuality,
      consensusIssues,
      needsRefinement,
    };
  }

  private findAgreements(responses: AIResponse[]): string[] {
    const agreements: string[] = [];
    const sentences = responses.map(r => this.extractSentences(r.content));

    for (let i = 0; i < sentences[0].length; i++) {
      const baseSentence = sentences[0][i];
      const similarCount = sentences.filter(sentList =>
        sentList.some(sent => this.calculateSimilarity(baseSentence, sent) > 0.8)
      ).length;

      if (similarCount / responses.length > 0.75) {
        agreements.push(baseSentence);
      }
    }

    return agreements;
  }

  private identifyConflicts(responses: AIResponse[]): ConflictReport[] {
    const conflicts: ConflictReport[] = [];
    const topics = this.extractTopics(responses[0].content);

    for (const topic of topics) {
      const topicContent = responses.map(r => this.extractTopicContent(r.content, topic));
      const disagreement = this.findDisagreement(topicContent);

      if (disagreement) {
        conflicts.push({
          section: topic,
          disagreement,
          affectedModels: responses.map(r => r.modelId),
          resolution: this.resolveConflict(topicContent, responses),
        });
      }
    }

    return conflicts;
  }

  private async mergeBestParts(
    responses: AIResponse[],
    agreements: string[],
    conflicts: ConflictReport[]
  ): Promise<string> {
    const sections: Map<string, string> = new Map();

    for (const agreement of agreements) {
      sections.set(this.getSectionKey(agreement), agreement);
    }

    for (const conflict of conflicts) {
      sections.set(conflict.section, conflict.resolution);
    }

    const sortedSections = Array.from(sections.entries())
      .sort((a, b) => this.getSectionOrder(a[0]) - this.getSectionOrder(b[0]));

    return sortedSections.map(([_, content]) => content).join('\n\n');
  }

  private aggregateIssues(
    verifications: VerificationResult[],
    threshold: number
  ): Issue[] {
    const issueMap = new Map<string, { issue: Issue; count: number }>();

    for (const verification of verifications) {
      for (const issue of verification.issues) {
        const key = `${issue.type}-${issue.location}`;
        const existing = issueMap.get(key);

        if (existing) {
          existing.count++;
        } else {
          issueMap.set(key, { issue, count: 1 });
        }
      }
    }

    const consensusIssues: Issue[] = [];
    const minAgreement = Math.ceil(verifications.length * threshold);

    for (const { issue, count } of issueMap.values()) {
      if (count >= minAgreement) {
        consensusIssues.push(issue);
      }
    }

    return consensusIssues.sort((a, b) => {
      const severityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
      return severityOrder[a.severity] - severityOrder[b.severity];
    });
  }

  private calculateOverallQuality(verifications: VerificationResult[]): number {
    const avgScore = verifications.reduce((sum, v) => sum + v.qualityScore, 0) / verifications.length;
    const passRate = verifications.filter(v => v.passed).length / verifications.length;

    return avgScore * 0.7 + passRate * 0.3;
  }

  private assessQuality(content: string, responses: AIResponse[]): QualityMetrics {
    const accuracy = this.assessAccuracy(content, responses);
    const clarity = this.assessClarity(content);
    const completeness = this.assessCompleteness(content, responses);
    const consistency = this.assessConsistency(content);

    return {
      accuracy,
      clarity,
      completeness,
      consistency,
      overallScore: (accuracy + clarity + completeness + consistency) / 4,
    };
  }

  private assessAccuracy(content: string, responses: AIResponse[]): number {
    const avgConfidence = responses.reduce((sum, r) => sum + r.confidence, 0) / responses.length;
    return Math.min(avgConfidence * 1.1, 1.0);
  }

  private assessClarity(content: string): number {
    const sentences = this.extractSentences(content);
    const avgLength = sentences.reduce((sum, s) => sum + s.split(' ').length, 0) / sentences.length;

    const clarityScore = avgLength < 25 ? 1.0 : Math.max(0.6, 1.0 - (avgLength - 25) / 100);
    return clarityScore;
  }

  private assessCompleteness(content: string, responses: AIResponse[]): number {
    const allTopics = new Set<string>();
    responses.forEach(r => {
      this.extractTopics(r.content).forEach(t => allTopics.add(t));
    });

    const coveredTopics = this.extractTopics(content);
    return coveredTopics.length / allTopics.size;
  }

  private assessConsistency(content: string): number {
    const sentences = this.extractSentences(content);
    let consistencyScore = 1.0;

    for (let i = 1; i < sentences.length; i++) {
      const similarity = this.calculateSimilarity(sentences[i - 1], sentences[i]);
      if (similarity > 0.9) {
        consistencyScore -= 0.05;
      }
    }

    return Math.max(0.6, consistencyScore);
  }

  private calculateConfidence(agreements: string[], totalResponses: number): number {
    if (totalResponses === 0) return 0;
    return Math.min((agreements.length / totalResponses) * 1.2, 1.0);
  }

  private determineMergeStrategy(phase: PhaseConfig, conflictCount: number): string {
    if (conflictCount === 0) return 'full-agreement';
    if (conflictCount < 3) return 'selective-merge';
    if (conflictCount < 5) return 'conflict-resolution';
    return 'weighted-voting';
  }

  private extractSentences(content: string): string[] {
    return content
      .split(/[.!?]+/)
      .map(s => s.trim())
      .filter(s => s.length > 0);
  }

  private extractTopics(content: string): string[] {
    const lines = content.split('\n').filter(l => l.trim());
    return lines
      .filter(l => l.startsWith('#') || l.match(/^[A-Z][^.!?]*:/) || l.length < 100)
      .map(l => l.replace(/^#+\s*/, '').replace(/:$/, '').trim());
  }

  private extractTopicContent(content: string, topic: string): string {
    const lines = content.split('\n');
    const topicIndex = lines.findIndex(l => l.includes(topic));

    if (topicIndex === -1) return '';

    const nextTopicIndex = lines.findIndex((l, i) => i > topicIndex && l.match(/^#+|^[A-Z]/));
    const endIndex = nextTopicIndex === -1 ? lines.length : nextTopicIndex;

    return lines.slice(topicIndex, endIndex).join('\n').trim();
  }

  private findDisagreement(topicContents: string[]): string | null {
    if (topicContents.length < 2) return null;

    const similarities = [];
    for (let i = 0; i < topicContents.length - 1; i++) {
      for (let j = i + 1; j < topicContents.length; j++) {
        similarities.push(this.calculateSimilarity(topicContents[i], topicContents[j]));
      }
    }

    const avgSimilarity = similarities.reduce((a, b) => a + b, 0) / similarities.length;
    return avgSimilarity < 0.6 ? 'Significant disagreement detected' : null;
  }

  private resolveConflict(topicContents: string[], responses: AIResponse[]): string {
    const scored = topicContents.map((content, index) => ({
      content,
      score: responses[index].confidence * (content.length / 100),
    }));

    scored.sort((a, b) => b.score - a.score);
    return scored[0].content;
  }

  private calculateSimilarity(text1: string, text2: string): number {
    const words1 = new Set(text1.toLowerCase().split(/\s+/));
    const words2 = new Set(text2.toLowerCase().split(/\s+/));

    const intersection = new Set([...words1].filter(w => words2.has(w)));
    const union = new Set([...words1, ...words2]);

    return intersection.size / union.size;
  }

  private getSectionKey(text: string): string {
    return text.substring(0, 50).toLowerCase().replace(/\s+/g, '-');
  }

  private getSectionOrder(key: string): number {
    const orderMap: Record<string, number> = {
      introduction: 0,
      overview: 1,
      'learning-objectives': 2,
      content: 3,
      examples: 4,
      practice: 5,
      summary: 6,
      assessment: 7,
    };

    for (const [pattern, order] of Object.entries(orderMap)) {
      if (key.includes(pattern)) return order;
    }

    return 999;
  }
}

export const consensusEngine = new MultiAIConsensus();
