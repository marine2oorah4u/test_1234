import { supabase } from './supabase';

export async function startBookGeneration(queueId: string): Promise<void> {
  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

  const response = await fetch(
    `${supabaseUrl}/functions/v1/book-generator-worker`,
    {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${anonKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ queueId }),
    }
  );

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Failed to start book generation: ${error}`);
  }

  return response.json();
}

export async function getBookProgress(bookId: string) {
  const { data, error } = await supabase
    .from('generation_queue')
    .select('*')
    .eq('book_id', bookId)
    .maybeSingle();

  if (error) throw error;
  return data;
}

export async function getBookVersions(bookId: string) {
  const { data, error } = await supabase
    .from('book_versions')
    .select('*')
    .eq('book_id', bookId)
    .order('reading_level', { ascending: true });

  if (error) throw error;
  return data;
}
