export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type ReadingLevel = 'phd' | 'masters' | 'bachelors' | 'high_school' | 'middle_school' | 'elementary' | 'kindergarten' | 'library'
export type FormatType = 'pdf' | 'epub' | 'html' | 'audio' | 'video' | 'docx' | 'markdown' | 'latex'
export type AddonType = 'activity_pack' | 'worksheet_set' | 'quiz_pack' | 'answer_key' | 'lesson_plans' | 'presentation_slides' | 'career_guide' | 'study_guide'
export type LessonType = 'quiz' | 'exercise' | 'game' | 'simulation' | 'activity'

export interface Database {
  public: {
    Tables: {
      books: {
        Row: {
          id: string
          title: string
          subject: string
          description: string
          status: 'pending' | 'processing' | 'completed' | 'failed'
          metadata: Json
          is_demo: boolean
          created_at: string
          updated_at: string
          completed_at: string | null
          expiration_date: string | null
        }
        Insert: {
          id?: string
          title: string
          subject: string
          description?: string
          status?: 'pending' | 'processing' | 'completed' | 'failed'
          metadata?: Json
          is_demo?: boolean
          created_at?: string
          updated_at?: string
          completed_at?: string | null
          expiration_date?: string | null
        }
        Update: {
          id?: string
          title?: string
          subject?: string
          description?: string
          status?: 'pending' | 'processing' | 'completed' | 'failed'
          metadata?: Json
          is_demo?: boolean
          created_at?: string
          updated_at?: string
          completed_at?: string | null
          expiration_date?: string | null
        }
      }
      book_versions: {
        Row: {
          id: string
          book_id: string
          reading_level: ReadingLevel
          format_type: FormatType
          file_url: string | null
          file_size: number
          word_count: number
          duration: number | null
          status: 'pending' | 'processing' | 'completed' | 'failed'
          metadata: Json
          is_library_edition: boolean
          is_textbook_edition: boolean
          is_honors: boolean
          theme_applied: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          book_id: string
          reading_level: ReadingLevel
          format_type: FormatType
          file_url?: string | null
          file_size?: number
          word_count?: number
          duration?: number | null
          status?: 'pending' | 'processing' | 'completed' | 'failed'
          metadata?: Json
          is_library_edition?: boolean
          is_textbook_edition?: boolean
          is_honors?: boolean
          theme_applied?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          book_id?: string
          reading_level?: ReadingLevel
          format_type?: FormatType
          file_url?: string | null
          file_size?: number
          word_count?: number
          duration?: number | null
          status?: 'pending' | 'processing' | 'completed' | 'failed'
          metadata?: Json
          is_library_edition?: boolean
          is_textbook_edition?: boolean
          is_honors?: boolean
          theme_applied?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      book_addons: {
        Row: {
          id: string
          book_id: string
          reading_level: ReadingLevel
          addon_type: AddonType
          file_url: string | null
          file_size: number
          status: 'pending' | 'processing' | 'completed' | 'failed'
          metadata: Json
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          book_id: string
          reading_level: ReadingLevel
          addon_type: AddonType
          file_url?: string | null
          file_size?: number
          status?: 'pending' | 'processing' | 'completed' | 'failed'
          metadata?: Json
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          book_id?: string
          reading_level?: ReadingLevel
          addon_type?: AddonType
          file_url?: string | null
          file_size?: number
          status?: 'pending' | 'processing' | 'completed' | 'failed'
          metadata?: Json
          created_at?: string
          updated_at?: string
        }
      }
      textbook_designs: {
        Row: {
          id: string
          book_id: string
          reading_level: ReadingLevel
          cover_design_data: Json
          interior_template_id: string | null
          theme_name: string | null
          color_scheme: Json
          page_layout_config: Json
          typography_config: Json
          design_status: 'pending' | 'processing' | 'completed' | 'failed'
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          book_id: string
          reading_level: ReadingLevel
          cover_design_data?: Json
          interior_template_id?: string | null
          theme_name?: string | null
          color_scheme?: Json
          page_layout_config?: Json
          typography_config?: Json
          design_status?: 'pending' | 'processing' | 'completed' | 'failed'
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          book_id?: string
          reading_level?: ReadingLevel
          cover_design_data?: Json
          interior_template_id?: string | null
          theme_name?: string | null
          color_scheme?: Json
          page_layout_config?: Json
          typography_config?: Json
          design_status?: 'pending' | 'processing' | 'completed' | 'failed'
          created_at?: string
          updated_at?: string
        }
      }
      country_packages: {
        Row: {
          id: string
          book_id: string
          reading_level: ReadingLevel
          country_code: string
          country_name: string
          language_code: string
          customization_applied: Json
          file_url: string | null
          status: 'pending' | 'processing' | 'completed' | 'failed'
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          book_id: string
          reading_level: ReadingLevel
          country_code: string
          country_name: string
          language_code: string
          customization_applied?: Json
          file_url?: string | null
          status?: 'pending' | 'processing' | 'completed' | 'failed'
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          book_id?: string
          reading_level?: ReadingLevel
          country_code?: string
          country_name?: string
          language_code?: string
          customization_applied?: Json
          file_url?: string | null
          status?: 'pending' | 'processing' | 'completed' | 'failed'
          created_at?: string
          updated_at?: string
        }
      }
      language_translations: {
        Row: {
          id: string
          book_id: string
          reading_level: ReadingLevel
          source_language: string
          target_language: string
          language_name: string
          translation_provider: string | null
          verification_status: 'unverified' | 'in_progress' | 'verified' | 'failed'
          verification_count: number
          quality_score: number
          file_url: string | null
          status: 'pending' | 'processing' | 'completed' | 'failed'
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          book_id: string
          reading_level: ReadingLevel
          source_language?: string
          target_language: string
          language_name: string
          translation_provider?: string | null
          verification_status?: 'unverified' | 'in_progress' | 'verified' | 'failed'
          verification_count?: number
          quality_score?: number
          file_url?: string | null
          status?: 'pending' | 'processing' | 'completed' | 'failed'
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          book_id?: string
          reading_level?: ReadingLevel
          source_language?: string
          target_language?: string
          language_name?: string
          translation_provider?: string | null
          verification_status?: 'unverified' | 'in_progress' | 'verified' | 'failed'
          verification_count?: number
          quality_score?: number
          file_url?: string | null
          status?: 'pending' | 'processing' | 'completed' | 'failed'
          created_at?: string
          updated_at?: string
        }
      }
      generation_queue: {
        Row: {
          id: string
          book_id: string
          status: 'queued' | 'processing' | 'completed' | 'failed' | 'cancelled'
          progress_stage: string
          progress_percentage: number
          estimated_completion: string | null
          error_log: Json | null
          generation_config: Json
          started_at: string | null
          completed_at: string | null
          created_at: string
        }
        Insert: {
          id?: string
          book_id: string
          status?: 'queued' | 'processing' | 'completed' | 'failed' | 'cancelled'
          progress_stage?: string
          progress_percentage?: number
          estimated_completion?: string | null
          error_log?: Json | null
          generation_config?: Json
          started_at?: string | null
          completed_at?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          book_id?: string
          status?: 'queued' | 'processing' | 'completed' | 'failed' | 'cancelled'
          progress_stage?: string
          progress_percentage?: number
          estimated_completion?: string | null
          error_log?: Json | null
          generation_config?: Json
          started_at?: string | null
          completed_at?: string | null
          created_at?: string
        }
      }
      api_services: {
        Row: {
          id: string
          service_name: string
          provider: string
          purpose: string
          api_key_encrypted: string | null
          is_active: boolean
          priority_order: number
          model_name: string | null
          config: Json
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          service_name: string
          provider: string
          purpose: string
          api_key_encrypted?: string | null
          is_active?: boolean
          priority_order?: number
          model_name?: string | null
          config?: Json
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          service_name?: string
          provider?: string
          purpose?: string
          api_key_encrypted?: string | null
          is_active?: boolean
          priority_order?: number
          model_name?: string | null
          config?: Json
          created_at?: string
          updated_at?: string
        }
      }
      api_usage: {
        Row: {
          id: string
          service_id: string
          date: string
          tokens_used: number
          requests_count: number
          cost: number
          response_time_avg: number
          errors_count: number
          created_at: string
        }
        Insert: {
          id?: string
          service_id: string
          date?: string
          tokens_used?: number
          requests_count?: number
          cost?: number
          response_time_avg?: number
          errors_count?: number
          created_at?: string
        }
        Update: {
          id?: string
          service_id?: string
          date?: string
          tokens_used?: number
          requests_count?: number
          cost?: number
          response_time_avg?: number
          errors_count?: number
          created_at?: string
        }
      }
      api_limits: {
        Row: {
          id: string
          service_id: string
          monthly_token_limit: number | null
          monthly_request_limit: number | null
          current_usage: number
          reset_date: string
          expiration_date: string | null
          alert_threshold: number
          budget_limit: number | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          service_id: string
          monthly_token_limit?: number | null
          monthly_request_limit?: number | null
          current_usage?: number
          reset_date: string
          expiration_date?: string | null
          alert_threshold?: number
          budget_limit?: number | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          service_id?: string
          monthly_token_limit?: number | null
          monthly_request_limit?: number | null
          current_usage?: number
          reset_date?: string
          expiration_date?: string | null
          alert_threshold?: number
          budget_limit?: number | null
          created_at?: string
          updated_at?: string
        }
      }
      interactive_lessons: {
        Row: {
          id: string
          book_id: string
          reading_level: ReadingLevel
          lesson_type: LessonType
          lesson_data: Json
          title: string
          description: string | null
          difficulty: number
          order_index: number
          estimated_time: number | null
          voice_enabled: boolean
          ai_tutor_available: boolean
          difficulty_adaptive: boolean
          completion_rate: number
          average_score: number
          created_at: string
        }
        Insert: {
          id?: string
          book_id: string
          reading_level: ReadingLevel
          lesson_type: LessonType
          lesson_data?: Json
          title: string
          description?: string | null
          difficulty?: number
          order_index?: number
          estimated_time?: number | null
          voice_enabled?: boolean
          ai_tutor_available?: boolean
          difficulty_adaptive?: boolean
          completion_rate?: number
          average_score?: number
          created_at?: string
        }
        Update: {
          id?: string
          book_id?: string
          reading_level?: ReadingLevel
          lesson_type?: LessonType
          lesson_data?: Json
          title?: string
          description?: string | null
          difficulty?: number
          order_index?: number
          estimated_time?: number | null
          voice_enabled?: boolean
          ai_tutor_available?: boolean
          difficulty_adaptive?: boolean
          completion_rate?: number
          average_score?: number
          created_at?: string
        }
      }
      tutor_sessions: {
        Row: {
          id: string
          user_id: string | null
          book_id: string
          lesson_id: string | null
          conversation_log: Json
          questions_asked: number
          concepts_mastered: Json
          time_spent: number
          session_start: string
          session_end: string | null
          created_at: string
        }
        Insert: {
          id?: string
          user_id?: string | null
          book_id: string
          lesson_id?: string | null
          conversation_log?: Json
          questions_asked?: number
          concepts_mastered?: Json
          time_spent?: number
          session_start?: string
          session_end?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string | null
          book_id?: string
          lesson_id?: string | null
          conversation_log?: Json
          questions_asked?: number
          concepts_mastered?: Json
          time_spent?: number
          session_start?: string
          session_end?: string | null
          created_at?: string
        }
      }
      illustration_assets: {
        Row: {
          id: string
          book_id: string
          page_number: number
          asset_type: 'stock_photo' | 'diagram' | 'ai_generated' | 'infographic'
          source_url: string | null
          alt_text: string | null
          caption: string | null
          position_data: Json
          created_at: string
        }
        Insert: {
          id?: string
          book_id: string
          page_number: number
          asset_type: 'stock_photo' | 'diagram' | 'ai_generated' | 'infographic'
          source_url?: string | null
          alt_text?: string | null
          caption?: string | null
          position_data?: Json
          created_at?: string
        }
        Update: {
          id?: string
          book_id?: string
          page_number?: number
          asset_type?: 'stock_photo' | 'diagram' | 'ai_generated' | 'infographic'
          source_url?: string | null
          alt_text?: string | null
          caption?: string | null
          position_data?: Json
          created_at?: string
        }
      }
      user_preferences: {
        Row: {
          id: string
          user_id: string
          theme_preference: string | null
          language_preference: string | null
          learning_settings: Json
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          theme_preference?: string | null
          language_preference?: string | null
          learning_settings?: Json
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          theme_preference?: string | null
          language_preference?: string | null
          learning_settings?: Json
          created_at?: string
          updated_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}
