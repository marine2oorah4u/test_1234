import {
  modelRouter,
  MAXIMUM_QUALITY_PHASES,
  PhaseConfig,
  RoutingDecision,
  AI_MODELS,
} from '../config/maximumQualityModels';
import {
  consensusEngine,
  AIResponse,
  ConsensusResult,
  VerificationResult,
  Issue,
} from './multiAIConsensus';

export interface BookGenerationConfig {
  subject: string;
  gradeLevel: string;
  readingLevel: string;
  targetLength: number;
  specializations: string[];
  qualityTarget: number;
  maxIterations: number;
  enableMultiCloud: boolean;
}

export interface GenerationProgress {
  phase: string;
  progress: number;
  currentStep: string;
  aiResponses: number;
  totalAIs: number;
  qualityScore: number;
  estimatedCompletion: Date;
}

export interface GenerationResult {
  success: boolean;
  content: string;
  metadata: {
    totalAIsUsed: number;
    totalTokens: number;
    totalCost: number;
    qualityScore: number;
    iterations: number;
    timeElapsed: number;
  };
  phaseResults: Map<string, PhaseResult>;
  issues: Issue[];
}

export interface PhaseResult {
  phase: string;
  attempts: number;
  finalQuality: number;
  aiDecisions: RoutingDecision[];
  consensusResult?: ConsensusResult;
  verificationResults?: VerificationResult[];
}

export class MaximumQualityOrchestrator {
  private progressCallback?: (progress: GenerationProgress) => void;
  private currentGeneration: {
    startTime: Date;
    totalTokens: number;
    totalCost: number;
    aiCount: number;
  } | null = null;

  setProgressCallback(callback: (progress: GenerationProgress) => void) {
    this.progressCallback = callback;
  }

  async generateBook(config: BookGenerationConfig): Promise<GenerationResult> {
    this.currentGeneration = {
      startTime: new Date(),
      totalTokens: 0,
      totalCost: 0,
      aiCount: 0,
    };

    const phaseResults = new Map<string, PhaseResult>();
    let bookContent = '';
    let currentQuality = 0;
    let iteration = 0;

    try {
      const researchResult = await this.executePhase(
        'research',
        this.buildResearchPrompt(config),
        config
      );
      phaseResults.set('research', researchResult);
      this.reportProgress('research', 100, 'Research complete', researchResult.finalQuality);

      for (iteration = 0; iteration < config.maxIterations; iteration++) {
        const generationResult = await this.executePhase(
          'generation',
          this.buildGenerationPrompt(config, researchResult, bookContent),
          config
        );
        phaseResults.set(`generation-${iteration}`, generationResult);
        bookContent = generationResult.consensusResult?.finalContent || '';

        this.reportProgress('generation', ((iteration + 1) / config.maxIterations) * 100,
          `Generation iteration ${iteration + 1}`, generationResult.finalQuality);

        const verificationResult = await this.executePhase(
          'verification',
          this.buildVerificationPrompt(bookContent),
          config
        );
        phaseResults.set(`verification-${iteration}`, verificationResult);
        currentQuality = verificationResult.finalQuality;

        this.reportProgress('verification', ((iteration + 1) / config.maxIterations) * 100,
          `Verification iteration ${iteration + 1}`, currentQuality);

        if (currentQuality >= config.qualityTarget) {
          break;
        }

        if (currentQuality >= 0.70 && iteration < config.maxIterations - 1) {
          const refinementResult = await this.executePhase(
            'refinement',
            this.buildRefinementPrompt(bookContent, verificationResult.verificationResults || []),
            config
          );
          phaseResults.set(`refinement-${iteration}`, refinementResult);
          bookContent = refinementResult.consensusResult?.finalContent || bookContent;

          this.reportProgress('refinement', ((iteration + 1) / config.maxIterations) * 100,
            `Refinement iteration ${iteration + 1}`, refinementResult.finalQuality);
        }
      }

      if (currentQuality >= config.qualityTarget * 0.95) {
        const polishResult = await this.executePhase(
          'polish',
          this.buildPolishPrompt(bookContent),
          config
        );
        phaseResults.set('polish', polishResult);
        bookContent = polishResult.consensusResult?.finalContent || bookContent;

        this.reportProgress('polish', 100, 'Final polish complete', polishResult.finalQuality);
      }

      const allIssues = this.aggregateIssues(phaseResults);

      return {
        success: currentQuality >= config.qualityTarget * 0.90,
        content: bookContent,
        metadata: {
          totalAIsUsed: this.currentGeneration.aiCount,
          totalTokens: this.currentGeneration.totalTokens,
          totalCost: this.currentGeneration.totalCost,
          qualityScore: currentQuality,
          iterations: iteration + 1,
          timeElapsed: Date.now() - this.currentGeneration.startTime.getTime(),
        },
        phaseResults,
        issues: allIssues,
      };
    } finally {
      this.currentGeneration = null;
    }
  }

  private async executePhase(
    phaseName: string,
    prompt: string,
    config: BookGenerationConfig
  ): Promise<PhaseResult> {
    const phase = MAXIMUM_QUALITY_PHASES[phaseName as keyof typeof MAXIMUM_QUALITY_PHASES];
    if (!phase) throw new Error(`Unknown phase: ${phaseName}`);

    let attempt = 0;
    let bestResult: PhaseResult | null = null;

    while (attempt < phase.maxRetries) {
      attempt++;

      const aiDecisions = modelRouter.selectModels(phase);

      if (aiDecisions.length < phase.minAIs) {
        throw new Error(`Insufficient available AIs for ${phaseName}. Need ${phase.minAIs}, got ${aiDecisions.length}`);
      }

      const responses = await this.executeParallel(aiDecisions, prompt, config);

      let result: PhaseResult;

      if (phaseName === 'verification') {
        const verificationResults = this.parseVerificationResponses(responses);
        const consensusVerification = await consensusEngine.verifyWithConsensus(
          prompt,
          phase,
          verificationResults
        );

        result = {
          phase: phaseName,
          attempts: attempt,
          finalQuality: consensusVerification.overallQuality,
          aiDecisions,
          verificationResults,
        };
      } else {
        const consensusResult = await consensusEngine.generateWithConsensus(
          prompt,
          phase,
          responses
        );

        result = {
          phase: phaseName,
          attempts: attempt,
          finalQuality: consensusResult.qualityMetrics.overallScore,
          aiDecisions,
          consensusResult,
        };
      }

      if (result.finalQuality >= phase.qualityThreshold) {
        return result;
      }

      if (!bestResult || result.finalQuality > bestResult.finalQuality) {
        bestResult = result;
      }
    }

    return bestResult || {
      phase: phaseName,
      attempts: attempt,
      finalQuality: 0,
      aiDecisions: [],
    };
  }

  private async executeParallel(
    decisions: RoutingDecision[],
    prompt: string,
    config: BookGenerationConfig
  ): Promise<AIResponse[]> {
    const startTime = Date.now();

    const responses = await Promise.all(
      decisions.map(async (decision) => {
        const model = AI_MODELS[decision.modelId];

        const mockResponse = this.simulateAIResponse(decision.modelId, prompt, model);

        if (this.currentGeneration) {
          this.currentGeneration.totalTokens += mockResponse.metadata.tokens;
          this.currentGeneration.totalCost += decision.estimatedCost;
          this.currentGeneration.aiCount++;
        }

        modelRouter.recordUsage(
          decision.modelId,
          mockResponse.metadata.tokens,
          decision.location
        );

        return mockResponse;
      })
    );

    return responses;
  }

  private simulateAIResponse(modelId: string, prompt: string, model: any): AIResponse {
    const estimatedTokens = Math.floor(Math.random() * 5000) + 2000;
    const latency = model.speed.avgLatency + Math.random() * 500;

    return {
      modelId,
      content: this.generateMockContent(prompt, modelId),
      confidence: 0.85 + Math.random() * 0.12,
      metadata: {
        tokens: estimatedTokens,
        latency,
        timestamp: new Date(),
      },
    };
  }

  private generateMockContent(prompt: string, modelId: string): string {
    return `[${modelId}] Generated content based on: ${prompt.substring(0, 100)}...\n\nThis is simulated high-quality educational content.`;
  }

  private parseVerificationResponses(responses: AIResponse[]): VerificationResult[] {
    return responses.map((response) => {
      const qualityScore = response.confidence;
      const numIssues = Math.floor((1 - qualityScore) * 10);

      const issues: Issue[] = [];
      for (let i = 0; i < numIssues; i++) {
        issues.push({
          type: ['factual', 'grammar', 'logic', 'clarity', 'accessibility'][Math.floor(Math.random() * 5)] as any,
          severity: qualityScore > 0.9 ? 'low' : qualityScore > 0.8 ? 'medium' : 'high',
          location: `Section ${i + 1}`,
          description: `Issue detected by ${response.modelId}`,
        });
      }

      return {
        modelId: response.modelId,
        issues,
        qualityScore,
        passed: qualityScore >= 0.9,
      };
    });
  }

  private buildResearchPrompt(config: BookGenerationConfig): string {
    return `Research the following topic thoroughly:
Subject: ${config.subject}
Grade Level: ${config.gradeLevel}
Reading Level: ${config.readingLevel}
Specializations: ${config.specializations.join(', ')}

Provide comprehensive research covering:
1. Core concepts and learning objectives
2. Key facts and information
3. Real-world applications
4. Common misconceptions
5. Teaching strategies`;
  }

  private buildGenerationPrompt(
    config: BookGenerationConfig,
    researchResult: PhaseResult,
    previousContent: string
  ): string {
    return `Generate educational content based on research:
Subject: ${config.subject}
Grade Level: ${config.gradeLevel}
Reading Level: ${config.readingLevel}
Target Length: ${config.targetLength} words
${previousContent ? '\n\nImprove upon this previous version:\n' + previousContent : ''}`;
  }

  private buildVerificationPrompt(content: string): string {
    return `Verify the following educational content for:
1. Factual accuracy
2. Grammar and clarity
3. Logical flow
4. Accessibility
5. Age-appropriateness

Content to verify:
${content}`;
  }

  private buildRefinementPrompt(content: string, verifications: VerificationResult[]): string {
    const issues = verifications.flatMap(v => v.issues);
    return `Refine this content to address the following issues:
${issues.map(i => `- ${i.type}: ${i.description}`).join('\n')}

Content:
${content}`;
  }

  private buildPolishPrompt(content: string): string {
    return `Perform final polish on this educational content:
- Enhance readability
- Improve engagement
- Ensure consistency
- Add finishing touches

Content:
${content}`;
  }

  private aggregateIssues(phaseResults: Map<string, PhaseResult>): Issue[] {
    const allIssues: Issue[] = [];

    for (const result of phaseResults.values()) {
      if (result.verificationResults) {
        for (const verification of result.verificationResults) {
          allIssues.push(...verification.issues);
        }
      }
    }

    return allIssues
      .sort((a, b) => {
        const severityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
        return severityOrder[a.severity] - severityOrder[b.severity];
      })
      .slice(0, 20);
  }

  private reportProgress(phase: string, progress: number, step: string, qualityScore: number) {
    if (!this.progressCallback || !this.currentGeneration) return;

    const elapsed = Date.now() - this.currentGeneration.startTime.getTime();
    const estimatedTotal = (elapsed / progress) * 100;
    const estimatedCompletion = new Date(this.currentGeneration.startTime.getTime() + estimatedTotal);

    this.progressCallback({
      phase,
      progress,
      currentStep: step,
      aiResponses: this.currentGeneration.aiCount,
      totalAIs: 50,
      qualityScore,
      estimatedCompletion,
    });
  }

  getLoadBalancingStatus() {
    return modelRouter.getLoadBalancingStatus();
  }

  resetDailyQuotas() {
    modelRouter.resetDailyQuotas();
  }
}

export const maximumQualityOrchestrator = new MaximumQualityOrchestrator();
