import { createContext, useContext, useState, ReactNode, useEffect } from 'react';

interface AccessibilitySettings {
  textSize: number;
  textBold: boolean;
  highContrast: boolean;
  largeButtons: boolean;
  screenReaderMode: boolean;
  dyslexiaFont: boolean;
  colorBlindMode: boolean;
  reducedMotion: boolean;
}

interface AccessibilityContextType {
  settings: AccessibilitySettings;
  updateTextSize: (size: number) => void;
  updateTextBold: (bold: boolean) => void;
  updateHighContrast: (contrast: boolean) => void;
  updateLargeButtons: (large: boolean) => void;
  updateScreenReaderMode: (mode: boolean) => void;
  updateDyslexiaFont: (font: boolean) => void;
  updateColorBlindMode: (mode: boolean) => void;
  updateReducedMotion: (motion: boolean) => void;
  speak: (text: string) => void;
}

const AccessibilityContext = createContext<AccessibilityContextType | undefined>(undefined);

export function AccessibilityProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<AccessibilitySettings>({
    textSize: 16,
    textBold: false,
    highContrast: false,
    largeButtons: false,
    screenReaderMode: false,
    dyslexiaFont: false,
    colorBlindMode: false,
    reducedMotion: false,
  });

  useEffect(() => {
    document.documentElement.style.setProperty('--text-size', `${settings.textSize}px`);
    document.documentElement.style.setProperty('--font-weight', settings.textBold ? '700' : '400');

    if (settings.highContrast) {
      document.documentElement.classList.add('high-contrast');
    } else {
      document.documentElement.classList.remove('high-contrast');
    }

    if (settings.largeButtons) {
      document.documentElement.classList.add('large-buttons');
    } else {
      document.documentElement.classList.remove('large-buttons');
    }

    if (settings.screenReaderMode) {
      document.documentElement.classList.add('screen-reader-mode');
    } else {
      document.documentElement.classList.remove('screen-reader-mode');
    }

    if (settings.dyslexiaFont) {
      document.documentElement.classList.add('dyslexia-font');
    } else {
      document.documentElement.classList.remove('dyslexia-font');
    }

    if (settings.colorBlindMode) {
      document.documentElement.classList.add('color-blind-mode');
    } else {
      document.documentElement.classList.remove('color-blind-mode');
    }

    if (settings.reducedMotion) {
      document.documentElement.classList.add('reduced-motion');
    } else {
      document.documentElement.classList.remove('reduced-motion');
    }
  }, [settings]);

  const updateTextSize = (size: number) => {
    setSettings(prev => ({ ...prev, textSize: size }));
  };

  const updateTextBold = (bold: boolean) => {
    setSettings(prev => ({ ...prev, textBold: bold }));
  };

  const updateHighContrast = (contrast: boolean) => {
    setSettings(prev => ({ ...prev, highContrast: contrast }));
  };

  const updateLargeButtons = (large: boolean) => {
    setSettings(prev => ({ ...prev, largeButtons: large }));
  };

  const updateScreenReaderMode = (mode: boolean) => {
    setSettings(prev => ({ ...prev, screenReaderMode: mode }));
  };

  const updateDyslexiaFont = (font: boolean) => {
    setSettings(prev => ({ ...prev, dyslexiaFont: font }));
  };

  const updateColorBlindMode = (mode: boolean) => {
    setSettings(prev => ({ ...prev, colorBlindMode: mode }));
  };

  const updateReducedMotion = (motion: boolean) => {
    setSettings(prev => ({ ...prev, reducedMotion: motion }));
  };

  const speak = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.9;
      utterance.pitch = 1;
      utterance.volume = 1;
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <AccessibilityContext.Provider
      value={{
        settings,
        updateTextSize,
        updateTextBold,
        updateHighContrast,
        updateLargeButtons,
        updateScreenReaderMode,
        updateDyslexiaFont,
        updateColorBlindMode,
        updateReducedMotion,
        speak,
      }}
    >
      {children}
    </AccessibilityContext.Provider>
  );
}

export function useAccessibility() {
  const context = useContext(AccessibilityContext);
  if (context === undefined) {
    throw new Error('useAccessibility must be used within an AccessibilityProvider');
  }
  return context;
}
