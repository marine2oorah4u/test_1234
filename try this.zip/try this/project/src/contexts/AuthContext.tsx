import { createContext, useContext, useEffect, useState } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  isAdmin: boolean;
  isApproved: boolean;
  approvalStatus: 'pending' | 'approved' | 'rejected' | null;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isApproved, setIsApproved] = useState(false);
  const [approvalStatus, setApprovalStatus] = useState<'pending' | 'approved' | 'rejected' | null>(null);

  const checkApprovalStatus = async (userId: string, userIsAdmin: boolean) => {
    try {
      // Admins are always approved
      if (userIsAdmin) {
        setIsApproved(true);
        setApprovalStatus('approved');
        return;
      }

      const { data, error } = await supabase
        .from('user_approvals')
        .select('status')
        .eq('user_id', userId)
        .maybeSingle();

      if (error) {
        console.error('Error checking approval status:', error);
        // If no approval record exists (first user), they're approved
        setIsApproved(true);
        setApprovalStatus(null);
        return;
      }

      if (!data) {
        // No approval record means first user or admin, approve them
        setIsApproved(true);
        setApprovalStatus(null);
      } else {
        setApprovalStatus(data.status as 'pending' | 'approved' | 'rejected');
        setIsApproved(data.status === 'approved');
      }
    } catch (error) {
      console.error('Error checking approval status:', error);
      setIsApproved(true);
      setApprovalStatus(null);
    }
  };

  useEffect(() => {
    supabase.auth.getSession().then(async ({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        const { data: adminData } = await supabase
          .from('user_roles')
          .select('role')
          .eq('user_id', session.user.id)
          .eq('role', 'admin')
          .maybeSingle();

        const userIsAdmin = !!adminData;
        setIsAdmin(userIsAdmin);
        await checkApprovalStatus(session.user.id, userIsAdmin);
      } else {
        setIsAdmin(false);
        setIsApproved(false);
        setApprovalStatus(null);
      }
      setLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      (async () => {
        setSession(session);
        setUser(session?.user ?? null);
        if (session?.user) {
          const { data: adminData } = await supabase
            .from('user_roles')
            .select('role')
            .eq('user_id', session.user.id)
            .eq('role', 'admin')
            .maybeSingle();

          const userIsAdmin = !!adminData;
          setIsAdmin(userIsAdmin);
          await checkApprovalStatus(session.user.id, userIsAdmin);
        } else {
          setIsAdmin(false);
          setIsApproved(false);
          setApprovalStatus(null);
        }
        setLoading(false);
      })();
    });

    return () => subscription.unsubscribe();
  }, []);

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    if (error) throw error;
  };

  const signUp = async (email: string, password: string) => {
    const { error } = await supabase.auth.signUp({
      email,
      password,
    });
    if (error) throw error;
  };

  const signOut = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  };

  return (
    <AuthContext.Provider value={{ user, session, loading, isAdmin, isApproved, approvalStatus, signIn, signUp, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
