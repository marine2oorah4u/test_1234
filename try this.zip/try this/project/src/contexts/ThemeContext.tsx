import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Theme, ThemeContextType } from '../types/theme.types';
import { ALL_THEMES, getThemeById, ADMIN_THEMES } from '../config/themes';
import { supabase } from '../lib/supabase';
import { useAuth } from './AuthContext';

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

interface ThemeProviderProps {
  children: ReactNode;
  category?: 'admin' | 'demo';
}

export const ThemeProvider: React.FC<ThemeProviderProps> = ({ children, category = 'admin' }) => {
  const { user } = useAuth();
  const [currentTheme, setCurrentTheme] = useState<Theme>(ADMIN_THEMES[0]);
  const [loading, setLoading] = useState(true);

  const availableThemes = ALL_THEMES.filter(theme => theme.category === category);

  useEffect(() => {
    loadUserTheme();
  }, [user, category]);

  useEffect(() => {
    applyThemeToDocument(currentTheme);
  }, [currentTheme]);

  const loadUserTheme = async () => {
    setLoading(true);
    try {
      if (user) {
        const { data, error } = await supabase
          .from('user_preferences')
          .select('theme_id, theme_category')
          .eq('user_id', user.id)
          .maybeSingle();

        if (error) throw error;

        if (data && data.theme_category === category) {
          const theme = getThemeById(data.theme_id);
          if (theme) {
            setCurrentTheme(theme);
          }
        } else {
          setCurrentTheme(availableThemes[0]);
        }
      } else {
        const savedThemeId = localStorage.getItem(`theme_${category}`);
        if (savedThemeId) {
          const theme = getThemeById(savedThemeId);
          if (theme && theme.category === category) {
            setCurrentTheme(theme);
          } else {
            setCurrentTheme(availableThemes[0]);
          }
        } else {
          setCurrentTheme(availableThemes[0]);
        }
      }
    } catch (error) {
      console.error('Error loading theme:', error);
      setCurrentTheme(availableThemes[0]);
    } finally {
      setLoading(false);
    }
  };

  const setTheme = async (themeId: string) => {
    const theme = getThemeById(themeId);
    if (!theme || theme.category !== category) return;

    setCurrentTheme(theme);

    try {
      if (user) {
        const { error } = await supabase
          .from('user_preferences')
          .upsert({
            user_id: user.id,
            theme_id: themeId,
            theme_category: category,
          }, {
            onConflict: 'user_id',
          });

        if (error) throw error;
      } else {
        localStorage.setItem(`theme_${category}`, themeId);
      }
    } catch (error) {
      console.error('Error saving theme:', error);
    }
  };

  const applyThemeToDocument = (theme: Theme) => {
    const root = document.documentElement;

    Object.entries(theme.colors).forEach(([key, value]) => {
      root.style.setProperty(`--color-${key}`, value);
    });

    if (theme.patterns?.backgroundImage) {
      root.style.setProperty('--bg-pattern', theme.patterns.backgroundImage);
    } else {
      root.style.setProperty('--bg-pattern', 'none');
    }

    if (theme.patterns?.backgroundWallpaper) {
      const wallpaperUrl = theme.patterns.backgroundWallpaper;
      root.style.setProperty('--bg-wallpaper', `url("${wallpaperUrl}")`);
      root.style.setProperty('--wallpaper-opacity', String(theme.patterns.wallpaperOpacity || 0.15));
    } else {
      root.style.setProperty('--bg-wallpaper', 'none');
      root.style.setProperty('--wallpaper-opacity', '0');
    }

    if (theme.animations?.glowColor) {
      root.style.setProperty('--glow-color', theme.animations.glowColor);
    }

    root.style.setProperty('--transition', theme.animations.transition);

    if (theme.fontFamily) {
      root.style.setProperty('--font-theme', theme.fontFamily);
    }
  };

  const value: ThemeContextType = {
    currentTheme,
    availableThemes,
    setTheme,
    loading,
  };

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
};
