import { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ThemeProvider } from './contexts/ThemeContext';
import { AccessibilityProvider } from './contexts/AccessibilityContext';
import { LoginPage } from './components/LoginPage';
import { DashboardLayout } from './components/DashboardLayout';
import { OverviewPage } from './pages/OverviewPage';
import { GenerateBookPage } from './pages/GenerateBookPage';
import { BooksLibraryPage } from './pages/BooksLibraryPage';
import { APIServicesPage } from './pages/APIServicesPage';
import { UsageMonitorPage } from './pages/UsageMonitorPage';
import { DemoHomePage } from './pages/DemoHomePage';
import { DemoAddonsPage } from './pages/DemoAddonsPage';
import { DemoPipelineWalkthroughPage } from './pages/DemoPipelineWalkthroughPage';
import { DemoStepWalkthroughPage } from './pages/DemoStepWalkthroughPage';
import { DemoResourcesPage } from './pages/DemoResourcesPage';
import { DemoAboutPage } from './pages/DemoAboutPage';
import { DemoRoadmapPage } from './pages/DemoRoadmapPage';
import { DemoThemeSelector } from './components/DemoThemeSelector';
import { ThemeDecorations } from './components/ThemeDecorations';
import { SystemDiagnosticsPage } from './pages/SystemDiagnosticsPage';
import { APIKeysManagementPage } from './pages/APIKeysManagementPage';
import { LoadBalancingDashboard } from './pages/LoadBalancingDashboard';
import { ComprehensiveMonitorPage } from './pages/ComprehensiveMonitorPage';
import { AdminRoleManagementPage } from './pages/AdminRoleManagementPage';
import { WorkflowEditorPage } from './pages/WorkflowEditorPage';
import { UserApprovalPage } from './pages/UserApprovalPage';
import { ScoutsGenerationPage } from './pages/ScoutsGenerationPage';
import { StressTestPage } from './pages/StressTestPage';
import { PipelineManagementPage } from './pages/PipelineManagementPage';
import { LanguageSelectionPage } from './pages/LanguageSelectionPage';
import { Activity } from 'lucide-react';
import { supabase } from './lib/supabase';

type AppMode = 'demo-home' | 'demo-addons' | 'demo-walkthrough' | 'demo-step-walkthrough' | 'demo-resources' | 'demo-about' | 'demo-roadmap' | 'login' | 'app';

function AppContent() {
  const { user, loading, isAdmin, isApproved, approvalStatus } = useAuth();
  const [currentPage, setCurrentPage] = useState('overview');
  const [mode, setMode] = useState<AppMode>('demo-home');

  useEffect(() => {
    const handleNavigate = (e: Event) => {
      const customEvent = e as CustomEvent;
      setCurrentPage(customEvent.detail.page);
    };

    window.addEventListener('navigate', handleNavigate);
    return () => window.removeEventListener('navigate', handleNavigate);
  }, []);

  useEffect(() => {
    // After successful login from login page
    if (user && mode === 'login') {
      if (isAdmin) {
        setMode('app');
      } else {
        setMode('demo-home');
      }
    }

    // Handle logout
    if (!user && mode === 'app') {
      setMode('demo-home');
    }
  }, [user, isAdmin, mode]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--color-background)' }}>
        <Activity className="w-8 h-8 animate-spin" style={{ color: 'var(--color-primary)' }} />
      </div>
    );
  }

  if (mode === 'demo-home') {
    return (
      <ThemeProvider category="demo">
        <ThemeDecorations />
        <DemoHomePage
          onNavigate={(page) => {
            if (page === 'addons') setMode('demo-addons');
            else if (page === 'walkthrough') setMode('demo-walkthrough');
            else if (page === 'step-walkthrough') setMode('demo-step-walkthrough');
            else if (page === 'resources') setMode('demo-resources');
            else if (page === 'about') setMode('demo-about');
            else if (page === 'roadmap') setMode('demo-roadmap');
            else if (page === 'overview') {
              setCurrentPage('overview');
              setMode('app');
            }
          }}
          onSignUp={() => setMode('login')}
        />
        <DemoThemeSelector />
      </ThemeProvider>
    );
  }


  if (mode === 'demo-addons') {
    return (
      <ThemeProvider category="demo">
        <ThemeDecorations />
        <DemoAddonsPage
          onBack={() => setMode('demo-home')}
          onNavigate={(page) => {
            if (page === 'overview') {
              setCurrentPage('overview');
              setMode('app');
            }
          }}
        />
        <DemoThemeSelector />
      </ThemeProvider>
    );
  }


  if (mode === 'demo-walkthrough') {
    return (
      <ThemeProvider category="demo">
        <ThemeDecorations />
        <DemoPipelineWalkthroughPage
          onBack={() => setMode('demo-home')}
          onNavigate={(page) => {
            if (page === 'overview') {
              setCurrentPage('overview');
              setMode('app');
            }
          }}
        />
        <DemoThemeSelector />
      </ThemeProvider>
    );
  }

  if (mode === 'demo-step-walkthrough') {
    return (
      <ThemeProvider category="demo">
        <ThemeDecorations />
        <DemoStepWalkthroughPage
          onBack={() => setMode('demo-home')}
          onNavigate={(page) => {
            if (page === 'overview') {
              setCurrentPage('overview');
              setMode('app');
            }
          }}
        />
        <DemoThemeSelector />
      </ThemeProvider>
    );
  }

  if (mode === 'demo-resources') {
    return (
      <ThemeProvider category="demo">
        <ThemeDecorations />
        <DemoResourcesPage
          onBack={() => setMode('demo-home')}
          onNavigate={(page) => {
            if (page === 'overview') {
              setCurrentPage('overview');
              setMode('app');
            }
          }}
        />
        <DemoThemeSelector />
      </ThemeProvider>
    );
  }

  if (mode === 'demo-about') {
    return (
      <ThemeProvider category="demo">
        <ThemeDecorations />
        <DemoAboutPage
          onBack={() => setMode('demo-home')}
          onNavigate={(page) => {
            if (page === 'overview') {
              setCurrentPage('overview');
              setMode('app');
            }
          }}
        />
        <DemoThemeSelector />
      </ThemeProvider>
    );
  }

  if (mode === 'demo-roadmap') {
    return (
      <ThemeProvider category="demo">
        <ThemeDecorations />
        <DemoRoadmapPage
          onBack={() => setMode('demo-home')}
          onNavigate={(page) => {
            if (page === 'overview') {
              setCurrentPage('overview');
              setMode('app');
            }
          }}
        />
        <DemoThemeSelector />
      </ThemeProvider>
    );
  }

  if (mode === 'login') {
    return (
      <ThemeProvider category="demo">
        <LoginPage />
      </ThemeProvider>
    );
  }

  if (!user) {
    return (
      <ThemeProvider category="demo">
        <LoginPage />
      </ThemeProvider>
    );
  }

  if (user && !isApproved && !isAdmin) {
    return (
      <ThemeProvider category="demo">
        <div className="min-h-screen bg-gradient-to-br from-blue-50 to-slate-100 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-xl p-8">
            <div className="text-center">
              {approvalStatus === 'pending' && (
                <>
                  <div className="bg-yellow-100 p-4 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center">
                    <Activity className="w-10 h-10 text-yellow-600" />
                  </div>
                  <h1 className="text-2xl font-bold text-gray-900 mb-2">Approval Pending</h1>
                  <p className="text-gray-600 mb-6">
                    Your account is awaiting approval from an administrator. You will be notified via email once your account is approved.
                  </p>
                </>
              )}
              {approvalStatus === 'rejected' && (
                <>
                  <div className="bg-red-100 p-4 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center">
                    <Activity className="w-10 h-10 text-red-600" />
                  </div>
                  <h1 className="text-2xl font-bold text-gray-900 mb-2">Account Rejected</h1>
                  <p className="text-gray-600 mb-6">
                    Your account request has been rejected by an administrator. Please contact support for more information.
                  </p>
                </>
              )}
              <button
                onClick={async () => {
                  await supabase.auth.signOut();
                  window.location.reload();
                }}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2.5 px-4 rounded-lg transition"
              >
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </ThemeProvider>
    );
  }

  if (!isAdmin && mode !== 'app') {
    return (
      <ThemeProvider category="demo">
        <ThemeDecorations />
        <DemoHomePage
          onNavigate={(page) => {
            if (page === 'addons') setMode('demo-addons');
            else if (page === 'walkthrough') setMode('demo-walkthrough');
            else if (page === 'step-walkthrough') setMode('demo-step-walkthrough');
            else if (page === 'resources') setMode('demo-resources');
            else if (page === 'about') setMode('demo-about');
            else if (page === 'roadmap') setMode('demo-roadmap');
          }}
          onSignUp={() => setMode('login')}
        />
        <DemoThemeSelector />
      </ThemeProvider>
    );
  }

  // If mode is 'app' and user is admin, show admin dashboard
  if (mode === 'app' && isAdmin) {
    const renderPage = () => {
      switch (currentPage) {
        case 'overview':
          return <OverviewPage />;
        case 'generate':
          return <GenerateBookPage />;
        case 'library':
          return <BooksLibraryPage />;
        case 'api-services':
          return <APIServicesPage />;
        case 'api-keys':
          return <APIKeysManagementPage />;
        case 'usage':
          return <UsageMonitorPage />;
        case 'diagnostics':
          return <SystemDiagnosticsPage />;
        case 'load-balancing':
          return <LoadBalancingDashboard />;
        case 'monitor':
          return <ComprehensiveMonitorPage />;
        case 'admin-roles':
          return <AdminRoleManagementPage />;
        case 'user-approvals':
          return <UserApprovalPage />;
        case 'workflow-editor':
          return <WorkflowEditorPage />;
        case 'scouts':
          return <ScoutsGenerationPage />;
        case 'stress-test':
          return <StressTestPage />;
        case 'pipelines':
          return <PipelineManagementPage />;
        case 'languages':
          return <LanguageSelectionPage />;
        case 'demo-home':
          setMode('demo-home');
          return null;
        default:
          return <OverviewPage />;
      }
    };

    return (
      <ThemeProvider category="admin">
        <DashboardLayout currentPage={currentPage} onNavigate={setCurrentPage}>
          {renderPage()}
        </DashboardLayout>
      </ThemeProvider>
    );
  }

  // Fallback to demo home
  return (
    <ThemeProvider category="demo">
      <ThemeDecorations />
      <DemoHomePage
        onNavigate={(page) => {
          if (page === 'addons') setMode('demo-addons');
          else if (page === 'walkthrough') setMode('demo-walkthrough');
          else if (page === 'step-walkthrough') setMode('demo-step-walkthrough');
          else if (page === 'resources') setMode('demo-resources');
          else if (page === 'about') setMode('demo-about');
          else if (page === 'roadmap') setMode('demo-roadmap');
          else if (page === 'overview') {
            setCurrentPage('overview');
            setMode('app');
          }
        }}
        onSignUp={() => setMode('login')}
      />
      <DemoThemeSelector />
    </ThemeProvider>
  );
}

function App() {
  return (
    <AuthProvider>
      <AccessibilityProvider>
        <AppContent />
      </AccessibilityProvider>
    </AuthProvider>
  );
}

export default App;
