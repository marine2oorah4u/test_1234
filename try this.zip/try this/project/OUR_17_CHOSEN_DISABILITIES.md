# Our 17 Chosen Disabilities - Why We Picked Each One

## Selection Criteria
1. **High Prevalence** - Affects significant population
2. **Direct Learning Impact** - Causes hard time learning or reading in school
3. **Addressable** - They CAN benefit from educational materials with accommodations
4. **Real-World Struggle** - Not just a disease where they can do fine in school

---

## KEEP: 11 From Current Pipelines (Already Built)

### 1. Dyslexia (35M people, 10.5%)
**Pipeline:** 3.24
**Why We Chose It:**
- Most common learning disability
- Directly affects ability to read and decode text
- **Struggle:** Cannot decode text despite high intelligence - letters flip, words blur
- **Why It Works:** They CAN learn with dyslexic fonts, text-to-speech, larger spacing
- **Impact Scores:** Reading 10/10, Comprehension 8/10

### 2. ADHD (17M people, 8%)
**Pipeline:** 3.25
**Why We Chose It:**
- Extremely common, affects ALL learning
- **Struggle:** Constant distraction prevents completing anything - brain jumps around
- **Why It Works:** They CAN focus with chunked content, built-in breaks, clear structure
- **Impact Scores:** Focus/Attention 10/10, Memory 7/10, Processing 7/10

### 3. Dyscalculia (20M people, 6%)
**Pipeline:** 3.29
**Why We Chose It:**
- Math-specific learning disability, affects STEM learning
- **Struggle:** Cannot understand numbers or quantities - math is gibberish
- **Why It Works:** They CAN learn with visual models, manipulatives, step-by-step breakdowns
- **Impact Scores:** Reading 3/10, Comprehension 5/10, but crucial for math content

### 4. Color Blindness (13M people, 4%)
**Pipeline:** 3.26
**Why We Chose It:**
- Very common, easy to fix
- **Struggle:** Cannot use color-coded information - charts/graphs are useless
- **Why It Works:** They CAN see with patterns, labels instead of colors, high contrast
- **Impact Scores:** Reading 5/10 (when color is used for emphasis)

### 5. Blind and Low Vision (11.5M people, 3.5%)
**Pipeline:** 3.28
**Why We Chose It:**
- Federal law requires accessibility (ADA)
- **Struggle:** Cannot access visual materials at all
- **Why It Works:** They CAN access via screen readers, braille, audio descriptions
- **Impact Scores:** Reading 10/10 (without accommodations)

### 6. Deaf and Hard of Hearing (11M people, 3.3%)
**Pipeline:** 3.27
**Why We Chose It:**
- Federal law requires accessibility (ADA)
- **Struggle:** Cannot access audio content or spoken instructions
- **Why It Works:** They CAN learn through visual text, captions, written materials
- **Impact Scores:** Reading 8/10 (miss audio cues), Comprehension 5/10

### 7. Intellectual Disability (6.5M people, 2%)
**Pipeline:** 3.30
**Why We Chose It:**
- Cannot access grade-level content
- **Struggle:** Content is too complex - vocabulary too hard, concepts too abstract
- **Why It Works:** They CAN learn with simplified language, shorter sentences, more visuals
- **Impact Scores:** Comprehension 9/10, Reading 7/10, Memory 8/10

### 8. Executive Function Disorder (3M people, 1%)
**Pipeline:** 3.32
**Why We Chose It:**
- Affects ability to organize and plan complex learning
- **Struggle:** Cannot organize information, plan multi-step tasks, track progress
- **Why It Works:** They CAN succeed with explicit step-by-step instructions, checklists, visual organization
- **Impact Scores:** Focus 7/10, Memory 6/10

### 9. Autism Level 1 (3M people, 1%)
**Pipeline:** 3.43
**Why We Chose It:**
- Social/sensory issues disrupt learning environment
- **Struggle:** Unpredictability causes anxiety, sensory overload prevents focus
- **Why It Works:** They CAN learn with predictable structure, clear expectations, reduced sensory input
- **Impact Scores:** Focus 7/10, Comprehension 5/10

### 10. Autism Level 2 (1.5M people, 0.5%)
**Pipeline:** 3.44
**Why We Chose It:**
- Cannot function without routine and visual supports
- **Struggle:** Need substantial accommodations, cannot adapt to changes
- **Why It Works:** They CAN learn with visual schedules, social stories, AAC devices
- **Impact Scores:** Focus 8/10, Comprehension 7/10, Reading 6/10

### 11. Autism Level 3 (500K people, 0.2%)
**Pipeline:** 3.45
**Why We Chose It:**
- Cannot access typical materials at all
- **Struggle:** Severe communication deficits, need comprehensive support
- **Why It Works:** They CAN learn with picture-based materials, AAC, sensory modifications
- **Impact Scores:** Reading 8/10, Comprehension 9/10, Focus 9/10

---

## ADD: 6 New High-Impact Disabilities (Must Build)

### 12. Irlen Syndrome (43M people, 13%)
**Pipeline:** NEW - MUST ADD
**Why We Chose It:**
- MASSIVE prevalence - more than dyslexia
- **Struggle:** Reading causes physical pain - eye strain, headaches, words move on page
- **Why It Works:** They CAN read comfortably with colored backgrounds, different fonts, overlays
- **Impact Scores:** Reading 9/10, Focus 6/10
- **Easy Win:** Simple color/background changes help millions

### 13. Dysgraphia (35M people, 10.5%)
**Pipeline:** NEW - MUST ADD
**Why We Chose It:**
- As common as dyslexia but affects OUTPUT not input
- **Struggle:** Understand perfectly but cannot write or type - hand won't cooperate with brain
- **Why It Works:** They CAN show knowledge with speech-to-text, typing, oral responses
- **Impact Scores:** Writing 10/10, but Reading/Comprehension are fine
- **Critical:** Without this, they can't prove they learned anything

### 14. OWL LD (Oral & Written Language) (13M people, 4%)
**Pipeline:** NEW - MUST ADD
**Why We Chose It:**
- Both spoken AND written language affected
- **Struggle:** All language-based learning is extremely difficult - need heavy scaffolding
- **Why It Works:** They CAN learn with extensive visual supports, simplified language
- **Impact Scores:** Comprehension 9/10, Reading 7/10, Processing 7/10

### 15. FASD (Fetal Alcohol Spectrum) (5M people, 1.5%)
**Pipeline:** NEW - MUST ADD
**Why We Chose It:**
- More common than autism, permanent brain damage
- **Struggle:** Brain damage creates barriers in executive function and memory
- **Why It Works:** They CAN learn with extensive memory aids, explicit structure, repetition
- **Impact Scores:** Focus 8/10, Memory 8/10, Processing 7/10

### 16. Central Auditory Processing Disorder (2.5M people, 0.75%)
**Pipeline:** NEW - MUST ADD
**Why We Chose It:**
- Often misdiagnosed as ADHD
- **Struggle:** Ears work fine but brain scrambles what they hear - sounds are garbled
- **Why It Works:** They CAN learn through visual instructions, written text, captions
- **Impact Scores:** Comprehension 7/10, Focus 7/10, Reading 6/10, Processing 7/10

### 17. Down Syndrome (400K people, 0.12%)
**Pipeline:** NEW - MUST ADD
**Why We Chose It:**
- Common chromosomal disorder with intellectual disability
- **Struggle:** Need heavily modified materials - standard content too complex
- **Why It Works:** They CAN learn with simplified language, pictures, concrete examples
- **Impact Scores:** Comprehension 8/10, Reading 7/10, Memory 7/10, Processing 7/10

---

## Total Impact

**17 Disabilities covering 220.9M people (70% of US population)**

**Keep:** 11 (already built)
**Add:** 6 (must build)

**All 17 meet criteria:**
✅ High prevalence
✅ Causes hard time learning in school
✅ CAN benefit from educational materials with proper accommodations
✅ Real learning struggles, not just general diseases

---

## What We Rejected and Why

We removed 26 disabilities from the original 43 because:

1. **General Diseases** (cancer, diabetes, epilepsy, MS, Parkinson's, etc.) - They can do fine in school, no learning disability
2. **Physical-Only** (chronic pain, mobility, spinal cord, muscular dystrophy) - No cognitive/learning impact
3. **Cannot Process Information** (reading comprehension deficit, language processing disorder) - If they can't understand reading or talking, they can't benefit from books
4. **Mental Health** (depression, anxiety, OCD, PTSD, bipolar, schizophrenia) - Not learning disabilities, different interventions needed
5. **Low Prevalence + Low Impact** (speech disorders, voice disorders, selective mutism) - Very small populations with minimal learning impact

**Result:** 100% of our 17 pipelines are high-impact and addressable vs 51% of the original 43.
