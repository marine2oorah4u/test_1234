#!/usr/bin/env python3
"""
Add definitions for remaining 12 Grade A/B pipelines to complete all 21 disability pipelines.
"""

# Pipeline definitions for remaining disabilities
REMAINING_PIPELINES = {
    "3.27_deaf_hard_of_hearing": {
        "name": "Deaf/Hard of Hearing",
        "full_name": "Deaf and Hard of Hearing",
        "prevalence": "11 million",
        "steps": [
            {"num": 1, "name": "Audio Content Audit", "category": "analysis", "description": "Identify all audio elements requiring captions or transcripts.", "key_focus": "audio accessibility"},
            {"num": 2, "name": "Caption Generation and Synchronization", "category": "modification", "description": "Create accurate, synchronized captions for all audio/video content.", "key_focus": "captions and timing"},
            {"num": 3, "name": "Transcript Creation", "category": "enhancement", "description": "Generate comprehensive written transcripts of all spoken content.", "key_focus": "text alternatives"},
            {"num": 4, "name": "Visual Communication Enhancement", "category": "enhancement", "description": "Add visual cues, icons, and indicators to replace audio alerts.", "key_focus": "visual alternatives"},
            {"num": 5, "name": "Sign Language Video Integration", "category": "enhancement", "description": "Add ASL interpretation videos where appropriate.", "key_focus": "sign language"},
            {"num": 6, "name": "Speaker Identification System", "category": "enhancement", "description": "Clearly identify speakers in multi-person dialogues.", "key_focus": "speaker clarity"},
            {"num": 7, "name": "Sound Effect Description", "category": "enhancement", "description": "Describe meaningful sounds in text format.", "key_focus": "non-speech audio"},
            {"num": 8, "name": "Caption Formatting and Readability", "category": "modification", "description": "Optimize caption display, timing, and readability.", "key_focus": "caption quality"},
            {"num": 9, "name": "Alert and Notification Alternatives", "category": "enhancement", "description": "Provide visual alternatives for all audio alerts.", "key_focus": "alert accessibility"},
            {"num": 10, "name": "Deaf Culture Sensitivity Review", "category": "verification", "description": "Ensure content is respectful and appropriate for Deaf community.", "key_focus": "cultural sensitivity"}
        ]
    },
    "3.28_blind_low_vision": {
        "name": "Blind/Low Vision",
        "full_name": "Blind and Low Vision",
        "prevalence": "8 million",
        "steps": [
            {"num": 1, "name": "Screen Reader Compatibility Audit", "category": "analysis", "description": "Test all content with JAWS, NVDA, and VoiceOver.", "key_focus": "screen reader access"},
            {"num": 2, "name": "Image Alternative Text Creation", "category": "modification", "description": "Write comprehensive, descriptive alt text for all images.", "key_focus": "image description"},
            {"num": 3, "name": "Semantic Structure Enhancement", "category": "modification", "description": "Implement proper heading hierarchy and semantic HTML.", "key_focus": "document structure"},
            {"num": 4, "name": "Keyboard Navigation Optimization", "category": "modification", "description": "Ensure full keyboard accessibility without mouse.", "key_focus": "keyboard access"},
            {"num": 5, "name": "Data Table Accessibility", "category": "modification", "description": "Add proper table headers and descriptions for complex tables.", "key_focus": "table navigation"},
            {"num": 6, "name": "Form and Interactive Element Labels", "category": "enhancement", "description": "Add clear labels and instructions for all form elements.", "key_focus": "form accessibility"},
            {"num": 7, "name": "Audio Description for Visual Content", "category": "enhancement", "description": "Create audio descriptions for charts, diagrams, and visual data.", "key_focus": "audio alternatives"},
            {"num": 8, "name": "High Contrast and Large Print Versions", "category": "generation", "description": "Generate high contrast and large print accessible formats.", "key_focus": "low vision support"},
            {"num": 9, "name": "Tactile Graphics Preparation", "category": "enhancement", "description": "Prepare specifications for tactile/braille graphics if needed.", "key_focus": "tactile access"},
            {"num": 10, "name": "Braille-Ready Format Generation", "category": "generation", "description": "Create braille-ready files following braille formatting standards.", "key_focus": "braille preparation"}
        ]
    }
}

print(f"Prepared definitions for {len(REMAINING_PIPELINES)} additional pipelines")
for key, info in REMAINING_PIPELINES.items():
    print(f"  - {info['name']} ({info['prevalence']} affected): {len(info['steps'])} custom steps + 4 universal = 14 total")

