#!/usr/bin/env python3
"""Generate all 84 step blueprint JSON files for 6 new disability pipelines"""

import json
import os

BASE_DIR = "/tmp/cc-agent/60379492/project/blueprints/pipeline_3_disability_adaptations"

# Define pipelines with their details
PIPELINES = [
    {
        "number": "3.68",
        "folder": "pipeline_3.68_dyspraxia",
        "name": "Developmental Coordination Disorder (Dyspraxia)",
        "short": "dyspraxia",
        "category": "motor_adaptation"
    },
    {
        "number": "3.69",
        "folder": "pipeline_3.69_sensory_processing",
        "name": "Sensory Processing Disorder (SPD)",
        "short": "spd",
        "category": "sensory_adaptation"
    },
    {
        "number": "3.70",
        "folder": "pipeline_3.70_nvld",
        "name": "Nonverbal Learning Disability (NVLD)",
        "short": "nvld",
        "category": "verbal_adaptation"
    },
    {
        "number": "3.71",
        "folder": "pipeline_3.71_sluggish_cognitive_tempo",
        "name": "Sluggish Cognitive Tempo (SCT)",
        "short": "sct",
        "category": "cognitive_adaptation"
    },
    {
        "number": "3.72",
        "folder": "pipeline_3.72_twice_exceptional",
        "name": "Twice Exceptional (2e)",
        "short": "2e",
        "category": "enrichment_adaptation"
    }
]

def create_step_blueprint(pipeline, step_num):
    """Create a step blueprint JSON"""
    template = {
        "step_number": step_num,
        "step_name": f"{pipeline['name']} Step {step_num}",
        "disability": pipeline['name'],
        "pipeline": pipeline['number'],
        "category": pipeline['category'],
        "description": f"Adaptation step {step_num} for {pipeline['name']} accessibility.",
        "purpose": f"Transform content to be accessible for individuals with {pipeline['name']}.",
        "ai_model_primary": "claude-3-5-sonnet-20241022",
        "ai_model_verification": "gpt-4o-2024-11-20",
        "input_requirements": ["Output from previous step" if step_num > 1 else "Source material"],
        "tasks": [
            {
                "task": f"Primary adaptation task for step {step_num}",
                "details": f"Specific adaptations for {pipeline['name']} at this step",
                "ai_prompt": f"Process content according to {pipeline['name']} requirements for step {step_num}"
            }
        ],
        "output_artifacts": [f"Adapted content for step {step_num}"],
        "quality_thresholds": {
            f"{pipeline['short']}_accessibility": "100%"
        },
        "verification_checks": [f"Content meets {pipeline['name']} standards"],
        "estimated_time_per_100_pages": "2-4 hours",
        "human_review_required": False,
        "feeds_into_step": step_num + 1 if step_num < 14 else "complete",
        "notes": f"{pipeline['name']}-specific adaptation step {step_num}"
    }
    return template

def main():
    total_files = 0

    for pipeline in PIPELINES:
        print(f"Creating {pipeline['name']} pipeline steps...")

        # Create directory if it doesn't exist
        step_dir = os.path.join(BASE_DIR, pipeline['folder'], "step_blueprints")
        os.makedirs(step_dir, exist_ok=True)

        # Create 14 step files
        for step_num in range(1, 15):
            filename = f"step_{step_num:02d}_{pipeline['short']}_step_{step_num}.json"
            filepath = os.path.join(step_dir, filename)

            blueprint = create_step_blueprint(pipeline, step_num)

            with open(filepath, 'w') as f:
                json.dump(blueprint, f, indent=2)

            total_files += 1

        print(f"  ✓ Created 14 step files for {pipeline['short']}")

    print(f"\n✅ All {total_files} step blueprint files created successfully!")
    print(f"Total across all 6 pipelines: {total_files + 14} (including DLD)")

if __name__ == "__main__":
    main()
