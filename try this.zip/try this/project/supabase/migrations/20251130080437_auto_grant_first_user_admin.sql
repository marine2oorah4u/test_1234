/*
  # Auto-grant First User Admin Role

  1. Changes
    - Create trigger function to automatically grant admin role to first user
    - First user to sign up gets admin role automatically
    - Subsequent users get 'user' role by default

  2. Security
    - Only runs for first user (checks if any admins exist)
    - Uses SECURITY DEFINER to bypass RLS
*/

-- Function to auto-grant admin to first user
CREATE OR REPLACE FUNCTION auto_grant_first_admin()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_admin_count integer;
BEGIN
  -- Check if there are any existing admins
  SELECT COUNT(*) INTO v_admin_count
  FROM user_roles
  WHERE role = 'admin';

  -- If no admins exist, make this user an admin
  IF v_admin_count = 0 THEN
    INSERT INTO user_roles (user_id, role, granted_by)
    VALUES (NEW.id, 'admin', NEW.id)
    ON CONFLICT (user_id, role) DO NOTHING;
  ELSE
    -- Otherwise, grant default 'user' role
    INSERT INTO user_roles (user_id, role)
    VALUES (NEW.id, 'user')
    ON CONFLICT (user_id, role) DO NOTHING;
  END IF;

  RETURN NEW;
END;
$$;

-- Create trigger on auth.users table
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION auto_grant_first_admin();