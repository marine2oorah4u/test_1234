/*
  # Fix Auto-grant Admin Trigger

  1. Changes
    - Drop the old trigger that was causing database errors
    - Create a simpler function that doesn't require direct auth.users access
    - Use a different approach that works with Supabase's security model

  2. Security
    - Still grants admin to first user
    - Uses proper Supabase patterns
*/

-- Drop old trigger and function
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS auto_grant_first_admin();

-- Create new function that works correctly
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_admin_count integer;
BEGIN
  -- Check if there are any existing admins
  SELECT COUNT(*) INTO v_admin_count
  FROM public.user_roles
  WHERE role = 'admin';

  -- If no admins exist, make this user an admin
  IF v_admin_count = 0 THEN
    INSERT INTO public.user_roles (user_id, role, granted_by)
    VALUES (NEW.id, 'admin', NEW.id)
    ON CONFLICT (user_id, role) DO NOTHING;
  ELSE
    -- Otherwise, grant default 'user' role
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'user')
    ON CONFLICT (user_id, role) DO NOTHING;
  END IF;

  RETURN NEW;
END;
$$;

-- Recreate trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();