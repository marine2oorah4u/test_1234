/*
  # Add Language Tiers and Storage Tiers
  
  1. New Tables
    - `language_tiers` - The 4-tier language system (Tier 1-4)
    - `storage_tiers` - The 5-tier storage architecture
    - `worker_scenarios_extended` - Extended worker scenarios (up to 1B workers)
    
  2. Purpose
    - Track language tier assignments and feature sets
    - Define storage tier policies and costs
    - Document extreme scaling scenarios
    
  3. Security
    - Enable RLS on all tables
    - Authenticated users can read
*/

-- Language Tiers (the 4-tier language classification system)
CREATE TABLE IF NOT EXISTS language_tiers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tier_number integer NOT NULL CHECK (tier_number >= 1 AND tier_number <= 4),
  tier_name text NOT NULL,
  language_count_min integer NOT NULL,
  language_count_max integer NOT NULL,
  users_served_estimate bigint,
  users_served_description text,
  
  -- Feature flags
  gets_all_reading_levels boolean DEFAULT true,
  reading_levels_count integer DEFAULT 8,
  gets_all_addons boolean DEFAULT true,
  addon_count_estimate integer DEFAULT 64,
  gets_all_disability_adaptations boolean DEFAULT true,
  disability_adaptation_count integer DEFAULT 400,
  gets_interactive_features boolean DEFAULT true,
  interactive_feature_count integer DEFAULT 50,
  gets_country_variations boolean DEFAULT true,
  
  -- Storage and priority
  storage_tier text DEFAULT 'hot',
  generation_priority integer DEFAULT 1,
  backup_copy_count integer DEFAULT 12,
  
  -- Costs and estimates
  items_per_topic_estimate integer,
  description text,
  examples text,
  special_notes text,
  
  created_at timestamptz DEFAULT now()
);

-- Storage Tiers (the 5-tier storage architecture)
CREATE TABLE IF NOT EXISTS storage_tiers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tier_number integer NOT NULL CHECK (tier_number >= 1 AND tier_number <= 5),
  tier_name text NOT NULL,
  
  -- Storage characteristics
  access_pattern text NOT NULL,
  latency text NOT NULL,
  backup_copy_count integer DEFAULT 12,
  
  -- Providers and costs
  storage_providers text[] DEFAULT '{}',
  cost_per_tb_per_month numeric NOT NULL,
  
  -- Content stored in this tier
  language_tiers_included text[] DEFAULT '{}',
  topic_range_description text,
  content_description text,
  
  -- Technical details
  geographic_distribution text,
  backup_strategy text,
  archive_policy text,
  
  created_at timestamptz DEFAULT now()
);

-- Extended Worker Scenarios (including extreme scales)
CREATE TABLE IF NOT EXISTS worker_scenarios_extended (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  worker_count bigint NOT NULL,
  scenario_name text NOT NULL,
  
  -- Timeline calculations
  total_work_hours bigint DEFAULT 7500000000,
  hours_per_worker numeric,
  days_per_worker numeric,
  timeline_readable text,
  
  -- Cost calculations
  cost_per_month_usd bigint,
  total_cost_usd bigint DEFAULT 37500000000,
  
  -- Infrastructure requirements
  api_accounts_needed integer,
  bandwidth_tb_per_second numeric,
  storage_write_speed_tb_per_second numeric,
  database_shards_needed integer,
  infrastructure_complexity text,
  
  -- Feasibility
  is_feasible boolean DEFAULT true,
  is_recommended boolean DEFAULT false,
  feasibility_notes text,
  
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE language_tiers ENABLE ROW LEVEL SECURITY;
ALTER TABLE storage_tiers ENABLE ROW LEVEL SECURITY;
ALTER TABLE worker_scenarios_extended ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Authenticated users can view language tiers"
  ON language_tiers FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can view storage tiers"
  ON storage_tiers FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can view extended worker scenarios"
  ON worker_scenarios_extended FOR SELECT
  TO authenticated
  USING (true);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_language_tiers_number ON language_tiers(tier_number);
CREATE INDEX IF NOT EXISTS idx_storage_tiers_number ON storage_tiers(tier_number);
CREATE INDEX IF NOT EXISTS idx_worker_scenarios_extended_count ON worker_scenarios_extended(worker_count);