/*
  # Storage Buckets for Educational Content

  ## Overview
  Creates storage buckets for all generated book formats and assets.
  Each bucket has appropriate access policies for public downloads.

  ## Buckets Created
    - `book-pdfs` - PDF format books
    - `book-epubs` - EPUB format books
    - `book-audio` - Audio book files
    - `book-videos` - Video format books
    - `book-html` - HTML/web versions
    - `book-documents` - DOCX and other document formats
    - `book-images` - Book covers and illustrations
    - `interactive-assets` - Game assets, exercise files, etc.

  ## Security
    - All buckets allow public read access for downloads
    - Write access restricted to authenticated users
    - File size limits enforced per bucket type
*/

-- Insert storage buckets (if they don't exist)
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES 
  ('book-pdfs', 'book-pdfs', true, 104857600, ARRAY['application/pdf']),
  ('book-epubs', 'book-epubs', true, 52428800, ARRAY['application/epub+zip']),
  ('book-audio', 'book-audio', true, 524288000, ARRAY['audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/ogg']),
  ('book-videos', 'book-videos', true, 1073741824, ARRAY['video/mp4', 'video/webm', 'video/ogg']),
  ('book-html', 'book-html', true, 10485760, ARRAY['text/html', 'application/zip']),
  ('book-documents', 'book-documents', true, 52428800, ARRAY['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/markdown', 'text/plain', 'application/x-latex']),
  ('book-images', 'book-images', true, 10485760, ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml']),
  ('interactive-assets', 'interactive-assets', true, 104857600, ARRAY['application/json', 'application/javascript', 'text/html', 'image/jpeg', 'image/png', 'audio/mpeg'])
ON CONFLICT (id) DO NOTHING;

-- Storage policies for public read access
CREATE POLICY "Public read access for book PDFs"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'book-pdfs');

CREATE POLICY "Public read access for book EPUBs"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'book-epubs');

CREATE POLICY "Public read access for book audio"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'book-audio');

CREATE POLICY "Public read access for book videos"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'book-videos');

CREATE POLICY "Public read access for book HTML"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'book-html');

CREATE POLICY "Public read access for book documents"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'book-documents');

CREATE POLICY "Public read access for book images"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'book-images');

CREATE POLICY "Public read access for interactive assets"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'interactive-assets');

-- Storage policies for authenticated write access
CREATE POLICY "Authenticated users can upload PDFs"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'book-pdfs');

CREATE POLICY "Authenticated users can upload EPUBs"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'book-epubs');

CREATE POLICY "Authenticated users can upload audio"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'book-audio');

CREATE POLICY "Authenticated users can upload videos"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'book-videos');

CREATE POLICY "Authenticated users can upload HTML"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'book-html');

CREATE POLICY "Authenticated users can upload documents"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'book-documents');

CREATE POLICY "Authenticated users can upload images"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'book-images');

CREATE POLICY "Authenticated users can upload interactive assets"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'interactive-assets');

-- Authenticated users can update/delete their uploads
CREATE POLICY "Authenticated users can update storage objects"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete storage objects"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (true);