/*
  # Features Catalog System

  1. New Tables
    - `feature_categories`
      - `id` (uuid, primary key)
      - `category_number` (integer)
      - `name` (text)
      - `description` (text)
      - `total_features` (integer)
      - `group_type` (text) - e.g., "Core Learning", "Social", etc.
      
    - `features`
      - `id` (uuid, primary key)
      - `category_id` (uuid, foreign key)
      - `feature_number` (integer) - sequential number within category
      - `name` (text)
      - `description` (text)
      - `priority` (text) - MVP, Phase2, Phase3, Future
      - `complexity` (text) - Low, Medium, High, Very High
      - `status` (text) - not_started, planning, in_progress, completed
      - `tags` (text array)
      - `dependencies` (text array)
      - `created_at` (timestamptz)
      
  2. Security
    - Enable RLS on both tables
    - Authenticated users can read all features
    - Only admins can modify features
*/

-- Create feature_categories table
CREATE TABLE IF NOT EXISTS feature_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_number integer UNIQUE NOT NULL,
  name text NOT NULL,
  description text,
  total_features integer DEFAULT 0,
  group_type text,
  created_at timestamptz DEFAULT now()
);

-- Create features table
CREATE TABLE IF NOT EXISTS features (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid REFERENCES feature_categories(id) ON DELETE CASCADE,
  feature_number integer NOT NULL,
  name text NOT NULL,
  description text,
  priority text CHECK (priority IN ('MVP', 'Phase2', 'Phase3', 'Future')),
  complexity text CHECK (complexity IN ('Low', 'Medium', 'High', 'Very High')),
  status text DEFAULT 'not_started' CHECK (status IN ('not_started', 'planning', 'in_progress', 'completed')),
  tags text[] DEFAULT '{}',
  dependencies text[] DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  UNIQUE(category_id, feature_number)
);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_features_category ON features(category_id);
CREATE INDEX IF NOT EXISTS idx_features_priority ON features(priority);
CREATE INDEX IF NOT EXISTS idx_features_status ON features(status);

-- Enable RLS
ALTER TABLE feature_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE features ENABLE ROW LEVEL SECURITY;

-- RLS Policies for feature_categories
CREATE POLICY "Anyone can view feature categories"
  ON feature_categories FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage feature categories"
  ON feature_categories FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

-- RLS Policies for features
CREATE POLICY "Anyone can view features"
  ON features FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage features"
  ON features FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );
