/*
  # Fix User Roles RLS Policies

  1. Changes
    - Drop existing policies that cause infinite recursion
    - Create simpler policies that allow users to read their own roles
    - Allow all authenticated users to read roles (app will filter admin pages)

  2. Security
    - Users can view their own roles
    - All authenticated users can view roles (necessary to check admin status)
    - Only existing admins can modify roles
    - First user gets auto-admin via trigger
*/

-- Drop existing policies that cause recursion
DROP POLICY IF EXISTS "Admins can view all roles" ON user_roles;
DROP POLICY IF EXISTS "Admins can manage roles" ON user_roles;
DROP POLICY IF EXISTS "Users can view own roles" ON user_roles;

-- Allow all authenticated users to SELECT their own roles
-- This is necessary to check if someone is an admin
CREATE POLICY "Users can view own roles"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Allow all authenticated users to view all roles
-- This is safe because we control who can access admin pages in the app
CREATE POLICY "All authenticated can view roles"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

-- Only allow INSERT/UPDATE/DELETE by service role or existing admins
-- We use a function to avoid recursion
CREATE OR REPLACE FUNCTION check_is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_id = auth.uid()
    AND role = 'admin'
    LIMIT 1
  );
$$;

CREATE POLICY "Admins can insert roles"
  ON user_roles
  FOR INSERT
  TO authenticated
  WITH CHECK (check_is_admin());

CREATE POLICY "Admins can update roles"
  ON user_roles
  FOR UPDATE
  TO authenticated
  USING (check_is_admin())
  WITH CHECK (check_is_admin());

CREATE POLICY "Admins can delete roles"
  ON user_roles
  FOR DELETE
  TO authenticated
  USING (check_is_admin());
