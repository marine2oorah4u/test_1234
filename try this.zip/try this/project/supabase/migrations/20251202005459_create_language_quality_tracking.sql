/*
  # Language Quality & Feature Tracking System

  1. New Tables
    - `supported_languages` - All languages we support with quality tiers
    - `language_features` - Which features are available per language
    - `course_language_status` - Status of each course in each language
    - `language_quality_reports` - User-submitted quality reports

  2. Purpose
    - Track which languages are supported and their quality tier
    - Track feature availability (voice, video, AI tutor voice, etc.)
    - Display appropriate warnings/badges to users
    - Allow users to report translation issues
    - Continuously improve based on AI model improvements

  3. Security
    - Enable RLS on all tables
    - Users can read all language data
    - Only authenticated users can submit quality reports
*/

-- Supported Languages
CREATE TABLE IF NOT EXISTS supported_languages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  language_code text UNIQUE NOT NULL,
  language_name_english text NOT NULL,
  language_name_native text NOT NULL,

  quality_tier integer NOT NULL CHECK (quality_tier >= 1 AND quality_tier <= 3),
  quality_status text NOT NULL CHECK (quality_status IN ('complete', 'improving', 'beta')),

  has_text_translation boolean DEFAULT true,
  has_voice_narration boolean DEFAULT false,
  has_video_narration boolean DEFAULT false,
  has_ai_tutor_voice boolean DEFAULT false,
  has_cultural_adaptation boolean DEFAULT false,

  voice_quality text CHECK (voice_quality IN ('excellent', 'good', 'robotic', 'unavailable')),
  voice_provider text,

  translation_accuracy_estimate integer CHECK (translation_accuracy_estimate >= 0 AND translation_accuracy_estimate <= 100),
  translation_provider text,

  native_speakers_millions numeric,
  total_speakers_millions numeric,
  countries_spoken_in text[] DEFAULT '{}',

  user_facing_status_badge text NOT NULL,
  user_facing_banner_message text,
  user_facing_voice_message text,

  last_quality_update timestamptz DEFAULT now(),
  planned_improvements text,
  improvement_eta timestamptz,

  is_active boolean DEFAULT true,
  display_order integer DEFAULT 999,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Language Features
CREATE TABLE IF NOT EXISTS language_features (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  language_id uuid REFERENCES supported_languages(id) ON DELETE CASCADE,

  feature_type text NOT NULL CHECK (feature_type IN (
    'text_lessons',
    'audio_lessons',
    'video_lessons',
    'interactive_quizzes',
    'ai_tutor_text',
    'ai_tutor_voice',
    'worksheets',
    'activity_packs',
    'flashcards',
    'study_guides',
    'career_guides',
    'presentations',
    'vr_experiences',
    'ar_experiences',
    'games',
    'simulations',
    'virtual_labs',
    'cultural_adaptations'
  )),

  is_available boolean DEFAULT false,
  quality_rating integer CHECK (quality_rating >= 1 AND quality_rating <= 5),
  quality_description text,

  availability_message text,
  coming_soon boolean DEFAULT false,
  estimated_availability timestamptz,

  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),

  UNIQUE(language_id, feature_type)
);

-- Course Language Status (using books table)
CREATE TABLE IF NOT EXISTS course_language_status (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),

  book_id uuid REFERENCES books(id) ON DELETE CASCADE,
  language_id uuid REFERENCES supported_languages(id) ON DELETE CASCADE,

  generation_status text NOT NULL DEFAULT 'pending' CHECK (generation_status IN (
    'pending',
    'in_progress',
    'completed',
    'needs_review',
    'published',
    'retired'
  )),

  translation_quality_score integer CHECK (translation_quality_score >= 0 AND translation_quality_score <= 100),
  user_reported_issues_count integer DEFAULT 0,
  user_rating_average numeric CHECK (user_rating_average >= 0 AND user_rating_average <= 5),
  user_rating_count integer DEFAULT 0,

  features_complete jsonb DEFAULT '{}',
  features_total integer DEFAULT 18,
  features_completed integer DEFAULT 0,
  completion_percentage integer DEFAULT 0,

  generation_started_at timestamptz,
  generation_completed_at timestamptz,
  last_updated_at timestamptz DEFAULT now(),
  published_at timestamptz,

  status_message text,
  show_beta_warning boolean DEFAULT false,
  show_improving_banner boolean DEFAULT false,

  notes text,
  created_at timestamptz DEFAULT now(),

  UNIQUE(book_id, language_id)
);

-- Language Quality Reports
CREATE TABLE IF NOT EXISTS language_quality_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),

  language_id uuid REFERENCES supported_languages(id) ON DELETE CASCADE,
  course_language_status_id uuid REFERENCES course_language_status(id) ON DELETE CASCADE,

  reported_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  reporter_is_native_speaker boolean DEFAULT false,

  issue_type text NOT NULL CHECK (issue_type IN (
    'translation_error',
    'grammar_error',
    'cultural_inappropriateness',
    'missing_translation',
    'voice_quality',
    'voice_missing',
    'unclear_explanation',
    'technical_error',
    'other'
  )),

  issue_severity text NOT NULL CHECK (issue_severity IN ('minor', 'moderate', 'major', 'critical')),

  section_reference text,
  page_number integer,
  content_excerpt text,

  issue_description text NOT NULL,
  suggested_correction text,

  report_status text NOT NULL DEFAULT 'submitted' CHECK (report_status IN (
    'submitted',
    'under_review',
    'accepted',
    'fixed',
    'rejected',
    'duplicate'
  )),

  reviewed_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  reviewed_at timestamptz,
  reviewer_notes text,

  fixed_at timestamptz,
  fix_notes text,

  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE supported_languages ENABLE ROW LEVEL SECURITY;
ALTER TABLE language_features ENABLE ROW LEVEL SECURITY;
ALTER TABLE course_language_status ENABLE ROW LEVEL SECURITY;
ALTER TABLE language_quality_reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view supported languages"
  ON supported_languages FOR SELECT
  USING (true);

CREATE POLICY "Anyone can view language features"
  ON language_features FOR SELECT
  USING (true);

CREATE POLICY "Anyone can view course language status"
  ON course_language_status FOR SELECT
  USING (true);

CREATE POLICY "Anyone can view quality reports"
  ON language_quality_reports FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can submit quality reports"
  ON language_quality_reports FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = reported_by);

CREATE POLICY "Users can update own reports"
  ON language_quality_reports FOR UPDATE
  TO authenticated
  USING (auth.uid() = reported_by)
  WITH CHECK (auth.uid() = reported_by);

CREATE INDEX IF NOT EXISTS idx_supported_languages_code ON supported_languages(language_code);
CREATE INDEX IF NOT EXISTS idx_supported_languages_tier ON supported_languages(quality_tier);
CREATE INDEX IF NOT EXISTS idx_language_features_language ON language_features(language_id);
CREATE INDEX IF NOT EXISTS idx_course_language_status_book ON course_language_status(book_id);
CREATE INDEX IF NOT EXISTS idx_course_language_status_language ON course_language_status(language_id);
CREATE INDEX IF NOT EXISTS idx_quality_reports_language ON language_quality_reports(language_id);
CREATE INDEX IF NOT EXISTS idx_quality_reports_status ON language_quality_reports(report_status);
