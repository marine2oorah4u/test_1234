/*
  # AI Educational Content Generator - Core Database Schema

  ## Overview
  This migration creates the foundational database structure for an AI-powered educational content generation platform.
  The system generates multi-level, multi-format educational books with interactive content, AI tutoring, and comprehensive admin monitoring.

  ## 1. New Tables

  ### Books Management
    - `books` - Master table for all generated educational content
      - `id` (uuid, primary key) - Unique book identifier
      - `title` (text) - Book title
      - `subject` (text) - Main subject/topic
      - `description` (text) - Detailed book description
      - `status` (text) - Generation status: pending, processing, completed, failed
      - `metadata` (jsonb) - Flexible metadata storage (keywords, categories, etc.)
      - `is_demo` (boolean) - Whether this is a demo or full version
      - `created_at` (timestamptz) - Creation timestamp
      - `updated_at` (timestamptz) - Last update timestamp
      - `completed_at` (timestamptz) - Generation completion timestamp
      - `expiration_date` (timestamptz, nullable) - For demo books with time limits

    - `book_versions` - Different versions/formats/reading levels of each book
      - `id` (uuid, primary key)
      - `book_id` (uuid, foreign key) - References books table
      - `reading_level` (text) - Reading level: phd, masters, bachelors, high_school, middle_school, elementary, kindergarten
      - `format_type` (text) - Format: pdf, epub, html, audio, video, docx, markdown, latex
      - `file_url` (text, nullable) - Storage URL for the file
      - `file_size` (bigint) - File size in bytes
      - `word_count` (integer) - Word count for text formats
      - `duration` (integer, nullable) - Duration in seconds for audio/video
      - `status` (text) - Version status: pending, processing, completed, failed
      - `metadata` (jsonb) - Version-specific metadata
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `sub_books` - Tracks relationship between master books and sub-books
      - `id` (uuid, primary key)
      - `master_book_id` (uuid, foreign key) - The main/parent book
      - `sub_book_id` (uuid, foreign key) - The sub-book/chapter book
      - `order_index` (integer) - Order in the series
      - `relationship_type` (text) - Type: chapter, volume, part
      - `created_at` (timestamptz)

  ### Subject Management
    - `subjects` - Categorized subject taxonomy
      - `id` (uuid, primary key)
      - `main_subject` (text) - Primary subject category
      - `sub_subject` (text, nullable) - Sub-category
      - `category` (text) - Broad category grouping
      - `keywords` (text[]) - Array of related keywords
      - `description` (text) - Subject description
      - `created_at` (timestamptz)

  ### Generation Queue System
    - `generation_queue` - Tracks background generation jobs
      - `id` (uuid, primary key)
      - `book_id` (uuid, foreign key) - Book being generated
      - `status` (text) - Job status: queued, processing, completed, failed
      - `progress_stage` (text) - Current pipeline stage
      - `progress_percentage` (integer) - Overall completion percentage (0-100)
      - `estimated_completion` (timestamptz, nullable) - Estimated completion time
      - `error_log` (jsonb, nullable) - Error details if failed
      - `generation_config` (jsonb) - Configuration for this generation
      - `started_at` (timestamptz, nullable)
      - `completed_at` (timestamptz, nullable)
      - `created_at` (timestamptz)

  ### API Management
    - `api_services` - Configuration for all AI/external services
      - `id` (uuid, primary key)
      - `service_name` (text) - Service identifier (openai, anthropic, elevenlabs, etc.)
      - `provider` (text) - Provider name
      - `purpose` (text) - Service purpose (text_generation, audio, research, etc.)
      - `api_key_encrypted` (text) - Encrypted API key
      - `is_active` (boolean) - Whether service is active
      - `priority_order` (integer) - Priority for failover (1 = primary, 2 = secondary, etc.)
      - `model_name` (text, nullable) - Specific model being used
      - `config` (jsonb) - Service-specific configuration
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `api_usage` - Tracks API usage and costs
      - `id` (uuid, primary key)
      - `service_id` (uuid, foreign key) - References api_services
      - `date` (date) - Usage date
      - `tokens_used` (bigint) - Tokens consumed
      - `requests_count` (integer) - Number of API requests
      - `cost` (numeric) - Estimated cost in USD
      - `response_time_avg` (integer) - Average response time in ms
      - `errors_count` (integer) - Number of errors
      - `created_at` (timestamptz)

    - `api_limits` - Tracks service limits and thresholds
      - `id` (uuid, primary key)
      - `service_id` (uuid, foreign key) - References api_services
      - `monthly_token_limit` (bigint, nullable) - Token limit per month
      - `monthly_request_limit` (integer, nullable) - Request limit per month
      - `current_usage` (bigint) - Current period usage
      - `reset_date` (date) - When usage resets
      - `expiration_date` (date, nullable) - Service expiration date
      - `alert_threshold` (integer) - Alert when usage reaches this percentage
      - `budget_limit` (numeric, nullable) - Monthly budget limit in USD
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  ### Admin System
    - `admin_logs` - Audit log for admin actions
      - `id` (uuid, primary key)
      - `action_type` (text) - Type of action performed
      - `user_id` (uuid, nullable) - Admin user who performed action
      - `details` (jsonb) - Action details
      - `ip_address` (text, nullable) - IP address of admin
      - `created_at` (timestamptz)

  ### Interactive Content
    - `interactive_lessons` - Store interactive learning content
      - `id` (uuid, primary key)
      - `book_id` (uuid, foreign key) - Parent book
      - `reading_level` (text) - Reading level this is designed for
      - `lesson_type` (text) - Type: quiz, exercise, game, simulation
      - `lesson_data` (jsonb) - JSON data for the lesson/exercise
      - `title` (text) - Lesson title
      - `description` (text, nullable) - Lesson description
      - `difficulty` (integer) - Difficulty level 1-5
      - `order_index` (integer) - Order within the book
      - `estimated_time` (integer, nullable) - Estimated completion time in minutes
      - `created_at` (timestamptz)

  ## 2. Security

  ### Row Level Security (RLS)
    - All tables have RLS enabled
    - Public read access for books and content
    - Write access restricted to authenticated admin users
    - API keys are encrypted and access-controlled

  ### RLS Policies
    - Books and content: Public can read completed books, only admins can write
    - API services: Only admins can access
    - Admin logs: Only admins can read their own logs
    - Generation queue: Public can read status of their generations, only system can write

  ## 3. Important Notes
    - All timestamps use timestamptz for timezone awareness
    - JSONB fields allow flexible data structures without schema changes
    - Foreign key constraints ensure referential integrity
    - Indexes on frequently queried fields for performance
    - Encrypted storage for sensitive API keys
    - Default values prevent null errors and provide sensible defaults
*/

-- Enable UUID extension if not already enabled
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Books table - master table for all generated content
CREATE TABLE IF NOT EXISTS books (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  subject text NOT NULL,
  description text DEFAULT '',
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
  metadata jsonb DEFAULT '{}',
  is_demo boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  completed_at timestamptz,
  expiration_date timestamptz
);

-- Book versions - different formats and reading levels
CREATE TABLE IF NOT EXISTS book_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id uuid NOT NULL REFERENCES books(id) ON DELETE CASCADE,
  reading_level text NOT NULL CHECK (reading_level IN ('phd', 'masters', 'bachelors', 'high_school', 'middle_school', 'elementary', 'kindergarten')),
  format_type text NOT NULL CHECK (format_type IN ('pdf', 'epub', 'html', 'audio', 'video', 'docx', 'markdown', 'latex')),
  file_url text,
  file_size bigint DEFAULT 0,
  word_count integer DEFAULT 0,
  duration integer,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(book_id, reading_level, format_type)
);

-- Sub-books relationship tracking
CREATE TABLE IF NOT EXISTS sub_books (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  master_book_id uuid NOT NULL REFERENCES books(id) ON DELETE CASCADE,
  sub_book_id uuid NOT NULL REFERENCES books(id) ON DELETE CASCADE,
  order_index integer NOT NULL DEFAULT 0,
  relationship_type text NOT NULL DEFAULT 'chapter' CHECK (relationship_type IN ('chapter', 'volume', 'part')),
  created_at timestamptz DEFAULT now(),
  UNIQUE(master_book_id, sub_book_id)
);

-- Subjects taxonomy
CREATE TABLE IF NOT EXISTS subjects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  main_subject text NOT NULL,
  sub_subject text,
  category text NOT NULL,
  keywords text[] DEFAULT '{}',
  description text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  UNIQUE(main_subject, sub_subject)
);

-- Generation queue for background jobs
CREATE TABLE IF NOT EXISTS generation_queue (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id uuid NOT NULL REFERENCES books(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'queued' CHECK (status IN ('queued', 'processing', 'completed', 'failed', 'cancelled')),
  progress_stage text DEFAULT 'initializing',
  progress_percentage integer DEFAULT 0 CHECK (progress_percentage >= 0 AND progress_percentage <= 100),
  estimated_completion timestamptz,
  error_log jsonb,
  generation_config jsonb DEFAULT '{}',
  started_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- API services configuration
CREATE TABLE IF NOT EXISTS api_services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_name text NOT NULL UNIQUE,
  provider text NOT NULL,
  purpose text NOT NULL,
  api_key_encrypted text,
  is_active boolean DEFAULT true,
  priority_order integer NOT NULL DEFAULT 999,
  model_name text,
  config jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- API usage tracking
CREATE TABLE IF NOT EXISTS api_usage (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_id uuid NOT NULL REFERENCES api_services(id) ON DELETE CASCADE,
  date date NOT NULL DEFAULT CURRENT_DATE,
  tokens_used bigint DEFAULT 0,
  requests_count integer DEFAULT 0,
  cost numeric(10, 4) DEFAULT 0,
  response_time_avg integer DEFAULT 0,
  errors_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  UNIQUE(service_id, date)
);

-- API limits and thresholds
CREATE TABLE IF NOT EXISTS api_limits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_id uuid NOT NULL REFERENCES api_services(id) ON DELETE CASCADE,
  monthly_token_limit bigint,
  monthly_request_limit integer,
  current_usage bigint DEFAULT 0,
  reset_date date NOT NULL,
  expiration_date date,
  alert_threshold integer DEFAULT 80 CHECK (alert_threshold >= 0 AND alert_threshold <= 100),
  budget_limit numeric(10, 2),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(service_id)
);

-- Admin audit logs
CREATE TABLE IF NOT EXISTS admin_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  action_type text NOT NULL,
  user_id uuid,
  details jsonb DEFAULT '{}',
  ip_address text,
  created_at timestamptz DEFAULT now()
);

-- Interactive lessons and exercises
CREATE TABLE IF NOT EXISTS interactive_lessons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id uuid NOT NULL REFERENCES books(id) ON DELETE CASCADE,
  reading_level text NOT NULL CHECK (reading_level IN ('phd', 'masters', 'bachelors', 'high_school', 'middle_school', 'elementary', 'kindergarten')),
  lesson_type text NOT NULL CHECK (lesson_type IN ('quiz', 'exercise', 'game', 'simulation', 'activity')),
  lesson_data jsonb NOT NULL DEFAULT '{}',
  title text NOT NULL,
  description text,
  difficulty integer DEFAULT 3 CHECK (difficulty >= 1 AND difficulty <= 5),
  order_index integer DEFAULT 0,
  estimated_time integer,
  created_at timestamptz DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_books_status ON books(status);
CREATE INDEX IF NOT EXISTS idx_books_subject ON books(subject);
CREATE INDEX IF NOT EXISTS idx_books_created_at ON books(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_book_versions_book_id ON book_versions(book_id);
CREATE INDEX IF NOT EXISTS idx_book_versions_status ON book_versions(status);
CREATE INDEX IF NOT EXISTS idx_generation_queue_status ON generation_queue(status);
CREATE INDEX IF NOT EXISTS idx_generation_queue_book_id ON generation_queue(book_id);
CREATE INDEX IF NOT EXISTS idx_api_usage_service_date ON api_usage(service_id, date);
CREATE INDEX IF NOT EXISTS idx_interactive_lessons_book_id ON interactive_lessons(book_id);
CREATE INDEX IF NOT EXISTS idx_sub_books_master ON sub_books(master_book_id);

-- Enable Row Level Security on all tables
ALTER TABLE books ENABLE ROW LEVEL SECURITY;
ALTER TABLE book_versions ENABLE ROW LEVEL SECURITY;
ALTER TABLE sub_books ENABLE ROW LEVEL SECURITY;
ALTER TABLE subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE generation_queue ENABLE ROW LEVEL SECURITY;
ALTER TABLE api_services ENABLE ROW LEVEL SECURITY;
ALTER TABLE api_usage ENABLE ROW LEVEL SECURITY;
ALTER TABLE api_limits ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE interactive_lessons ENABLE ROW LEVEL SECURITY;

-- RLS Policies for books (public read for completed books)
CREATE POLICY "Anyone can view completed books"
  ON books FOR SELECT
  USING (status = 'completed');

CREATE POLICY "Authenticated users can insert books"
  ON books FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update books"
  ON books FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete books"
  ON books FOR DELETE
  TO authenticated
  USING (true);

-- RLS Policies for book_versions
CREATE POLICY "Anyone can view completed book versions"
  ON book_versions FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM books
      WHERE books.id = book_versions.book_id
      AND books.status = 'completed'
    )
  );

CREATE POLICY "Authenticated users can manage book versions"
  ON book_versions FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for sub_books
CREATE POLICY "Anyone can view sub-book relationships"
  ON sub_books FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can manage sub-books"
  ON sub_books FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for subjects (public read)
CREATE POLICY "Anyone can view subjects"
  ON subjects FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can manage subjects"
  ON subjects FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for generation_queue (public can track their jobs)
CREATE POLICY "Anyone can view generation queue"
  ON generation_queue FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can manage generation queue"
  ON generation_queue FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for API services (admin only)
CREATE POLICY "Only authenticated users can view API services"
  ON api_services FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Only authenticated users can manage API services"
  ON api_services FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for API usage (admin only)
CREATE POLICY "Only authenticated users can view API usage"
  ON api_usage FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Only authenticated users can manage API usage"
  ON api_usage FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for API limits (admin only)
CREATE POLICY "Only authenticated users can view API limits"
  ON api_limits FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Only authenticated users can manage API limits"
  ON api_limits FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for admin_logs (admin only)
CREATE POLICY "Only authenticated users can view admin logs"
  ON admin_logs FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Only authenticated users can create admin logs"
  ON admin_logs FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- RLS Policies for interactive_lessons
CREATE POLICY "Anyone can view interactive lessons for completed books"
  ON interactive_lessons FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM books
      WHERE books.id = interactive_lessons.book_id
      AND books.status = 'completed'
    )
  );

CREATE POLICY "Authenticated users can manage interactive lessons"
  ON interactive_lessons FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Function to automatically update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at
CREATE TRIGGER update_books_updated_at BEFORE UPDATE ON books
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_book_versions_updated_at BEFORE UPDATE ON book_versions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_api_services_updated_at BEFORE UPDATE ON api_services
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_api_limits_updated_at BEFORE UPDATE ON api_limits
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();