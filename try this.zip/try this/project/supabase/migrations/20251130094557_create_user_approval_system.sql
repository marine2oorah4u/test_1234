/*
  # User Approval System

  1. New Tables
    - `user_approvals`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `email` (text)
      - `status` (text: 'pending', 'approved', 'rejected')
      - `approved_by` (uuid, references auth.users, nullable)
      - `approved_at` (timestamptz, nullable)
      - `rejected_at` (timestamptz, nullable)
      - `rejection_reason` (text, nullable)
      - `requested_at` (timestamptz)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `user_approvals` table
    - Users can view their own approval status
    - Admins can view all approval requests
    - Only admins can approve/reject users

  3. Triggers
    - Automatically create approval request for non-first users on signup
    - First user gets auto-admin and no approval needed

  4. Notes
    - First user (already created) bypasses approval system
    - All subsequent signups require admin approval
    - Users cannot log in until approved
*/

-- Create user_approvals table
CREATE TABLE IF NOT EXISTS user_approvals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  email text NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  approved_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  approved_at timestamptz,
  rejected_at timestamptz,
  rejection_reason text,
  requested_at timestamptz DEFAULT now() NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL
);

-- Create indexes for faster lookups
CREATE INDEX IF NOT EXISTS idx_user_approvals_user_id ON user_approvals(user_id);
CREATE INDEX IF NOT EXISTS idx_user_approvals_status ON user_approvals(status);
CREATE INDEX IF NOT EXISTS idx_user_approvals_email ON user_approvals(email);

-- Enable RLS
ALTER TABLE user_approvals ENABLE ROW LEVEL SECURITY;

-- Policy: Users can view their own approval status
CREATE POLICY "Users can view own approval status"
  ON user_approvals
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Policy: Admins can view all approval requests
CREATE POLICY "Admins can view all approvals"
  ON user_approvals
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

-- Policy: Admins can update approval status
CREATE POLICY "Admins can update approvals"
  ON user_approvals
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

-- Policy: System can insert approval requests (for trigger)
CREATE POLICY "System can insert approvals"
  ON user_approvals
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Function to create approval request on signup (modified to work with existing trigger)
CREATE OR REPLACE FUNCTION create_user_approval_request()
RETURNS TRIGGER AS $$
DECLARE
  v_admin_count integer;
BEGIN
  -- Check if there are any existing admins
  SELECT COUNT(*) INTO v_admin_count
  FROM user_roles
  WHERE role = 'admin';

  -- If admins exist (not first user), create approval request
  IF v_admin_count > 0 THEN
    INSERT INTO user_approvals (user_id, email, status, requested_at)
    VALUES (NEW.id, NEW.email, 'pending', now())
    ON CONFLICT (user_id) DO NOTHING;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Add this to the existing user creation trigger
DROP TRIGGER IF EXISTS on_auth_user_created_approval ON auth.users;
CREATE TRIGGER on_auth_user_created_approval
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION create_user_approval_request();

-- Function to check if user is approved (used by AuthContext)
CREATE OR REPLACE FUNCTION is_user_approved(user_id_param uuid)
RETURNS boolean AS $$
DECLARE
  v_is_admin boolean;
  v_approval_status text;
BEGIN
  -- Check if user is admin (admins are always approved)
  SELECT EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_id = user_id_param
    AND role = 'admin'
  ) INTO v_is_admin;

  IF v_is_admin THEN
    RETURN true;
  END IF;

  -- Check approval status
  SELECT status INTO v_approval_status
  FROM user_approvals
  WHERE user_id = user_id_param;

  -- If no approval record exists (first user), they're approved
  IF v_approval_status IS NULL THEN
    RETURN true;
  END IF;

  -- Otherwise, check if status is approved
  RETURN v_approval_status = 'approved';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Update timestamp trigger
CREATE OR REPLACE FUNCTION update_user_approvals_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS user_approvals_updated_at ON user_approvals;
CREATE TRIGGER user_approvals_updated_at
  BEFORE UPDATE ON user_approvals
  FOR EACH ROW
  EXECUTE FUNCTION update_user_approvals_updated_at();
