/*
  # Add Robotic Voice Options

  1. Changes
    - Add robotic voice availability tracking to supported_languages
    - Add user preference for robotic voice to user_preferences
    - Track voice provider options

  2. Purpose
    - Allow users to opt-in to robotic voice when high-quality voice unavailable
    - Track which languages have robotic voice available
    - Store user preferences for voice quality tolerance
*/

-- Add robotic voice columns to supported_languages
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'supported_languages' AND column_name = 'has_robotic_voice_available'
  ) THEN
    ALTER TABLE supported_languages ADD COLUMN has_robotic_voice_available boolean DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'supported_languages' AND column_name = 'allow_user_enable_robotic'
  ) THEN
    ALTER TABLE supported_languages ADD COLUMN allow_user_enable_robotic boolean DEFAULT true;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'supported_languages' AND column_name = 'robotic_voice_provider'
  ) THEN
    ALTER TABLE supported_languages ADD COLUMN robotic_voice_provider text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'supported_languages' AND column_name = 'robotic_voice_quality_notes'
  ) THEN
    ALTER TABLE supported_languages ADD COLUMN robotic_voice_quality_notes text;
  END IF;
END $$;

-- Add user voice preference columns to user_preferences
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_preferences' AND column_name = 'enable_robotic_voice_global'
  ) THEN
    ALTER TABLE user_preferences ADD COLUMN enable_robotic_voice_global boolean DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_preferences' AND column_name = 'voice_quality_preference'
  ) THEN
    ALTER TABLE user_preferences ADD COLUMN voice_quality_preference text DEFAULT 'high_quality_only' 
      CHECK (voice_quality_preference IN ('high_quality_only', 'accept_good', 'accept_robotic', 'any_voice'));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_preferences' AND column_name = 'robotic_voice_languages_enabled'
  ) THEN
    ALTER TABLE user_preferences ADD COLUMN robotic_voice_languages_enabled text[] DEFAULT '{}';
  END IF;
END $$;

-- Create table for user language-specific voice preferences
CREATE TABLE IF NOT EXISTS user_language_voice_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  language_id uuid REFERENCES supported_languages(id) ON DELETE CASCADE,
  
  enable_robotic_voice boolean DEFAULT false,
  preference_set_at timestamptz DEFAULT now(),
  
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  
  UNIQUE(user_id, language_id)
);

-- Enable RLS
ALTER TABLE user_language_voice_preferences ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view own voice preferences"
  ON user_language_voice_preferences FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own voice preferences"
  ON user_language_voice_preferences FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own voice preferences"
  ON user_language_voice_preferences FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own voice preferences"
  ON user_language_voice_preferences FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_user_language_voice_prefs_user ON user_language_voice_preferences(user_id);
CREATE INDEX IF NOT EXISTS idx_user_language_voice_prefs_language ON user_language_voice_preferences(language_id);

-- Comments
COMMENT ON TABLE user_language_voice_preferences IS 'Stores user preferences for enabling robotic voice on specific languages';
COMMENT ON COLUMN supported_languages.has_robotic_voice_available IS 'Whether robotic/automated voice is available for this language';
COMMENT ON COLUMN supported_languages.allow_user_enable_robotic IS 'Whether users can opt-in to use robotic voice';
COMMENT ON COLUMN supported_languages.robotic_voice_provider IS 'Provider of robotic voice (google_tts, azure_basic, etc)';
