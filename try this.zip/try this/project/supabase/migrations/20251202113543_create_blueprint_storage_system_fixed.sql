/*
  # Blueprint Storage System
  
  1. New Tables
    - `generation_blueprints` - Master blueprint registry
    - `format_specifications` - Format rules for each book type
    - `ai_model_configurations` - AI model assignments per step
    - `worker_configurations` - Worker pool templates
    - `quality_thresholds` - Quality standards and verification rules
    - `image_specifications` - Image requirements per type
    - `step_blueprints` - Individual step documentation
    
  2. Security
    - Enable RLS on all tables
    - Admin-only write access
    - Public read access for operational data
    
  3. Indexes
    - Optimized for blueprint lookups during generation
*/

-- Master blueprint registry
CREATE TABLE IF NOT EXISTS generation_blueprints (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  blueprint_type text NOT NULL,
  pipeline_number int,
  name text NOT NULL,
  description text,
  version text NOT NULL DEFAULT '1.0',
  specifications jsonb NOT NULL DEFAULT '{}'::jsonb,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Format specifications for each book type
CREATE TABLE IF NOT EXISTS format_specifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  book_type text NOT NULL,
  structure_rules jsonb NOT NULL DEFAULT '{}'::jsonb,
  formatting_rules jsonb NOT NULL DEFAULT '{}'::jsonb,
  typography_rules jsonb NOT NULL DEFAULT '{}'::jsonb,
  image_requirements jsonb NOT NULL DEFAULT '{}'::jsonb,
  accessibility_rules jsonb NOT NULL DEFAULT '{}'::jsonb,
  page_layout jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- AI model configurations
CREATE TABLE IF NOT EXISTS ai_model_configurations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pipeline_id text NOT NULL,
  step_id text NOT NULL,
  step_name text NOT NULL,
  models jsonb NOT NULL DEFAULT '[]'::jsonb,
  worker_count int NOT NULL DEFAULT 1,
  consensus_rules jsonb NOT NULL DEFAULT '{}'::jsonb,
  fallback_models jsonb DEFAULT '[]'::jsonb,
  timeout_seconds int DEFAULT 600,
  retry_count int DEFAULT 3,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Worker pool configurations
CREATE TABLE IF NOT EXISTS worker_configurations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pipeline_id text NOT NULL,
  step_id text NOT NULL,
  worker_type text NOT NULL,
  workers_per_item int NOT NULL,
  concurrent_items int NOT NULL,
  total_workers int GENERATED ALWAYS AS (workers_per_item * concurrent_items) STORED,
  scaling_rules jsonb DEFAULT '{}'::jsonb,
  resource_limits jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Quality thresholds and verification rules
CREATE TABLE IF NOT EXISTS quality_thresholds (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pipeline_id text NOT NULL,
  step_id text,
  threshold_type text NOT NULL,
  minimum_pass_score numeric NOT NULL,
  excellence_target numeric,
  automatic_retry_below numeric,
  major_revision_below numeric,
  verification_criteria jsonb NOT NULL DEFAULT '{}'::jsonb,
  fail_action text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Image specifications
CREATE TABLE IF NOT EXISTS image_specifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  image_type text NOT NULL,
  required_per_section_min int NOT NULL DEFAULT 0,
  required_per_section_max int NOT NULL DEFAULT 0,
  format_preferences jsonb DEFAULT '[]'::jsonb,
  resolution_requirements jsonb NOT NULL DEFAULT '{}'::jsonb,
  style_guidelines jsonb DEFAULT '{}'::jsonb,
  sources jsonb DEFAULT '[]'::jsonb,
  licensing_requirements jsonb DEFAULT '{}'::jsonb,
  accessibility_requirements jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Individual step blueprints
CREATE TABLE IF NOT EXISTS step_blueprints (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pipeline_id text NOT NULL,
  step_number int NOT NULL,
  step_id text NOT NULL,
  step_name text NOT NULL,
  description text,
  process_details jsonb NOT NULL DEFAULT '{}'::jsonb,
  input_requirements jsonb DEFAULT '{}'::jsonb,
  output_specifications jsonb DEFAULT '{}'::jsonb,
  quality_checks jsonb DEFAULT '{}'::jsonb,
  estimated_duration_minutes int,
  dependencies jsonb DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(pipeline_id, step_number)
);

-- Enable RLS
ALTER TABLE generation_blueprints ENABLE ROW LEVEL SECURITY;
ALTER TABLE format_specifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_model_configurations ENABLE ROW LEVEL SECURITY;
ALTER TABLE worker_configurations ENABLE ROW LEVEL SECURITY;
ALTER TABLE quality_thresholds ENABLE ROW LEVEL SECURITY;
ALTER TABLE image_specifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE step_blueprints ENABLE ROW LEVEL SECURITY;

-- RLS Policies - Public read for operational data
CREATE POLICY "Anyone can read blueprints"
  ON generation_blueprints FOR SELECT
  USING (true);

CREATE POLICY "Anyone can read format specs"
  ON format_specifications FOR SELECT
  USING (true);

CREATE POLICY "Anyone can read AI model configs"
  ON ai_model_configurations FOR SELECT
  USING (true);

CREATE POLICY "Anyone can read worker configs"
  ON worker_configurations FOR SELECT
  USING (true);

CREATE POLICY "Anyone can read quality thresholds"
  ON quality_thresholds FOR SELECT
  USING (true);

CREATE POLICY "Anyone can read image specs"
  ON image_specifications FOR SELECT
  USING (true);

CREATE POLICY "Anyone can read step blueprints"
  ON step_blueprints FOR SELECT
  USING (true);

-- Admin-only write policies
CREATE POLICY "Admins can insert blueprints"
  ON generation_blueprints FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Admins can update blueprints"
  ON generation_blueprints FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Admins can insert format specs"
  ON format_specifications FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Admins can update format specs"
  ON format_specifications FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Admins can insert AI model configs"
  ON ai_model_configurations FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Admins can update AI model configs"
  ON ai_model_configurations FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Admins can insert worker configs"
  ON worker_configurations FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Admins can update worker configs"
  ON worker_configurations FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Admins can insert quality thresholds"
  ON quality_thresholds FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Admins can update quality thresholds"
  ON quality_thresholds FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Admins can insert image specs"
  ON image_specifications FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Admins can update image specs"
  ON image_specifications FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Admins can insert step blueprints"
  ON step_blueprints FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Admins can update step blueprints"
  ON step_blueprints FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_blueprints_type ON generation_blueprints(blueprint_type);
CREATE INDEX IF NOT EXISTS idx_blueprints_pipeline ON generation_blueprints(pipeline_number);
CREATE INDEX IF NOT EXISTS idx_format_specs_book_type ON format_specifications(book_type);
CREATE INDEX IF NOT EXISTS idx_ai_configs_pipeline_step ON ai_model_configurations(pipeline_id, step_id);
CREATE INDEX IF NOT EXISTS idx_worker_configs_pipeline_step ON worker_configurations(pipeline_id, step_id);
CREATE INDEX IF NOT EXISTS idx_quality_pipeline_step ON quality_thresholds(pipeline_id, step_id);
CREATE INDEX IF NOT EXISTS idx_step_blueprints_pipeline ON step_blueprints(pipeline_id, step_number);
