/*
  # Comprehensive Educational Platform Expansion

  ## Overview
  This migration expands the educational content generation platform with:
  - Add-ons system (8 supplement types per book)
  - Enhanced interactive lessons with AI tutor
  - Country-specific customization
  - Multi-language translation support
  - Textbook design system
  - Illustration asset management
  - Enhanced book versions with special editions

  ## 1. Book Versions Table Updates
  
  Adds fields for special editions:
    - `is_library_edition` - For comprehensive Library/Reference format
    - `is_textbook_edition` - For professional textbook design
    - `is_honors` - For Honors/Advanced versions
    - `theme_applied` - Theme/color scheme used in design
  
  Updates reading_level enum to include 'library'

  ## 2. New Tables

  ### Educational Add-ons
    - `book_addons` - Educational supplements for each book
      - Stores 8 types: activity_pack, worksheet_set, quiz_pack, answer_key, 
        lesson_plans, presentation_slides, career_guide, study_guide
      - Generated automatically for all books
      - One record per addon type per reading level

  ### Textbook Design System
    - `textbook_designs` - Professional textbook cover and interior designs
      - Cover design data (front, spine, back)
      - Interior templates and themes
      - Typography and layout configurations
      - Design status tracking

  ### Global Distribution
    - `country_packages` - Country-specific customized versions
      - ISO country codes, language codes
      - Tracks customizations applied (examples, units, references)
      - Supports all 195+ countries

    - `language_translations` - Multi-language book translations
      - Source and target language tracking
      - AI provider used for translation
      - Multi-verification system (quality scores)
      - Supports 200-300 languages

  ### Interactive Learning Enhancements
    - Updates `interactive_lessons` with:
      - Voice-enabled TTS support
      - AI tutor availability flag
      - Adaptive difficulty settings
      - Performance metrics (completion rate, average score)

    - `tutor_sessions` - AI tutor chat history
      - Conversation logs per user
      - Questions asked and concepts mastered
      - Time tracking and performance data

  ### Visual Assets
    - `illustration_assets` - Image and diagram management
      - Stock photos, diagrams, infographics
      - Source tracking and positioning data
      - Caption and alt-text for accessibility

  ### User Preferences
    - `user_preferences` - Per-user settings
      - Theme preferences
      - Language preferences
      - Learning settings

  ## 3. Security
  
  All new tables have RLS enabled:
    - Public read access for completed content
    - Authenticated write access for system operations
    - User-specific access for preferences and tutor sessions

  ## 4. Indexes
  
  Performance indexes on:
    - Foreign key relationships
    - Status fields for filtering
    - Date fields for sorting
    - Country and language codes for lookups
*/

-- ============================================
-- PART 1: Update book_versions table
-- ============================================

-- Add new columns to book_versions
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'book_versions' AND column_name = 'is_library_edition'
  ) THEN
    ALTER TABLE book_versions ADD COLUMN is_library_edition boolean DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'book_versions' AND column_name = 'is_textbook_edition'
  ) THEN
    ALTER TABLE book_versions ADD COLUMN is_textbook_edition boolean DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'book_versions' AND column_name = 'is_honors'
  ) THEN
    ALTER TABLE book_versions ADD COLUMN is_honors boolean DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'book_versions' AND column_name = 'theme_applied'
  ) THEN
    ALTER TABLE book_versions ADD COLUMN theme_applied text;
  END IF;
END $$;

-- Update reading_level check constraint to include 'library'
ALTER TABLE book_versions DROP CONSTRAINT IF EXISTS book_versions_reading_level_check;
ALTER TABLE book_versions ADD CONSTRAINT book_versions_reading_level_check 
  CHECK (reading_level IN ('phd', 'masters', 'bachelors', 'high_school', 'middle_school', 'elementary', 'kindergarten', 'library'));

-- ============================================
-- PART 2: Create book_addons table
-- ============================================

CREATE TABLE IF NOT EXISTS book_addons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id uuid NOT NULL REFERENCES books(id) ON DELETE CASCADE,
  reading_level text NOT NULL CHECK (reading_level IN ('phd', 'masters', 'bachelors', 'high_school', 'middle_school', 'elementary', 'kindergarten', 'library')),
  addon_type text NOT NULL CHECK (addon_type IN ('activity_pack', 'worksheet_set', 'quiz_pack', 'answer_key', 'lesson_plans', 'presentation_slides', 'career_guide', 'study_guide')),
  file_url text,
  file_size bigint DEFAULT 0,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(book_id, reading_level, addon_type)
);

-- ============================================
-- PART 3: Create textbook_designs table
-- ============================================

CREATE TABLE IF NOT EXISTS textbook_designs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id uuid NOT NULL REFERENCES books(id) ON DELETE CASCADE,
  reading_level text NOT NULL CHECK (reading_level IN ('phd', 'masters', 'bachelors', 'high_school', 'middle_school', 'elementary', 'kindergarten', 'library')),
  cover_design_data jsonb DEFAULT '{}',
  interior_template_id text,
  theme_name text,
  color_scheme jsonb DEFAULT '{}',
  page_layout_config jsonb DEFAULT '{}',
  typography_config jsonb DEFAULT '{}',
  design_status text NOT NULL DEFAULT 'pending' CHECK (design_status IN ('pending', 'processing', 'completed', 'failed')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(book_id, reading_level)
);

-- ============================================
-- PART 4: Create country_packages table
-- ============================================

CREATE TABLE IF NOT EXISTS country_packages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id uuid NOT NULL REFERENCES books(id) ON DELETE CASCADE,
  reading_level text NOT NULL CHECK (reading_level IN ('phd', 'masters', 'bachelors', 'high_school', 'middle_school', 'elementary', 'kindergarten', 'library')),
  country_code text NOT NULL,
  country_name text NOT NULL,
  language_code text NOT NULL,
  customization_applied jsonb DEFAULT '{}',
  file_url text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(book_id, reading_level, country_code)
);

-- ============================================
-- PART 5: Create language_translations table
-- ============================================

CREATE TABLE IF NOT EXISTS language_translations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id uuid NOT NULL REFERENCES books(id) ON DELETE CASCADE,
  reading_level text NOT NULL CHECK (reading_level IN ('phd', 'masters', 'bachelors', 'high_school', 'middle_school', 'elementary', 'kindergarten', 'library')),
  source_language text NOT NULL DEFAULT 'en',
  target_language text NOT NULL,
  language_name text NOT NULL,
  translation_provider text,
  verification_status text NOT NULL DEFAULT 'unverified' CHECK (verification_status IN ('unverified', 'in_progress', 'verified', 'failed')),
  verification_count integer DEFAULT 0,
  quality_score numeric(3, 2) DEFAULT 0.0 CHECK (quality_score >= 0 AND quality_score <= 1),
  file_url text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(book_id, reading_level, target_language)
);

-- ============================================
-- PART 6: Update interactive_lessons table
-- ============================================

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'interactive_lessons' AND column_name = 'voice_enabled'
  ) THEN
    ALTER TABLE interactive_lessons ADD COLUMN voice_enabled boolean DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'interactive_lessons' AND column_name = 'ai_tutor_available'
  ) THEN
    ALTER TABLE interactive_lessons ADD COLUMN ai_tutor_available boolean DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'interactive_lessons' AND column_name = 'difficulty_adaptive'
  ) THEN
    ALTER TABLE interactive_lessons ADD COLUMN difficulty_adaptive boolean DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'interactive_lessons' AND column_name = 'completion_rate'
  ) THEN
    ALTER TABLE interactive_lessons ADD COLUMN completion_rate numeric(5, 2) DEFAULT 0.0 CHECK (completion_rate >= 0 AND completion_rate <= 100);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'interactive_lessons' AND column_name = 'average_score'
  ) THEN
    ALTER TABLE interactive_lessons ADD COLUMN average_score numeric(5, 2) DEFAULT 0.0 CHECK (average_score >= 0 AND average_score <= 100);
  END IF;
END $$;

-- Update reading_level check constraint
ALTER TABLE interactive_lessons DROP CONSTRAINT IF EXISTS interactive_lessons_reading_level_check;
ALTER TABLE interactive_lessons ADD CONSTRAINT interactive_lessons_reading_level_check 
  CHECK (reading_level IN ('phd', 'masters', 'bachelors', 'high_school', 'middle_school', 'elementary', 'kindergarten', 'library'));

-- ============================================
-- PART 7: Create tutor_sessions table
-- ============================================

CREATE TABLE IF NOT EXISTS tutor_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  book_id uuid NOT NULL REFERENCES books(id) ON DELETE CASCADE,
  lesson_id uuid REFERENCES interactive_lessons(id) ON DELETE SET NULL,
  conversation_log jsonb DEFAULT '[]',
  questions_asked integer DEFAULT 0,
  concepts_mastered jsonb DEFAULT '[]',
  time_spent integer DEFAULT 0,
  session_start timestamptz DEFAULT now(),
  session_end timestamptz,
  created_at timestamptz DEFAULT now()
);

-- ============================================
-- PART 8: Create illustration_assets table
-- ============================================

CREATE TABLE IF NOT EXISTS illustration_assets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id uuid NOT NULL REFERENCES books(id) ON DELETE CASCADE,
  page_number integer NOT NULL,
  asset_type text NOT NULL CHECK (asset_type IN ('stock_photo', 'diagram', 'ai_generated', 'infographic')),
  source_url text,
  alt_text text,
  caption text,
  position_data jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- ============================================
-- PART 9: Create indexes for performance
-- ============================================

CREATE INDEX IF NOT EXISTS idx_book_addons_book_id ON book_addons(book_id);
CREATE INDEX IF NOT EXISTS idx_book_addons_status ON book_addons(status);
CREATE INDEX IF NOT EXISTS idx_book_addons_type ON book_addons(addon_type);

CREATE INDEX IF NOT EXISTS idx_textbook_designs_book_id ON textbook_designs(book_id);
CREATE INDEX IF NOT EXISTS idx_textbook_designs_status ON textbook_designs(design_status);

CREATE INDEX IF NOT EXISTS idx_country_packages_book_id ON country_packages(book_id);
CREATE INDEX IF NOT EXISTS idx_country_packages_country ON country_packages(country_code);
CREATE INDEX IF NOT EXISTS idx_country_packages_status ON country_packages(status);

CREATE INDEX IF NOT EXISTS idx_language_translations_book_id ON language_translations(book_id);
CREATE INDEX IF NOT EXISTS idx_language_translations_language ON language_translations(target_language);
CREATE INDEX IF NOT EXISTS idx_language_translations_status ON language_translations(status);

CREATE INDEX IF NOT EXISTS idx_tutor_sessions_user_id ON tutor_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_tutor_sessions_book_id ON tutor_sessions(book_id);
CREATE INDEX IF NOT EXISTS idx_tutor_sessions_lesson_id ON tutor_sessions(lesson_id);

CREATE INDEX IF NOT EXISTS idx_illustration_assets_book_id ON illustration_assets(book_id);
CREATE INDEX IF NOT EXISTS idx_illustration_assets_type ON illustration_assets(asset_type);

-- ============================================
-- PART 10: Enable Row Level Security
-- ============================================

ALTER TABLE book_addons ENABLE ROW LEVEL SECURITY;
ALTER TABLE textbook_designs ENABLE ROW LEVEL SECURITY;
ALTER TABLE country_packages ENABLE ROW LEVEL SECURITY;
ALTER TABLE language_translations ENABLE ROW LEVEL SECURITY;
ALTER TABLE tutor_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE illustration_assets ENABLE ROW LEVEL SECURITY;

-- ============================================
-- PART 11: Create RLS Policies
-- ============================================

-- book_addons policies
CREATE POLICY "Anyone can view completed book addons"
  ON book_addons FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM books
      WHERE books.id = book_addons.book_id
      AND books.status = 'completed'
    )
  );

CREATE POLICY "Authenticated users can manage book addons"
  ON book_addons FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- textbook_designs policies
CREATE POLICY "Anyone can view textbook designs for completed books"
  ON textbook_designs FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM books
      WHERE books.id = textbook_designs.book_id
      AND books.status = 'completed'
    )
  );

CREATE POLICY "Authenticated users can manage textbook designs"
  ON textbook_designs FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- country_packages policies
CREATE POLICY "Anyone can view completed country packages"
  ON country_packages FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM books
      WHERE books.id = country_packages.book_id
      AND books.status = 'completed'
    )
  );

CREATE POLICY "Authenticated users can manage country packages"
  ON country_packages FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- language_translations policies
CREATE POLICY "Anyone can view completed translations"
  ON language_translations FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM books
      WHERE books.id = language_translations.book_id
      AND books.status = 'completed'
    )
  );

CREATE POLICY "Authenticated users can manage translations"
  ON language_translations FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- tutor_sessions policies
CREATE POLICY "Users can view own tutor sessions"
  ON tutor_sessions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create tutor sessions"
  ON tutor_sessions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own tutor sessions"
  ON tutor_sessions FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Authenticated users can delete own tutor sessions"
  ON tutor_sessions FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- illustration_assets policies
CREATE POLICY "Anyone can view illustration assets for completed books"
  ON illustration_assets FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM books
      WHERE books.id = illustration_assets.book_id
      AND books.status = 'completed'
    )
  );

CREATE POLICY "Authenticated users can manage illustration assets"
  ON illustration_assets FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- ============================================
-- PART 12: Add update triggers
-- ============================================

CREATE TRIGGER update_book_addons_updated_at BEFORE UPDATE ON book_addons
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_textbook_designs_updated_at BEFORE UPDATE ON textbook_designs
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_country_packages_updated_at BEFORE UPDATE ON country_packages
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_language_translations_updated_at BEFORE UPDATE ON language_translations
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
