/*
  # Generation Groups and Scaling Configuration
  
  This migration creates tables to store our generation planning:
  
  1. New Tables
    - `generation_groups` - The groups/subcategories we're generating
    - `topic_inventory` - Complete inventory of all topics to generate
    - `scaling_scenarios` - Different worker scaling scenarios (1M, 10M, 100M workers)
    - `storage_requirements` - Storage calculations and costs
    
  2. Purpose
    - Save all the planning work for book generation
    - Track groups, topics, workers, timelines, costs
    - Reference for scaling decisions
    
  3. Security
    - Enable RLS on all tables
    - Authenticated users can read
    - Only admins can modify (future implementation)
*/

-- Generation Groups (the categories/subcategories we're generating)
CREATE TABLE IF NOT EXISTS generation_groups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_number integer NOT NULL,
  group_name text NOT NULL,
  category_id uuid REFERENCES book_categories(id),
  parent_group_id uuid REFERENCES generation_groups(id),
  topic_count integer NOT NULL DEFAULT 0,
  description text,
  applicable_reading_levels text[] DEFAULT ARRAY['library', 'phd', 'masters', 'bachelors', 'high_school', 'middle_school', 'elementary', 'kindergarten'],
  worker_config jsonb DEFAULT '{}',
  generation_priority integer DEFAULT 999,
  is_active boolean DEFAULT true,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Topic Inventory (all the individual topics we need to generate)
CREATE TABLE IF NOT EXISTS topic_inventory (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  generation_group_id uuid REFERENCES generation_groups(id),
  topic_name text NOT NULL,
  subject_area text NOT NULL,
  description text,
  estimated_page_count integer DEFAULT 400,
  priority_level integer DEFAULT 5 CHECK (priority_level >= 1 AND priority_level <= 10),
  generation_status text DEFAULT 'pending' CHECK (generation_status IN ('pending', 'queued', 'processing', 'completed', 'failed')),
  book_id uuid REFERENCES books(id),
  tags text[] DEFAULT '{}',
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Scaling Scenarios (worker counts and timelines)
CREATE TABLE IF NOT EXISTS scaling_scenarios (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  scenario_name text UNIQUE NOT NULL,
  worker_count bigint NOT NULL,
  total_topics bigint NOT NULL,
  time_per_book_hours numeric DEFAULT 3.0,
  books_per_worker_lifetime integer DEFAULT 50,
  total_timeline_days numeric,
  total_timeline_readable text,
  parallel_processing boolean DEFAULT true,
  cost_estimate_usd numeric,
  infrastructure_notes text,
  is_recommended boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Storage Requirements (calculations for storage needs)
CREATE TABLE IF NOT EXISTS storage_requirements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  calculation_name text UNIQUE NOT NULL,
  total_base_books bigint NOT NULL,
  reading_level_multiplier integer DEFAULT 8,
  disability_multiplier integer DEFAULT 40,
  total_book_versions bigint,
  avg_book_size_mb numeric DEFAULT 2.5,
  total_storage_pb numeric,
  storage_cost_per_tb_usd numeric DEFAULT 20,
  monthly_storage_cost_usd numeric,
  yearly_storage_cost_usd numeric,
  with_corporate_grants boolean DEFAULT false,
  grant_discount_percent numeric DEFAULT 0,
  notes text,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE generation_groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE topic_inventory ENABLE ROW LEVEL SECURITY;
ALTER TABLE scaling_scenarios ENABLE ROW LEVEL SECURITY;
ALTER TABLE storage_requirements ENABLE ROW LEVEL SECURITY;

-- RLS Policies (read-only for authenticated users)
CREATE POLICY "Authenticated users can view generation groups"
  ON generation_groups FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can view topic inventory"
  ON topic_inventory FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can view scaling scenarios"
  ON scaling_scenarios FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can view storage requirements"
  ON storage_requirements FOR SELECT
  TO authenticated
  USING (true);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_generation_groups_category ON generation_groups(category_id);
CREATE INDEX IF NOT EXISTS idx_generation_groups_active ON generation_groups(is_active);
CREATE INDEX IF NOT EXISTS idx_topic_inventory_group ON topic_inventory(generation_group_id);
CREATE INDEX IF NOT EXISTS idx_topic_inventory_status ON topic_inventory(generation_status);
CREATE INDEX IF NOT EXISTS idx_topic_inventory_priority ON topic_inventory(priority_level);