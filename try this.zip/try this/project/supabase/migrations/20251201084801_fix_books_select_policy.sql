/*
  # Fix Books SELECT Policy

  1. Changes
    - Add policy to allow authenticated users to view ALL books (not just completed)
    - Keep existing policy for public to view completed books

  2. Security
    - Authenticated users can see all books (needed for dashboard)
    - Public users can only see completed books
*/

CREATE POLICY "Authenticated users can view all books"
  ON books
  FOR SELECT
  TO authenticated
  USING (auth.uid() IS NOT NULL);
