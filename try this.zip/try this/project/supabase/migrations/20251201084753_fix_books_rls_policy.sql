/*
  # Fix Books RLS Policy for Authenticated Users

  1. Changes
    - Drop existing INSERT policy
    - Create new INSERT policy that explicitly checks auth.uid() is not null
    - This ensures authenticated users can definitely insert books

  2. Security
    - Still requires authentication
    - More explicit check for authenticated state
*/

DROP POLICY IF EXISTS "Authenticated users can insert books" ON books;

CREATE POLICY "Authenticated users can insert books"
  ON books
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() IS NOT NULL);
