/*
  # Update Book Categories - Remove General Reading, Merge Sensory & AAC

  ## Overview
  This migration restructures the book categories based on updated requirements:
  - Removes Category 1 (General Reading Library) - not feasible
  - Merges Category 7 (Sensory Support) into disability adaptation system
  - Merges Category 8 (AAC & Communication) into disability adaptation system
  - Results in 5 main educational book categories
  
  ## Changes
  1. Mark 'general_reading' category as inactive (soft delete)
  2. Mark 'sensory_support' category as inactive (now part of disabilities)
  3. Mark 'aac_communication' category as inactive (now part of disabilities)
  4. Update order_index for remaining categories
  5. Add notes explaining the changes
  
  ## Final Active Categories (5 total)
  1. Educational Textbooks (K-12) - Main priority
  2. Life Skills & Transition (14-22)
  3. Early Intervention (0-5)
  4. Social Skills Curriculum
  5. Executive Function
  
  ## Notes
  - Sensory support is now handled as disability adaptations applied to ANY book
  - AAC/Communication is now handled as disability adaptations applied to ANY book
  - General Reading removed as it's not legally feasible (can't copy existing books)
  - All educational content is the focus
*/

-- Mark categories as inactive instead of deleting (preserves data integrity)
UPDATE book_categories 
SET 
  is_active = false,
  description = CASE 
    WHEN category_name = 'general_reading' 
      THEN 'REMOVED: Not feasible due to copyright limitations. Focus is on educational content only.'
    WHEN category_name = 'sensory_support'
      THEN 'MERGED INTO DISABILITY ADAPTATIONS: Sensory support is now an adaptation layer applied to any book for students with sensory needs.'
    WHEN category_name = 'aac_communication'
      THEN 'MERGED INTO DISABILITY ADAPTATIONS: AAC/Communication support is now an adaptation layer applied to any book for non-verbal students.'
    ELSE description
  END
WHERE category_name IN ('general_reading', 'sensory_support', 'aac_communication');

-- Update order_index for remaining active categories
UPDATE book_categories SET order_index = 1 WHERE category_name = 'educational_textbooks';
UPDATE book_categories SET order_index = 2 WHERE category_name = 'life_skills_transition';
UPDATE book_categories SET order_index = 3 WHERE category_name = 'early_intervention';
UPDATE book_categories SET order_index = 4 WHERE category_name = 'social_skills';
UPDATE book_categories SET order_index = 5 WHERE category_name = 'executive_function';

-- Add comment to clarify the new structure
COMMENT ON TABLE book_categories IS 'Book categories for the global educational library. Categories 1, 7, and 8 have been removed/merged. Sensory and AAC support are now handled through the disability_profiles and disability_adaptations system, allowing any book to be adapted for sensory needs or AAC users.';

-- Ensure sensory and AAC-related disabilities are properly configured
-- Update Sensory Processing Disorder to indicate it covers sensory support
UPDATE disability_profiles 
SET 
  description = 'Difficulty processing and responding to sensory information. This profile covers all sensory support needs previously in the Sensory Support category.',
  adaptation_guidelines = jsonb_build_object(
    'visual', 'High contrast, reduced clutter, predictable layouts',
    'auditory', 'Volume control, quiet options, minimal background noise',
    'tactile', 'Texture warnings, smooth materials, tactile alternatives',
    'vestibular', 'Stable layouts, minimal motion, grounding elements',
    'proprioceptive', 'Movement breaks, heavy work options, body awareness',
    'interoceptive', 'Emotion check-ins, body signal recognition',
    'olfactory', 'Scent-free, no strong smells',
    'gustatory', 'Food references mindful of sensitivities'
  )
WHERE disability_name = 'Sensory Processing Disorder';

-- Update Speech/Language Impairments to cover AAC communication needs
UPDATE disability_profiles 
SET 
  description = 'Difficulties with speech production, language comprehension, or expression. Includes AAC (Augmentative & Alternative Communication) users who are non-verbal or minimally verbal.',
  adaptation_guidelines = jsonb_build_object(
    'aac_integration', 'Picture symbols, core vocabulary boards, communication device compatibility',
    'visual_supports', 'Visual schedules, picture supports, symbol-based content',
    'communication_levels', 'Adapted for various communication abilities',
    'partner_training', 'Includes communication partner guidance',
    'multimodal', 'Supports gestures, signs, pictures, and speech'
  ),
  common_accommodations = '["Visual communication aids", "AAC device compatible", "Core vocabulary integration", "Picture symbols", "Alternative response methods", "Extra processing time", "Clear articulation models", "Communication partner training"]'::jsonb
WHERE disability_name = 'Speech/Language Impairments';

-- Create a view to easily see active categories
CREATE OR REPLACE VIEW active_book_categories AS
SELECT 
  id,
  category_name,
  display_name,
  description,
  target_age_range,
  order_index,
  created_at
FROM book_categories
WHERE is_active = true
ORDER BY order_index;