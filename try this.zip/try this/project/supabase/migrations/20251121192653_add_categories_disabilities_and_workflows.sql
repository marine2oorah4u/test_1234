/*
  # Comprehensive Special Education & Book Category System

  ## Overview
  This migration transforms the platform into a comprehensive educational content system with:
  - 8 separate book categories (Reading, Textbooks, Life Skills, etc.)
  - 40 disability/condition profiles for adapted content
  - Disability-specific adaptation tracking
  - Full workflow system for content generation
  - Cultural adaptation and low-resource support

  ## 1. New Tables

  ### Book Categories System
    - `book_categories` - The 8 main content categories
      - `id` (uuid, primary key)
      - `category_name` (text, unique) - Category identifier
      - `display_name` (text) - User-friendly name
      - `description` (text) - Category description
      - `target_age_range` (text) - Age range (e.g., "14-22", "0-5", "All Ages")
      - `workflow_config` (jsonb) - Category-specific workflow steps
      - `is_active` (boolean) - Whether category is active
      - `order_index` (integer) - Display order
      - `created_at` (timestamptz)

  ### Disability Profiles System
    - `disability_profiles` - 40 disability/condition profiles
      - `id` (uuid, primary key)
      - `disability_name` (text, unique) - Standardized name
      - `category` (text) - Grouping: cognitive, physical, sensory, behavioral, developmental, etc.
      - `priority_tier` (integer) - 1=Top 10, 2=Top 25, 3=Top 40
      - `description` (text) - Detailed description
      - `adaptation_guidelines` (jsonb) - Best practices for adaptations
      - `common_accommodations` (jsonb) - Typical accommodations needed
      - `is_active` (boolean) - Whether actively supported
      - `created_at` (timestamptz)

  ### Disability Adaptations Tracking
    - `disability_adaptations` - Tracks adapted versions of content
      - `id` (uuid, primary key)
      - `book_id` (uuid, foreign key) - Source book
      - `reading_level` (text) - Reading level of source
      - `disability_id` (uuid, foreign key) - Target disability
      - `adapted_content_url` (text) - Storage URL for adapted version
      - `adaptations_applied` (jsonb) - List of specific adaptations made
      - `adaptation_notes` (text) - Additional context
      - `validation_count` (integer) - How many validation passes
      - `quality_score` (numeric) - Overall quality (0-1)
      - `status` (text) - pending, processing, completed, failed
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  ### Workflow System
    - `workflow_templates` - Master workflow definitions
      - `id` (uuid, primary key)
      - `workflow_name` (text, unique) - Identifier
      - `workflow_type` (text) - base, accessibility, disability_specific, translation, cultural
      - `category_id` (uuid, nullable) - If category-specific
      - `disability_id` (uuid, nullable) - If disability-specific
      - `steps` (jsonb) - Array of workflow steps with details
      - `estimated_duration` (integer) - Minutes to complete
      - `is_active` (boolean)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `workflow_executions` - Tracks individual workflow runs
      - `id` (uuid, primary key)
      - `book_id` (uuid, foreign key) - Book being processed
      - `template_id` (uuid, foreign key) - Workflow template used
      - `current_step` (integer) - Current step index
      - `status` (text) - queued, running, paused, completed, failed
      - `progress_data` (jsonb) - Detailed progress per step
      - `error_log` (jsonb) - Any errors encountered
      - `started_at` (timestamptz)
      - `completed_at` (timestamptz)
      - `created_at` (timestamptz)

  ### Cultural & Low-Resource Support
    - `cultural_adaptations` - Cultural customizations
      - `id` (uuid, primary key)
      - `book_id` (uuid, foreign key)
      - `reading_level` (text)
      - `culture_region` (text) - Region/culture identifier
      - `adaptations_made` (jsonb) - List of cultural changes
      - `examples_localized` (jsonb) - Before/after examples
      - `cultural_sensitivity_notes` (text)
      - `status` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `low_resource_versions` - Print-only, offline versions
      - `id` (uuid, primary key)
      - `book_id` (uuid, foreign key)
      - `reading_level` (text)
      - `version_type` (text) - black_white, minimal_materials, offline_complete
      - `file_url` (text)
      - `teacher_guide_url` (text) - Minimal training guide
      - `materials_needed` (jsonb) - Required materials list
      - `cost_estimate` (numeric) - Estimated printing cost
      - `status` (text)
      - `created_at` (timestamptz)

  ### Enhanced Books Table
    - Add `category_id` to books table
    - Add `requires_disability_adaptations` boolean
    - Add `target_disabilities` array for filtering

  ## 2. Security
    - All tables have RLS enabled
    - Public read for completed content
    - Authenticated write for system operations
    - Admin-only for workflow and profile management

  ## 3. Indexes
    - Foreign key relationships
    - Status and category filters
    - Disability lookups
    - Workflow tracking

  ## 4. Important Notes
    - Disability adaptations are automatically triggered for applicable categories
    - Each workflow tracks progress and errors in detail
    - Cultural adaptations are optional but recommended
    - Low-resource versions follow same quality standards
    - All adaptations go through full validation pipeline
*/

-- ============================================
-- PART 1: Create book_categories table
-- ============================================

CREATE TABLE IF NOT EXISTS book_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_name text NOT NULL UNIQUE,
  display_name text NOT NULL,
  description text NOT NULL,
  target_age_range text,
  workflow_config jsonb DEFAULT '{}',
  is_active boolean DEFAULT true,
  order_index integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Insert the 8 main categories
INSERT INTO book_categories (category_name, display_name, description, target_age_range, order_index)
VALUES 
  ('general_reading', 'General Reading Library', 'Storybooks, novels, picture books for leisure and enjoyment. Fiction and non-fiction for home reading and libraries.', 'All Ages', 1),
  ('educational_textbooks', 'Educational Textbooks', 'K-12 curriculum textbooks, workbooks, and subject-specific materials for formal education.', '5-18', 2),
  ('life_skills_transition', 'Life Skills & Transition', 'Job skills, independent living, self-advocacy, and community navigation for young adults with disabilities.', '14-22', 3),
  ('early_intervention', 'Early Intervention', 'Parent-guided activities, pre-literacy, communication development, and therapy support for young children.', '0-5', 4),
  ('social_skills', 'Social Skills Curriculum', 'Social stories, perspective-taking, conversation skills, emotion regulation, and friendship building.', '3-21', 5),
  ('executive_function', 'Executive Function', 'Organization, planning, time management, task breakdown, and self-monitoring skills.', '6-21', 6),
  ('sensory_support', 'Sensory Support', 'Sensory-friendly activities, calming strategies, sensory breaks, and sensory diet implementation.', '2-21', 7),
  ('aac_communication', 'AAC & Communication', 'Communication boards, symbol-based activities, core vocabulary practice, and alternative communication supports.', '2-21', 8)
ON CONFLICT (category_name) DO NOTHING;

-- ============================================
-- PART 2: Create disability_profiles table
-- ============================================

CREATE TABLE IF NOT EXISTS disability_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  disability_name text NOT NULL UNIQUE,
  category text NOT NULL CHECK (category IN ('cognitive', 'physical', 'sensory', 'behavioral', 'developmental', 'neurological', 'learning', 'communication', 'multiple')),
  priority_tier integer NOT NULL CHECK (priority_tier IN (1, 2, 3)),
  description text NOT NULL,
  adaptation_guidelines jsonb DEFAULT '{}',
  common_accommodations jsonb DEFAULT '[]',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Insert Top 10 disabilities (Priority Tier 1)
INSERT INTO disability_profiles (disability_name, category, priority_tier, description, common_accommodations)
VALUES 
  ('Autism Spectrum Disorder', 'developmental', 1, 'Neurodevelopmental condition affecting social communication, behavior, and sensory processing.', '["Visual supports", "Clear routines", "Predictable structure", "Social elements reduced", "Sensory considerations"]'::jsonb),
  ('ADHD', 'neurological', 1, 'Attention Deficit Hyperactivity Disorder affecting focus, impulse control, and activity levels.', '["Shorter bursts", "Movement breaks", "High engagement", "Minimal distractions", "Clear instructions"]'::jsonb),
  ('Specific Learning Disabilities', 'learning', 1, 'Includes Dyslexia, Dyscalculia, Dysgraphia affecting reading, math, or writing.', '["Multi-sensory approach", "Extra time", "Assistive technology", "Modified materials", "Step-by-step instructions"]'::jsonb),
  ('Intellectual Disability', 'cognitive', 1, 'Significant limitations in intellectual functioning and adaptive behavior.', '["Simplified language", "More scaffolding", "Real-world contexts", "Visual supports", "Repetition"]'::jsonb),
  ('Speech/Language Impairments', 'communication', 1, 'Difficulties with speech production, language comprehension, or expression.', '["Visual communication aids", "Extra processing time", "Alternative response methods", "Clear articulation models"]'::jsonb),
  ('Visual Impairments', 'sensory', 1, 'Low vision or blindness affecting access to visual information.', '["Tactile elements", "Audio descriptions", "High contrast", "Large print", "Screen reader compatible"]'::jsonb),
  ('Deaf/Hard of Hearing', 'sensory', 1, 'Hearing loss affecting access to auditory information.', '["Visual-heavy content", "No audio dependencies", "Captions/transcripts", "Sign language integration", "Visual alerts"]'::jsonb),
  ('Physical Disabilities', 'physical', 1, 'Includes Cerebral Palsy and motor impairments affecting movement and coordination.', '["Accessible formats", "Adaptive equipment compatible", "No fine motor requirements", "Alternative input methods"]'::jsonb),
  ('Emotional/Behavioral Disorders', 'behavioral', 1, 'Difficulties with emotional regulation and behavior affecting learning.', '["Clear expectations", "Positive reinforcement", "Calming strategies", "Choice options", "Predictable routines"]'::jsonb),
  ('Traumatic Brain Injury', 'neurological', 1, 'Brain injury causing cognitive, physical, or behavioral changes.', '["Simplified content", "Memory aids", "Frequent breaks", "Multi-sensory input", "Flexible pacing"]'::jsonb);

-- Insert disabilities 11-25 (Priority Tier 2)
INSERT INTO disability_profiles (disability_name, category, priority_tier, description, common_accommodations)
VALUES 
  ('Auditory Processing Disorder', 'sensory', 2, 'Difficulty processing auditory information despite normal hearing.', '["Visual reinforcement", "Written instructions", "Quiet environment", "Extra processing time", "Repetition"]'::jsonb),
  ('Down Syndrome', 'developmental', 2, 'Genetic condition causing intellectual disability and characteristic features.', '["Simplified language", "Visual supports", "Hands-on learning", "Repetition", "Peer modeling"]'::jsonb),
  ('Sensory Processing Disorder', 'sensory', 2, 'Difficulty processing and responding to sensory information.', '["Sensory breaks", "Reduced stimulation", "Clear sensory warnings", "Alternative textures", "Flexible seating"]'::jsonb),
  ('Anxiety Disorders', 'behavioral', 2, 'Excessive worry or fear affecting daily functioning and learning.', '["Predictable routines", "Calming strategies", "Choice options", "Safe spaces", "Gradual exposure"]'::jsonb),
  ('Depression', 'behavioral', 2, 'Persistent sadness and loss of interest affecting cognition and learning.', '["Flexible deadlines", "Encouraging tone", "Small achievable goals", "Positive reinforcement", "Check-ins"]'::jsonb),
  ('Oppositional Defiant Disorder', 'behavioral', 2, 'Pattern of angry, defiant behavior toward authority figures.', '["Clear expectations", "Choice within limits", "Positive reinforcement", "Consistent consequences", "Respectful tone"]'::jsonb),
  ('Tourette Syndrome', 'neurological', 2, 'Neurological condition causing involuntary movements or sounds (tics).', '["Flexible expectations", "Tic breaks allowed", "Non-judgmental environment", "Stress reduction", "Focus on content not delivery"]'::jsonb),
  ('Epilepsy', 'neurological', 2, 'Seizure disorder that can affect memory and learning.', '["No flashing content", "Memory aids", "Flexible pacing", "Safety considerations", "Seizure response plan"]'::jsonb),
  ('Fetal Alcohol Spectrum Disorders', 'developmental', 2, 'Prenatal alcohol exposure causing cognitive and behavioral challenges.', '["Clear structure", "Simplified instructions", "Visual aids", "Repetition", "Concrete examples"]'::jsonb),
  ('Fragile X Syndrome', 'developmental', 2, 'Genetic condition causing intellectual disability and behavioral challenges.', '["Visual supports", "Reduced anxiety triggers", "Clear routines", "Sensory considerations", "Social skills support"]'::jsonb),
  ('Nonverbal Learning Disability', 'learning', 2, 'Difficulty with visual-spatial skills, motor skills, and social understanding.', '["Verbal instruction emphasis", "Step-by-step breakdown", "Explicit social teaching", "Organizational support"]'::jsonb),
  ('Selective Mutism', 'communication', 2, 'Anxiety-based inability to speak in certain situations.', '["Alternative communication methods", "No forced speech", "Gradual exposure", "Low-pressure environment"]'::jsonb),
  ('Apraxia of Speech', 'communication', 2, 'Motor speech disorder affecting ability to plan and coordinate speech movements.', '["Visual speech cues", "Extra time", "Alternative communication", "Practice opportunities", "No pressure"]'::jsonb),
  ('Multiple Disabilities', 'multiple', 2, 'Combination of two or more disabilities requiring extensive support.', '["Highly individualized", "Multi-modal approach", "Extensive modifications", "Team collaboration", "Comprehensive supports"]'::jsonb),
  ('Deaf-Blindness', 'sensory', 2, 'Combined vision and hearing loss requiring specialized communication.', '["Tactile communication", "Close proximity", "Consistent routines", "Tactile exploration", "Alternative formats"]'::jsonb);

-- Insert disabilities 26-40 (Priority Tier 3)
INSERT INTO disability_profiles (disability_name, category, priority_tier, description, common_accommodations)
VALUES 
  ('Williams Syndrome', 'developmental', 3, 'Genetic condition with distinctive cognitive profile and personality traits.', '["Auditory learning emphasis", "Structured environment", "Visual spatial support", "Social skills guidance"]'::jsonb),
  ('Prader-Willi Syndrome', 'developmental', 3, 'Genetic disorder affecting appetite, growth, cognitive function, and behavior.', '["Clear structure", "Food-related modifications", "Behavioral support", "Concrete learning"]'::jsonb),
  ('Angelman Syndrome', 'developmental', 3, 'Genetic disorder causing severe developmental delays and communication challenges.', '["Visual supports", "Communication devices", "Simplified content", "Movement breaks", "Repetition"]'::jsonb),
  ('Rett Syndrome', 'neurological', 3, 'Genetic disorder affecting development, primarily in females, with loss of skills.', '["Assistive technology", "Eye gaze access", "Simplified input", "Support for hand movements"]'::jsonb),
  ('Muscular Dystrophy', 'physical', 3, 'Progressive muscle weakness affecting movement and sometimes cognition.', '["Accessible formats", "Minimal physical demands", "Fatigue management", "Adaptive equipment"]'::jsonb),
  ('Spina Bifida', 'physical', 3, 'Birth defect affecting the spine, potentially impacting mobility and cognition.', '["Accessible materials", "Extra time for tasks", "Memory support", "Physical accommodations"]'::jsonb),
  ('Hydrocephalus', 'neurological', 3, 'Fluid buildup in brain affecting cognitive and physical function.', '["Memory aids", "Processing time", "Visual supports", "Simplified instructions"]'::jsonb),
  ('Spinal Cord Injury', 'physical', 3, 'Damage to spinal cord affecting movement and sensation.', '["Accessible formats", "Alternative input methods", "No physical manipulation required", "Adaptive technology"]'::jsonb),
  ('Limb Differences', 'physical', 3, 'Congenital or acquired limb differences affecting manipulation of materials.', '["Alternative manipulation methods", "Adaptive tools", "Digital access", "Modified materials"]'::jsonb),
  ('Chronic Illness', 'physical', 3, 'Ongoing health conditions (diabetes, cancer, etc.) affecting learning and attendance.', '["Flexible pacing", "Fatigue management", "Medical accommodations", "Makeup work options"]'::jsonb),
  ('Reactive Attachment Disorder', 'behavioral', 3, 'Difficulty forming attachments due to early trauma or neglect.', '["Consistent relationships", "Clear boundaries", "Trauma-informed approach", "Trust-building"]'::jsonb),
  ('PTSD', 'behavioral', 3, 'Post-Traumatic Stress Disorder affecting memory, attention, and emotional regulation.', '["Trauma-sensitive content", "Safety emphasis", "Calming strategies", "Trigger warnings", "Choice"]'::jsonb),
  ('Obsessive-Compulsive Disorder', 'behavioral', 3, 'Intrusive thoughts and repetitive behaviors affecting concentration and time.', '["Extra time", "Flexible expectations", "Exposure support", "Routine flexibility", "Non-judgmental"]'::jsonb),
  ('Eating Disorders', 'behavioral', 3, 'Disordered eating affecting cognition, energy, and concentration.', '["No food-related content triggers", "Health emphasis not appearance", "Flexible scheduling", "Supportive tone"]'::jsonb),
  ('Processing Speed Deficits', 'cognitive', 3, 'Slower processing of information affecting task completion time.', '["Extended time", "Reduced content load", "Clear organization", "Frequent breaks", "No time pressure"]'::jsonb);

-- ============================================
-- PART 3: Create disability_adaptations table
-- ============================================

CREATE TABLE IF NOT EXISTS disability_adaptations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id uuid NOT NULL REFERENCES books(id) ON DELETE CASCADE,
  reading_level text NOT NULL CHECK (reading_level IN ('phd', 'masters', 'bachelors', 'high_school', 'middle_school', 'elementary', 'kindergarten', 'library')),
  disability_id uuid NOT NULL REFERENCES disability_profiles(id) ON DELETE CASCADE,
  adapted_content_url text,
  adaptations_applied jsonb DEFAULT '[]',
  adaptation_notes text,
  validation_count integer DEFAULT 0,
  quality_score numeric(3, 2) DEFAULT 0.0 CHECK (quality_score >= 0 AND quality_score <= 1),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(book_id, reading_level, disability_id)
);

-- ============================================
-- PART 4: Create workflow system tables
-- ============================================

CREATE TABLE IF NOT EXISTS workflow_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workflow_name text NOT NULL UNIQUE,
  workflow_type text NOT NULL CHECK (workflow_type IN ('base', 'accessibility', 'disability_specific', 'translation', 'cultural', 'low_resource')),
  category_id uuid REFERENCES book_categories(id) ON DELETE SET NULL,
  disability_id uuid REFERENCES disability_profiles(id) ON DELETE SET NULL,
  steps jsonb NOT NULL DEFAULT '[]',
  estimated_duration integer DEFAULT 30,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS workflow_executions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id uuid NOT NULL REFERENCES books(id) ON DELETE CASCADE,
  template_id uuid NOT NULL REFERENCES workflow_templates(id) ON DELETE CASCADE,
  current_step integer DEFAULT 0,
  status text NOT NULL DEFAULT 'queued' CHECK (status IN ('queued', 'running', 'paused', 'completed', 'failed', 'cancelled')),
  progress_data jsonb DEFAULT '{}',
  error_log jsonb DEFAULT '[]',
  started_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- ============================================
-- PART 5: Create cultural & low-resource tables
-- ============================================

CREATE TABLE IF NOT EXISTS cultural_adaptations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id uuid NOT NULL REFERENCES books(id) ON DELETE CASCADE,
  reading_level text NOT NULL CHECK (reading_level IN ('phd', 'masters', 'bachelors', 'high_school', 'middle_school', 'elementary', 'kindergarten', 'library')),
  culture_region text NOT NULL,
  adaptations_made jsonb DEFAULT '[]',
  examples_localized jsonb DEFAULT '{}',
  cultural_sensitivity_notes text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(book_id, reading_level, culture_region)
);

CREATE TABLE IF NOT EXISTS low_resource_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id uuid NOT NULL REFERENCES books(id) ON DELETE CASCADE,
  reading_level text NOT NULL CHECK (reading_level IN ('phd', 'masters', 'bachelors', 'high_school', 'middle_school', 'elementary', 'kindergarten', 'library')),
  version_type text NOT NULL CHECK (version_type IN ('black_white', 'minimal_materials', 'offline_complete')),
  file_url text,
  teacher_guide_url text,
  materials_needed jsonb DEFAULT '[]',
  cost_estimate numeric(10, 2) DEFAULT 0,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
  created_at timestamptz DEFAULT now(),
  UNIQUE(book_id, reading_level, version_type)
);

-- ============================================
-- PART 6: Update books table
-- ============================================

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'books' AND column_name = 'category_id'
  ) THEN
    ALTER TABLE books ADD COLUMN category_id uuid REFERENCES book_categories(id) ON DELETE SET NULL;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'books' AND column_name = 'requires_disability_adaptations'
  ) THEN
    ALTER TABLE books ADD COLUMN requires_disability_adaptations boolean DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'books' AND column_name = 'target_disabilities'
  ) THEN
    ALTER TABLE books ADD COLUMN target_disabilities uuid[] DEFAULT '{}';
  END IF;
END $$;

-- ============================================
-- PART 7: Create indexes
-- ============================================

CREATE INDEX IF NOT EXISTS idx_book_categories_active ON book_categories(is_active);
CREATE INDEX IF NOT EXISTS idx_book_categories_order ON book_categories(order_index);

CREATE INDEX IF NOT EXISTS idx_disability_profiles_category ON disability_profiles(category);
CREATE INDEX IF NOT EXISTS idx_disability_profiles_tier ON disability_profiles(priority_tier);
CREATE INDEX IF NOT EXISTS idx_disability_profiles_active ON disability_profiles(is_active);

CREATE INDEX IF NOT EXISTS idx_disability_adaptations_book ON disability_adaptations(book_id);
CREATE INDEX IF NOT EXISTS idx_disability_adaptations_disability ON disability_adaptations(disability_id);
CREATE INDEX IF NOT EXISTS idx_disability_adaptations_status ON disability_adaptations(status);

CREATE INDEX IF NOT EXISTS idx_workflow_templates_type ON workflow_templates(workflow_type);
CREATE INDEX IF NOT EXISTS idx_workflow_templates_category ON workflow_templates(category_id);
CREATE INDEX IF NOT EXISTS idx_workflow_templates_disability ON workflow_templates(disability_id);

CREATE INDEX IF NOT EXISTS idx_workflow_executions_book ON workflow_executions(book_id);
CREATE INDEX IF NOT EXISTS idx_workflow_executions_template ON workflow_executions(template_id);
CREATE INDEX IF NOT EXISTS idx_workflow_executions_status ON workflow_executions(status);

CREATE INDEX IF NOT EXISTS idx_cultural_adaptations_book ON cultural_adaptations(book_id);
CREATE INDEX IF NOT EXISTS idx_cultural_adaptations_region ON cultural_adaptations(culture_region);

CREATE INDEX IF NOT EXISTS idx_low_resource_versions_book ON low_resource_versions(book_id);
CREATE INDEX IF NOT EXISTS idx_low_resource_versions_type ON low_resource_versions(version_type);

CREATE INDEX IF NOT EXISTS idx_books_category ON books(category_id);

-- ============================================
-- PART 8: Enable Row Level Security
-- ============================================

ALTER TABLE book_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE disability_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE disability_adaptations ENABLE ROW LEVEL SECURITY;
ALTER TABLE workflow_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE workflow_executions ENABLE ROW LEVEL SECURITY;
ALTER TABLE cultural_adaptations ENABLE ROW LEVEL SECURITY;
ALTER TABLE low_resource_versions ENABLE ROW LEVEL SECURITY;

-- ============================================
-- PART 9: Create RLS Policies
-- ============================================

-- book_categories policies (public read)
CREATE POLICY "Anyone can view active categories"
  ON book_categories FOR SELECT
  USING (is_active = true);

CREATE POLICY "Authenticated users can manage categories"
  ON book_categories FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- disability_profiles policies (public read)
CREATE POLICY "Anyone can view active disability profiles"
  ON disability_profiles FOR SELECT
  USING (is_active = true);

CREATE POLICY "Authenticated users can manage disability profiles"
  ON disability_profiles FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- disability_adaptations policies
CREATE POLICY "Anyone can view completed disability adaptations"
  ON disability_adaptations FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM books
      WHERE books.id = disability_adaptations.book_id
      AND books.status = 'completed'
    )
  );

CREATE POLICY "Authenticated users can manage disability adaptations"
  ON disability_adaptations FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- workflow_templates policies (admin only)
CREATE POLICY "Authenticated users can view workflow templates"
  ON workflow_templates FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can manage workflow templates"
  ON workflow_templates FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- workflow_executions policies
CREATE POLICY "Anyone can view workflow executions"
  ON workflow_executions FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can manage workflow executions"
  ON workflow_executions FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- cultural_adaptations policies
CREATE POLICY "Anyone can view completed cultural adaptations"
  ON cultural_adaptations FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM books
      WHERE books.id = cultural_adaptations.book_id
      AND books.status = 'completed'
    )
  );

CREATE POLICY "Authenticated users can manage cultural adaptations"
  ON cultural_adaptations FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- low_resource_versions policies
CREATE POLICY "Anyone can view completed low-resource versions"
  ON low_resource_versions FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM books
      WHERE books.id = low_resource_versions.book_id
      AND books.status = 'completed'
    )
  );

CREATE POLICY "Authenticated users can manage low-resource versions"
  ON low_resource_versions FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- ============================================
-- PART 10: Create update triggers
-- ============================================

CREATE TRIGGER update_disability_adaptations_updated_at BEFORE UPDATE ON disability_adaptations
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_workflow_templates_updated_at BEFORE UPDATE ON workflow_templates
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_cultural_adaptations_updated_at BEFORE UPDATE ON cultural_adaptations
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
