/*
  # API Keys Management System

  1. New Tables
    - `api_keys`
      - `id` (uuid, primary key)
      - `service_name` (text) - e.g., 'openai', 'anthropic', 'google'
      - `api_key` (text) - encrypted API key
      - `status` (text) - 'active', 'inactive', 'testing', 'error'
      - `last_tested_at` (timestamptz)
      - `test_result` (jsonb) - stores test results
      - `monthly_cost` (decimal) - estimated monthly cost
      - `usage_stats` (jsonb) - tracks usage per model
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `ai_model_config`
      - `id` (uuid, primary key)
      - `pipeline_name` (text) - which pipeline this is for
      - `model_name` (text) - e.g., 'gpt-5.1', 'claude-3.5-sonnet'
      - `provider` (text) - 'openai', 'anthropic', etc.
      - `enabled` (boolean) - whether to use this model
      - `priority` (integer) - order of preference
      - `use_case` (text) - 'content', 'verification', 'research', etc.
      - `config` (jsonb) - model-specific settings
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `ai_generation_logs`
      - `id` (uuid, primary key)
      - `book_id` (uuid) - references books table
      - `pipeline` (text) - which pipeline
      - `model_name` (text) - which AI model was used
      - `prompt` (text) - the prompt sent
      - `response` (text) - the response received
      - `tokens_used` (integer)
      - `cost` (decimal)
      - `quality_score` (integer) - 0-100
      - `passed_verification` (boolean)
      - `error_message` (text)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Only authenticated admins can access API keys
    - All users can view generation logs for their books
*/

-- API Keys table
CREATE TABLE IF NOT EXISTS api_keys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_name text UNIQUE NOT NULL,
  api_key text NOT NULL,
  status text DEFAULT 'inactive' CHECK (status IN ('active', 'inactive', 'testing', 'error')),
  last_tested_at timestamptz,
  test_result jsonb,
  monthly_cost decimal(10,2) DEFAULT 0,
  usage_stats jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- AI Model Configuration
CREATE TABLE IF NOT EXISTS ai_model_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pipeline_name text NOT NULL,
  model_name text NOT NULL,
  provider text NOT NULL,
  enabled boolean DEFAULT true,
  priority integer DEFAULT 0,
  use_case text NOT NULL,
  config jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(pipeline_name, model_name)
);

-- AI Generation Logs
CREATE TABLE IF NOT EXISTS ai_generation_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id uuid REFERENCES books(id) ON DELETE CASCADE,
  pipeline text NOT NULL,
  model_name text NOT NULL,
  prompt text,
  response text,
  tokens_used integer DEFAULT 0,
  cost decimal(10,4) DEFAULT 0,
  quality_score integer CHECK (quality_score >= 0 AND quality_score <= 100),
  passed_verification boolean DEFAULT false,
  error_message text,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE api_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_model_config ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_generation_logs ENABLE ROW LEVEL SECURITY;

-- RLS Policies for api_keys (admin only)
CREATE POLICY "Only authenticated users can view API keys"
  ON api_keys FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Only authenticated users can manage API keys"
  ON api_keys FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for ai_model_config (admin only)
CREATE POLICY "Anyone can view model config"
  ON ai_model_config FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Only authenticated users can manage model config"
  ON ai_model_config FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for ai_generation_logs
CREATE POLICY "Anyone can view generation logs"
  ON ai_generation_logs FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "System can create generation logs"
  ON ai_generation_logs FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_api_keys_service ON api_keys(service_name);
CREATE INDEX IF NOT EXISTS idx_ai_model_config_pipeline ON ai_model_config(pipeline_name);
CREATE INDEX IF NOT EXISTS idx_ai_generation_logs_book ON ai_generation_logs(book_id);
CREATE INDEX IF NOT EXISTS idx_ai_generation_logs_created ON ai_generation_logs(created_at DESC);

-- Insert initial API keys (will be updated via UI)
INSERT INTO api_keys (service_name, api_key, status) VALUES
  ('openai', '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', 'testing'),
  ('google', 'AIzaSyD3gH3tHYF5zwiSayE4zXS2zCKmn-APvCY', 'testing'),
  ('deepseek', 'sk-990f907b62ca4d34b23174d0d131f49b', 'testing'),
  ('deepl', 'e164773d-c6ed-4666-b4f9-65b088bd0b3d:fx', 'testing'),
  ('anthropic', '', 'inactive'),
  ('perplexity', '', 'inactive')
ON CONFLICT (service_name) DO UPDATE SET
  api_key = EXCLUDED.api_key,
  updated_at = now();

-- Insert recommended AI model configuration
INSERT INTO ai_model_config (pipeline_name, model_name, provider, enabled, priority, use_case, config) VALUES
  -- Content Generation Pipeline
  ('content_generation', 'gpt-5.1', 'openai', true, 1, 'primary_writer', '{"temperature": 0.7, "max_tokens": 4000}'),
  ('content_generation', 'gpt-5-pro', 'openai', true, 2, 'quality_writer', '{"temperature": 0.8, "max_tokens": 4000}'),
  ('content_generation', 'claude-3.5-sonnet', 'anthropic', false, 3, 'structured_writer', '{"temperature": 0.7, "max_tokens": 4000}'),
  ('content_generation', 'gemini-pro-1.5', 'google', true, 4, 'stem_writer', '{"temperature": 0.7, "max_tokens": 4000}'),
  ('content_generation', 'deepseek-v3', 'deepseek', true, 5, 'logic_writer', '{"temperature": 0.7, "max_tokens": 4000}'),
  
  -- Research Pipeline
  ('research', 'o4-mini-deep-research', 'openai', true, 1, 'primary_researcher', '{"temperature": 0.5}'),
  ('research', 'gemini-flash', 'google', true, 2, 'fast_facts', '{"temperature": 0.5}'),
  ('research', 'gpt-5.1', 'openai', true, 3, 'deep_research', '{"temperature": 0.5}'),
  ('research', 'deepseek-v3', 'deepseek', true, 4, 'fact_verification', '{"temperature": 0.3}'),
  
  -- Verification Pipeline
  ('verification', 'gpt-5-mini', 'openai', true, 1, 'quality_check', '{"temperature": 0.3}'),
  ('verification', 'gemini-flash', 'google', true, 2, 'fact_check', '{"temperature": 0.3}'),
  ('verification', 'deepseek-v3', 'deepseek', true, 3, 'logic_check', '{"temperature": 0.3}'),
  
  -- Image Generation
  ('image_generation', 'gpt-image-1', 'openai', true, 1, 'illustrations', '{"size": "1024x1024", "quality": "standard"}'),
  ('image_generation', 'imagen-4', 'google', true, 2, 'diagrams', '{"size": "1024x1024"}'),
  
  -- Audio Generation
  ('audio_generation', 'gpt-4o-mini-tts', 'openai', true, 1, 'narration', '{"voice": "alloy", "speed": 1.0}'),
  ('audio_generation', 'gemini-2.5-flash-tts', 'google', true, 2, 'multilingual', '{"voice": "en-US-Neural2-A"}'),
  
  -- Video Generation
  ('video_generation', 'sora-2', 'openai', true, 1, 'educational_videos', '{"duration": 30}'),
  ('video_generation', 'veo-2', 'google', true, 2, 'demonstrations', '{"duration": 30}'),
  
  -- Translation
  ('translation', 'deepl', 'deepl', true, 1, 'primary_translation', '{"formality": "default"}'),
  ('translation', 'gpt-5-mini', 'openai', true, 2, 'context_translation', '{"temperature": 0.3}')
ON CONFLICT (pipeline_name, model_name) DO UPDATE SET
  enabled = EXCLUDED.enabled,
  priority = EXCLUDED.priority,
  updated_at = now();
