/*
  # Add Admin Roles and System Logging

  1. New Tables
    - `user_roles`
      - Maps users to roles (admin, user, viewer)
    - `system_logs`
      - Comprehensive logging for all system operations
    - `pipeline_logs`
      - Detailed logs for pipeline execution
    - `ai_usage_logs`
      - Track every AI API call with tokens and cost

  2. Security
    - Enable RLS on all new tables
    - Only admins can view/manage roles
    - System logs readable by admins only
    - Pipeline logs readable by pipeline owner or admin

  3. Functions
    - Helper function to check if user is admin
    - Function to log AI usage automatically
*/

-- User Roles Table
CREATE TABLE IF NOT EXISTS user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role text NOT NULL CHECK (role IN ('admin', 'user', 'viewer')),
  granted_by uuid REFERENCES auth.users(id),
  granted_at timestamptz DEFAULT now() NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL,
  UNIQUE(user_id, role)
);

ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view all roles"
  ON user_roles FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      WHERE ur.user_id = auth.uid()
      AND ur.role = 'admin'
    )
  );

CREATE POLICY "Admins can manage roles"
  ON user_roles FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      WHERE ur.user_id = auth.uid()
      AND ur.role = 'admin'
    )
  );

CREATE POLICY "Users can view own roles"
  ON user_roles FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- System Logs Table
CREATE TABLE IF NOT EXISTS system_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  timestamp timestamptz DEFAULT now() NOT NULL,
  level text NOT NULL CHECK (level IN ('debug', 'info', 'warning', 'error', 'critical')),
  category text NOT NULL,
  message text NOT NULL,
  details jsonb DEFAULT '{}'::jsonb,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ip_address inet,
  user_agent text,
  created_at timestamptz DEFAULT now() NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_system_logs_timestamp ON system_logs(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_system_logs_level ON system_logs(level);
CREATE INDEX IF NOT EXISTS idx_system_logs_category ON system_logs(category);
CREATE INDEX IF NOT EXISTS idx_system_logs_user_id ON system_logs(user_id);

ALTER TABLE system_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view all system logs"
  ON system_logs FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      WHERE ur.user_id = auth.uid()
      AND ur.role = 'admin'
    )
  );

CREATE POLICY "System can insert logs"
  ON system_logs FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Pipeline Logs Table
CREATE TABLE IF NOT EXISTS pipeline_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pipeline_id text NOT NULL,
  timestamp timestamptz DEFAULT now() NOT NULL,
  phase text NOT NULL,
  level text NOT NULL CHECK (level IN ('info', 'success', 'warning', 'error')),
  message text NOT NULL,
  details jsonb DEFAULT '{}'::jsonb,
  ai_model text,
  tokens_used integer DEFAULT 0,
  cost_estimate decimal(10, 4) DEFAULT 0,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now() NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_pipeline_logs_pipeline_id ON pipeline_logs(pipeline_id);
CREATE INDEX IF NOT EXISTS idx_pipeline_logs_timestamp ON pipeline_logs(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_pipeline_logs_level ON pipeline_logs(level);
CREATE INDEX IF NOT EXISTS idx_pipeline_logs_phase ON pipeline_logs(phase);

ALTER TABLE pipeline_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own pipeline logs"
  ON pipeline_logs FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all pipeline logs"
  ON pipeline_logs FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      WHERE ur.user_id = auth.uid()
      AND ur.role = 'admin'
    )
  );

CREATE POLICY "System can insert pipeline logs"
  ON pipeline_logs FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id OR user_id IS NULL);

-- AI Usage Logs Table
CREATE TABLE IF NOT EXISTS ai_usage_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  timestamp timestamptz DEFAULT now() NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  pipeline_id text,
  ai_model text NOT NULL,
  provider text NOT NULL,
  phase text NOT NULL,
  operation text NOT NULL,
  tokens_input integer DEFAULT 0,
  tokens_output integer DEFAULT 0,
  tokens_total integer DEFAULT 0,
  cost_input decimal(10, 6) DEFAULT 0,
  cost_output decimal(10, 6) DEFAULT 0,
  cost_total decimal(10, 6) DEFAULT 0,
  latency_ms integer,
  success boolean DEFAULT true,
  error_message text,
  cloud_location text,
  created_at timestamptz DEFAULT now() NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_ai_usage_timestamp ON ai_usage_logs(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_ai_usage_user_id ON ai_usage_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_ai_usage_pipeline_id ON ai_usage_logs(pipeline_id);
CREATE INDEX IF NOT EXISTS idx_ai_usage_ai_model ON ai_usage_logs(ai_model);
CREATE INDEX IF NOT EXISTS idx_ai_usage_provider ON ai_usage_logs(provider);

ALTER TABLE ai_usage_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own AI usage logs"
  ON ai_usage_logs FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all AI usage logs"
  ON ai_usage_logs FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      WHERE ur.user_id = auth.uid()
      AND ur.role = 'admin'
    )
  );

CREATE POLICY "System can insert AI usage logs"
  ON ai_usage_logs FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Helper function to check if user is admin
CREATE OR REPLACE FUNCTION is_admin(check_user_id uuid DEFAULT auth.uid())
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_id = check_user_id
    AND role = 'admin'
  );
END;
$$;

-- Function to log AI usage
CREATE OR REPLACE FUNCTION log_ai_usage(
  p_pipeline_id text,
  p_ai_model text,
  p_provider text,
  p_phase text,
  p_operation text,
  p_tokens_input integer,
  p_tokens_output integer,
  p_cost_input decimal,
  p_cost_output decimal,
  p_latency_ms integer DEFAULT NULL,
  p_success boolean DEFAULT true,
  p_error_message text DEFAULT NULL,
  p_cloud_location text DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_log_id uuid;
BEGIN
  INSERT INTO ai_usage_logs (
    user_id,
    pipeline_id,
    ai_model,
    provider,
    phase,
    operation,
    tokens_input,
    tokens_output,
    tokens_total,
    cost_input,
    cost_output,
    cost_total,
    latency_ms,
    success,
    error_message,
    cloud_location
  ) VALUES (
    auth.uid(),
    p_pipeline_id,
    p_ai_model,
    p_provider,
    p_phase,
    p_operation,
    p_tokens_input,
    p_tokens_output,
    p_tokens_input + p_tokens_output,
    p_cost_input,
    p_cost_output,
    p_cost_input + p_cost_output,
    p_latency_ms,
    p_success,
    p_error_message,
    p_cloud_location
  ) RETURNING id INTO v_log_id;

  RETURN v_log_id;
END;
$$;