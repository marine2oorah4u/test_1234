/*
  # Enhanced Visual & Data Verification System

  1. New Tables
    - `visual_element_verification` - Track verification of all images, graphs, charts
    - `data_accuracy_checks` - Specific tracking for data accuracy in visualizations
  
  2. Security
    - Enable RLS on all tables
    - Policies for authenticated users
*/

-- Visual Element Verification Table
CREATE TABLE IF NOT EXISTS visual_element_verification (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id UUID REFERENCES books(id) ON DELETE CASCADE,
  pipeline_id TEXT NOT NULL,
  step_number INTEGER NOT NULL,
  visual_type TEXT NOT NULL CHECK (visual_type IN ('image', 'graph', 'chart', 'infographic', 'diagram', 'photo', 'illustration')),
  visual_identifier TEXT NOT NULL,
  visual_description TEXT,
  
  -- Creation info
  created_by_ai_model TEXT NOT NULL,
  creation_timestamp TIMESTAMPTZ DEFAULT now(),
  source_type TEXT CHECK (source_type IN ('ai_generated', 'stock_photo', 'diagram', 'chart', 'infographic')),
  source_url TEXT,
  stock_photo_service TEXT,
  
  -- Fact-checking results (Team A)
  fact_check_team JSONB NOT NULL DEFAULT '{"perplexity": {}, "claude_opus": {}, "gpt4": {}}',
  fact_check_perplexity_score INTEGER CHECK (fact_check_perplexity_score >= 0 AND fact_check_perplexity_score <= 100),
  fact_check_claude_opus_score INTEGER CHECK (fact_check_claude_opus_score >= 0 AND fact_check_claude_opus_score <= 100),
  fact_check_gpt4_score INTEGER CHECK (fact_check_gpt4_score >= 0 AND fact_check_gpt4_score <= 100),
  all_facts_verified BOOLEAN NOT NULL DEFAULT false,
  factual_issues_found JSONB DEFAULT '[]',
  factual_corrections_applied JSONB DEFAULT '[]',
  fact_check_consensus TEXT CHECK (fact_check_consensus IN ('all_pass', 'majority_pass', 'failed')),
  
  -- Visual quality results (Team B)
  visual_quality_team JSONB NOT NULL DEFAULT '{"gpt4o": {}, "gemini_pro": {}, "claude_3_5": {}}',
  quality_gpt4o_score INTEGER CHECK (quality_gpt4o_score >= 0 AND quality_gpt4o_score <= 100),
  quality_gemini_pro_score INTEGER CHECK (quality_gemini_pro_score >= 0 AND quality_gemini_pro_score <= 100),
  quality_claude_35_score INTEGER CHECK (quality_claude_35_score >= 0 AND quality_claude_35_score <= 100),
  visual_quality_score INTEGER CHECK (visual_quality_score >= 0 AND visual_quality_score <= 100),
  quality_issues_found JSONB DEFAULT '[]',
  quality_improvements_applied JSONB DEFAULT '[]',
  quality_consensus TEXT CHECK (quality_consensus IN ('all_pass', 'majority_pass', 'failed')),
  
  -- Mathematical/Statistical verification (Team C - for data visuals only)
  mathematical_verification_required BOOLEAN DEFAULT false,
  mathematical_team JSONB DEFAULT '{"wolfram": {}, "gpt4": {}, "claude_opus": {}}',
  math_wolfram_score INTEGER CHECK (math_wolfram_score >= 0 AND math_wolfram_score <= 100),
  math_gpt4_score INTEGER CHECK (math_gpt4_score >= 0 AND math_gpt4_score <= 100),
  math_claude_opus_score INTEGER CHECK (math_claude_opus_score >= 0 AND math_claude_opus_score <= 100),
  all_calculations_verified BOOLEAN DEFAULT false,
  mathematical_issues_found JSONB DEFAULT '[]',
  mathematical_corrections_applied JSONB DEFAULT '[]',
  math_consensus TEXT CHECK (math_consensus IN ('all_pass', 'majority_pass', 'failed', 'not_required')),
  
  -- Cross-reference verification
  cross_reference_checks JSONB DEFAULT '{}',
  source_material_match BOOLEAN DEFAULT false,
  external_sources_verified BOOLEAN DEFAULT false,
  consistency_with_other_visuals BOOLEAN DEFAULT false,
  academic_standards_met BOOLEAN DEFAULT false,
  grade_level_appropriate BOOLEAN DEFAULT false,
  
  -- Educational effectiveness
  educational_value_score INTEGER CHECK (educational_value_score >= 0 AND educational_value_score <= 100),
  clarifies_concept BOOLEAN,
  adds_new_information BOOLEAN,
  student_learning_value BOOLEAN,
  complements_text BOOLEAN,
  cognitive_level_appropriate BOOLEAN,
  teacher_usefulness_score INTEGER CHECK (teacher_usefulness_score >= 0 AND teacher_usefulness_score <= 100),
  
  -- Accessibility
  alt_text TEXT,
  alt_text_verified BOOLEAN DEFAULT false,
  colorblind_friendly BOOLEAN DEFAULT false,
  sufficient_contrast BOOLEAN DEFAULT false,
  text_readable BOOLEAN DEFAULT false,
  
  -- Final approval
  final_approval_status TEXT NOT NULL DEFAULT 'pending' CHECK (final_approval_status IN ('pending', 'approved', 'rejected', 'needs_revision')),
  approved_by_models TEXT[] DEFAULT '{}',
  approval_scores JSONB DEFAULT '{}',
  rejection_reasons JSONB DEFAULT '[]',
  revision_count INTEGER DEFAULT 0,
  approval_timestamp TIMESTAMPTZ,
  
  -- Metadata
  verification_duration INTERVAL,
  total_cost DECIMAL(10,2),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_visual_elem_book ON visual_element_verification(book_id);
CREATE INDEX idx_visual_elem_type ON visual_element_verification(visual_type);
CREATE INDEX idx_visual_elem_status ON visual_element_verification(final_approval_status);
CREATE INDEX idx_visual_elem_step ON visual_element_verification(book_id, step_number);

-- Data Accuracy Checks Table (for detailed tracking of data in graphs/charts)
CREATE TABLE IF NOT EXISTS data_accuracy_checks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  visual_element_id UUID REFERENCES visual_element_verification(id) ON DELETE CASCADE,
  book_id UUID REFERENCES books(id) ON DELETE CASCADE,
  
  -- Data point info
  data_point_identifier TEXT NOT NULL,
  data_value NUMERIC,
  data_unit TEXT,
  data_label TEXT,
  
  -- Verification
  source_value NUMERIC,
  source_reference TEXT,
  values_match BOOLEAN NOT NULL,
  verified_by_ai_model TEXT NOT NULL,
  verification_method TEXT,
  
  -- If mismatch
  discrepancy_details TEXT,
  correction_applied BOOLEAN DEFAULT false,
  corrected_value NUMERIC,
  
  -- Metadata
  verified_at TIMESTAMPTZ DEFAULT now(),
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_data_accuracy_visual ON data_accuracy_checks(visual_element_id);
CREATE INDEX idx_data_accuracy_book ON data_accuracy_checks(book_id);
CREATE INDEX idx_data_accuracy_match ON data_accuracy_checks(values_match);

-- Visual Quality Statistics View
CREATE OR REPLACE VIEW visual_quality_statistics AS
SELECT 
  book_id,
  pipeline_id,
  visual_type,
  COUNT(*) as total_visuals,
  COUNT(*) FILTER (WHERE all_facts_verified = true) as fact_verified_count,
  COUNT(*) FILTER (WHERE final_approval_status = 'approved') as approved_count,
  COUNT(*) FILTER (WHERE final_approval_status = 'rejected') as rejected_count,
  COUNT(*) FILTER (WHERE final_approval_status = 'needs_revision') as needs_revision_count,
  ROUND(AVG(visual_quality_score), 2) as avg_quality_score,
  ROUND(AVG(fact_check_perplexity_score), 2) as avg_fact_check_score,
  ROUND(AVG(educational_value_score), 2) as avg_educational_value,
  COUNT(*) FILTER (WHERE mathematical_verification_required = true) as data_visuals_count,
  COUNT(*) FILTER (WHERE all_calculations_verified = true) as calculations_verified_count,
  ROUND(AVG(revision_count), 2) as avg_revisions_needed,
  COUNT(*) FILTER (WHERE colorblind_friendly = true) as colorblind_friendly_count,
  COUNT(*) FILTER (WHERE sufficient_contrast = true) as accessible_count
FROM visual_element_verification
GROUP BY book_id, pipeline_id, visual_type;

-- Data Accuracy Statistics View
CREATE OR REPLACE VIEW data_accuracy_statistics AS
SELECT 
  book_id,
  COUNT(*) as total_data_points_checked,
  COUNT(*) FILTER (WHERE values_match = true) as accurate_data_points,
  COUNT(*) FILTER (WHERE values_match = false) as inaccurate_data_points,
  COUNT(*) FILTER (WHERE correction_applied = true) as corrections_applied,
  ROUND(100.0 * COUNT(*) FILTER (WHERE values_match = true) / COUNT(*), 2) as accuracy_percentage
FROM data_accuracy_checks
GROUP BY book_id;

-- Enable Row Level Security
ALTER TABLE visual_element_verification ENABLE ROW LEVEL SECURITY;
ALTER TABLE data_accuracy_checks ENABLE ROW LEVEL SECURITY;

-- Policies for visual_element_verification
CREATE POLICY "Users can view visual verification for their books"
  ON visual_element_verification FOR SELECT
  TO authenticated
  USING (
    book_id IN (
      SELECT id FROM books WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "System can insert visual verification"
  ON visual_element_verification FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "System can update visual verification"
  ON visual_element_verification FOR UPDATE
  TO authenticated
  USING (true);

-- Policies for data_accuracy_checks
CREATE POLICY "Users can view data accuracy checks for their books"
  ON data_accuracy_checks FOR SELECT
  TO authenticated
  USING (
    book_id IN (
      SELECT id FROM books WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "System can insert data accuracy checks"
  ON data_accuracy_checks FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "System can update data accuracy checks"
  ON data_accuracy_checks FOR UPDATE
  TO authenticated
  USING (true);
