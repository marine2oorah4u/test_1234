/*
  # Disability Impact Grading System for Educational Materials

  1. New Tables
    - `disability_categories`
      - Category groupings (Learning, Sensory, Physical, etc.)
    - `disabilities`
      - All disabilities with impact grading and educational relevance
      - Prevalence data and statistics
      - Real-world learning impact scores
    - `disability_accommodations`
      - Specific accommodations needed for each disability
    - `disability_pipeline_status`
      - Track which ones we have, need to add, or should remove

  2. Security
    - Enable RLS on all tables
    - Public read access for reference data
    - Admin-only write access
*/

-- Create disability categories table
CREATE TABLE IF NOT EXISTS disability_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create main disabilities table
CREATE TABLE IF NOT EXISTS disabilities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid REFERENCES disability_categories(id),
  name text NOT NULL,
  alternate_names text[], -- Other names for the condition
  description text NOT NULL,
  
  -- Prevalence data
  prevalence_count bigint, -- Estimated number of people affected
  prevalence_percentage numeric(5,2), -- Percentage of population
  prevalence_source text, -- Citation/source
  
  -- Educational impact grading
  impact_grade text NOT NULL CHECK (impact_grade IN ('A', 'B', 'C', 'D', 'F')),
  impact_explanation text NOT NULL,
  
  -- Learning impact scores (0-10)
  reading_impact_score int CHECK (reading_impact_score >= 0 AND reading_impact_score <= 10),
  comprehension_impact_score int CHECK (comprehension_impact_score >= 0 AND comprehension_impact_score <= 10),
  writing_impact_score int CHECK (writing_impact_score >= 0 AND writing_impact_score <= 10),
  focus_attention_score int CHECK (focus_attention_score >= 0 AND focus_attention_score <= 10),
  memory_impact_score int CHECK (memory_impact_score >= 0 AND memory_impact_score <= 10),
  processing_speed_score int CHECK (processing_speed_score >= 0 AND processing_speed_score <= 10),
  
  -- Status and decisions
  pipeline_status text NOT NULL CHECK (pipeline_status IN ('keep_essential', 'keep_important', 'keep_optional', 'remove', 'add_new', 'consider')),
  pipeline_number text, -- e.g., "3.24" for existing pipelines
  pipeline_priority int, -- 1-10, higher = more important
  
  -- Decision rationale
  keep_remove_rationale text NOT NULL,
  real_world_impact text,
  accommodation_summary text,
  
  -- Metadata
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create accommodations table
CREATE TABLE IF NOT EXISTS disability_accommodations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  disability_id uuid REFERENCES disabilities(id) ON DELETE CASCADE,
  accommodation_type text NOT NULL, -- 'visual', 'auditory', 'cognitive', 'motor', 'format'
  accommodation_name text NOT NULL,
  description text NOT NULL,
  difficulty_to_implement text CHECK (difficulty_to_implement IN ('easy', 'moderate', 'difficult', 'very_difficult')),
  impact_level text CHECK (impact_level IN ('critical', 'high', 'medium', 'low')),
  examples text[],
  created_at timestamptz DEFAULT now()
);

-- Create pipeline status tracking
CREATE TABLE IF NOT EXISTS disability_pipeline_status (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  disability_id uuid REFERENCES disabilities(id) ON DELETE CASCADE,
  has_blueprints boolean DEFAULT false,
  blueprints_count int DEFAULT 0,
  blueprints_complete boolean DEFAULT false,
  implementation_status text CHECK (implementation_status IN ('not_started', 'in_progress', 'complete', 'deprecated')),
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE disability_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE disabilities ENABLE ROW LEVEL SECURITY;
ALTER TABLE disability_accommodations ENABLE ROW LEVEL SECURITY;
ALTER TABLE disability_pipeline_status ENABLE ROW LEVEL SECURITY;

-- Public read access (reference data)
CREATE POLICY "Anyone can read disability categories"
  ON disability_categories FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can read disabilities"
  ON disabilities FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can read accommodations"
  ON disability_accommodations FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can read pipeline status"
  ON disability_pipeline_status FOR SELECT
  TO public
  USING (true);

-- Admin-only write access
CREATE POLICY "Authenticated users can insert categories"
  ON disability_categories FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update categories"
  ON disability_categories FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can insert disabilities"
  ON disabilities FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update disabilities"
  ON disabilities FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can insert accommodations"
  ON disability_accommodations FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update accommodations"
  ON disability_accommodations FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can insert pipeline status"
  ON disability_pipeline_status FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update pipeline status"
  ON disability_pipeline_status FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_disabilities_category ON disabilities(category_id);
CREATE INDEX IF NOT EXISTS idx_disabilities_impact_grade ON disabilities(impact_grade);
CREATE INDEX IF NOT EXISTS idx_disabilities_pipeline_status ON disabilities(pipeline_status);
CREATE INDEX IF NOT EXISTS idx_accommodations_disability ON disability_accommodations(disability_id);
CREATE INDEX IF NOT EXISTS idx_pipeline_status_disability ON disability_pipeline_status(disability_id);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply triggers
CREATE TRIGGER update_disability_categories_updated_at
  BEFORE UPDATE ON disability_categories
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_disabilities_updated_at
  BEFORE UPDATE ON disabilities
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_pipeline_status_updated_at
  BEFORE UPDATE ON disability_pipeline_status
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
