/*
  # Verification & Error Detection System

  1. New Tables
    - `verification_checks` - Track all verification checks (during, end-of-step, quality gates, triple)
    - `error_corrections` - Track all errors detected and correction attempts
    - `quality_gates` - Track quality gate results between steps
    - `backward_propagations` - Track when pipeline goes backward to fix issues
    - `step_execution_log` - Detailed log of each step execution with verification status
  
  2. Security
    - Enable RLS on all tables
    - Policies for authenticated users to read their own data
    - Admin-only write access for system operations
*/

-- Verification Checks Table
CREATE TABLE IF NOT EXISTS verification_checks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id UUID REFERENCES books(id) ON DELETE CASCADE,
  pipeline_id TEXT NOT NULL,
  step_number INTEGER NOT NULL,
  verification_type TEXT NOT NULL CHECK (verification_type IN ('during_step', 'end_of_step', 'quality_gate', 'triple_verification')),
  verification_round INTEGER DEFAULT 1,
  verifier_ai_model TEXT NOT NULL,
  started_at TIMESTAMPTZ DEFAULT now(),
  completed_at TIMESTAMPTZ,
  passed BOOLEAN,
  issues_found JSONB DEFAULT '[]',
  fixes_applied JSONB DEFAULT '[]',
  verification_score INTEGER CHECK (verification_score >= 0 AND verification_score <= 100),
  confidence_level TEXT CHECK (confidence_level IN ('high', 'medium', 'low')),
  notes TEXT,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_verification_book ON verification_checks(book_id);
CREATE INDEX idx_verification_step ON verification_checks(book_id, step_number);
CREATE INDEX idx_verification_type ON verification_checks(verification_type);
CREATE INDEX idx_verification_passed ON verification_checks(passed);

-- Error Corrections Table
CREATE TABLE IF NOT EXISTS error_corrections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id UUID REFERENCES books(id) ON DELETE CASCADE,
  pipeline_id TEXT NOT NULL,
  step_number INTEGER NOT NULL,
  error_category TEXT NOT NULL CHECK (error_category IN ('critical', 'major', 'minor')),
  error_type TEXT NOT NULL,
  error_description TEXT NOT NULL,
  detection_timestamp TIMESTAMPTZ DEFAULT now(),
  detected_by_ai_model TEXT,
  correction_attempts INTEGER DEFAULT 0,
  max_correction_attempts INTEGER DEFAULT 3,
  fix_successful BOOLEAN DEFAULT false,
  backward_propagation_needed BOOLEAN DEFAULT false,
  went_back_to_step INTEGER,
  resolution_timestamp TIMESTAMPTZ,
  resolution_method TEXT,
  auto_fixed BOOLEAN DEFAULT false,
  manual_intervention_required BOOLEAN DEFAULT false,
  correction_details JSONB DEFAULT '{}',
  before_state JSONB,
  after_state JSONB,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_errors_book ON error_corrections(book_id);
CREATE INDEX idx_errors_step ON error_corrections(book_id, step_number);
CREATE INDEX idx_errors_category ON error_corrections(error_category);
CREATE INDEX idx_errors_resolved ON error_corrections(fix_successful);
CREATE INDEX idx_errors_backprop ON error_corrections(backward_propagation_needed);

-- Quality Gates Table
CREATE TABLE IF NOT EXISTS quality_gates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id UUID REFERENCES books(id) ON DELETE CASCADE,
  pipeline_id TEXT NOT NULL,
  from_step INTEGER NOT NULL,
  to_step INTEGER NOT NULL,
  gate_name TEXT NOT NULL,
  started_at TIMESTAMPTZ DEFAULT now(),
  completed_at TIMESTAMPTZ,
  gatekeeper_1_model TEXT NOT NULL,
  gatekeeper_1_result JSONB NOT NULL DEFAULT '{}',
  gatekeeper_1_passed BOOLEAN,
  gatekeeper_2_model TEXT NOT NULL,
  gatekeeper_2_result JSONB NOT NULL DEFAULT '{}',
  gatekeeper_2_passed BOOLEAN,
  gatekeeper_3_model TEXT NOT NULL,
  gatekeeper_3_result JSONB NOT NULL DEFAULT '{}',
  gatekeeper_3_passed BOOLEAN,
  gate_passed BOOLEAN NOT NULL DEFAULT false,
  consensus_score INTEGER,
  retry_count INTEGER DEFAULT 0,
  issues_blocking_gate JSONB DEFAULT '[]',
  resolution_actions JSONB DEFAULT '[]',
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_quality_gates_book ON quality_gates(book_id);
CREATE INDEX idx_quality_gates_step ON quality_gates(from_step, to_step);
CREATE INDEX idx_quality_gates_passed ON quality_gates(gate_passed);

-- Backward Propagations Table
CREATE TABLE IF NOT EXISTS backward_propagations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id UUID REFERENCES books(id) ON DELETE CASCADE,
  pipeline_id TEXT NOT NULL,
  triggered_at_step INTEGER NOT NULL,
  went_back_to_step INTEGER NOT NULL,
  steps_affected INTEGER NOT NULL,
  reason TEXT NOT NULL,
  root_cause TEXT,
  triggered_at TIMESTAMPTZ DEFAULT now(),
  completed_at TIMESTAMPTZ,
  re_execution_successful BOOLEAN,
  steps_re_executed JSONB DEFAULT '[]',
  issues_resolved JSONB DEFAULT '[]',
  total_time_spent INTERVAL,
  additional_cost_incurred DECIMAL(10,2),
  lessons_learned TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_backprop_book ON backward_propagations(book_id);
CREATE INDEX idx_backprop_trigger_step ON backward_propagations(triggered_at_step);
CREATE INDEX idx_backprop_success ON backward_propagations(re_execution_successful);

-- Step Execution Log (Enhanced with verification tracking)
CREATE TABLE IF NOT EXISTS step_execution_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id UUID REFERENCES books(id) ON DELETE CASCADE,
  pipeline_id TEXT NOT NULL,
  step_number INTEGER NOT NULL,
  step_name TEXT NOT NULL,
  execution_attempt INTEGER DEFAULT 1,
  status TEXT NOT NULL CHECK (status IN ('pending', 'in_progress', 'verifying', 'correcting', 'completed', 'failed', 'rolled_back')),
  started_at TIMESTAMPTZ DEFAULT now(),
  completed_at TIMESTAMPTZ,
  ai_models_used TEXT[] NOT NULL DEFAULT '{}',
  during_step_checks_count INTEGER DEFAULT 0,
  during_step_errors_found INTEGER DEFAULT 0,
  during_step_errors_fixed INTEGER DEFAULT 0,
  end_of_step_verification_passed BOOLEAN,
  quality_gate_passed BOOLEAN,
  verification_score INTEGER CHECK (verification_score >= 0 AND verification_score <= 100),
  errors_encountered JSONB DEFAULT '[]',
  corrections_applied JSONB DEFAULT '[]',
  outputs_generated JSONB DEFAULT '[]',
  time_spent INTERVAL,
  tokens_used INTEGER DEFAULT 0,
  cost_incurred DECIMAL(10,2),
  notes TEXT,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_step_log_book ON step_execution_log(book_id);
CREATE INDEX idx_step_log_step ON step_execution_log(book_id, step_number);
CREATE INDEX idx_step_log_status ON step_execution_log(status);
CREATE INDEX idx_step_log_attempt ON step_execution_log(execution_attempt);

-- Verification Statistics View
CREATE OR REPLACE VIEW verification_statistics AS
SELECT 
  book_id,
  pipeline_id,
  COUNT(*) as total_verifications,
  COUNT(*) FILTER (WHERE passed = true) as passed_count,
  COUNT(*) FILTER (WHERE passed = false) as failed_count,
  ROUND(AVG(verification_score), 2) as avg_verification_score,
  COUNT(*) FILTER (WHERE verification_type = 'during_step') as during_step_checks,
  COUNT(*) FILTER (WHERE verification_type = 'end_of_step') as end_of_step_checks,
  COUNT(*) FILTER (WHERE verification_type = 'quality_gate') as quality_gate_checks,
  COUNT(*) FILTER (WHERE verification_type = 'triple_verification') as triple_verifications
FROM verification_checks
GROUP BY book_id, pipeline_id;

-- Error Statistics View
CREATE OR REPLACE VIEW error_statistics AS
SELECT 
  book_id,
  pipeline_id,
  COUNT(*) as total_errors,
  COUNT(*) FILTER (WHERE error_category = 'critical') as critical_errors,
  COUNT(*) FILTER (WHERE error_category = 'major') as major_errors,
  COUNT(*) FILTER (WHERE error_category = 'minor') as minor_errors,
  COUNT(*) FILTER (WHERE fix_successful = true) as resolved_errors,
  COUNT(*) FILTER (WHERE auto_fixed = true) as auto_fixed_errors,
  COUNT(*) FILTER (WHERE manual_intervention_required = true) as manual_intervention_needed,
  COUNT(*) FILTER (WHERE backward_propagation_needed = true) as backward_propagations_needed,
  ROUND(AVG(correction_attempts), 2) as avg_correction_attempts
FROM error_corrections
GROUP BY book_id, pipeline_id;

-- Quality Gate Statistics View  
CREATE OR REPLACE VIEW quality_gate_statistics AS
SELECT 
  book_id,
  pipeline_id,
  COUNT(*) as total_gates,
  COUNT(*) FILTER (WHERE gate_passed = true) as gates_passed,
  COUNT(*) FILTER (WHERE gate_passed = false) as gates_failed,
  ROUND(AVG(consensus_score), 2) as avg_consensus_score,
  ROUND(AVG(retry_count), 2) as avg_retry_count
FROM quality_gates
GROUP BY book_id, pipeline_id;

-- Enable Row Level Security
ALTER TABLE verification_checks ENABLE ROW LEVEL SECURITY;
ALTER TABLE error_corrections ENABLE ROW LEVEL SECURITY;
ALTER TABLE quality_gates ENABLE ROW LEVEL SECURITY;
ALTER TABLE backward_propagations ENABLE ROW LEVEL SECURITY;
ALTER TABLE step_execution_log ENABLE ROW LEVEL SECURITY;

-- Policies for verification_checks
CREATE POLICY "Users can view verification checks for their books"
  ON verification_checks FOR SELECT
  TO authenticated
  USING (
    book_id IN (
      SELECT id FROM books WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "System can insert verification checks"
  ON verification_checks FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Policies for error_corrections
CREATE POLICY "Users can view error corrections for their books"
  ON error_corrections FOR SELECT
  TO authenticated
  USING (
    book_id IN (
      SELECT id FROM books WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "System can insert error corrections"
  ON error_corrections FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "System can update error corrections"
  ON error_corrections FOR UPDATE
  TO authenticated
  USING (true);

-- Policies for quality_gates
CREATE POLICY "Users can view quality gates for their books"
  ON quality_gates FOR SELECT
  TO authenticated
  USING (
    book_id IN (
      SELECT id FROM books WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "System can insert quality gates"
  ON quality_gates FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Policies for backward_propagations
CREATE POLICY "Users can view backward propagations for their books"
  ON backward_propagations FOR SELECT
  TO authenticated
  USING (
    book_id IN (
      SELECT id FROM books WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "System can insert backward propagations"
  ON backward_propagations FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "System can update backward propagations"
  ON backward_propagations FOR UPDATE
  TO authenticated
  USING (true);

-- Policies for step_execution_log
CREATE POLICY "Users can view step execution log for their books"
  ON step_execution_log FOR SELECT
  TO authenticated
  USING (
    book_id IN (
      SELECT id FROM books WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "System can insert step execution log"
  ON step_execution_log FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "System can update step execution log"
  ON step_execution_log FOR UPDATE
  TO authenticated
  USING (true);
