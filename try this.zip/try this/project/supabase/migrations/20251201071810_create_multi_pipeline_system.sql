/*
  # Multi-Pipeline System Architecture

  ## Overview
  Creates comprehensive system for 6 main pipelines with advanced AI features

  ## Main Pipelines
  1. Educational Books (current) - Global library packages
  2. Scouts System (admin only) - Merit badges, handbooks, training
  3. Educational/School Content - Institution-specific materials
  4. Corporate Training - Company training and documentation
  5. Language Preservation - Endangered language documentation
  6. Web Development/Vibe Coding - GitHub repo analysis & code generation

  ## New Tables
  
  ### Core Pipeline Tables
  - `main_pipelines` - Configuration for each main pipeline
  - `pipeline_access` - User access control per pipeline
  - `country_adaptations` - Country-specific automatic variations
  - `country_adaptation_configs` - Settings per country
  
  ### AI Feature Tables
  - `ai_process_stats` - Real-time AI process statistics
  - `ai_memory_storage` - Persistent AI context and memory
  - `attachment_reviews` - AI attachment analysis and reviews
  - `output_estimations` - Output estimation configs and history
  
  ### System Health Tables
  - `stress_test_results` - System load and capability testing
  - `self_healing_logs` - Auto-detected and repaired issues
  - `bug_detection_rules` - Rules for auto-detecting problems
  
  ### Integration Tables
  - `github_repositories` - Connected GitHub repos
  - `github_repo_analysis` - Full repo comprehension data
  
  ## Security
  - RLS enabled on all tables
  - Admin-only access for sensitive pipelines
  - User-level access control

  ## Notes
  - All pipelines share AI infrastructure
  - Country adaptations auto-generate for major countries
  - Self-healing runs automatically
*/

-- =============================================
-- MAIN PIPELINES SYSTEM
-- =============================================

CREATE TABLE IF NOT EXISTS main_pipelines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  description text,
  category text NOT NULL, -- 'education', 'scouts', 'corporate', 'preservation', 'web-dev'
  is_admin_only boolean DEFAULT false,
  is_active boolean DEFAULT true,
  priority_order integer DEFAULT 0,
  settings jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE main_pipelines ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active pipelines"
  ON main_pipelines FOR SELECT
  TO authenticated
  USING (is_active = true);

CREATE POLICY "Admins can manage all pipelines"
  ON main_pipelines FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

-- =============================================
-- PIPELINE ACCESS CONTROL
-- =============================================

CREATE TABLE IF NOT EXISTS pipeline_access (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pipeline_id uuid REFERENCES main_pipelines(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  access_level text DEFAULT 'read', -- 'read', 'write', 'admin'
  granted_by uuid REFERENCES auth.users(id),
  granted_at timestamptz DEFAULT now(),
  expires_at timestamptz,
  UNIQUE(pipeline_id, user_id)
);

ALTER TABLE pipeline_access ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own pipeline access"
  ON pipeline_access FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Admins can manage pipeline access"
  ON pipeline_access FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

-- =============================================
-- COUNTRY ADAPTATIONS (Automatic Variations)
-- =============================================

CREATE TABLE IF NOT EXISTS country_adaptation_configs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  country_code text UNIQUE NOT NULL, -- ISO 3166-1 alpha-2
  country_name text NOT NULL,
  is_auto_generate boolean DEFAULT true,
  priority_tier integer DEFAULT 2, -- 1=highest priority, 3=lowest
  locale text NOT NULL, -- en-US, en-GB, fr-FR, etc.
  currency_code text, -- USD, GBP, EUR, etc.
  measurement_system text DEFAULT 'metric', -- 'metric', 'imperial'
  date_format text DEFAULT 'YYYY-MM-DD',
  education_system jsonb DEFAULT '{}'::jsonb,
  cultural_notes text,
  adaptation_rules jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE country_adaptation_configs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view country configs"
  ON country_adaptation_configs FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage country configs"
  ON country_adaptation_configs FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE TABLE IF NOT EXISTS country_adaptations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id uuid REFERENCES books(id) ON DELETE CASCADE,
  country_code text REFERENCES country_adaptation_configs(country_code),
  pipeline_id uuid REFERENCES main_pipelines(id),
  adapted_content jsonb DEFAULT '{}'::jsonb,
  adaptation_status text DEFAULT 'pending', -- 'pending', 'processing', 'completed', 'failed'
  auto_generated boolean DEFAULT true,
  quality_score decimal(3,2),
  review_status text DEFAULT 'pending', -- 'pending', 'approved', 'needs_revision'
  reviewed_by uuid REFERENCES auth.users(id),
  reviewed_at timestamptz,
  storage_path text,
  file_size bigint,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(book_id, country_code)
);

ALTER TABLE country_adaptations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view country adaptations"
  ON country_adaptations FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage country adaptations"
  ON country_adaptations FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

-- =============================================
-- AI PROCESS STATISTICS (Real-time Tracking)
-- =============================================

CREATE TABLE IF NOT EXISTS ai_process_stats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  process_type text NOT NULL, -- 'generation', 'review', 'adaptation', 'analysis'
  ai_model text NOT NULL,
  pipeline_id uuid REFERENCES main_pipelines(id),
  book_id uuid REFERENCES books(id),
  started_at timestamptz DEFAULT now(),
  completed_at timestamptz,
  status text DEFAULT 'running', -- 'running', 'completed', 'failed', 'cancelled'
  input_tokens integer DEFAULT 0,
  output_tokens integer DEFAULT 0,
  total_cost decimal(10,4) DEFAULT 0,
  processing_time_ms integer,
  quality_score decimal(3,2),
  error_message text,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE ai_process_stats ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view all AI process stats"
  ON ai_process_stats FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role IN ('admin', 'operator')
    )
  );

CREATE POLICY "Admins can insert AI process stats"
  ON ai_process_stats FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role IN ('admin', 'operator')
    )
  );

-- =============================================
-- AI MEMORY STORAGE (Persistent Context)
-- =============================================

CREATE TABLE IF NOT EXISTS ai_memory_storage (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  memory_key text UNIQUE NOT NULL,
  memory_type text NOT NULL, -- 'context', 'preference', 'pattern', 'learned'
  pipeline_id uuid REFERENCES main_pipelines(id),
  user_id uuid REFERENCES auth.users(id),
  content jsonb NOT NULL,
  importance_score integer DEFAULT 5, -- 1-10
  access_count integer DEFAULT 0,
  last_accessed_at timestamptz DEFAULT now(),
  expires_at timestamptz,
  tags text[] DEFAULT ARRAY[]::text[],
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE ai_memory_storage ENABLE ROW LEVEL SECURITY;

CREATE POLICY "System can access all memories"
  ON ai_memory_storage FOR ALL
  TO authenticated
  USING (true);

CREATE INDEX IF NOT EXISTS idx_ai_memory_key ON ai_memory_storage(memory_key);
CREATE INDEX IF NOT EXISTS idx_ai_memory_pipeline ON ai_memory_storage(pipeline_id);
CREATE INDEX IF NOT EXISTS idx_ai_memory_user ON ai_memory_storage(user_id);

-- =============================================
-- ATTACHMENT REVIEW SYSTEM
-- =============================================

CREATE TABLE IF NOT EXISTS attachment_reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  attachment_url text NOT NULL,
  attachment_type text NOT NULL, -- 'image', 'pdf', 'document', 'code'
  file_name text NOT NULL,
  file_size bigint,
  uploaded_by uuid REFERENCES auth.users(id),
  pipeline_id uuid REFERENCES main_pipelines(id),
  book_id uuid REFERENCES books(id),
  ai_analysis jsonb DEFAULT '{}'::jsonb,
  extracted_text text,
  detected_content text[],
  quality_score decimal(3,2),
  usability_score decimal(3,2),
  recommendations text[],
  review_status text DEFAULT 'pending', -- 'pending', 'approved', 'rejected', 'needs_revision'
  reviewed_by uuid REFERENCES auth.users(id),
  reviewed_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE attachment_reviews ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their attachment reviews"
  ON attachment_reviews FOR SELECT
  TO authenticated
  USING (uploaded_by = auth.uid() OR EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_roles.user_id = auth.uid()
    AND user_roles.role IN ('admin', 'operator')
  ));

CREATE POLICY "Users can create attachment reviews"
  ON attachment_reviews FOR INSERT
  TO authenticated
  WITH CHECK (uploaded_by = auth.uid());

CREATE POLICY "Admins can update attachment reviews"
  ON attachment_reviews FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role IN ('admin', 'operator')
    )
  );

-- =============================================
-- OUTPUT ESTIMATION & SLIDER CONTROL
-- =============================================

CREATE TABLE IF NOT EXISTS output_estimations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pipeline_id uuid REFERENCES main_pipelines(id),
  process_type text NOT NULL,
  input_parameters jsonb NOT NULL,
  estimated_tokens integer,
  estimated_cost decimal(10,4),
  estimated_time_seconds integer,
  estimated_quality decimal(3,2),
  actual_tokens integer,
  actual_cost decimal(10,4),
  actual_time_seconds integer,
  actual_quality decimal(3,2),
  accuracy_score decimal(3,2), -- How close was the estimate?
  user_id uuid REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now(),
  completed_at timestamptz
);

ALTER TABLE output_estimations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their estimations"
  ON output_estimations FOR SELECT
  TO authenticated
  USING (user_id = auth.uid() OR EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_roles.user_id = auth.uid()
    AND user_roles.role IN ('admin', 'operator')
  ));

CREATE POLICY "System can create estimations"
  ON output_estimations FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- =============================================
-- STRESS TESTING FRAMEWORK
-- =============================================

CREATE TABLE IF NOT EXISTS stress_test_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  test_name text NOT NULL,
  pipeline_id uuid REFERENCES main_pipelines(id),
  test_type text NOT NULL, -- 'load', 'concurrent', 'endurance', 'spike'
  test_parameters jsonb DEFAULT '{}'::jsonb,
  started_at timestamptz DEFAULT now(),
  completed_at timestamptz,
  duration_seconds integer,
  total_requests integer DEFAULT 0,
  successful_requests integer DEFAULT 0,
  failed_requests integer DEFAULT 0,
  avg_response_time_ms integer,
  max_response_time_ms integer,
  min_response_time_ms integer,
  requests_per_second decimal(10,2),
  total_tokens_used bigint DEFAULT 0,
  total_cost decimal(10,4) DEFAULT 0,
  cpu_usage_avg decimal(5,2),
  memory_usage_avg_mb integer,
  errors jsonb DEFAULT '[]'::jsonb,
  bottlenecks text[],
  recommendations text[],
  pass_fail text DEFAULT 'pending', -- 'pending', 'pass', 'fail'
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE stress_test_results ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view stress test results"
  ON stress_test_results FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role IN ('admin', 'operator')
    )
  );

CREATE POLICY "Admins can create stress tests"
  ON stress_test_results FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role IN ('admin', 'operator')
    )
  );

-- =============================================
-- SELF-HEALING SYSTEM
-- =============================================

CREATE TABLE IF NOT EXISTS bug_detection_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rule_name text UNIQUE NOT NULL,
  rule_type text NOT NULL, -- 'error_pattern', 'performance', 'data_integrity', 'security'
  detection_query text,
  severity text DEFAULT 'medium', -- 'low', 'medium', 'high', 'critical'
  auto_fix_available boolean DEFAULT false,
  auto_fix_script text,
  notification_threshold integer DEFAULT 1,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE bug_detection_rules ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage bug detection rules"
  ON bug_detection_rules FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE TABLE IF NOT EXISTS self_healing_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rule_id uuid REFERENCES bug_detection_rules(id),
  pipeline_id uuid REFERENCES main_pipelines(id),
  issue_type text NOT NULL,
  issue_description text NOT NULL,
  severity text NOT NULL,
  detected_at timestamptz DEFAULT now(),
  auto_fix_attempted boolean DEFAULT false,
  auto_fix_successful boolean DEFAULT false,
  fix_applied_at timestamptz,
  fix_description text,
  manual_intervention_required boolean DEFAULT false,
  resolved boolean DEFAULT false,
  resolved_at timestamptz,
  resolved_by uuid REFERENCES auth.users(id),
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE self_healing_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view self-healing logs"
  ON self_healing_logs FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role IN ('admin', 'operator')
    )
  );

CREATE POLICY "System can create healing logs"
  ON self_healing_logs FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Admins can update healing logs"
  ON self_healing_logs FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role IN ('admin', 'operator')
    )
  );

-- =============================================
-- GITHUB INTEGRATION
-- =============================================

CREATE TABLE IF NOT EXISTS github_repositories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  repo_url text UNIQUE NOT NULL,
  repo_name text NOT NULL,
  repo_owner text NOT NULL,
  branch text DEFAULT 'main',
  connected_by uuid REFERENCES auth.users(id),
  access_token_encrypted text,
  last_sync_at timestamptz,
  sync_status text DEFAULT 'pending', -- 'pending', 'syncing', 'completed', 'failed'
  total_files integer DEFAULT 0,
  total_lines integer DEFAULT 0,
  languages jsonb DEFAULT '{}'::jsonb,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE github_repositories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their connected repos"
  ON github_repositories FOR SELECT
  TO authenticated
  USING (connected_by = auth.uid() OR EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_roles.user_id = auth.uid()
    AND user_roles.role IN ('admin', 'operator')
  ));

CREATE POLICY "Users can connect repos"
  ON github_repositories FOR INSERT
  TO authenticated
  WITH CHECK (connected_by = auth.uid());

CREATE POLICY "Users can update their repos"
  ON github_repositories FOR UPDATE
  TO authenticated
  USING (connected_by = auth.uid());

CREATE TABLE IF NOT EXISTS github_repo_analysis (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  repo_id uuid REFERENCES github_repositories(id) ON DELETE CASCADE,
  analysis_type text NOT NULL, -- 'structure', 'dependencies', 'patterns', 'documentation'
  file_path text,
  content_summary text,
  code_patterns jsonb DEFAULT '[]'::jsonb,
  dependencies jsonb DEFAULT '[]'::jsonb,
  complexity_score integer,
  documentation_quality decimal(3,2),
  recommendations text[],
  ai_insights jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE github_repo_analysis ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view analysis of their repos"
  ON github_repo_analysis FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM github_repositories gr
      WHERE gr.id = github_repo_analysis.repo_id
      AND (gr.connected_by = auth.uid() OR EXISTS (
        SELECT 1 FROM user_roles
        WHERE user_roles.user_id = auth.uid()
        AND user_roles.role IN ('admin', 'operator')
      ))
    )
  );

CREATE POLICY "System can create repo analysis"
  ON github_repo_analysis FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- =============================================
-- INDEXES FOR PERFORMANCE
-- =============================================

CREATE INDEX IF NOT EXISTS idx_pipelines_slug ON main_pipelines(slug);
CREATE INDEX IF NOT EXISTS idx_pipelines_category ON main_pipelines(category);
CREATE INDEX IF NOT EXISTS idx_pipeline_access_user ON pipeline_access(user_id);
CREATE INDEX IF NOT EXISTS idx_country_adaptations_book ON country_adaptations(book_id);
CREATE INDEX IF NOT EXISTS idx_country_adaptations_country ON country_adaptations(country_code);
CREATE INDEX IF NOT EXISTS idx_ai_stats_pipeline ON ai_process_stats(pipeline_id);
CREATE INDEX IF NOT EXISTS idx_ai_stats_model ON ai_process_stats(ai_model);
CREATE INDEX IF NOT EXISTS idx_ai_stats_status ON ai_process_stats(status);
CREATE INDEX IF NOT EXISTS idx_attachments_pipeline ON attachment_reviews(pipeline_id);
CREATE INDEX IF NOT EXISTS idx_attachments_book ON attachment_reviews(book_id);
CREATE INDEX IF NOT EXISTS idx_stress_test_pipeline ON stress_test_results(pipeline_id);
CREATE INDEX IF NOT EXISTS idx_healing_logs_pipeline ON self_healing_logs(pipeline_id);
CREATE INDEX IF NOT EXISTS idx_healing_logs_resolved ON self_healing_logs(resolved);
CREATE INDEX IF NOT EXISTS idx_github_repos_owner ON github_repositories(repo_owner);

-- =============================================
-- INSERT DEFAULT DATA
-- =============================================

-- Insert 6 main pipelines
INSERT INTO main_pipelines (name, slug, description, category, is_admin_only, priority_order) VALUES
  ('Educational Books', 'educational-books', 'Global library packages for K-12 and adult learning', 'education', false, 1),
  ('Scouts System', 'scouts', 'Merit badges, handbooks, training materials, and scout-specific content', 'scouts', true, 2),
  ('School & Institutional Content', 'school-content', 'Educational materials for schools and institutions', 'education', false, 3),
  ('Corporate Training', 'corporate', 'Company training materials and corporate documentation', 'corporate', false, 4),
  ('Language Preservation', 'language-preservation', 'Documentation and preservation of endangered languages', 'preservation', false, 5),
  ('Web Development & Vibe Coding', 'web-dev', 'GitHub repo analysis, code generation, and web development', 'web-dev', false, 6)
ON CONFLICT (slug) DO NOTHING;

-- Insert top 30 countries for auto-generation (Tier 1 & 2)
INSERT INTO country_adaptation_configs (country_code, country_name, priority_tier, locale, currency_code, measurement_system) VALUES
  -- Tier 1: Top Priority (English-speaking & largest markets)
  ('US', 'United States', 1, 'en-US', 'USD', 'imperial'),
  ('GB', 'United Kingdom', 1, 'en-GB', 'GBP', 'metric'),
  ('CA', 'Canada', 1, 'en-CA', 'CAD', 'metric'),
  ('AU', 'Australia', 1, 'en-AU', 'AUD', 'metric'),
  ('IN', 'India', 1, 'en-IN', 'INR', 'metric'),
  ('DE', 'Germany', 1, 'de-DE', 'EUR', 'metric'),
  ('FR', 'France', 1, 'fr-FR', 'EUR', 'metric'),
  ('ES', 'Spain', 1, 'es-ES', 'EUR', 'metric'),
  ('IT', 'Italy', 1, 'it-IT', 'EUR', 'metric'),
  ('JP', 'Japan', 1, 'ja-JP', 'JPY', 'metric'),
  
  -- Tier 2: High Priority
  ('BR', 'Brazil', 2, 'pt-BR', 'BRL', 'metric'),
  ('MX', 'Mexico', 2, 'es-MX', 'MXN', 'metric'),
  ('CN', 'China', 2, 'zh-CN', 'CNY', 'metric'),
  ('KR', 'South Korea', 2, 'ko-KR', 'KRW', 'metric'),
  ('NL', 'Netherlands', 2, 'nl-NL', 'EUR', 'metric'),
  ('SE', 'Sweden', 2, 'sv-SE', 'SEK', 'metric'),
  ('NO', 'Norway', 2, 'no-NO', 'NOK', 'metric'),
  ('DK', 'Denmark', 2, 'da-DK', 'DKK', 'metric'),
  ('FI', 'Finland', 2, 'fi-FI', 'EUR', 'metric'),
  ('PL', 'Poland', 2, 'pl-PL', 'PLN', 'metric'),
  ('BE', 'Belgium', 2, 'nl-BE', 'EUR', 'metric'),
  ('AT', 'Austria', 2, 'de-AT', 'EUR', 'metric'),
  ('CH', 'Switzerland', 2, 'de-CH', 'CHF', 'metric'),
  ('IE', 'Ireland', 2, 'en-IE', 'EUR', 'metric'),
  ('NZ', 'New Zealand', 2, 'en-NZ', 'NZD', 'metric'),
  ('SG', 'Singapore', 2, 'en-SG', 'SGD', 'metric'),
  ('ZA', 'South Africa', 2, 'en-ZA', 'ZAR', 'metric'),
  ('AR', 'Argentina', 2, 'es-AR', 'ARS', 'metric'),
  ('CL', 'Chile', 2, 'es-CL', 'CLP', 'metric'),
  ('PT', 'Portugal', 2, 'pt-PT', 'EUR', 'metric')
ON CONFLICT (country_code) DO NOTHING;

-- Insert some default bug detection rules
INSERT INTO bug_detection_rules (rule_name, rule_type, severity, auto_fix_available) VALUES
  ('High Token Usage Spike', 'performance', 'high', false),
  ('Failed Generation Loop', 'error_pattern', 'critical', true),
  ('Orphaned Storage Files', 'data_integrity', 'medium', true),
  ('Stale AI Process Records', 'data_integrity', 'low', true),
  ('Missing RLS Policies', 'security', 'critical', false)
ON CONFLICT (rule_name) DO NOTHING;