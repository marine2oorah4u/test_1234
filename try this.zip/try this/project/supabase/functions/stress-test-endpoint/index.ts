import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    );

    const { data: { user } } = await supabaseClient.auth.getUser();
    if (!user) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    const url = new URL(req.url);
    const testType = url.searchParams.get('type') || 'simple';
    const complexity = parseInt(url.searchParams.get('complexity') || '1');
    
    const startTime = performance.now();
    
    let result: any;
    switch (testType) {
      case 'database':
        result = await testDatabase(supabaseClient, complexity);
        break;
      case 'compute':
        result = await testCompute(complexity);
        break;
      case 'memory':
        result = await testMemory(complexity);
        break;
      default:
        result = await testSimple();
    }
    
    const endTime = performance.now();
    const responseTime = endTime - startTime;
    
    const response = {
      success: true,
      testType,
      complexity,
      responseTime: Math.round(responseTime),
      timestamp: new Date().toISOString(),
      result,
    };

    return new Response(
      JSON.stringify(response),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error) {
    console.error('Error in stress test endpoint:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message,
        timestamp: new Date().toISOString(),
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});

async function testSimple() {
  return {
    operation: 'simple',
    message: 'Endpoint responding normally',
  };
}

async function testDatabase(client: any, complexity: number) {
  const queries = [];
  
  for (let i = 0; i < complexity; i++) {
    queries.push(
      client
        .from('books')
        .select('id, title, subject_category, created_at')
        .limit(10)
    );
  }
  
  const results = await Promise.all(queries);
  const totalRecords = results.reduce((sum, r) => sum + (r.data?.length || 0), 0);
  
  return {
    operation: 'database',
    queriesExecuted: complexity,
    recordsRetrieved: totalRecords,
  };
}

async function testCompute(complexity: number) {
  let result = 0;
  const iterations = complexity * 100000;
  
  for (let i = 0; i < iterations; i++) {
    result += Math.sqrt(i) * Math.sin(i);
  }
  
  return {
    operation: 'compute',
    iterations,
    result: result.toFixed(2),
  };
}

async function testMemory(complexity: number) {
  const arrays = [];
  const arraySize = complexity * 10000;
  
  for (let i = 0; i < 10; i++) {
    arrays.push(new Array(arraySize).fill(Math.random()));
  }
  
  const totalSize = arrays.reduce((sum, arr) => sum + arr.length, 0);
  
  return {
    operation: 'memory',
    arraysCreated: arrays.length,
    totalElements: totalSize,
    approximateMB: (totalSize * 8 / 1024 / 1024).toFixed(2),
  };
}
