import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";
import { jsPDF } from "npm:jspdf@2.5.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface BookContent {
  title: string;
  chapters: Chapter[];
  metadata: {
    subject: string;
    readingLevel: string;
    wordCount: number;
  };
}

interface Chapter {
  title: string;
  content: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { queueId } = await req.json();

    if (!queueId) {
      throw new Error("Queue ID is required");
    }

    const { data: queueItem, error: queueError } = await supabase
      .from("generation_queue")
      .select("*, books(*)")
      .eq("id", queueId)
      .maybeSingle();

    if (queueError) throw queueError;
    if (!queueItem) throw new Error("Queue item not found");

    const config = queueItem.generation_config;
    const book = queueItem.books;

    // Fetch API keys
    const { data: apiKeys } = await supabase
      .from("api_keys")
      .select("service_name, api_key, status")
      .in("status", ["active", "testing"]);

    const openaiKey = apiKeys?.find(k => k.service_name === "openai")?.api_key;
    if (!openaiKey) {
      throw new Error("OpenAI API key not configured");
    }

    // Get book versions to generate
    const { data: versions } = await supabase
      .from("book_versions")
      .select("*")
      .eq("book_id", book.id);

    if (!versions || versions.length === 0) {
      throw new Error("No book versions found");
    }

    // Generate content for each version
    for (const version of versions) {
      try {
        await updateProgress(supabase, queueId, "research", 10);
        const outline = await generateOutline(openaiKey, book.subject, version.reading_level);

        await updateProgress(supabase, queueId, "writing", 30);
        const content = await generateBookContent(openaiKey, book.subject, outline, version.reading_level);

        await updateProgress(supabase, queueId, "formats", 60);

        if (version.format_type === "pdf") {
          const pdfData = await generatePDF(content, book.title);
          const fileUrl = await uploadToStorage(supabase, pdfData, book.id, version.id, "pdf");

          await supabase
            .from("book_versions")
            .update({
              file_url: fileUrl,
              status: "completed",
              word_count: content.metadata.wordCount,
            })
            .eq("id", version.id);
        } else if (version.format_type === "text") {
          const textData = await generateTextFile(content);
          const fileUrl = await uploadToStorage(supabase, textData, book.id, version.id, "txt");

          await supabase
            .from("book_versions")
            .update({
              file_url: fileUrl,
              status: "completed",
              word_count: content.metadata.wordCount,
            })
            .eq("id", version.id);
        }

        await updateProgress(supabase, queueId, "finalizing", 90);
      } catch (error) {
        console.error(`Error generating version ${version.id}:`, error);
        await supabase
          .from("book_versions")
          .update({
            status: "failed",
            metadata: { error: error.message },
          })
          .eq("id", version.id);
      }
    }

    await supabase
      .from("generation_queue")
      .update({
        status: "completed",
        progress_percentage: 100,
        completed_at: new Date().toISOString(),
      })
      .eq("id", queueId);

    await supabase
      .from("books")
      .update({
        status: "completed",
        completed_at: new Date().toISOString(),
      })
      .eq("id", book.id);

    return new Response(
      JSON.stringify({ success: true, message: "Book generation completed" }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Error in book generation:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});

async function updateProgress(
  supabase: any,
  queueId: string,
  stage: string,
  percentage: number
) {
  await supabase
    .from("generation_queue")
    .update({
      progress_stage: stage,
      progress_percentage: percentage,
      status: "processing",
    })
    .eq("id", queueId);
}

async function generateOutline(apiKey: string, subject: string, readingLevel: string): Promise<string[]> {
  const prompt = `Create a detailed outline for an educational book about "${subject}" for ${readingLevel} reading level.
  Provide 5-7 chapter titles that cover the topic comprehensively. Return only the chapter titles, one per line.`;

  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "gpt-3.5-turbo",
      messages: [
        { role: "system", content: "You are an expert educational content writer." },
        { role: "user", content: prompt }
      ],
      temperature: 0.7,
      max_tokens: 500,
    }),
  });

  if (!response.ok) {
    throw new Error(`OpenAI API error: ${response.statusText}`);
  }

  const data = await response.json();
  const outline = data.choices[0].message.content.trim().split("\n").filter((line: string) => line.trim());
  return outline;
}

async function generateBookContent(
  apiKey: string,
  subject: string,
  outline: string[],
  readingLevel: string
): Promise<BookContent> {
  const chapters: Chapter[] = [];
  let totalWords = 0;

  for (const chapterTitle of outline) {
    const prompt = `Write a comprehensive chapter titled "${chapterTitle}" for an educational book about "${subject}".
    Target reading level: ${readingLevel}.
    Write 500-800 words with clear explanations, examples, and engaging content.`;

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: [
          { role: "system", content: "You are an expert educational content writer." },
          { role: "user", content: prompt }
        ],
        temperature: 0.7,
        max_tokens: 1500,
      }),
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.statusText}`);
    }

    const data = await response.json();
    const content = data.choices[0].message.content.trim();
    const wordCount = content.split(/\s+/).length;
    totalWords += wordCount;

    chapters.push({
      title: chapterTitle.replace(/^\d+\.\s*/, ""),
      content: content,
    });
  }

  return {
    title: subject,
    chapters,
    metadata: {
      subject,
      readingLevel,
      wordCount: totalWords,
    },
  };
}

async function generatePDF(content: BookContent, title: string): Promise<Uint8Array> {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 20;
  const maxWidth = pageWidth - (margin * 2);
  let yPosition = margin;

  // Title page
  doc.setFontSize(24);
  doc.text(title, pageWidth / 2, pageHeight / 2, { align: "center" });
  doc.setFontSize(12);
  doc.text(`Reading Level: ${content.metadata.readingLevel}`, pageWidth / 2, pageHeight / 2 + 15, { align: "center" });
  doc.text(`Word Count: ${content.metadata.wordCount}`, pageWidth / 2, pageHeight / 2 + 25, { align: "center" });
  doc.addPage();
  yPosition = margin;

  // Chapters
  for (const chapter of content.chapters) {
    // Chapter title
    doc.setFontSize(16);
    doc.setFont("helvetica", "bold");

    if (yPosition > pageHeight - 40) {
      doc.addPage();
      yPosition = margin;
    }

    doc.text(chapter.title, margin, yPosition);
    yPosition += 10;

    // Chapter content
    doc.setFontSize(11);
    doc.setFont("helvetica", "normal");

    const lines = doc.splitTextToSize(chapter.content, maxWidth);

    for (const line of lines) {
      if (yPosition > pageHeight - margin) {
        doc.addPage();
        yPosition = margin;
      }
      doc.text(line, margin, yPosition);
      yPosition += 7;
    }

    yPosition += 15; // Space between chapters
  }

  return doc.output("arraybuffer");
}

async function generateTextFile(content: BookContent): Promise<Uint8Array> {
  let text = `${content.title}\n\n`;
  text += `Reading Level: ${content.metadata.readingLevel}\n`;
  text += `Word Count: ${content.metadata.wordCount}\n`;
  text += `\n${"=".repeat(80)}\n\n`;

  for (const chapter of content.chapters) {
    text += `${chapter.title}\n`;
    text += `${"-".repeat(chapter.title.length)}\n\n`;
    text += `${chapter.content}\n\n`;
    text += `${"=".repeat(80)}\n\n`;
  }

  return new TextEncoder().encode(text);
}

async function uploadToStorage(
  supabase: any,
  fileData: Uint8Array,
  bookId: string,
  versionId: string,
  extension: string
): Promise<string> {
  const bucket = extension === "pdf" ? "book-pdfs" : "book-documents";
  const fileName = `${bookId}/${versionId}.${extension}`;
  const mimeType = extension === "pdf" ? "application/pdf" : "text/plain";

  const { error: uploadError } = await supabase.storage
    .from(bucket)
    .upload(fileName, fileData, {
      contentType: mimeType,
      upsert: true,
    });

  if (uploadError) {
    throw new Error(`Storage upload error: ${uploadError.message}`);
  }

  const { data } = supabase.storage
    .from(bucket)
    .getPublicUrl(fileName);

  return data.publicUrl;
}
