# Language Support System

## Overview

Complete language quality tracking system with 150 languages across 3 quality tiers, featuring user-controlled robotic voice options for languages with limited AI voice support.

## Language Tiers

### Tier 1: Complete (50-75 languages)
- **Badge**: ✅ Fully Available
- **Translation**: 95-100% accurate
- **Voice**: Excellent quality (ElevenLabs, OpenAI TTS HD)
- **Features**: All features at 100%
- **Examples**: English, Spanish, French, German, Italian, Portuguese, Japanese, Chinese, Korean, Arabic, Hindi, Russian

### Tier 2: Improving (75-100 languages)
- **Badge**: ⭐ High Quality - Continuously Improving
- **Translation**: 85-95% accurate
- **Voice**: Good quality (Google Neural, Azure Neural)
- **Features**: Most features available
- **Banner**: "This course is continuously being improved as AI models advance. Translation quality is good but may contain minor errors."
- **Examples**: Polish, Czech, Greek, Romanian, Bengali, Tagalog, Thai, Vietnamese

### Tier 3: Beta (25-50 languages)
- **Badge**: 🚧 Beta Quality - Active Development
- **Translation**: 70-85% accurate
- **Voice**: Text-only by default, robotic voice optional
- **Banner**: "This course is in active development. Translation quality is decent but may contain errors. We're continuously improving it."
- **User Choice**: Can enable robotic voice with warning

## Voice Quality Strategy

### High-Quality Voice Available
- Display: "Audio available (excellent/good quality)"
- Action: Enable automatically

### Robotic Voice Available
- Display: "High-quality audio not yet available"
- Button: "Enable automated voice?"
- Modal Warning:
  - "This uses automated voice synthesis which may sound robotic"
  - "We recommend text-based learning for better experience"
  - Options: "Keep text-only" | "Enable anyway"

### No Voice Available
- Display: "Audio coming soon - Text-based learning available"
- All text features work perfectly
- No voice button shown

## Database Schema

### supported_languages
- Language metadata and quality tier
- Feature availability flags
- Voice quality and provider info
- Robotic voice availability
- User-facing status messages

### language_features
- Detailed feature tracking per language
- 18 feature types (text, audio, video, AI tutor, etc.)
- Quality ratings and availability messages

### course_language_status
- Generation status per book per language
- Quality scores and user ratings
- Feature completion tracking
- Beta/improving warnings

### language_quality_reports
- User-submitted feedback system
- Issue types: translation errors, grammar, cultural issues, voice quality
- Status tracking: submitted → under review → fixed
- Native speaker flagging

### user_language_voice_preferences
- User's robotic voice choices per language
- Global voice quality preference
- Individual language overrides

## UI Components

### LanguageCard
- Shows language with quality badge
- Feature availability indicators
- Speaker population stats
- Click to select and configure

### VoiceQualitySelector
- Shows current voice status
- Toggle for robotic voice (if available)
- Warning modal before enabling
- Clear messaging about quality

### LanguageSelectionPage
- Browse all 150 languages
- Search and filter by tier
- Stats dashboard (tier counts)
- Select language to configure

## Voice Provider Support

| Provider | Languages | Quality |
|----------|-----------|---------|
| **ElevenLabs** | 29 | Excellent |
| **OpenAI TTS** | 57 | Good |
| **Google Neural** | 40+ | Good |
| **Azure Neural** | 75+ | Good |
| **Google TTS (Standard)** | 140+ | Robotic |
| **Azure Basic** | 140+ | Robotic |

## User Flow

1. **Select Language** → Browse 150 languages with quality badges
2. **Review Features** → See what's available for that language
3. **Voice Decision** →
   - Tier 1/2: Auto-enabled high-quality voice
   - Tier 3: Choose text-only or robotic voice
4. **Start Learning** → All text content works regardless of voice choice
5. **Report Issues** → Users can report translation problems
6. **Continuous Improvement** → Courses updated as AI improves

## Admin Features

- Manage language quality tiers
- Update feature availability
- Review user-reported issues
- Track translation quality scores
- Set improvement timelines

## Key Benefits

✅ **Transparent Quality**: Users know exactly what to expect
✅ **User Choice**: Let users decide about robotic voice
✅ **Continuous Improvement**: Clear communication about ongoing improvements
✅ **Issue Reporting**: Users help improve quality
✅ **Equal Access**: Every book available in all 150 languages
✅ **Text-First**: All courses fully functional in text mode

## Future Expansion

As AI voice models improve:
- Automatically upgrade languages from Tier 3 → Tier 2 → Tier 1
- Re-generate courses with better models
- Notify users of improvements
- Expand to additional languages (200+)
