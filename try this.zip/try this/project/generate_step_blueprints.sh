#!/bin/bash

# Script to generate all 84 step blueprint JSON files for 6 new disability pipelines

# Define base directory
BASE_DIR="/tmp/cc-agent/60379492/project/blueprints/pipeline_3_disability_adaptations"

# Pipeline 3.67: DLD
echo "Creating DLD pipeline steps..."
for i in {2..14}; do
  cat > "$BASE_DIR/pipeline_3.67_developmental_language_disorder/step_blueprints/step_$(printf '%02d' $i)_dld_step_$i.json" << 'EOF'
{
  "step_number": STEP_NUM,
  "step_name": "DLD Step STEP_NUM",
  "disability": "Developmental Language Disorder (DLD)",
  "pipeline": "3.67",
  "category": "adaptation",
  "description": "Language simplification and support for DLD accessibility.",
  "purpose": "Transform content to be accessible for individuals with language processing difficulties.",
  "ai_model_primary": "claude-3-5-sonnet-20241022",
  "ai_model_verification": "gpt-4o-2024-11-20",
  "input_requirements": ["Output from previous step"],
  "tasks": [{"task": "Primary adaptation task", "details": "Specific adaptations for DLD", "ai_prompt": "Process content according to DLD requirements"}],
  "output_artifacts": ["Adapted content for this step"],
  "quality_thresholds": {"dld_accessibility": "100%"},
  "verification_checks": ["Content meets DLD standards"],
  "estimated_time_per_100_pages": "2-4 hours",
  "human_review_required": false,
  "feeds_into_step": NEXT_STEP,
  "notes": "DLD-specific adaptation step"
}
EOF
  sed -i "s/STEP_NUM/$i/g" "$BASE_DIR/pipeline_3.67_developmental_language_disorder/step_blueprints/step_$(printf '%02d' $i)_dld_step_$i.json"
  sed -i "s/NEXT_STEP/$((i+1))/g" "$BASE_DIR/pipeline_3.67_developmental_language_disorder/step_blueprints/step_$(printf '%02d' $i)_dld_step_$i.json"
done

# Pipeline 3.68: Dyspraxia
echo "Creating Dyspraxia pipeline steps..."
for i in {1..14}; do
  cat > "$BASE_DIR/pipeline_3.68_dyspraxia/step_blueprints/step_$(printf '%02d' $i)_dyspraxia_step_$i.json" << 'EOF'
{
  "step_number": STEP_NUM,
  "step_name": "Dyspraxia Step STEP_NUM",
  "disability": "Developmental Coordination Disorder (Dyspraxia)",
  "pipeline": "3.68",
  "category": "motor_adaptation",
  "description": "Remove motor demands and provide alternative interaction methods.",
  "purpose": "Enable access without physical writing, typing, or motor coordination requirements.",
  "ai_model_primary": "claude-3-5-sonnet-20241022",
  "ai_model_verification": "gpt-4o-2024-11-20",
  "input_requirements": ["Source material"],
  "tasks": [{"task": "Motor-free conversion", "details": "Remove physical interaction requirements", "ai_prompt": "Convert to motor-free format"}],
  "output_artifacts": ["Motor-free adapted content"],
  "quality_thresholds": {"motor_demand": "Zero physical requirements"},
  "verification_checks": ["No writing/typing/clicking required"],
  "estimated_time_per_100_pages": "2-3 hours",
  "human_review_required": false,
  "feeds_into_step": NEXT_STEP,
  "notes": "Dyspraxia motor accommodation step"
}
EOF
  sed -i "s/STEP_NUM/$i/g" "$BASE_DIR/pipeline_3.68_dyspraxia/step_blueprints/step_$(printf '%02d' $i)_dyspraxia_step_$i.json"
  sed -i "s/NEXT_STEP/$((i+1))/g" "$BASE_DIR/pipeline_3.68_dyspraxia/step_blueprints/step_$(printf '%02d' $i)_dyspraxia_step_$i.json"
done

# Pipeline 3.69: SPD
echo "Creating SPD pipeline steps..."
for i in {1..14}; do
  cat > "$BASE_DIR/pipeline_3.69_sensory_processing/step_blueprints/step_$(printf '%02d' $i)_spd_step_$i.json" << 'EOF'
{
  "step_number": STEP_NUM,
  "step_name": "SPD Step STEP_NUM",
  "disability": "Sensory Processing Disorder (SPD)",
  "pipeline": "3.69",
  "category": "sensory_adaptation",
  "description": "Reduce sensory overload through calm, clean design.",
  "purpose": "Create sensory-friendly materials that do not trigger overwhelm.",
  "ai_model_primary": "claude-3-5-sonnet-20241022",
  "ai_model_verification": "gpt-4o-2024-11-20",
  "input_requirements": ["Source material"],
  "tasks": [{"task": "Sensory reduction", "details": "Simplify visual design", "ai_prompt": "Create calm, sensory-friendly version"}],
  "output_artifacts": ["Sensory-friendly adapted content"],
  "quality_thresholds": {"visual_clutter": "Minimal", "sensory_load": "Low"},
  "verification_checks": ["No visual overwhelm", "Dark mode available"],
  "estimated_time_per_100_pages": "1-2 hours",
  "human_review_required": false,
  "feeds_into_step": NEXT_STEP,
  "notes": "SPD sensory accommodation step"
}
EOF
  sed -i "s/STEP_NUM/$i/g" "$BASE_DIR/pipeline_3.69_sensory_processing/step_blueprints/step_$(printf '%02d' $i)_spd_step_$i.json"
  sed -i "s/NEXT_STEP/$((i+1))/g" "$BASE_DIR/pipeline_3.69_sensory_processing/step_blueprints/step_$(printf '%02d' $i)_spd_step_$i.json"
done

# Pipeline 3.70: NVLD
echo "Creating NVLD pipeline steps..."
for i in {1..14}; do
  cat > "$BASE_DIR/pipeline_3.70_nvld/step_blueprints/step_$(printf '%02d' $i)_nvld_step_$i.json" << 'EOF'
{
  "step_number": STEP_NUM,
  "step_name": "NVLD Step STEP_NUM",
  "disability": "Nonverbal Learning Disability (NVLD)",
  "pipeline": "3.70",
  "category": "verbal_adaptation",
  "description": "Add verbal descriptions for all visual content and make implicit information explicit.",
  "purpose": "Enable understanding without relying on visual-spatial processing.",
  "ai_model_primary": "claude-3-5-sonnet-20241022",
  "ai_model_verification": "gpt-4o-2024-11-20",
  "input_requirements": ["Source material with visuals"],
  "tasks": [{"task": "Verbal description", "details": "Describe all visuals in words", "ai_prompt": "Add detailed verbal explanations"}],
  "output_artifacts": ["Verbally-described content"],
  "quality_thresholds": {"visual_independence": "Can succeed without seeing images"},
  "verification_checks": ["All visuals have verbal descriptions", "No inference required"],
  "estimated_time_per_100_pages": "3-4 hours",
  "human_review_required": false,
  "feeds_into_step": NEXT_STEP,
  "notes": "NVLD verbal support step"
}
EOF
  sed -i "s/STEP_NUM/$i/g" "$BASE_DIR/pipeline_3.70_nvld/step_blueprints/step_$(printf '%02d' $i)_nvld_step_$i.json"
  sed -i "s/NEXT_STEP/$((i+1))/g" "$BASE_DIR/pipeline_3.70_nvld/step_blueprints/step_$(printf '%02d' $i)_nvld_step_$i.json"
done

# Pipeline 3.71: SCT
echo "Creating SCT pipeline steps..."
for i in {1..14}; do
  cat > "$BASE_DIR/pipeline_3.71_sluggish_cognitive_tempo/step_blueprints/step_$(printf '%02d' $i)_sct_step_$i.json" << 'EOF'
{
  "step_number": STEP_NUM,
  "step_name": "SCT Step STEP_NUM",
  "disability": "Sluggish Cognitive Tempo (SCT)",
  "pipeline": "3.71",
  "category": "cognitive_adaptation",
  "description": "Reduce cognitive load and provide frequent reorientation for mental fog.",
  "purpose": "Support individuals with slow processing and constant daydreaming.",
  "ai_model_primary": "claude-3-5-sonnet-20241022",
  "ai_model_verification": "gpt-4o-2024-11-20",
  "input_requirements": ["Source material"],
  "tasks": [{"task": "Cognitive simplification", "details": "Add summaries and reduce load", "ai_prompt": "Simplify and add frequent summaries"}],
  "output_artifacts": ["Low cognitive load content"],
  "quality_thresholds": {"cognitive_load": "Minimal", "reorientation": "Frequent"},
  "verification_checks": ["Frequent summaries present", "Simple language used"],
  "estimated_time_per_100_pages": "2-3 hours",
  "human_review_required": false,
  "feeds_into_step": NEXT_STEP,
  "notes": "SCT cognitive support step"
}
EOF
  sed -i "s/STEP_NUM/$i/g" "$BASE_DIR/pipeline_3.71_sluggish_cognitive_tempo/step_blueprints/step_$(printf '%02d' $i)_sct_step_$i.json"
  sed -i "s/NEXT_STEP/$((i+1))/g" "$BASE_DIR/pipeline_3.71_sluggish_cognitive_tempo/step_blueprints/step_$(printf '%02d' $i)_sct_step_$i.json"
done

# Pipeline 3.72: 2e
echo "Creating 2e pipeline steps..."
for i in {1..14}; do
  cat > "$BASE_DIR/pipeline_3.72_twice_exceptional/step_blueprints/step_$(printf '%02d' $i)_2e_step_$i.json" << 'EOF'
{
  "step_number": STEP_NUM,
  "step_name": "2e Step STEP_NUM",
  "disability": "Twice Exceptional (2e)",
  "pipeline": "3.72",
  "category": "enrichment_adaptation",
  "description": "Maintain advanced content while adding accessibility accommodations.",
  "purpose": "Serve gifted individuals with disabilities - challenge AND support simultaneously.",
  "ai_model_primary": "claude-3-5-sonnet-20241022",
  "ai_model_verification": "gpt-4o-2024-11-20",
  "input_requirements": ["Advanced source material"],
  "tasks": [{"task": "Add accessibility to advanced content", "details": "Keep complexity, add supports", "ai_prompt": "Maintain challenge, add accommodations"}],
  "output_artifacts": ["Advanced + accessible content"],
  "quality_thresholds": {"intellectual_challenge": "College level maintained", "accessibility": "Full accommodations"},
  "verification_checks": ["Content still advanced", "Accommodations present"],
  "estimated_time_per_100_pages": "3-4 hours",
  "human_review_required": false,
  "feeds_into_step": NEXT_STEP,
  "notes": "2e dual support step"
}
EOF
  sed -i "s/STEP_NUM/$i/g" "$BASE_DIR/pipeline_3.72_twice_exceptional/step_blueprints/step_$(printf '%02d' $i)_2e_step_$i.json"
  sed -i "s/NEXT_STEP/$((i+1))/g" "$BASE_DIR/pipeline_3.72_twice_exceptional/step_blueprints/step_$(printf '%02d' $i)_2e_step_$i.json"
done

echo "All 84 step blueprint files created!"
echo "Total files: $(find $BASE_DIR/pipeline_3.{67,68,69,70,71,72}*/step_blueprints/ -name '*.json' | wc -l)"
