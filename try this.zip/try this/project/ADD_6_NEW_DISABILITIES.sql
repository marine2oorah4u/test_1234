-- Add 6 New Disabilities to Database
-- This inserts the new disabilities we're adding based on research

-- First, ensure categories exist
INSERT INTO disability_categories (name, description, sort_order) VALUES
('Learning Disabilities', 'Conditions that affect learning processes including reading, writing, math, and language', 1),
('Sensory Processing', 'Conditions affecting how sensory information is processed', 2),
('Cognitive/Executive Function', 'Conditions affecting thinking, memory, planning, and executive functions', 3),
('Motor/Physical', 'Conditions affecting physical movement and motor control', 4),
('Developmental', 'Conditions affecting overall development and multiple areas', 5),
('Neurological', 'Brain-based conditions affecting various functions', 6)
ON CONFLICT DO NOTHING;

-- Get category IDs (we'll need these)
-- For this script, we'll use subqueries to get the IDs

-- 1. DEVELOPMENTAL LANGUAGE DISORDER (DLD)
INSERT INTO disabilities (
  category_id,
  name,
  alternate_names,
  description,
  prevalence_count,
  prevalence_percentage,
  prevalence_source,
  impact_grade,
  impact_explanation,
  reading_impact_score,
  comprehension_impact_score,
  writing_impact_score,
  focus_attention_score,
  memory_impact_score,
  processing_speed_score,
  pipeline_status,
  pipeline_number,
  pipeline_priority,
  keep_remove_rationale,
  real_world_impact,
  accommodation_summary
) VALUES (
  (SELECT id FROM disability_categories WHERE name = 'Learning Disabilities' LIMIT 1),
  'Developmental Language Disorder (DLD)',
  ARRAY['Language-Based Learning Disorder', 'Specific Language Impairment', 'SLI'],
  'A condition where individuals struggle with understanding and using language despite having normal intelligence and no other developmental delays. Affects both oral and written language comprehension and expression.',
  24500000,
  7.50,
  'NIH/NIDCD studies estimate 7-8% of children have DLD',
  'A',
  'CRITICAL - Cannot understand complex sentences, instructions, or academic language. Makes all reading comprehension extremely difficult. Essential accommodation needed.',
  9, -- reading_impact
  10, -- comprehension_impact (HIGHEST)
  8, -- writing_impact
  6, -- focus_attention
  7, -- memory_impact
  7, -- processing_speed
  'add_new',
  '3.67',
  10,
  'MUST ADD - 24.5M people (7.5%) cannot understand academic language without simplification. This is fundamental to all learning.',
  'Cannot follow multi-step directions, cannot understand textbook language, struggles in all academic subjects, often misdiagnosed as intellectual disability',
  'Simplified language, shorter sentences, visual supports, explicit vocabulary instruction, avoid idioms/figurative language, frequent comprehension checks'
);

-- 2. DEVELOPMENTAL COORDINATION DISORDER (DYSPRAXIA)
INSERT INTO disabilities (
  category_id,
  name,
  alternate_names,
  description,
  prevalence_count,
  prevalence_percentage,
  prevalence_source,
  impact_grade,
  impact_explanation,
  reading_impact_score,
  comprehension_impact_score,
  writing_impact_score,
  focus_attention_score,
  memory_impact_score,
  processing_speed_score,
  pipeline_status,
  pipeline_number,
  pipeline_priority,
  keep_remove_rationale,
  real_world_impact,
  accommodation_summary
) VALUES (
  (SELECT id FROM disability_categories WHERE name = 'Motor/Physical' LIMIT 1),
  'Developmental Coordination Disorder (Dyspraxia)',
  ARRAY['Dyspraxia', 'Motor Planning Disorder', 'Clumsy Child Syndrome'],
  'A motor planning disorder affecting the ability to plan and coordinate physical movements. Impacts fine motor (writing, typing) and gross motor (balance, coordination) skills.',
  18000000,
  5.50,
  'Research indicates 5-6% of children have DCD/Dyspraxia',
  'A',
  'CRITICAL - Cannot physically complete assignments requiring writing, typing, or mouse control. Broader than dysgraphia - affects ALL motor-based tasks.',
  3, -- reading_impact (minimal)
  2, -- comprehension_impact (minimal)
  10, -- writing_impact (HIGHEST - cannot write/type)
  5, -- focus_attention (frustration impacts focus)
  4, -- memory_impact
  8, -- processing_speed (motor planning is slow)
  'add_new',
  '3.68',
  10,
  'MUST ADD - 18M people (5.5%) cannot physically complete standard assignments. Dysgraphia only covers writing; this covers ALL motor tasks including typing, mouse use, page turning.',
  'Cannot take handwritten notes, cannot type efficiently, struggles with physical books, exhausted by motor demands, often seen as lazy or unmotivated',
  'Speech-to-text, oral assessments, digital materials with minimal interaction needed, extended time for physical tasks, ergonomic accommodations, alternative response formats'
);

-- 3. SENSORY PROCESSING DISORDER (SPD)
INSERT INTO disabilities (
  category_id,
  name,
  alternate_names,
  description,
  prevalence_count,
  prevalence_percentage,
  prevalence_source,
  impact_grade,
  impact_explanation,
  reading_impact_score,
  comprehension_impact_score,
  writing_impact_score,
  focus_attention_score,
  memory_impact_score,
  processing_speed_score,
  pipeline_status,
  pipeline_number,
  pipeline_priority,
  keep_remove_rationale,
  real_world_impact,
  accommodation_summary
) VALUES (
  (SELECT id FROM disability_categories WHERE name = 'Sensory Processing' LIMIT 1),
  'Sensory Processing Disorder (SPD)',
  ARRAY['Sensory Integration Disorder', 'Sensory Modulation Disorder'],
  'A condition where the brain has trouble receiving and responding to sensory information. Can be over-responsive (sensory overload) or under-responsive. Affects learning through visual, auditory, and tactile sensitivities.',
  33000000,
  10.00,
  'Studies show 5-16% of children have SPD, using mid-range of 10%',
  'B',
  'HIGH PRIORITY - Standard textbooks cause sensory overload (busy pages, harsh lighting, overwhelming visuals). Cannot focus when in sensory distress. Accommodations are straightforward.',
  7, -- reading_impact (visual sensitivities)
  6, -- comprehension_impact (distracted by sensory input)
  5, -- writing_impact (tactile issues)
  9, -- focus_attention (HIGHEST - sensory overload prevents focus)
  5, -- memory_impact
  6, -- processing_speed
  'add_new',
  '3.69',
  9,
  'SHOULD ADD - 33M people (10%) experience sensory overload from standard materials. Easy accommodations with huge impact. Very common overlap with autism, ADHD.',
  'Cannot tolerate standard textbook design, overwhelmed by busy pages, sensitive to bright white paper, distracted by visual noise, may need movement breaks',
  'Calm/clean layout, muted colors, dark mode option, sans-serif fonts, larger spacing, minimal visual clutter, predictable organization, avoid overwhelming graphics'
);

-- 4. NONVERBAL LEARNING DISABILITY (NVLD)
INSERT INTO disabilities (
  category_id,
  name,
  alternate_names,
  description,
  prevalence_count,
  prevalence_percentage,
  prevalence_source,
  impact_grade,
  impact_explanation,
  reading_impact_score,
  comprehension_impact_score,
  writing_impact_score,
  focus_attention_score,
  memory_impact_score,
  processing_speed_score,
  pipeline_status,
  pipeline_number,
  pipeline_priority,
  keep_remove_rationale,
  real_world_impact,
  accommodation_summary
) VALUES (
  (SELECT id FROM disability_categories WHERE name = 'Learning Disabilities' LIMIT 1),
  'Nonverbal Learning Disability (NVLD)',
  ARRAY['Nonverbal LD', 'Right-Hemisphere Learning Disorder'],
  'The opposite of dyslexia - strong verbal skills but extreme difficulty with visual-spatial, math, pattern recognition, and reading nonverbal cues. Struggles with anything not explicitly stated in words.',
  11500000,
  3.50,
  'Estimated 3-4% of population has NVLD',
  'B',
  'HIGH PRIORITY - Cannot understand diagrams, charts, maps, or visual information. Needs everything explained in words. Often mistaken for being "smart but lazy."',
  4, -- reading_impact (reading words is fine)
  7, -- comprehension_impact (struggles with inference, context)
  6, -- writing_impact (organization issues)
  5, -- focus_attention
  6, -- memory_impact
  7, -- processing_speed (visual processing is slow)
  'add_new',
  '3.70',
  8,
  'SHOULD ADD - 11.5M people (3.5%) cannot learn from visual materials. Complete opposite of dyslexia. Needs verbal explanations for all visual content.',
  'Cannot understand graphs/charts without verbal explanation, misses social cues in reading, struggles with math despite strong reading, needs explicit instruction for everything',
  'Verbal descriptions of all visuals, explicit verbal instructions, avoid "figure it out" tasks, provide written social scripts, step-by-step verbal guidance, minimize reliance on visual-spatial reasoning'
);

-- 5. SLUGGISH COGNITIVE TEMPO (SCT)
INSERT INTO disabilities (
  category_id,
  name,
  alternate_names,
  description,
  prevalence_count,
  prevalence_percentage,
  prevalence_source,
  impact_grade,
  impact_explanation,
  reading_impact_score,
  comprehension_impact_score,
  writing_impact_score,
  focus_attention_score,
  memory_impact_score,
  processing_speed_score,
  pipeline_status,
  pipeline_number,
  pipeline_priority,
  keep_remove_rationale,
  real_world_impact,
  accommodation_summary
) VALUES (
  (SELECT id FROM disability_categories WHERE name = 'Cognitive/Executive Function' LIMIT 1),
  'Sluggish Cognitive Tempo (SCT)',
  ARRAY['Concentration Deficit Disorder', 'CDD'],
  'A distinct attention disorder (NOT ADHD) characterized by daydreaming, mental fog, lethargy, and slow processing speed. Appears "spaced out" rather than hyperactive.',
  8000000,
  2.50,
  'Studies estimate 2-3% have SCT, distinct from ADHD',
  'B',
  'HIGH PRIORITY - Different from ADHD. Constantly "in a fog," processes very slowly, loses track of what they are reading/doing. Standard pace is overwhelming.',
  6, -- reading_impact (slow, gets lost)
  7, -- comprehension_impact (mental fog)
  7, -- writing_impact (slow organization)
  9, -- focus_attention (HIGHEST - constantly drifting)
  8, -- memory_impact (working memory fog)
  10, -- processing_speed (HIGHEST - hallmark symptom)
  'add_new',
  '3.71',
  8,
  'SHOULD ADD - 8M people (2.5%) need slower pace and frequent reorientation. NOT the same as ADHD - different brain pattern, different accommodations.',
  'Daydreams during reading, loses place constantly, needs to reread multiple times, appears unmotivated but is struggling with mental fog, exhausted by cognitive demands',
  'Extended time (even more than ADHD), frequent summaries and reorientation, simple clear language, step-by-step with pauses, minimize cognitive load, built-in breaks'
);

-- 6. TWICE EXCEPTIONAL (2e)
INSERT INTO disabilities (
  category_id,
  name,
  alternate_names,
  description,
  prevalence_count,
  prevalence_percentage,
  prevalence_source,
  impact_grade,
  impact_explanation,
  reading_impact_score,
  comprehension_impact_score,
  writing_impact_score,
  focus_attention_score,
  memory_impact_score,
  processing_speed_score,
  pipeline_status,
  pipeline_number,
  pipeline_priority,
  keep_remove_rationale,
  real_world_impact,
  accommodation_summary
) VALUES (
  (SELECT id FROM disability_categories WHERE name = 'Developmental' LIMIT 1),
  'Twice Exceptional (2e)',
  ARRAY['Gifted with Learning Disability', '2e Learners'],
  'Individuals who are both intellectually gifted AND have one or more disabilities (e.g., gifted + dyslexic, gifted + ADHD). Need BOTH advanced content AND accommodations simultaneously.',
  6500000,
  2.00,
  'Estimated 2% of population is 2e - gifted with disability',
  'A',
  'CRITICAL - Unique needs. Cannot access their own intelligence without accommodations, but accommodations alone are not enough - they need advanced content. Standard materials either bore them or are inaccessible.',
  8, -- reading_impact (depends on disability)
  8, -- comprehension_impact (can understand advanced concepts if accessible)
  8, -- writing_impact (depends on disability)
  7, -- focus_attention (often bored by standard level)
  7, -- memory_impact
  7, -- processing_speed
  'add_new',
  '3.72',
  9,
  'MUST ADD - 6.5M people (2%) need advanced content + accommodations. Cannot be served by either "gifted" or "disability" materials alone. Unique population that falls through the cracks.',
  'Brilliant mind trapped by disability, standard special ed bores them, standard gifted programs exclude them, often undiagnosed because strengths mask weaknesses',
  'College-level concepts + accessibility features (dyslexic font, extended time, etc.), enrichment + accommodations, challenge + support, avoid dumbing down while providing access'
);

-- Add accommodations for each new disability

-- DLD Accommodations
INSERT INTO disability_accommodations (disability_id, accommodation_type, accommodation_name, description, difficulty_to_implement, impact_level, examples) VALUES
((SELECT id FROM disabilities WHERE name = 'Developmental Language Disorder (DLD)' LIMIT 1), 'cognitive', 'Simplified Language', 'Use shorter sentences (5-10 words), common vocabulary, active voice', 'moderate', 'critical', ARRAY['Instead of: "The phenomenon was observed by researchers" Use: "Researchers saw this happen"']),
((SELECT id FROM disabilities WHERE name = 'Developmental Language Disorder (DLD)' LIMIT 1), 'visual', 'Visual Supports', 'Add pictures, diagrams, and visual representations of concepts', 'easy', 'high', ARRAY['Picture dictionary', 'Labeled diagrams', 'Photo sequences']),
((SELECT id FROM disabilities WHERE name = 'Developmental Language Disorder (DLD)' LIMIT 1), 'cognitive', 'Explicit Vocabulary', 'Define all academic vocabulary, avoid idioms and figurative language', 'easy', 'critical', ARRAY['Vocabulary boxes', 'Glossary on page', 'Avoid: "piece of cake" Say: "easy"']);

-- Dyspraxia Accommodations
INSERT INTO disability_accommodations (disability_id, accommodation_type, accommodation_name, description, difficulty_to_implement, impact_level, examples) VALUES
((SELECT id FROM disabilities WHERE name = 'Developmental Coordination Disorder (Dyspraxia)' LIMIT 1), 'motor', 'Speech-to-Text Options', 'Allow voice input for all written responses', 'easy', 'critical', ARRAY['Built-in voice typing', 'Oral assessments', 'Video responses']),
((SELECT id FROM disabilities WHERE name = 'Developmental Coordination Disorder (Dyspraxia)' LIMIT 1), 'motor', 'Minimal Physical Interaction', 'Digital materials that require minimal clicking/typing', 'moderate', 'high', ARRAY['Single-click navigation', 'Large click targets', 'Keyboard-only navigation']),
((SELECT id FROM disabilities WHERE name = 'Developmental Coordination Disorder (Dyspraxia)' LIMIT 1), 'format', 'Alternative Response Formats', 'Multiple choice instead of essay, checkboxes instead of writing', 'easy', 'critical', ARRAY['Select from options', 'Drag and drop (simple)', 'Verbal demonstrations']);

-- SPD Accommodations
INSERT INTO disability_accommodations (disability_id, accommodation_type, accommodation_name, description, difficulty_to_implement, impact_level, examples) VALUES
((SELECT id FROM disabilities WHERE name = 'Sensory Processing Disorder (SPD)' LIMIT 1), 'visual', 'Calm Visual Design', 'Clean layout, muted colors, lots of white space, no visual clutter', 'easy', 'high', ARRAY['Simple backgrounds', 'One concept per page', 'Organized sections']),
((SELECT id FROM disabilities WHERE name = 'Sensory Processing Disorder (SPD)' LIMIT 1), 'visual', 'Dark Mode Option', 'Provide dark background option to reduce eye strain', 'easy', 'high', ARRAY['Toggle dark/light', 'Sepia tone option', 'Adjustable contrast']),
((SELECT id FROM disabilities WHERE name = 'Sensory Processing Disorder (SPD)' LIMIT 1), 'visual', 'Increased Spacing', 'Larger fonts, more line spacing, bigger margins', 'easy', 'medium', ARRAY['1.5-2x line spacing', '14pt+ fonts', 'Wide margins']);

-- NVLD Accommodations
INSERT INTO disability_accommodations (disability_id, accommodation_type, accommodation_name, description, difficulty_to_implement, impact_level, examples) VALUES
((SELECT id FROM disabilities WHERE name = 'Nonverbal Learning Disability (NVLD)' LIMIT 1), 'cognitive', 'Verbal Descriptions of Visuals', 'Every diagram/chart/image needs detailed verbal explanation', 'moderate', 'critical', ARRAY['Alt text for all images', 'Written explanation beside diagrams', 'Verbal walkthrough of maps']),
((SELECT id FROM disabilities WHERE name = 'Nonverbal Learning Disability (NVLD)' LIMIT 1), 'cognitive', 'Explicit Instructions', 'Never assume they will infer or figure things out - state everything explicitly', 'easy', 'critical', ARRAY['Step-by-step directions', 'No "figure it out" tasks', 'State the obvious']),
((SELECT id FROM disabilities WHERE name = 'Nonverbal Learning Disability (NVLD)' LIMIT 1), 'cognitive', 'Social Scripts', 'Provide written explanations of social situations in reading', 'easy', 'high', ARRAY['Explain character emotions', 'State implicit social rules', 'Clarify sarcasm/jokes']);

-- SCT Accommodations
INSERT INTO disability_accommodations (disability_id, accommodation_type, accommodation_name, description, difficulty_to_implement, impact_level, examples) VALUES
((SELECT id FROM disabilities WHERE name = 'Sluggish Cognitive Tempo (SCT)' LIMIT 1), 'cognitive', 'Frequent Summaries', 'Summarize after every major point to help reorient', 'easy', 'critical', ARRAY['Chapter summaries', 'Section recaps', 'Key point boxes']),
((SELECT id FROM disabilities WHERE name = 'Sluggish Cognitive Tempo (SCT)' LIMIT 1), 'cognitive', 'Simple Clear Language', 'Minimal cognitive load - one idea at a time', 'easy', 'high', ARRAY['Short paragraphs', 'Clear topic sentences', 'Avoid dense text']),
((SELECT id FROM disabilities WHERE name = 'Sluggish Cognitive Tempo (SCT)' LIMIT 1), 'format', 'Built-in Breaks', 'Natural stopping points to prevent overwhelm', 'easy', 'high', ARRAY['Chapter breaks', 'Reflection questions', 'Pause points']);

-- 2e Accommodations
INSERT INTO disability_accommodations (disability_id, accommodation_type, accommodation_name, description, difficulty_to_implement, impact_level, examples) VALUES
((SELECT id FROM disabilities WHERE name = 'Twice Exceptional (2e)' LIMIT 1), 'cognitive', 'Advanced Content + Accommodations', 'College-level concepts with accessibility features', 'moderate', 'critical', ARRAY['Complex ideas in dyslexic font', 'Advanced math with extended time', 'Sophisticated text with audio']),
((SELECT id FROM disabilities WHERE name = 'Twice Exceptional (2e)' LIMIT 1), 'cognitive', 'Enrichment Activities', 'Extension questions and deeper exploration opportunities', 'easy', 'high', ARRAY['Research projects', 'Open-ended questions', 'Advanced applications']),
((SELECT id FROM disabilities WHERE name = 'Twice Exceptional (2e)' LIMIT 1), 'format', 'Multiple Format Options', 'Same advanced content in multiple accessible formats', 'moderate', 'critical', ARRAY['Audio + text', 'Video + transcript', 'Interactive + printable']);

-- Add pipeline status tracking for all 6
INSERT INTO disability_pipeline_status (disability_id, has_blueprints, blueprints_count, blueprints_complete, implementation_status, notes) VALUES
((SELECT id FROM disabilities WHERE name = 'Developmental Language Disorder (DLD)' LIMIT 1), false, 0, false, 'not_started', 'NEW - Need to create 14-step pipeline like existing ones'),
((SELECT id FROM disabilities WHERE name = 'Developmental Coordination Disorder (Dyspraxia)' LIMIT 1), false, 0, false, 'not_started', 'NEW - Need to create 14-step pipeline like existing ones'),
((SELECT id FROM disabilities WHERE name = 'Sensory Processing Disorder (SPD)' LIMIT 1), false, 0, false, 'not_started', 'NEW - Need to create 14-step pipeline like existing ones'),
((SELECT id FROM disabilities WHERE name = 'Nonverbal Learning Disability (NVLD)' LIMIT 1), false, 0, false, 'not_started', 'NEW - Need to create 14-step pipeline like existing ones'),
((SELECT id FROM disabilities WHERE name = 'Sluggish Cognitive Tempo (SCT)' LIMIT 1), false, 0, false, 'not_started', 'NEW - Need to create 14-step pipeline like existing ones'),
((SELECT id FROM disabilities WHERE name = 'Twice Exceptional (2e)' LIMIT 1), false, 0, false, 'not_started', 'NEW - Need to create 14-step pipeline like existing ones');
