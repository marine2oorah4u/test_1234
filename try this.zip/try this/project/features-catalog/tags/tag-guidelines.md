# 🏷️ Feature Tagging Guidelines

## Purpose

This guide explains how to tag each of the 1,244+ features consistently so we can:
- **Filter features** by audience, context, priority, etc.
- **Plan implementation phases** based on priority and complexity
- **Identify dependencies** between features
- **Determine what should be core vs add-on**
- **Estimate effort** realistically

## How to Tag a Feature

### Example Feature Tagged

```json
{
  "id": "CAT02-CODE-057",
  "category": 2,
  "category_label": "Interactive Learning",
  "subcategory": "Practice & Application",
  "name": "In-browser code editor",
  "description": "Monaco-based code editor with syntax highlighting, auto-complete, and multi-language support for writing and testing code directly in lessons",
  "user_story": "As a learner, I want to write and run code without leaving the lesson so that I can immediately practice what I'm learning",
  "acceptance_criteria": [
    "Supports Python, JavaScript, Java, C++, and 10+ other languages",
    "Syntax highlighting and error detection",
    "Auto-save every 5 seconds",
    "Can run code and see output",
    "Can submit for grading",
    "Works on desktop and tablet"
  ],
  "tags": {
    "audience": ["learner", "teacher"],
    "context": ["k12", "higher_ed", "self_directed"],
    "modality": ["code", "interactive"],
    "layer": ["practice_interaction", "content_delivery"],
    "priority": "must_have",
    "complexity": "complex",
    "dependencies": ["CAT02-CODE-064", "CAT19-TECH-950"],
    "technology": ["react", "monaco-editor", "code_execution"],
    "data_sensitivity": ["internal"],
    "accessibility_impact": ["motor", "visual", "universal"],
    "platform": ["web", "desktop"],
    "offline_capable": "partial",
    "add_on_potential": "core"
  },
  "estimated_effort": "3-4 weeks",
  "existing_tools": ["Codecademy IDE", "Replit", "CodeSandbox", "Monaco Editor"],
  "implementation_notes": "Use Monaco editor (VS Code's editor). Need secure code execution sandbox. Consider using Judge0 API or custom Docker containers."
}
```

## Tag Dimension Guidelines

### 1. **audience** (Who uses it?)

**Ask:** "Who directly interacts with or benefits from this feature?"

- `learner` - Students using the platform
- `teacher` - Instructors creating or managing content
- `parent_guardian` - Parents monitoring progress
- `school_admin` - School-level administrators
- `district_admin` - District/system-level admins
- `it_admin` - Technical administrators
- `counselor_guidance` - Academic counselors
- `researcher` - People analyzing learning data
- `curriculum_team` - Content creators and curriculum designers
- `government_ministry` - National/regional education authorities
- `ngo_partner` - NGOs delivering education
- `homeschool_parent` - Parents homeschooling their children
- `tutor_mentor` - One-on-one tutors and mentors
- `content_creator` - Third-party content creators

**Multiple values OK:** Yes (e.g., both learner and teacher)

---

### 2. **context** (Where is this used?)

**Ask:** "What educational environment or setting?"

- `k12` - Primary and secondary education
- `higher_ed` - Universities and colleges
- `corporate_training` - Workplace learning
- `vocational_trade` - Trade schools and apprenticeships
- `nonformal_youth` - Scouts, clubs, community programs
- `homeschool` - Home-based education
- `low_bandwidth` - Limited internet connectivity
- `global_south` - Developing regions
- `urban` - City environments
- `rural_remote` - Remote or rural areas
- `self_directed` - Independent adult learners
- `lifelong_learning` - Continuous adult education

**Multiple values OK:** Yes

---

### 3. **modality** (How is it experienced?)

**Ask:** "What format or medium does the learner interact with?"

- `video` - Video content
- `audio` - Audio/podcast format
- `text` - Written content
- `interactive` - Interactive exercises
- `assessment` - Quizzes, tests, exams
- `code` - Programming/code-based
- `vr` - Virtual reality
- `ar` - Augmented reality
- `sms` - Text messaging
- `chat_app` - WhatsApp, Telegram, etc.
- `print` - Printable materials
- `offline_local_server` - Local server/network
- `hardware_device` - Physical devices (Arduino, etc.)
- `voice` - Voice commands/responses
- `whiteboard` - Digital whiteboard
- `simulation` - Simulations and virtual labs
- `game` - Game-based learning

**Multiple values OK:** Yes

---

### 4. **layer** (What system layer?)

**Ask:** "What part of the platform does this feature belong to?"

- `content_delivery` - Serving lessons, videos, text
- `practice_interaction` - Hands-on practice and exercises
- `assessment_testing` - Quizzes, tests, grading
- `ai_tutor` - AI teaching and tutoring
- `analytics_reporting` - Data analysis and reports
- `admin_ops` - Administrative operations
- `curriculum_authoring` - Creating and editing content
- `credentials_pathways` - Certificates, badges, career paths
- `research_workflow` - Academic research tools
- `governance_compliance` - Legal and compliance
- `infrastructure_platform` - Core technical infrastructure
- `social_collaboration` - Social learning features
- `wellbeing_support` - Student support services
- `maker_labs` - Physical/maker/robotics labs
- `offline_alt_channel` - Alternative delivery methods
- `note_taking` - Note-taking and study tools
- `gamification` - Points, badges, leaderboards
- `accessibility` - Accessibility accommodations
- `integration` - Third-party integrations
- `security_privacy` - Security and privacy features

**Multiple values OK:** Yes

---

### 5. **priority** (When to build?)

**Ask:** "How critical is this feature for launch and user value?"

- `must_have` - **Phase 1** - Absolutely required for MVP/v1
  - Core learning experience
  - Basic platform functionality
  - Legal/compliance requirements

- `should_have` - **Phase 2** - Important but not blocking launch
  - Significant value-add
  - Competitive features
  - Major convenience features

- `nice_to_have` - **Phase 3** - Valuable but can wait
  - Polish and refinement
  - Advanced features
  - Niche use cases

- `future_experimental` - **Phase 4+** - Emerging tech, experimental
  - Cutting-edge technology
  - Unproven concepts
  - Future possibilities

**Multiple values OK:** No (pick one)

---

### 6. **complexity** (How hard to build?)

**Ask:** "How much effort and technical difficulty?"

- `trivial` - Hours (simple UI, basic logic)
- `simple` - 1-3 days (straightforward feature)
- `moderate` - 1-2 weeks (some complexity)
- `complex` - 3-6 weeks (significant work)
- `very_complex` - 2+ months (major undertaking)

**Multiple values OK:** No

---

### 7. **dependencies** (What must exist first?)

**Ask:** "What other features must be built before this one?"

List feature IDs that this feature depends on.

Example: A "Code review by AI" feature depends on:
- In-browser code editor (CAT02-CODE-057)
- AI tutor system (CAT03-AI-141)
- Code execution engine (CAT02-CODE-064)

**Format:** Array of feature IDs

---

### 8. **technology** (What tools/tech needed?)

**Ask:** "What technologies or third-party tools are required?"

- `react` - React framework
- `typescript` - TypeScript
- `supabase` - Supabase backend
- `ai_api` - AI APIs (OpenAI, Claude, etc.)
- `video_streaming` - Video infrastructure
- `webrtc` - Real-time communication
- `websockets` - Live updates
- `pdf_generation` - PDF creation
- `image_processing` - Image manipulation
- `audio_processing` - Audio editing/processing
- `code_execution` - Code sandboxing/execution
- `3d_rendering` - 3D graphics
- `blockchain` - Blockchain tech
- `biometrics` - Biometric authentication
- `iot_devices` - IoT device integration
- `machine_learning` - ML models
- `nlp` - Natural language processing
- `tts` - Text-to-speech
- `stt` - Speech-to-text
- `ocr` - Optical character recognition
- `payment_gateway` - Payment processing

**Multiple values OK:** Yes

---

### 9. **data_sensitivity** (How sensitive is the data?)

**Ask:** "What type of data does this handle?"

- `public` - Publicly available information
- `internal` - Internal platform data
- `confidential` - Sensitive but not regulated
- `pii` - Personally identifiable information
- `educational_records` - FERPA-protected records
- `health_info` - Health-related data
- `financial` - Payment/financial data

**Multiple values OK:** Yes

---

### 10. **accessibility_impact** (Who benefits accessibility-wise?)

**Ask:** "Which disabilities or needs does this address?"

- `visual` - Blind or low vision users
- `hearing` - Deaf or hard of hearing users
- `motor` - Motor impairments
- `cognitive` - Cognitive disabilities
- `reading_level` - Reading difficulties
- `language` - Language barriers
- `universal` - Benefits all users

**Multiple values OK:** Yes

---

### 11. **platform** (Which platforms?)

**Ask:** "Where can this feature be used?"

- `web` - Web browsers
- `ios` - iOS app
- `android` - Android app
- `desktop` - Desktop app
- `smarttv` - Smart TV app
- `smartwatch` - Smartwatch
- `feature_phone` - Basic phones (SMS/USSD)
- `any` - Works everywhere

**Multiple values OK:** Yes

---

### 12. **offline_capable** (Works offline?)

**Ask:** "Can users access this without internet?"

- `yes` - Fully works offline
- `partial` - Some offline functionality
- `no` - Requires internet connection

**Multiple values OK:** No

---

### 13. **add_on_potential** (Core or add-on?)

**Ask:** "Should this be built-in or optional?"

- `core` - Part of the main platform (everyone gets it)
- `optional_addon` - Plugin/extension (users enable if wanted)
- `third_party_integration` - Integration with external tool
- `premium_feature` - Paid upgrade feature

**Multiple values OK:** No

---

## Quick Decision Tree

### Is this feature MUST_HAVE?

**YES if:**
- ✅ Users can't learn without it
- ✅ Platform doesn't work without it
- ✅ Legal/compliance requirement
- ✅ Every competitor has it

**NO if:**
- ❌ Only specific users need it
- ❌ Can be added later without breaking things
- ❌ Nice enhancement but not critical
- ❌ Experimental or unproven

### Should this be CORE or ADDON?

**CORE if:**
- ✅ 80%+ of users will use it
- ✅ Fundamental to the learning experience
- ✅ Hard to separate from platform
- ✅ Security or compliance related

**ADDON if:**
- ✅ Only specific subjects/contexts need it
- ✅ Can be cleanly isolated
- ✅ Third-party tool already does it well
- ✅ Premium/specialized feature

---

## Tagging Process

### Step 1: Basic Info
1. Assign unique ID (format: `CAT##-XXX-###`)
2. Set category (1-29)
3. Write clear name and description
4. Optional: Add user story and acceptance criteria

### Step 2: Apply Tags
1. Start with **priority** (helps organize everything else)
2. Set **audience** (who uses it)
3. Set **context** (where it's used)
4. Set **layer** (what system part)
5. Set **complexity** (how hard to build)
6. Set **add_on_potential** (core vs addon)

### Step 3: Technical Details
1. List **dependencies** (other features needed first)
2. List **technology** (what tools/APIs needed)
3. Set **platform** (where it runs)
4. Set **offline_capable** (works offline?)

### Step 4: Compliance & Impact
1. Set **data_sensitivity** (privacy level)
2. Set **accessibility_impact** (who benefits)

### Step 5: Implementation
1. Set **estimated_effort** (time to build)
2. List **existing_tools** (what's already out there)
3. Add **implementation_notes** (technical considerations)

---

## Examples by Priority

### MUST_HAVE Example
```json
{
  "name": "Video playback with captions",
  "priority": "must_have",
  "complexity": "moderate",
  "add_on_potential": "core",
  "rationale": "Core learning delivery method, legal requirement (accessibility)"
}
```

### SHOULD_HAVE Example
```json
{
  "name": "Spaced repetition flashcards",
  "priority": "should_have",
  "complexity": "complex",
  "add_on_potential": "core",
  "rationale": "Proven learning science, major competitive feature, but platform works without it"
}
```

### NICE_TO_HAVE Example
```json
{
  "name": "3D molecule viewer",
  "priority": "nice_to_have",
  "complexity": "moderate",
  "add_on_potential": "optional_addon",
  "rationale": "Only chemistry/biology courses need it, can use external tools initially"
}
```

### FUTURE_EXPERIMENTAL Example
```json
{
  "name": "Brain-computer interface support",
  "priority": "future_experimental",
  "complexity": "very_complex",
  "add_on_potential": "third_party_integration",
  "rationale": "Emerging tech, very few users have hardware, high risk"
}
```

---

## Common Patterns

### Learning Features (Most are MUST_HAVE)
- Video lessons → `must_have`
- Practice problems → `must_have`
- Quizzes → `must_have`
- Progress tracking → `must_have`

### Social Features (Often SHOULD_HAVE)
- Discussion forums → `should_have`
- Study groups → `should_have`
- Leaderboards → `nice_to_have` (optional)

### Advanced Features (Often NICE_TO_HAVE)
- VR experiences → `nice_to_have` or `future_experimental`
- Complex simulations → `nice_to_have`
- Blockchain credentials → `future_experimental`

### Accessibility Features (Almost Always MUST_HAVE)
- Screen reader support → `must_have`
- Captions → `must_have`
- Keyboard navigation → `must_have`

---

## Next Steps

1. **Tag all 1,244 features** using this schema
2. **Generate reports** by priority, complexity, dependencies
3. **Create implementation roadmap** based on priorities
4. **Identify quick wins** (high value, low complexity)
5. **Design feature blueprints** for complex features
6. **Plan integration patterns** for related features

---

## Tools for Tagging

We'll create:
- JSON database of all tagged features
- Scripts to filter/query features
- Visualization of dependencies
- Implementation timeline based on tags
- Effort estimation rollups
