# Format Blueprint: Nook EPUB Format

## Metadata
- **Format ID**: `25_NOOK`
- **Format Name**: Nook Optimized EPUB
- **Tier**: 7 (Platform-Specific Formats)
- **File Extension**: `.epub`
- **Priority**: Medium (US market, Barnes & Noble)
- **Accessibility Level**: High

---

## Overview

### Purpose
Create an optimized EPUB for Barnes & Noble Nook platform. Nook uses standard EPUB format with some specific requirements and features for optimal display on Nook devices and apps.

### Use Cases
- US bookstore distribution (Barnes & Noble)
- Physical bookstore presence (in-store displays)
- Nook device owners
- Samsung Galaxy device integration
- Educational market (B&N Education)

---

## Platform Overview

### Nook Stats
- **Reach**: Primarily US market
- **Devices**: Nook eReaders, Samsung tablets, iOS, Android, Web
- **Market Share**: #5 globally, formerly #2 in US
- **Parent**: Barnes & Noble (largest US bookstore chain)
- **Unique**: Physical bookstore integration, Samsung partnership
- **Advantage**: In-store promotion opportunities

### Key Advantages
- Physical bookstore presence
- Standard EPUB (no proprietary format)
- In-store promotional opportunities
- Education market (college bookstores)
- Samsung device pre-installation
- 65% royalty rate (high)

---

## Technical Specifications

### Accepted Formats
1. **EPUB 3.0** (Recommended)
2. **EPUB 2.0.1** (Supported)
3. **Fixed-Layout EPUB** (For graphic novels, children's books)

### EPUB Requirements

#### File Structure (Standard EPUB)
```
book.epub
├── mimetype
├── META-INF/
│   └── container.xml
├── OEBPS/
│   ├── content.opf
│   ├── toc.ncx
│   ├── nav.xhtml (EPUB 3)
│   ├── chapters/
│   ├── images/
│   └── styles/
```

#### content.opf Metadata
```xml
<?xml version="1.0" encoding="UTF-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="pub-id">
  <metadata xmlns:dc="http://purl.org/dc/elements/1.1/">

    <!-- Required -->
    <dc:title>Book Title</dc:title>
    <dc:creator>Author Name</dc:creator>
    <dc:identifier id="pub-id">urn:isbn:978-1-234567-89-0</dc:identifier>
    <dc:language>en</dc:language>
    <meta property="dcterms:modified">2025-12-03T00:00:00Z</meta>

    <!-- Highly Recommended -->
    <dc:description>Book description (up to 2000 characters)</dc:description>
    <dc:publisher>Publisher Name</dc:publisher>
    <dc:date>2025-12-03</dc:date>
    <dc:subject>Category</dc:subject>
    <dc:rights>Copyright © 2025 Author Name</dc:rights>

    <!-- Cover -->
    <meta name="cover" content="cover-image"/>

  </metadata>

  <manifest>
    <item id="cover-image" href="images/cover.jpg" media-type="image/jpeg" properties="cover-image"/>
    <item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/>
    <item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>
  </manifest>

  <spine toc="ncx">
    <itemref idref="cover"/>
    <itemref idref="chapter01"/>
  </spine>

  <guide>
    <reference type="cover" title="Cover" href="cover.xhtml"/>
    <reference type="toc" title="Table of Contents" href="toc.xhtml"/>
  </guide>
</package>
```

---

## Nook Specific Optimizations

### 1. Cover Image
**Requirements:**
- **Minimum Size**: 1400px (shortest side)
- **Recommended**: 1600px × 2400px
- **Maximum Size**: 4000px × 4000px
- **Aspect Ratio**: 2:3 (1:1.5)
- **Format**: JPEG (preferred) or PNG
- **File Size**: <2 MB
- **Color**: RGB
- **Resolution**: 300 dpi source

**Nook-Specific:**
- Cover must have visible title and author
- Professional quality (appears in B&N stores)
- No explicit content on cover (store policy)
- Consider grayscale e-ink display

### 2. Supported Features

**EPUB 3 Features Supported:**
- HTML5 and CSS3
- SVG images
- MathML (basic support)
- JavaScript (limited)
- Audio/Video (via HTML5)
- Fixed Layout EPUB

**Limited Support:**
- Complex JavaScript interactions
- Advanced CSS animations
- Some web fonts

### 3. Typography & Fonts

**Embedded Fonts:**
- Nook supports custom fonts
- OTF and TTF formats
- Embed with `@font-face`
- Provide fallback fonts

**System Fonts:**
- Multiple font choices for readers
- Let users override (don't force fonts)

**CSS Example:**
```css
@font-face {
  font-family: "CustomFont";
  src: url("../fonts/CustomFont.otf");
}

body {
  font-family: "CustomFont", Georgia, serif;
  line-height: 1.5;
}
```

### 4. Page Breaks
Use CSS for better control:
```css
h1 {
  page-break-before: always;
}

.chapter {
  page-break-before: always;
}

img {
  page-break-inside: avoid;
}
```

---

## Quality Checklist

### EPUB Validation
- [ ] Passes EPUBCheck 4.0+
- [ ] Cover image embedded properly
- [ ] ToC functional (ncx and nav.xhtml)
- [ ] All internal links work
- [ ] Metadata complete
- [ ] No missing chapters

### Nook Specific
- [ ] Cover 1400px+ minimum
- [ ] Description under 2000 characters
- [ ] ISBN required (for distribution)
- [ ] BISAC categories assigned (up to 3)
- [ ] Age rating set
- [ ] Sample content designated (first 10%)

### Content Quality
- [ ] Images high-resolution (300 dpi source)
- [ ] Equations readable
- [ ] Hyperlinks functional
- [ ] Formatting consistent
- [ ] Tested in Nook Preview tool

### Accessibility
- [ ] Alt text for all images
- [ ] Semantic HTML structure
- [ ] Logical reading order
- [ ] Screen reader compatible
- [ ] Color contrast sufficient

---

## Upload Process

### Step 1: Nook Press Account
**Access**: press.barnesandnoble.com

**Requirements:**
- Free account creation
- Tax information (W-9 for US)
- Banking details for royalties
- ISBN (required for distribution)

### Step 2: Prepare Files
- Validated EPUB file
- Cover image (1600×2400+)
- Book description (up to 2000 characters)
- Author bio
- ISBN-13 (required)

### Step 3: Upload to Nook Press
**Book Information:**
- Title and subtitle
- Author name(s)
- Publisher name
- Description (max 2000 characters)
- Language
- Publication date
- ISBN-13 (required)
- Edition number

**Categories & Keywords:**
- Select up to 3 BISAC categories
- Add up to 5 keywords
- Set age rating (if applicable)
- Adult content flag (if applicable)

**Pricing:**
- Set US price ($0.99-$199.99)
- Automatic pricing for other territories
- Or custom pricing per territory

### Step 4: Preview & Publish
- Preview in Nook Press Previewer
- Test on actual Nook device (recommended)
- Review all metadata
- Submit for publication
- Live within 24-72 hours

---

## Testing Checklist

### Device Testing
- [ ] Nook GlowLight (e-ink device)
- [ ] Nook Tablet
- [ ] Nook app on iOS
- [ ] Nook app on Android
- [ ] Samsung Galaxy (Nook preinstalled)
- [ ] Web reader

### Functionality Testing
- [ ] Table of contents navigation
- [ ] Hyperlinks work
- [ ] Images display correctly
- [ ] Text reflows at different sizes
- [ ] Night mode readable
- [ ] Bookmarks functional
- [ ] Highlights work
- [ ] Search functional
- [ ] Font changes work

---

## Nook Platform Features

### 1. LendMe
- Nook's book lending feature
- Readers can lend books to friends (14 days)
- Publisher can enable/disable
- Helps word-of-mouth marketing

### 2. Nook Readouts
- In-store reading events
- Promotional opportunities
- Connect with local readers

### 3. Barnes & Noble Membership
- B&N members get benefits
- Promotional opportunities for members
- In-store signage possible

### 4. B&N Education
- College bookstore distribution
- Textbook rental program
- Course material integration

### 5. Sample Downloads
- First 10% available as sample
- Designate sample ending point in EPUB
- Critical for conversion

---

## Revenue & Pricing

### Revenue Share
- **65% to Publisher**: List price $2.99-$9.99
- **40% to Publisher**: List price $0.99-$2.98
- **40% to Publisher**: List price $10+
- **B&N keeps**: 35% (or 60%)
- **Payment**: Monthly, $10 minimum
- **Preorders**: Supported

### Pricing Strategy
- **Sweet Spot**: $2.99-$9.99 (65% royalty)
- Competitive pricing vs. Amazon
- Consider B&N member promotions
- Promotional pricing available

---

## AI Model Recommendations

### Metadata Optimization
- **Description Writing**: Claude Sonnet (compelling, concise)
- **Keyword Selection**: GPT-4 (SEO optimization)
- **Category Selection**: Gemini Pro (BISAC matching)

### Quality Assurance
- **EPUB Validation**: Claude Opus (error detection)
- **Preview Testing**: GPT-4 (checklist verification)

---

## Output Structure

### Deliverables
```
nook/
├── book_nook_optimized.epub        # Validated EPUB
├── cover_1600x2400.jpg             # High-res cover
├── book_description.txt            # Marketing copy (2000 char max)
├── metadata.txt                    # All metadata
├── bisac_categories.txt            # 3 categories
├── keywords.txt                    # 5 keywords
└── nook_press_upload_guide.pdf     # Instructions
```

---

## Metadata to Include

```json
{
  "format": "Nook EPUB",
  "epub_version": "3.0",
  "file_size_mb": 13.8,
  "isbn_13": "978-1-234567-89-0",
  "title": "Book Title",
  "subtitle": "Subtitle",
  "author": "Author Name",
  "publisher": "Publisher Name",
  "publication_date": "2025-12-03",
  "language": "en",
  "page_count": 324,
  "edition": "1st Edition",
  "bisac_categories": [
    "EDU029000",
    "COM051010",
    "REF025000"
  ],
  "keywords": [
    "education",
    "programming",
    "reference"
  ],
  "cover_specifications": {
    "width": 1600,
    "height": 2400,
    "format": "JPEG"
  },
  "pricing": {
    "usd": 9.99,
    "royalty_rate": "65%"
  },
  "features": {
    "lendme_enabled": true,
    "sample_percent": 10
  }
}
```

---

## Advantages

1. **Physical Presence**: Barnes & Noble stores
2. **High Royalty**: 65% at $2.99-$9.99 price point
3. **Standard EPUB**: No proprietary format
4. **Education Market**: B&N Education network
5. **In-Store Promotion**: Physical marketing opportunities
6. **LendMe**: Viral book sharing

---

## Limitations

1. **US-Focused**: Limited international reach
2. **Smaller Market Share**: Declining vs. competitors
3. **Device Availability**: Fewer devices than competitors
4. **Feature Support**: Some EPUB 3 features limited

---

## Best Practices

1. **ISBN Required**: Must have ISBN for distribution
2. **Professional Cover**: Appears in physical stores
3. **Pricing Sweet Spot**: $2.99-$9.99 for 65% royalty
4. **Test on Device**: Borrow or buy a Nook for testing
5. **Enable LendMe**: Helps word-of-mouth
6. **In-Store Promotion**: Leverage B&N store presence
7. **Sample Quality**: First 10% is critical

---

## Related Formats

- **04_EPUB_30.md**: Standard EPUB base
- **22_GOOGLE_PLAY_BOOKS.md**: Google Play optimization
- **23_APPLE_BOOKS.md**: Apple Books optimization
- **24_KOBO.md**: Kobo EPUB

---

## Update History
- **2025-12-03**: Initial blueprint created
