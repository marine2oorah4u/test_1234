# Format Blueprint: M4B Audiobook

## Metadata
- **Format ID**: `18_M4B_AUDIOBOOK`
- **Format Name**: M4B Audiobook (Chapter-Marked)
- **Tier**: 5 (Audio Formats)
- **File Extension**: `.m4b`
- **Priority**: High (Apple ecosystem, chapter navigation)
- **Accessibility Level**: High (with proper chapter marks)

---

## Overview

### Purpose
Create a single-file audiobook in M4B (MPEG-4 Audiobook) format with embedded chapter markers. Provides seamless listening experience with bookmarking, chapter navigation, and remembering playback position.

### Use Cases
- Apple Books distribution
- Audible submissions (alternative to AAX)
- iTunes Store audiobooks
- iOS/macOS native playback
- Premium audiobook products
- Single-file convenience
- Chapter-based navigation

---

## Technical Specifications

### Container Format
- **Format**: M4B (MPEG-4 Audio Book)
- **Container**: MP4 container (same as M4A but designated for audiobooks)
- **Codec**: AAC (Advanced Audio Coding)

### Audio Quality

#### Standard Quality
- **Codec**: AAC-LC (Low Complexity)
- **Bitrate**: 64-96 kbps (mono) or 128 kbps (stereo)
- **Sample Rate**: 44.1 kHz or 48 kHz
- **Channels**: Mono (recommended for voice) or Stereo
- **File Size**: ~0.5-1 MB per minute

#### High Quality (Audible Standard)
- **Codec**: AAC-HE (High Efficiency) v1 or v2
- **Bitrate**: 32-64 kbps (HE optimized)
- **Sample Rate**: 22.05 kHz or 44.1 kHz
- **Channels**: Mono
- **File Size**: ~0.25-0.5 MB per minute

#### Premium Quality
- **Codec**: AAC-LC
- **Bitrate**: 128-256 kbps (stereo)
- **Sample Rate**: 48 kHz
- **Channels**: Stereo
- **File Size**: ~1-2 MB per minute

### Key Features
1. **Chapter Markers**: Embedded navigation points
2. **Bookmarking**: Automatic position memory
3. **Album Art**: Embedded cover image
4. **Metadata**: Rich ID3-style tags
5. **DRM Support**: Optional (FairPlay for iTunes)
6. **Single File**: Entire book in one file

---

## File Structure

### M4B Package
```
audiobook.m4b                 # Single file containing:
├── Audio Stream (AAC)        # Compressed audio
├── Chapter Markers           # Navigation points
├── Metadata                  # Book info (atoms)
├── Cover Art (embedded)      # Album artwork
└── Bookmarking Data          # Position tracking
```

### Chapter Marker Structure
```
Chapter 1: Introduction        00:00:00
Chapter 2: Background          00:15:32
Chapter 3: Core Concepts       00:32:18
Chapter 4: Advanced Topics     00:51:45
Chapter 5: Practical Examples  01:12:09
...
```

---

## Production Workflow

### Step 1: Source Audio Preparation
**Starting Point:**
- Individual chapter MP3s (from Format 16 or 17)
- OR complete MP3 audiobook
- High-quality source (192 kbps or better)

### Step 2: Chapter Marker Planning
- List all chapters with titles
- Determine exact start times
- Plan logical break points
- Include front/back matter if applicable
- Verify chapter sequence

### Step 3: Audio Concatenation
**Combine all chapters into single file:**

Using **FFmpeg** (recommended):
```bash
# Create file list
cat > chapters.txt << EOF
file '01_intro.mp3'
file '02_chapter1.mp3'
file '03_chapter2.mp3'
EOF

# Concatenate
ffmpeg -f concat -safe 0 -i chapters.txt \
  -c:a aac -b:a 64k -ar 44100 -ac 1 \
  -metadata title="Book Title" \
  -metadata artist="Author Name" \
  -metadata album="Book Title" \
  -metadata genre="Audiobook" \
  -metadata date="2025" \
  output.m4b
```

### Step 4: Chapter Marker Embedding

**Option A: Using MP4Box**
```bash
# Create chapter file (chapters.txt):
# CHAPTER1=00:00:00.000
# CHAPTER1NAME=Introduction
# CHAPTER2=00:15:32.000
# CHAPTER2NAME=Background

# Add chapters
mp4box -chap chapters.txt output.m4b
```

**Option A: Using MP4v2/mp4chaps**
```bash
# Create chapter file (format):
# 00:00:00.000 Introduction
# 00:15:32.000 Background
# 00:32:18.000 Core Concepts

# Add chapters
mp4chaps --import output.m4b
```

**Option C: Using Chapter Tool for Mac**
- Import M4B file
- Add chapter markers interactively
- Export with chapters

### Step 5: Metadata Embedding

**Essential Metadata (MP4 Atoms):**
```bash
# Using AtomicParsley
AtomicParsley output.m4b \
  --title "Complete Book Title" \
  --artist "Author Name" \
  --album "Book Title" \
  --albumArtist "Author Name" \
  --year "2025" \
  --genre "Audiobook" \
  --stik "Audiobook" \
  --comment "Professional narration" \
  --description "Book description..." \
  --longdesc "Extended description..." \
  --artwork cover.jpg \
  --overWrite
```

**Metadata Fields:**
- `©nam` - Title
- `©ART` - Artist (Author or Narrator)
- `©alb` - Album (Book Title)
- `aART` - Album Artist (Author)
- `©day` - Year
- `©gen` - Genre
- `©cmt` - Comment
- `desc` - Description
- `ldes` - Long Description
- `stik` - Media Kind (set to "Audiobook")
- `covr` - Cover Art

### Step 6: Cover Art Embedding
**Requirements:**
- **Format**: JPEG or PNG
- **Size**: 1400x1400 px minimum (Audible/Apple standard)
- **Aspect Ratio**: 1:1 (square)
- **Resolution**: 72-300 dpi
- **Color**: RGB
- **File Size**: <2 MB

```bash
ffmpeg -i output.m4b -i cover.jpg \
  -map 0:a -map 1:v -c copy -disposition:v:0 attached_pic \
  output_with_cover.m4b
```

### Step 7: Quality Control
- Test playback in Apple Books
- Verify chapter navigation works
- Check cover art displays
- Test bookmarking (close and reopen)
- Validate metadata
- Check audio quality
- Test on iPhone/iPad

---

## Quality Checklist

### Audio Quality
- [ ] No audio artifacts from concatenation
- [ ] Consistent volume throughout
- [ ] Proper chapter transitions (no gaps/overlaps)
- [ ] Bitrate appropriate for content
- [ ] Sample rate consistent
- [ ] Channels appropriate (mono for voice)

### Chapter Markers
- [ ] All chapters marked correctly
- [ ] Chapter titles descriptive
- [ ] Timestamps accurate to the second
- [ ] Front/back matter included if applicable
- [ ] Sequence logical and complete
- [ ] Navigation works in players

### Metadata
- [ ] Title accurate
- [ ] Author name correct
- [ ] Genre set to "Audiobook"
- [ ] Media Kind (stik) set to "Audiobook"
- [ ] Cover art embedded and displays
- [ ] Description comprehensive
- [ ] Year/date included
- [ ] ISBN included (if applicable)

### Functionality
- [ ] Bookmarking works (position saved)
- [ ] Chapter skip forward/back functional
- [ ] Cover art displays in all players
- [ ] Sleep timer works
- [ ] Playback speed adjustable
- [ ] Compatible with iTunes/Apple Books
- [ ] Compatible with Audible app (if targeting)

---

## Platform-Specific Requirements

### Apple Books / iTunes Store
- **Format**: M4B with AAC-LC
- **Bitrate**: 64-128 kbps recommended
- **Sample Rate**: 44.1 kHz
- **Chapters**: Required
- **Cover Art**: 1400x1400 minimum, 3000x3000 preferred
- **Metadata**: Complete
- **File Size**: < 4 GB (practical limit)

### Audible (ACX)
- **Format**: M4B or AAX
- **Bitrate**: 64-128 kbps
- **Sample Rate**: 44.1 kHz or 48 kHz
- **Peak Level**: -3 dB
- **RMS Level**: -18 to -23 dB
- **Chapters**: Strongly recommended
- **Opening Credits**: Required (first 5 seconds)
- **Closing Credits**: Required (last 30 seconds)

### Findaway Voices
- **Format**: M4B accepted
- **Bitrate**: 64-192 kbps
- **Chapters**: Required
- **Cover Art**: Embedded

---

## Tools & Software

### Command Line (Free)
- **FFmpeg**: Audio conversion and concatenation
- **MP4Box**: Chapter marker tools
- **AtomicParsley**: Metadata editing
- **mp4chaps**: Chapter management

### GUI Applications

#### Mac
- **Chapter and Verse** ($9.99) - Chapter editing
- **Audiobook Builder** ($9.99) - Complete M4B creation
- **MakeMKV** (Free) - Conversion tool
- **Music/Books app** - Built-in playback testing

#### Windows
- **Audiobook Converter** - M4B creation
- **mp3DirectCut** - Audio editing
- **Foobar2000** - With M4B plugins

#### Cross-Platform
- **Audacity** (Free) - Audio editing
- **MediaInfo** - Metadata verification
- **VLC Player** - Testing playback

---

## Automation Script Example

### Bash Script for M4B Creation
```bash
#!/bin/bash
# m4b-creator.sh

TITLE="Book Title"
AUTHOR="Author Name"
COVER="cover.jpg"
OUTPUT="${TITLE}.m4b"

# Concatenate chapters
ffmpeg -f concat -safe 0 -i chapters_list.txt \
  -c:a aac -b:a 64k -ar 44100 -ac 1 \
  temp.m4b

# Add metadata and cover
AtomicParsley temp.m4b \
  --title "$TITLE" \
  --artist "$AUTHOR" \
  --album "$TITLE" \
  --albumArtist "$AUTHOR" \
  --year "2025" \
  --genre "Audiobook" \
  --stik "Audiobook" \
  --artwork "$COVER" \
  --overWrite

# Add chapters
mp4chaps --import temp.m4b

# Rename to final
mv temp.m4b "$OUTPUT"

echo "M4B created: $OUTPUT"
```

---

## AI Model Recommendations

### Chapter Planning
- **Chapter Identification**: Claude Sonnet (structure analysis)
- **Chapter Titling**: GPT-4 (descriptive titles)

### Metadata Generation
- **Description Writing**: Gemini Pro (compelling copy)
- **Keyword Selection**: Claude Opus (SEO optimization)

### Quality Assurance
- **Timestamp Verification**: GPT-4 (accuracy check)
- **Metadata Validation**: Claude Sonnet (completeness)

---

## Output Structure

### Primary Output
- **File**: `[BookTitle]_Audiobook.m4b`
- **Size**: 400-800 MB for 8-hour audiobook (64 kbps)

### Additional Files
- `chapter_list.txt` - Chapter titles and times
- `audiobook_metadata.txt` - Complete metadata
- `cover_1400x1400.jpg` - Cover artwork
- `m4b_specifications.pdf` - Technical details

---

## Metadata to Include

```json
{
  "format": "M4B Audiobook",
  "audio_codec": "AAC-LC",
  "audio_quality": {
    "bitrate": "64 kbps",
    "sample_rate": "44.1 kHz",
    "channels": "Mono",
    "container": "MP4"
  },
  "structure": {
    "single_file": true,
    "chapter_markers": 14,
    "bookmarking": true,
    "cover_embedded": true
  },
  "content": {
    "total_runtime": "8:47:22",
    "file_size_mb": 285,
    "chapter_count": 14,
    "narrator_type": "human|ai"
  },
  "compatibility": [
    "Apple Books",
    "iTunes",
    "iOS Books app",
    "macOS Books app",
    "Audible app (with conversion)",
    "VLC Player",
    "Most audiobook players"
  ],
  "distribution": {
    "apple_books_ready": true,
    "audible_compatible": true,
    "drm_free": true
  }
}
```

---

## Advantages

1. **Single File**: Easy to manage and transfer
2. **Chapter Navigation**: Jump between sections easily
3. **Bookmarking**: Automatic position memory
4. **Native Support**: Works perfectly on Apple devices
5. **Smaller Size**: AAC more efficient than MP3
6. **Professional**: Industry-standard format
7. **Embedded Art**: Cover always visible

---

## Limitations

1. **Platform-Specific**: Best on Apple/iOS devices
2. **Limited Tools**: Fewer editing options than MP3
3. **Complexity**: Harder to create than simple MP3
4. **Android**: Variable support (needs specific apps)
5. **DRM**: Some platforms add copy protection

---

## Best Practices

1. **Quality Source**: Start with high-quality audio
2. **Accurate Chapters**: Verify timestamps precisely
3. **Professional Art**: Use high-resolution cover (1400x1400+)
4. **Complete Metadata**: Fill all fields thoroughly
5. **Test Thoroughly**: Check on multiple devices
6. **Backup MP3s**: Keep source files
7. **Silence Management**: Proper gaps between chapters (1-2 sec)
8. **File Naming**: Use clear, descriptive names

---

## Related Formats

- **16_MP3_AUDIOBOOK_HUMAN.md**: Source format (human narrated)
- **17_MP3_AUDIOBOOK_AI.md**: Source format (AI narrated)
- **08_DAISY_30.md**: Alternative structured audio

---

## Update History
- **2025-12-03**: Initial blueprint created
