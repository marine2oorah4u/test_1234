# Format Blueprint: H5P Package

## Metadata
- **Format ID**: `15_H5P_PACKAGE`
- **Format Name**: H5P Interactive Content Package
- **Tier**: 4 (Interactive Formats)
- **File Extension**: `.h5p`
- **Priority**: High (modern interactive content)
- **Accessibility Level**: High (WCAG 2.1 AA)

---

## Overview

### Purpose
Create HTML5-based interactive content using H5P (HTML5 Package) framework. Provides rich, reusable interactive elements that work across devices and can be embedded in multiple platforms (WordPress, Moodle, Canvas, Drupal).

### Use Cases
- Interactive course modules
- Self-paced learning content
- Formative assessments and quizzes
- Interactive videos with questions
- Drag-and-drop exercises
- Flashcard sets
- Interactive presentations
- Timeline visualizations
- 360-degree virtual tours

---

## Technical Specifications

### H5P Version
- **Target**: H5P 1.24 or later
- **Format**: ZIP archive with JSON content

### Package Structure
```
package.h5p (ZIP archive)
├── h5p.json                 # Package metadata
├── content/
│   └── content.json         # Content structure and data
├── images/                  # Media assets
├── videos/
├── audios/
└── libraries/               # H5P libraries (if standalone)
```

### Core H5P Content Types

#### Knowledge Check & Assessment
1. **Multiple Choice**: Single or multi-select questions
2. **Fill in the Blanks**: Text input exercises
3. **Drag and Drop**: Visual matching exercises
4. **Drag the Words**: Sentence completion
5. **Mark the Words**: Text highlighting exercises
6. **True/False**: Binary choice questions
7. **Essay**: Open-ended responses
8. **Quiz (Question Set)**: Combined assessments

#### Interactive Media
9. **Interactive Video**: Videos with embedded questions
10. **Interactive Book**: Multi-page interactive content
11. **Course Presentation**: Slideshow with interactivity
12. **Virtual Tour (360)**: Panoramic explorations
13. **Interactive Images**: Hotspot-based images
14. **Audio Recorder**: Voice response capture

#### Games & Engagement
15. **Memory Game**: Matching card games
16. **Flashcards**: Study card sets
17. **Dialog Cards**: Q&A flashcards
18. **Find the Hotspot**: Image-based treasure hunt
19. **Guess the Answer**: Image-based questions
20. **Personality Quiz**: Branching quiz paths

#### Visualization & Structure
21. **Timeline**: Interactive chronology
22. **Chart**: Data visualization
23. **Accordion**: Collapsible content sections
24. **Image Slider**: Gallery navigation
25. **Collage**: Multi-image layouts

---

## Conversion Workflow

### Step 1: Content Analysis
- Identify suitable H5P content types for each section
- Map book chapters to H5P structures
- Plan interactive element placement
- Design assessment strategy

### Step 2: Content Type Selection
**For Different Content:**
- **Text-heavy chapters** → Interactive Book
- **Concept explanations** → Course Presentation
- **Practice exercises** → Quiz (Question Set)
- **Key terms** → Flashcards or Dialog Cards
- **Processes/Events** → Timeline
- **Complex topics** → Interactive Video with embedded questions

### Step 3: H5P Creation
- Create H5P content using H5P editor
- Design visual layouts and interactions
- Add media assets (images, videos, audio)
- Configure feedback and scoring
- Set accessibility options

### Step 4: Content Structuring
- Organize multiple H5P elements
- Create navigation between elements
- Design progressive difficulty
- Add help text and instructions

### Step 5: Package Export
- Export from H5P editor
- Verify .h5p file integrity
- Test in target platform
- Optimize file size

### Step 6: Testing & Validation
- Test in standalone H5P viewer
- Test in WordPress H5P plugin
- Test in Moodle H5P activity
- Verify mobile responsiveness
- Check accessibility features

---

## Quality Checklist

### Technical Requirements
- [ ] Valid h5p.json metadata
- [ ] content.json properly structured
- [ ] All media assets included
- [ ] File size optimized (<100MB ideal)
- [ ] Compatible with H5P 1.24+
- [ ] Works in standalone viewer
- [ ] Works in WordPress plugin
- [ ] Works in Moodle activity

### Content Requirements
- [ ] All chapters converted
- [ ] Interactive elements functional
- [ ] Clear instructions provided
- [ ] Feedback messages helpful
- [ ] Navigation intuitive
- [ ] Progress tracking works
- [ ] Scoring accurate (if applicable)

### Accessibility Requirements
- [ ] WCAG 2.1 AA compliant
- [ ] Keyboard navigation functional
- [ ] Screen reader compatible
- [ ] Alt text for all images
- [ ] Captions for videos
- [ ] Color contrast sufficient (4.5:1)
- [ ] Focus indicators visible
- [ ] ARIA labels appropriate

### User Experience
- [ ] Responsive on all devices
- [ ] Touch-friendly on mobile/tablet
- [ ] Loading times acceptable
- [ ] Visual design consistent
- [ ] Error messages clear
- [ ] Help documentation available

---

## Sample h5p.json

```json
{
  "title": "Book Title - Interactive Course",
  "language": "en",
  "mainLibrary": "H5P.InteractiveBook",
  "embedTypes": ["iframe"],
  "license": "CC BY-SA",
  "defaultLanguage": "en",
  "preloadedDependencies": [
    {
      "machineName": "H5P.InteractiveBook",
      "majorVersion": 1,
      "minorVersion": 5
    },
    {
      "machineName": "H5P.Quiz",
      "majorVersion": 1,
      "minorVersion": 4
    }
  ]
}
```

---

## Sample content.json (Interactive Book)

```json
{
  "chapters": [
    {
      "title": "Chapter 1: Introduction",
      "params": {
        "content": [
          {
            "library": "H5P.AdvancedText 1.1",
            "params": {
              "text": "<h2>Welcome to Chapter 1</h2><p>This chapter introduces...</p>"
            }
          },
          {
            "library": "H5P.Image 1.1",
            "params": {
              "file": {"path": "images/chapter1-intro.jpg"},
              "alt": "Diagram showing key concepts"
            }
          },
          {
            "library": "H5P.QuestionSet 1.17",
            "params": {
              "questions": [
                {
                  "library": "H5P.MultiChoice 1.14",
                  "params": {
                    "question": "What is the main topic?",
                    "answers": [
                      {"text": "Option A", "correct": false},
                      {"text": "Option B", "correct": true},
                      {"text": "Option C", "correct": false}
                    ],
                    "behaviour": {
                      "enableRetry": true,
                      "showSolutionsRequiresInput": true
                    }
                  }
                }
              ]
            }
          }
        ]
      }
    }
  ]
}
```

---

## Recommended Content Types by Section

### For Textbook Chapters
- **Main Content**: Interactive Book (multi-page)
- **Supplemental**: Course Presentation (slideshows)

### For Exercises
- **Multiple Choice**: Quiz (Question Set)
- **Practical**: Drag and Drop, Fill in the Blanks
- **Open-ended**: Essay questions

### For Vocabulary
- **Study Tools**: Flashcards, Dialog Cards
- **Practice**: Mark the Words, Drag the Words

### For Concepts
- **Visual**: Interactive Images with hotspots
- **Sequential**: Timeline
- **Comparative**: Image Slider

### For Videos (if included)
- **Enhanced Videos**: Interactive Video with embedded questions

---

## AI Model Recommendations

### Primary Models
- **Content Type Selection**: Claude Sonnet (pedagogical decisions)
- **Quiz Generation**: GPT-4 (question creation)
- **Interactive Design**: Gemini Pro (UX planning)
- **Accessibility**: Claude Opus (WCAG compliance)

### Content Creation Models
- **Text Content**: Gemini Pro (writing)
- **Question Writing**: Claude Sonnet (assessment design)
- **Feedback Messages**: GPT-4 (constructive feedback)

---

## Output Structure

### Primary Output
- **File**: `[BookTitle]_Interactive.h5p`
- **Size**: Optimized (compress media)
- **Type**: Standalone H5P package

### Additional Files
- `H5P_Installation_Guide.pdf` - Platform setup
- `H5P_User_Guide.pdf` - Learner instructions
- `Content_Inventory.xlsx` - List of all H5P elements

---

## Metadata to Include

```json
{
  "format": "H5P Package",
  "h5p_version": "1.24",
  "main_content_type": "H5P.InteractiveBook",
  "total_chapters": 12,
  "interactive_elements": {
    "quizzes": 8,
    "flashcards": 5,
    "interactive_videos": 3,
    "drag_and_drop": 6,
    "timelines": 2
  },
  "total_questions": 95,
  "media_assets": {
    "images": 47,
    "videos": 8,
    "audio": 3
  },
  "accessibility": "WCAG 2.1 AA",
  "mobile_optimized": true,
  "file_size_mb": 67.2,
  "compatible_platforms": [
    "WordPress (H5P Plugin)",
    "Moodle (H5P Activity)",
    "Canvas (LTI)",
    "Drupal (H5P Module)",
    "Standalone H5P Viewer"
  ]
}
```

---

## Advantages

1. **Rich Interactivity**: 40+ content types available
2. **Platform Independent**: Works in multiple LMS/CMS
3. **Mobile Friendly**: Fully responsive
4. **Accessible**: Built-in WCAG support
5. **Reusable**: Content can be exported/imported
6. **Open Source**: No licensing costs
7. **Modern**: HTML5, no Flash required
8. **Trackable**: Integrates with xAPI for analytics

---

## Best Practices

1. **Progressive Complexity**: Start simple, build up
2. **Varied Content Types**: Mix different interactions
3. **Clear Instructions**: Explain how to interact
4. **Immediate Feedback**: Provide instant responses
5. **Mobile First**: Design for smallest screens
6. **Optimize Media**: Compress images and videos
7. **Test Accessibility**: Use screen reader
8. **Chunking**: Break content into digestible pieces

---

## Platform Integration

### WordPress
```php
// Shortcode: [h5p id="123"]
// Plugin: H5P by Joubel
```

### Moodle
- Add as "H5P activity"
- Supports grade passback
- xAPI tracking available

### Canvas
- Install via LTI
- Use H5P.com or self-hosted

### Standalone
- Use H5P standalone player
- Embed in static HTML pages

---

## Related Formats

- **12_SCORM_PACKAGE.md**: LMS-specific interactivity
- **13_XAPI_TIN_CAN.md**: Advanced tracking
- **14_INTERACTIVE_PDF.md**: Offline interactivity

---

## Update History
- **2025-12-03**: Initial blueprint created
