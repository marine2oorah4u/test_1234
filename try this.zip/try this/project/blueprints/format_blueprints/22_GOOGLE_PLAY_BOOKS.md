# Format Blueprint: Google Play Books Format

## Metadata
- **Format ID**: `22_GOOGLE_PLAY_BOOKS`
- **Format Name**: Google Play Books Optimized EPUB
- **Tier**: 7 (Platform-Specific Formats)
- **File Extension**: `.epub`
- **Priority**: High (major platform, Android reach)
- **Accessibility Level**: High (strong accessibility support)

---

## Overview

### Purpose
Create an optimized EPUB specifically formatted for Google Play Books with platform-specific features, metadata enrichment, and compatibility with Google's reading experience across Android, iOS, and web.

### Use Cases
- Android ecosystem distribution
- Chromebook educational materials
- Google Classroom integration
- Global audience reach (190+ countries)
- Cross-device sync (Google account)
- Family Library sharing

---

## Platform Overview

### Google Play Books Stats
- **Reach**: Available in 190+ countries
- **Devices**: Android, iOS, Web, Chromebooks
- **Market Share**: #2 ebook platform globally
- **Features**: Cloud storage, family sharing, note sync
- **Integration**: Google Classroom, Google Drive

### Key Advantages
- Massive Android user base
- Strong educational market presence
- Excellent international reach
- No proprietary format (uses standard EPUB)
- Good revenue share (52% to publisher)

---

## Technical Specifications

### Accepted Formats
1. **EPUB 3.0.1** (Recommended)
2. **EPUB 2.0.1** (Supported)
3. **PDF** (Supported but not recommended for reflowable content)

### EPUB Requirements

#### File Structure (Standard EPUB)
```
book.epub (ZIP archive)
├── mimetype                    # Must be first, uncompressed
├── META-INF/
│   └── container.xml          # Points to OPF file
├── OEBPS/
│   ├── content.opf            # Package document
│   ├── toc.ncx                # Navigation (EPUB 2)
│   ├── nav.xhtml              # Navigation (EPUB 3)
│   ├── chapter01.xhtml        # Content files
│   ├── stylesheet.css         # Styles
│   └── images/                # Media assets
```

#### content.opf Metadata
```xml
<?xml version="1.0" encoding="UTF-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="3.0">
  <metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
    <!-- Required -->
    <dc:title>Complete Book Title</dc:title>
    <dc:creator>Author Name</dc:creator>
    <dc:identifier id="pub-id">ISBN-13-number</dc:identifier>
    <dc:language>en</dc:language>
    <meta property="dcterms:modified">2025-12-03T00:00:00Z</meta>

    <!-- Highly Recommended for Google Play -->
    <dc:description>Compelling book description (max 4000 chars)</dc:description>
    <dc:publisher>Publisher Name</dc:publisher>
    <dc:date>2025-12-03</dc:date>
    <dc:subject>Category1</dc:subject>
    <dc:subject>Category2</dc:subject>
    <dc:rights>Copyright © 2025 Author Name. All rights reserved.</dc:rights>

    <!-- Cover Image -->
    <meta name="cover" content="cover-image"/>

    <!-- Google Play Specific (Optional) -->
    <meta property="belongs-to-collection" id="series">Series Name</meta>
    <meta refines="#series" property="collection-type">series</meta>
    <meta refines="#series" property="group-position">1</meta>
  </metadata>

  <manifest>
    <item id="cover-image" href="images/cover.jpg" media-type="image/jpeg" properties="cover-image"/>
    <item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/>
    <item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>
    <!-- More items... -->
  </manifest>

  <spine toc="ncx">
    <itemref idref="cover"/>
    <itemref idref="chapter01"/>
    <!-- More itemrefs... -->
  </spine>
</package>
```

---

## Google Play Specific Optimizations

### 1. Cover Image
**Requirements:**
- **Format**: JPEG or PNG
- **Minimum Size**: 1400px (shortest side)
- **Recommended**: 1600px × 2560px or 2400px × 3840px
- **Aspect Ratio**: 1:1.5 to 1:1.6 (portrait)
- **File Size**: <10 MB
- **Color**: RGB (not CMYK)
- **Content**: Title and author visible, no excessive text

**Best Practices:**
- High-resolution for Retina/high-DPI displays
- Professional design
- Readable at thumbnail size (100px)
- Avoid pure white or black backgrounds

### 2. Book Description
**Guidelines:**
- **Length**: 50-4000 characters
- **Format**: HTML basic tags supported: `<p>`, `<b>`, `<i>`, `<br>`
- **Structure**:
  - Hook (first 150 characters visible in search)
  - Book overview (2-3 paragraphs)
  - Key topics/chapters
  - Target audience
  - Author credentials
- **SEO**: Include relevant keywords naturally
- **No Marketing Speak**: Avoid "Best seller!", excessive punctuation

### 3. Categories (BISAC Codes)
**Selection:**
- Choose 1-3 relevant BISAC categories
- Primary category most important (affects discovery)
- Use specific subcategories when possible

**Examples:**
- EDU029010 - Education / Teaching Methods & Materials / Mathematics
- COM051010 - Computers / Programming / Algorithms
- BUS053000 - Business & Economics / Entrepreneurship

### 4. Search Keywords
**Optimization:**
- Not visible metadata in EPUB, set in Google Play Console
- Choose 5-7 relevant keywords
- Think: "What would readers search for?"
- Include synonyms, related topics
- Avoid: Author name, title (already indexed)

### 5. Table of Contents
**Requirements:**
- Both `toc.ncx` (EPUB 2) and `nav.xhtml` (EPUB 3)
- Clear, hierarchical structure
- Includes all chapters and major sections
- Front matter (intro, preface) included
- Back matter (appendix, glossary) included

### 6. Fonts
**Embedded Fonts:**
- Optional (Google Play has system fonts)
- If embedded, use WOFF or OTF
- Include license rights for embedding
- Fallback fonts in CSS

**CSS Font Stack:**
```css
body {
  font-family: "Custom Font", Georgia, serif;
  line-height: 1.5;
}
```

---

## Quality Checklist

### EPUB Validation
- [ ] Passes EPUBCheck 4.0+ with no errors
- [ ] All internal links functional
- [ ] All images display correctly
- [ ] Table of contents complete
- [ ] Metadata complete (title, author, ISBN, description)
- [ ] Cover image properly embedded
- [ ] EPUB file size <2 GB (practical limit)

### Google Play Specific
- [ ] Cover image 1400px+ (shortest side)
- [ ] Cover aspect ratio 1:1.5 to 1:1.6
- [ ] Description 50-4000 characters
- [ ] BISAC categories selected (1-3)
- [ ] Language correctly set
- [ ] ISBN-13 included (if available)
- [ ] Copyright information included

### Content Quality
- [ ] No missing chapters or sections
- [ ] Images high-resolution (300 dpi sources)
- [ ] No typos or formatting errors
- [ ] Hyperlinks working
- [ ] Footnotes/endnotes functional
- [ ] Equations readable (SVG or high-res PNG)

### Accessibility
- [ ] All images have alt text
- [ ] Semantic HTML (h1, h2, p, etc.)
- [ ] Logical reading order
- [ ] Table headers defined
- [ ] Language of content declared
- [ ] Color contrast sufficient

---

## Upload Process

### Step 1: Prepare Files
- Final EPUB file (validated with EPUBCheck)
- Cover image (separate JPEG, 1600×2560+)
- Book description (text or HTML)
- Author bio
- ISBN (if applicable)

### Step 2: Google Play Books Partner Center
**Access**: play.google.com/books/publish

**Required Information:**
- Book title and subtitle
- Author name(s)
- Description
- Language
- Publication date
- ISBN (optional but recommended)
- BISAC categories
- Age rating (if applicable)
- Geographic availability

### Step 3: Upload EPUB
- Use "Add new book" or "Upload books" tool
- Upload EPUB file (drag and drop or browse)
- System validates file automatically
- Fix any errors reported
- Preview in Google Play Books reader

### Step 4: Pricing & Distribution
**Pricing Options:**
- Free
- Fixed price (set per country)
- Dynamic pricing (Google suggests prices)

**Distribution:**
- Select countries (up to 190+)
- Set availability date
- Choose sales regions

### Step 5: Review & Publish
- Preview on web, Android, iOS
- Check formatting, images, ToC
- Verify metadata display
- Submit for review (1-3 days typically)
- Monitor publication status

---

## Testing Checklist

### Preview Testing
- [ ] Preview in Google Play Books web reader
- [ ] Test on Android device (phone)
- [ ] Test on Android tablet
- [ ] Test on Chromebook
- [ ] Test on iOS (Google Play Books app)

### Functionality Testing
- [ ] Table of contents navigation works
- [ ] Hyperlinks functional (internal and external)
- [ ] Images load and display correctly
- [ ] Text reflows properly at different sizes
- [ ] Bookmarks and highlights work
- [ ] Search within book works
- [ ] Text-to-speech reads correctly

---

## Platform Features to Leverage

### Google Play Books Features
1. **Family Library**: Share with up to 5 family members
2. **Google Classroom**: Direct assignment to students
3. **Cloud Storage**: Access across all devices
4. **Offline Reading**: Download for offline access
5. **Note Syncing**: Notes sync across devices
6. **Dictionary**: Built-in dictionary lookup
7. **Translation**: In-app translation
8. **Reading Statistics**: Track reading progress

### Marketing Opportunities
- Google Play Books promotional programs
- Google Ads for books
- Cross-promotion with Android apps
- YouTube book trailers (link in description)

---

## Revenue & Pricing

### Revenue Share
- **Publisher receives**: 52% of list price (after local taxes)
- **Google keeps**: 48%
- **Payment**: Monthly, $10 minimum threshold
- **Currencies**: Local currency by country

### Pricing Strategy
- Research competitor pricing
- Consider dynamic pricing (Google adjusts based on market)
- Promotional pricing (temporary discounts)
- Bundle with other books (series)

---

## AI Model Recommendations

### Metadata Optimization
- **Description Writing**: Claude Sonnet (compelling copy)
- **Keyword Selection**: GPT-4 (SEO optimization)
- **Category Selection**: Gemini Pro (BISAC matching)

### Quality Assurance
- **EPUB Validation**: Claude Opus (error detection)
- **Preview Testing**: GPT-4 (checklist verification)

---

## Output Structure

### Deliverables
```
google_play_books/
├── book_optimized_google_play.epub     # Optimized EPUB
├── cover_1600x2560.jpg                 # High-res cover
├── cover_2400x3840.jpg                 # Ultra-high-res cover
├── book_description.txt                # HTML description
├── metadata.txt                        # All metadata fields
├── bisac_categories.txt                # Selected categories
├── keywords.txt                        # SEO keywords
└── upload_checklist.pdf                # Step-by-step guide
```

---

## Metadata to Include

```json
{
  "format": "Google Play Books EPUB",
  "epub_version": "3.0.1",
  "file_size_mb": 15.3,
  "isbn_13": "978-1-234567-89-0",
  "title": "Complete Book Title",
  "subtitle": "Subtitle if applicable",
  "author": "Author Name",
  "publisher": "Publisher Name",
  "publication_date": "2025-12-03",
  "language": "en",
  "page_count": 324,
  "bisac_categories": [
    "EDU029000 - Education / Teaching Methods",
    "COM051010 - Computers / Programming"
  ],
  "keywords": [
    "programming",
    "education",
    "algorithms",
    "computer science",
    "software development"
  ],
  "cover_specifications": {
    "width": 1600,
    "height": 2560,
    "format": "JPEG",
    "aspect_ratio": "1:1.6"
  },
  "pricing": {
    "usd": 19.99,
    "strategy": "dynamic"
  },
  "distribution": {
    "countries": 190,
    "family_library": true,
    "google_classroom": true
  }
}
```

---

## Advantages

1. **Massive Reach**: 190+ countries, billions of Android users
2. **Standard Format**: Uses EPUB (no proprietary format)
3. **Educational Market**: Strong Google Classroom integration
4. **Revenue Share**: 52% is competitive
5. **No DRM Required**: Optional DRM
6. **Family Sharing**: Built-in sharing features
7. **Global Discovery**: Google Search integration

---

## Best Practices

1. **High-Quality Cover**: Invest in professional design
2. **SEO Description**: First 150 characters crucial
3. **Complete Metadata**: Fill every field
4. **Test Thoroughly**: Preview on multiple devices
5. **Monitor Reviews**: Respond to reader feedback
6. **Update Regularly**: Publish corrected editions
7. **Leverage Classroom**: Market to educators
8. **International**: Consider translations

---

## Common Issues & Solutions

### Issue: EPUB validation errors
**Solution**: Run EPUBCheck, fix all errors before upload

### Issue: Cover image rejected
**Solution**: Ensure 1400px minimum, correct aspect ratio

### Issue: Description not displaying correctly
**Solution**: Use only basic HTML tags, test preview

### Issue: Table of contents missing
**Solution**: Include both toc.ncx and nav.xhtml

### Issue: Low discoverability
**Solution**: Optimize keywords, categories, and description

---

## Related Formats

- **04_EPUB_30.md**: Standard EPUB base format
- **23_APPLE_BOOKS.md**: Apple Books optimization
- **24_KOBO.md**: Kobo-specific EPUB
- **25_NOOK.md**: Nook-specific EPUB

---

## Update History
- **2025-12-03**: Initial blueprint created
