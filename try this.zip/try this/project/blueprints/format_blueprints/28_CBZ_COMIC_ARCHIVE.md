# Format Blueprint: CBZ Comic Archive Format

## Metadata
- **Format ID**: `28_CBZ_COMIC_ARCHIVE`
- **Format Name**: CBZ/CBR Comic Book Archive
- **Tier**: 8 (Advanced/Specialized Formats)
- **File Extension**: `.cbz` (ZIP) or `.cbr` (RAR)
- **Priority**: Low-Medium (visual/graphic-heavy books)
- **Accessibility Level**: Low (image-based, not screen reader friendly)

---

## Overview

### Purpose
Create a comic book archive format for highly visual, image-based books. Each page is a full-page image displayed sequentially. Ideal for graphic novels, illustrated children's books, visual guides, and manga-style educational content.

### Use Cases
- Graphic novels and comics
- Illustrated children's books (fixed layout)
- Visual step-by-step guides (cooking, crafts, DIY)
- Art books and portfolios
- Manga and webtoons
- Photo books
- Infographic collections
- Visual timelines
- Architectural drawings
- Technical diagrams (engineering, blueprints)

---

## Technical Specifications

### File Format
- **CBZ**: ZIP archive containing images
- **CBR**: RAR archive containing images (less common)
- **CB7**: 7z archive containing images (rare)

**Recommendation:** Use CBZ (ZIP) for maximum compatibility

### Archive Structure
```
book.cbz (ZIP archive)
├── 000_cover.jpg
├── 001_page_01.jpg
├── 002_page_02.jpg
├── 003_page_03.jpg
├── ...
├── 150_page_150.jpg
└── [Optional] ComicInfo.xml
```

### Image Specifications

#### Standard Quality
- **Format**: JPEG (photos, complex art) or PNG (text, simple graphics)
- **Resolution**: 1200px - 1600px (height for portrait)
- **DPI**: 150-300 dpi
- **Color**: RGB, 8-bit
- **Compression**: 80-90% quality (JPEG)

#### High Quality (Digital Only)
- **Resolution**: 2000px - 3000px (height)
- **DPI**: 300 dpi
- **Format**: PNG (lossless for text/diagrams)
- **File Size**: 1-5 MB per page

#### Web/Mobile Optimized
- **Resolution**: 800px - 1200px (height)
- **DPI**: 72-150 dpi
- **Format**: JPEG
- **File Size**: 200-500 KB per page

### Aspect Ratios
- **Portrait (most common)**: 2:3 (e.g., 1200×1800)
- **Square**: 1:1 (e.g., 1500×1500)
- **Landscape**: 3:2 or 16:9
- **Webtoon/Scroll**: Variable height, fixed width (800px)

---

## File Naming Convention

### Sequential Numbering
```
000_cover.jpg          # Cover (always first)
001_title_page.jpg
002_copyright.jpg
003_chapter_01.jpg
004_chapter_01.jpg
...
150_back_cover.jpg
```

**Rules:**
- Zero-padded numbers (001, 002, not 1, 2)
- Ensures correct alphabetical sorting
- Descriptive suffixes optional
- Consistent image format throughout

---

## ComicInfo.xml (Metadata)

### Standard Metadata File
```xml
<?xml version="1.0"?>
<ComicInfo xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
           xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <Title>Book Title</Title>
  <Series>Series Name</Series>
  <Number>1</Number>
  <Count>5</Count>
  <Volume>1</Volume>
  <Summary>Book description and summary</Summary>
  <Notes>Additional notes about this edition</Notes>
  <Year>2025</Year>
  <Month>12</Month>
  <Writer>Author Name</Writer>
  <Penciller>Illustrator Name</Penciller>
  <Inker>Inker Name</Inker>
  <Colorist>Colorist Name</Colorist>
  <Letterer>Letterer Name</Letterer>
  <CoverArtist>Cover Artist Name</CoverArtist>
  <Editor>Editor Name</Editor>
  <Publisher>Publisher Name</Publisher>
  <Imprint>Imprint Name</Imprint>
  <Genre>Educational, Non-Fiction</Genre>
  <Tags>programming, tutorial, illustrated</Tags>
  <Web>https://example.com/book</Web>
  <PageCount>150</PageCount>
  <LanguageISO>en</LanguageISO>
  <Format>CBZ</Format>
  <BlackAndWhite>No</BlackAndWhite>
  <Manga>No</Manga>
  <Characters></Characters>
  <Teams></Teams>
  <Locations></Locations>
  <ScanInformation>Digital Original</ScanInformation>
  <StoryArc>Complete Course</StoryArc>
  <SeriesGroup>Programming Fundamentals</SeriesGroup>
  <AgeRating>Everyone</AgeRating>
  <Pages>
    <Page Image="0" Type="FrontCover"/>
    <Page Image="1"/>
    <Page Image="2"/>
    <!-- ... -->
    <Page Image="150" Type="BackCover"/>
  </Pages>
</ComicInfo>xml>
```

---

## Production Workflow

### Step 1: Page Design
**Software Options:**
- Adobe InDesign (professional layout)
- Adobe Illustrator (vector graphics)
- Photoshop (image editing)
- Procreate (iPad illustration)
- Clip Studio Paint (manga/comics)
- Canva (templates)

**Page Design Guidelines:**
- **Margins**: 0.25" safe zone from edges
- **Text Size**: 14pt minimum for readability
- **Contrast**: High contrast for legibility
- **Visual Flow**: Left-to-right, top-to-bottom (Western)
- **Right-to-left for manga**: Reverse flow

### Step 2: Export Pages as Images
**Export Settings:**
- One image per page
- Sequential naming (001, 002, 003...)
- Consistent dimensions (e.g., all 1200×1800)
- JPEG 85-90% quality or PNG
- RGB color mode
- Embed color profile (sRGB)

### Step 3: Optimize Images
```bash
# Batch resize to 1200px height (ImageMagick)
mogrify -resize x1200 -quality 85 *.jpg

# Convert PNG to JPEG (if needed)
mogrify -format jpg *.png

# Optimize JPEG file size
jpegoptim --max=85 *.jpg
```

### Step 4: Create ComicInfo.xml
- Use template or metadata editor
- Fill all relevant fields
- Include page count and page types
- Save as ComicInfo.xml

### Step 5: Create CBZ Archive
**Using Command Line (Recommended):**
```bash
# Create CBZ (ZIP with .cbz extension)
zip -r book.cbz *.jpg ComicInfo.xml

# Or if files in folder:
cd book_pages/
zip -r ../book.cbz *
```

**Using GUI:**
- Windows: Select all files → Send to → Compressed folder → Rename .zip to .cbz
- Mac: Select all files → Right-click → Compress → Rename to .cbz
- 7-Zip: Add to archive → Format: ZIP → Rename to .cbz

### Step 6: Test & Validate
**Test in Comic Readers:**
- CDisplayEx (Windows)
- ComicRack (Windows)
- Chunky (iOS)
- Perfect Viewer (Android)
- Panels (Mac)
- Calibre (cross-platform)
- Web-based: Comic Reader (browser extension)

---

## Quality Checklist

### Image Quality
- [ ] All pages same dimensions
- [ ] Consistent resolution (1200-1600px height)
- [ ] JPEG quality 80-90% (or PNG lossless)
- [ ] No pixelation or artifacts
- [ ] Color consistent across pages
- [ ] Text readable at actual size

### File Organization
- [ ] Pages numbered sequentially (001, 002...)
- [ ] Cover is page 000 or 001
- [ ] No missing page numbers
- [ ] All images in root of archive (no subfolders)
- [ ] ComicInfo.xml included
- [ ] No extraneous files

### Metadata
- [ ] ComicInfo.xml valid XML
- [ ] Title and author filled
- [ ] Page count accurate
- [ ] Genre/tags appropriate
- [ ] Language specified
- [ ] Year/date included

### Reading Experience
- [ ] Pages display in correct order
- [ ] Cover displays first
- [ ] Page transitions smooth
- [ ] Text legible on mobile devices
- [ ] Navigation intuitive
- [ ] File size reasonable (<500MB ideal)

---

## Comic Readers (Software)

### Desktop
- **CDisplayEx** (Windows) - Popular, feature-rich
- **ComicRack** (Windows) - Library management
- **Panels** (Mac) - Beautiful interface
- **Calibre** (All) - Ebook manager with CBZ support
- **Sumatra PDF** (Windows) - Lightweight

### Mobile (iOS)
- **Chunky Comic Reader** - Best for iOS
- **ComicFlow** - Free, local files
- **YACReader** - Cross-platform sync

### Mobile (Android)
- **Perfect Viewer** - Highly customizable
- **Tachiyomi** - Manga reader (supports CBZ)
- **Moon+ Reader** - Multi-format
- **CDisplayEx** - Android version

### Web-Based
- **Comic Reader** - Browser extension (Chrome, Firefox)
- **Kimchi Reader** - Web app
- **ACBR** - Online reader

---

## Use Case Examples

### 1. Illustrated Children's Book
```
kids_book.cbz
├── 000_cover.jpg           (Full-page illustration)
├── 001_title_page.jpg
├── 002_page_01.jpg         (Large text + illustration)
├── 003_page_02.jpg
...
```

### 2. Visual Step-by-Step Guide (Cooking)
```
cooking_guide.cbz
├── 000_cover.jpg
├── 001_ingredients.jpg     (Ingredient photos + list)
├── 002_step_01.jpg         (Photo + numbered instruction)
├── 003_step_02.jpg
...
├── 020_final_dish.jpg
```

### 3. Infographic Collection
```
infographics.cbz
├── 000_cover.jpg
├── 001_infographic_01.jpg  (Full-page infographic)
├── 002_infographic_02.jpg
...
```

### 4. Educational Manga
```
edu_manga.cbz
├── 000_cover.jpg
├── 001_chapter_01.jpg      (Manga-style panel layout)
├── 002_chapter_01.jpg
...
```

---

## AI Model Recommendations

### Image Generation
- **Illustrations**: DALL-E 3, Midjourney, Stable Diffusion
- **Diagrams**: GPT-4 (SVG generation) + rendering
- **Layout Design**: Claude Sonnet (composition guidance)

### Text/Captions
- **Dialogue**: Claude Opus (natural conversation)
- **Captions**: GPT-4 (concise descriptions)
- **Translation**: Gemini Pro (manga/comics)

### Quality Assurance
- **Image Validation**: Claude Sonnet (check consistency)
- **Metadata**: GPT-4 (ComicInfo.xml generation)

---

## Output Structure

### Deliverables
```
cbz_archive/
├── book.cbz                        # Final CBZ file
├── book_pages/                     # Source images (backup)
│   ├── 000_cover.jpg
│   ├── 001_page_01.jpg
│   └── ...
├── ComicInfo.xml                   # Metadata file
├── thumbnail.jpg                   # Cover thumbnail (300x450)
└── creation_notes.md               # Production notes
```

---

## Metadata to Include

```json
{
  "format": "CBZ Comic Book Archive",
  "container": "ZIP",
  "total_pages": 150,
  "file_size_mb": 285,
  "image_format": "JPEG",
  "image_dimensions": "1200x1800",
  "image_dpi": 150,
  "avg_file_size_per_page_kb": 1900,
  "metadata_file": "ComicInfo.xml",
  "compatible_readers": [
    "CDisplayEx",
    "ComicRack",
    "Chunky",
    "Perfect Viewer",
    "Calibre"
  ],
  "content_type": "Educational illustrated guide",
  "reading_direction": "left-to-right",
  "color_mode": "RGB",
  "features": {
    "sequential_reading": true,
    "double_page_spreads": false,
    "metadata_embedded": true
  }
}
```

---

## Advantages

1. **Visual Impact**: Perfect for image-heavy content
2. **Simple Format**: Just a ZIP of images
3. **Universal Readers**: Many comic reader apps
4. **No Reflow Issues**: Fixed layout, always looks same
5. **Easy to Create**: No complex markup needed
6. **Cross-Platform**: Works on all devices
7. **Archival**: Simple, long-term format

---

## Limitations

1. **Accessibility**: Not screen reader friendly
2. **File Size**: Large (images add up)
3. **No Text Search**: Images can't be searched
4. **Fixed Layout**: Doesn't reflow for different screens
5. **Creation Time**: Each page must be designed
6. **Translation**: Requires re-designing pages
7. **Updates**: Entire archive must be replaced

---

## Best Practices

1. **Consistent Dimensions**: Same size for all pages
2. **Zero-Padded Numbers**: Use 001, 002, not 1, 2
3. **Include Metadata**: Add ComicInfo.xml
4. **Optimize Images**: Balance quality and file size
5. **Test on Devices**: Check on phone, tablet, desktop
6. **High Contrast**: Ensure text is readable
7. **Sequential Flow**: Logical page order
8. **Cover First**: Always start with cover image

---

## Related Formats

- **14_INTERACTIVE_PDF.md**: Alternative fixed-layout format
- **10_LARGE_PRINT_PDF.md**: PDF with large text
- **04_EPUB_30.md**: Fixed-layout EPUB alternative

---

## Update History
- **2025-12-03**: Initial blueprint created
