# Format Blueprint: SCORM Package

## Metadata
- **Format ID**: `12_SCORM_PACKAGE`
- **Format Name**: SCORM Package
- **Tier**: 4 (Interactive Formats)
- **File Extension**: `.zip` (contains SCORM package)
- **Priority**: High (LMS integration)
- **Accessibility Level**: High (screen reader compatible)

---

## Overview

### Purpose
Create a complete SCORM 1.2 or SCORM 2004 package for Learning Management System (LMS) integration. Enables tracking of student progress, completion, scores, and time spent.

### Use Cases
- Corporate training programs
- Online courses in LMS platforms (Moodle, Canvas, Blackboard)
- Compliance training with completion tracking
- Educational institutions using LMS
- Professional certification programs

---

## Technical Specifications

### SCORM Version
- **Primary**: SCORM 1.2 (maximum compatibility)
- **Alternative**: SCORM 2004 (advanced features)

### Package Structure
```
scorm_package/
├── imsmanifest.xml          # SCORM manifest (required)
├── adlcp_rootv1p2.xsd       # Schema files
├── ims_xml.xsd
├── imscp_rootv1p1p2.xsd
├── imsmd_rootv1p2p1.xsd
├── index.html               # Launch file
├── content/
│   ├── pages/               # Course pages
│   ├── images/              # Media assets
│   ├── css/                 # Stylesheets
│   └── js/                  # JavaScript files
├── scorm_api/
│   └── SCORMAdapter.js      # SCORM API wrapper
└── resources/
    └── assessment_data.json # Quiz/assessment data
```

### Required SCORM Elements
1. **Manifest File** (`imsmanifest.xml`)
   - Organizations structure
   - Resources definitions
   - Metadata
   - Sequencing rules (SCORM 2004)

2. **Launch File** (`index.html`)
   - SCORM API initialization
   - LMS communication
   - Progress tracking

3. **SCORM API Wrapper**
   - `LMSInitialize()` / `Initialize()`
   - `LMSFinish()` / `Terminate()`
   - `LMSGetValue()` / `GetValue()`
   - `LMSSetValue()` / `SetValue()`
   - `LMSCommit()` / `Commit()`

### Data Tracking
- **Completion Status**: `cmi.core.lesson_status`
- **Score**: `cmi.core.score.raw`, `.min`, `.max`
- **Time**: `cmi.core.session_time`
- **Progress**: `cmi.core.lesson_location`
- **Suspend Data**: `cmi.suspend_data` (bookmark progress)
- **Student Info**: `cmi.core.student_id`, `student_name`

---

## Conversion Workflow

### Step 1: Source Analysis
- Identify book content and structure
- Map chapters to SCORM activities (SCOs)
- Identify assessment points
- Determine completion criteria

### Step 2: Content Organization
- Break content into Shareable Content Objects (SCOs)
- Create navigation structure
- Design menu/table of contents
- Plan assessment integration

### Step 3: SCORM Package Creation
- Generate `imsmanifest.xml` with proper structure
- Create HTML pages for each SCO
- Implement SCORM API wrapper
- Add navigation controls
- Integrate progress tracking

### Step 4: Assessment Integration
- Convert quizzes to SCORM-trackable format
- Implement score reporting
- Add completion triggers
- Create mastery criteria

### Step 5: LMS Testing
- Test in SCORM Cloud
- Verify tracking functionality
- Test completion criteria
- Validate score reporting
- Check suspend/resume functionality

### Step 6: Package Validation
- Validate against SCORM conformance test suite
- Check manifest schema compliance
- Test in multiple LMS platforms
- Verify accessibility features

---

## Quality Checklist

### Technical Requirements
- [ ] Valid `imsmanifest.xml` (schema compliant)
- [ ] SCORM API properly initialized
- [ ] All SCOs launch correctly
- [ ] Navigation works in all directions
- [ ] Progress tracking functions correctly
- [ ] Completion status reports accurately
- [ ] Scores (if applicable) report correctly
- [ ] Suspend data preserves progress
- [ ] Package size under LMS limits (typically <500MB)

### Content Requirements
- [ ] All chapters included as SCOs
- [ ] Images and media properly referenced
- [ ] Assessments integrated and functional
- [ ] Table of contents matches structure
- [ ] Glossary/resources accessible
- [ ] Help/instructions provided

### Accessibility Requirements
- [ ] Screen reader compatible
- [ ] Keyboard navigation functional
- [ ] Alt text for all images
- [ ] Proper heading structure
- [ ] ARIA labels where needed
- [ ] Color contrast compliant

### LMS Compatibility
- [ ] Tested in SCORM Cloud
- [ ] Works in Moodle
- [ ] Works in Canvas
- [ ] Works in Blackboard
- [ ] Works in TalentLMS
- [ ] Mobile responsive (if LMS supports)

---

## Sample Manifest Structure

```xml
<?xml version="1.0" encoding="UTF-8"?>
<manifest identifier="BOOK_SCORM_001" version="1.0"
          xmlns="http://www.imsproject.org/xsd/imscp_rootv1p1p2"
          xmlns:adlcp="http://www.adlnet.org/xsd/adlcp_rootv1p2">

  <metadata>
    <schema>ADL SCORM</schema>
    <schemaversion>1.2</schemaversion>
  </metadata>

  <organizations default="BOOK_ORG">
    <organization identifier="BOOK_ORG">
      <title>Book Title - SCORM Package</title>

      <item identifier="CHAPTER_01" identifierref="RES_CHAPTER_01">
        <title>Chapter 1: Introduction</title>
      </item>

      <item identifier="CHAPTER_02" identifierref="RES_CHAPTER_02">
        <title>Chapter 2: Core Concepts</title>
      </item>

      <!-- More chapters -->

      <item identifier="ASSESSMENT" identifierref="RES_ASSESSMENT">
        <title>Final Assessment</title>
      </item>
    </organization>
  </organizations>

  <resources>
    <resource identifier="RES_CHAPTER_01" type="webcontent"
              adlcp:scormtype="sco" href="content/chapter_01.html">
      <file href="content/chapter_01.html"/>
      <file href="css/styles.css"/>
      <file href="js/scorm_adapter.js"/>
      <!-- More files -->
    </resource>

    <!-- More resources -->
  </resources>
</manifest>
```

---

## AI Model Recommendations

### Primary Models
- **Manifest Generation**: Claude Sonnet (structure expertise)
- **SCORM API Integration**: GPT-4 (code generation)
- **Content Conversion**: Gemini Pro (HTML conversion)
- **Assessment Creation**: Claude Opus (quiz logic)

### Verification Models
- **Schema Validation**: GPT-4 (technical validation)
- **LMS Compatibility**: Claude Sonnet (standards compliance)
- **Accessibility Check**: Gemini Pro (WCAG verification)

---

## Output Structure

### Primary Output
- **File**: `[BookTitle]_SCORM_Package.zip`
- **Size**: Optimized for LMS upload (typically <200MB)
- **Contents**: Complete SCORM 1.2/2004 package

### Additional Files
- `SCORM_Installation_Guide.pdf` - LMS setup instructions
- `SCORM_Completion_Criteria.txt` - Tracking requirements
- `LMS_Compatibility_Report.pdf` - Tested platforms

---

## Metadata to Include

```json
{
  "format": "SCORM Package",
  "version": "SCORM 1.2",
  "total_scos": 15,
  "duration_minutes": 180,
  "completion_threshold": 80,
  "mastery_score": 70,
  "tracking_elements": [
    "completion",
    "score",
    "time",
    "progress",
    "suspend_data"
  ],
  "tested_lms": [
    "SCORM Cloud",
    "Moodle 4.0",
    "Canvas",
    "Blackboard Learn"
  ],
  "package_size_mb": 45.7,
  "accessibility": "WCAG 2.1 AA"
}
```

---

## Known Limitations

1. **File Size**: Large packages may exceed LMS limits
2. **Media**: Some LMS platforms have video codec restrictions
3. **Offline Access**: Depends on LMS implementation
4. **Mobile**: Variable support across LMS platforms
5. **Sequencing**: SCORM 1.2 has limited sequencing vs 2004

---

## Best Practices

1. **Keep It Simple**: Use SCORM 1.2 unless advanced features needed
2. **Test Early**: Validate in SCORM Cloud during development
3. **Optimize Media**: Compress images and videos
4. **Use Relative Paths**: Ensure portability across LMS platforms
5. **Include Help**: Provide clear instructions for learners
6. **Bookmark Progress**: Use suspend data for long courses
7. **Clear Completion**: Define explicit completion criteria

---

## Related Formats

- **13_XAPI_TIN_CAN.md**: Modern alternative to SCORM
- **14_INTERACTIVE_PDF.md**: Simpler interactive format
- **15_H5P_PACKAGE.md**: HTML5-based interactive content

---

## Update History
- **2025-12-03**: Initial blueprint created
