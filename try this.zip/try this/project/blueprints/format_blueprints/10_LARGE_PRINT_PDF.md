# Format Blueprint: Large Print PDF (18-24pt)

## Basic Information
- **File Extension:** `.pdf`
- **Format Type:** Accessibility / Large Print
- **Tier:** 3 (Accessibility - Conditional)
- **Priority:** HIGH for low vision readers
- **Generation Time:** 4-6 minutes per 200 pages (becomes 400-600 pages)
- **File Size Estimate:** 60-100 MB (200 pages of content)

---

## Purpose & Use Case

**Primary Purpose:**
Large text PDF specifically designed for readers with low vision, seniors, and those who need larger text for comfortable reading.

**Best Used For:**
- Low vision readers
- Senior readers (presbyopia)
- Readers with visual impairments
- People recovering from eye surgery
- Classroom projection
- Distance viewing

**Distribution Channels:**
- Libraries (large print sections)
- Senior centers
- Schools for visually impaired
- Low vision support organizations
- Direct download for low vision users

**Use When:**
- Low vision adaptation requested
- Senior-friendly version needed
- Classroom/projection use
- Accessibility requirements

---

## Technical Specifications

### Core Requirements
- **Font Size:** 18pt minimum, 20-24pt preferred
- **Font:** Sans-serif (Arial, Verdana) or high-contrast serif
- **Line Spacing:** 1.5x minimum, 2.0x preferred
- **Contrast:** High contrast (black on white or white on black)
- **Page Size:** 8.5" × 11" (letter) - more pages needed
- **Margins:** 1" all sides (generous)
- **Images:** Larger, high contrast
- **Resolution:** 150 DPI (sufficient for large text)
- **Simplicity:** Clean layout, no decorative elements

### Quality Standards
- **Readability:** Easy to read at arm's length
- **Contrast Ratio:** 7:1 minimum (WCAG AAA)
- **Font Weight:** Medium or Bold (not thin)
- **No Small Text:** All text 18pt or larger
- **Clear Headings:** Strong visual hierarchy
- **Simple Layout:** One column, no complex layouts
- **Page Numbers:** Large and clear

---

## Generation Process

### Step 1: Configure Large Print Layout (1 minute)

**Code Example:**
```python
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER
from reportlab.platypus import SimpleDocTemplate, Paragraph, PageBreak, Spacer

def create_large_print_pdf(output_path):
    """Initialize large print PDF with proper settings"""

    doc = SimpleDocTemplate(
        output_path,
        pagesize=letter,
        rightMargin=inch,
        leftMargin=inch,
        topMargin=inch,
        bottomMargin=inch
    )

    # Define styles
    styles = getSampleStyleSheet()

    # Title style (24pt)
    title_style = ParagraphStyle(
        'LargePrintTitle',
        parent=styles['Heading1'],
        fontSize=24,
        leading=36,  # 1.5x line height
        spaceAfter=24,
        fontName='Helvetica-Bold',
        textColor='#000000',
        alignment=TA_CENTER
    )

    # Chapter heading (22pt)
    chapter_style = ParagraphStyle(
        'LargePrintChapter',
        parent=styles['Heading1'],
        fontSize=22,
        leading=33,
        spaceAfter=22,
        spaceBefore=22,
        fontName='Helvetica-Bold',
        textColor='#000000',
        keepWithNext=True
    )

    # Section heading (20pt)
    section_style = ParagraphStyle(
        'LargePrintSection',
        parent=styles['Heading2'],
        fontSize=20,
        leading=30,
        spaceAfter=16,
        spaceBefore=16,
        fontName='Helvetica-Bold',
        textColor='#000000'
    )

    # Body text (18pt)
    body_style = ParagraphStyle(
        'LargePrintBody',
        parent=styles['Normal'],
        fontSize=18,
        leading=27,  # 1.5x line height
        spaceAfter=18,
        fontName='Helvetica',
        textColor='#000000',
        alignment=TA_LEFT
    )

    return doc, {
        'title': title_style,
        'chapter': chapter_style,
        'section': section_style,
        'body': body_style
    }
```

**Output:** PDF document template configured
**Time:** 1 minute

### Step 2: Convert Content (2 minutes)

**Code Example:**
```python
from bs4 import BeautifulSoup

def convert_to_large_print(html_content, styles):
    """Convert regular content to large print format"""

    soup = BeautifulSoup(html_content, 'html.parser')
    story = []  # ReportLab story (document elements)

    # Title page
    title = soup.find('h1', class_='title')
    if title:
        story.append(Paragraph(title.text, styles['title']))
        story.append(Spacer(1, 0.5*inch))

    # Author
    author = soup.find('p', class_='author')
    if author:
        story.append(Paragraph(author.text, styles['body']))
        story.append(PageBreak())

    # Table of contents
    story.append(Paragraph("TABLE OF CONTENTS", styles['chapter']))
    toc = soup.find('nav', class_='toc')
    if toc:
        for link in toc.find_all('a'):
            story.append(Paragraph(f"• {link.text}", styles['body']))
        story.append(PageBreak())

    # Chapters
    for chapter in soup.find_all('section', class_='chapter'):
        # Chapter heading
        heading = chapter.find('h2')
        if heading:
            story.append(Paragraph(heading.text, styles['chapter']))
            story.append(Spacer(1, 0.3*inch))

        # Section headings and paragraphs
        for element in chapter.find_all(['h3', 'p']):
            if element.name == 'h3':
                story.append(Paragraph(element.text, styles['section']))
            elif element.name == 'p':
                # Simplify text (remove complex formatting)
                text = element.get_text()
                story.append(Paragraph(text, styles['body']))

        story.append(PageBreak())

    return story
```

**Output:** Content converted to large print
**Time:** 2 minutes

### Step 3: Handle Images (1 minute)

**Code Example:**
```python
from reportlab.platypus import Image
from PIL import Image as PILImage

def add_large_print_image(img_path, max_width=5*inch):
    """Add high-contrast image with caption"""

    # Open and enhance contrast
    img = PILImage.open(img_path)

    # Increase contrast for better visibility
    from PIL import ImageEnhance
    enhancer = ImageEnhance.Contrast(img)
    img = enhancer.enhance(1.5)  # Increase contrast by 50%

    # Save enhanced image
    enhanced_path = img_path.replace('.jpg', '_enhanced.jpg')
    img.save(enhanced_path, quality=95)

    # Add to PDF
    image = Image(enhanced_path, width=max_width, height=max_width,
                  kind='proportional')

    return image
```

**Output:** High-contrast images
**Time:** 1 minute

### Step 4: Add Page Numbers and Headers (30 seconds)

**Code Example:**
```python
from reportlab.lib.units import inch

def add_page_numbers(canvas, doc):
    """Add large page numbers to each page"""

    canvas.saveState()

    # Large page number (18pt)
    canvas.setFont('Helvetica-Bold', 18)

    # Bottom center
    page_num = f"Page {canvas.getPageNumber()}"
    canvas.drawCentredString(
        letter[0] / 2,
        0.5 * inch,
        page_num
    )

    canvas.restoreState()

# Use when building PDF
doc.build(story, onFirstPage=add_page_numbers, onLaterPages=add_page_numbers)
```

**Output:** Page numbers added
**Time:** 30 seconds

### Step 5: Generate High Contrast Variant (Optional - 1 minute)

**Code Example:**
```python
def create_high_contrast_variant(pdf_path):
    """Create white-on-black variant for users who prefer it"""

    # Modify styles for inverted colors
    body_style_inverted = ParagraphStyle(
        'LargePrintBodyInverted',
        fontSize=18,
        leading=27,
        spaceAfter=18,
        fontName='Helvetica',
        textColor='#FFFFFF',
        backColor='#000000'
    )

    # Set page background to black
    # Canvas.setFillColor for background

    return inverted_pdf_path
```

**Output:** High contrast variant (optional)
**Time:** 1 minute (if generated)

**Total Time:** 4-6 minutes per book

---

## Quality Verification

### Automated Checks
1. All text 18pt or larger
2. Contrast ratio 7:1 or higher
3. Line spacing 1.5x minimum
4. No decorative fonts
5. Page numbers large and clear
6. Images high contrast
7. File size appropriate
8. PDF/A compliant

### Testing Checklist
- [ ] Readable at arm's length (24 inches)
- [ ] Text clear at 100% zoom
- [ ] High contrast maintained
- [ ] No small text anywhere
- [ ] Page numbers easily visible
- [ ] Headings clearly distinguished
- [ ] Images clear and high contrast
- [ ] No busy backgrounds
- [ ] Simple, clean layout
- [ ] Tested with low vision users

---

## Tools & Libraries

### Python Libraries
```txt
reportlab==4.0.4
Pillow==10.0.0
beautifulsoup4==4.12.2
```

### Installation
```bash
pip install reportlab Pillow beautifulsoup4
```

---

## Storage & Naming

### File Naming Convention
```
{book_id}_{reading_level}_{disability}_large_print.pdf

Examples:
math_algebra_college_low_vision_large_print.pdf
science_biology_elementary_senior_large_print.pdf
```

### Variants
- Standard: Black text on white
- High contrast: White text on black (optional)
- Ultra large: 24pt+ for severe low vision (optional)

---

## Performance Metrics

### Generation Speed
- **Target:** 4 minutes for 200 pages of content
- **Maximum:** 8 minutes

### File Size
- **Target:** 60-80 MB (200 pages becomes 400-600 pages)
- **Maximum:** 150 MB

### Page Count
- Original 200 pages → 400-600 large print pages

---

## Accessibility Standards

### WCAG Guidelines Met
- **1.4.3 Contrast (Minimum):** Level AA (4.5:1) ✅
- **1.4.6 Contrast (Enhanced):** Level AAA (7:1) ✅
- **1.4.8 Visual Presentation:** Level AAA ✅
- **1.4.12 Text Spacing:** Adjustable ✅

### Best Practices
- Sans-serif fonts preferred (easier to read)
- No italics (harder to read in large print)
- No all-caps paragraphs
- Generous line spacing
- Clear page breaks
- Simplified layout

---

## Related Formats

### PDF Digital 150 DPI
**Difference:** Standard font size (11-12pt)
**When to use instead:** Regular vision users

### DAISY 3.0
**Difference:** Audio + text synchronization
**When to use instead:** Blind users or audio preferred
