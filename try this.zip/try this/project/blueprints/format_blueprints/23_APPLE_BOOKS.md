# Format Blueprint: Apple Books Format

## Metadata
- **Format ID**: `23_APPLE_BOOKS`
- **Format Name**: Apple Books Optimized EPUB
- **Tier**: 7 (Platform-Specific Formats)
- **File Extension**: `.epub`
- **Priority**: High (major platform, iOS ecosystem)
- **Accessibility Level**: Very High (industry-leading accessibility)

---

## Overview

### Purpose
Create an optimized EPUB specifically formatted for Apple Books (formerly iBooks) with Apple-specific enhancements, features, and compatibility across iOS, iPadOS, and macOS.

### Use Cases
- iOS/iPad ecosystem distribution
- Mac desktop readers
- Educational publishing (iTunes U integration)
- Premium ebook experiences
- Enhanced interactivity (EPUB 3 features)
- Subscription via Apple Books+ (if eligible)

---

## Platform Overview

### Apple Books Stats
- **Reach**: 155+ countries
- **Devices**: iPhone, iPad, Mac, Apple Vision Pro
- **Market Share**: #3 globally, #1 in education
- **Unique**: Apple Pencil support, Multi-Touch enhancements
- **Integration**: Apple Classroom, Schoolwork app

### Key Advantages
- Premium user base (higher spending)
- Excellent typography and rendering
- Strong educational market
- Apple Pencil annotation support
- Best EPUB 3 feature support
- Family Sharing built-in

---

## Technical Specifications

### Accepted Formats
1. **EPUB 3.0** (Strongly Recommended)
2. **EPUB 2.0.1** (Supported)
3. **Multi-Touch Books** (.ibooks - discontinued but legacy support)
4. **PDF** (Supported but not recommended)

### Apple Books EPUB Requirements

#### Enhanced EPUB 3 Features
Apple Books supports advanced EPUB 3 features:
- **JavaScript**: Interactive elements
- **HTML5 Audio/Video**: Embedded multimedia
- **MathML**: Native math rendering
- **SMIL**: Synchronized text-audio
- **CSS3 Animations**: Visual effects
- **Fixed Layout**: Graphic novels, children's books
- **Read Aloud**: Enhanced text-to-speech

#### content.opf with Apple Extensions
```xml
<?xml version="1.0" encoding="UTF-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="pub-id"
         xmlns:ibooks="http://vocabulary.itunes.apple.com/rdf/ibooks/vocabulary-extensions-1.0/">

  <metadata xmlns:dc="http://purl.org/dc/elements/1.1/"
            xmlns:opf="http://www.idpf.org/2007/opf">

    <!-- Standard Metadata -->
    <dc:title>Book Title</dc:title>
    <dc:creator>Author Name</dc:creator>
    <dc:identifier id="pub-id">urn:uuid:12345</dc:identifier>
    <dc:language>en</dc:language>
    <meta property="dcterms:modified">2025-12-03T00:00:00Z</meta>

    <!-- Apple Books Specific -->
    <meta property="ibooks:specified-fonts">true</meta>
    <meta property="ibooks:version">1.0</meta>
    <meta property="ibooks:iphone-orientation-lock">none</meta>
    <meta property="ibooks:ipad-orientation-lock">none</meta>
    <meta property="ibooks:binding">true</meta>

    <!-- Scrolling (Continuous) vs. Pagination -->
    <meta property="rendition:layout">reflowable</meta>
    <meta property="rendition:spread">auto</meta>

    <!-- For Fixed Layout -->
    <!-- <meta property="rendition:layout">pre-paginated</meta> -->
    <!-- <meta property="rendition:spread">landscape</meta> -->

  </metadata>

  <manifest>
    <!-- Apple requires cover-image property -->
    <item id="cover" href="images/cover.jpg" media-type="image/jpeg" properties="cover-image"/>

    <!-- JavaScript for interactivity -->
    <item id="script" href="js/interactive.js" media-type="text/javascript"/>

    <!-- HTML5 Video -->
    <item id="video1" href="media/video.mp4" media-type="video/mp4"/>

    <!-- More items -->
  </manifest>

  <spine>
    <itemref idref="cover"/>
    <itemref idref="chapter01"/>
  </spine>
</package>
```

---

## Apple Books Specific Optimizations

### 1. Cover Image
**Requirements:**
- **Minimum Size**: 1400px (shortest side)
- **Recommended**: 1600px × 2400px or higher
- **Maximum Size**: 4000px × 4000px
- **Aspect Ratio**: 1:1.5 (2:3 ratio)
- **Format**: JPEG or PNG (JPEG preferred, smaller file size)
- **Color Space**: RGB
- **Resolution**: 72-300 dpi
- **File Size**: <2 MB per image

**Apple Books Cover Best Practices:**
- Title and author clearly readable
- High contrast for visibility on device
- Avoid very thin fonts (hard to read at thumbnail size)
- No blurriness or pixelation
- Professional typography

### 2. Typography & Fonts
**Embedded Fonts:**
- Apple Books supports custom fonts beautifully
- Use OTF or TTF formats
- Embed via `@font-face` in CSS
- Set `ibooks:specified-fonts` to `true` in metadata
- Provide fallback fonts

**CSS Font Stack Example:**
```css
@font-face {
  font-family: "Custom Serif";
  src: url("../fonts/CustomSerif.otf");
  font-weight: normal;
  font-style: normal;
}

body {
  font-family: "Custom Serif", "Georgia", "Times New Roman", serif;
  line-height: 1.5;
  font-size: 1em;
}
```

**Apple System Fonts:**
If not embedding, Apple Books has excellent system fonts:
- San Francisco (sans-serif)
- New York (serif)
- Menlo (monospace)

### 3. Interactive Features
**Supported:**
- HTML5 audio/video (MP4, M4A, M4V)
- JavaScript interactivity
- HTML forms (quizzes)
- CSS animations
- SVG graphics (with animations)
- Canvas elements

**Example Interactive Element:**
```html
<div class="interactive-quiz">
  <p>What is 2 + 2?</p>
  <button onclick="checkAnswer(4)">4</button>
  <button onclick="checkAnswer(5)">5</button>
  <div id="feedback"></div>
</div>

<script>
function checkAnswer(answer) {
  var feedback = document.getElementById('feedback');
  if (answer === 4) {
    feedback.textContent = "Correct!";
  } else {
    feedback.textContent = "Try again.";
  }
}
</script>
```

### 4. Math Support (MathML)
Apple Books has native MathML rendering:
```html
<math xmlns="http://www.w3.org/1998/Math/MathML">
  <mrow>
    <msup>
      <mi>x</mi>
      <mn>2</mn>
    </msup>
    <mo>+</mo>
    <mi>y</mi>
    <mo>=</mo>
    <mn>5</mn>
  </mrow>
</math>
```

**Fallback for Other Readers:**
Use SVG or high-resolution PNG as fallback for readers without MathML support.

### 5. Fixed Layout (Optional)
For highly designed books (children's books, cookbooks, textbooks):
```xml
<meta property="rendition:layout">pre-paginated</meta>
<meta property="rendition:orientation">portrait</meta>
<meta property="rendition:spread">none</meta>
```

**Fixed Layout Specifications:**
- Page Size: 1024×768 (iPad landscape) or 768×1024 (portrait)
- Higher resolution for Retina: 2048×1536 or 1536×2048
- All content positioned absolutely
- Not responsive (fixed design)

---

## Quality Checklist

### EPUB Validation
- [ ] Passes EPUBCheck 4.0+
- [ ] Passes Apple Books Asset Guide checker
- [ ] All internal links functional
- [ ] Cover image embedded with `cover-image` property
- [ ] Table of contents complete (nav.xhtml)
- [ ] Metadata complete

### Apple Books Specific
- [ ] Cover 1400px+ minimum (1600×2400 recommended)
- [ ] Aspect ratio 1:1.5 (2:3)
- [ ] `ibooks:` metadata included
- [ ] Fonts embedded (if custom) with license
- [ ] JavaScript tested in Apple Books
- [ ] Audio/video tested on iOS
- [ ] MathML renders correctly (if applicable)

### Content Quality
- [ ] High-resolution images (300 dpi source)
- [ ] All multimedia functional
- [ ] Interactive elements tested
- [ ] Equations readable
- [ ] Hyperlinks working
- [ ] No formatting errors

### Accessibility (Apple Priority)
- [ ] All images have alt text
- [ ] Semantic HTML used
- [ ] Logical reading order
- [ ] VoiceOver compatible
- [ ] Color contrast WCAG AA minimum
- [ ] Captions for videos
- [ ] Transcripts for audio

---

## Upload Process

### Step 1: Prepare Files
- Final EPUB file (validated)
- Cover image (separate file, 1600×2400+)
- Book description (plain text or basic HTML)
- Author bio
- ISBN (required for distribution)
- Screenshots (optional, 5 max)

### Step 2: Apple Books Connect
**Access**: books.apple.com

**Requirements:**
- Apple ID
- Tax and banking information
- Signed Apple Books agreement

### Step 3: Create Book Listing
**Required Information:**
- Title and subtitle
- Author name(s)
- Publisher name
- ISBN-13 (required)
- Publication date
- Description (up to 4000 characters)
- Language
- Primary category (choose from Apple's list)
- Keywords (up to 7)
- Copyright text
- Age rating (if applicable)

### Step 4: Upload EPUB & Assets
- Upload EPUB file
- Upload cover image (separate)
- Add screenshots (optional but recommended)
- Set pricing per territory
- Choose availability (155+ countries)
- Select preorder date (optional)

### Step 5: Review & Validation
- Apple automatically validates EPUB
- Preview in Apple Books for Mac
- Test on iOS device (TestFlight or direct download)
- Fix any validation errors
- Submit for review (1-5 days typically)

---

## Testing Checklist

### Device Testing
- [ ] iPhone (various sizes: SE, Pro, Pro Max)
- [ ] iPad (iPad, iPad Air, iPad Pro)
- [ ] Mac (macOS Apple Books app)
- [ ] Apple Vision Pro (if applicable)

### Feature Testing
- [ ] Table of contents navigation
- [ ] Hyperlinks (internal and external)
- [ ] Images load correctly
- [ ] Custom fonts render properly
- [ ] JavaScript interactivity works
- [ ] Audio/video playback functional
- [ ] MathML displays correctly
- [ ] Bookmarks and highlights work
- [ ] Search functionality
- [ ] VoiceOver (screen reader) compatibility
- [ ] Apple Pencil annotations (iPad)

---

## Apple Books Unique Features

### 1. Reading Goals
- Users can set reading goals
- Your book tracks reading time
- Badges for completion

### 2. Scroll vs. Page Turn
- Users can choose continuous scroll or pagination
- Design should work well in both modes

### 3. Apple Pencil Support
- Readers can annotate with Apple Pencil
- Handwritten notes synced via iCloud
- Highlight and underline

### 4. Night Mode / Themes
- Auto dark mode support
- Multiple theme options (sepia, night, white, black)
- Design for light and dark backgrounds

### 5. Family Sharing
- Purchase once, share with up to 5 family members
- No DRM limitations for family

### 6. iCloud Sync
- Bookmarks, notes, highlights sync across devices
- Reading position syncs automatically

### 7. Educational Features
- Apple Classroom integration
- Schoolwork app assignments
- Progress tracking for educators

---

## Revenue & Pricing

### Revenue Share
- **Publisher receives**: 70% of price (for books $0.99-$9.99)
- **Publisher receives**: 70% (for books $10+, if eligible)
- **Apple keeps**: 30%
- **Payment**: Monthly, via wire transfer
- **Minimum**: $150 threshold

### Pricing Strategy
- Research category pricing
- Consider psychological pricing ($9.99 vs. $10.00)
- Educational pricing options
- Volume purchase program (VPP) for schools
- Promotional pricing (limited-time discounts)

---

## AI Model Recommendations

### Content Optimization
- **Description Writing**: Claude Sonnet (compelling copy)
- **Keyword Selection**: GPT-4 (App Store SEO)
- **Category Selection**: Gemini Pro (best fit)

### Interactive Features
- **JavaScript Coding**: GPT-4 (quiz/interactive elements)
- **MathML Generation**: Claude Opus (equation formatting)

### Quality Assurance
- **Accessibility Check**: Claude Sonnet (WCAG validation)
- **EPUB Validation**: GPT-4 (error detection)

---

## Output Structure

### Deliverables
```
apple_books/
├── book_optimized_apple_books.epub  # Apple-optimized EPUB
├── cover_1600x2400.jpg              # High-res cover
├── cover_2400x3600.jpg              # Ultra-high-res cover
├── screenshots/                     # Preview screenshots (5 max)
│   ├── screenshot_01.png
│   ├── screenshot_02.png
│   └── ...
├── book_description.txt             # Marketing description
├── metadata.txt                     # All metadata fields
├── keywords.txt                     # SEO keywords
└── upload_guide.pdf                 # Step-by-step instructions
```

---

## Metadata to Include

```json
{
  "format": "Apple Books EPUB",
  "epub_version": "3.0",
  "file_size_mb": 18.7,
  "isbn_13": "978-1-234567-89-0",
  "title": "Complete Book Title",
  "subtitle": "Subtitle",
  "author": "Author Name",
  "publisher": "Publisher Name",
  "publication_date": "2025-12-03",
  "language": "en",
  "page_count": 324,
  "apple_category": "Education & Reference",
  "keywords": [
    "education",
    "learning",
    "reference",
    "study guide",
    "textbook"
  ],
  "features": {
    "custom_fonts": true,
    "interactive_elements": true,
    "mathml": true,
    "audio_video": false,
    "fixed_layout": false
  },
  "cover_specifications": {
    "width": 1600,
    "height": 2400,
    "format": "JPEG",
    "aspect_ratio": "2:3"
  },
  "pricing": {
    "usd": 24.99,
    "tier": "standard"
  },
  "distribution": {
    "countries": 155,
    "family_sharing": true,
    "preorder": false
  },
  "accessibility": {
    "voiceover_compatible": true,
    "wcag_level": "AA",
    "apple_pencil_annotations": true
  }
}
```

---

## Advantages

1. **Premium Market**: High-spending, engaged users
2. **Best EPUB Support**: Industry-leading EPUB 3 rendering
3. **Education Focus**: Strong in K-12 and higher education
4. **Beautiful Typography**: Best-in-class font rendering
5. **Interactive Features**: Full JavaScript, multimedia support
6. **Apple Pencil**: Unique annotation capabilities
7. **Family Sharing**: Built-in viral distribution

---

## Best Practices

1. **High-Quality Cover**: Invest in professional design
2. **Test on Real Devices**: iPhone, iPad, Mac
3. **Leverage Interactivity**: Use EPUB 3 features
4. **Custom Fonts**: Enhance brand and readability
5. **Accessibility First**: VoiceOver is critical
6. **Educational Market**: Target schools and universities
7. **Screenshots**: Include 5 compelling previews
8. **Regular Updates**: Publish revised editions easily

---

## Common Issues & Solutions

### Issue: Custom fonts not displaying
**Solution**: Set `ibooks:specified-fonts` to `true` in metadata

### Issue: JavaScript not working
**Solution**: Ensure EPUB 3.0, test in Apple Books preview

### Issue: Cover rejected
**Solution**: Check aspect ratio (2:3), minimum 1400px

### Issue: Math equations not rendering
**Solution**: Use MathML for Apple Books, provide SVG fallback

### Issue: Low discoverability
**Solution**: Optimize keywords, category, and description SEO

---

## Related Formats

- **04_EPUB_30.md**: Standard EPUB base format
- **22_GOOGLE_PLAY_BOOKS.md**: Google Play optimization
- **24_KOBO.md**: Kobo-specific EPUB
- **25_NOOK.md**: Nook-specific EPUB

---

## Update History
- **2025-12-03**: Initial blueprint created
