# Format Blueprint: Microsoft Word (DOCX)

## Basic Information
- **File Extension:** `.docx`
- **Format Type:** Academic / Editable Document
- **Tier:** 2 (Academic - Conditional)
- **Priority:** HIGH for institutional use, collaborative editing
- **Generation Time:** 3-5 minutes per 200 pages
- **File Size Estimate:** 15-30 MB for 200 pages with images

---

## Purpose & Use Case

**Primary Purpose:**
Fully editable Microsoft Word document for collaboration, institutional requirements, and further editing.

**Best Used For:**
- Collaborative editing and review
- Institutional/corporate requirements
- Editorial workflow
- Manuscript submissions (some publishers)
- Grant proposals and reports
- Government documentation
- Track changes and comments
- Version comparison
- Accessibility compliance (built-in checker)

**Distribution Channels:**
- Direct download for editors
- Institutional repositories
- Microsoft OneDrive/SharePoint
- Google Drive (Word-compatible)
- Email distribution
- Publisher submission portals

**Use When:**
- Collaborative editing required
- Track changes needed
- Institutional Microsoft Office requirement
- Publisher requires Word format
- Accessibility tools needed
- Comments and review workflow
- Integration with Microsoft ecosystem

---

## Technical Specifications

### Core Requirements
- **Format:** Office Open XML (.docx)
- **Compatibility:** Word 2016+ (Office 365 recommended)
- **Encoding:** UTF-8
- **Styles:** Complete style system (headings, body, captions)
- **TOC:** Auto-generated table of contents
- **Images:** Embedded (not linked)
- **Equations:** Office Math format (MathML)
- **Bibliography:** Word citation manager
- **Cross-references:** Auto-updating
- **Accessibility:** Alt text, reading order, proper structure

### File Structure (Internal)
```
document.docx (ZIP archive)
├── [Content_Types].xml
├── _rels/
├── word/
│   ├── document.xml (main content)
│   ├── styles.xml (paragraph and character styles)
│   ├── numbering.xml (lists and numbering)
│   ├── footnotes.xml
│   ├── endnotes.xml
│   ├── comments.xml
│   ├── media/ (embedded images)
│   │   ├── image1.jpg
│   │   └── ...
│   └── _rels/
└── docProps/
    ├── core.xml (metadata)
    └── app.xml
```

### Quality Standards
- **Styles:** All text using named styles (no direct formatting)
- **Headings:** Proper heading hierarchy (H1-H6)
- **TOC:** Auto-generated and updateable
- **Images:** Properly captioned with alt text
- **Equations:** Editable Office Math format
- **Tables:** Proper table styles
- **Page Layout:** Consistent margins and spacing
- **Accessibility Score:** 90+ in built-in checker
- **Compatibility:** Works in Word 2016+

---

## Generation Process

### Step 1: Initialize Document (15 seconds)

**Code Example:**
```python
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE

def create_word_document(book_metadata):
    """Initialize Word document with proper settings"""

    doc = Document()

    # Set document properties
    core_props = doc.core_properties
    core_props.title = book_metadata['title']
    core_props.author = book_metadata['author']
    core_props.subject = book_metadata['subject']
    core_props.keywords = ', '.join(book_metadata['keywords'])
    core_props.comments = book_metadata.get('description', '')

    # Page setup
    section = doc.sections[0]
    section.page_height = Inches(11)
    section.page_width = Inches(8.5)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)

    return doc
```

### Step 2: Define Styles (30 seconds)

**Code Example:**
```python
def setup_styles(doc):
    """Create custom styles for the document"""

    styles = doc.styles

    # Title style
    if 'Book Title' not in styles:
        title_style = styles.add_style('Book Title', WD_STYLE_TYPE.PARAGRAPH)
        title_font = title_style.font
        title_font.name = 'Calibri'
        title_font.size = Pt(28)
        title_font.bold = True
        title_font.color.rgb = RGBColor(0, 0, 0)
        title_style.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
        title_style.paragraph_format.space_after = Pt(12)

    # Body Text style
    body_style = styles['Normal']
    body_font = body_style.font
    body_font.name = 'Georgia'
    body_font.size = Pt(11)
    body_style.paragraph_format.line_spacing = 1.15
    body_style.paragraph_format.space_after = Pt(8)

    # Heading styles (already exist, just modify)
    for i in range(1, 4):
        heading_style = styles[f'Heading {i}']
        heading_font = heading_style.font
        heading_font.name = 'Calibri'
        heading_font.bold = True
        heading_font.color.rgb = RGBColor(0, 70, 135)

        if i == 1:
            heading_font.size = Pt(18)
            heading_style.paragraph_format.page_break_before = True
        elif i == 2:
            heading_font.size = Pt(14)
        elif i == 3:
            heading_font.size = Pt(12)

    # Caption style
    if 'Caption' not in styles:
        caption_style = styles.add_style('Caption', WD_STYLE_TYPE.PARAGRAPH)
        caption_font = caption_style.font
        caption_font.name = 'Calibri'
        caption_font.size = Pt(9)
        caption_font.italic = True
        caption_style.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER

    return doc
```

### Step 3: Add Content (2 minutes)

**Code Example:**
```python
from bs4 import BeautifulSoup

def add_content_to_word(doc, html_content):
    """Convert HTML content to Word document"""

    soup = BeautifulSoup(html_content, 'html.parser')

    for element in soup.find_all(['h1', 'h2', 'h3', 'p', 'img', 'table', 'ul', 'ol']):
        if element.name == 'h1':
            doc.add_heading(element.text, level=1)

        elif element.name == 'h2':
            doc.add_heading(element.text, level=2)

        elif element.name == 'h3':
            doc.add_heading(element.text, level=3)

        elif element.name == 'p':
            paragraph = doc.add_paragraph(element.text)
            # Apply inline formatting
            for strong in element.find_all('strong'):
                # Would need more complex logic for partial bold
                pass

        elif element.name == 'img':
            add_image_to_word(doc, element)

        elif element.name == 'table':
            add_table_to_word(doc, element)

        elif element.name in ['ul', 'ol']:
            add_list_to_word(doc, element)

    return doc

def add_image_to_word(doc, img_element):
    """Add image with caption"""
    src = img_element.get('src')
    alt = img_element.get('alt', '')

    try:
        # Add image (max width 6 inches)
        paragraph = doc.add_paragraph()
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = paragraph.add_run()
        run.add_picture(src, width=Inches(6))

        # Add caption
        if alt:
            caption = doc.add_paragraph(alt, style='Caption')
    except Exception as e:
        print(f"Error adding image {src}: {e}")

def add_table_to_word(doc, table_element):
    """Convert HTML table to Word table"""
    rows = table_element.find_all('tr')

    if not rows:
        return

    # Determine number of columns
    first_row = rows[0]
    cols = len(first_row.find_all(['th', 'td']))

    # Create Word table
    word_table = doc.add_table(rows=len(rows), cols=cols)
    word_table.style = 'Light Grid Accent 1'

    # Fill table
    for i, row in enumerate(rows):
        cells = row.find_all(['th', 'td'])
        for j, cell in enumerate(cells):
            word_table.rows[i].cells[j].text = cell.text

            # Header row formatting
            if row.find('th'):
                word_table.rows[i].cells[j].paragraphs[0].runs[0].font.bold = True

def add_list_to_word(doc, list_element):
    """Add bulleted or numbered list"""
    is_ordered = list_element.name == 'ol'

    for li in list_element.find_all('li', recursive=False):
        style = 'List Number' if is_ordered else 'List Bullet'
        doc.add_paragraph(li.text, style=style)
```

### Step 4: Add Table of Contents (15 seconds)

**Code Example:**
```python
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

def add_toc(doc):
    """Add auto-updating table of contents"""

    # Add TOC heading
    doc.add_heading('Table of Contents', level=1)

    # Add TOC field
    paragraph = doc.add_paragraph()
    run = paragraph.add_run()

    # Create TOC field code
    fldChar1 = OxmlElement('w:fldChar')
    fldChar1.set(qn('w:fldCharType'), 'begin')

    instrText = OxmlElement('w:instrText')
    instrText.set(qn('xml:space'), 'preserve')
    instrText.text = 'TOC \\o "1-3" \\h \\z \\u'

    fldChar2 = OxmlElement('w:fldChar')
    fldChar2.set(qn('w:fldCharType'), 'separate')

    fldChar3 = OxmlElement('w:t')
    fldChar3.text = "Right-click to update field."

    fldChar4 = OxmlElement('w:fldChar')
    fldChar4.set(qn('w:fldCharType'), 'end')

    # Add elements to run
    r_element = run._r
    r_element.append(fldChar1)
    r_element.append(instrText)
    r_element.append(fldChar2)
    r_element.append(fldChar3)
    r_element.append(fldChar4)

    # Add page break after TOC
    doc.add_page_break()

    return doc
```

### Step 5: Add Comments and Track Changes (Optional - 30 seconds)

**Code Example:**
```python
from docx.oxml import parse_xml

def add_comment(doc, paragraph, text, author="System"):
    """Add comment to paragraph"""

    # This is a simplified example
    # Full implementation requires more complex XML manipulation

    comment_part = doc.part.add_comment_part()
    comment_id = len(doc.part.comment_part.comments)

    comment_xml = f'''
    <w:comment w:id="{comment_id}" w:author="{author}"
               xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
        <w:p>
            <w:r>
                <w:t>{text}</w:t>
            </w:r>
        </w:p>
    </w:comment>
    '''

    # Add comment reference to paragraph
    # (Simplified - actual implementation is more complex)
```

### Step 6: Add Accessibility Features (30 seconds)

**Code Example:**
```python
def add_accessibility_features(doc):
    """Add alt text and proper reading order"""

    # Alt text for images is added when images are inserted

    # Set document language
    doc._element.set(qn('w:lang'), 'en-US')

    # Add document title for screen readers
    settings = doc.settings
    settings.element.set(qn('w:doNotDisplayPageBoundaries'), '1')

    return doc
```

### Step 7: Save and Validate (15 seconds)

**Code Example:**
```python
def save_word_document(doc, output_path):
    """Save and validate Word document"""

    try:
        doc.save(output_path)

        # Verify file was created
        if os.path.exists(output_path):
            file_size = os.path.getsize(output_path)
            if file_size > 0:
                return {
                    'success': True,
                    'path': output_path,
                    'size': file_size
                }

    except Exception as e:
        return {
            'success': False,
            'error': str(e)
        }
```

**Total Time:** 3-5 minutes per book

---

## Quality Verification

### Automated Checks
1. File opens in Microsoft Word
2. All styles properly applied
3. TOC present and updateable
4. All images embedded
5. All headings in correct hierarchy
6. Page count matches expected
7. No corrupt content
8. Accessibility checker passes

### Testing Checklist
- [ ] Opens in Word 2016+
- [ ] Opens in Word Online
- [ ] Opens in Google Docs
- [ ] TOC updates correctly (right-click → Update Field)
- [ ] All images display
- [ ] All tables formatted properly
- [ ] Track changes works
- [ ] Comments can be added
- [ ] Export to PDF works
- [ ] Accessibility checker score 90+
- [ ] Can be converted back to PDF

---

## Tools & Libraries

### Python Libraries
```txt
python-docx==1.1.0
beautifulsoup4==4.12.2
lxml==4.9.3
Pillow==10.0.0
```

### Installation
```bash
pip install python-docx beautifulsoup4 lxml Pillow
```

---

## Storage & Naming

### File Naming Convention
```
{book_id}_{reading_level}_{disability}.docx

Examples:
math_algebra_college_standard.docx
science_biology_elementary_dyslexia.docx
```

---

## Performance Metrics

### Generation Speed
- **Target:** 3 minutes for 200 pages
- **Maximum:** 6 minutes

### File Size
- **Target:** 15-25 MB for 200 pages
- **Maximum:** 50 MB

---

## Related Formats

### PDF Digital
**Difference:** Not editable, for reading only
**When to use instead:** Final distribution, no editing needed

### LaTeX Source
**Difference:** Academic source format, complex equations
**When to use instead:** Academic submissions, complex math
