# Format Blueprint: Large Format Poster / Wall Chart

## Metadata
- **Format ID**: `21_LARGE_FORMAT_POSTER`
- **Format Name**: Large Format Poster / Wall Chart
- **Tier**: 6 (Print Formats - Specialized)
- **File Extension**: `.pdf` (print-ready)
- **Priority**: Medium (visual learning tool)
- **Accessibility Level**: Medium (visual reference)

---

## Overview

### Purpose
Create large-format visual reference materials designed for wall display. Condenses key information into highly visual, at-a-glance formats ideal for classrooms, offices, labs, and study spaces.

### Use Cases
- Educational wall charts for classrooms
- Quick reference guides for professionals
- Laboratory procedure posters
- Historical timelines and infographics
- Periodic tables and formula sheets
- Anatomy and biology diagrams
- Language learning charts (verb conjugations, vocabulary)
- Process flow diagrams
- Safety instructions and protocols
- Motivational and inspirational educational quotes

---

## Technical Specifications

### Standard Poster Sizes

#### Small Posters
- **18" × 24"** (457mm × 610mm) - Common classroom size
- **24" × 36"** (610mm × 914mm) - Standard poster size

#### Medium Posters
- **27" × 40"** (686mm × 1016mm) - Movie poster size
- **36" × 48"** (914mm × 1219mm) - Large reference chart

#### Large Wall Charts
- **40" × 60"** (1016mm × 1524mm) - Classroom wall chart
- **48" × 72"** (1219mm × 1829mm) - Large display

#### Banner Sizes
- **24" × 72"** (610mm × 1829mm) - Vertical timeline
- **36" × 96"** (914mm × 2438mm) - Horizontal timeline

### Paper/Material Options

#### Standard Paper
- **Weight**: 80-100 lb (216-270 gsm) cover stock
- **Finish**: Matte or gloss
- **Durability**: Moderate
- **Cost**: Low

#### Synthetic/Waterproof
- **Material**: Tyvek, Teslin, or synthetic paper
- **Features**: Tear-resistant, waterproof, writable
- **Durability**: High (lab/outdoor use)
- **Cost**: Medium-High

#### Laminated
- **Base**: Standard paper
- **Coating**: 3-5 mil lamination
- **Features**: Wipeable, dry-erase compatible, durable
- **Durability**: Very High
- **Cost**: Medium

#### Canvas/Fabric
- **Material**: Canvas or fabric print
- **Mounting**: Stretcher bars or roll-up
- **Durability**: High
- **Cost**: High (premium presentation)

---

## Design Principles

### Visual Hierarchy
1. **Title**: Largest, most prominent (2-4" height)
2. **Main Sections**: Clear headers (1-2" height)
3. **Content**: Readable from 3-5 feet away
4. **Footnotes**: Smallest, bottom (0.5-1" height)

### Typography Guidelines

#### Viewing Distance: 3-5 feet (classroom/office)
- **Title**: 144-200pt (2-3" height)
- **Section Headers**: 72-96pt (1-1.5" height)
- **Body Text**: 36-48pt (0.5-0.75" height)
- **Captions**: 24-32pt (0.3-0.5" height)

#### Viewing Distance: 6-10 feet (large room)
- **Title**: 200-288pt (3-4" height)
- **Section Headers**: 96-144pt (1.5-2" height)
- **Body Text**: 48-72pt (0.75-1" height)
- **Captions**: 32-48pt (0.5-0.75" height)

### Color Strategy
- **High Contrast**: 7:1 contrast ratio minimum
- **Color Coding**: Consistent use across sections
- **Limited Palette**: 3-5 main colors maximum
- **Colorblind Safe**: Use patterns + colors
- **White Space**: 30-40% of design

---

## Content Types & Layouts

### 1. Reference Chart
**Example**: Periodic Table, Multiplication Table

**Layout:**
- Grid-based structure
- Clear categorization
- Legend/key prominent
- Footnotes at bottom
- Consistent cell sizing

### 2. Timeline
**Example**: Historical Events, Project Phases

**Layout:**
- Horizontal or vertical flow
- Date markers clear
- Events spaced proportionally
- Visual milestones (icons)
- Color-coded periods

### 3. Process Diagram
**Example**: Scientific Method, Product Assembly

**Layout:**
- Numbered steps
- Directional arrows
- Visual icons for each step
- Decision points highlighted
- Start/end clearly marked

### 4. Anatomy/Diagram
**Example**: Human Body Systems, Plant Parts

**Layout:**
- Large central image
- Labeled parts with callouts
- Color-coded systems
- Detailed insets for complexity
- Side panel for descriptions

### 5. Language/Formula Sheet
**Example**: Verb Conjugations, Math Formulas

**Layout:**
- Table/grid format
- Clear categorization
- Examples highlighted
- Exception rules noted
- Practice space (optional)

### 6. Infographic
**Example**: Statistics, Data Visualization

**Layout:**
- Mixed charts (pie, bar, line)
- Large numbers prominent
- Visual metaphors
- Key takeaways highlighted
- Source citations

---

## Production Workflow

### Step 1: Content Condensation
- Identify essential information only
- Remove unnecessary text
- Replace text with visuals where possible
- Create hierarchy of importance
- Design for scanning, not reading

### Step 2: Layout Design
**Software:**
- Adobe Illustrator (vector, scalable)
- Adobe InDesign (text-heavy layouts)
- Canva (templates available)
- Affinity Designer (affordable alternative)

**Template Setup:**
- Document size: Target poster size
- Resolution: 150-300 dpi (lower acceptable for large formats)
- Color mode: CMYK (for print)
- Bleed: 0.25-0.5" all sides
- Safe zone: 0.5" margin from edges

### Step 3: Visual Design
- Create strong focal point (title/main image)
- Use grid system for alignment
- Balance text and visuals (60% visual, 40% text)
- Add icons and illustrations
- Apply consistent color scheme

### Step 4: Typography
- Use bold, sans-serif fonts (Arial, Helvetica, Futura)
- Ensure readability at distance
- Limit to 2-3 font families
- Use weight variations (bold, regular)
- Avoid italics (harder to read)

### Step 5: Print Preparation
**Pre-Flight Check:**
- [ ] All images minimum 150 dpi at full size
- [ ] All fonts converted to outlines (or embedded)
- [ ] Colors in CMYK mode
- [ ] Bleed areas included (0.25-0.5")
- [ ] No critical content in safe zone margin
- [ ] File format: PDF (PDF/X-1a or PDF/X-4)

**Export Settings:**
- Format: PDF
- Quality: High Quality Print or Press Quality
- Compression: Automatic (JPEG) Medium-High
- Marks: Crop marks and bleed marks
- Color: CMYK
- Compatibility: Acrobat 5 (PDF 1.4) or newer

### Step 6: Printing
**Professional Print Shops:**
- Local FedEx/UPS/Staples (up to 36"×48")
- Online: Vistaprint, Printful, Overnight Prints
- Specialized: Banner World, Signs.com

**DIY Large Format:**
- Tile printing (print on multiple sheets, assemble)
- Home plotter (if available)

**Finishing Options:**
- Lamination (3-5 mil gloss or matte)
- Mounting (foam core, gator board)
- Grommets (for hanging)
- Roll-up banner stand

---

## Quality Checklist

### Design Quality
- [ ] Title readable from 10+ feet away
- [ ] Body text readable from 3-5 feet
- [ ] Color contrast sufficient (7:1 minimum)
- [ ] Visual hierarchy clear
- [ ] No pixelated images
- [ ] Consistent alignment
- [ ] White space balanced

### Technical Quality
- [ ] Resolution 150+ dpi at full size
- [ ] CMYK color mode (not RGB)
- [ ] All fonts outlined or embedded
- [ ] Bleed areas included (0.25-0.5")
- [ ] Safe margins respected (0.5")
- [ ] File size manageable (<500MB)

### Content Quality
- [ ] Information accurate
- [ ] Sources cited (if applicable)
- [ ] Content condensed (no walls of text)
- [ ] Key points highlighted
- [ ] Logical flow/organization
- [ ] Copyright cleared for images

### Print Quality
- [ ] Colors vibrant and accurate
- [ ] No banding or streaks
- [ ] Registration aligned (colors match)
- [ ] Trim clean and straight
- [ ] Lamination smooth (no bubbles)
- [ ] Mounting secure (if applicable)

---

## Resolution Guidelines

### Minimum DPI by Size

| Poster Size | Viewing Distance | Minimum DPI |
|-------------|------------------|-------------|
| 18" × 24"   | 3 feet          | 200 dpi     |
| 24" × 36"   | 4 feet          | 150 dpi     |
| 36" × 48"   | 5 feet          | 120 dpi     |
| 48" × 72"   | 8 feet          | 100 dpi     |

**Formula**: DPI = (Desired Quality × 300) / (Viewing Distance in inches / 12)

---

## Example Poster Types

### 1. Periodic Table of Elements
- **Size**: 36" × 48"
- **Layout**: Grid (18 × 7 cells)
- **Content**: Element symbols, atomic numbers, groups
- **Features**: Color-coded by element type
- **Viewers**: Students, chemistry labs

### 2. Historical Timeline (World History)
- **Size**: 24" × 72" (horizontal banner)
- **Layout**: Linear timeline, left to right
- **Content**: Major events 3000 BCE - 2025 CE
- **Features**: Color-coded eras, key figures illustrated
- **Viewers**: History classrooms

### 3. Human Anatomy Chart
- **Size**: 27" × 40"
- **Layout**: Central figure with labeled callouts
- **Content**: Major organs, skeletal system, muscles
- **Features**: Detailed insets, color-coded systems
- **Viewers**: Medical students, health clinics

### 4. Spanish Verb Conjugation Chart
- **Size**: 18" × 24"
- **Layout**: Table format
- **Content**: 50 most common verbs, all tenses
- **Features**: Color-coded regular vs irregular
- **Viewers**: Language learners, classrooms

### 5. Programming Language Syntax Sheet
- **Size**: 24" × 36"
- **Layout**: Sectioned by concept (loops, arrays, etc.)
- **Content**: Code examples, syntax rules
- **Features**: Color-coded by keyword type
- **Viewers**: Programmers, computer labs

---

## AI Model Recommendations

### Content Design
- **Information Condensing**: Claude Sonnet (extract key points)
- **Visual Layout**: GPT-4 (design suggestions)

### Graphics Creation
- **Icons/Illustrations**: DALL-E 3, Midjourney
- **Infographic Design**: Claude Opus (data visualization)

### Quality Assurance
- **Readability Check**: Gemini Pro (typography evaluation)
- **Accuracy Verification**: Claude Sonnet (fact-checking)

---

## Output Structure

### Print-Ready Files
```
poster/
├── Poster_Print_Ready_36x48.pdf       # Full-size print file
├── Poster_Preview_Screen.pdf          # Lower res for review
├── Print_Specifications.txt           # Printer instructions
├── Source_Files/                      # Editable sources
│   ├── Poster_Design.ai              # Illustrator file
│   └── Assets/                       # Images, fonts
└── Thumbnail_Preview.jpg              # Quick reference
```

---

## Metadata to Include

```json
{
  "format": "Large Format Poster",
  "size": "36 x 48 inches",
  "size_mm": "914 x 1219 mm",
  "orientation": "Portrait",
  "content_type": "Reference Chart",
  "resolution": "150 dpi",
  "color_mode": "CMYK",
  "printing": {
    "material": "80 lb cover stock, matte",
    "finish": "Laminated (3 mil matte)",
    "mounting": "None (flat print)"
  },
  "viewing_distance": "3-5 feet",
  "target_audience": [
    "Students (grades 6-12)",
    "Teachers",
    "Professionals"
  ],
  "features": {
    "wipeable": true,
    "waterproof": false,
    "tear_resistant": "moderate"
  },
  "production_cost": "$18.50 per unit"
}
```

---

## Cost Estimation

### Professional Printing (Per Unit)

| Size       | Paper | Laminated | Mounted (Foam Core) |
|------------|-------|-----------|---------------------|
| 18" × 24"  | $8    | $12       | $18                 |
| 24" × 36"  | $12   | $18       | $28                 |
| 36" × 48"  | $18   | $28       | $45                 |
| 48" × 72"  | $35   | $55       | $85                 |

**Bulk Discounts**: 50+ units typically 20-40% off

---

## Mounting & Display Options

### Hanging Methods
- **Grommets**: Metal rings in corners
- **Poster Rails**: Top/bottom wooden or metal rails
- **Frame**: Standard poster frame
- **Magnetic Strips**: Easy swap-out system
- **Push Pins**: Simple, temporary

### Protective Measures
- **Lamination**: Protects from moisture, tears
- **UV-Resistant Ink**: Prevents fading
- **Sealed Edges**: Extends lamination life

---

## Advantages

1. **Visual Impact**: Large, attention-grabbing
2. **Quick Reference**: Information at-a-glance
3. **Durable**: Lamination options for longevity
4. **Versatile**: Classrooms, offices, homes, labs
5. **Affordable**: Lower cost per viewer than books
6. **Always Visible**: Constant reinforcement
7. **Shareable**: Easy to distribute in classrooms

---

## Limitations

1. **Limited Detail**: Space constraints
2. **Fixed Information**: Can't update easily
3. **Damage Risk**: Can tear, fade, or crease
4. **Storage**: Bulky to store and ship
5. **Not Portable**: Not practical to carry

---

## Best Practices

1. **Less Is More**: Prioritize essential information
2. **Test Readability**: Print sample at 50% scale, view from distance
3. **Color-Code Consistently**: Use legend
4. **Professional Printing**: Worth the investment
5. **Laminate**: Extends life 5-10x
6. **Use Vectors**: Scalable without quality loss
7. **Cite Sources**: Build credibility
8. **Consider Lighting**: Design for wall display conditions

---

## Related Formats

- **10_LARGE_PRINT_PDF.md**: Enlarged text book version
- **20_BOOKLET_FORMAT.md**: Portable alternative
- **04_EPUB_30.md**: Digital interactive reference

---

## Update History
- **2025-12-03**: Initial blueprint created
