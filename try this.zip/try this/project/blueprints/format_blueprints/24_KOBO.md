# Format Blueprint: Kobo EPUB Format

## Metadata
- **Format ID**: `24_KOBO`
- **Format Name**: Kobo Optimized EPUB
- **Tier**: 7 (Platform-Specific Formats)
- **File Extension**: `.epub`
- **Priority**: Medium-High (global reach, independent alternative)
- **Accessibility Level**: High

---

## Overview

### Purpose
Create an optimized EPUB for Kobo, the leading independent ebook retailer. Kobo supports standard EPUB with excellent compatibility and is particularly strong in Canada, Japan, and international markets.

### Use Cases
- Alternative to Amazon (DRM-free option)
- International distribution (190+ countries)
- Library partnerships (OverDrive integration)
- Reader-friendly platform (no ecosystem lock-in)
- Independent authors and publishers
- Walmart partnership (US distribution)

---

## Platform Overview

### Kobo Stats
- **Reach**: 190+ countries
- **Devices**: Kobo eReaders, iOS, Android, Windows, Web
- **Market Share**: #4 globally, #2 in Canada
- **Parent**: Rakuten (Japanese e-commerce giant)
- **Unique**: Strong library integration, DRM-free options
- **Partnership**: Walmart (US), Indigo (Canada)

### Key Advantages
- Standard EPUB (no proprietary format)
- DRM-free option available
- Excellent EPUB compatibility
- Strong international presence
- Library integration (OverDrive)
- Fair revenue split (45% commission)
- No exclusivity requirements

---

## Technical Specifications

### Accepted Formats
1. **EPUB 3.0.1** (Recommended)
2. **EPUB 2.0.1** (Supported)
3. **PDF** (Supported for fixed layout only)
4. **Kobo KEPUB** (proprietary enhancement - optional)

### Standard EPUB Requirements

#### File Structure
```
book.epub (ZIP archive)
├── mimetype
├── META-INF/
│   └── container.xml
├── OEBPS/
│   ├── content.opf
│   ├── toc.ncx (EPUB 2)
│   ├── nav.xhtml (EPUB 3)
│   ├── chapters/
│   ├── images/
│   └── styles/
```

#### content.opf Metadata (Kobo-optimized)
```xml
<?xml version="1.0" encoding="UTF-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="pub-id">
  <metadata xmlns:dc="http://purl.org/dc/elements/1.1/">

    <!-- Required -->
    <dc:title>Book Title</dc:title>
    <dc:creator>Author Name</dc:creator>
    <dc:identifier id="pub-id">urn:uuid:12345678</dc:identifier>
    <dc:language>en</dc:language>
    <meta property="dcterms:modified">2025-12-03T00:00:00Z</meta>

    <!-- Highly Recommended -->
    <dc:description>Compelling book description</dc:description>
    <dc:publisher>Publisher Name</dc:publisher>
    <dc:date>2025-12-03</dc:date>
    <dc:subject>Subject / Category</dc:subject>
    <dc:rights>Copyright statement</dc:rights>

    <!-- Cover -->
    <meta name="cover" content="cover-image"/>

    <!-- Series Information (if applicable) -->
    <meta property="belongs-to-collection" id="series">Series Name</meta>
    <meta refines="#series" property="collection-type">series</meta>
    <meta refines="#series" property="group-position">1</meta>

  </metadata>

  <manifest>
    <item id="cover-image" href="images/cover.jpg" media-type="image/jpeg" properties="cover-image"/>
    <item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/>
    <item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>
    <!-- Content items -->
  </manifest>

  <spine toc="ncx">
    <itemref idref="cover"/>
    <itemref idref="chapter01"/>
  </spine>

  <guide>
    <reference type="cover" title="Cover" href="cover.xhtml"/>
    <reference type="toc" title="Table of Contents" href="nav.xhtml"/>
  </guide>
</package>
```

---

## Kobo Specific Optimizations

### 1. Cover Image
**Requirements:**
- **Minimum**: 1400px (shortest side)
- **Recommended**: 1600px × 2400px
- **Maximum**: 10000px × 10000px
- **Aspect Ratio**: 1:1.5 (2:3 ratio ideal)
- **Format**: JPEG (preferred) or PNG
- **File Size**: <5 MB
- **Color**: RGB

**Best Practices:**
- High-resolution for e-ink and color displays
- Readable at thumbnail size
- Professional typography
- Avoid excessive text

### 2. KEPUB Enhancement (Optional)
Kobo's proprietary enhancement to EPUB for better reading experience on Kobo devices.

**Benefits:**
- Better hyphenation
- Reading statistics (words read, time remaining)
- Improved page turning
- Better footnote handling
- Enhanced typography

**Creation:**
- Upload standard EPUB to Kobo Writing Life
- Kobo automatically converts to KEPUB
- No manual KEPUB creation needed

### 3. Table of Contents
**Requirements:**
- Both toc.ncx (EPUB 2) and nav.xhtml (EPUB 3)
- Hierarchical structure
- All major sections included
- Logical ordering

**Kobo-Specific Feature:**
- Kobo displays ToC prominently
- Users navigate via "Table of Contents" button
- Clear chapter titles important

### 4. CSS & Typography
**Kobo eReader Considerations:**
- E-ink displays (grayscale)
- Various screen sizes (6" to 8" models)
- User-adjustable fonts and sizes
- Night mode support

**CSS Best Practices:**
```css
body {
  margin: 0;
  padding: 0;
  font-family: serif; /* Let user override */
  line-height: 1.5;
}

h1, h2, h3 {
  page-break-after: avoid;
  page-break-inside: avoid;
}

img {
  max-width: 100%;
  height: auto;
}

/* Avoid fixed font sizes */
p {
  font-size: 1em; /* Relative sizing */
  margin: 1em 0;
}
```

---

## Quality Checklist

### EPUB Validation
- [ ] Passes EPUBCheck 4.0+
- [ ] All internal links functional
- [ ] Cover image embedded
- [ ] ToC complete (ncx + nav.xhtml)
- [ ] Metadata complete
- [ ] No missing chapters

### Kobo Specific
- [ ] Cover 1400px+ (shortest side)
- [ ] Description under 4000 characters
- [ ] ISBN included (if available)
- [ ] Series metadata (if part of series)
- [ ] BISAC categories assigned
- [ ] Age rating set (if applicable)

### Content Quality
- [ ] Images 300 dpi (source)
- [ ] Equations readable
- [ ] Hyperlinks working
- [ ] No formatting errors
- [ ] Tested on Kobo Preview tool

### Accessibility
- [ ] Alt text for all images
- [ ] Semantic HTML
- [ ] Logical reading order
- [ ] Sufficient color contrast
- [ ] Screen reader compatible

---

## Upload Process

### Step 1: Create Kobo Account
**Access**: kobo.com/writinglife

**Requirements:**
- Author/publisher account (free)
- Tax information (W-9 or W-8)
- Banking details for royalties

### Step 2: Prepare Files
- Validated EPUB file
- Cover image (1600×2400+)
- Book description
- ISBN (optional but recommended)
- Author bio

### Step 3: Upload to Kobo Writing Life
**Book Details:**
- Title and subtitle
- Author name(s)
- Publisher (can be author name)
- Description (up to 4000 characters)
- Language
- Publication date
- ISBN (optional)
- Series information (if applicable)

**Categories:**
- Select up to 3 BISAC categories
- Add up to 7 keywords
- Set age rating

**Pricing:**
- Set price per territory
- Choose currencies (40+ supported)
- Pricing must be $1.99-$299.99 USD equivalent
- Enrollment in Kobo Plus (subscription service)

### Step 4: Territories & Distribution
- Select countries (190+ available)
- Set specific pricing per region
- Choose Kobo Plus eligibility
- Library distribution (OverDrive)

### Step 5: Preview & Publish
- Preview in Kobo Writing Life
- Download sample to test on device
- Submit for publication
- Live within 24-48 hours typically

---

## Testing Checklist

### Device Testing
- [ ] Kobo eReader (e-ink device)
- [ ] Kobo app on iOS
- [ ] Kobo app on Android
- [ ] Kobo Desktop (Windows/Mac)
- [ ] Web reader (kobo.com)

### Functionality Testing
- [ ] Table of contents navigation
- [ ] Hyperlinks functional
- [ ] Images display correctly
- [ ] Text reflows at different sizes
- [ ] Night mode (dark theme) readable
- [ ] Bookmarks work
- [ ] Highlights work
- [ ] Search functional

---

## Kobo Platform Features

### 1. Kobo Plus
- Subscription service (like Kindle Unlimited)
- Authors earn per page read
- Additional revenue stream
- Opt-in when uploading

### 2. OverDrive Integration
- Kobo partners with OverDrive (library platform)
- Books available for library lending
- Additional reach to libraries worldwide
- Royalties per checkout

### 3. Reading Life
- Kobo's achievement/gamification system
- Readers earn awards for reading
- Track reading statistics
- Social features

### 4. Pocket Integration
- Read saved articles and ebooks together
- Seamless integration
- Sync across devices

### 5. Built-in Dictionary
- Multi-language dictionaries
- One-tap word lookup
- Translation support

---

## Revenue & Pricing

### Revenue Share
- **Publisher receives**: 45% (list price $9.99+)
- **Publisher receives**: 45% (list price $1.99-$9.98)
- **Publisher receives**: 45% (list price below $1.99)
- **Kobo keeps**: 55%
- **Payment**: Quarterly, $100 minimum threshold
- **Kobo Plus**: Separate calculation (per page read)

### Pricing Strategy
- Competitive pricing vs. Amazon
- Consider Kobo Plus enrollment (discoverability)
- Regional pricing adjustments
- Promotional pricing tools available

---

## AI Model Recommendations

### Metadata Optimization
- **Description Writing**: Claude Sonnet (compelling copy)
- **Keyword Selection**: GPT-4 (SEO optimization)
- **Category Selection**: Gemini Pro (BISAC matching)

### Quality Assurance
- **EPUB Validation**: Claude Opus (error detection)
- **Device Testing**: GPT-4 (checklist verification)

---

## Output Structure

### Deliverables
```
kobo/
├── book_kobo_optimized.epub        # Validated EPUB
├── cover_1600x2400.jpg             # High-res cover
├── book_description.txt            # Marketing copy
├── metadata.txt                    # All metadata fields
├── bisac_categories.txt            # Selected categories
├── keywords.txt                    # SEO keywords
└── kobo_upload_guide.pdf           # Step-by-step instructions
```

---

## Metadata to Include

```json
{
  "format": "Kobo EPUB",
  "epub_version": "3.0.1",
  "file_size_mb": 14.2,
  "isbn_13": "978-1-234567-89-0",
  "title": "Book Title",
  "subtitle": "Subtitle",
  "author": "Author Name",
  "publisher": "Publisher Name",
  "publication_date": "2025-12-03",
  "language": "en",
  "page_count": 324,
  "bisac_categories": [
    "EDU029000",
    "COM051010",
    "REF025000"
  ],
  "keywords": [
    "education",
    "programming",
    "reference"
  ],
  "cover_specifications": {
    "width": 1600,
    "height": 2400,
    "format": "JPEG"
  },
  "pricing": {
    "usd": 19.99,
    "eur": 18.99,
    "cad": 25.99
  },
  "distribution": {
    "countries": 190,
    "kobo_plus_enrolled": true,
    "overdrive_enabled": true
  }
}
```

---

## Advantages

1. **Standard EPUB**: No proprietary format
2. **DRM-Free Option**: Publisher choice
3. **International**: Strong global presence
4. **Fair Commission**: 45% is competitive
5. **Library Integration**: OverDrive partnership
6. **No Exclusivity**: Sell everywhere
7. **Independent**: Alternative to Amazon

---

## Best Practices

1. **Standard EPUB**: Focus on EPUB quality, Kobo handles rest
2. **Test on Device**: Kobo devices have unique characteristics
3. **Kobo Plus**: Consider enrollment for discoverability
4. **International Pricing**: Adjust for local markets
5. **Library Distribution**: Enable OverDrive
6. **Regular Updates**: Easy to publish revisions
7. **Series Tagging**: Use series metadata properly

---

## Related Formats

- **04_EPUB_30.md**: Standard EPUB base
- **22_GOOGLE_PLAY_BOOKS.md**: Google Play optimization
- **23_APPLE_BOOKS.md**: Apple Books optimization
- **25_NOOK.md**: Nook-specific EPUB

---

## Update History
- **2025-12-03**: Initial blueprint created
