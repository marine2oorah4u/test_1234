# Format Blueprint: Booklet Format (Saddle-Stitched)

## Metadata
- **Format ID**: `20_BOOKLET_FORMAT`
- **Format Name**: Saddle-Stitched Booklet
- **Tier**: 6 (Print Formats - Specialized)
- **File Extension**: `.pdf` (print-ready)
- **Priority**: Medium (budget-friendly print)
- **Accessibility Level**: Medium-High (portable format)

---

## Overview

### Purpose
Create a compact, folded booklet format bound with staples through the spine (saddle-stitched). Cost-effective for short to medium-length content, conferences, workshops, and quick reference guides.

### Use Cases
- Workshop handouts and training materials
- Conference proceedings and session materials
- Quick reference guides and cheat sheets
- Student study guides and course packets
- Event programs and schedules
- Product catalogs and brochures
- Church bulletins and newsletters
- Trade show takeaways

---

## Technical Specifications

### Standard Booklet Sizes

#### Letter Half-Fold (Most Common)
- **Finished Size**: 5.5" × 8.5" (140mm × 216mm)
- **Flat Size**: 11" × 8.5" (letter landscape)
- **Page Count**: 8-64 pages (multiples of 4)
- **Orientation**: Portrait when folded

#### Tabloid Half-Fold
- **Finished Size**: 8.5" × 11" (letter portrait size)
- **Flat Size**: 11" × 17" (tabloid landscape)
- **Page Count**: 8-80 pages (multiples of 4)
- **Orientation**: Portrait when folded

#### A4 Half-Fold (International)
- **Finished Size**: 148mm × 210mm (A5)
- **Flat Size**: 297mm × 210mm (A4 landscape)
- **Page Count**: 8-64 pages (multiples of 4)
- **Orientation**: Portrait when folded

#### Digest Size
- **Finished Size**: 5.5" × 8" (140mm × 203mm)
- **Flat Size**: 11" × 8"
- **Page Count**: 8-48 pages
- **Orientation**: Portrait when folded

### Binding Specifications

#### Saddle-Stitch
- **Method**: Staples through folded spine
- **Staple Count**: 2 staples (standard) or 3 (longer spines)
- **Page Limit**: 64 pages maximum (16 sheets)
- **Advantage**: Lays flat when open

#### Wire-O / Spiral (Alternative)
- **Method**: Wire or plastic coil binding
- **Page Limit**: Up to 200 pages
- **Advantage**: 360° rotation, durable

---

## Page Layout Design

### Critical Concepts

#### 1. Imposition (Page Arrangement)
Booklets require special page ordering:
- Pages print in "spreads" (2 pages side-by-side)
- **Outer spread**: Cover (p1) + Back (p last)
- **Inner spreads**: Pages arranged so they're sequential when folded

**Example 8-Page Booklet:**
```
Sheet 1 (Outer):
  Front side: Page 8 | Page 1 (cover)
  Back side:  Page 2 | Page 7

Sheet 2 (Inner):
  Front side: Page 6 | Page 3
  Back side:  Page 4 | Page 5
```

#### 2. Creep / Shingling
- **Issue**: Inner pages "creep" outward when folded
- **Solution**: Adjust page margins progressively
- **Adjustment**: 0.0625" (1.5mm) per sheet typically

#### 3. Margins
- **Outer Margin**: 0.5" minimum
- **Inner Margin (Spine)**: 0.625" (accounts for fold)
- **Top/Bottom**: 0.5" minimum
- **Bleed**: 0.125" (if full-bleed design)

---

## Production Workflow

### Step 1: Content Planning
- Calculate total pages (must be multiple of 4)
- Add blank pages if needed to reach multiple of 4
- Plan front cover, inside covers, back cover
- Design spreads, not individual pages

### Step 2: Page Count Calculation
```
Total Content Pages + Front Cover + Back Cover + Inside Covers = Total

Example:
- 28 content pages
- 1 front cover
- 1 back cover
- 2 inside covers (inside front + inside back)
= 32 pages total ✓ (divisible by 4)
```

### Step 3: Template Setup (InDesign/Illustrator)

**Document Settings:**
- **Page Size**: Flat size (e.g., 11" × 8.5" for letter half-fold)
- **Pages**: Total page count
- **Facing Pages**: Enabled
- **Saddle Stitch**: Enable in Page Setup
- **Margins**: 0.5" (outer), 0.625" (inner)
- **Bleed**: 0.125" (if applicable)

### Step 4: Content Layout
- Design spreads as reader will see them
- Account for spine fold (avoid centered text)
- Keep important content away from spine (0.25" safe zone)
- Balance left/right pages visually

### Step 5: Imposition
**Option A: Software Imposition**
- Adobe InDesign: Use "Print Booklet" feature
- Adobe Acrobat: Booklet printing
- Specialized tools: Quite Imposing Plus, PitStop

**Option B: Manual Imposition**
Calculate page order:
```
For N pages, pages on same sheet:
Sheet 1: (1, N), (2, N-1)
Sheet 2: (3, N-2), (4, N-3)
...continue pattern
```

### Step 6: Print-Ready PDF Export

**Settings:**
- **Format**: PDF/X-1a or PDF/X-4
- **Color**: CMYK
- **Resolution**: 300 dpi
- **Fonts**: Embedded
- **Crop/Bleed Marks**: Include
- **Spreads**: Export as spreads (2-up)

### Step 7: Print Production
- Print on both sides (duplex)
- Use proper paper weight (60-80 lb text)
- Fold each sheet precisely at center
- Collate sheets in order (outer to inner)
- Staple through spine (2-3 staples)
- Trim edges if needed (for bleed)

---

## Quality Checklist

### Page Layout
- [ ] Total pages divisible by 4
- [ ] Pages in correct imposition order
- [ ] Spine safe zone respected (0.25" each side of fold)
- [ ] Margins appropriate (0.5" outer, 0.625" inner)
- [ ] Bleeds extend 0.125" beyond trim
- [ ] No important content in fold area

### Typography
- [ ] Font size readable (10pt minimum)
- [ ] Line spacing adequate (1.2-1.5)
- [ ] Text not too close to spine
- [ ] Headers/footers in safe zones
- [ ] Page numbers excluded from cover/inside covers

### Design
- [ ] Cover visually distinct
- [ ] Spreads balanced (left/right)
- [ ] Images span spine correctly (if designed to)
- [ ] Color consistent across pages
- [ ] Sufficient contrast for readability

### Technical
- [ ] PDF in correct format (PDF/X-1a or X-4)
- [ ] Images 300 dpi minimum
- [ ] Fonts embedded
- [ ] Color mode CMYK (for print)
- [ ] File size manageable (<50MB)

### Print Production
- [ ] Paper weight appropriate (60-100 lb)
- [ ] Duplex printing aligned (front to back)
- [ ] Fold crisp and straight
- [ ] Staples properly positioned
- [ ] Trimming accurate (if applicable)

---

## Page Count Guidelines

### Maximum Pages by Paper Weight

| Paper Weight | Max Pages (Saddle-Stitch) |
|--------------|---------------------------|
| 60 lb text   | 64 pages                 |
| 70 lb text   | 48 pages                 |
| 80 lb text   | 40 pages                 |
| 100 lb text  | 28 pages                 |

**Exceed limits?** Consider:
- Perfect binding (glued spine)
- Wire-O or spiral binding
- Breaking into multiple volumes

---

## Cover Design Considerations

### Front Cover Must Include:
- Title (large, clear)
- Author or organization
- Eye-catching graphic
- Version/date (if applicable)

### Back Cover May Include:
- Summary or description
- ISBN/barcode (if published)
- Contact information
- Price (if applicable)
- QR code for digital resources

### Inside Covers:
- Table of contents (inside front)
- Additional resources (inside back)
- Copyright information
- Contact details

---

## Cost-Effective Design Tips

1. **Black & White Interior**: Use color only on cover
2. **Standard Sizes**: Use letter or tabloid (cheaper)
3. **Minimize Pages**: Stay under 32 pages if possible
4. **Simple Graphics**: Avoid heavy ink coverage
5. **Digital Printing**: For short runs (<500 copies)
6. **Bulk Stock**: Use standard paper weights (60-70 lb)

---

## Printing Specifications Sheet

```
BOOKLET PRINTING SPECIFICATIONS
--------------------------------

Title: [Book Title]
Finished Size: 5.5" × 8.5" (letter half-fold)
Total Pages: 32 pages

COVER:
- Pages: 4 (front, inside front, inside back, back)
- Stock: 80 lb cover, gloss
- Printing: 4/4 (full color both sides)
- Coating: Gloss UV on outside only

INTERIOR:
- Pages: 28 pages
- Stock: 60 lb text, white
- Printing: 1/1 (black both sides)
- Coating: None

BINDING:
- Method: Saddle-stitch
- Staples: 2 staples through spine
- Position: Centered on 8.5" spine

FINISHING:
- Fold: Machine-fold at 5.5" (center)
- Trim: Flush cut (no bleed)
- Corners: Square

QUANTITY: 500 copies

DELIVERY:
- Format: Finished booklets, boxed
- Packaging: 25 per bundle, 500 total
```

---

## InDesign "Print Booklet" Settings

```
File → Print Booklet

Booklet Type: 2-up Saddle Stitch
Page Range: All
Margins: Auto

Print Settings:
- Printer: [Select printer or PDF]
- Paper Size: 11 × 8.5" (for 5.5 × 8.5" finished)
- Orientation: Landscape
- Pages Per Sheet: 2
- Binding: Left (Short Edge)

Bleed: 0.125" all sides (if needed)
```

---

## AI Model Recommendations

### Layout Design
- **Imposition Planning**: Claude Sonnet (page ordering)
- **Cover Design**: DALL-E or Midjourney (graphics)

### Content Adaptation
- **Content Condensing**: Gemini Pro (fit page count)
- **Visual Design**: GPT-4 (layout suggestions)

### Quality Assurance
- **Page Order Verification**: Claude Opus (sequence checking)
- **Print Readiness**: GPT-4 (technical validation)

---

## Output Structure

### Print-Ready Files
```
booklet/
├── Booklet_Imposed_Print_Ready.pdf  # Ready for printer
├── Booklet_Sequential_Review.pdf    # For proofing
├── Print_Specifications.txt         # Printer instructions
└── Assembly_Instructions.pdf        # DIY assembly guide
```

---

## Metadata to Include

```json
{
  "format": "Saddle-Stitched Booklet",
  "finished_size": "5.5 x 8.5 inches",
  "flat_size": "11 x 8.5 inches",
  "total_pages": 32,
  "binding": "Saddle-stitch (2 staples)",
  "paper": {
    "cover": "80 lb cover, gloss coated",
    "interior": "60 lb text, uncoated"
  },
  "printing": {
    "cover": "4/4 full color",
    "interior": "1/1 black and white"
  },
  "production": {
    "method": "Digital printing",
    "quantity": 500,
    "cost_per_unit": "$2.75"
  },
  "features": {
    "lays_flat": true,
    "portable": true,
    "cost_effective": true
  }
}
```

---

## Advantages

1. **Cost-Effective**: Cheap to produce
2. **Quick Turnaround**: Fast printing
3. **Lays Flat**: Easy to read and reference
4. **Portable**: Compact, easy to carry
5. **Professional**: Clean, finished look
6. **Flexible**: Various sizes available
7. **No Glue**: Environmentally friendlier

---

## Limitations

1. **Page Limit**: Maximum 64 pages
2. **Spine Restrictions**: Can't print on spine
3. **Durability**: Less durable than perfect binding
4. **Creep Issues**: Inner pages shift slightly
5. **Fold Stress**: Center fold can crack over time

---

## Best Practices

1. **Keep It Short**: Under 48 pages ideal
2. **Test Print**: Always print proof copy
3. **Check Imposition**: Verify page order before printing
4. **Quality Paper**: Use 60-80 lb text for durability
5. **Design Spreads**: Think in two-page layouts
6. **Safe Zones**: Keep critical content away from spine
7. **Professional Printer**: Use for quantities >100

---

## Related Formats

- **01_PDF_PRINT_300DPI.md**: Standard bound book
- **19_BINDER_BOOK.md**: Modular alternative
- **21_LARGE_FORMAT_POSTER.md**: Single-sheet reference

---

## Update History
- **2025-12-03**: Initial blueprint created
