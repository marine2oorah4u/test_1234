# Format Blueprint: LaTeX Source

## Basic Information
- **File Extension:** `.tex` (+ compiled PDF)
- **Format Type:** Academic / Source Code
- **Tier:** 2 (Academic - Conditional)
- **Priority:** HIGH for academic/research books
- **Generation Time:** 4-6 minutes per 200 pages
- **File Size Estimate:** 5-10 MB (source), 40-60 MB (compiled PDF)

---

## Purpose & Use Case

**Primary Purpose:**
Complete LaTeX source code for academic publishing, journals, and arxiv.org submissions. Industry standard for academic mathematics, physics, computer science, and research papers.

**Best Used For:**
- Academic journals (IEEE, ACM, Springer, Elsevier)
- arxiv.org submissions
- Mathematical and scientific textbooks
- Research papers and theses
- Collaborative academic writing
- Version-controlled academic documents
- Books requiring complex equations
- Academic peer review

**Distribution Channels:**
- arxiv.org (preprint server)
- Academic journals
- University repositories
- GitHub (academic projects)
- Overleaf (collaborative editing)
- Direct download for researchers

**Use When:**
- Book contains complex mathematical equations
- Target audience is academic/research
- Submitting to academic journals
- Need precise typographic control
- Collaborating with academics
- Publishing research content

---

## Technical Specifications

### Core Requirements
- **LaTeX Version:** LaTeX2e or XeLaTeX
- **Document Class:** book, report, or article
- **Encoding:** UTF-8
- **Bibliography:** BibTeX or BibLaTeX
- **Equations:** amsmath, amssymb packages
- **Graphics:** graphicx, tikz for diagrams
- **References:** hyperref for cross-references
- **Compilation:** PDFLaTeX or XeLaTeX
- **Output:** Both .tex source AND compiled PDF

### File Structure
```
book-latex/
├── main.tex (main document)
├── preamble.tex (packages and settings)
├── chapters/
│   ├── chapter01.tex
│   ├── chapter02.tex
│   └── ...
├── figures/
│   ├── figure01.pdf (vector graphics preferred)
│   ├── figure02.png
│   └── ...
├── tables/
│   ├── table01.tex
│   └── ...
├── bibliography.bib (BibTeX database)
├── custom-commands.tex (custom macros)
├── Makefile (compilation script)
├── README.md (compilation instructions)
└── compiled/
    └── main.pdf (compiled output)
```

### Quality Standards
- **Compilation:** Must compile without errors
- **Warnings:** Minimize overfull/underfull box warnings
- **References:** All citations resolved
- **Equations:** Properly formatted and numbered
- **Cross-references:** All working
- **Bibliography:** Complete and formatted correctly
- **Figures:** Vector format (PDF) where possible
- **Tables:** Properly formatted with booktabs
- **Code Style:** Consistent indentation and formatting

---

## Generation Process

### Step 1: Convert Content to LaTeX (2 minutes)

**Code Example:**
```python
def generate_latex_document(book_data):
    """Convert book content to LaTeX format"""

    # Main document structure
    main_tex = r'''\documentclass[11pt,letterpaper,oneside]{book}

% Encoding and fonts
\usepackage[utf8]{inputenc}
\usepackage[T1]{fontenc}
\usepackage{lmodern}

% Mathematics
\usepackage{amsmath,amssymb,amsthm}
\usepackage{mathtools}

% Graphics and colors
\usepackage{graphicx}
\usepackage[svgnames]{xcolor}
\usepackage{tikz}

% Tables
\usepackage{booktabs}
\usepackage{multirow}
\usepackage{longtable}

% Typography
\usepackage{microtype}
\usepackage{setspace}

% Hyperlinks and references
\usepackage[
    colorlinks=true,
    linkcolor=blue,
    citecolor=red,
    urlcolor=blue
]{hyperref}
\usepackage{cleveref}

% Bibliography
\usepackage[backend=bibtex,style=numeric,sorting=none]{biblatex}
\addbibresource{bibliography.bib}

% Custom commands
\input{custom-commands}

% Metadata
\title{''' + book_data['title'] + r'''}
\author{''' + book_data['author'] + r'''}
\date{''' + book_data['date'] + r'''}

\begin{document}

\frontmatter
\maketitle

\tableofcontents

\mainmatter
'''

    # Add chapters
    for chapter in book_data['chapters']:
        main_tex += f"\\input{{chapters/{chapter['filename']}}}\n"

    # Back matter
    main_tex += r'''
\backmatter

% Bibliography
\printbibliography

\end{document}
'''

    return main_tex
```

### Step 2: Convert HTML/Markdown to LaTeX (1 minute)

**Code Example:**
```python
from bs4 import BeautifulSoup
import re

def html_to_latex(html_content):
    """Convert HTML content to LaTeX"""
    soup = BeautifulSoup(html_content, 'html.parser')
    latex = ""

    for element in soup.descendants:
        if element.name == 'h1':
            latex += f"\\chapter{{{element.text}}}\n"
        elif element.name == 'h2':
            latex += f"\\section{{{element.text}}}\n"
        elif element.name == 'h3':
            latex += f"\\subsection{{{element.text}}}\n"
        elif element.name == 'p':
            text = element.text
            # Escape special LaTeX characters
            text = escape_latex(text)
            latex += f"{text}\n\n"
        elif element.name == 'strong' or element.name == 'b':
            latex += f"\\textbf{{{element.text}}}"
        elif element.name == 'em' or element.name == 'i':
            latex += f"\\textit{{{element.text}}}"
        elif element.name == 'img':
            caption = element.get('alt', '')
            src = element.get('src')
            latex += f"\\begin{{figure}}[htbp]\n"
            latex += f"  \\centering\n"
            latex += f"  \\includegraphics[width=0.8\\textwidth]{{{src}}}\n"
            latex += f"  \\caption{{{caption}}}\n"
            latex += f"\\end{{figure}}\n\n"

    return latex

def escape_latex(text):
    """Escape special LaTeX characters"""
    replacements = {
        '\\': r'\textbackslash{}',
        '&': r'\&',
        '%': r'\%',
        '$': r'\$',
        '#': r'\#',
        '_': r'\_',
        '{': r'\{',
        '}': r'\}',
        '~': r'\textasciitilde{}',
        '^': r'\textasciicircum{}'
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return text
```

### Step 3: Convert Equations to LaTeX (30 seconds)

**Code Example:**
```python
def convert_equations(text):
    """Convert MathML or ASCII math to LaTeX"""

    # Inline math: $...$
    text = re.sub(r'\$([^\$]+)\$', r'$\1$', text)

    # Display math: $$...$$
    text = re.sub(r'\$\$([^\$]+)\$\$',
                  r'\\begin{equation}\n\1\n\\end{equation}',
                  text)

    # Common equation conversions
    conversions = {
        '×': r'\times',
        '÷': r'\div',
        '±': r'\pm',
        '≠': r'\neq',
        '≤': r'\leq',
        '≥': r'\geq',
        '∞': r'\infty',
        '∑': r'\sum',
        '∫': r'\int',
        '√': r'\sqrt',
        'α': r'\alpha',
        'β': r'\beta',
        'γ': r'\gamma',
        'π': r'\pi'
    }

    for symbol, latex in conversions.items():
        text = text.replace(symbol, latex)

    return text
```

### Step 4: Generate Bibliography (30 seconds)

**Code Example:**
```python
def generate_bibtex(references):
    """Generate BibTeX bibliography"""
    bibtex = ""

    for i, ref in enumerate(references):
        entry_type = ref.get('type', 'article')
        cite_key = ref.get('key', f'ref{i+1}')

        bibtex += f"@{entry_type}{{{cite_key},\n"

        fields = {
            'author': ref.get('author'),
            'title': ref.get('title'),
            'journal': ref.get('journal'),
            'year': ref.get('year'),
            'volume': ref.get('volume'),
            'pages': ref.get('pages'),
            'publisher': ref.get('publisher'),
            'doi': ref.get('doi'),
            'url': ref.get('url')
        }

        for field, value in fields.items():
            if value:
                bibtex += f"  {field} = {{{value}}},\n"

        bibtex += "}\n\n"

    return bibtex
```

### Step 5: Compile LaTeX to PDF (1-2 minutes)

**Code Example:**
```python
import subprocess
import os

def compile_latex(tex_file_path, output_dir):
    """Compile LaTeX to PDF using pdflatex"""

    # Change to document directory
    original_dir = os.getcwd()
    doc_dir = os.path.dirname(tex_file_path)
    os.chdir(doc_dir)

    tex_file = os.path.basename(tex_file_path)

    try:
        # Run pdflatex (twice for references)
        for i in range(2):
            result = subprocess.run(
                ['pdflatex', '-interaction=nonstopmode', tex_file],
                capture_output=True,
                text=True,
                timeout=120
            )

            if result.returncode != 0:
                print(f"LaTeX compilation error:\n{result.stdout}")
                return None

        # Run bibtex if bibliography exists
        if os.path.exists('bibliography.bib'):
            subprocess.run(['bibtex', tex_file.replace('.tex', '')],
                          capture_output=True)

            # Run pdflatex again (twice for bibliography)
            for i in range(2):
                subprocess.run(
                    ['pdflatex', '-interaction=nonstopmode', tex_file],
                    capture_output=True
                )

        pdf_file = tex_file.replace('.tex', '.pdf')

        if os.path.exists(pdf_file):
            # Move PDF to output directory
            output_pdf = os.path.join(output_dir, pdf_file)
            os.rename(pdf_file, output_pdf)
            return output_pdf
        else:
            return None

    finally:
        os.chdir(original_dir)
```

### Step 6: Package Source Files (30 seconds)

**Code Example:**
```python
import zipfile

def package_latex_source(source_dir, output_path):
    """Package all LaTeX source files into ZIP"""

    with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(source_dir):
            for file in files:
                if file.endswith(('.tex', '.bib', '.pdf', '.png', '.jpg')):
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, source_dir)
                    zipf.write(file_path, arcname)

        # Add README with compilation instructions
        readme = """# LaTeX Source Compilation Instructions

## Requirements
- TeX Live 2020+ or MiKTeX
- pdflatex or xelatex
- bibtex or biber

## Compilation
```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

Or use the provided Makefile:
```bash
make
```

## Overleaf
Upload the entire ZIP file to Overleaf for online compilation.
"""
        zipf.writestr('README.md', readme)

    return output_path
```

**Total Time:** 4-6 minutes per book

---

## Quality Verification

### Automated Checks
1. LaTeX source compiles without errors
2. All figures referenced exist
3. All citations resolved
4. All cross-references working
5. PDF generated successfully
6. No undefined references
7. All equations properly formatted
8. Bibliography complete

### Testing Checklist
- [ ] Compiles with pdflatex
- [ ] Compiles with xelatex (if using Unicode)
- [ ] All chapters included
- [ ] All figures display correctly
- [ ] All tables formatted properly
- [ ] All equations numbered correctly
- [ ] Bibliography complete
- [ ] Cross-references working
- [ ] PDF looks professional
- [ ] Uploads to arxiv.org successfully
- [ ] Uploads to Overleaf successfully

---

## Tools & Libraries

### Required Software
- **TeX Live** (Linux/Mac) or **MiKTeX** (Windows)
- **Python 3.9+**
- **Pandoc** (optional, for conversion)

### Python Libraries
```txt
beautifulsoup4==4.12.2
lxml==4.9.3
```

### LaTeX Packages (installed with TeX Live)
```
amsmath, amssymb, amsthm, mathtools
graphicx, xcolor, tikz
booktabs, multirow, longtable
hyperref, cleveref
biblatex
microtype
```

---

## Storage & Naming

### File Naming Convention
```
{book_id}_{reading_level}_latex_source.zip
{book_id}_{reading_level}_latex_compiled.pdf

Examples:
math_calculus_college_latex_source.zip
physics_quantum_graduate_latex_compiled.pdf
```

---

## Performance Metrics

### Generation Speed
- **Target:** 4 minutes for 200 pages
- **Maximum:** 8 minutes

### Success Rate
- **Target:** 95%+ (LaTeX compilation can be finicky)

---

## Related Formats

### PDF Print 300 DPI
**Difference:** Pre-compiled PDF, not editable source
**When to use instead:** Final distribution, not academic submission
