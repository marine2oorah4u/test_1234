# Format Blueprint: Markdown Source Format

## Metadata
- **Format ID**: `27_MARKDOWN_SOURCE`
- **Format Name**: Markdown Source Format
- **Tier**: 8 (Advanced/Developer Formats)
- **File Extension**: `.md`
- **Priority**: Medium-High (version control, collaboration)
- **Accessibility Level**: High (plain text)

---

## Overview

### Purpose
Create a clean, human-readable, version-control-friendly Markdown representation of book content. Enables collaborative editing, version tracking, and easy conversion to other formats using static site generators or build tools.

### Use Cases
- Version control (Git/GitHub)
- Collaborative writing and editing
- Static site generation (Hugo, Jekyll, Gatsby)
- Documentation platforms (GitBook, Docusaurus)
- Open-source textbooks
- Technical documentation
- Easy proofreading and review
- Diff-friendly editing workflow
- Automated build pipelines
- Content management without databases

---

## Technical Specifications

### Markdown Flavor
**Use CommonMark + GitHub Flavored Markdown (GFM)**
- **CommonMark**: Core standard spec
- **GFM Additions**: Tables, task lists, strikethrough, autolinks
- **Math**: KaTeX or MathJax syntax ($$...$$)
- **Code**: Fenced code blocks with syntax highlighting
- **Footnotes**: Extended syntax

### File Structure
```
book_markdown/
├── README.md                      # Book overview and navigation
├── metadata.yml                   # YAML frontmatter
├── 00_front_matter/
│   ├── cover.md
│   ├── table_of_contents.md
│   ├── preface.md
│   └── introduction.md
├── 01_chapter_01/
│   ├── README.md                  # Chapter overview
│   ├── 01_section_01.md
│   ├── 02_section_02.md
│   ├── exercises.md
│   └── images/
│       ├── diagram_01.png
│       └── chart_01.svg
├── 02_chapter_02/
├── ...
├── appendices/
│   ├── glossary.md
│   ├── references.md
│   └── index.md
└── assets/
    ├── images/
    ├── code/
    └── data/
```

---

## Markdown Document Structure

### 1. Metadata (YAML Frontmatter)
```markdown
---
title: "Complete Book Title"
subtitle: "Subtitle"
author: "Author Name"
publisher: "Publisher Name"
publication_date: "2025-12-03"
isbn: "978-1-234567-89-0"
language: "en"
version: "1.0.0"
categories:
  - Education
  - Programming
tags:
  - tutorial
  - beginner
  - comprehensive
description: "Compelling book description that explains what readers will learn..."
---
```

### 2. Chapter Template
```markdown
# Chapter 1: Introduction to Programming

**Learning Objectives:**
- Understand what programming is
- Learn basic programming concepts
- Write your first program

**Estimated Reading Time:** 30 minutes

---

## 1.1 What is Programming?

Programming is the process of creating instructions for computers to follow...

### Key Concept: Variables

A **variable** is a named storage location that holds data.

```python
# Example: Creating a variable
name = "Alice"
age = 25
```

> **Note:** Variable names should be descriptive and follow naming conventions.

### Visual Example

![Programming Workflow](images/programming_workflow.png)
*Figure 1.1: The basic programming workflow*

---

## 1.2 Your First Program

Let's write a simple "Hello, World!" program:

```python
print("Hello, World!")
```

**Expected Output:**
```
Hello, World!
```

### Try It Yourself

Modify the program to print your name instead.

---

## Summary

In this chapter, we learned:
- ✓ Programming is problem-solving with code
- ✓ Variables store data
- ✓ The `print()` function displays output

---

## Exercises

1. **Basic**: Write a program that prints your favorite color
2. **Intermediate**: Create variables for your name and age, then print them
3. **Advanced**: Calculate the sum of two numbers and print the result

---

## Additional Resources

- [Python Documentation](https://docs.python.org/)
- [Programming Exercises](https://example.com/exercises)

---

**Next Chapter:** [Chapter 2: Data Types →](../02_chapter_02/README.md)
```

### 3. Math Equations
```markdown
### Quadratic Formula

The quadratic formula is:

$$
x = \frac{-b \pm \sqrt{b^2 - 4ac}}{2a}
$$

For inline math: The value of $\pi \approx 3.14159$.
```

### 4. Tables
```markdown
| Language | Typing | Use Case |
|----------|--------|----------|
| Python   | Dynamic | General-purpose, Data Science |
| JavaScript | Dynamic | Web Development |
| Java | Static | Enterprise Applications |
```

### 5. Task Lists
```markdown
## Learning Checklist

- [x] Read Chapter 1
- [x] Complete exercises
- [ ] Build sample project
- [ ] Take quiz
```

### 6. Callouts/Admonitions
```markdown
> **⚠️ Warning:** Be careful with infinite loops!

> **💡 Tip:** Use descriptive variable names for better code readability.

> **📚 Definition:** A **function** is a reusable block of code.

> **🎯 Best Practice:** Always add comments to complex code.
```

### 7. Code Blocks with Syntax Highlighting
```markdown
```python
def greet(name):
    """
    Greet the user by name.

    Args:
        name (str): The person's name

    Returns:
        str: Greeting message
    """
    return f"Hello, {name}!"

# Usage
message = greet("Alice")
print(message)
```
```

### 8. Footnotes
```markdown
Programming languages have evolved significantly over time[^1].

[^1]: The first high-level programming language was Fortran, created in 1957.
```

---

## Build System Integration

### Static Site Generators

#### Hugo
```yaml
# config.yaml
title: "Book Title"
theme: "book-theme"
outputs:
  home: ["HTML", "RSS", "PDF"]
params:
  author: "Author Name"
  isbn: "978-1-234567-89-0"
```

#### Jekyll
```yaml
# _config.yml
title: "Book Title"
author: "Author Name"
markdown: kramdown
plugins:
  - jekyll-toc
  - jekyll-seo-tag
```

#### Docusaurus
```javascript
// docusaurus.config.js
module.exports = {
  title: 'Book Title',
  tagline: 'Subtitle',
  url: 'https://book.example.com',
  markdown: {
    mermaid: true,
  },
};
```

### Pandoc Conversion
```bash
# Convert Markdown to PDF
pandoc book.md -o book.pdf \
  --pdf-engine=xelatex \
  --toc \
  --number-sections \
  --highlight-style=tango

# Convert to EPUB
pandoc book.md -o book.epub \
  --epub-cover-image=cover.jpg \
  --toc

# Convert to DOCX
pandoc book.md -o book.docx \
  --reference-doc=template.docx \
  --toc
```

---

## Version Control Best Practices

### Git Workflow
```bash
# Initialize repository
git init
git add .
git commit -m "Initial book structure"

# Create feature branch for new chapter
git checkout -b chapter-5-algorithms

# Make changes, commit frequently
git add 05_chapter_05/
git commit -m "Add section on sorting algorithms"

# Merge back to main
git checkout main
git merge chapter-5-algorithms
```

### .gitignore Example
```
# Build outputs
_site/
dist/
*.pdf
*.epub

# OS files
.DS_Store
Thumbs.db

# Editor files
.vscode/
.idea/
*.swp

# Temporary files
*~
*.tmp
```

### Commit Message Convention
```
Add section on recursion

- Explain recursive function definition
- Add fibonacci example
- Include practice problems

Closes #15
```

---

## Collaboration Features

### Pull Request Template
```markdown
## Chapter/Section Changed
Chapter 3, Section 2

## Summary of Changes
- Fixed typo in code example
- Added clarifying paragraph
- Updated diagram

## Checklist
- [x] Spell-checked content
- [x] Tested code examples
- [x] Updated table of contents
- [ ] Peer review requested
```

### Issue Template
```markdown
## Issue Type
- [ ] Typo/Grammar
- [ ] Technical Error
- [ ] Missing Content
- [ ] Suggestion

## Location
Chapter 5, Section 3

## Description
The code example on line 42 produces an error...

## Suggested Fix
Change `x = 5` to `x = "5"`
```

---

## Quality Checklist

### Markdown Validity
- [ ] All Markdown syntax correct
- [ ] YAML frontmatter valid
- [ ] No broken internal links
- [ ] All images referenced exist
- [ ] Code blocks have language specified
- [ ] Tables formatted correctly

### Content Structure
- [ ] Consistent heading hierarchy (H1 → H2 → H3)
- [ ] Chapter numbering consistent
- [ ] Section cross-references accurate
- [ ] Table of contents matches structure
- [ ] All assets in proper directories

### Version Control
- [ ] .gitignore configured
- [ ] Meaningful commit messages
- [ ] Branches for major changes
- [ ] No sensitive data committed
- [ ] Binary files tracked with LFS (if large)

### Build System
- [ ] Pandoc conversions successful
- [ ] Static site generates correctly
- [ ] Math equations render properly
- [ ] Syntax highlighting works
- [ ] Images load correctly

---

## CI/CD Pipeline Example

### GitHub Actions Workflow
```yaml
name: Build Book

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2

      - name: Install Pandoc
        run: sudo apt-get install pandoc

      - name: Build PDF
        run: pandoc book.md -o book.pdf --toc

      - name: Build EPUB
        run: pandoc book.md -o book.epub --toc

      - name: Upload Artifacts
        uses: actions/upload-artifact@v2
        with:
          name: book-outputs
          path: |
            book.pdf
            book.epub
```

---

## AI Model Recommendations

### Content Conversion
- **HTML to Markdown**: GPT-4 (structure preservation)
- **LaTeX to Markdown**: Claude Sonnet (math handling)
- **Formatting Cleanup**: Gemini Pro (consistency)

### Quality Assurance
- **Link Validation**: Claude Opus (check all links)
- **Style Consistency**: GPT-4 (enforce conventions)
- **Spell Check**: Gemini Pro (context-aware)

---

## Output Structure

### Deliverables
```
markdown_source/
├── README.md                       # Project overview
├── metadata.yml                    # Book metadata
├── build.sh                        # Build script
├── .gitignore                      # Git ignore rules
├── chapters/                       # All chapter content
│   ├── 01_introduction.md
│   ├── 02_basics.md
│   └── ...
├── assets/
│   ├── images/
│   ├── code/
│   └── data/
├── templates/
│   ├── chapter_template.md
│   └── pandoc_template.latex
└── build/                          # Generated outputs (gitignored)
    ├── book.pdf
    ├── book.epub
    └── book.html
```

---

## Metadata to Include

```json
{
  "format": "Markdown Source Format",
  "markdown_flavor": "GFM + CommonMark",
  "total_files": 48,
  "total_size_kb": 2840,
  "chapters": 15,
  "sections": 76,
  "word_count": 85000,
  "code_examples": 142,
  "images": 67,
  "version_control": "Git",
  "build_tools": [
    "Pandoc",
    "Hugo",
    "Jekyll",
    "Docusaurus"
  ],
  "output_formats": [
    "PDF",
    "EPUB",
    "HTML",
    "DOCX"
  ],
  "features": [
    "YAML frontmatter",
    "Math equations (KaTeX)",
    "Syntax highlighting",
    "Tables",
    "Task lists",
    "Footnotes"
  ]
}
```

---

## Advantages

1. **Human-Readable**: Easy to read and edit
2. **Version Control**: Perfect for Git
3. **Collaborative**: Multiple authors can work together
4. **Portable**: Plain text, works anywhere
5. **Future-Proof**: Long-term format stability
6. **Multi-Output**: Convert to many formats
7. **Diff-Friendly**: See changes easily

---

## Best Practices

1. **One Sentence Per Line**: Makes diffs cleaner
2. **Consistent Naming**: Use clear file/folder names
3. **Regular Commits**: Commit frequently with clear messages
4. **Branch Strategy**: Use branches for major changes
5. **Automated Builds**: CI/CD for consistency
6. **Link Validation**: Check links regularly
7. **Asset Organization**: Keep images/code organized
8. **Documentation**: README for project setup

---

## Related Formats

- **11_PLAIN_TEXT.md**: Simpler plain text version
- **26_JSON_API_FORMAT.md**: Structured data format
- **06_LATEX_SOURCE.md**: Academic typesetting

---

## Update History
- **2025-12-03**: Initial blueprint created
