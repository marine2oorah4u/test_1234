# Format Blueprint: Braille Ready File (BRF)

## Basic Information
- **File Extension:** `.brf`
- **Format Type:** Accessibility / Braille
- **Tier:** 3 (Accessibility - Conditional)
- **Priority:** HIGH for blind users with braille devices
- **Generation Time:** 5-7 minutes per 200 pages
- **File Size Estimate:** 2-5 MB (ASCII braille text)

---

## Purpose & Use Case

**Primary Purpose:**
ASCII-based braille format for refreshable braille displays and braille embossers. Industry standard for electronic braille distribution.

**Best Used For:**
- Blind readers with refreshable braille displays
- Braille embossers and printers
- Braille note-takers
- Electronic braille distribution
- Libraries serving blind patrons
- Schools for blind students
- Braille transcription services

**Distribution Channels:**
- Bookshare
- National Library Service (NLS)
- RNIB (UK)
- Braille transcription services
- Schools for the blind
- Local libraries

**Use When:**
- Book adapted for blind users
- Braille embosser output needed
- Refreshable braille display users
- Tactile graphics needed

---

## Technical Specifications

### Core Requirements
- **Encoding:** ASCII (Grade 2 Braille)
- **Braille Code:** Unified English Braille (UEB) or EBAE
- **Characters:** 6-dot or 8-dot braille cells
- **Line Length:** 40 characters (typical)
- **Page Length:** 25 lines (typical)
- **Format:** Plain text with form feeds
- **Images:** Tactile graphic descriptions
- **Tables:** Linearized or described
- **Math:** Nemeth Braille Code

### File Structure
```
book.brf (Plain text file)

Example content:
,! ",TITLE
,A UTH OR
,COPY RI\T #BJBF

,C #A4 ,INTRODUCTION
  ,! C IS ! BEGIN+ ( A N !IRO-
DUCTION4 ,BRAILLE IS A TACTILE
":+ SY/ US$ BY PEOPLE : ARE
BL9D OR VISUALLY IMPAIR$4
  ...

[Page markers: ^#A]
[Line breaks and spacing preserved]
```

### Quality Standards
- **Braille Code Accuracy:** 100% correct Grade 2 Braille
- **Formatting:** Proper indentation and spacing
- **Page Breaks:** Logical placement
- **Headers/Footers:** Page numbers in braille
- **Tactile Graphics:** Described verbally
- **Math Notation:** Proper Nemeth Braille Code
- **Validation:** Passes Duxbury DBT check

---

## Generation Process

### Step 1: Convert Text to Braille (3 minutes)

**Code Example:**
```python
import louis  # liblouis braille translator

def text_to_braille(text, table='en-us-g2.ctb'):
    """
    Convert text to Grade 2 Braille using liblouis

    Common tables:
    - en-us-g2.ctb: US Grade 2 Braille
    - en-ueb-g2.ctb: Unified English Braille Grade 2
    - nemeth.ctb: Nemeth Braille Code (mathematics)
    """

    # Translate to braille
    braille = louis.translateString([table], text)

    return braille

def convert_html_to_braille(html_content):
    """Convert HTML book to braille format"""
    from bs4 import BeautifulSoup

    soup = BeautifulSoup(html_content, 'html.parser')
    braille_output = []

    # Title page
    title = soup.find('h1', class_='title')
    if title:
        braille_output.append(text_to_braille(title.text.upper()))
        braille_output.append('\n\n')

    # Author
    author = soup.find('p', class_='author')
    if author:
        braille_output.append(text_to_braille(author.text))
        braille_output.append('\n\n')

    # Table of contents
    braille_output.append(text_to_braille("TABLE OF CONTENTS"))
    braille_output.append('\n')

    # Chapters
    for chapter in soup.find_all('section', class_='chapter'):
        # Chapter heading
        heading = chapter.find('h2')
        if heading:
            braille_output.append('\f')  # Form feed (new page)
            braille_output.append(text_to_braille(heading.text.upper()))
            braille_output.append('\n\n')

        # Paragraphs
        for para in chapter.find_all('p'):
            # Convert paragraph
            para_text = para.get_text()
            braille_para = text_to_braille(para_text)

            # Wrap at 40 characters
            wrapped = wrap_braille_text(braille_para, width=40)
            braille_output.append(wrapped)
            braille_output.append('\n\n')

    return ''.join(braille_output)

def wrap_braille_text(text, width=40):
    """Wrap braille text at specified width"""
    words = text.split()
    lines = []
    current_line = []
    current_length = 0

    for word in words:
        word_length = len(word)

        if current_length + word_length + 1 <= width:
            current_line.append(word)
            current_length += word_length + 1
        else:
            lines.append(' '.join(current_line))
            current_line = [word]
            current_length = word_length

    if current_line:
        lines.append(' '.join(current_line))

    return '\n'.join(lines)
```

**Output:** Braille-encoded text
**Time:** 3 minutes

### Step 2: Handle Special Elements (1 minute)

**Code Example:**
```python
def handle_images(img_element):
    """Convert image to tactile description"""
    alt_text = img_element.get('alt', 'Image')
    description = f"[TACTILE GRAPHIC: {alt_text}]"
    return text_to_braille(description)

def handle_table(table_element):
    """Convert table to linear braille format"""
    # Tables are challenging in braille
    # Option 1: Linearize (read row by row)
    # Option 2: Provide verbal description

    rows = table_element.find_all('tr')
    braille_table = []

    for row in rows:
        cells = row.find_all(['td', 'th'])
        row_text = ' | '.join(cell.get_text() for cell in cells)
        braille_table.append(text_to_braille(row_text))

    return '\n'.join(braille_table)

def handle_math(math_text):
    """Convert math to Nemeth Braille Code"""
    # Use Nemeth Braille table
    nemeth_braille = louis.translateString(['nemeth.ctb'], math_text)
    return nemeth_braille
```

**Output:** Special elements converted to braille
**Time:** 1 minute

### Step 3: Add Page Formatting (1 minute)

**Code Example:**
```python
def format_braille_pages(braille_text, lines_per_page=25):
    """Add page breaks and page numbers"""

    lines = braille_text.split('\n')
    pages = []
    current_page = []
    line_count = 0
    page_num = 1

    for line in lines:
        # Check for manual page breaks (form feed)
        if '\f' in line:
            # Save current page
            if current_page:
                pages.append({
                    'number': page_num,
                    'content': '\n'.join(current_page)
                })
                page_num += 1
            current_page = []
            line_count = 0
            continue

        # Add line to current page
        current_page.append(line)
        line_count += 1

        # Auto page break
        if line_count >= lines_per_page:
            # Add page number in braille
            page_marker = text_to_braille(f"Page {page_num}")
            current_page.append(f"\n{page_marker}")

            pages.append({
                'number': page_num,
                'content': '\n'.join(current_page)
            })
            page_num += 1
            current_page = []
            line_count = 0

    # Add last page
    if current_page:
        page_marker = text_to_braille(f"Page {page_num}")
        current_page.append(f"\n{page_marker}")
        pages.append({
            'number': page_num,
            'content': '\n'.join(current_page)
        })

    # Combine with form feeds between pages
    formatted = '\f'.join(page['content'] for page in pages)

    return formatted
```

**Output:** Formatted braille with page breaks
**Time:** 1 minute

### Step 4: Add Metadata Header (30 seconds)

**Code Example:**
```python
def add_brf_header(book_metadata):
    """Add BRF header with metadata"""

    header = f'''#BRF FILE
,! "{book_metadata['title'].upper()}"
,A: {book_metadata['author']}
,PUBLISH$4 {book_metadata['publisher']}
,DATE4 {book_metadata['date']}
,! BOOK IS 9 ,GRADE #B ,BRAILLE
,TRANSCRIB$ BY4 ,EDUCATIONAL ,BOOKS ,:
,ISBN4 {book_metadata['isbn']}

'''

    # Convert header to braille
    braille_header = text_to_braille(header)

    return braille_header
```

**Output:** BRF file with header
**Time:** 30 seconds

### Step 5: Validate and Save (30 seconds)

**Code Example:**
```python
def validate_brf(brf_content):
    """Validate BRF file"""

    issues = []

    # Check line length
    for i, line in enumerate(brf_content.split('\n')):
        if len(line) > 42:  # Typical max is 40, allow 2 chars buffer
            issues.append(f"Line {i+1} too long: {len(line)} chars")

    # Check for invalid characters
    valid_chars = set(' !"#$%&\'()*+,-./0123456789:;<=>?@'
                     'ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`'
                     'abcdefghijklmnopqrstuvwxyz{|}~\n\f')

    for i, char in enumerate(brf_content):
        if char not in valid_chars:
            issues.append(f"Invalid character at position {i}: '{char}'")

    return {
        'valid': len(issues) == 0,
        'issues': issues
    }

def save_brf(brf_content, output_path):
    """Save BRF file"""

    # Validate first
    validation = validate_brf(brf_content)

    if not validation['valid']:
        print("Warning: BRF has validation issues:")
        for issue in validation['issues'][:10]:  # Show first 10
            print(f"  - {issue}")

    # Save as ASCII
    with open(output_path, 'w', encoding='ascii', errors='replace') as f:
        f.write(brf_content)

    return output_path
```

**Output:** Final validated BRF file
**Time:** 30 seconds

**Total Time:** 5-7 minutes per book

---

## Quality Verification

### Automated Checks
1. File is valid ASCII
2. Line length within limits (40-42 chars)
3. Page breaks properly placed
4. Grade 2 Braille correct
5. No invalid characters
6. Metadata present
7. Math in Nemeth Code
8. File size reasonable

### Testing Checklist
- [ ] Opens on braille display
- [ ] Reads correctly on Freedom Scientific Focus
- [ ] Reads correctly on HumanWare BrailleNote
- [ ] Embosses correctly on braille printer
- [ ] Navigation works (page jumps)
- [ ] Math formulas correct
- [ ] Tables readable
- [ ] Tactile descriptions present
- [ ] Page numbers correct

---

## Tools & Libraries

### Python Libraries
```txt
louis==3.27.0  # liblouis braille translator
beautifulsoup4==4.12.2
lxml==4.9.3
```

### Installation
```bash
# Install liblouis
sudo apt-get install liblouis-dev liblouis-bin  # Linux
brew install liblouis  # macOS

# Install Python bindings
pip install louis beautifulsoup4 lxml
```

### Braille Translation Tables
- **en-us-g2.ctb** - US Grade 2 Braille
- **en-ueb-g2.ctb** - Unified English Braille
- **nemeth.ctb** - Nemeth Braille Code (math)
- **en-us-comp8.ctb** - Computer Braille (code)

---

## Storage & Naming

### File Naming Convention
```
{book_id}_{reading_level}_{disability}_braille.brf

Examples:
math_algebra_college_blind_braille.brf
science_biology_elementary_blind_braille.brf
```

---

## Performance Metrics

### Generation Speed
- **Target:** 5 minutes for 200 pages
- **Maximum:** 10 minutes

### File Size
- **Target:** 2-4 MB for 200 pages
- **Maximum:** 10 MB

---

## Braille Standards

### Grade 2 Braille Contractions
- Common word contractions (and, the, for, etc.)
- Letter group contractions
- Shortform words
- Punctuation marks

### Formatting Rules
- **Emphasis:** Underline or italics markers
- **Headings:** Centered and marked
- **Lists:** Proper indentation
- **Poetry:** Line breaks preserved
- **Quotes:** Special quotation marks

---

## Related Formats

### PEF (Portable Embosser Format)
**Difference:** XML-based, more metadata
**When to use instead:** Modern braille embossers

### BRF (this format)
**Difference:** ASCII-based, widely supported
**When to use:** Maximum compatibility with displays
