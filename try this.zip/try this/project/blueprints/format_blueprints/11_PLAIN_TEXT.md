# Format Blueprint: Plain Text (TXT)

## Basic Information
- **File Extension:** `.txt`
- **Format Type:** Accessibility / Universal
- **Tier:** 3 (Accessibility - Conditional)
- **Priority:** HIGH for maximum accessibility
- **Generation Time:** 1-2 minutes per 200 pages
- **File Size Estimate:** 1-3 MB

---

## Purpose & Use Case

**Primary Purpose:**
Maximum accessibility plain text format that works with any screen reader, text editor, or assistive technology. Universal compatibility.

**Best Used For:**
- Screen reader users (maximum compatibility)
- Legacy assistive technology
- Text-to-speech software
- Braille displays (as fallback)
- Command-line interfaces
- Low-bandwidth environments
- Archival purposes
- Maximum portability

**Distribution Channels:**
- Bookshare
- Project Gutenberg-style archives
- Screen reader users
- Legacy systems
- Email (inline text)
- Terminal/console reading

**Use When:**
- Maximum accessibility required
- Legacy system compatibility needed
- Screen reader users without PDF support
- Low bandwidth/storage environments
- Archival/preservation

---

## Technical Specifications

### Core Requirements
- **Encoding:** UTF-8 (universal)
- **Line Endings:** LF (Unix) or CRLF (Windows) - auto-detect
- **Line Length:** 80 characters max (for readability)
- **Headings:** Marked with underlines or special characters
- **Images:** Alt text descriptions [in brackets]
- **Tables:** Linearized or ASCII art
- **Math:** Plain text approximation or LaTeX notation
- **Links:** Full URLs in parentheses

### File Structure
```
TITLE OF BOOK
By Author Name

Copyright 2024 Publisher Name
ISBN: 978-1234567890

============================================================

TABLE OF CONTENTS

Chapter 1: Introduction ............................ Page 5
Chapter 2: Getting Started ........................ Page 15
Chapter 3: Advanced Topics ........................ Page 45

============================================================

CHAPTER 1: INTRODUCTION

This is the beginning of the chapter. The text is wrapped at
80 characters for easy reading in any text editor or terminal.

[Image: A diagram showing the process flow from input to output.
The diagram includes three boxes labeled "Input", "Process", and
"Output" connected by arrows.]

Each paragraph is separated by a blank line for readability.
Special emphasis is shown with *asterisks* or _underscores_.

============================================================
```

### Quality Standards
- **Readability:** Clear structure with visual separators
- **Screen Reader Friendly:** Logical reading order
- **Wrapping:** 80 characters per line
- **Encoding:** Valid UTF-8
- **Line Endings:** Consistent
- **Alt Text:** All images described
- **Tables:** Readable in linear format
- **No Binary Data:** Pure text only

---

## Generation Process

### Step 1: Strip HTML and Extract Text (30 seconds)

**Code Example:**
```python
from bs4 import BeautifulSoup
import textwrap

def html_to_plain_text(html_content):
    """Convert HTML to plain text"""

    soup = BeautifulSoup(html_content, 'html.parser')
    text_parts = []

    # Title
    title = soup.find('h1', class_='title')
    if title:
        text_parts.append(title.text.upper())
        text_parts.append('=' * len(title.text))
        text_parts.append('')

    # Author
    author = soup.find('p', class_='author')
    if author:
        text_parts.append(f"By {author.text}")
        text_parts.append('')

    # Copyright
    copyright_text = soup.find('p', class_='copyright')
    if copyright_text:
        text_parts.append(copyright_text.text)
        text_parts.append('')

    text_parts.append('=' * 60)
    text_parts.append('')

    # Chapters
    for chapter in soup.find_all('section', class_='chapter'):
        # Chapter heading
        heading = chapter.find('h2')
        if heading:
            text_parts.append('')
            text_parts.append(heading.text.upper())
            text_parts.append('-' * len(heading.text))
            text_parts.append('')

        # Paragraphs
        for para in chapter.find_all('p'):
            # Wrap at 80 characters
            wrapped = textwrap.fill(para.get_text(), width=80)
            text_parts.append(wrapped)
            text_parts.append('')  # Blank line between paragraphs

    return '\n'.join(text_parts)
```

**Output:** Plain text structure
**Time:** 30 seconds

### Step 2: Handle Special Elements (30 seconds)

**Code Example:**
```python
def handle_images_plaintext(img_element):
    """Convert image to alt text description"""
    alt_text = img_element.get('alt', 'Image')
    caption = img_element.get('title', '')

    if caption:
        return f"[Image: {alt_text}. {caption}]"
    else:
        return f"[Image: {alt_text}]"

def handle_tables_plaintext(table_element):
    """Convert table to plain text format"""

    rows = table_element.find_all('tr')
    text_table = []

    # Simple ASCII table
    for row in rows:
        cells = row.find_all(['td', 'th'])
        row_text = ' | '.join(cell.get_text().strip() for cell in cells)
        text_table.append(row_text)

        # Add separator after header
        if row.find('th'):
            text_table.append('-' * len(row_text))

    return '\n'.join(text_table)

def handle_lists_plaintext(list_element):
    """Convert lists to plain text"""

    items = list_element.find_all('li', recursive=False)
    is_ordered = list_element.name == 'ol'

    list_text = []
    for i, item in enumerate(items, 1):
        if is_ordered:
            prefix = f"{i}. "
        else:
            prefix = "• "

        # Wrap list item text
        item_text = item.get_text()
        wrapped = textwrap.fill(item_text, width=77,
                               initial_indent=prefix,
                               subsequent_indent='   ')
        list_text.append(wrapped)

    return '\n'.join(list_text)

def handle_math_plaintext(math_text):
    """Convert math to plain text approximation"""

    # Simple replacements
    replacements = {
        '×': 'x',
        '÷': '/',
        '²': '^2',
        '³': '^3',
        '√': 'sqrt',
        '≤': '<=',
        '≥': '>=',
        '≠': '!=',
        '∞': 'infinity',
        'π': 'pi',
        '∑': 'sum',
        '∫': 'integral'
    }

    for symbol, replacement in replacements.items():
        math_text = math_text.replace(symbol, replacement)

    return math_text
```

**Output:** Special elements converted
**Time:** 30 seconds

### Step 3: Add Metadata Header (15 seconds)

**Code Example:**
```python
def add_text_header(book_metadata):
    """Add plain text header with metadata"""

    header = f'''{book_metadata['title'].upper()}
{'=' * len(book_metadata['title'])}

Author: {book_metadata['author']}
Publisher: {book_metadata['publisher']}
Publication Date: {book_metadata['date']}
ISBN: {book_metadata['isbn']}
Language: {book_metadata['language']}

{book_metadata.get('description', '')}

{'=' * 60}

'''

    return header
```

**Output:** Metadata header
**Time:** 15 seconds

### Step 4: Add Table of Contents (15 seconds)

**Code Example:**
```python
def generate_text_toc(chapters):
    """Generate plain text table of contents"""

    toc = ['TABLE OF CONTENTS', '=' * 60, '']

    for i, chapter in enumerate(chapters, 1):
        # Calculate approximate page (assuming ~3000 chars per page)
        page_num = (sum(len(c['content']) for c in chapters[:i-1]) // 3000) + 1

        # Format with dots
        title = chapter['title']
        dots = '.' * (50 - len(title) - len(str(page_num)))
        toc.append(f"Chapter {i}: {title} {dots} Page {page_num}")

    toc.append('')
    toc.append('=' * 60)
    toc.append('')

    return '\n'.join(toc)
```

**Output:** Table of contents
**Time:** 15 seconds

### Step 5: Format and Save (15 seconds)

**Code Example:**
```python
def save_plain_text(text_content, output_path, line_ending='lf'):
    """Save plain text file with proper encoding and line endings"""

    # Normalize line endings
    if line_ending == 'crlf':
        # Windows
        text_content = text_content.replace('\n', '\r\n')
    elif line_ending == 'lf':
        # Unix/Linux/Mac
        text_content = text_content.replace('\r\n', '\n')

    # Save with UTF-8 encoding
    with open(output_path, 'w', encoding='utf-8', newline='') as f:
        f.write(text_content)

    # Also create a version with BOM for maximum compatibility
    bom_path = output_path.replace('.txt', '_utf8bom.txt')
    with open(bom_path, 'w', encoding='utf-8-sig') as f:
        f.write(text_content)

    return output_path

def validate_plain_text(text_content):
    """Validate plain text file"""

    issues = []

    # Check line length
    for i, line in enumerate(text_content.split('\n'), 1):
        if len(line) > 82:  # Allow 2 chars buffer
            issues.append(f"Line {i} too long: {len(line)} characters")

    # Check for non-UTF-8 characters
    try:
        text_content.encode('utf-8')
    except UnicodeEncodeError as e:
        issues.append(f"Encoding error: {e}")

    # Check for control characters (except newline, tab)
    import re
    control_chars = re.findall(r'[\x00-\x08\x0B-\x0C\x0E-\x1F]', text_content)
    if control_chars:
        issues.append(f"Found {len(control_chars)} control characters")

    return {
        'valid': len(issues) == 0,
        'issues': issues
    }
```

**Output:** Final validated plain text file
**Time:** 15 seconds

**Total Time:** 1-2 minutes per book

---

## Quality Verification

### Automated Checks
1. Valid UTF-8 encoding
2. Line length under 80 characters
3. No binary data
4. Consistent line endings
5. All images have alt text
6. Logical structure maintained
7. No control characters
8. File size reasonable

### Testing Checklist
- [ ] Opens in Notepad
- [ ] Opens in vim/nano
- [ ] Reads well with NVDA screen reader
- [ ] Reads well with JAWS
- [ ] Reads well with VoiceOver
- [ ] Displays correctly in terminal
- [ ] Wraps properly at 80 characters
- [ ] Structure clear and navigable
- [ ] Images described adequately
- [ ] Math readable

---

## Tools & Libraries

### Python Libraries
```txt
beautifulsoup4==4.12.2
lxml==4.9.3
```

### Installation
```bash
pip install beautifulsoup4 lxml
```

---

## Storage & Naming

### File Naming Convention
```
{book_id}_{reading_level}_{disability}_plaintext.txt

Examples:
math_algebra_college_standard_plaintext.txt
science_biology_elementary_blind_plaintext.txt

# Also create UTF-8 BOM variant for compatibility
math_algebra_college_standard_plaintext_utf8bom.txt
```

---

## Performance Metrics

### Generation Speed
- **Target:** 1 minute for 200 pages
- **Maximum:** 3 minutes

### File Size
- **Target:** 1-2 MB for 200 pages
- **Maximum:** 5 MB

---

## Text Formatting Conventions

### Headings
```
LEVEL 1 HEADING (CHAPTER)
=========================

Level 2 Heading (Section)
-------------------------

Level 3 Heading (Subsection):
```

### Emphasis
```
*Bold text* or **bold text**
_Italic text_ or /italic text/
```

### Lists
```
Unordered:
• Item 1
• Item 2
  - Subitem 2.1
  - Subitem 2.2

Ordered:
1. First item
2. Second item
   a. Sub-item
   b. Sub-item
```

### Links
```
For more information, visit our website (https://example.com).
See Chapter 5 for details.
```

### Code/Monospace
```
    function example() {
        return "indented code block";
    }
```

---

## Accessibility Benefits

### Screen Reader Optimized
- Linear reading order
- Clear structure markers
- Descriptive alt text
- No visual-only formatting

### Universal Compatibility
- Works with all screen readers
- Works with all braille displays
- Works with all TTS software
- Works on any device/OS

### Low Bandwidth
- Smallest file size
- Fast download
- Email-friendly
- Works offline

---

## Related Formats

### Markdown
**Difference:** Includes formatting syntax
**When to use instead:** Developers, version control

### DAISY 3.0
**Difference:** Synchronized audio + text
**When to use instead:** Users who prefer audio

### HTML Responsive
**Difference:** Web-based with styling
**When to use instead:** Online reading with visual formatting
