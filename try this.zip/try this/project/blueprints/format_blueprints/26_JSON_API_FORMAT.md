# Format Blueprint: JSON API Format

## Metadata
- **Format ID**: `26_JSON_API_FORMAT`
- **Format Name**: JSON API / Structured Data Format
- **Tier**: 8 (Advanced/Developer Formats)
- **File Extension**: `.json`
- **Priority**: High (programmatic access, integrations)
- **Accessibility Level**: N/A (machine-readable)

---

## Overview

### Purpose
Create a machine-readable JSON representation of book content for API distribution, application integration, search indexing, and programmatic access. Enables developers to build custom interfaces, integrate with other systems, and create dynamic experiences.

### Use Cases
- Custom mobile app development
- Web application integration
- Search engine optimization (structured data)
- Content management systems
- Third-party integrations
- AI/ML training data
- Chatbot knowledge bases
- Custom learning platforms
- Translation workflows
- Content syndication

---

## Technical Specifications

### JSON Structure
```json
{
  "book": {
    "metadata": {},
    "structure": {},
    "content": {},
    "media": {},
    "relationships": {},
    "accessibility": {}
  },
  "api_version": "1.0",
  "generated_at": "2025-12-03T00:00:00Z"
}
```

---

## Complete JSON Schema

### 1. Metadata Block
```json
{
  "metadata": {
    "title": "Complete Book Title",
    "subtitle": "Subtitle if applicable",
    "author": {
      "name": "Author Name",
      "bio": "Author biography",
      "website": "https://authorsite.com",
      "email": "author@example.com"
    },
    "publisher": "Publisher Name",
    "publication_date": "2025-12-03",
    "isbn_13": "978-1-234567-89-0",
    "isbn_10": "1234567890",
    "language": "en",
    "page_count": 324,
    "word_count": 82000,
    "reading_time_minutes": 410,
    "edition": "1st Edition",
    "version": "1.0.0",
    "copyright": "Copyright © 2025 Author Name. All rights reserved.",
    "license": "All Rights Reserved",
    "categories": [
      "Education / Teaching Methods",
      "Computers / Programming"
    ],
    "subjects": [
      "programming",
      "education",
      "algorithms"
    ],
    "tags": ["beginner", "tutorial", "comprehensive"],
    "description": "Compelling book description...",
    "cover_image_url": "https://example.com/cover.jpg"
  }
}
```

### 2. Structure Block
```json
{
  "structure": {
    "type": "educational_book",
    "sections": [
      {
        "id": "front_matter",
        "type": "front_matter",
        "title": "Front Matter",
        "items": [
          {"id": "cover", "type": "cover", "title": "Cover"},
          {"id": "toc", "type": "toc", "title": "Table of Contents"},
          {"id": "preface", "type": "preface", "title": "Preface"}
        ]
      },
      {
        "id": "chapter_01",
        "type": "chapter",
        "number": 1,
        "title": "Introduction to Programming",
        "sections": [
          {
            "id": "section_01_01",
            "type": "section",
            "number": 1,
            "title": "What is Programming?",
            "subsections": []
          }
        ],
        "page_range": {"start": 1, "end": 25},
        "estimated_reading_time_minutes": 30
      }
    ],
    "navigation": {
      "table_of_contents": [],
      "index": [],
      "glossary_available": true
    }
  }
}
```

### 3. Content Block
```json
{
  "content": {
    "chapters": [
      {
        "id": "chapter_01",
        "number": 1,
        "title": "Introduction to Programming",
        "content_type": "html",
        "content": "<h1>Chapter 1: Introduction</h1><p>...</p>",
        "plain_text": "Chapter 1: Introduction\n\n...",
        "markdown": "# Chapter 1: Introduction\n\n...",
        "summary": "This chapter introduces fundamental programming concepts...",
        "key_points": [
          "Programming is problem-solving",
          "Algorithms are step-by-step instructions",
          "Variables store data"
        ],
        "sections": [
          {
            "id": "section_01_01",
            "title": "What is Programming?",
            "content": "<h2>What is Programming?</h2><p>...</p>",
            "images": [
              {
                "id": "img_01_01",
                "url": "https://example.com/images/programming.jpg",
                "alt_text": "Diagram showing programming workflow",
                "caption": "The programming process"
              }
            ],
            "code_examples": [
              {
                "id": "code_01_01",
                "language": "python",
                "code": "print('Hello, World!')",
                "description": "A simple Hello World program"
              }
            ]
          }
        ],
        "exercises": [
          {
            "id": "exercise_01_01",
            "type": "multiple_choice",
            "question": "What is a variable?",
            "options": ["A", "B", "C", "D"],
            "correct_answer": "B",
            "explanation": "..."
          }
        ],
        "references": [
          {
            "id": "ref_01_01",
            "citation": "Knuth, D. (1968). The Art of Computer Programming",
            "url": "https://example.com/ref"
          }
        ]
      }
    ]
  }
}
```

### 4. Media Block
```json
{
  "media": {
    "images": [
      {
        "id": "img_01_01",
        "filename": "programming.jpg",
        "url": "https://cdn.example.com/images/programming.jpg",
        "alt_text": "Programming workflow diagram",
        "caption": "The programming process",
        "width": 1200,
        "height": 800,
        "format": "JPEG",
        "size_bytes": 245000,
        "usage_count": 2,
        "used_in_chapters": ["chapter_01", "chapter_05"]
      }
    ],
    "videos": [
      {
        "id": "video_01_01",
        "title": "Introduction to Variables",
        "url": "https://cdn.example.com/videos/variables.mp4",
        "duration_seconds": 180,
        "format": "MP4",
        "size_bytes": 12500000,
        "thumbnail_url": "https://cdn.example.com/thumbs/variables.jpg",
        "transcript": "..."
      }
    ],
    "audio": [],
    "code_files": [
      {
        "id": "code_file_01",
        "filename": "hello.py",
        "language": "python",
        "url": "https://cdn.example.com/code/hello.py",
        "content": "print('Hello, World!')"
      }
    ]
  }
}
```

### 5. Relationships Block
```json
{
  "relationships": {
    "series": {
      "name": "Complete Programming Series",
      "position": 1,
      "total_books": 5,
      "previous_book": null,
      "next_book": {
        "isbn": "978-1-234567-90-6",
        "title": "Advanced Programming Concepts"
      }
    },
    "prerequisites": [
      {
        "title": "Basic Computer Skills",
        "isbn": "978-1-234567-88-3",
        "required": false
      }
    ],
    "recommendations": [
      {
        "title": "Data Structures",
        "isbn": "978-1-234567-91-3",
        "reason": "Natural next step"
      }
    ],
    "related_topics": [
      "algorithms",
      "software engineering",
      "computer science"
    ]
  }
}
```

### 6. Accessibility Block
```json
{
  "accessibility": {
    "screen_reader_compatible": true,
    "alt_text_complete": true,
    "semantic_structure": true,
    "wcag_level": "AA",
    "features": [
      "Image descriptions",
      "Code annotations",
      "Math descriptions",
      "Video transcripts"
    ],
    "alternative_formats_available": [
      "Large Print",
      "DAISY",
      "Braille",
      "Audiobook"
    ]
  }
}
```

---

## API Endpoints (RESTful Design)

### Book Metadata
```
GET /api/v1/books/{isbn}
GET /api/v1/books/{isbn}/metadata
```

### Content Access
```
GET /api/v1/books/{isbn}/chapters
GET /api/v1/books/{isbn}/chapters/{chapter_id}
GET /api/v1/books/{isbn}/chapters/{chapter_id}/sections/{section_id}
```

### Search & Discovery
```
GET /api/v1/books/search?q={query}
GET /api/v1/books?category={category}
GET /api/v1/books?author={author}
```

### Media Assets
```
GET /api/v1/books/{isbn}/media/images
GET /api/v1/books/{isbn}/media/videos
GET /api/v1/books/{isbn}/media/{media_id}
```

### Table of Contents & Navigation
```
GET /api/v1/books/{isbn}/toc
GET /api/v1/books/{isbn}/index
GET /api/v1/books/{isbn}/glossary
```

---

## Use Case Examples

### 1. Custom Reading App
```javascript
// Fetch book metadata
const book = await fetch('/api/v1/books/978-1-234567-89-0');
const metadata = await book.json();

// Load chapter
const chapter = await fetch(`/api/v1/books/978-1-234567-89-0/chapters/chapter_01`);
const chapterData = await chapter.json();

// Render in custom UI
renderChapter(chapterData);
```

### 2. Search Integration
```javascript
// Index book content for search
const chapters = await fetch('/api/v1/books/978-1-234567-89-0/chapters');
const allContent = await chapters.json();

// Index in Elasticsearch, Algolia, etc.
await searchEngine.index(allContent);
```

### 3. AI Training Data
```python
import requests

# Fetch all content
book = requests.get('https://api.example.com/books/978-1-234567-89-0/full').json()

# Extract text for AI training
training_data = []
for chapter in book['content']['chapters']:
    training_data.append({
        'text': chapter['plain_text'],
        'metadata': {
            'title': chapter['title'],
            'topic': book['metadata']['subjects']
        }
    })
```

---

## Quality Checklist

### Data Completeness
- [ ] All metadata fields populated
- [ ] All chapters included with content
- [ ] Table of contents complete
- [ ] All images cataloged with URLs
- [ ] All code examples included
- [ ] References and citations included

### JSON Validity
- [ ] Valid JSON syntax (no parsing errors)
- [ ] Consistent data types
- [ ] No null/undefined in required fields
- [ ] Arrays properly formatted
- [ ] Nested structures correct

### API Compliance
- [ ] Follows RESTful principles
- [ ] Authentication mechanism defined
- [ ] Rate limiting specified
- [ ] Error codes documented
- [ ] Versioning implemented

### Content Quality
- [ ] HTML sanitized (no malicious code)
- [ ] URLs valid and accessible
- [ ] Code examples syntax-checked
- [ ] Plain text accurately extracted
- [ ] Markdown properly formatted

---

## Security Considerations

### Authentication
```json
{
  "authentication": {
    "type": "Bearer Token",
    "header": "Authorization: Bearer {token}",
    "token_lifetime": 3600,
    "refresh_available": true
  }
}
```

### Access Control
```json
{
  "access": {
    "public_metadata": true,
    "content_requires_auth": true,
    "rate_limit": {
      "requests_per_hour": 1000,
      "burst_limit": 50
    }
  }
}
```

### Data Privacy
- No personal user data in public API
- Content access logged for analytics
- GDPR/CCPA compliance
- No PII in metadata

---

## AI Model Recommendations

### JSON Generation
- **Structure Design**: Claude Sonnet (schema design)
- **Content Extraction**: GPT-4 (HTML to JSON)
- **Metadata Population**: Gemini Pro (data enrichment)

### Quality Assurance
- **JSON Validation**: Claude Opus (syntax checking)
- **Content Verification**: GPT-4 (accuracy check)
- **API Testing**: Gemini Pro (endpoint validation)

---

## Output Structure

### Deliverables
```
json_api/
├── book_complete.json              # Full book in JSON
├── book_metadata.json              # Metadata only
├── chapters/                       # Individual chapter JSONs
│   ├── chapter_01.json
│   ├── chapter_02.json
│   └── ...
├── api_documentation.md            # API endpoint docs
├── json_schema.json                # JSON schema definition
└── example_usage.md                # Code examples
```

---

## Metadata to Include

```json
{
  "format": "JSON API Format",
  "api_version": "1.0",
  "json_schema_version": "draft-07",
  "total_size_mb": 8.5,
  "compression": "gzip available",
  "endpoints": 15,
  "authentication_required": true,
  "rate_limits": {
    "requests_per_hour": 1000,
    "concurrent_connections": 10
  },
  "features": [
    "Full text search",
    "Chapter-level access",
    "Media URLs",
    "Code examples",
    "Exercises/quizzes",
    "References"
  ],
  "integrations": [
    "Mobile apps",
    "Web applications",
    "Search engines",
    "CMS platforms",
    "AI systems"
  ]
}
```

---

## Advantages

1. **Machine-Readable**: Perfect for programmatic access
2. **Flexible**: Use in any application
3. **Searchable**: Easy to index and search
4. **Integrations**: Connect to any system
5. **API-First**: Modern development approach
6. **Versioned**: Track changes over time
7. **Lightweight**: Efficient data transfer

---

## Best Practices

1. **Validate JSON**: Use JSON schema validator
2. **Version API**: Implement versioning (/v1/, /v2/)
3. **Document Thoroughly**: Clear API docs
4. **Consistent Naming**: Use snake_case or camelCase consistently
5. **Error Handling**: Provide meaningful error messages
6. **Caching**: Implement caching for performance
7. **Pagination**: For large datasets
8. **Compression**: Use gzip for transfer

---

## Related Formats

- **04_EPUB_30.md**: Source for content extraction
- **27_MARKDOWN_SOURCE.md**: Alternative text format
- **11_PLAIN_TEXT.md**: Simplified text version

---

## Update History
- **2025-12-03**: Initial blueprint created
