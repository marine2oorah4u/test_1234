# Format Blueprint: DAISY 3.0 (Digital Accessible Information System)

## Basic Information
- **File Extension:** `.zip` (DAISY package) or `.daisy`
- **Format Type:** Accessibility / Digital Talking Book
- **Tier:** 3 (Accessibility - Conditional)
- **Priority:** HIGH for blind and dyslexic users
- **Generation Time:** 10-15 minutes per 200 pages (with TTS audio)
- **File Size Estimate:** 20-50 MB (text), 200-500 MB (with audio)

---

## Purpose & Use Case

**Primary Purpose:**
Synchronized text and audio format specifically designed for blind, dyslexic, and print-disabled readers. Industry standard for accessible digital books.

**Best Used For:**
- Blind readers with screen readers
- Dyslexic readers needing synchronized audio
- Low vision readers
- Learning disabilities
- Libraries for print-disabled patrons
- Schools for students with reading disabilities
- Organizations serving blind/dyslexic communities

**Distribution Channels:**
- Bookshare (global library for print-disabled)
- Learning Ally
- National Library Service (NLS)
- RNIB (UK)
- Vision Australia
- Local libraries for disabled patrons
- Schools and universities

**Use When:**
- Book adapted for blind users
- Book adapted for dyslexia
- Accessibility requirement
- Library serving disabled patrons

---

## Technical Specifications

### Core Requirements
- **Format Version:** DAISY 3.0 (ANSI/NISO Z39.86-2005)
- **Structure:** XML-based with SMIL synchronization
- **Navigation:** NCX file for hierarchical navigation
- **Text:** XHTML with semantic markup
- **Audio:** MP3 or WAV (human or TTS)
- **Synchronization:** SMIL files linking text to audio
- **Images:** Alt text descriptions (required)
- **Metadata:** Dublin Core
- **Player Compatibility:** Victor Reader, Dolphin EasyReader, AMIS

### File Structure
```
book.daisy (ZIP archive)
├── daisy202.dtd
├── ncc.html (Navigation Control Center)
├── package.opf (metadata)
├── dtbook.xml (full text in DTBook format)
├── navigation.ncx
├── audio/
│   ├── chapter01.mp3
│   ├── chapter02.mp3
│   └── ...
├── smil/
│   ├── chapter01.smil (sync text-audio)
│   ├── chapter02.smil
│   └── ...
├── text/
│   ├── chapter01.html
│   ├── chapter02.html
│   └── ...
└── images/
    ├── descriptions.txt (tactile descriptions)
    └── ...
```

### Quality Standards
- **Validation:** Passes DAISY Pipeline validation
- **Navigation:** Complete heading structure
- **Synchronization:** Text-audio perfectly synced
- **Alt Text:** All images described
- **Audio Quality:** 64-128 kbps MP3
- **Reading Order:** Logical flow
- **Metadata:** Complete Dublin Core
- **Player Compatibility:** Works in all major DAISY players

---

## Generation Process

### Step 1: Create DTBook XML (2 minutes)

**Code Example:**
```python
from lxml import etree

def create_dtbook(book_data):
    """Generate DTBook XML format"""

    # DTBook namespace
    ns = "http://www.daisy.org/z3986/2005/dtbook/"

    # Create root element
    dtbook = etree.Element(f"{{{ns}}}dtbook",
                           version="2005-3",
                           nsmap={None: ns})

    # Head element with metadata
    head = etree.SubElement(dtbook, "head")

    # Meta elements
    meta_elements = [
        ("dc:Title", book_data['title']),
        ("dc:Creator", book_data['author']),
        ("dc:Language", book_data['language']),
        ("dc:Date", book_data['date']),
        ("dc:Publisher", book_data['publisher']),
        ("dc:Format", "DAISY 3.0"),
        ("dc:Identifier", book_data['isbn']),
    ]

    for name, content in meta_elements:
        meta = etree.SubElement(head, "meta",
                               name=name,
                               content=content)

    # Book element
    book = etree.SubElement(dtbook, "book")

    # Frontmatter
    frontmatter = etree.SubElement(book, "frontmatter")
    doctitle = etree.SubElement(frontmatter, "doctitle")
    doctitle.text = book_data['title']

    docauthor = etree.SubElement(frontmatter, "docauthor")
    docauthor.text = book_data['author']

    # Bodymatter
    bodymatter = etree.SubElement(book, "bodymatter")

    # Add levels (chapters)
    for i, chapter in enumerate(book_data['chapters']):
        level1 = etree.SubElement(bodymatter, "level1", id=f"ch{i+1}")

        # Chapter heading
        h1 = etree.SubElement(level1, "h1", id=f"ch{i+1}_h1")
        h1.text = chapter['title']

        # Chapter content (paragraphs)
        for j, para in enumerate(chapter['paragraphs']):
            p = etree.SubElement(level1, "p", id=f"ch{i+1}_p{j+1}")
            p.text = para['text']

    # Convert to string with pretty print
    dtbook_str = etree.tostring(dtbook,
                                pretty_print=True,
                                encoding='utf-8',
                                xml_declaration=True)

    return dtbook_str
```

**Output:** dtbook.xml file
**Time:** 2 minutes

### Step 2: Generate Audio with TTS (5-8 minutes)

**Code Example:**
```python
from gtts import gTTS
import os

def generate_tts_audio(text, output_path, language='en'):
    """Generate text-to-speech audio using Google TTS"""

    # For production, use premium TTS:
    # - Amazon Polly
    # - Google Cloud TTS
    # - Microsoft Azure TTS
    # - ElevenLabs (most natural)

    # Example with Google TTS (basic)
    tts = gTTS(text=text, lang=language, slow=False)
    tts.save(output_path)

    return output_path

def generate_chapter_audio(chapters, output_dir):
    """Generate audio for all chapters"""

    audio_files = []

    for i, chapter in enumerate(chapters):
        # Combine chapter title and content
        full_text = f"{chapter['title']}. "
        full_text += " ".join([p['text'] for p in chapter['paragraphs']])

        # Generate audio
        audio_path = os.path.join(output_dir, f"chapter{i+1:02d}.mp3")
        generate_tts_audio(full_text, audio_path)

        audio_files.append({
            'chapter_num': i + 1,
            'path': audio_path,
            'duration': get_audio_duration(audio_path)
        })

    return audio_files

def get_audio_duration(audio_path):
    """Get audio file duration in seconds"""
    from mutagen.mp3 import MP3
    audio = MP3(audio_path)
    return audio.info.length
```

**Output:** MP3 audio files for each chapter
**Time:** 5-8 minutes (depends on book length)

### Step 3: Create SMIL Synchronization Files (2 minutes)

**Code Example:**
```python
def create_smil_file(chapter_data, audio_file, output_path):
    """Create SMIL file for text-audio synchronization"""

    smil = f'''<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE smil PUBLIC "-//W3C//DTD SMIL 1.0//EN"
    "http://www.w3.org/TR/REC-smil/SMIL10.dtd">
<smil>
  <head>
    <meta name="dc:format" content="Daisy 2.02"/>
    <meta name="dc:title" content="{chapter_data['title']}"/>
    <layout>
      <region id="textView"/>
    </layout>
  </head>
  <body>
    <seq dur="{chapter_data['duration']}s">
'''

    # Add synchronized paragraphs
    current_time = 0
    for i, para in enumerate(chapter_data['paragraphs']):
        para_id = f"ch{chapter_data['num']}_p{i+1}"
        para_duration = para['audio_duration']

        smil += f'''      <par endsync="last">
        <text src="text/chapter{chapter_data['num']:02d}.html#{para_id}"
              id="text_{para_id}" region="textView"/>
        <audio src="../audio/{audio_file}"
               clip-begin="{current_time}s"
               clip-end="{current_time + para_duration}s"
               id="audio_{para_id}"/>
      </par>
'''
        current_time += para_duration

    smil += '''    </seq>
  </body>
</smil>'''

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(smil)

    return output_path
```

**Output:** SMIL files for synchronization
**Time:** 2 minutes

### Step 4: Create Navigation Control Center (NCC) (1 minute)

**Code Example:**
```python
def create_ncc_html(book_data, chapters, audio_files):
    """Create NCC.html navigation file"""

    ncc = f'''<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>{book_data['title']}</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  <meta name="dc:format" content="Daisy 2.02"/>
  <meta name="dc:title" content="{book_data['title']}"/>
  <meta name="dc:creator" content="{book_data['author']}"/>
  <meta name="dc:publisher" content="{book_data['publisher']}"/>
  <meta name="dc:date" content="{book_data['date']}"/>
  <meta name="ncc:generator" content="Educational Books DAISY Generator"/>
  <meta name="ncc:totalTime" content="{calculate_total_time(audio_files)}"/>
  <meta name="ncc:multimediaType" content="audioFullText"/>
</head>
<body>
  <h1 class="title" id="ncc_title">{book_data['title']}</h1>
  <h2 class="author">{book_data['author']}</h2>
'''

    # Add navigation links
    for i, chapter in enumerate(chapters):
        ncc += f'''  <h2 class="chapter">
    <a href="smil/chapter{i+1:02d}.smil#ch{i+1}_h1">
      {chapter['title']}
    </a>
  </h2>
'''

    ncc += '''</body>
</html>'''

    return ncc

def calculate_total_time(audio_files):
    """Calculate total time in HH:MM:SS format"""
    total_seconds = sum(f['duration'] for f in audio_files)
    hours = int(total_seconds // 3600)
    minutes = int((total_seconds % 3600) // 60)
    seconds = int(total_seconds % 60)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
```

**Output:** ncc.html navigation file
**Time:** 1 minute

### Step 5: Package DAISY Book (30 seconds)

**Code Example:**
```python
import zipfile

def package_daisy_book(source_dir, output_path):
    """Package DAISY book into ZIP file"""

    with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(source_dir):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, source_dir)
                zipf.write(file_path, arcname)

    return output_path
```

**Output:** Final DAISY book ZIP package
**Time:** 30 seconds

**Total Time:** 10-15 minutes per book

---

## Quality Verification

### Automated Checks
1. Validates with DAISY Pipeline
2. All audio files present
3. All SMIL files valid
4. NCX navigation complete
5. DTBook XML valid
6. All images have descriptions
7. Metadata complete
8. File structure correct

### Testing Checklist
- [ ] Opens in Victor Reader Stream
- [ ] Opens in Dolphin EasyReader
- [ ] Opens in AMIS player
- [ ] Navigation works (jump to chapter)
- [ ] Audio plays correctly
- [ ] Text displays synchronized with audio
- [ ] All headings navigable
- [ ] Images described verbally
- [ ] Reading order correct
- [ ] Bookmarks work

---

## Tools & Libraries

### Python Libraries
```txt
lxml==4.9.3
gtts==2.3.0
mutagen==1.46.0
beautifulsoup4==4.12.2
```

### External Tools
- **DAISY Pipeline 2:** Validation and conversion
- **Obi:** DAISY authoring tool
- **Tobi:** DAISY production tool

### Installation
```bash
pip install lxml gtts mutagen beautifulsoup4

# Download DAISY Pipeline 2
wget http://www.daisy.org/pipeline2/download
```

---

## Storage & Naming

### File Naming Convention
```
{book_id}_{reading_level}_{disability}_daisy30.zip

Examples:
math_algebra_college_blind_daisy30.zip
science_biology_elementary_dyslexia_daisy30.zip
```

---

## Performance Metrics

### Generation Speed
- **Target:** 10 minutes for 200 pages (with TTS)
- **Maximum:** 20 minutes

### File Size
- **Text-only:** 20-50 MB
- **With audio:** 200-500 MB

---

## Related Formats

### EPUB 3.0 with Media Overlays
**Difference:** Modern alternative to DAISY, more widely supported
**When to use instead:** Modern devices, broader compatibility

### MP3 Audiobook
**Difference:** Audio only, no synchronized text
**When to use instead:** Audio-only distribution
