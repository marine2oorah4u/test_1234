# Format Blueprint: xAPI (Tin Can API) Package

## Metadata
- **Format ID**: `13_XAPI_TIN_CAN`
- **Format Name**: xAPI / Tin Can API Package
- **Tier**: 4 (Interactive Formats)
- **File Extension**: `.zip` (contains xAPI package)
- **Priority**: High (modern LMS standard)
- **Accessibility Level**: High (modern web standards)

---

## Overview

### Purpose
Create an Experience API (xAPI/Tin Can) package for modern learning platforms. Provides richer tracking than SCORM with support for mobile, offline, and complex learning scenarios.

### Use Cases
- Modern LMS platforms (TalentLMS, Docebo, LearnDash)
- Mobile learning applications
- Offline learning experiences
- Social learning tracking
- Multi-device learning journeys
- Video-based courses with detailed analytics

---

## Technical Specifications

### xAPI Version
- **Standard**: xAPI 1.0.3 (current specification)
- **Profile**: cmi5 (if LMS-launched)

### Package Structure
```
xapi_package/
├── tincan.xml               # Package manifest
├── index.html               # Launch file
├── content/
│   ├── pages/               # Course pages
│   ├── media/               # Videos, images
│   ├── css/                 # Stylesheets
│   └── js/                  # JavaScript
├── xapi/
│   ├── xAPIWrapper.js       # xAPI library
│   ├── StatementQueue.js    # Offline support
│   └── config.js            # Configuration
└── data/
    ├── actors.json          # Learner profiles
    └── activities.json      # Activity definitions
```

### xAPI Statement Structure
Every learner interaction creates an xAPI statement:
```json
{
  "actor": {
    "name": "John Doe",
    "mbox": "mailto:john@example.com",
    "objectType": "Agent"
  },
  "verb": {
    "id": "http://adlnet.gov/expapi/verbs/completed",
    "display": {"en-US": "completed"}
  },
  "object": {
    "id": "http://example.com/activities/chapter-1",
    "definition": {
      "name": {"en-US": "Chapter 1: Introduction"},
      "description": {"en-US": "Introduction to core concepts"},
      "type": "http://adlnet.gov/expapi/activities/lesson"
    }
  },
  "result": {
    "score": {"scaled": 0.95, "raw": 95, "min": 0, "max": 100},
    "success": true,
    "completion": true,
    "duration": "PT15M30S"
  },
  "context": {
    "contextActivities": {
      "parent": [{"id": "http://example.com/activities/course"}]
    }
  }
}
```

### Key xAPI Verbs (ADL Vocabulary)
- **experienced**: Viewed/read content
- **completed**: Finished an activity
- **passed**: Successfully completed assessment
- **failed**: Did not pass assessment
- **answered**: Responded to question
- **mastered**: Achieved mastery level
- **progressed**: Advanced through content
- **attempted**: Started an activity
- **interacted**: Engaged with interactive element
- **watched**: Viewed video content

---

## Conversion Workflow

### Step 1: Activity Mapping
- Map each chapter/section to xAPI activity ID
- Define activity types (lesson, assessment, resource)
- Create activity hierarchy (course → chapters → sections)
- Generate unique, stable activity IRIs

### Step 2: Verb Selection
- Identify trackable interactions
- Choose appropriate verbs from ADL vocabulary
- Define custom verbs if needed
- Create verb usage guidelines

### Step 3: Statement Design
- Design statement templates for each interaction
- Define result structure (scores, completion)
- Plan context data (parent activities, categories)
- Create extensions for custom data

### Step 4: Package Creation
- Generate `tincan.xml` manifest
- Create HTML5 content pages
- Integrate xAPIWrapper library
- Implement statement generation
- Add offline caching (localStorage)

### Step 5: LRS Integration
- Configure LRS endpoints
- Implement authentication (OAuth 2.0 or Basic Auth)
- Add statement batching for performance
- Create retry logic for failed statements

### Step 6: Testing & Validation
- Test statement structure with ADL xAPI validator
- Verify LRS communication
- Test offline functionality
- Validate mobile responsiveness
- Check multi-device scenarios

---

## Quality Checklist

### Technical Requirements
- [ ] Valid `tincan.xml` manifest
- [ ] xAPI statements conform to 1.0.3 spec
- [ ] Unique activity IRIs for all activities
- [ ] Proper verb usage (ADL vocabulary)
- [ ] Actor identification working
- [ ] LRS communication functional
- [ ] Authentication implemented
- [ ] Offline statement queuing
- [ ] Statement batching for performance

### Content Requirements
- [ ] All chapters trackable as activities
- [ ] Video progress tracked (if applicable)
- [ ] Quiz responses captured
- [ ] Navigation tracked
- [ ] Time spent recorded accurately
- [ ] Completion criteria defined

### Accessibility Requirements
- [ ] WCAG 2.1 AA compliant
- [ ] Screen reader compatible
- [ ] Keyboard navigation
- [ ] Alt text for media
- [ ] Captions for videos
- [ ] Responsive design

### LRS Compatibility
- [ ] Works with Learning Locker
- [ ] Works with Watershed LRS
- [ ] Works with Veracity Learning
- [ ] Works with SCORM Cloud (xAPI support)
- [ ] Mobile device compatible

---

## Sample tincan.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<tincan xmlns="http://projecttincan.com/tincan.xsd">
  <activities>
    <activity id="http://example.com/book/12345" type="http://adlnet.gov/expapi/activities/course">
      <name>Complete Book Title</name>
      <description>Full course based on the book content</description>
      <launch lang="en-US">index.html</launch>
    </activity>
  </activities>
</tincan>
```

---

## xAPI Statement Examples

### Chapter Completion
```json
{
  "actor": {"mbox": "mailto:learner@example.com"},
  "verb": {
    "id": "http://adlnet.gov/expapi/verbs/completed",
    "display": {"en-US": "completed"}
  },
  "object": {
    "id": "http://example.com/book/chapter/3",
    "definition": {
      "name": {"en-US": "Chapter 3: Advanced Topics"},
      "type": "http://adlnet.gov/expapi/activities/lesson"
    }
  },
  "result": {
    "completion": true,
    "duration": "PT22M15S"
  }
}
```

### Quiz Answer
```json
{
  "actor": {"mbox": "mailto:learner@example.com"},
  "verb": {
    "id": "http://adlnet.gov/expapi/verbs/answered",
    "display": {"en-US": "answered"}
  },
  "object": {
    "id": "http://example.com/book/quiz/q5",
    "definition": {
      "name": {"en-US": "Question 5"},
      "type": "http://adlnet.gov/expapi/activities/cmi.interaction",
      "interactionType": "choice",
      "correctResponsesPattern": ["B"],
      "choices": [
        {"id": "A", "description": {"en-US": "Option A"}},
        {"id": "B", "description": {"en-US": "Option B"}},
        {"id": "C", "description": {"en-US": "Option C"}}
      ]
    }
  },
  "result": {
    "response": "B",
    "success": true,
    "score": {"raw": 1, "min": 0, "max": 1}
  }
}
```

### Video Progress
```json
{
  "actor": {"mbox": "mailto:learner@example.com"},
  "verb": {
    "id": "http://adlnet.gov/expapi/verbs/progressed",
    "display": {"en-US": "progressed"}
  },
  "object": {
    "id": "http://example.com/book/video/intro",
    "definition": {
      "name": {"en-US": "Introduction Video"},
      "type": "https://w3id.org/xapi/video/activity-type/video"
    }
  },
  "result": {
    "extensions": {
      "https://w3id.org/xapi/video/extensions/time": 145.6,
      "https://w3id.org/xapi/video/extensions/progress": 0.65
    }
  }
}
```

---

## AI Model Recommendations

### Primary Models
- **Statement Design**: Claude Sonnet (structured data)
- **JavaScript Integration**: GPT-4 (code generation)
- **Activity Mapping**: Gemini Pro (content analysis)
- **Verb Selection**: Claude Opus (semantic understanding)

### Verification Models
- **Statement Validation**: GPT-4 (JSON schema validation)
- **LRS Testing**: Claude Sonnet (integration testing)
- **Performance**: Gemini Pro (optimization)

---

## Output Structure

### Primary Output
- **File**: `[BookTitle]_xAPI_Package.zip`
- **Size**: Optimized for web delivery
- **Contents**: Complete xAPI package

### Additional Files
- `xAPI_Implementation_Guide.pdf` - Setup instructions
- `Statement_Reference.json` - All statement templates
- `LRS_Configuration.txt` - Connection settings
- `Analytics_Dashboard_Setup.pdf` - Reporting configuration

---

## Metadata to Include

```json
{
  "format": "xAPI Package",
  "xapi_version": "1.0.3",
  "total_activities": 18,
  "trackable_interactions": 245,
  "supported_verbs": [
    "experienced",
    "completed",
    "passed",
    "answered",
    "progressed",
    "mastered"
  ],
  "offline_capable": true,
  "mobile_optimized": true,
  "estimated_statements": 500,
  "analytics_ready": true,
  "tested_lrs": [
    "Learning Locker",
    "Watershed",
    "SCORM Cloud"
  ]
}
```

---

## Advantages Over SCORM

1. **Richer Data**: Track any experience, not just LMS activities
2. **Mobile Native**: Works on any device, online or offline
3. **Social Learning**: Track discussions, collaborations
4. **Video Analytics**: Detailed video interaction data
5. **Flexible**: No SCO structure limitations
6. **Modern**: Uses RESTful APIs and JSON
7. **Granular**: Track individual interactions, not just completion

---

## Best Practices

1. **Stable IRIs**: Use permanent, unchanging activity identifiers
2. **Batch Statements**: Send multiple statements together
3. **Offline First**: Queue statements when offline
4. **Meaningful Verbs**: Choose verbs that match actions precisely
5. **Rich Context**: Include parent activities and categories
6. **Privacy**: Consider anonymization for sensitive data
7. **Standard Extensions**: Use community-defined extensions

---

## Related Formats

- **12_SCORM_PACKAGE.md**: Traditional LMS format
- **14_INTERACTIVE_PDF.md**: Simpler interactive option
- **15_H5P_PACKAGE.md**: HTML5 interactive content

---

## Update History
- **2025-12-03**: Initial blueprint created
