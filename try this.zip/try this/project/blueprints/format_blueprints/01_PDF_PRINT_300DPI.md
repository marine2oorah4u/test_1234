# Format Blueprint: PDF Print 300 DPI

## Basic Information
- **File Extension:** `.pdf`
- **Format Type:** Print
- **Tier:** 1 (Core - Always Generate)
- **Priority:** ALWAYS
- **Generation Time:** 3-5 minutes per 200 pages
- **File Size Estimate:** 40-60 MB for 200 pages with images

---

## Purpose & Use Case

**Primary Purpose:**
Professional-quality printing for physical books, bookstores, and print-on-demand services.

**Best Used For:**
- Commercial printing (offset, digital)
- Print-on-demand services (Amazon KDP, IngramSpark, Lulu)
- Bookstore distribution
- Library physical copies
- Professional archival copies

**Distribution Channels:**
- Print-on-demand platforms
- Commercial printers
- Self-publishing services
- Educational institutions (bulk printing)

---

## Technical Specifications

### Core Requirements
- **Resolution:** 300 DPI (dots per inch) minimum
- **Color Space:** CMYK for color printing
- **Color Space (Alternative):** Grayscale for black/white books
- **Page Size:** 8.5" × 11" (US Letter) or custom trim size
- **Bleed:** 0.125" (3mm) on all sides that go to edge
- **Trim Marks:** Yes (crop marks for cutting)
- **Font Embedding:** All fonts must be embedded or outlined
- **PDF Version:** PDF/X-1a:2001 or PDF/X-4
- **Compression:** JPEG (quality 90-95) for images
- **Text:** Vector (no rasterization)

### File Structure
```
PDF Structure:
├── Document Catalog
├── Metadata (XMP)
├── Page Tree
│   ├── Page 1 (Cover)
│   ├── Page 2 (Copyright)
│   ├── Page 3 (Table of Contents)
│   ├── Pages 4-N (Content)
│   └── Page N+1 (Index/Back Matter)
├── Fonts (Embedded)
├── Images (300 DPI CMYK)
├── Color Profile (ICC)
└── Crop/Bleed Marks
```

### Quality Standards
- **Color Accuracy:** SWOP CMYK color profile
- **Black Text:** 100% K (not rich black)
- **Image Resolution:** Minimum 300 DPI, maximum 400 DPI
- **Line Weights:** Minimum 0.25pt for printed lines
- **Overprint Settings:** Black text overprints
- **Transparency:** Flattened (no live transparency)
- **Layers:** Flattened to single layer
- **Security:** No password protection
- **Editable:** No (final locked file)

### Metadata Requirements
```json
{
  "title": "Book Title",
  "author": "Author Name",
  "subject": "Book Subject",
  "keywords": "keyword1, keyword2, keyword3",
  "creator": "Educational Books System v1.0",
  "producer": "PDF Generation Engine",
  "isbn": "ISBN-13 number",
  "copyright": "Copyright Year, Publisher",
  "language": "en-US",
  "page_count": 200,
  "trim_size": "8.5x11",
  "binding_type": "perfect_bound",
  "creation_date": "2024-12-03",
  "modification_date": "2024-12-03"
}
```

---

## Generation Process

### Input Requirements
**From Previous Pipeline:**
- Master book content (HTML/JSON with full formatting)
- Images in original high resolution (minimum 300 DPI)
- Vector graphics in SVG or high-res PNG
- Fonts used in the book (TTF/OTF files)
- Table of contents structure
- Page layout specifications
- Metadata JSON

**Format-Specific Needs:**
- Color profile: SWOP CMYK ICC profile
- Bleed specifications (if cover/full-bleed pages)
- Trim size specifications
- Binding type (perfect bound, saddle stitch, etc.)
- Spine width calculation (based on page count)

### Step-by-Step Process

#### Step 1: Content Preparation (30 seconds)
**Action:**
- Parse master book HTML/JSON
- Extract all text content
- Identify all image references
- Build document structure (chapters, sections, pages)

**Tools/Libraries:**
- Python: `BeautifulSoup4` or `lxml` for HTML parsing
- `json` module for JSON parsing

**Output:**
- Structured document tree
- List of all assets (images, fonts)

**Time:** 30 seconds

#### Step 2: Image Processing (1-2 minutes)
**Action:**
- Convert all images to CMYK color space
- Ensure all images are at least 300 DPI
- Compress images to JPEG quality 90-95
- Resize oversized images (max 400 DPI)
- Add bleed to full-page images

**Tools/Libraries:**
- Python: `Pillow (PIL)` for image processing
- `ImageMagick` for advanced conversions
- ICC color profiles for CMYK conversion

**Code Example:**
```python
from PIL import Image, ImageCms
import os

def convert_to_cmyk_300dpi(input_path, output_path):
    # Open image
    img = Image.open(input_path)

    # Convert to RGB first if needed
    if img.mode != 'RGB':
        img = img.convert('RGB')

    # Check and adjust DPI
    dpi = img.info.get('dpi', (72, 72))[0]
    if dpi < 300:
        # Resample to 300 DPI
        scale = 300 / dpi
        new_size = (int(img.width * scale), int(img.height * scale))
        img = img.resize(new_size, Image.LANCZOS)

    # Convert to CMYK
    cmyk_profile = ImageCms.getOpenProfile('SWOP2006_Coated5v2.icc')
    srgb_profile = ImageCms.createProfile('sRGB')
    img_cmyk = ImageCms.profileToProfile(img, srgb_profile, cmyk_profile,
                                          outputMode='CMYK')

    # Save with compression
    img_cmyk.save(output_path, 'JPEG', quality=92, dpi=(300, 300))

    return output_path
```

**Output:**
- CMYK JPEG images at 300 DPI
- Image manifest file

**Time:** 1-2 minutes

#### Step 3: Page Layout Generation (1-2 minutes)
**Action:**
- Create page templates based on book type
- Apply typography (fonts, sizes, spacing)
- Calculate line breaks and pagination
- Position images and captions
- Add headers, footers, page numbers
- Create bleed area and trim box
- Add crop marks

**Tools/Libraries:**
- `ReportLab` (Python PDF library)
- `WeasyPrint` (HTML to PDF)
- `Prince XML` (commercial, best quality)

**Code Example:**
```python
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader

def create_print_pdf(content, output_path):
    # Define page size with bleed
    bleed = 0.125 * inch  # 0.125 inches
    page_width, page_height = letter

    # Create canvas
    c = canvas.Canvas(output_path, pagesize=letter)

    # Set up for print
    c.setTitle(content['title'])
    c.setAuthor(content['author'])

    # Add bleed box
    c.setPageSize((page_width + 2*bleed, page_height + 2*bleed))

    # Add trim box (actual page size)
    c.setMediaBox(bleed, bleed, page_width + bleed, page_height + bleed)

    # Add crop marks
    add_crop_marks(c, page_width, page_height, bleed)

    # Generate pages
    for page in content['pages']:
        render_page(c, page, bleed)
        c.showPage()

    # Save PDF
    c.save()

    return output_path

def add_crop_marks(canvas, width, height, bleed):
    """Add printer crop marks"""
    mark_length = 0.25 * inch
    canvas.setStrokeColorRGB(0, 0, 0)
    canvas.setLineWidth(0.5)

    # Top-left corner
    canvas.line(0, height + bleed, mark_length, height + bleed)  # Horizontal
    canvas.line(bleed, height, bleed, height + mark_length)  # Vertical

    # Top-right corner
    canvas.line(width + bleed, height + bleed, width + 2*bleed - mark_length, height + bleed)
    canvas.line(width + bleed, height, width + bleed, height + mark_length)

    # Bottom-left corner
    canvas.line(0, bleed, mark_length, bleed)
    canvas.line(bleed, 0, bleed, mark_length)

    # Bottom-right corner
    canvas.line(width + bleed, bleed, width + 2*bleed - mark_length, bleed)
    canvas.line(width + bleed, 0, width + bleed, mark_length)
```

**Output:**
- Paginated PDF with proper layout
- Crop marks and bleed areas

**Time:** 1-2 minutes

#### Step 4: Font Embedding (15 seconds)
**Action:**
- Embed all fonts used in the document
- Convert text to outlines if font licensing prohibits embedding
- Verify all glyphs are present
- Subset fonts to reduce file size

**Tools/Libraries:**
- `PyPDF2` or `pikepdf` for font manipulation
- `fonttools` for font subsetting

**Code Example:**
```python
from pikepdf import Pdf

def embed_fonts(pdf_path):
    """Ensure all fonts are embedded"""
    pdf = Pdf.open(pdf_path)

    for page in pdf.pages:
        # Check for fonts
        if '/Font' in page.Resources:
            fonts = page.Resources.Font
            for font_name in fonts:
                font = fonts[font_name]
                # Verify font is embedded
                if '/FontFile' not in font and '/FontFile2' not in font:
                    raise ValueError(f"Font {font_name} is not embedded!")

    pdf.save(pdf_path)
    return pdf_path
```

**Output:**
- PDF with all fonts embedded
- Font verification report

**Time:** 15 seconds

#### Step 5: Color Space Conversion (30 seconds)
**Action:**
- Convert document color space to CMYK
- Apply ICC color profile
- Ensure black text is 100% K
- Convert RGB colors to CMYK equivalents
- Flatten transparency

**Tools/Libraries:**
- `Ghostscript` for color conversion
- `pikepdf` for PDF manipulation

**Code Example:**
```bash
# Ghostscript command to convert to CMYK PDF/X-1a
gs -dPDFX \
   -dBATCH \
   -dNOPAUSE \
   -sDEVICE=pdfwrite \
   -sColorConversionStrategy=CMYK \
   -dOverrideICC \
   -sOutputFile=output_cmyk.pdf \
   input_rgb.pdf
```

**Output:**
- CMYK PDF ready for printing
- Color conversion report

**Time:** 30 seconds

#### Step 6: PDF/X Compliance (30 seconds)
**Action:**
- Convert to PDF/X-1a or PDF/X-4 standard
- Add required PDF/X metadata
- Remove interactive elements (buttons, forms)
- Flatten all layers
- Add output intent (printing condition)

**Tools/Libraries:**
- `Ghostscript` with PDFX_def.ps settings
- Adobe Acrobat Preflight (commercial)

**Code Example:**
```python
import subprocess

def make_pdfx_compliant(input_pdf, output_pdf):
    """Convert PDF to PDF/X-1a standard"""

    # Create PDFX settings file
    pdfx_settings = """
    /OutputConditionIdentifier (CGATS TR 001)
    /Info (SWOP Coated Grade 3, 300 lpi)
    /Type /OutputIntent
    /S /GTS_PDFX
    /DestOutputProfile (SWOP2006_Coated5v2.icc)
    """

    # Run Ghostscript
    cmd = [
        'gs',
        '-dPDFX',
        '-dBATCH',
        '-dNOPAUSE',
        '-dNOOUTERSAVE',
        '-sDEVICE=pdfwrite',
        f'-sOutputFile={output_pdf}',
        'PDFX_def.ps',
        input_pdf
    ]

    subprocess.run(cmd, check=True)
    return output_pdf
```

**Output:**
- PDF/X-1a compliant file
- Compliance report

**Time:** 30 seconds

#### Step 7: Quality Verification (30 seconds)
**Action:**
- Validate PDF/X compliance
- Check all images are 300 DPI
- Verify fonts are embedded
- Check color space is CMYK
- Validate trim box and bleed box
- Check file size
- Verify page count
- Test print sample page

**Tools/Libraries:**
- `pdfinfo` (command-line tool)
- `jhove` (PDF validation)
- Adobe Acrobat Preflight

**Code Example:**
```python
import subprocess
import json

def validate_print_pdf(pdf_path):
    """Validate PDF for printing"""

    issues = []

    # Check PDF/X compliance
    result = subprocess.run(
        ['pdfinfo', pdf_path],
        capture_output=True,
        text=True
    )

    info = result.stdout

    # Check required specifications
    if 'PDF-X' not in info:
        issues.append("Not PDF/X compliant")

    if '300' not in info:
        issues.append("Images may not be 300 DPI")

    # Check file size
    import os
    size_mb = os.path.getsize(pdf_path) / (1024 * 1024)
    if size_mb > 100:
        issues.append(f"File size too large: {size_mb:.1f}MB")

    return {
        'valid': len(issues) == 0,
        'issues': issues,
        'size_mb': size_mb
    }
```

**Output:**
- Validation report (pass/fail)
- List of any issues found

**Time:** 30 seconds

#### Step 8: Finalization (15 seconds)
**Action:**
- Add final metadata
- Optimize file size (if needed)
- Generate filename
- Move to storage location
- Create backup copy
- Update database record

**Tools/Libraries:**
- `pikepdf` for final metadata
- `pdftk` for optimization

**Output:**
- Final print-ready PDF
- Storage confirmation
- Database entry

**Time:** 15 seconds

**Total Time:** 3-5 minutes per book

---

## Quality Verification

### Automated Checks
1. **File Integrity:** PDF opens without errors
2. **PDF/X Validation:** Passes PDF/X-1a or PDF/X-4 validation
3. **DPI Check:** All images minimum 300 DPI
4. **Font Check:** All fonts embedded or outlined
5. **Color Space:** Document in CMYK
6. **Bleed Check:** Bleed area present (0.125")
7. **Size Check:** File size 40-60 MB for 200 pages
8. **Page Count:** Matches expected page count
9. **Metadata:** All required fields populated

### Manual Review Points
1. **Visual Inspection:** Sample pages look correct
2. **Print Test:** Test print 2-3 pages
3. **Color Accuracy:** Colors match design intent
4. **Crop Mark Alignment:** Marks in correct position
5. **Text Clarity:** Text is sharp and readable
6. **Image Quality:** Images are crisp, no pixelation

### Pass/Fail Criteria
- ✅ **Must Pass:**
  - PDF/X compliant
  - All images 300 DPI minimum
  - All fonts embedded
  - CMYK color space
  - Bleed present where needed
  - No transparency
  - Opens without errors

- ⚠️ **Should Pass:**
  - File size under 60 MB
  - Black text is 100% K
  - Crop marks present
  - Metadata complete

- ℹ️ **Nice to Have:**
  - File size under 50 MB
  - Images exactly 300 DPI (not higher)
  - Fonts subsetted to reduce size

---

## Tools & Libraries

### Required Software
- **Python 3.9+:** Core programming
- **Ghostscript:** PDF/X conversion and color management
- **ImageMagick:** Image processing (alternative to Pillow)

### Python Libraries
```txt
Pillow==10.0.0          # Image processing
pikepdf==8.4.0          # PDF manipulation
reportlab==4.0.4        # PDF generation
beautifulsoup4==4.12.2  # HTML parsing
lxml==4.9.3             # XML/HTML parsing
fonttools==4.42.1       # Font handling
```

### Installation
```bash
# Install Python packages
pip install Pillow pikepdf reportlab beautifulsoup4 lxml fonttools

# Install Ghostscript (Ubuntu/Debian)
sudo apt-get install ghostscript

# Install Ghostscript (macOS)
brew install ghostscript

# Install ImageMagick (optional)
sudo apt-get install imagemagick
```

### Command-Line Tools
```bash
# Verify installations
gs --version          # Ghostscript
convert --version     # ImageMagick
pdfinfo --version     # Poppler utils
```

---

## Error Handling

### Common Issues

1. **Issue:** Images are low resolution (under 300 DPI)
   - **Cause:** Source images captured at screen resolution (72-96 DPI)
   - **Solution:**
     - Request higher resolution images
     - Upscale with AI (not ideal, quality loss)
     - Use vector graphics where possible
     - Regenerate diagrams at 300 DPI

2. **Issue:** PDF not PDF/X compliant
   - **Cause:** Transparency not flattened, or RGB color space
   - **Solution:**
     - Run through Ghostscript PDF/X conversion
     - Flatten all transparency layers
     - Convert to CMYK color space
     - Remove interactive elements

3. **Issue:** Fonts not embedded
   - **Cause:** Font licensing restrictions
   - **Solution:**
     - Use alternative open-source fonts
     - Convert text to outlines (last resort)
     - Get proper font license
     - Use web-safe fonts that allow embedding

4. **Issue:** File size too large (over 100 MB)
   - **Cause:** Uncompressed images or redundant data
   - **Solution:**
     - Compress images to JPEG 90-92 quality
     - Remove embedded thumbnails
     - Subset fonts
     - Optimize with `pdftk` or Ghostscript

5. **Issue:** Crop marks missing or misaligned
   - **Cause:** Template error or incorrect page size
   - **Solution:**
     - Recalculate bleed area
     - Regenerate with correct crop mark function
     - Verify page size matches trim size

### Fallback Strategies
- **If PDF/X conversion fails:** Generate standard PDF and manually convert with Adobe Acrobat
- **If font embedding fails:** Convert all text to outlines (increases file size)
- **If image quality insufficient:** Use placeholder and flag for manual replacement
- **If file size too large:** Reduce image quality to 85-90 (acceptable minimum)

---

## Storage & Naming

### File Naming Convention
```
{book_id}_{reading_level}_{disability}_print_300dpi.pdf

Examples:
math_algebra_college_standard_print_300dpi.pdf
math_algebra_elementary_dyslexia_print_300dpi.pdf
science_biology_highschool_blind_print_300dpi.pdf
```

### Storage Location
```
/storage/books/{subject}/{book_id}/formats/
  ├── math_algebra_college_standard_print_300dpi.pdf
  ├── math_algebra_college_standard_digital_150dpi.pdf
  ├── math_algebra_college_standard.epub
  └── ...
```

### Backup Strategy
- **Primary Storage:** Supabase Storage bucket `book-formats`
- **Backup Location:** AWS S3 bucket (daily sync)
- **Archive Policy:** Keep all versions, archive after 90 days

---

## Accessibility Considerations

### WCAG Compliance
- **Level:** N/A (print format, not web)
- **Requirements:** Physical accessibility handled through alternative formats
- **Exceptions:** Print format is not accessible to blind users (use DAISY/Braille instead)

### Screen Reader Compatibility
- **Compatibility:** None (print format)
- **Alternative:** Generate PDF Digital 150 DPI for screen readers

---

## Testing Checklist

- [ ] File generates without errors
- [ ] File size between 40-60 MB (for 200 page book)
- [ ] PDF/X-1a or PDF/X-4 compliant
- [ ] All images minimum 300 DPI
- [ ] All images in CMYK color space
- [ ] All fonts embedded or outlined
- [ ] Bleed area present (0.125" on all sides)
- [ ] Crop marks visible and correctly positioned
- [ ] Black text is 100% K (not rich black)
- [ ] Transparency flattened
- [ ] Metadata complete and accurate
- [ ] Opens correctly in Adobe Acrobat
- [ ] Opens correctly in PDF readers
- [ ] Test print shows correct colors
- [ ] Test print shows sharp text
- [ ] Page count matches expected

---

## Performance Metrics

### Generation Speed
- **Target:** 3 minutes for 200 pages
- **Average:** 4 minutes
- **Maximum Acceptable:** 7 minutes

### Success Rate
- **Target:** 99%+
- **Current:** Track in database

### File Quality
- **Target:** 100% PDF/X compliant
- **Current:** Track in database

---

## Examples

### Sample Generation Command
```python
from book_generator import PDFPrintGenerator

# Initialize generator
generator = PDFPrintGenerator(
    dpi=300,
    color_space='CMYK',
    pdfx_standard='X-1a',
    bleed_inches=0.125
)

# Generate PDF
result = generator.generate(
    input_file='book_master.json',
    output_file='book_print_300dpi.pdf',
    trim_size='8.5x11',
    binding='perfect'
)

print(f"Generated: {result.path}")
print(f"Size: {result.size_mb}MB")
print(f"Valid: {result.validation.passed}")
```

### Sample Output Structure
```
book_print_300dpi.pdf
├── Pages: 200
├── Size: 52.3 MB
├── Format: PDF/X-1a
├── Color: CMYK
├── Fonts: 5 embedded
├── Images: 87 at 300 DPI
└── Bleed: 0.125" all sides
```

---

## Version History

- **v1.0** (2024-12-03) - Initial blueprint
- Future versions will be tracked here

---

## Notes & Best Practices

### Best Practices
1. **Always check source image DPI before processing** - Upscaling loses quality
2. **Use vector graphics (SVG) where possible** - Scale to any resolution
3. **Test print a sample** before printing entire run
4. **Keep original high-res images** - Never downscale originals
5. **Verify PDF/X compliance** - Saves expensive reprints
6. **Use professional color profiles** - SWOP2006 Coated is industry standard
7. **Flatten transparency early** - Prevents unexpected results
8. **Subset fonts** - Reduces file size significantly
9. **Keep page count divisible by 4** - Printing requirement (signatures)
10. **Budget extra time for large image-heavy books** - Science and art books take longer

### Important Considerations
- **Print costs vary by DPI:** 300 DPI is sweet spot for quality vs. cost
- **File size affects upload/download times:** Keep under 60 MB when possible
- **Some printers require specific PDF/X versions:** Check with printer first
- **Color accuracy depends on paper stock:** Coated vs. uncoated affects appearance
- **Binding method affects margins:** Perfect binding needs larger inner margins

### Known Limitations
- **Cannot improve source image quality** - Low-res images will look blurry
- **CMYK color gamut smaller than RGB** - Some colors may shift
- **Large files slow to process** - 500+ page books may take 15-20 minutes
- **Font licensing can restrict embedding** - Always check license terms

---

## Related Formats

### PDF Digital 150 DPI
**Difference:** Lower resolution (150 vs. 300 DPI), RGB color space, smaller file size
**When to use instead:** For screen reading, email distribution, quick previews

### Print-Ready with Bleeds
**Difference:** Additional bleed area, registration marks, color bars
**When to use instead:** For professional commercial printing runs (500+ copies)

### Large Print PDF
**Difference:** Larger font sizes (18-24pt), simplified layout
**When to use instead:** For low vision readers, seniors, accessibility needs
