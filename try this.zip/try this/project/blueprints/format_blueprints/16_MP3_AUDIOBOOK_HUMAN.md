# Format Blueprint: MP3 Audiobook (Human Narration)

## Metadata
- **Format ID**: `16_MP3_AUDIOBOOK_HUMAN`
- **Format Name**: MP3 Audiobook - Human Narrated
- **Tier**: 5 (Audio Formats)
- **File Extension**: `.mp3` (chapter files) or `.zip` (complete)
- **Priority**: High (premium audio experience)
- **Accessibility Level**: Critical (for blind/low vision users)

---

## Overview

### Purpose
Professional human-narrated audiobook in MP3 format. Provides premium listening experience with expressive narration, proper pacing, and high production values.

### Use Cases
- Accessibility for blind/low vision users
- Commuters and travelers
- Multitasking learners (exercise, chores)
- Auditory learners
- Premium educational products
- Professional training materials

---

## Technical Specifications

### Audio Quality

#### Standard Quality (Most Common)
- **Bitrate**: 128 kbps CBR (Constant Bit Rate)
- **Sample Rate**: 44.1 kHz
- **Channels**: Mono (narration) or Stereo (if music/effects)
- **File Size**: ~1 MB per minute
- **Use**: Standard distribution

#### High Quality (Premium)
- **Bitrate**: 192-256 kbps CBR
- **Sample Rate**: 48 kHz
- **Channels**: Stereo
- **File Size**: ~1.5-2 MB per minute
- **Use**: Premium subscribers

#### Audible/ACX Standard
- **Bitrate**: 192 kbps CBR or VBR
- **Sample Rate**: 44.1 kHz or 48 kHz
- **Format**: MP3 or M4B
- **Peak Level**: -3 dB
- **RMS Level**: -18 to -23 dB

### File Structure
```
audiobook/
├── metadata.txt              # Book and narrator info
├── cover.jpg                 # Album art (1400x1400px minimum)
├── 01_Front_Matter.mp3       # Introduction, preface
├── 02_Chapter_01.mp3         # Chapter 1
├── 03_Chapter_02.mp3         # Chapter 2
├── ...
├── 15_Chapter_13.mp3         # Final chapter
└── 16_Back_Matter.mp3        # Acknowledgments, resources
```

### MP3 Metadata (ID3 Tags)
```
Title: Chapter 1: Introduction
Artist: [Narrator Name]
Album: [Book Title]
Album Artist: [Author Name]
Track: 2/16
Genre: Education / Non-Fiction / Audiobook
Year: 2025
Comment: Professional narration
Cover Art: Embedded (300x300 minimum)
```

---

## Production Workflow

### Step 1: Script Preparation
- Convert book text to narration script
- Mark pronunciation for technical terms
- Add narration notes (pacing, tone, emphasis)
- Create pronunciation guide
- Remove redundant visual references
- Adapt tables/charts to audio-friendly descriptions

### Step 2: Narrator Selection
**Criteria:**
- **Voice Quality**: Clear, pleasant, professional
- **Experience**: Educational content narration
- **Accent**: Appropriate for target audience
- **Reading Speed**: 150-160 words per minute (standard)
- **Recording Setup**: Professional studio quality

**Sources:**
- ACX (Audiobook Creation Exchange)
- Voices.com, Voice123
- Findaway Voices
- Professional voice actors
- Internal narrator team

### Step 3: Recording
**Studio Requirements:**
- Treated acoustic space (no echo)
- Professional microphone (Neumann, Shure, Audio-Technica)
- Pop filter and shock mount
- Quality audio interface
- DAW software (Pro Tools, Adobe Audition, Audacity)

**Recording Process:**
- Record in chapters/sections
- Use consistent microphone distance
- Monitor levels continuously
- Record room tone for noise reduction
- Take multiple takes for difficult sections
- Save raw recordings (backup)

### Step 4: Audio Editing
- Remove mouth sounds, breaths (selective)
- Cut mistakes and retakes
- Normalize volume levels
- Apply compression (subtle)
- EQ for clarity (reduce mud, enhance presence)
- De-ess sibilance
- Noise reduction (minimal, preserve quality)
- Check for clipping or distortion

### Step 5: Mastering
- Match volume across all chapters
- Peak normalization to -3 dB
- RMS leveling to -18 to -20 dB
- Limiter for consistency
- Final quality check
- Export at target bitrate

### Step 6: Quality Control
- Listen to entire audiobook
- Check chapter transitions
- Verify metadata accuracy
- Test on multiple devices
- Proofread against text for accuracy
- Check pronunciation consistency

### Step 7: Packaging
- Export all chapters as MP3
- Embed metadata and cover art
- Create playlist file (.m3u or .pls)
- Package in ZIP for distribution
- Create M4B version (see Format 18)

---

## Quality Checklist

### Audio Technical Quality
- [ ] No clipping or distortion
- [ ] Consistent volume throughout
- [ ] Minimal background noise (< -60 dB)
- [ ] No mouth clicks or pops
- [ ] Smooth chapter transitions
- [ ] Proper silence at chapter ends (1-2 seconds)
- [ ] Peak levels at -3 dB
- [ ] RMS levels between -18 and -23 dB

### Narration Quality
- [ ] Clear pronunciation
- [ ] Appropriate pacing (150-160 wpm)
- [ ] Natural expression and inflection
- [ ] Consistent voice throughout
- [ ] Proper emphasis on key points
- [ ] No reading errors
- [ ] Engaging delivery
- [ ] Professional tone

### Content Accuracy
- [ ] All text narrated
- [ ] No missing sections
- [ ] Correct chapter order
- [ ] Technical terms pronounced correctly
- [ ] Citations read appropriately
- [ ] Tables/charts adapted for audio
- [ ] Visual references removed/adapted

### Metadata & Packaging
- [ ] ID3 tags complete and accurate
- [ ] Cover art embedded (high resolution)
- [ ] Chapter markers set correctly
- [ ] File names descriptive and sequential
- [ ] Total runtime calculated
- [ ] ISBN included (if applicable)

---

## Script Adaptation Examples

### Original Text
```
"See Figure 3.2 on page 47 for a diagram of the process."
```

### Adapted for Audio
```
"Let me describe this process. First, the input enters
through the top valve, then flows through three chambers..."
```

### Original (Table)
```
| Country | Population | GDP |
|---------|------------|-----|
| USA     | 331M       | $21T|
| China   | 1.4B       | $14T|
```

### Adapted for Audio
```
"The following countries show interesting economic data:
The United States, with a population of 331 million,
has a GDP of 21 trillion dollars. China, with 1.4 billion
people, has a GDP of 14 trillion dollars."
```

---

## Cost Estimation

### Professional Narration (Industry Rates)
- **Rate Range**: $200-400 per finished hour
- **200-page book**: ~8-10 finished hours
- **Total Cost**: $1,600-$4,000
- **ACX Royalty Share**: Alternative to upfront payment

### Production Costs
- **Studio Time**: $50-150/hour (if not self-recording)
- **Editing**: $50-100 per finished hour
- **Mastering**: $200-500 per project
- **Total Production**: $2,000-$5,000 for full book

### DIY / In-House
- **Equipment**: $500-2,000 (one-time)
- **Software**: Free (Audacity) to $30/month (Adobe Audition)
- **Training**: Time investment
- **Labor**: Internal team hours

---

## AI Model Recommendations

### Pre-Production
- **Script Adaptation**: Claude Sonnet (text transformation)
- **Pronunciation Guide**: GPT-4 (phonetic notation)
- **Narrator Briefing**: Gemini Pro (instructions)

### Post-Production
- **Transcript Verification**: Claude Opus (accuracy check)
- **Metadata Generation**: GPT-4 (ID3 tags)
- **Quality Assurance**: Gemini Pro (issue detection)

---

## Output Structure

### Primary Output
- **Files**: Individual MP3s per chapter
- **Package**: `[BookTitle]_Audiobook_MP3.zip`
- **Total Size**: Variable (typically 100-300 MB per hour)

### Additional Files
- `audiobook_metadata.txt` - Book and narrator details
- `chapter_timestamps.txt` - Start times and durations
- `pronunciation_guide.pdf` - Reference for listeners
- `narrator_bio.pdf` - Narrator information

---

## Metadata to Include

```json
{
  "format": "MP3 Audiobook - Human Narrated",
  "audio_quality": {
    "bitrate": "192 kbps",
    "sample_rate": "44.1 kHz",
    "channels": "Stereo",
    "format": "MP3"
  },
  "narrator": {
    "name": "Jane Smith",
    "bio": "Professional audiobook narrator with 200+ titles",
    "accent": "American - General",
    "experience": "15 years"
  },
  "production": {
    "studio": "XYZ Audio Productions",
    "engineer": "John Doe",
    "recording_date": "2025-12-03"
  },
  "content": {
    "total_chapters": 14,
    "total_runtime": "8 hours 47 minutes",
    "word_count": 82000,
    "narration_speed": "155 wpm"
  },
  "file_info": {
    "total_size_mb": 765,
    "chapter_count": 16,
    "format_version": "MP3 ID3v2.4"
  }
}
```

---

## Distribution Platforms

### Audiobook Retailers
- **Audible/ACX**: Requires M4B format typically
- **Google Play Books**: Accepts MP3
- **Apple Books**: Prefers M4B
- **Spotify**: MP3 supported
- **Scribd**: MP3 supported

### Direct Sales
- **Your Website**: ZIP download
- **Gumroad**: Direct sales
- **Payhip**: Digital goods platform

### Educational Platforms
- **Udemy**: Course content
- **Teachable**: Course materials
- **LMS Integration**: Download or streaming

---

## Advantages

1. **Premium Quality**: Human expression and nuance
2. **Engaging**: Professional performance
3. **Accessibility**: Critical for blind/low vision users
4. **Portable**: Standard format, plays anywhere
5. **Monetizable**: Premium pricing justified
6. **Brand Value**: Professional image
7. **Emotional Connection**: Human voice builds trust

---

## Best Practices

1. **Professional Narrator**: Worth the investment
2. **Consistent Quality**: Use same narrator for series
3. **Chapter Structure**: Break at natural points
4. **Timing**: Add pauses for complex concepts
5. **Proofread**: Follow along while listening
6. **Backup Everything**: Keep raw recordings
7. **Test Playback**: Check on multiple devices
8. **Accessibility Notes**: Describe important visuals

---

## Related Formats

- **17_MP3_AUDIOBOOK_AI.md**: AI-narrated alternative (lower cost)
- **18_M4B_AUDIOBOOK.md**: Chapter-marked format for Apple devices
- **08_DAISY_30.md**: Structured accessible audio

---

## Update History
- **2025-12-03**: Initial blueprint created
