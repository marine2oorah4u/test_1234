# CRITICAL ARCHITECTURE REQUIREMENTS - MUST FIX

## 🚨 CONFIRMED REQUIREMENTS (December 3, 2025)

### 1. ✅ **EVERY PIPELINE MUST MATCH MASTER BOOK PIPELINE DETAIL LEVEL**

**Current Status**: ❌ **INCOMPLETE**
- Pipeline 3.24 (Dyslexia): ✅ Has good detail BUT needs to match Master Book exactly
- Pipelines 3.25-3.28: ❌ Structure only, need FULL detail
- Pipelines 3.29-3.66: ❌ Not started

**Required Detail Level (from Pipeline 1 - Master Book)**:
```json
{
  "step_number": X,
  "step_name": "Full descriptive name",
  "pipeline": "Pipeline X.XX - Name",
  "purpose": "Detailed purpose explanation",
  "ai_discretion_note": "Full AI discretion clause",
  "why_this_step_is_critical": "Detailed explanation with statistics",

  "input": {
    "source": "Exact source specification",
    "required_data": ["Detailed array of all inputs"]
  },

  "process": {
    "description": "Full process description",
    "steps": [
      {
        "action": "Specific action",
        "details": {
          "detailed_specifications": "Full detail",
          "sub_specifications": "More detail"
        }
      }
    ]
  },

  "ai_models": {
    "primary": "claude-3-7-sonnet-20250219",
    "secondary": "gpt-4o-2024-11-20",
    "verification": "gemini-2.0-flash-exp",
    "image_generation": "dall-e-3 OR midjourney OR stable-diffusion",
    "consensus_required": true,
    "note": "Detailed notes on model usage"
  },

  "output": {
    "format": "Exact output format",
    "required_elements": {
      "element_1": "Detailed specification",
      "element_2": "More specification"
    }
  },

  "verification": {
    "automated_checks": [
      {
        "check": "Specific check description",
        "type": "validation_type",
        "failure_action": "Exact action to take"
      }
    ],
    "visual_verification": [
      {
        "check": "Visual check description",
        "test": "How to test",
        "method": "AI visual analysis + human review"
      }
    ],
    "human_review_triggers": [
      "Specific trigger condition 1",
      "Specific trigger condition 2"
    ],
    "quality_threshold": {
      "minimum_score": 95,
      "scoring_criteria": {
        "criterion_1": 30,
        "criterion_2": 40,
        "criterion_3": 30
      }
    }
  },

  "research_references": [
    {
      "finding": "Specific research finding",
      "source": "Full citation",
      "note": "How it applies"
    }
  ],

  "common_mistakes_to_avoid": [
    "Detailed mistake 1",
    "Detailed mistake 2"
  ],

  "success_criteria": {
    "must_achieve_all": [
      "Specific criterion 1",
      "Specific criterion 2"
    ]
  },

  "estimated_time": {
    "ai_processing": "X minutes",
    "verification": "X minutes",
    "human_review": "X minutes if triggered",
    "total": "X-X minutes"
  },

  "next_step": "Step XX: Next Step Name"
}
```

### 2. ✅ **SOURCE DATA FLOW - NO CROSS-CONTAMINATION**

**CRITICAL RULE**: Each disability adaptation works from **MASTER BOOK or READING LEVEL VERSION ONLY**

```
CORRECT DATA FLOW:
Master Book (Pipeline 1)
    ↓
Reading Level Versions (Pipeline 2)
    ↓ ↓ ↓ (each disability pipeline reads from here)
    ↓ ↓ ↓
    ↓ ↓ ↓→ Dyslexia Adaptation
    ↓ ↓ → ADHD Adaptation
    ↓ → Color Blind Adaptation
    → Deaf/HOH Adaptation
    → Blind Adaptation
    → [38 other disability adaptations]

WRONG DATA FLOW (DO NOT DO THIS):
Dyslexia → ADHD ❌ NO!
ADHD → Color Blind ❌ NO!
Any disability → Another disability ❌ NEVER!
```

**Why This Matters**:
- Dyslexia adaptations (large fonts, special spacing) would BREAK ADHD needs (chunking, interactivity)
- ADHD adaptations (gamification, timers) would CONFUSE blind users (screen reader chaos)
- Color blind adaptations (patterns everywhere) would OVERWHELM dyslexic users
- Each disability has DIFFERENT needs - mixing them creates unusable books

**Implementation**:
```json
{
  "input": {
    "source": "Master book from Pipeline 1 OR specific reading level from Pipeline 2",
    "NEVER_USE": "Output from any other disability adaptation pipeline",
    "verification": "Confirm source is master/reading-level, not disability-adapted"
  }
}
```

### 3. ✅ **MEDIA HANDLING IN EVERY PIPELINE**

**Current Status**: ❌ **MISSING FROM MOST PIPELINES**

Every disability pipeline MUST include these media steps:

#### **Step X: Media Analysis and Adaptation Planning**
```json
{
  "step_name": "Media Analysis and Adaptation Planning",
  "purpose": "Identify all media (images, videos, audio, diagrams) and plan disability-specific adaptations",
  "process": {
    "media_inventory": [
      "Count all images",
      "Identify all videos",
      "List all audio files",
      "Catalog all diagrams/charts",
      "Note all interactive media"
    ],
    "disability_specific_needs": {
      "dyslexia": "Images must support text, not replace it; clear labels",
      "adhd": "Images must be engaging, not distracting; add interactive elements",
      "color_blind": "All color-coded information must have patterns/labels",
      "deaf": "All audio must have captions/transcripts; visual alternatives",
      "blind": "All images need detailed alt text; audio descriptions"
    }
  }
}
```

#### **Step Y: Image Generation and Adaptation**
```json
{
  "step_name": "Image Generation and Adaptation for [Disability]",
  "ai_models": {
    "image_generation": "dall-e-3",
    "backup": "midjourney OR stable-diffusion",
    "verification": "gpt-4o-vision OR claude-3-7-sonnet with vision"
  },
  "process": {
    "for_each_image": [
      "Generate disability-appropriate version",
      "Add required labels/annotations",
      "Verify accessibility",
      "Create multiple formats if needed"
    ]
  },
  "dyslexia_specific": {
    "font_in_images": "OpenDyslexic or Comic Sans",
    "labels": "Large, clear, high contrast",
    "complexity": "Simple, uncluttered",
    "color": "Match color scheme options"
  },
  "adhd_specific": {
    "engagement": "Add interactive elements",
    "focus": "Remove distracting elements",
    "chunking": "Break complex diagrams into steps",
    "gamification": "Add progress indicators"
  },
  "color_blind_specific": {
    "patterns": "Add patterns to all colored areas",
    "labels": "Text labels for all color-coded info",
    "contrast": "7:1 minimum",
    "testing": "Verify with all color blind simulators"
  },
  "deaf_specific": {
    "captions": "Add captions to all images with text",
    "visual_cues": "Replace sound indicators with visual",
    "sign_language": "Add sign language overlay if needed"
  },
  "blind_specific": {
    "alt_text": "Comprehensive descriptions (100+ words for complex images)",
    "audio_description": "Detailed audio descriptions",
    "tactile": "Design tactile versions for braille books",
    "3d_models": "Generate 3D printable models if beneficial"
  }
}
```

#### **Step Z: Media Quality Verification**
```json
{
  "step_name": "Media Quality Verification for [Disability]",
  "verification": {
    "image_checks": [
      "All images meet disability-specific requirements",
      "Fonts in images are disability-appropriate",
      "Colors/patterns are accessible",
      "Size and resolution are appropriate",
      "No missing alt text (for blind)",
      "No color-only information (for color blind)"
    ],
    "video_checks": [
      "Captions present and accurate (deaf)",
      "Audio descriptions present (blind)",
      "Visual quality appropriate for disability",
      "Interactive elements function (ADHD)"
    ],
    "audio_checks": [
      "Transcripts available (deaf)",
      "Clear pronunciation guides (dyslexia)",
      "Appropriate pacing (ADHD)",
      "Alternative formats (blind)"
    ]
  }
}
```

### 4. ✅ **FORMATTING STEPS IN EVERY PIPELINE**

Every pipeline needs:

#### **Step: Layout and Formatting for [Disability]**
```json
{
  "step_name": "Layout and Formatting Optimization",
  "process": {
    "page_layout": "Disability-specific layout rules",
    "margins": "Appropriate margins",
    "white_space": "Required white space",
    "columns": "Single vs. multi-column decisions",
    "page_breaks": "Strategic page break placement"
  }
}
```

#### **Step: PDF/Print Layout Generation**
```json
{
  "step_name": "PDF and Print Layout Generation",
  "specifications": {
    "dpi": "300 for print, 150 for digital",
    "bleed": "Print specifications",
    "color_mode": "CMYK for print, RGB for digital",
    "embedded_fonts": "All fonts embedded",
    "accessibility_tags": "PDF/UA compliance"
  }
}
```

### 5. ✅ **QUALITY CHECKS MATCHING MASTER BOOK PIPELINE**

Every disability pipeline MUST include:

#### **Multi-Stage Verification** (like Master Book):
1. **Section-Level Verification** (after each major section)
2. **Chapter-Level Verification** (after chapter assembly)
3. **Book-Level Verification** (after complete assembly)
4. **Format-Specific Verification** (for each output format)
5. **Assistive Technology Verification** (disability-specific tools)

#### **Quality Thresholds** (like Master Book):
```json
{
  "verification": {
    "quality_threshold": {
      "minimum_score": 95,
      "section_level": {
        "content_accuracy": 98,
        "disability_compliance": 97,
        "formatting": 95,
        "media_quality": 96
      },
      "chapter_level": {
        "overall_quality": 96,
        "consistency": 98,
        "accessibility": 97
      },
      "book_level": {
        "final_quality": 97,
        "complete_accessibility": 98,
        "assistive_tech_compatible": 96
      }
    },
    "failure_action": "Return to appropriate step, fix, and re-verify",
    "escalation": "Human review after 3 failed attempts"
  }
}
```

#### **Human Review Triggers** (like Master Book):
- Quality score below threshold
- Automated checks identify issues
- Complex edge cases
- New disability considerations
- Community feedback indicates problems

### 6. ✅ **RE-CHECK AND FIX CYCLES**

Every pipeline step MUST include:

```json
{
  "verification_loop": {
    "step_1": "Perform automated checks",
    "step_2": "If checks fail, identify issues",
    "step_3": "AI fixes issues automatically",
    "step_4": "Re-run checks",
    "step_5": "If still failing after 3 attempts, trigger human review",
    "step_6": "Human reviews and approves fixes",
    "step_7": "Apply fixes and verify again",
    "step_8": "Only proceed when ALL checks pass at required threshold"
  },
  "never_skip_verification": true,
  "no_tolerance_for_errors": "Quality over speed"
}
```

---

## IMMEDIATE ACTION REQUIRED

### Phase 1: Fix Existing Pipelines (3.24-3.28)
1. ✅ Dyslexia (3.24) - Review and enhance to Master Book level
2. ❌ ADHD (3.25) - Expand all 15 steps to full detail
3. ❌ Color Blindness (3.26) - Expand all 12 steps to full detail
4. ❌ Deaf/HOH (3.27) - Expand all 14 steps to full detail
5. ❌ Blind (3.28) - Expand all 16 steps to full detail

### Phase 2: Build Remaining Pipelines (3.29-3.66)
Build all 38 remaining pipelines with **FULL MASTER BOOK LEVEL DETAIL** from the start.

### Phase 3: Verification
- Audit ALL pipelines against Master Book standard
- Verify source data flow (no cross-contamination)
- Confirm media handling in all pipelines
- Verify quality checks match Master Book

---

## TEMPLATE FOR ALL FUTURE STEPS

Use Pipeline 1 (Master Book) Step 01-18 as the EXACT template for detail level.

**Minimum Requirements Per Step**:
- 200-500 lines of JSON (not 20-30!)
- Multiple AI model assignments
- Detailed process breakdowns with sub-steps
- Comprehensive verification criteria
- Research citations (2-5 per step minimum)
- Common mistakes section
- Success criteria
- Time estimates
- Human review triggers
- Quality thresholds with scoring breakdown

---

## CONFIRMATION CHECKLIST

Before marking ANY pipeline step as "complete":
- [ ] Detail level matches Master Book Pipeline
- [ ] Source data flow documented (master/reading-level only)
- [ ] Media handling included (images, videos, audio)
- [ ] Formatting steps included (layout, PDF, print)
- [ ] Multi-stage verification included
- [ ] Quality thresholds defined (95+ minimum)
- [ ] Re-check/fix cycles included
- [ ] Human review triggers defined
- [ ] Research citations included
- [ ] Common mistakes documented
- [ ] Success criteria explicit
- [ ] Time estimates provided

**If ANY item is unchecked, the step is NOT complete.**

---

This document serves as the blueprint for completing ALL 43 disability adaptation pipelines to the SAME standard as the Master Book Pipeline.
