# Pipeline 3.43 - Autism Spectrum Disorder Level 1 (High Functioning)

**Population:** 2-3 million Americans
**Prevalence:** Social communication challenges, restricted interests, sensory sensitivities

## Specific Adaptations
1. Clear, literal language
2. Explicit instructions
3. Predictable structure
4. Visual schedules
5. Social cues explained
6. Sensory-friendly design
7. Reduced sensory input
8. Special interest integration
9. Transition warnings
10. Routine and consistency
