# Pipeline 3.45 - Autism Spectrum Disorder Level 3 (High Support)

**Population:** 500,000-1 million Americans
**Prevalence:** Require substantial support, limited verbal communication

## Specific Adaptations
1. Picture-based communication
2. AAC symbol support
3. Very simple language
4. Heavy visual supports
5. Minimal text
6. Sensory regulation tools
7. Predictable routine
8. Clear structure
9. Visual timers
10. Alternative communication
