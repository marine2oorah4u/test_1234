# Pipeline 3.44 - Autism Spectrum Disorder Level 2 (Moderate Support)

**Population:** 1-2 million Americans
**Prevalence:** More significant social/communication challenges, need more support

## Specific Adaptations
1. Highly visual content
2. Picture supports
3. Simplified language
4. Concrete examples
5. Routine and structure
6. Sensory accommodations
7. Clear expectations
8. Visual schedules
9. Social stories
10. Calming strategies
