# Intelligent Format Conversion System

**Purpose:** Automatically generate the right formats for each book based on reading level, disability, subject, and use case.

---

## 📋 Format Categories (28 Total)

### ✅ Core Formats (5) - ALWAYS GENERATED
1. **PDF (Print 300dpi)** - For printing, bookstores, POD
2. **PDF (Digital 150dpi)** - For screens, tablets, computers
3. **EPUB 3.0** - For most e-readers (Apple, Google, Kobo, Nook)
4. **MOBI/AZW3** - For Amazon Kindle
5. **HTML Responsive** - For web reading, browsers, apps

### 📚 Academic Formats (2)
6. **LaTeX** - Academic journals, scientific papers, technical docs
7. **DOCX** - Editable by teachers/students

### ♿ Accessibility Formats (4)
8. **DAISY** - Screen readers, blind/low vision (WCAG AAA)
9. **Braille-Ready BRF** - Braille embossers, tactile reading
10. **Large Print PDF** - 18-24pt font for low vision/seniors
11. **Text-to-Speech Ready** - Optimized for screen readers

### 🎮 Interactive Formats (4)
12. **EPUB Fixed Layout** - Image-heavy, complex layouts
13. **HTML5 Interactive** - JavaScript, simulations, exercises
14. **SCORM Package** - LMS (Canvas, Moodle, Blackboard)
15. **xAPI/TinCan** - Learning analytics, tracking

### 🎧 Audio Formats (2)
16. **Audiobook (M4B)** - Chaptered, Apple Books
17. **MP3 (Chaptered)** - Universal audio player

### 🖨️ Print Formats (3)
18. **Print-Ready PDF (Bleeds)** - Professional print shops
19. **Binder-Ready PDF** - 3-hole punch layout
20. **Spiral Binding Layout** - Lay-flat design

### 🎯 Specialized Formats (8)
21. **KFX** - Enhanced Kindle format
22. **CBZ/CBR** - Comic book archives
23. **iBooks Author** - Apple's interactive format
24. **Google Play Books** - Google ecosystem
25. **VR/AR Ready** - 3D content, virtual reality
26. **Markdown** - Developer-friendly, version control
27. **Plain Text (UTF-8)** - Maximum accessibility
28. **JSON Structured** - Machine-readable, AI-friendly

---

## 🤖 AI-Powered Format Selection Logic

### Decision Matrix

```javascript
function intelligentFormatSelection(book) {
  const formats = new Set();

  // ========================================
  // 1. CORE FORMATS (Always include)
  // ========================================
  formats.add('pdf_print_300dpi');
  formats.add('pdf_digital_150dpi');
  formats.add('epub3');
  formats.add('mobi_azw3');
  formats.add('html_responsive');

  // ========================================
  // 2. READING LEVEL BASED
  // ========================================
  switch(book.readingLevel) {
    case 'elementary':
      formats.add('large_print_pdf');
      formats.add('cbz'); // Comic book format for illustrations
      formats.add('html5_interactive');
      formats.add('epub_fixed_layout');
      break;

    case 'middle_school':
      formats.add('docx');
      formats.add('html5_interactive');
      break;

    case 'high_school':
      formats.add('docx');
      formats.add('latex'); // Start introducing academic formats
      formats.add('scorm');
      break;

    case 'college_university':
      formats.add('latex'); // REQUIRED for academic work
      formats.add('docx');
      formats.add('scorm');
      formats.add('xapi');
      formats.add('markdown');
      break;

    case 'professional':
      formats.add('latex');
      formats.add('docx');
      formats.add('scorm');
      formats.add('xapi');
      break;

    case 'advanced_professional':
      formats.add('latex'); // Heavy emphasis on academic format
      formats.add('markdown');
      formats.add('json_structured');
      break;

    case 'plain_language':
      formats.add('large_print_pdf');
      formats.add('daisy'); // REQUIRED for accessibility
      formats.add('tts_ready');
      formats.add('simple_html');
      formats.add('audiobook_m4b');
      formats.add('audiobook_mp3');
      break;

    case 'quick_reference':
      formats.add('pdf_pocket_size');
      formats.add('html_mobile_optimized');
      formats.add('plain_text');
      break;
  }

  // ========================================
  // 3. DISABILITY BASED (CRITICAL)
  // ========================================
  switch(book.disability) {
    case 'blind':
      formats.add('daisy'); // REQUIRED
      formats.add('braille_brf'); // REQUIRED
      formats.add('tts_ready'); // REQUIRED
      formats.add('audiobook_m4b');
      formats.add('audiobook_mp3');
      formats.add('html_aria_enhanced');
      formats.add('plain_text');
      // REMOVE: PDF print (useless for blind users)
      formats.delete('pdf_print_300dpi');
      break;

    case 'low_vision':
      formats.add('daisy'); // REQUIRED
      formats.add('large_print_pdf'); // REQUIRED
      formats.add('tts_ready');
      formats.add('audiobook_m4b');
      formats.add('audiobook_mp3');
      formats.add('html_high_contrast');
      break;

    case 'dyslexia':
      formats.add('dyslexia_font_pdf'); // OpenDyslexic font
      formats.add('tts_ready'); // REQUIRED
      formats.add('audiobook_m4b');
      formats.add('audiobook_mp3');
      formats.add('epub_dyslexia_friendly');
      formats.add('html_focus_mode');
      break;

    case 'adhd':
      formats.add('html_focus_mode'); // Distraction-free
      formats.add('pdf_bookmarked'); // Easy navigation
      formats.add('epub_short_chapters');
      formats.add('audiobook_m4b'); // Alternative learning
      break;

    case 'deaf_hard_of_hearing':
      formats.add('html_caption_ready'); // Video with captions
      formats.add('pdf_visual_emphasis');
      // SKIP: Audiobook formats (useless)
      break;

    case 'autism_level1':
    case 'autism_level2':
    case 'autism_level3':
      formats.add('simple_html'); // Predictable, clean
      formats.add('pdf_structured'); // Clear hierarchy
      formats.add('large_print_pdf');
      formats.add('tts_ready');
      break;

    case 'dyscalculia':
      formats.add('html5_interactive'); // Visual math tools
      formats.add('epub_mathml'); // Proper math rendering
      formats.add('pdf_visual_math');
      break;

    case 'intellectual_disability':
      formats.add('large_print_pdf');
      formats.add('simple_html');
      formats.add('cbz'); // Picture-heavy
      formats.add('audiobook_m4b');
      formats.add('tts_ready');
      break;

    case 'memory_impairments':
      formats.add('html_spaced_repetition');
      formats.add('scorm'); // For tracking progress
      formats.add('pdf_summary_enhanced');
      break;

    case 'executive_function':
      formats.add('html_checklist_mode');
      formats.add('pdf_bookmarked');
      formats.add('scorm'); // Progress tracking
      break;

    case 'color_blindness':
      formats.add('pdf_colorblind_safe');
      formats.add('html_pattern_based');
      formats.add('epub_texture_enhanced');
      break;
  }

  // ========================================
  // 4. SUBJECT BASED
  // ========================================
  const stemSubjects = ['mathematics', 'science', 'engineering', 'physics', 'chemistry', 'biology'];
  if (stemSubjects.includes(book.subject)) {
    formats.add('latex'); // REQUIRED for equations
    formats.add('html5_interactive'); // Simulations
    formats.add('epub_mathml');
    formats.add('pdf_equation_enhanced');
  }

  if (book.subject === 'computer_science' || book.subject === 'programming') {
    formats.add('markdown'); // Developer-friendly
    formats.add('html_syntax_highlighting');
    formats.add('pdf_code_friendly');
    formats.add('json_structured');
  }

  if (book.subject === 'art' || book.subject === 'design') {
    formats.add('pdf_high_res'); // High DPI for images
    formats.add('epub_fixed_layout');
    formats.add('cbz'); // Image archives
  }

  if (book.subject === 'language_learning') {
    formats.add('html5_interactive'); // Pronunciation
    formats.add('audiobook_m4b'); // Native speaker audio
    formats.add('audiobook_mp3');
    formats.add('scorm'); // Progress tracking
  }

  if (book.subject === 'music') {
    formats.add('pdf_music_notation');
    formats.add('epub_with_audio');
    formats.add('html5_interactive');
  }

  if (book.subject === 'history' || book.subject === 'geography') {
    formats.add('epub_fixed_layout'); // Maps, timelines
    formats.add('html5_interactive'); // Interactive maps
    formats.add('vr_ar_ready'); // Virtual tours
  }

  // ========================================
  // 5. BOOK TYPE BASED
  // ========================================
  if (book.type === 'workbook' || book.type === 'worksheet') {
    formats.add('docx'); // Teachers can edit
    formats.add('binder_ready_pdf');
    formats.add('pdf_fillable'); // Fill-in forms
    // SKIP: EPUB (not suitable for worksheets)
    formats.delete('epub3');
    formats.delete('mobi_azw3');
  }

  if (book.type === 'reference') {
    formats.add('binder_ready_pdf');
    formats.add('html_searchable');
    formats.add('pdf_indexed');
    formats.add('spiral_binding_layout');
  }

  if (book.type === 'textbook') {
    formats.add('scorm'); // LMS integration
    formats.add('epub_fixed_layout');
    formats.add('ibooks_author');
    formats.add('google_play_books');
    formats.add('binder_ready_pdf');
  }

  if (book.type === 'lesson_plan' || book.type === 'educator_package') {
    formats.add('docx'); // REQUIRED for editing
    formats.add('scorm');
    formats.add('xapi');
    formats.add('binder_ready_pdf');
  }

  if (book.type === 'activity_pack') {
    formats.add('docx');
    formats.add('binder_ready_pdf');
    formats.add('html5_interactive');
  }

  if (book.type === 'quiz' || book.type === 'assessment') {
    formats.add('scorm'); // REQUIRED for LMS
    formats.add('xapi');
    formats.add('html5_interactive');
    formats.add('pdf_fillable');
  }

  // ========================================
  // 6. USE CASE OPTIMIZATION
  // ========================================
  if (book.useCase === 'classroom') {
    formats.add('docx');
    formats.add('pdf_print_300dpi');
    formats.add('scorm');
    formats.add('binder_ready_pdf');
  }

  if (book.useCase === 'self_study') {
    formats.add('epub3');
    formats.add('mobi_azw3');
    formats.add('audiobook_m4b');
    formats.add('html_progress_tracking');
  }

  if (book.useCase === 'professional_development') {
    formats.add('scorm');
    formats.add('xapi');
    formats.add('pdf_certificate_ready');
  }

  if (book.useCase === 'research') {
    formats.add('latex'); // REQUIRED
    formats.add('docx'); // Citations
    formats.add('markdown');
    formats.add('json_structured');
  }

  // ========================================
  // 7. SPECIAL CONSIDERATIONS
  // ========================================

  // Age-based additions
  if (book.targetAge <= 8) {
    formats.add('cbz'); // Picture-heavy
    formats.add('large_print_pdf');
    formats.add('audiobook_m4b');
  }

  if (book.targetAge >= 65) {
    formats.add('large_print_pdf'); // REQUIRED for seniors
    formats.add('audiobook_m4b');
    formats.add('simple_html');
  }

  // Mobile optimization
  if (book.mobileOptimized) {
    formats.add('html_mobile_optimized');
    formats.add('epub3'); // Reflows well
  }

  // Offline access needed
  if (book.offlineAccess) {
    formats.add('pdf_digital_150dpi');
    formats.add('epub3');
    formats.add('mobi_azw3');
    // SKIP: HTML if no offline capability
  }

  return Array.from(formats).sort();
}
```

---

## 📊 Format Generation Priority

### Tier 1: ALWAYS Generate (5 formats)
- PDF (Print 300dpi)
- PDF (Digital 150dpi)
- EPUB 3.0
- MOBI/AZW3
- HTML Responsive

**Time:** ~15 minutes per book

### Tier 2: Conditional Core (5 formats)
- DOCX (if editable needed)
- LaTeX (if academic/STEM)
- Large Print PDF (if accessibility needed)
- Audiobook (if audio needed)
- DAISY (if blind/low vision)

**Time:** ~20 minutes additional

### Tier 3: Specialized (18 formats)
- All other formats based on intelligent selection
- Generated only when logic determines necessity

**Time:** ~5-60 minutes per format (varies widely)

---

## 🎯 Implementation in Pipelines

### Add to End of Each Pipeline:

```javascript
// At the end of Pipeline 1, 2, 3, 5, 6, 7, 8
async function generateFormats(book) {
  const selectedFormats = intelligentFormatSelection(book);

  console.log(`Generating ${selectedFormats.length} formats for: ${book.title}`);

  const results = await Promise.all(
    selectedFormats.map(format => convertToFormat(book, format))
  );

  await storage.saveFormats(book.id, results);
  await database.updateBookFormats(book.id, selectedFormats);

  return results;
}
```

---

## 💾 Storage Strategy

### Organized by Book:
```
/books/{book_id}/
  /formats/
    - print.pdf (300dpi)
    - digital.pdf (150dpi)
    - book.epub
    - book.mobi
    - book.html
    - book.docx
    - book.tex (if applicable)
    - book.daisy (if applicable)
    - audiobook.m4b (if applicable)
    - ... (other formats)
  /metadata/
    - formats_generated.json
    - generation_log.json
```

---

## ✅ Next Steps

1. **Integrate into existing pipelines** - Add format generation step to end of P1, P2, P3
2. **Build conversion functions** - Create actual format converters
3. **Test with sample book** - Verify logic works correctly
4. **Add to database schema** - Track which formats exist for each book
5. **Build format manager UI** - Allow users to regenerate specific formats

---

## 📝 Summary

The AI intelligently selects **5-15 formats per book** based on:
- ✅ Reading level (Elementary vs Professional)
- ✅ Disability type (Blind needs DAISY, not PDF)
- ✅ Subject matter (STEM needs LaTeX, Art needs high-res PDFs)
- ✅ Book type (Workbooks need DOCX, not EPUB)
- ✅ Use case (Classroom vs Self-study)
- ✅ Target age (Kids vs Seniors)

This ensures we generate exactly what's needed, nothing more, nothing less.
