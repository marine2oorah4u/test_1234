# Pipeline 2a Elementary - Visual Design Requirements

## CRITICAL UPDATES - Step 5: Add Additional Images & Visual Themes

### ✅ UNIQUE THEMES FOR EACH BOOK
- **Each book gets completely unique visual theme** - NEVER reuse themes across books
- Unique color palette per book (never reuse exact colors)
- Unique mascot character per book (different character for each book)
- Each book's theme appropriate to its specific subject matter

### ✅ REAL PHOTOS PREFERRED
- **35% minimum of images should be real photographs** from stock photo sites
- **Prefer real photos over AI-generated** for anything that can be photographed

#### Use Real Photos For:
- Animals, plants, natural phenomena
- Real-world examples of concepts
- People demonstrating activities (diverse representation)
- Objects, tools, everyday items
- Places and environments
- Scientific equipment and experiments
- Historical photos

#### Photo Sources (Free & Licensed):
- Pexels.com
- Unsplash.com
- Pixabay.com
- NASA Image Library (space/science)
- Wikimedia Commons (educational content)

#### Use AI Generation For:
- Mascot character (unique cartoon character per book)
- Diagrams and labeled illustrations
- Step-by-step process visualizations
- Concept visualizations that don't exist in real life
- Decorative elements and borders
- Cartoon-style explanations

### ✅ PROFESSIONAL QUALITY AESTHETIC
**Target Look:** Scholastic, National Geographic Kids, DK Readers quality

**NOT generic AI-generated look** - should look like real elementary educational books kids actually read

### Image Quality Requirements:
- 300 DPI minimum (print quality)
- High resolution, crystal clear
- Appropriate for 8-11 year old audience
- Diverse, inclusive representation in photos
- Proper licensing documentation for all real photos

## Updated Process Flow

### Step 5 Phase 1: Create UNIQUE Theme (15-20 min)
- Analyze book subject
- Research successful elementary books in subject area
- Create completely NEW unique theme concept
- Verify theme hasn't been used before
- Design unique color palette
- Design unique mascot character

### Step 5 Phase 2: Source Real Photos FIRST (20-30 min)
**PRIORITY TASK**
- Search Pexels, Unsplash, Pixabay for relevant keywords
- Find high-quality real photos for 35%+ of image needs
- Document photo sources and licensing
- Ensure diverse, inclusive representation

### Step 5 Phase 3: Create Unique Mascot (10-15 min)
- Design completely new character (different from all other books)
- Generate 6-8 poses/expressions
- Create style guide for consistency within THIS book only

### Step 5 Phase 4: AI-Generate Educational Diagrams (20-25 min)
- Charts, labeled diagrams
- Step-by-step visualizations
- Process flows
- Concept illustrations

### Step 5 Phase 5: AI-Generate Decorative Elements (10-15 min)
- Unique borders matching theme
- Corner decorations
- Section dividers
- Background patterns
- Icon sets

### Step 5 Phase 6: Chapter Openers (12-18 min)
- Consider real photos first
- Use AI if better for content preview
- Can combine real photo + AI mascot

## Success Checklist

✅ 15-20 images per section achieved
✅ 35%+ are real stock photos (not AI-generated)
✅ Visual theme is UNIQUE to this book only
✅ Mascot character is UNIQUE to this book only
✅ Color palette is UNIQUE to this book only
✅ Looks like Scholastic/Nat Geo Kids quality (professional)
✅ Appeals to 8-11 year olds
✅ Every page visually engaging
✅ All real photos properly licensed and documented
✅ 300 DPI quality for all images
✅ Diverse, inclusive representation

## Cost: $8-12 per book
- Real photo sourcing and curation: included
- AI character and decoration generation: included
- Theme design and planning: included
