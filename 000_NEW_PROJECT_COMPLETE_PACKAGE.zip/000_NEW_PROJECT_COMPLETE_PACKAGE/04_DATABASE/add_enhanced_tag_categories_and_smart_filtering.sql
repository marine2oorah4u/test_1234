/*
  # Enhanced Tag Categories + Smart Addon Filtering System

  ## New Categories Added
  1. entity_type - What kind of thing is this? (person, location, species, object, event, concept)
  2. content_source - Where did we discover this? (wikipedia, museum, database, academic)
  3. addon_applicability - Which addons make sense for this content?

  ## Purpose
  - Enable smart filtering so we don't generate useless addons
  - Track provenance (where content came from)
  - Classify entity types for better organization

  ## Examples
  - Biography of Einstein: entity_type:person, source:wikipedia, addons:biography-pack,timeline,career-path
  - Marine Mammals: entity_type:species-group, source:database:gbif, addons:activity-pack,study-guide
  - Eiffel Tower: entity_type:location:landmark, source:wikipedia, addons:virtual-tour,history-pack
*/

-- =====================================================
-- STEP 1: Add 3 New Tag Categories
-- =====================================================

INSERT INTO tag_categories (category_key, category_name, description, applies_to, sort_order) VALUES

('entity_type', 'Entity Type',
  'What kind of thing is being taught? (e.g., entity:person, entity:location, entity:species, entity:event, entity:concept, entity:object)',
  ARRAY['subjects', 'topics', 'books'], 16),

('content_source', 'Content Source',
  'Where was this content discovered? (e.g., source:wikipedia, source:museum:smithsonian, source:database:gbif, source:academic:jstor)',
  ARRAY['subjects', 'topics', 'books'], 17),

('addon_applicability', 'Addon Applicability',
  'Which Pipeline 5 addons make sense for this content? (e.g., addon-ok:activity-pack, addon-ok:worksheets, addon-skip:career-guide)',
  ARRAY['subjects', 'books'], 18)

ON CONFLICT (category_key) DO NOTHING;


-- =====================================================
-- STEP 2: Seed Core Entity Type Tags
-- =====================================================

INSERT INTO core_tags (tag_key, category_key, tag_name, description, usage_notes) VALUES

-- Main Entity Types
('entity:person', 'entity_type', 'Person',
  'Content about a specific person or biography',
  'Use for biographies, historical figures, scientists, artists, etc.'),

('entity:location', 'entity_type', 'Location',
  'Content about a specific place or geographic feature',
  'Use for cities, countries, landmarks, natural features'),

('entity:location:landmark', 'entity_type', 'Landmark',
  'Content about a notable landmark or monument',
  'Use for Eiffel Tower, Statue of Liberty, Great Wall, etc.'),

('entity:location:natural', 'entity_type', 'Natural Location',
  'Content about natural geographic features',
  'Use for mountains, rivers, forests, ecosystems'),

('entity:species', 'entity_type', 'Species',
  'Content about a specific animal, plant, or organism species',
  'Use for individual species like "African Elephant" or "Blue Whale"'),

('entity:species-group', 'entity_type', 'Species Group',
  'Content about a group of related species',
  'Use for "Mammals", "Birds", "Marine Life", etc.'),

('entity:event', 'entity_type', 'Historical Event',
  'Content about a specific historical event or period',
  'Use for wars, revolutions, discoveries, social movements'),

('entity:object', 'entity_type', 'Physical Object',
  'Content about a specific object, artifact, or invention',
  'Use for inventions, artifacts, tools, vehicles'),

('entity:concept', 'entity_type', 'Abstract Concept',
  'Content about an idea, theory, or abstract concept',
  'Use for democracy, gravity, love, justice, etc.'),

('entity:skill', 'entity_type', 'Practical Skill',
  'Content teaching a practical skill or technique',
  'Use for cooking techniques, programming, carpentry, etc.'),

('entity:system', 'entity_type', 'System or Process',
  'Content about a complex system or process',
  'Use for circulatory system, democratic process, ecosystems'),

('entity:organization', 'entity_type', 'Organization',
  'Content about an organization or institution',
  'Use for companies, governments, NGOs, historical institutions'),

('entity:movement', 'entity_type', 'Cultural/Social Movement',
  'Content about cultural, artistic, or social movements',
  'Use for Renaissance, Impressionism, Civil Rights Movement'),

('entity:technology', 'entity_type', 'Technology',
  'Content about a specific technology or technological field',
  'Use for internet, AI, renewable energy, etc.');


-- =====================================================
-- STEP 3: Seed Content Source Tags
-- =====================================================

INSERT INTO core_tags (tag_key, category_key, tag_name, description, usage_notes) VALUES

-- Primary Sources
('source:wikipedia', 'content_source', 'Wikipedia',
  'Content discovered through Wikipedia',
  'Used for subjects initially found on Wikipedia'),

('source:museum:smithsonian', 'content_source', 'Smithsonian Museums',
  'Content from Smithsonian collections',
  'Used for subjects discovered in Smithsonian databases'),

('source:museum:british', 'content_source', 'British Museum',
  'Content from British Museum collections',
  'Used for subjects discovered in British Museum databases'),

('source:museum:natural-history', 'content_source', 'Natural History Museums',
  'Content from various natural history museums',
  'Used for subjects discovered in natural history collections'),

('source:database:gbif', 'content_source', 'GBIF Species Database',
  'Content from Global Biodiversity Information Facility',
  'Used for species discovered in GBIF'),

('source:database:iucn', 'content_source', 'IUCN Red List',
  'Content from IUCN species conservation database',
  'Used for endangered species information'),

('source:academic:jstor', 'content_source', 'JSTOR Academic Database',
  'Content discovered through academic research',
  'Used for subjects discovered in academic journals'),

('source:government:bls', 'content_source', 'US Bureau of Labor Statistics',
  'Content from BLS job and career data',
  'Used for career-related subjects'),

('source:curriculum:common-core', 'content_source', 'Common Core Standards',
  'Content derived from Common Core curriculum requirements',
  'Used for K-12 subjects aligned to standards'),

('source:unesco', 'content_source', 'UNESCO',
  'Content from UNESCO world heritage, education, or cultural databases',
  'Used for world heritage sites, cultural knowledge'),

('source:discovery:ai', 'content_source', 'AI Discovery',
  'Content discovered through AI analysis and synthesis',
  'Used for subjects identified by AI scanning multiple sources'),

('source:user:requested', 'content_source', 'User Requested',
  'Content added based on user requests',
  'Used for subjects specifically requested by users');


-- =====================================================
-- STEP 4: Seed Addon Applicability Tags
-- =====================================================

INSERT INTO core_tags (tag_key, category_key, tag_name, description, usage_notes) VALUES

-- Addon Inclusion Rules (what SHOULD be generated)
('addon-ok:activity-pack', 'addon_applicability', 'Activity Pack Applicable',
  'Activity packs make sense for this content',
  'Hands-on learning activities are appropriate'),

('addon-ok:worksheets', 'addon_applicability', 'Worksheets Applicable',
  'Worksheet sets make sense for this content',
  'Practice problems and exercises are appropriate'),

('addon-ok:quiz-pack', 'addon_applicability', 'Quiz Pack Applicable',
  'Quiz packs make sense for this content',
  'Testing and assessment materials are appropriate'),

('addon-ok:study-guide', 'addon_applicability', 'Study Guide Applicable',
  'Study guides make sense for this content',
  'Reference and review materials are appropriate'),

('addon-ok:lesson-plans', 'addon_applicability', 'Lesson Plans Applicable',
  'Lesson plans make sense for this content',
  'Educator teaching materials are appropriate'),

('addon-ok:presentation-slides', 'addon_applicability', 'Presentation Slides Applicable',
  'Presentation slides make sense for this content',
  'Visual presentation materials are appropriate'),

('addon-ok:career-guide', 'addon_applicability', 'Career Guide Applicable',
  'Career guides make sense for this content',
  'Career pathway information is relevant'),

('addon-ok:timeline', 'addon_applicability', 'Timeline Applicable',
  'Timeline addons make sense for this content',
  'Historical or sequential progression is relevant'),

('addon-ok:virtual-tour', 'addon_applicability', 'Virtual Tour Applicable',
  'Virtual tour addons make sense for this content',
  'Spatial or geographic exploration is relevant'),

('addon-ok:biography-pack', 'addon_applicability', 'Biography Pack Applicable',
  'Biography-focused addons make sense for this content',
  'Person-centered materials are relevant'),

-- Addon Exclusion Rules (what should NOT be generated)
('addon-skip:activity-pack', 'addon_applicability', 'Skip Activity Pack',
  'Activity packs do NOT make sense for this content',
  'Hands-on activities are not practical or appropriate'),

('addon-skip:worksheets', 'addon_applicability', 'Skip Worksheets',
  'Worksheet sets do NOT make sense for this content',
  'Practice problems are not applicable'),

('addon-skip:career-guide', 'addon_applicability', 'Skip Career Guide',
  'Career guides do NOT make sense for this content',
  'Career connections are not relevant');


-- =====================================================
-- STEP 5: Create Smart Filtering Rules Table
-- =====================================================

CREATE TABLE IF NOT EXISTS addon_filtering_rules (
  id bigint PRIMARY KEY GENERATED ALWAYS AS IDENTITY,

  -- What triggers this rule?
  entity_type_tag text NOT NULL,

  -- Which addon should be affected?
  addon_id bigint REFERENCES addons(id),
  addon_slug text, -- Or reference by slug

  -- Action: include or exclude?
  action text NOT NULL CHECK (action IN ('include', 'exclude', 'require')),

  -- Why?
  reason text NOT NULL,

  -- Examples
  example_subjects text[],

  -- Priority (higher = more important)
  priority int DEFAULT 50,

  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add index for fast lookups
CREATE INDEX IF NOT EXISTS idx_addon_filtering_entity_type
  ON addon_filtering_rules(entity_type_tag);

CREATE INDEX IF NOT EXISTS idx_addon_filtering_addon
  ON addon_filtering_rules(addon_id);


-- =====================================================
-- STEP 6: Seed Smart Filtering Rules
-- =====================================================

INSERT INTO addon_filtering_rules (entity_type_tag, addon_slug, action, reason, example_subjects, priority) VALUES

-- PERSON entity rules
('entity:person', '01_activity_packs', 'exclude',
  'Activity packs don''t make sense for biography content',
  ARRAY['Albert Einstein', 'Marie Curie', 'Leonardo da Vinci'], 90),

('entity:person', '07_career_guides', 'include',
  'Career guides are highly relevant for biographies - show the path they took',
  ARRAY['Albert Einstein', 'Marie Curie', 'Steve Jobs'], 95),

('entity:person', 'biography-timeline', 'require',
  'Timelines are essential for biographical content',
  ARRAY['George Washington', 'Cleopatra', 'Martin Luther King Jr.'], 100),

-- LOCATION entity rules
('entity:location', '01_activity_packs', 'exclude',
  'Activity packs rarely make sense for location content',
  ARRAY['Paris', 'Mount Everest', 'Amazon River'], 85),

('entity:location', 'virtual-tour', 'require',
  'Virtual tours are essential for location content',
  ARRAY['Eiffel Tower', 'Grand Canyon', 'Great Barrier Reef'], 100),

('entity:location:landmark', '06_presentation_slides', 'include',
  'Visual presentations work well for landmarks',
  ARRAY['Statue of Liberty', 'Taj Mahal', 'Colosseum'], 80),

-- SPECIES entity rules
('entity:species', '01_activity_packs', 'include',
  'Hands-on activities work great for learning about species',
  ARRAY['African Elephant', 'Blue Whale', 'Monarch Butterfly'], 85),

('entity:species', '02_worksheet_sets', 'include',
  'Worksheets help reinforce species knowledge',
  ARRAY['Polar Bear', 'Giant Panda', 'Bald Eagle'], 80),

('entity:species', '07_career_guides', 'exclude',
  'Career guides don''t make sense for individual species',
  ARRAY['Red Fox', 'Sea Turtle', 'Oak Tree'], 90),

('entity:species-group', '07_career_guides', 'include',
  'Career guides DO make sense for species groups (zoology, marine biology careers)',
  ARRAY['Marine Mammals', 'Birds of Prey', 'Reptiles'], 70),

-- SKILL entity rules
('entity:skill', '01_activity_packs', 'require',
  'Activity packs are essential for teaching practical skills',
  ARRAY['Cooking Basics', 'Woodworking', 'Photography'], 100),

('entity:skill', '02_worksheet_sets', 'require',
  'Practice worksheets are essential for skill development',
  ARRAY['Math Problem Solving', 'Grammar', 'Programming'], 100),

('entity:skill', '07_career_guides', 'include',
  'Career guides are relevant for marketable skills',
  ARRAY['Web Development', 'Graphic Design', 'Welding'], 85),

-- EVENT entity rules
('entity:event', 'timeline', 'require',
  'Timelines are essential for historical events',
  ARRAY['World War II', 'American Revolution', 'Industrial Revolution'], 100),

('entity:event', '01_activity_packs', 'exclude',
  'Activity packs rarely make sense for historical events',
  ARRAY['Fall of Rome', 'French Revolution', 'Moon Landing'], 85),

('entity:event', '06_presentation_slides', 'include',
  'Visual presentations work well for events',
  ARRAY['Civil Rights Movement', 'Space Race', 'Renaissance'], 80),

-- CONCEPT entity rules
('entity:concept', '02_worksheet_sets', 'include',
  'Worksheets help students practice abstract concepts',
  ARRAY['Democracy', 'Gravity', 'Photosynthesis'], 85),

('entity:concept', '03_quiz_packs', 'include',
  'Quizzes help assess understanding of concepts',
  ARRAY['Evolution', 'Supply and Demand', 'Atomic Theory'], 85),

('entity:concept', 'virtual-tour', 'exclude',
  'Virtual tours don''t make sense for abstract concepts',
  ARRAY['Justice', 'Freedom', 'Infinity'], 95);


-- =====================================================
-- STEP 7: Create View for Easy Querying
-- =====================================================

CREATE OR REPLACE VIEW subject_addon_recommendations AS
SELECT
  d.id as domain_id,
  d.name as domain_name,
  s.id as subject_id,
  s.name as subject_name,

  -- Extract entity type tags
  (SELECT STRING_AGG(ct.tag_key, ', ')
   FROM subject_tags st
   JOIN core_tags ct ON st.tag_id = ct.id
   WHERE st.subject_id = s.id
   AND ct.category_key = 'entity_type') as entity_types,

  -- Extract source tags
  (SELECT STRING_AGG(ct.tag_key, ', ')
   FROM subject_tags st
   JOIN core_tags ct ON st.tag_id = ct.id
   WHERE st.subject_id = s.id
   AND ct.category_key = 'content_source') as sources,

  -- Get applicable addons (includes)
  (SELECT STRING_AGG(afr.addon_slug, ', ')
   FROM addon_filtering_rules afr
   JOIN core_tags ct ON afr.entity_type_tag = ct.tag_key
   JOIN subject_tags st ON ct.id = st.tag_id
   WHERE st.subject_id = s.id
   AND afr.action = 'include'
   AND ct.category_key = 'entity_type') as recommended_addons,

  -- Get excluded addons
  (SELECT STRING_AGG(afr.addon_slug, ', ')
   FROM addon_filtering_rules afr
   JOIN core_tags ct ON afr.entity_type_tag = ct.tag_key
   JOIN subject_tags st ON ct.id = st.tag_id
   WHERE st.subject_id = s.id
   AND afr.action = 'exclude'
   AND ct.category_key = 'entity_type') as excluded_addons,

  -- Get required addons
  (SELECT STRING_AGG(afr.addon_slug, ', ')
   FROM addon_filtering_rules afr
   JOIN core_tags ct ON afr.entity_type_tag = ct.tag_key
   JOIN subject_tags st ON ct.id = st.tag_id
   WHERE st.subject_id = s.id
   AND afr.action = 'require'
   AND ct.category_key = 'entity_type') as required_addons

FROM domains d
JOIN subjects s ON s.domain_id = d.id
ORDER BY d.name, s.name;

-- Add helpful comment
COMMENT ON VIEW subject_addon_recommendations IS
  'Shows which addons should be generated for each subject based on entity type and filtering rules';


-- =====================================================
-- STEP 8: Enable RLS on new table
-- =====================================================

ALTER TABLE addon_filtering_rules ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read addon filtering rules"
  ON addon_filtering_rules
  FOR SELECT
  TO authenticated, anon
  USING (true);

CREATE POLICY "Only admins can modify addon filtering rules"
  ON addon_filtering_rules
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role IN ('super_admin', 'system_admin')
    )
  );
