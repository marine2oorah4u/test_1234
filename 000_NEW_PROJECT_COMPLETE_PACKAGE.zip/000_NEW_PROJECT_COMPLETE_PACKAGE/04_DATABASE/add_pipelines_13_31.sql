/*
  # Add Pipelines 13-31 - Approved New Pipelines

  ## Overview
  Adds 19 new approved pipelines (13-31) to the system:
  - User Group Packaging, Career Pathways, Youth Programs, Homeschool
  - Religious Education, Podcasts, Life Skills, Adult Ed, Trades
  - Pre-K, Test Prep, Summer Programs, Tutoring, PBL, STEAM
  - Gap Year, Dual Enrollment, Gifted, Competency-Based Ed

  ## Changes

  ### 1. Pipelines
  - Pipeline 13: User Group Packaging
  - Pipeline 14: Career Pathways System
  - Pipeline 15: Youth Programs (Scouts, 4-H, etc.)
  - Pipeline 16: Homeschool Curriculum
  - Pipeline 17: Religious & Spiritual Education
  - Pipeline 18: Podcast/Audio Series
  - Pipeline 19: Life Skills & Practical Education
  - Pipeline 20: Adult Basic Education / GED
  - Pipeline 21: Apprenticeship & Trades Programs
  - Pipeline 22: Pre-K / Early Childhood (Ages 0-4)
  - Pipeline 23: Test Prep (SAT, ACT, GRE, etc.)
  - Pipeline 24: Summer Learning / Camp Programs
  - Pipeline 25: Tutoring Center Packages
  - Pipeline 26: Project-Based Learning (PBL)
  - Pipeline 27: STEAM Integration
  - Pipeline 28: Gap Year / Alternative Education
  - Pipeline 29: Dual Enrollment / Early College
  - Pipeline 30: Gifted & Enrichment Extensions
  - Pipeline 31: Competency-Based Education (CBE)

  ## Security
  - Uses existing RLS policies from pipelines table
  - No data exposed without authentication
*/

-- Insert Pipeline 13: User Group Packaging
INSERT INTO pipelines (id, name, description, steps, status, priority, phase, created_at, updated_at)
VALUES (
  13,
  'User Group Packaging',
  'Package content specifically for each of the 35 user groups with customized bundles, features, pricing, and access controls',
  12,
  'planned',
  'high',
  2,
  now(),
  now()
) ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  updated_at = now();

-- Insert Pipeline 14: Career Pathways System
INSERT INTO pipelines (id, name, description, steps, status, priority, phase, created_at, updated_at)
VALUES (
  14,
  'Career Pathways System',
  'Map 400+ careers to educational content, create career development paths with skill assessments and job market data',
  12,
  'planned',
  'high',
  2,
  now(),
  now()
) ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  updated_at = now();

-- Insert Pipeline 15: Youth Programs
INSERT INTO pipelines (id, name, description, steps, status, priority, phase, created_at, updated_at)
VALUES (
  15,
  'Youth Programs (Scouts, 4-H, Cadets)',
  'Content and badge systems for youth organizations including merit badge guides, skill challenges, and leadership development',
  12,
  'planned',
  'medium',
  2,
  now(),
  now()
) ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  updated_at = now();

-- Insert Pipeline 16: Homeschool Curriculum
INSERT INTO pipelines (id, name, description, steps, status, priority, phase, created_at, updated_at)
VALUES (
  16,
  'Homeschool Curriculum (PreK-12)',
  'Complete PreK-12 curriculum packages for homeschool families with scope & sequence, lesson plans, parent guides, and record keeping',
  12,
  'planned',
  'high',
  2,
  now(),
  now()
) ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  updated_at = now();

-- Insert Pipeline 17: Religious & Spiritual Education
INSERT INTO pipelines (id, name, description, steps, status, priority, phase, created_at, updated_at)
VALUES (
  17,
  'Religious & Spiritual Education',
  'Multi-faith education, sacred texts study, ethical frameworks, and age-appropriate religious education',
  12,
  'planned',
  'medium',
  3,
  now(),
  now()
) ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  updated_at = now();

-- Insert Pipeline 18: Podcast/Audio Series
INSERT INTO pipelines (id, name, description, steps, status, priority, phase, created_at, updated_at)
VALUES (
  18,
  'Podcast/Audio Series',
  'Convert content to serialized podcast format with episode scripts, audio production guides, show notes, and transcripts',
  12,
  'planned',
  'medium',
  3,
  now(),
  now()
) ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  updated_at = now();

-- Insert Pipeline 19: Life Skills & Practical Education
INSERT INTO pipelines (id, name, description, steps, status, priority, phase, created_at, updated_at)
VALUES (
  19,
  'Life Skills & Practical Education',
  'Essential life skills for teens and adults including financial literacy, cooking, home maintenance, and communication',
  12,
  'planned',
  'high',
  2,
  now(),
  now()
) ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  updated_at = now();

-- Insert Pipeline 20: Adult Basic Education / GED
INSERT INTO pipelines (id, name, description, steps, status, priority, phase, created_at, updated_at)
VALUES (
  20,
  'Adult Basic Education / GED',
  'Adult literacy, GED prep, and foundational skills for 750M+ adults lacking basic literacy',
  12,
  'planned',
  'high',
  2,
  now(),
  now()
) ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  updated_at = now();

-- Insert Pipeline 21: Apprenticeship & Trades Programs
INSERT INTO pipelines (id, name, description, steps, status, priority, phase, created_at, updated_at)
VALUES (
  21,
  'Apprenticeship & Trades Programs',
  'Vocational training for skilled trades including trade theory, hands-on projects, safety protocols, and certification prep',
  12,
  'planned',
  'high',
  2,
  now(),
  now()
) ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  updated_at = now();

-- Insert Pipeline 22: Pre-K / Early Childhood
INSERT INTO pipelines (id, name, description, steps, status, priority, phase, created_at, updated_at)
VALUES (
  22,
  'Pre-K / Early Childhood (Ages 0-4)',
  'Early learning for infants, toddlers, and preschoolers with age-appropriate activities, parent guides, and developmental milestones',
  12,
  'planned',
  'high',
  2,
  now(),
  now()
) ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  updated_at = now();

-- Insert Pipeline 23: Test Prep
INSERT INTO pipelines (id, name, description, steps, status, priority, phase, created_at, updated_at)
VALUES (
  23,
  'Test Prep (SAT, ACT, GRE, etc.)',
  'Standardized test preparation with practice tests, study guides, timing strategies, and score improvement plans',
  12,
  'planned',
  'medium',
  3,
  now(),
  now()
) ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  updated_at = now();

-- Insert Pipeline 24: Summer Learning / Camp Programs
INSERT INTO pipelines (id, name, description, steps, status, priority, phase, created_at, updated_at)
VALUES (
  24,
  'Summer Learning / Camp Programs',
  'Summer enrichment to prevent learning loss with weekly themes, outdoor activities, and skill-building projects',
  12,
  'planned',
  'medium',
  3,
  now(),
  now()
) ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  updated_at = now();

-- Insert Pipeline 25: Tutoring Center Packages
INSERT INTO pipelines (id, name, description, steps, status, priority, phase, created_at, updated_at)
VALUES (
  25,
  'Tutoring Center Packages',
  'Materials for tutoring businesses and learning centers with diagnostic assessments, personalized learning paths, and progress tracking',
  12,
  'planned',
  'medium',
  3,
  now(),
  now()
) ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  updated_at = now();

-- Insert Pipeline 26: Project-Based Learning (PBL)
INSERT INTO pipelines (id, name, description, steps, status, priority, phase, created_at, updated_at)
VALUES (
  26,
  'Project-Based Learning (PBL)',
  'Real-world projects that integrate multiple subjects with project guides, rubrics, reflection tools, and community connections',
  12,
  'planned',
  'medium',
  3,
  now(),
  now()
) ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  updated_at = now();

-- Insert Pipeline 27: STEAM Integration
INSERT INTO pipelines (id, name, description, steps, status, priority, phase, created_at, updated_at)
VALUES (
  27,
  'STEAM Integration',
  'Integrated STEAM projects combining Science, Technology, Engineering, Arts, and Math with maker activities and design challenges',
  12,
  'planned',
  'medium',
  3,
  now(),
  now()
) ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  updated_at = now();

-- Insert Pipeline 28: Gap Year / Alternative Education
INSERT INTO pipelines (id, name, description, steps, status, priority, phase, created_at, updated_at)
VALUES (
  28,
  'Gap Year / Alternative Education',
  'Structured learning for gap year, unschooling, and alternative paths with self-directed learning guides and project portfolios',
  12,
  'planned',
  'low',
  4,
  now(),
  now()
) ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  updated_at = now();

-- Insert Pipeline 29: Dual Enrollment / Early College
INSERT INTO pipelines (id, name, description, steps, status, priority, phase, created_at, updated_at)
VALUES (
  29,
  'Dual Enrollment / Early College',
  'High school students taking college courses with college-level rigor, high school alignment, and transition support',
  12,
  'planned',
  'medium',
  3,
  now(),
  now()
) ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  updated_at = now();

-- Insert Pipeline 30: Gifted & Enrichment Extensions
INSERT INTO pipelines (id, name, description, steps, status, priority, phase, created_at, updated_at)
VALUES (
  30,
  'Gifted & Enrichment Extensions',
  'Challenge activities for advanced learners with acceleration options, depth/complexity, and independent projects',
  12,
  'planned',
  'medium',
  3,
  now(),
  now()
) ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  updated_at = now();

-- Insert Pipeline 31: Competency-Based Education (CBE)
INSERT INTO pipelines (id, name, description, steps, status, priority, phase, created_at, updated_at)
VALUES (
  31,
  'Competency-Based Education (CBE)',
  'Mastery-based learning with flexible pacing including competency maps, mastery assessments, and self-paced modules',
  12,
  'planned',
  'medium',
  3,
  now(),
  now()
) ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  updated_at = now();
