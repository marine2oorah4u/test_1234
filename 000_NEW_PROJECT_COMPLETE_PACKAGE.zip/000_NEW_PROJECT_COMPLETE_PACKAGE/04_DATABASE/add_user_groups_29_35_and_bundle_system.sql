/*
  # Add User Groups 29-35 and Auto-Bundling System

  ## New User Groups (29-35)
  - Group 29: Island Communities
  - Group 30: Maritime Workers
  - Group 31: Gig Economy Workers
  - Group 32: Artists & Creatives
  - Group 33: Neurodivergent Adults
  - Group 34: LGBTQ+ Learners
  - Group 35: Single Parents

  ## New Tables
  - `auto_bundle_tags` - AI tagging system for content
  - `auto_bundle_rules` - Rules for automatic collection creation
  - `auto_generated_collections` - Collections created by AI
  - `user_group_bundle_assignments` - Which bundles go to which groups

  ## Security
  - Enable RLS on all new tables
  - Add appropriate policies for authenticated users
*/

-- =====================================================
-- ADD NEW USER GROUPS (29-35)
-- =====================================================

DO $$
BEGIN
  -- GROUP 29: Island Communities
  IF NOT EXISTS (SELECT 1 FROM user_groups WHERE id = 29) THEN
    INSERT INTO user_groups (id, name, description, estimated_size, priority_level, special_needs)
    VALUES (
      29,
      'Island Communities',
      'Residents of island nations and communities with unique maritime, climate, and sustainability needs. Includes Pacific Islands, Caribbean, Mediterranean, and other island populations.',
      500000000,
      'high',
      ARRAY['marine_science_content', 'climate_adaptation', 'sustainable_tourism', 'indigenous_knowledge', 'maritime_skills', 'isolation_considerations', 'shipping_logistics', 'renewable_energy', 'ocean_conservation']
    );
  END IF;

  -- GROUP 30: Maritime Workers
  IF NOT EXISTS (SELECT 1 FROM user_groups WHERE id = 30) THEN
    INSERT INTO user_groups (id, name, description, estimated_size, priority_level, special_needs)
    VALUES (
      30,
      'Maritime Workers',
      'Commercial fishing, shipping, offshore work, port logistics, and maritime industry professionals needing industry-specific knowledge and certifications.',
      50000000,
      'medium',
      ARRAY['industry_certifications', 'safety_protocols', 'technical_training', 'international_regulations', 'weather_literacy', 'navigation_skills', 'equipment_operation', 'emergency_procedures']
    );
  END IF;

  -- GROUP 31: Gig Economy Workers
  IF NOT EXISTS (SELECT 1 FROM user_groups WHERE id = 31) THEN
    INSERT INTO user_groups (id, name, description, estimated_size, priority_level, special_needs)
    VALUES (
      31,
      'Gig Economy Workers',
      'Freelancers, platform workers, independent contractors, and those managing multiple income streams. Need business skills, financial literacy, and self-management training.',
      200000000,
      'high',
      ARRAY['business_fundamentals', 'financial_planning', 'tax_basics', 'self_marketing', 'time_management', 'client_relations', 'contract_negotiation', 'platform_navigation', 'income_diversification']
    );
  END IF;

  -- GROUP 32: Artists & Creatives
  IF NOT EXISTS (SELECT 1 FROM user_groups WHERE id = 32) THEN
    INSERT INTO user_groups (id, name, description, estimated_size, priority_level, special_needs)
    VALUES (
      32,
      'Artists & Creatives',
      'Visual artists, musicians, writers, designers, and other creative professionals building sustainable creative careers and navigating the arts economy.',
      20000000,
      'medium',
      ARRAY['creative_business', 'portfolio_development', 'arts_marketing', 'grant_writing', 'copyright_basics', 'pricing_strategies', 'exhibition_planning', 'arts_funding', 'creative_entrepreneurship']
    );
  END IF;

  -- GROUP 33: Neurodivergent Adults
  IF NOT EXISTS (SELECT 1 FROM user_groups WHERE id = 33) THEN
    INSERT INTO user_groups (id, name, description, estimated_size, priority_level, special_needs)
    VALUES (
      33,
      'Neurodivergent Adults',
      'Adults with ADHD, autism, dyslexia, and other neurodivergences seeking content ABOUT executive function, workplace advocacy, life management, and self-understanding. (Note: Format adaptations handled by Pipeline 3)',
      100000000,
      'high',
      ARRAY['executive_function_strategies', 'workplace_advocacy', 'communication_skills', 'time_management_systems', 'sensory_management', 'energy_management', 'relationship_skills', 'self_advocacy', 'accommodation_requests', 'strength_identification']
    );
  END IF;

  -- GROUP 34: LGBTQ+ Learners
  IF NOT EXISTS (SELECT 1 FROM user_groups WHERE id = 34) THEN
    INSERT INTO user_groups (id, name, description, estimated_size, priority_level, special_needs)
    VALUES (
      34,
      'LGBTQ+ Learners',
      'LGBTQ+ individuals seeking education on identity, history, advocacy, legal rights, healthcare navigation, and community resources.',
      300000000,
      'high',
      ARRAY['identity_education', 'lgbtq_history', 'legal_rights', 'healthcare_navigation', 'advocacy_skills', 'community_resources', 'workplace_rights', 'family_law', 'safety_planning', 'mental_health_resources']
    );
  END IF;

  -- GROUP 35: Single Parents
  IF NOT EXISTS (SELECT 1 FROM user_groups WHERE id = 35) THEN
    INSERT INTO user_groups (id, name, description, estimated_size, priority_level, special_needs)
    VALUES (
      35,
      'Single Parents',
      'Single parents managing household, career, and child-rearing responsibilities independently. Need time management, financial planning, and career flexibility strategies.',
      100000000,
      'high',
      ARRAY['time_management', 'financial_planning', 'career_flexibility', 'childcare_resources', 'support_systems', 'legal_rights', 'benefits_navigation', 'stress_management', 'work_life_balance', 'meal_planning']
    );
  END IF;

END $$;

-- =====================================================
-- AUTO-BUNDLING SYSTEM TABLES
-- =====================================================

-- Table: auto_bundle_tags
-- Tracks AI-generated tags for each piece of content
CREATE TABLE IF NOT EXISTS auto_bundle_tags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  content_id uuid NOT NULL,
  content_type text NOT NULL, -- 'book', 'addon', 'worksheet', etc.
  tag_category text NOT NULL, -- 'geography', 'subject', 'economic', 'climate', etc.
  tag_value text NOT NULL,
  confidence_score decimal(3,2) DEFAULT 0.95,
  ai_model_used text,
  created_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES auth.users(id)
);

CREATE INDEX IF NOT EXISTS idx_auto_bundle_tags_content ON auto_bundle_tags(content_id, content_type);
CREATE INDEX IF NOT EXISTS idx_auto_bundle_tags_category ON auto_bundle_tags(tag_category, tag_value);

-- Table: auto_bundle_rules
-- Defines rules for automatic collection creation
CREATE TABLE IF NOT EXISTS auto_bundle_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rule_name text UNIQUE NOT NULL,
  description text,
  target_user_group_id integer REFERENCES user_groups(id),
  required_tags jsonb NOT NULL, -- e.g., [{"category": "geography", "values": ["island", "coastal"]}]
  optional_tags jsonb, -- Additional tags that strengthen the match
  min_items integer DEFAULT 3,
  max_items integer DEFAULT 20,
  priority integer DEFAULT 50,
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Table: auto_generated_collections
-- Collections automatically created by AI
CREATE TABLE IF NOT EXISTS auto_generated_collections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  collection_name text NOT NULL,
  collection_type text NOT NULL, -- 'user_group', 'geography', 'subject', 'thematic'
  target_user_groups integer[] DEFAULT ARRAY[]::integer[],
  description text,
  item_count integer DEFAULT 0,
  generation_method text DEFAULT 'ai_auto_bundle', -- How it was created
  confidence_score decimal(3,2) DEFAULT 0.90,
  reviewed boolean DEFAULT false,
  approved boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES auth.users(id)
);

-- Table: collection_items
-- Links content to collections
CREATE TABLE IF NOT EXISTS collection_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  collection_id uuid NOT NULL REFERENCES auto_generated_collections(id) ON DELETE CASCADE,
  content_id uuid NOT NULL,
  content_type text NOT NULL, -- 'book', 'addon', 'worksheet', etc.
  position integer DEFAULT 0,
  relevance_score decimal(3,2) DEFAULT 0.90,
  added_at timestamptz DEFAULT now(),
  added_by uuid REFERENCES auth.users(id)
);

CREATE INDEX IF NOT EXISTS idx_collection_items_collection ON collection_items(collection_id);
CREATE INDEX IF NOT EXISTS idx_collection_items_content ON collection_items(content_id, content_type);

-- Table: user_group_bundle_assignments
-- Tracks which bundles are assigned to which user groups
CREATE TABLE IF NOT EXISTS user_group_bundle_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_group_id integer NOT NULL REFERENCES user_groups(id),
  collection_id uuid NOT NULL REFERENCES auto_generated_collections(id) ON DELETE CASCADE,
  assignment_reason text,
  auto_assigned boolean DEFAULT true,
  priority integer DEFAULT 50,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_group_id, collection_id)
);

CREATE INDEX IF NOT EXISTS idx_bundle_assignments_group ON user_group_bundle_assignments(user_group_id);
CREATE INDEX IF NOT EXISTS idx_bundle_assignments_collection ON user_group_bundle_assignments(collection_id);

-- =====================================================
-- ENABLE ROW LEVEL SECURITY
-- =====================================================

ALTER TABLE auto_bundle_tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE auto_bundle_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE auto_generated_collections ENABLE ROW LEVEL SECURITY;
ALTER TABLE collection_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_group_bundle_assignments ENABLE ROW LEVEL SECURITY;

-- =====================================================
-- RLS POLICIES
-- =====================================================

-- auto_bundle_tags policies
CREATE POLICY "Anyone can view bundle tags"
  ON auto_bundle_tags FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can create bundle tags"
  ON auto_bundle_tags FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- auto_bundle_rules policies
CREATE POLICY "Anyone can view bundle rules"
  ON auto_bundle_rules FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can create bundle rules"
  ON auto_bundle_rules FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update bundle rules"
  ON auto_bundle_rules FOR UPDATE
  TO authenticated
  USING (true);

-- auto_generated_collections policies
CREATE POLICY "Anyone can view collections"
  ON auto_generated_collections FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can create collections"
  ON auto_generated_collections FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update collections"
  ON auto_generated_collections FOR UPDATE
  TO authenticated
  USING (true);

-- collection_items policies
CREATE POLICY "Anyone can view collection items"
  ON collection_items FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can add collection items"
  ON collection_items FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- user_group_bundle_assignments policies
CREATE POLICY "Anyone can view bundle assignments"
  ON user_group_bundle_assignments FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can create bundle assignments"
  ON user_group_bundle_assignments FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- =====================================================
-- SAMPLE AUTO-BUNDLE RULES
-- =====================================================

-- Island Communities Bundle Rule
INSERT INTO auto_bundle_rules (rule_name, description, target_user_group_id, required_tags, optional_tags, min_items, max_items)
VALUES (
  'Island Communities Collection',
  'Automatically bundles marine science, climate adaptation, and sustainable tourism content for island residents',
  29,
  '[
    {"category": "geography", "values": ["island", "coastal", "maritime"]},
    {"category": "subject", "values": ["marine_science", "climate", "sustainability", "ocean"]}
  ]'::jsonb,
  '[
    {"category": "economic", "values": ["tourism", "fishing", "renewable_energy"]},
    {"category": "climate", "values": ["hurricane", "sea_level", "storm"]}
  ]'::jsonb,
  5,
  15
) ON CONFLICT (rule_name) DO NOTHING;

-- Gig Economy Bundle Rule
INSERT INTO auto_bundle_rules (rule_name, description, target_user_group_id, required_tags, optional_tags, min_items, max_items)
VALUES (
  'Gig Economy Workers Collection',
  'Bundles business fundamentals, financial literacy, and freelancing content for gig workers',
  31,
  '[
    {"category": "subject", "values": ["business", "finance", "entrepreneurship"]},
    {"category": "context", "values": ["freelance", "self_employed", "independent"]}
  ]'::jsonb,
  '[
    {"category": "skill", "values": ["marketing", "negotiation", "time_management", "client_relations"]}
  ]'::jsonb,
  5,
  12
) ON CONFLICT (rule_name) DO NOTHING;

-- Neurodivergent Adults Bundle Rule
INSERT INTO auto_bundle_rules (rule_name, description, target_user_group_id, required_tags, optional_tags, min_items, max_items)
VALUES (
  'Neurodivergent Adults Collection',
  'Bundles executive function, workplace advocacy, and life management content for neurodivergent adults',
  33,
  '[
    {"category": "subject", "values": ["executive_function", "neurodiversity", "self_advocacy"]},
    {"category": "audience", "values": ["adults", "workplace", "independent_living"]}
  ]'::jsonb,
  '[
    {"category": "skill", "values": ["time_management", "organization", "communication", "sensory_management"]}
  ]'::jsonb,
  5,
  15
) ON CONFLICT (rule_name) DO NOTHING;

-- Maritime Workers Bundle Rule
INSERT INTO auto_bundle_rules (rule_name, description, target_user_group_id, required_tags, optional_tags, min_items, max_items)
VALUES (
  'Maritime Workers Collection',
  'Bundles maritime industry, safety protocols, and certification content for maritime professionals',
  30,
  '[
    {"category": "industry", "values": ["maritime", "shipping", "fishing", "offshore"]},
    {"category": "subject", "values": ["safety", "navigation", "technical_skills"]}
  ]'::jsonb,
  '[
    {"category": "certification", "values": ["maritime_license", "safety_cert", "equipment_operation"]}
  ]'::jsonb,
  4,
  10
) ON CONFLICT (rule_name) DO NOTHING;
