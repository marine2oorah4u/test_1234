/*
  # Add New Pipelines 32-37 and User Groups 26-28

  This migration adds:

  1. **New Pipelines (32-37):**
     - Pipeline 32: Microlearning (Phase 2-3, Medium Priority)
     - Pipeline 33: Certification/License Prep (PENDING - needs clarification)
     - Pipeline 34: Historical Archives (Phase 2-3, Medium Priority)
     - Pipeline 35: Documentary Video (Phase 4-5, Potential Opportunity)
     - Pipeline 36: Simulations/Virtual Labs (Phase 5, Documentation Only)
     - Pipeline 37: Adaptive Assessment (Phase 4-5, Documentation Only)

  2. **New User Groups (26-28):**
     - Group 26: Immigrants & New Arrivals (Phase 2-3, Medium Priority)
     - Group 27: Rural Communities (Phase 2-3, Medium Priority)
     - Group 28: Urban At-Risk Youth (Phase 3, Pending Expert Consultation)

  3. **Security:**
     - RLS enabled on all tables
     - Authenticated users can read
     - Only admins can insert/update/delete
*/

-- ============================================
-- PIPELINE 32: MICROLEARNING
-- ============================================

-- Microlearning content table
CREATE TABLE IF NOT EXISTS microlearning_content (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  duration_seconds integer NOT NULL CHECK (duration_seconds >= 30 AND duration_seconds <= 600), -- 30 seconds to 10 minutes
  difficulty_level integer CHECK (difficulty_level >= 1 AND difficulty_level <= 100),
  topic_id uuid REFERENCES topics(id) ON DELETE CASCADE,
  format_type text NOT NULL CHECK (format_type IN ('video', 'infographic', 'quiz', 'flashcard', 'animation', 'audio', 'interactive')),
  content_url text,
  thumbnail_url text,
  tags text[], -- Mobile-optimized, notifications, spaced-repetition, gamification
  mobile_optimized boolean DEFAULT true,
  supports_offline boolean DEFAULT true,
  completion_tracking boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Spaced repetition scheduling
CREATE TABLE IF NOT EXISTS spaced_repetition_schedule (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  content_id uuid REFERENCES microlearning_content(id) ON DELETE CASCADE,
  next_review_date timestamptz NOT NULL,
  interval_days integer NOT NULL DEFAULT 1,
  ease_factor numeric(3,2) DEFAULT 2.5,
  repetitions integer DEFAULT 0,
  last_reviewed_at timestamptz,
  quality_rating integer CHECK (quality_rating >= 0 AND quality_rating <= 5), -- 0=complete blackout, 5=perfect recall
  created_at timestamptz DEFAULT now()
);

-- Daily streaks and achievements
CREATE TABLE IF NOT EXISTS microlearning_user_stats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  current_streak_days integer DEFAULT 0,
  longest_streak_days integer DEFAULT 0,
  total_minutes_learned integer DEFAULT 0,
  total_items_completed integer DEFAULT 0,
  last_activity_date date,
  badges_earned text[],
  level integer DEFAULT 1,
  experience_points integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE microlearning_content ENABLE ROW LEVEL SECURITY;
ALTER TABLE spaced_repetition_schedule ENABLE ROW LEVEL SECURITY;
ALTER TABLE microlearning_user_stats ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Authenticated users can view microlearning content"
  ON microlearning_content FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can view own spaced repetition schedule"
  ON spaced_repetition_schedule FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own spaced repetition schedule"
  ON spaced_repetition_schedule FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view own microlearning stats"
  ON microlearning_user_stats FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own microlearning stats"
  ON microlearning_user_stats FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- ============================================
-- PIPELINE 34: HISTORICAL ARCHIVES
-- ============================================

-- Historical documents and artifacts
CREATE TABLE IF NOT EXISTS historical_archives (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  document_type text NOT NULL CHECK (document_type IN (
    'primary_source', 'photograph', 'document', 'artifact', 'oral_history',
    'video', 'audio', 'newspaper', 'letter', 'diary', 'map', 'artwork'
  )),
  time_period text, -- e.g., "1920s", "Ancient Rome", "World War II"
  date_created date,
  date_range_start date,
  date_range_end date,
  location text,
  country_id uuid REFERENCES countries(id),
  cultural_context text,
  historical_significance text,
  primary_language text,
  original_source text, -- Original archive/museum
  digitization_quality text CHECK (digitization_quality IN ('low', 'medium', 'high', 'ultra_high')),
  file_url text,
  thumbnail_url text,
  metadata jsonb, -- Flexible storage for various metadata
  tags text[],
  content_warnings text[], -- Sensitive historical content
  educational_context text,
  research_notes text,
  citations text[],
  related_topics uuid[],
  ai_transcription text, -- For handwritten documents
  ai_translation text, -- For non-English documents
  word_count integer, -- Variable, AI decides
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Historical context and analysis
CREATE TABLE IF NOT EXISTS historical_analysis (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  archive_id uuid REFERENCES historical_archives(id) ON DELETE CASCADE,
  analysis_type text CHECK (analysis_type IN ('context', 'significance', 'perspective', 'bias_analysis', 'comparison')),
  content text NOT NULL,
  reading_level text,
  author_perspective text,
  generated_by_ai boolean DEFAULT false,
  reviewed_by_historian boolean DEFAULT false,
  historian_notes text,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE historical_archives ENABLE ROW LEVEL SECURITY;
ALTER TABLE historical_analysis ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Authenticated users can view historical archives"
  ON historical_archives FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can view historical analysis"
  ON historical_analysis FOR SELECT
  TO authenticated
  USING (true);

-- ============================================
-- PIPELINE 35: DOCUMENTARY VIDEO (FUTURE/POTENTIAL)
-- ============================================

-- Placeholder table for future documentary video pipeline
CREATE TABLE IF NOT EXISTS documentary_video_projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  status text DEFAULT 'potential' CHECK (status IN ('potential', 'planned', 'in_production', 'completed')),
  phase text DEFAULT 'Phase 4-5',
  notes text DEFAULT 'Potential opportunity - requires video production expertise and infrastructure',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE documentary_video_projects ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view documentary projects"
  ON documentary_video_projects FOR SELECT
  TO authenticated
  USING (true);

-- ============================================
-- PIPELINE 36: SIMULATIONS/VIRTUAL LABS (FUTURE)
-- ============================================

-- Placeholder table for future simulations pipeline
CREATE TABLE IF NOT EXISTS simulation_projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  status text DEFAULT 'future' CHECK (status IN ('future', 'research', 'development', 'completed')),
  phase text DEFAULT 'Phase 5',
  notes text DEFAULT 'Documentation only - no full blueprints yet. Will create when ready.',
  simulation_type text CHECK (simulation_type IN ('science_lab', 'physics', 'chemistry', 'biology', 'engineering', 'medical', 'business', 'history')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE simulation_projects ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view simulation projects"
  ON simulation_projects FOR SELECT
  TO authenticated
  USING (true);

-- ============================================
-- PIPELINE 37: ADAPTIVE ASSESSMENT (FUTURE)
-- ============================================

-- Placeholder table for future adaptive assessment pipeline
CREATE TABLE IF NOT EXISTS adaptive_assessment_projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  status text DEFAULT 'future' CHECK (status IN ('future', 'research', 'development', 'completed')),
  phase text DEFAULT 'Phase 4-5',
  notes text DEFAULT 'Documentation only - requires advanced AI/ML development',
  assessment_type text CHECK (assessment_type IN ('diagnostic', 'formative', 'summative', 'skills_based')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE adaptive_assessment_projects ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view adaptive assessment projects"
  ON adaptive_assessment_projects FOR SELECT
  TO authenticated
  USING (true);

-- ============================================
-- USER GROUP 26: IMMIGRANTS & NEW ARRIVALS
-- ============================================

-- Immigrant and new arrival content packages
CREATE TABLE IF NOT EXISTS immigrant_content_packages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  package_name text NOT NULL,
  target_audience text, -- Recent immigrants, refugees, visa holders, etc.
  primary_language text NOT NULL,
  english_proficiency_level text CHECK (english_proficiency_level IN ('beginner', 'intermediate', 'advanced', 'fluent')),
  content_focus text[], -- Language learning, cultural adaptation, job skills, legal info
  country_of_origin_id uuid REFERENCES countries(id),
  country_of_destination_id uuid REFERENCES countries(id),
  visa_type text, -- Student, work, refugee, permanent resident
  cultural_adaptation_modules text[],
  legal_information_modules text[],
  job_readiness_modules text[],
  community_resources text[],
  translation_services_included boolean DEFAULT true,
  cultural_sensitivity_reviewed boolean DEFAULT false,
  phase text DEFAULT 'Phase 2-3',
  priority text DEFAULT 'Medium',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE immigrant_content_packages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view immigrant packages"
  ON immigrant_content_packages FOR SELECT
  TO authenticated
  USING (true);

-- ============================================
-- USER GROUP 27: RURAL COMMUNITIES
-- ============================================

-- Rural community content packages
CREATE TABLE IF NOT EXISTS rural_community_packages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  package_name text NOT NULL,
  target_region text, -- Appalachia, Great Plains, Rural West, etc.
  population_density text CHECK (population_density IN ('very_sparse', 'sparse', 'rural')),
  internet_connectivity text CHECK (internet_connectivity IN ('none', 'limited', 'moderate', 'good')),
  offline_access_required boolean DEFAULT true,
  local_context_adaptation text[],
  agricultural_content boolean DEFAULT false,
  trades_focus boolean DEFAULT false,
  distance_learning_optimized boolean DEFAULT true,
  transportation_barriers_addressed boolean DEFAULT true,
  community_specific_resources text[],
  phase text DEFAULT 'Phase 2-3',
  priority text DEFAULT 'Medium',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE rural_community_packages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view rural packages"
  ON rural_community_packages FOR SELECT
  TO authenticated
  USING (true);

-- ============================================
-- USER GROUP 28: URBAN AT-RISK YOUTH
-- ============================================

-- Urban at-risk youth content packages
CREATE TABLE IF NOT EXISTS urban_youth_packages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  package_name text NOT NULL,
  target_age_range text,
  risk_factors_addressed text[], -- Trauma, poverty, violence exposure, family instability
  trauma_informed_approach boolean DEFAULT true,
  cultural_responsiveness text[],
  mentorship_integration boolean DEFAULT false,
  career_exploration boolean DEFAULT true,
  social_emotional_learning boolean DEFAULT true,
  restorative_practices boolean DEFAULT false,
  community_partnerships text[],
  expert_consultation_required boolean DEFAULT true,
  expert_consultation_types text[] DEFAULT ARRAY['trauma_specialists', 'social_workers', 'youth_advocates', 'community_leaders'],
  phase text DEFAULT 'Phase 3',
  priority text DEFAULT 'High (but requires expert consultation)',
  status text DEFAULT 'Pending Research and Expert Consultation',
  notes text DEFAULT 'REQUIRES consultation with trauma specialists, social workers, youth advocates before implementation',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE urban_youth_packages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view urban youth packages"
  ON urban_youth_packages FOR SELECT
  TO authenticated
  USING (true);

-- ============================================
-- UPDATE PIPELINES MASTER TABLE
-- ============================================

-- Add new pipelines to master tracking table (if it exists)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'pipelines') THEN
    INSERT INTO pipelines (pipeline_number, name, status, phase, priority, description)
    VALUES
      (32, 'Microlearning', 'planned', 'Phase 2-3', 'medium', 'Bite-sized learning, 30s-10min, mobile-optimized, spaced repetition'),
      (33, 'Certification/License Prep', 'pending_clarification', 'TBD', 'TBD', 'PENDING - needs more discussion about exact scope'),
      (34, 'Historical Archives', 'planned', 'Phase 2-3', 'medium', 'Primary sources, digitized documents, AI transcription, flexible word count'),
      (35, 'Documentary Video', 'potential', 'Phase 4-5', 'low', 'Potential opportunity only - requires video production expertise'),
      (36, 'Simulations/Virtual Labs', 'future', 'Phase 5', 'low', 'Documentation only - will create blueprints later'),
      (37, 'Adaptive Assessment', 'future', 'Phase 4-5', 'low', 'Documentation only - requires advanced AI/ML')
    ON CONFLICT (pipeline_number) DO UPDATE SET
      name = EXCLUDED.name,
      status = EXCLUDED.status,
      phase = EXCLUDED.phase,
      priority = EXCLUDED.priority,
      description = EXCLUDED.description;
  END IF;
END $$;

-- ============================================
-- UPDATE USER GROUPS MASTER TABLE
-- ============================================

-- Add new user groups to master tracking table (if it exists)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'user_groups') THEN
    INSERT INTO user_groups (group_number, name, status, phase, priority, description)
    VALUES
      (26, 'Immigrants & New Arrivals', 'planned', 'Phase 2-3', 'medium', 'Language learning, cultural adaptation, job skills, legal information'),
      (27, 'Rural Communities', 'planned', 'Phase 2-3', 'medium', 'Offline-first, limited connectivity, agricultural/trades focus, distance learning'),
      (28, 'Urban At-Risk Youth', 'pending_consultation', 'Phase 3', 'high', 'Trauma-informed, requires expert consultation before implementation')
    ON CONFLICT (group_number) DO UPDATE SET
      name = EXCLUDED.name,
      status = EXCLUDED.status,
      phase = EXCLUDED.phase,
      priority = EXCLUDED.priority,
      description = EXCLUDED.description;
  END IF;
END $$;

-- ============================================
-- INDEXES FOR PERFORMANCE
-- ============================================

CREATE INDEX IF NOT EXISTS idx_microlearning_topic ON microlearning_content(topic_id);
CREATE INDEX IF NOT EXISTS idx_microlearning_format ON microlearning_content(format_type);
CREATE INDEX IF NOT EXISTS idx_microlearning_duration ON microlearning_content(duration_seconds);

CREATE INDEX IF NOT EXISTS idx_spaced_rep_user ON spaced_repetition_schedule(user_id);
CREATE INDEX IF NOT EXISTS idx_spaced_rep_next_review ON spaced_repetition_schedule(next_review_date);

CREATE INDEX IF NOT EXISTS idx_historical_type ON historical_archives(document_type);
CREATE INDEX IF NOT EXISTS idx_historical_period ON historical_archives(time_period);
CREATE INDEX IF NOT EXISTS idx_historical_country ON historical_archives(country_id);

CREATE INDEX IF NOT EXISTS idx_immigrant_language ON immigrant_content_packages(primary_language);
CREATE INDEX IF NOT EXISTS idx_immigrant_origin ON immigrant_content_packages(country_of_origin_id);

CREATE INDEX IF NOT EXISTS idx_rural_region ON rural_community_packages(target_region);
CREATE INDEX IF NOT EXISTS idx_rural_connectivity ON rural_community_packages(internet_connectivity);

CREATE INDEX IF NOT EXISTS idx_urban_youth_age ON urban_youth_packages(target_age_range);
