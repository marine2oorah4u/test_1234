/*
  # Complete Addon System Upgrade

  1. New Systems
    - AI consensus tracking for all features
    - 1-100 difficulty scoring system
    - Rich visual content tracking
    - File structure and quality tracking

  2. Changes
    - Upgrade difficulty scoring to 1-100 scale
    - Add AI consensus verification tracking
    - Add visual quality metrics
    - Add file structure compliance tracking
    - Add self-healing attempt tracking

  3. Security
    - Enable RLS on all new tables
    - Policies for authenticated users and service role
*/

-- =====================================================
-- 1. AI CONSENSUS TRACKING SYSTEM
-- =====================================================

CREATE TABLE IF NOT EXISTS ai_consensus_tracking (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- What was being verified
  feature_id TEXT NOT NULL,
  feature_type TEXT NOT NULL CHECK (feature_type IN (
    'activity_pack', 'worksheet', 'quiz', 'lesson_plan', 'simulation',
    'game', 'role_play', 'debate', 'field_trip', 'challenge', 'other'
  )),
  task_type TEXT NOT NULL CHECK (task_type IN (
    'content_generation', 'safety_review', 'fact_verification',
    'logic_check', 'feasibility_check', 'quality_verification',
    'creative_content', 'quick_enhancement'
  )),

  -- AI models used
  models_used TEXT[] NOT NULL,
  model_count INTEGER NOT NULL CHECK (model_count BETWEEN 2 AND 10),

  -- Scoring
  individual_scores JSONB NOT NULL, -- {model_name: score}
  consensus_score DECIMAL(4,2) NOT NULL CHECK (consensus_score BETWEEN 0 AND 100),
  quality_threshold DECIMAL(4,2) NOT NULL,
  threshold_met BOOLEAN NOT NULL,

  -- Attempts and self-healing
  attempt_number INTEGER NOT NULL DEFAULT 1 CHECK (attempt_number BETWEEN 1 AND 5),
  total_attempts INTEGER NOT NULL DEFAULT 1,
  self_healing_applied BOOLEAN DEFAULT false,
  self_healing_actions JSONB, -- [{issue: "...", fix: "...", model: "..."}]

  -- Issues
  issues_detected TEXT[],
  issues_resolved TEXT[],
  issues_unresolved TEXT[],

  -- Final status
  final_status TEXT NOT NULL CHECK (final_status IN ('PASS', 'FAIL', 'MANUAL_REVIEW')),
  confidence_level TEXT CHECK (confidence_level IN ('Very High', 'High', 'Medium', 'Low')),

  -- Metadata
  created_at TIMESTAMPTZ DEFAULT now(),
  verified_by UUID REFERENCES auth.users(id)
);

CREATE INDEX idx_ai_consensus_feature ON ai_consensus_tracking(feature_id);
CREATE INDEX idx_ai_consensus_status ON ai_consensus_tracking(final_status);
CREATE INDEX idx_ai_consensus_score ON ai_consensus_tracking(consensus_score);
CREATE INDEX idx_ai_consensus_created ON ai_consensus_tracking(created_at);

ALTER TABLE ai_consensus_tracking ENABLE ROW LEVEL SECURITY;

CREATE POLICY "AI consensus readable by authenticated users"
  ON ai_consensus_tracking FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "AI consensus writable by service role"
  ON ai_consensus_tracking FOR INSERT
  TO service_role
  WITH CHECK (true);

-- =====================================================
-- 2. UPGRADE DIFFICULTY SYSTEM TO 1-100 SCALE
-- =====================================================

-- Add new difficulty columns to addon_features
ALTER TABLE addon_features
ADD COLUMN IF NOT EXISTS difficulty_score INTEGER CHECK (difficulty_score BETWEEN 1 AND 100),
ADD COLUMN IF NOT EXISTS difficulty_band TEXT CHECK (difficulty_band IN (
  'Beginner', 'Elementary', 'Intermediate', 'Advanced', 'Professional', 'Expert'
)),
ADD COLUMN IF NOT EXISTS difficulty_factors JSONB;

-- Migrate old 1-5 scale to 1-100 scale (if data exists)
-- 1 → 10, 2 → 30, 3 → 50, 4 → 70, 5 → 90
UPDATE addon_features
SET difficulty_score = CASE
  WHEN difficulty_level = 'beginner' THEN 20
  WHEN difficulty_level = 'elementary' THEN 35
  WHEN difficulty_level = 'intermediate' THEN 50
  WHEN difficulty_level = 'advanced' THEN 65
  WHEN difficulty_level = 'expert' THEN 85
  ELSE 50
END
WHERE difficulty_score IS NULL;

-- Set difficulty band based on score
UPDATE addon_features
SET difficulty_band = CASE
  WHEN difficulty_score BETWEEN 1 AND 20 THEN 'Beginner'
  WHEN difficulty_score BETWEEN 21 AND 35 THEN 'Elementary'
  WHEN difficulty_score BETWEEN 36 AND 50 THEN 'Intermediate'
  WHEN difficulty_score BETWEEN 51 AND 65 THEN 'Advanced'
  WHEN difficulty_score BETWEEN 66 AND 80 THEN 'Professional'
  WHEN difficulty_score BETWEEN 81 AND 100 THEN 'Expert'
  ELSE 'Intermediate'
END
WHERE difficulty_band IS NULL;

-- Add difficulty factor breakdown structure
UPDATE addon_features
SET difficulty_factors = jsonb_build_object(
  'concept_complexity', difficulty_score,
  'skill_requirements', difficulty_score,
  'reading_level', difficulty_score,
  'material_handling', difficulty_score - 5,
  'safety_considerations', difficulty_score + 5,
  'time_commitment', difficulty_score,
  'independence_level', difficulty_score
)
WHERE difficulty_factors IS NULL;

CREATE INDEX idx_difficulty_score ON addon_features(difficulty_score);
CREATE INDEX idx_difficulty_band ON addon_features(difficulty_band);

-- =====================================================
-- 3. VISUAL QUALITY TRACKING
-- =====================================================

CREATE TABLE IF NOT EXISTS visual_quality_tracking (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  addon_id UUID REFERENCES addon_features(id) ON DELETE CASCADE,

  -- Visual quality metrics
  overall_quality_tier TEXT NOT NULL CHECK (overall_quality_tier IN ('TIER_1_PREMIUM', 'TIER_2_ACCEPTABLE', 'TIER_3_UNACCEPTABLE')),
  quality_score DECIMAL(4,2) CHECK (quality_score BETWEEN 0 AND 100),

  -- Design elements
  has_cover_page BOOLEAN DEFAULT false,
  has_color_throughout BOOLEAN DEFAULT false,
  has_custom_graphics BOOLEAN DEFAULT false,
  has_professional_layout BOOLEAN DEFAULT false,
  has_visual_hierarchy BOOLEAN DEFAULT false,
  has_high_res_images BOOLEAN DEFAULT false,

  -- Accessibility
  color_contrast_wcag_aa BOOLEAN DEFAULT false,
  print_ready_300dpi BOOLEAN DEFAULT false,
  embedded_fonts BOOLEAN DEFAULT false,

  -- File structure
  has_table_of_contents BOOLEAN DEFAULT false,
  has_appendices BOOLEAN DEFAULT false,
  has_quick_start_guide BOOLEAN DEFAULT false,
  page_count INTEGER,

  -- Compliance
  meets_visual_standards BOOLEAN DEFAULT false,
  rejection_reasons TEXT[],

  created_at TIMESTAMPTZ DEFAULT now(),
  verified_by UUID REFERENCES auth.users(id)
);

CREATE INDEX idx_visual_quality_addon ON visual_quality_tracking(addon_id);
CREATE INDEX idx_visual_quality_tier ON visual_quality_tracking(overall_quality_tier);

ALTER TABLE visual_quality_tracking ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Visual quality readable by authenticated"
  ON visual_quality_tracking FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Visual quality writable by service role"
  ON visual_quality_tracking FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- =====================================================
-- 4. FILE STRUCTURE COMPLIANCE
-- =====================================================

CREATE TABLE IF NOT EXISTS file_structure_compliance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  addon_id UUID REFERENCES addon_features(id) ON DELETE CASCADE,

  -- File information
  file_name TEXT NOT NULL,
  file_size_mb DECIMAL(10,2),
  file_type TEXT CHECK (file_type IN ('PDF', 'DOCX', 'PPTX', 'ZIP')),

  -- Structure compliance
  has_cover_page BOOLEAN DEFAULT false,
  has_toc_if_needed BOOLEAN DEFAULT false,
  has_quick_start BOOLEAN DEFAULT false,
  has_main_content BOOLEAN DEFAULT false,
  has_appendices BOOLEAN DEFAULT false,

  -- Required sections by type
  required_sections JSONB, -- {section_name: present (boolean)}
  missing_sections TEXT[],

  -- Page counts
  total_pages INTEGER,
  expected_min_pages INTEGER,
  expected_max_pages INTEGER,
  within_page_range BOOLEAN,

  -- Packaging
  has_color_version BOOLEAN DEFAULT false,
  has_bw_version BOOLEAN DEFAULT false,
  has_editable_version BOOLEAN DEFAULT false,
  has_quick_start_sheet BOOLEAN DEFAULT false,
  has_assets_folder BOOLEAN DEFAULT false,

  -- Compliance
  fully_compliant BOOLEAN DEFAULT false,
  compliance_issues TEXT[],

  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_file_compliance_addon ON file_structure_compliance(addon_id);
CREATE INDEX idx_file_compliance_status ON file_structure_compliance(fully_compliant);

ALTER TABLE file_structure_compliance ENABLE ROW LEVEL SECURITY;

CREATE POLICY "File compliance readable by authenticated"
  ON file_structure_compliance FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "File compliance writable by service role"
  ON file_structure_compliance FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- =====================================================
-- 5. UPDATE ADDON_FEATURES TABLE
-- =====================================================

-- Add new columns for enhanced tracking
ALTER TABLE addon_features
ADD COLUMN IF NOT EXISTS visual_quality_verified BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS file_structure_verified BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS ai_consensus_verified BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS ready_for_production BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS rejection_reason TEXT,
ADD COLUMN IF NOT EXISTS total_verification_attempts INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS last_verification_date TIMESTAMPTZ;

-- Update ready_for_production logic
CREATE OR REPLACE FUNCTION update_production_readiness()
RETURNS TRIGGER AS $$
BEGIN
  NEW.ready_for_production := (
    NEW.visual_quality_verified = true AND
    NEW.file_structure_verified = true AND
    NEW.ai_consensus_verified = true AND
    NEW.quality_score >= 85.0
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER check_production_readiness
  BEFORE INSERT OR UPDATE ON addon_features
  FOR EACH ROW
  EXECUTE FUNCTION update_production_readiness();

-- =====================================================
-- 6. QUALITY VERIFICATION SUMMARY VIEW
-- =====================================================

CREATE OR REPLACE VIEW addon_quality_summary AS
SELECT
  af.id,
  af.feature_name,
  af.feature_type,
  af.difficulty_score,
  af.difficulty_band,
  af.quality_score,

  -- AI Consensus
  ac.consensus_score as ai_consensus_score,
  ac.final_status as ai_status,
  ac.confidence_level as ai_confidence,

  -- Visual Quality
  vq.overall_quality_tier,
  vq.meets_visual_standards,

  -- File Structure
  fs.fully_compliant as file_structure_compliant,
  fs.total_pages,

  -- Overall Status
  af.ready_for_production,
  af.rejection_reason,

  -- Verification dates
  af.last_verification_date,
  af.created_at

FROM addon_features af
LEFT JOIN LATERAL (
  SELECT * FROM ai_consensus_tracking
  WHERE feature_id = af.id::text
  ORDER BY created_at DESC
  LIMIT 1
) ac ON true
LEFT JOIN visual_quality_tracking vq ON vq.addon_id = af.id
LEFT JOIN file_structure_compliance fs ON fs.addon_id = af.id;

-- =====================================================
-- 7. HELPER FUNCTIONS
-- =====================================================

-- Function to calculate difficulty band from score
CREATE OR REPLACE FUNCTION get_difficulty_band(score INTEGER)
RETURNS TEXT AS $$
BEGIN
  RETURN CASE
    WHEN score BETWEEN 1 AND 20 THEN 'Beginner'
    WHEN score BETWEEN 21 AND 35 THEN 'Elementary'
    WHEN score BETWEEN 36 AND 50 THEN 'Intermediate'
    WHEN score BETWEEN 51 AND 65 THEN 'Advanced'
    WHEN score BETWEEN 66 AND 80 THEN 'Professional'
    WHEN score BETWEEN 81 AND 100 THEN 'Expert'
    ELSE 'Intermediate'
  END;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Function to check if all verification passed
CREATE OR REPLACE FUNCTION all_verifications_passed(addon_id_param UUID)
RETURNS BOOLEAN AS $$
DECLARE
  ai_passed BOOLEAN;
  visual_passed BOOLEAN;
  file_passed BOOLEAN;
BEGIN
  -- Check AI consensus
  SELECT final_status = 'PASS' INTO ai_passed
  FROM ai_consensus_tracking
  WHERE feature_id = addon_id_param::text
  ORDER BY created_at DESC
  LIMIT 1;

  -- Check visual quality
  SELECT meets_visual_standards INTO visual_passed
  FROM visual_quality_tracking
  WHERE addon_id = addon_id_param;

  -- Check file structure
  SELECT fully_compliant INTO file_passed
  FROM file_structure_compliance
  WHERE addon_id = addon_id_param;

  RETURN COALESCE(ai_passed, false) AND
         COALESCE(visual_passed, false) AND
         COALESCE(file_passed, false);
END;
$$ LANGUAGE plpgsql;

-- =====================================================
-- 8. GRANT PERMISSIONS
-- =====================================================

GRANT SELECT ON addon_quality_summary TO authenticated;
GRANT EXECUTE ON FUNCTION get_difficulty_band(INTEGER) TO authenticated;
GRANT EXECUTE ON FUNCTION all_verifications_passed(UUID) TO authenticated;
