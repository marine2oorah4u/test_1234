/*
  # Fix web_api_keys table - Add created_by column

  1. Changes
    - Add created_by column to web_api_keys table
    - This allows tracking who added each API key
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'web_api_keys' AND column_name = 'created_by'
  ) THEN
    ALTER TABLE web_api_keys ADD COLUMN created_by uuid REFERENCES auth.users(id);
  END IF;
END $$;
