/*
  # Global + Country-Specific Content System

  This migration creates the infrastructure for managing global content with country-specific variations:

  1. Tables Created
    - `countries` - All supported countries and their metadata
    - `country_content_requirements` - What each country needs (cultural, educational, etc.)
    - `content_localization_rules` - Pipeline rules for adapting content per country
    - `country_addon_generation` - Tracks which country variations have been generated
    - `country_book_catalog` - Tracks which books exist for which countries

  2. Design Philosophy
    - Store GLOBAL base content (no duplication)
    - Define COUNTRY-SPECIFIC requirements and rules
    - Generate variations ON-THE-FLY during pipeline execution
    - Track what's been generated

  3. Security
    - RLS enabled on all tables
    - Proper access controls
*/

-- Countries Table
CREATE TABLE IF NOT EXISTS countries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Basic Information
  country_code text UNIQUE NOT NULL,
  country_name text NOT NULL,
  country_name_local text,

  -- Language Information
  primary_language text NOT NULL,
  additional_languages text[] DEFAULT '{}',
  writing_system text NOT NULL,
  text_direction text DEFAULT 'ltr' CHECK (text_direction IN ('ltr', 'rtl', 'ttb')),

  -- Educational System
  education_system_type text,
  grade_levels jsonb DEFAULT '{}',
  curriculum_standards jsonb DEFAULT '{}',

  -- Cultural Context
  cultural_holidays text[] DEFAULT '{}',
  important_historical_events text[] DEFAULT '{}',
  local_contexts jsonb DEFAULT '{}',

  -- Content Preferences
  measurement_system text DEFAULT 'metric' CHECK (measurement_system IN ('metric', 'imperial', 'mixed')),
  date_format text DEFAULT 'YYYY-MM-DD',
  number_format text DEFAULT '1,000.00',

  -- Market Information
  priority_tier integer DEFAULT 3 CHECK (priority_tier BETWEEN 1 AND 5),
  market_size text CHECK (market_size IN ('large', 'medium', 'small')),
  launch_status text DEFAULT 'planned' CHECK (launch_status IN ('active', 'beta', 'planned', 'paused')),

  -- Regional Grouping
  region text,
  subregion text,

  -- Metadata
  enabled boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Country Content Requirements Table
CREATE TABLE IF NOT EXISTS country_content_requirements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  country_id uuid REFERENCES countries(id) ON DELETE CASCADE,

  -- Content Type
  requirement_category text NOT NULL,
  requirement_type text NOT NULL,

  -- Requirement Details
  requirement_name text NOT NULL,
  requirement_description text NOT NULL,

  -- Implementation Guidance
  implementation_rules jsonb DEFAULT '{}',
  examples jsonb DEFAULT '[]',

  -- Specific Data
  data_sources text[] DEFAULT '{}',
  verification_methods text[] DEFAULT '{}',

  -- Priority & Applicability
  priority text DEFAULT 'medium' CHECK (priority IN ('critical', 'high', 'medium', 'low')),
  applies_to_addons text[] DEFAULT '{}',
  applies_to_subjects text[] DEFAULT '{}',

  -- Metadata
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Content Localization Rules Table
CREATE TABLE IF NOT EXISTS content_localization_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  country_id uuid REFERENCES countries(id) ON DELETE CASCADE,

  -- Rule Identity
  rule_name text NOT NULL,
  rule_category text NOT NULL,

  -- Rule Definition
  rule_description text NOT NULL,

  -- Transformation Logic
  transformation_type text NOT NULL,
  source_pattern text,
  target_replacement text,

  -- AI Prompt Guidance
  ai_prompt_additions jsonb DEFAULT '{}',
  local_context_data jsonb DEFAULT '{}',

  -- Examples
  before_example text,
  after_example text,

  -- Applicability
  applies_to_pipelines text[] DEFAULT '{}',
  applies_to_addons text[] DEFAULT '{}',
  applies_to_reading_levels text[] DEFAULT '{}',

  -- Priority & Enforcement
  priority integer DEFAULT 50,
  mandatory boolean DEFAULT false,

  -- Metadata
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Country Addon Generation Tracking
CREATE TABLE IF NOT EXISTS country_addon_generation (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),

  -- What was generated
  book_id uuid REFERENCES books(id) ON DELETE CASCADE,
  addon_feature_id uuid REFERENCES addon_features(id) ON DELETE CASCADE,
  country_id uuid REFERENCES countries(id) ON DELETE CASCADE,

  -- Generation Details
  generation_type text DEFAULT 'country_specific' CHECK (
    generation_type IN ('global', 'country_specific', 'region_specific')
  ),

  -- Localization Applied
  rules_applied jsonb DEFAULT '[]',
  requirements_met jsonb DEFAULT '[]',

  -- Content Storage
  generated_content_path text,
  content_preview text,

  -- Quality & Verification
  quality_score numeric(5, 2),
  cultural_accuracy_verified boolean DEFAULT false,
  educational_standards_verified boolean DEFAULT false,

  -- Cost & Performance
  generation_cost numeric(10, 4),
  generation_time_seconds integer,
  tokens_used integer,

  -- Status
  status text DEFAULT 'generated' CHECK (
    status IN ('pending', 'generating', 'generated', 'verified', 'published', 'failed')
  ),

  -- Metadata
  generated_at timestamptz DEFAULT now(),
  generated_by uuid REFERENCES auth.users(id),
  verified_at timestamptz,
  verified_by uuid REFERENCES auth.users(id)
);

-- Country Book Catalog
CREATE TABLE IF NOT EXISTS country_book_catalog (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),

  book_id uuid REFERENCES books(id) ON DELETE CASCADE,
  country_id uuid REFERENCES countries(id) ON DELETE CASCADE,

  -- Availability
  available boolean DEFAULT true,
  availability_status text DEFAULT 'active' CHECK (
    availability_status IN ('active', 'coming_soon', 'discontinued', 'restricted')
  ),

  -- Localization Status
  localization_percentage integer DEFAULT 0 CHECK (localization_percentage BETWEEN 0 AND 100),
  country_adaptations_applied text[] DEFAULT '{}',

  -- Addons Available for This Country
  available_addons uuid[] DEFAULT '{}',

  -- Pricing & Access
  pricing_tier text,
  access_restrictions text[] DEFAULT '{}',

  -- Metadata
  added_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),

  UNIQUE(book_id, country_id)
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_countries_code ON countries(country_code);
CREATE INDEX IF NOT EXISTS idx_countries_region ON countries(region);
CREATE INDEX IF NOT EXISTS idx_countries_priority ON countries(priority_tier);
CREATE INDEX IF NOT EXISTS idx_countries_status ON countries(launch_status);

CREATE INDEX IF NOT EXISTS idx_country_requirements_country ON country_content_requirements(country_id);
CREATE INDEX IF NOT EXISTS idx_country_requirements_category ON country_content_requirements(requirement_category);

CREATE INDEX IF NOT EXISTS idx_localization_rules_country ON content_localization_rules(country_id);
CREATE INDEX IF NOT EXISTS idx_localization_rules_category ON content_localization_rules(rule_category);

CREATE INDEX IF NOT EXISTS idx_addon_generation_book ON country_addon_generation(book_id);
CREATE INDEX IF NOT EXISTS idx_addon_generation_country ON country_addon_generation(country_id);
CREATE INDEX IF NOT EXISTS idx_addon_generation_status ON country_addon_generation(status);

CREATE INDEX IF NOT EXISTS idx_book_catalog_book ON country_book_catalog(book_id);
CREATE INDEX IF NOT EXISTS idx_book_catalog_country ON country_book_catalog(country_id);

-- Enable RLS
ALTER TABLE countries ENABLE ROW LEVEL SECURITY;
ALTER TABLE country_content_requirements ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_localization_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE country_addon_generation ENABLE ROW LEVEL SECURITY;
ALTER TABLE country_book_catalog ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Anyone can view active countries"
  ON countries FOR SELECT
  TO authenticated
  USING (enabled = true);

CREATE POLICY "Admins can manage countries"
  ON countries FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Users can view content requirements"
  ON country_content_requirements FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage content requirements"
  ON country_content_requirements FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Users can view active localization rules"
  ON content_localization_rules FOR SELECT
  TO authenticated
  USING (active = true);

CREATE POLICY "Admins can manage localization rules"
  ON content_localization_rules FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Users can view their addon generations"
  ON country_addon_generation FOR SELECT
  TO authenticated
  USING (
    generated_by = auth.uid() OR
    status IN ('verified', 'published')
  );

CREATE POLICY "Authenticated users can insert generations"
  ON country_addon_generation FOR INSERT
  TO authenticated
  WITH CHECK (generated_by = auth.uid());

CREATE POLICY "Admins can manage all generations"
  ON country_addon_generation FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Anyone can view available books by country"
  ON country_book_catalog FOR SELECT
  TO authenticated
  USING (available = true);

CREATE POLICY "Admins can manage book catalog"
  ON country_book_catalog FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

-- Triggers
CREATE TRIGGER update_countries_updated_at
  BEFORE UPDATE ON countries
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_country_requirements_updated_at
  BEFORE UPDATE ON country_content_requirements
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_localization_rules_updated_at
  BEFORE UPDATE ON content_localization_rules
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_book_catalog_updated_at
  BEFORE UPDATE ON country_book_catalog
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Initial priority countries
INSERT INTO countries (country_code, country_name, primary_language, writing_system, region, subregion, priority_tier, market_size, launch_status) VALUES
  ('US', 'United States', 'en', 'latin', 'americas', 'north_america', 1, 'large', 'active'),
  ('IN', 'India', 'hi', 'devanagari', 'asia', 'south_asia', 1, 'large', 'active'),
  ('CN', 'China', 'zh', 'chinese', 'asia', 'east_asia', 1, 'large', 'planned'),
  ('GB', 'United Kingdom', 'en', 'latin', 'europe', 'northern_europe', 2, 'large', 'active'),
  ('BR', 'Brazil', 'pt', 'latin', 'americas', 'south_america', 2, 'large', 'active'),
  ('MX', 'Mexico', 'es', 'latin', 'americas', 'central_america', 2, 'large', 'active'),
  ('JP', 'Japan', 'ja', 'japanese', 'asia', 'east_asia', 2, 'large', 'planned'),
  ('DE', 'Germany', 'de', 'latin', 'europe', 'western_europe', 2, 'large', 'planned'),
  ('PK', 'Pakistan', 'ur', 'arabic', 'asia', 'south_asia', 3, 'medium', 'planned'),
  ('BD', 'Bangladesh', 'bn', 'bengali', 'asia', 'south_asia', 3, 'medium', 'planned'),
  ('NG', 'Nigeria', 'en', 'latin', 'africa', 'western_africa', 3, 'medium', 'planned'),
  ('ID', 'Indonesia', 'id', 'latin', 'asia', 'southeast_asia', 3, 'medium', 'planned'),
  ('PH', 'Philippines', 'en', 'latin', 'asia', 'southeast_asia', 3, 'medium', 'planned'),
  ('ZA', 'South Africa', 'en', 'latin', 'africa', 'southern_africa', 3, 'medium', 'planned'),
  ('KE', 'Kenya', 'en', 'latin', 'africa', 'eastern_africa', 3, 'medium', 'planned')
ON CONFLICT (country_code) DO NOTHING;

-- Example content requirements for India
INSERT INTO country_content_requirements (
  country_id,
  requirement_category,
  requirement_type,
  requirement_name,
  requirement_description,
  implementation_rules,
  examples,
  priority,
  applies_to_addons,
  applies_to_subjects
)
SELECT
  id,
  'cultural',
  'local_examples',
  'Indian Cultural Context',
  'Replace generic examples with Indian contexts, festivals, and scenarios',
  '{"rule": "Use Indian festivals, currency (₹), geography, and cultural references"}'::jsonb,
  '["Diwali instead of Christmas", "Rupees instead of Dollars", "Cricket instead of Baseball"]'::jsonb,
  'critical',
  ARRAY['activity_packs', 'worksheet_sets', 'quiz_packs'],
  ARRAY['mathematics', 'social_studies', 'language_arts']
FROM countries WHERE country_code = 'IN';

-- Example localization rule for India
INSERT INTO content_localization_rules (
  country_id,
  rule_name,
  rule_category,
  rule_description,
  transformation_type,
  source_pattern,
  target_replacement,
  ai_prompt_additions,
  applies_to_pipelines,
  applies_to_addons,
  priority,
  mandatory
)
SELECT
  id,
  'Currency Conversion',
  'terminology',
  'Replace dollar references with rupees',
  'replace',
  '\$|USD|dollar',
  '₹|INR|rupee',
  '{"context": "Use Indian currency (Rupees) in all examples. Current exchange rate guidance: 1 USD ≈ 83 INR", "examples": "₹500 for a textbook, ₹100 for lunch"}'::jsonb,
  ARRAY['pipeline_5_educational_addons'],
  ARRAY['activity_packs', 'worksheet_sets'],
  90,
  true
FROM countries WHERE country_code = 'IN';