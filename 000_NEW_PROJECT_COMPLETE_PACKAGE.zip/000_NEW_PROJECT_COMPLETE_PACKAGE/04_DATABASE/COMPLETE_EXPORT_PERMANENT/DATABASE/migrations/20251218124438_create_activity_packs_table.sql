/*
  # Create Activity Packs Table

  1. New Tables
    - `activity_packs`
      - `id` (text, primary key) - Unique identifier for the activity pack
      - `book_id` (text) - Reference to the book this pack is for
      - `title` (text) - Title of the activity pack
      - `description` (text) - Description of what's included
      - `activities` (jsonb) - Array of generated activities
      - `total_activities` (integer) - Count of activities in the pack
      - `total_cost` (numeric) - Cost to generate this pack
      - `quality_score` (integer) - Quality score from AI verification (0-100)
      - `created_at` (timestamptz) - When the pack was created
      - `updated_at` (timestamptz) - Last update time

  2. Security
    - Enable RLS on `activity_packs` table
    - Add policy for authenticated users to read activity packs
    - Add policy for authenticated users to create activity packs
*/

-- Create activity_packs table
CREATE TABLE IF NOT EXISTS activity_packs (
  id text PRIMARY KEY,
  book_id text NOT NULL,
  title text NOT NULL,
  description text,
  activities jsonb NOT NULL DEFAULT '[]'::jsonb,
  total_activities integer NOT NULL DEFAULT 0,
  total_cost numeric(10, 4) NOT NULL DEFAULT 0,
  quality_score integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE activity_packs ENABLE ROW LEVEL SECURITY;

-- Policy: Authenticated users can read all activity packs
CREATE POLICY "Authenticated users can read activity packs"
  ON activity_packs
  FOR SELECT
  TO authenticated
  USING (true);

-- Policy: Authenticated users can create activity packs
CREATE POLICY "Authenticated users can create activity packs"
  ON activity_packs
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Policy: Users can update their own activity packs
CREATE POLICY "Users can update activity packs"
  ON activity_packs
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_activity_packs_book_id ON activity_packs(book_id);
CREATE INDEX IF NOT EXISTS idx_activity_packs_created_at ON activity_packs(created_at DESC);
