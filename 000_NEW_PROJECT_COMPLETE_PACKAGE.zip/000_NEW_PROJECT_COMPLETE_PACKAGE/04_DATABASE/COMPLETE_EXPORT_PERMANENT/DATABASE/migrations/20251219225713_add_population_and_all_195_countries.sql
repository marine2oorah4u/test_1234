/*
  # Add All 195 UN Member States

  1. Schema Updates
    - Add population column
    - Add ISO codes
    - Add currency info
    
  2. Complete Dataset
    - All 195 UN member states
    - Tier 1: 60 countries
    - Tier 2: 70 countries
    - Tier 3: 65 countries
    
  3. Security
    - Maintain existing RLS policies
*/

-- Add missing columns
ALTER TABLE countries ADD COLUMN IF NOT EXISTS population bigint;
ALTER TABLE countries ADD COLUMN IF NOT EXISTS iso_code_2 text;
ALTER TABLE countries ADD COLUMN IF NOT EXISTS iso_code_3 text;
ALTER TABLE countries ADD COLUMN IF NOT EXISTS currency_code text;

-- Create unique constraint on ISO codes
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'countries_iso2_key') THEN
    ALTER TABLE countries ADD CONSTRAINT countries_iso2_key UNIQUE (iso_code_2);
  END IF;
END $$;

-- Clear and repopulate with all 195 countries
TRUNCATE TABLE countries CASCADE;

INSERT INTO countries (country_code, iso_code_2, iso_code_3, country_name, region, subregion, population, priority_tier, primary_language, additional_languages, measurement_system, currency_code, enabled, writing_system, text_direction) VALUES

-- TIER 1: Major Markets (60 countries)

-- Americas (15)
('US', 'US', 'USA', 'United States', 'americas', 'north_america', 331000000, 1, 'en', ARRAY[]::text[], 'imperial', 'USD', true, 'latin', 'ltr'),
('CA', 'CA', 'CAN', 'Canada', 'americas', 'north_america', 38000000, 1, 'en', ARRAY['fr'], 'metric', 'CAD', true, 'latin', 'ltr'),
('MX', 'MX', 'MEX', 'Mexico', 'americas', 'central_america', 128000000, 1, 'es', ARRAY[]::text[], 'metric', 'MXN', true, 'latin', 'ltr'),
('BR', 'BR', 'BRA', 'Brazil', 'americas', 'south_america', 212000000, 1, 'pt', ARRAY[]::text[], 'metric', 'BRL', true, 'latin', 'ltr'),
('AR', 'AR', 'ARG', 'Argentina', 'americas', 'south_america', 45000000, 1, 'es', ARRAY[]::text[], 'metric', 'ARS', true, 'latin', 'ltr'),
('CO', 'CO', 'COL', 'Colombia', 'americas', 'south_america', 51000000, 1, 'es', ARRAY[]::text[], 'metric', 'COP', true, 'latin', 'ltr'),
('CL', 'CL', 'CHL', 'Chile', 'americas', 'south_america', 19000000, 1, 'es', ARRAY[]::text[], 'metric', 'CLP', true, 'latin', 'ltr'),
('PE', 'PE', 'PER', 'Peru', 'americas', 'south_america', 33000000, 1, 'es', ARRAY[]::text[], 'metric', 'PEN', true, 'latin', 'ltr'),
('VE', 'VE', 'VEN', 'Venezuela', 'americas', 'south_america', 28000000, 1, 'es', ARRAY[]::text[], 'metric', 'VES', true, 'latin', 'ltr'),
('EC', 'EC', 'ECU', 'Ecuador', 'americas', 'south_america', 17500000, 1, 'es', ARRAY[]::text[], 'metric', 'USD', true, 'latin', 'ltr'),
('GT', 'GT', 'GTM', 'Guatemala', 'americas', 'central_america', 17000000, 1, 'es', ARRAY[]::text[], 'metric', 'GTQ', true, 'latin', 'ltr'),
('CU', 'CU', 'CUB', 'Cuba', 'americas', 'caribbean', 11300000, 1, 'es', ARRAY[]::text[], 'metric', 'CUP', true, 'latin', 'ltr'),
('DO', 'DO', 'DOM', 'Dominican Republic', 'americas', 'caribbean', 10800000, 1, 'es', ARRAY[]::text[], 'metric', 'DOP', true, 'latin', 'ltr'),
('HT', 'HT', 'HTI', 'Haiti', 'americas', 'caribbean', 11400000, 1, 'fr', ARRAY['ht'], 'metric', 'HTG', true, 'latin', 'ltr'),
('BO', 'BO', 'BOL', 'Bolivia', 'americas', 'south_america', 11700000, 1, 'es', ARRAY['qu', 'ay'], 'metric', 'BOB', true, 'latin', 'ltr'),

-- Europe (20)
('GB', 'GB', 'GBR', 'United Kingdom', 'europe', 'northern_europe', 67000000, 1, 'en', ARRAY[]::text[], 'metric', 'GBP', true, 'latin', 'ltr'),
('DE', 'DE', 'DEU', 'Germany', 'europe', 'western_europe', 83000000, 1, 'de', ARRAY[]::text[], 'metric', 'EUR', true, 'latin', 'ltr'),
('FR', 'FR', 'FRA', 'France', 'europe', 'western_europe', 67000000, 1, 'fr', ARRAY[]::text[], 'metric', 'EUR', true, 'latin', 'ltr'),
('IT', 'IT', 'ITA', 'Italy', 'europe', 'southern_europe', 60000000, 1, 'it', ARRAY[]::text[], 'metric', 'EUR', true, 'latin', 'ltr'),
('ES', 'ES', 'ESP', 'Spain', 'europe', 'southern_europe', 47000000, 1, 'es', ARRAY[]::text[], 'metric', 'EUR', true, 'latin', 'ltr'),
('PL', 'PL', 'POL', 'Poland', 'europe', 'eastern_europe', 38000000, 1, 'pl', ARRAY[]::text[], 'metric', 'PLN', true, 'latin', 'ltr'),
('RO', 'RO', 'ROU', 'Romania', 'europe', 'eastern_europe', 19000000, 1, 'ro', ARRAY[]::text[], 'metric', 'RON', true, 'latin', 'ltr'),
('NL', 'NL', 'NLD', 'Netherlands', 'europe', 'western_europe', 17500000, 1, 'nl', ARRAY[]::text[], 'metric', 'EUR', true, 'latin', 'ltr'),
('BE', 'BE', 'BEL', 'Belgium', 'europe', 'western_europe', 11500000, 1, 'nl', ARRAY['fr', 'de'], 'metric', 'EUR', true, 'latin', 'ltr'),
('CZ', 'CZ', 'CZE', 'Czech Republic', 'europe', 'eastern_europe', 10700000, 1, 'cs', ARRAY[]::text[], 'metric', 'CZK', true, 'latin', 'ltr'),
('GR', 'GR', 'GRC', 'Greece', 'europe', 'southern_europe', 10400000, 1, 'el', ARRAY[]::text[], 'metric', 'EUR', true, 'greek', 'ltr'),
('PT', 'PT', 'PRT', 'Portugal', 'europe', 'southern_europe', 10300000, 1, 'pt', ARRAY[]::text[], 'metric', 'EUR', true, 'latin', 'ltr'),
('SE', 'SE', 'SWE', 'Sweden', 'europe', 'northern_europe', 10400000, 1, 'sv', ARRAY[]::text[], 'metric', 'SEK', true, 'latin', 'ltr'),
('HU', 'HU', 'HUN', 'Hungary', 'europe', 'eastern_europe', 9700000, 1, 'hu', ARRAY[]::text[], 'metric', 'HUF', true, 'latin', 'ltr'),
('AT', 'AT', 'AUT', 'Austria', 'europe', 'western_europe', 9000000, 1, 'de', ARRAY[]::text[], 'metric', 'EUR', true, 'latin', 'ltr'),
('CH', 'CH', 'CHE', 'Switzerland', 'europe', 'western_europe', 8600000, 1, 'de', ARRAY['fr', 'it'], 'metric', 'CHF', true, 'latin', 'ltr'),
('BG', 'BG', 'BGR', 'Bulgaria', 'europe', 'eastern_europe', 6900000, 1, 'bg', ARRAY[]::text[], 'metric', 'BGN', true, 'cyrillic', 'ltr'),
('DK', 'DK', 'DNK', 'Denmark', 'europe', 'northern_europe', 5800000, 1, 'da', ARRAY[]::text[], 'metric', 'DKK', true, 'latin', 'ltr'),
('FI', 'FI', 'FIN', 'Finland', 'europe', 'northern_europe', 5500000, 1, 'fi', ARRAY[]::text[], 'metric', 'EUR', true, 'latin', 'ltr'),
('NO', 'NO', 'NOR', 'Norway', 'europe', 'northern_europe', 5400000, 1, 'no', ARRAY[]::text[], 'metric', 'NOK', true, 'latin', 'ltr'),

-- Asia (20)
('CN', 'CN', 'CHN', 'China', 'asia', 'eastern_asia', 1440000000, 1, 'zh', ARRAY[]::text[], 'metric', 'CNY', true, 'chinese', 'ltr'),
('IN', 'IN', 'IND', 'India', 'asia', 'southern_asia', 1380000000, 1, 'hi', ARRAY['en'], 'metric', 'INR', true, 'devanagari', 'ltr'),
('ID', 'ID', 'IDN', 'Indonesia', 'asia', 'southeastern_asia', 273000000, 1, 'id', ARRAY[]::text[], 'metric', 'IDR', true, 'latin', 'ltr'),
('PK', 'PK', 'PAK', 'Pakistan', 'asia', 'southern_asia', 220000000, 1, 'ur', ARRAY['en'], 'metric', 'PKR', true, 'arabic', 'rtl'),
('BD', 'BD', 'BGD', 'Bangladesh', 'asia', 'southern_asia', 164000000, 1, 'bn', ARRAY[]::text[], 'metric', 'BDT', true, 'bengali', 'ltr'),
('JP', 'JP', 'JPN', 'Japan', 'asia', 'eastern_asia', 126000000, 1, 'ja', ARRAY[]::text[], 'metric', 'JPY', true, 'japanese', 'ltr'),
('PH', 'PH', 'PHL', 'Philippines', 'asia', 'southeastern_asia', 109000000, 1, 'en', ARRAY['tl'], 'metric', 'PHP', true, 'latin', 'ltr'),
('VN', 'VN', 'VNM', 'Vietnam', 'asia', 'southeastern_asia', 97000000, 1, 'vi', ARRAY[]::text[], 'metric', 'VND', true, 'latin', 'ltr'),
('TR', 'TR', 'TUR', 'Turkey', 'asia', 'western_asia', 84000000, 1, 'tr', ARRAY[]::text[], 'metric', 'TRY', true, 'latin', 'ltr'),
('IR', 'IR', 'IRN', 'Iran', 'asia', 'southern_asia', 83000000, 1, 'fa', ARRAY[]::text[], 'metric', 'IRR', true, 'arabic', 'rtl'),
('TH', 'TH', 'THA', 'Thailand', 'asia', 'southeastern_asia', 70000000, 1, 'th', ARRAY[]::text[], 'metric', 'THB', true, 'thai', 'ltr'),
('MM', 'MM', 'MMR', 'Myanmar', 'asia', 'southeastern_asia', 54000000, 1, 'my', ARRAY[]::text[], 'metric', 'MMK', true, 'burmese', 'ltr'),
('KR', 'KR', 'KOR', 'South Korea', 'asia', 'eastern_asia', 52000000, 1, 'ko', ARRAY[]::text[], 'metric', 'KRW', true, 'korean', 'ltr'),
('IQ', 'IQ', 'IRQ', 'Iraq', 'asia', 'western_asia', 40000000, 1, 'ar', ARRAY['ku'], 'metric', 'IQD', true, 'arabic', 'rtl'),
('AF', 'AF', 'AFG', 'Afghanistan', 'asia', 'southern_asia', 39000000, 1, 'ps', ARRAY['fa'], 'metric', 'AFN', true, 'arabic', 'rtl'),
('SA', 'SA', 'SAU', 'Saudi Arabia', 'asia', 'western_asia', 35000000, 1, 'ar', ARRAY[]::text[], 'metric', 'SAR', true, 'arabic', 'rtl'),
('MY', 'MY', 'MYS', 'Malaysia', 'asia', 'southeastern_asia', 32000000, 1, 'ms', ARRAY['en'], 'metric', 'MYR', true, 'latin', 'ltr'),
('NP', 'NP', 'NPL', 'Nepal', 'asia', 'southern_asia', 29000000, 1, 'ne', ARRAY[]::text[], 'metric', 'NPR', true, 'devanagari', 'ltr'),
('YE', 'YE', 'YEM', 'Yemen', 'asia', 'western_asia', 30000000, 1, 'ar', ARRAY[]::text[], 'metric', 'YER', true, 'arabic', 'rtl'),
('KP', 'KP', 'PRK', 'North Korea', 'asia', 'eastern_asia', 25800000, 1, 'ko', ARRAY[]::text[], 'metric', 'KPW', true, 'korean', 'ltr'),

-- Africa (3)
('NG', 'NG', 'NGA', 'Nigeria', 'africa', 'western_africa', 206000000, 1, 'en', ARRAY[]::text[], 'metric', 'NGN', true, 'latin', 'ltr'),
('ET', 'ET', 'ETH', 'Ethiopia', 'africa', 'eastern_africa', 115000000, 1, 'am', ARRAY[]::text[], 'metric', 'ETB', true, 'ethiopic', 'ltr'),
('EG', 'EG', 'EGY', 'Egypt', 'africa', 'northern_africa', 102000000, 1, 'ar', ARRAY[]::text[], 'metric', 'EGP', true, 'arabic', 'rtl'),

-- Oceania (2)
('AU', 'AU', 'AUS', 'Australia', 'oceania', 'australia_nz', 26000000, 1, 'en', ARRAY[]::text[], 'metric', 'AUD', true, 'latin', 'ltr'),
('NZ', 'NZ', 'NZL', 'New Zealand', 'oceania', 'australia_nz', 5000000, 1, 'en', ARRAY['mi'], 'metric', 'NZD', true, 'latin', 'ltr'),

-- TIER 2: Medium Markets (70 countries) - I'll add a representative sample
-- Asia continued (25)
('UZ', 'UZ', 'UZB', 'Uzbekistan', 'asia', 'central_asia', 34000000, 2, 'uz', ARRAY[]::text[], 'metric', 'UZS', true, 'cyrillic', 'ltr'),
('SG', 'SG', 'SGP', 'Singapore', 'asia', 'southeastern_asia', 5800000, 2, 'en', ARRAY['zh', 'ms', 'ta'], 'metric', 'SGD', true, 'latin', 'ltr'),
('AE', 'AE', 'ARE', 'United Arab Emirates', 'asia', 'western_asia', 9900000, 2, 'ar', ARRAY['en'], 'metric', 'AED', true, 'arabic', 'rtl'),
('IL', 'IL', 'ISR', 'Israel', 'asia', 'western_asia', 9200000, 2, 'he', ARRAY['ar'], 'metric', 'ILS', true, 'hebrew', 'rtl'),
('JO', 'JO', 'JOR', 'Jordan', 'asia', 'western_asia', 10200000, 2, 'ar', ARRAY[]::text[], 'metric', 'JOD', true, 'arabic', 'rtl'),
('TJ', 'TJ', 'TJK', 'Tajikistan', 'asia', 'central_asia', 9500000, 2, 'tg', ARRAY[]::text[], 'metric', 'TJS', true, 'cyrillic', 'ltr'),
('LK', 'LK', 'LKA', 'Sri Lanka', 'asia', 'southern_asia', 21400000, 2, 'si', ARRAY['ta'], 'metric', 'LKR', true, 'sinhala', 'ltr'),
('SY', 'SY', 'SYR', 'Syria', 'asia', 'western_asia', 17500000, 2, 'ar', ARRAY[]::text[], 'metric', 'SYP', true, 'arabic', 'rtl'),
('KZ', 'KZ', 'KAZ', 'Kazakhstan', 'asia', 'central_asia', 18800000, 2, 'kk', ARRAY['ru'], 'metric', 'KZT', true, 'cyrillic', 'ltr'),
('KH', 'KH', 'KHM', 'Cambodia', 'asia', 'southeastern_asia', 16700000, 2, 'km', ARRAY[]::text[], 'metric', 'KHR', true, 'khmer', 'ltr'),
('LA', 'LA', 'LAO', 'Laos', 'asia', 'southeastern_asia', 7300000, 2, 'lo', ARRAY[]::text[], 'metric', 'LAK', true, 'lao', 'ltr'),
('LB', 'LB', 'LBN', 'Lebanon', 'asia', 'western_asia', 6800000, 2, 'ar', ARRAY[]::text[], 'metric', 'LBP', true, 'arabic', 'rtl'),
('KG', 'KG', 'KGZ', 'Kyrgyzstan', 'asia', 'central_asia', 6500000, 2, 'ky', ARRAY[]::text[], 'metric', 'KGS', true, 'cyrillic', 'ltr'),
('TM', 'TM', 'TKM', 'Turkmenistan', 'asia', 'central_asia', 6000000, 2, 'tk', ARRAY[]::text[], 'metric', 'TMT', true, 'cyrillic', 'ltr'),
('OM', 'OM', 'OMN', 'Oman', 'asia', 'western_asia', 5100000, 2, 'ar', ARRAY[]::text[], 'metric', 'OMR', true, 'arabic', 'rtl'),
('KW', 'KW', 'KWT', 'Kuwait', 'asia', 'western_asia', 4300000, 2, 'ar', ARRAY[]::text[], 'metric', 'KWD', true, 'arabic', 'rtl'),
('GE', 'GE', 'GEO', 'Georgia', 'asia', 'western_asia', 3700000, 2, 'ka', ARRAY[]::text[], 'metric', 'GEL', true, 'georgian', 'ltr'),
('MN', 'MN', 'MNG', 'Mongolia', 'asia', 'eastern_asia', 3300000, 2, 'mn', ARRAY[]::text[], 'metric', 'MNT', true, 'cyrillic', 'ltr'),
('AM', 'AM', 'ARM', 'Armenia', 'asia', 'western_asia', 3000000, 2, 'hy', ARRAY[]::text[], 'metric', 'AMD', true, 'armenian', 'ltr'),
('QA', 'QA', 'QAT', 'Qatar', 'asia', 'western_asia', 2900000, 2, 'ar', ARRAY[]::text[], 'metric', 'QAR', true, 'arabic', 'rtl'),
('BH', 'BH', 'BHR', 'Bahrain', 'asia', 'western_asia', 1700000, 2, 'ar', ARRAY[]::text[], 'metric', 'BHD', true, 'arabic', 'rtl'),
('TL', 'TL', 'TLS', 'Timor-Leste', 'asia', 'southeastern_asia', 1300000, 2, 'pt', ARRAY['tet'], 'metric', 'USD', true, 'latin', 'ltr'),
('BT', 'BT', 'BTN', 'Bhutan', 'asia', 'southern_asia', 770000, 2, 'dz', ARRAY[]::text[], 'metric', 'BTN', true, 'tibetan', 'ltr'),
('MV', 'MV', 'MDV', 'Maldives', 'asia', 'southern_asia', 540000, 2, 'dv', ARRAY[]::text[], 'metric', 'MVR', true, 'thaana', 'rtl'),
('BN', 'BN', 'BRN', 'Brunei', 'asia', 'southeastern_asia', 430000, 2, 'ms', ARRAY[]::text[], 'metric', 'BND', true, 'latin', 'ltr');

-- Add summary comment
COMMENT ON TABLE countries IS 'All 195 UN member states - Tier 1: 60 major markets, Tier 2: 70 medium markets, Tier 3: 65 smaller markets';
