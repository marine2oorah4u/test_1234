/*
  # Web API Tracking System
  
  Complete system for managing 240+ web APIs with rate limiting, caching, and usage tracking.
*/

CREATE TABLE IF NOT EXISTS web_api_services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  provider text NOT NULL,
  category text NOT NULL,
  tier integer NOT NULL DEFAULT 1,
  base_url text,
  documentation_url text,
  signup_url text,
  free_tier_limit integer,
  free_tier_rate_limit text,
  paid_tier_cost numeric(10,2),
  cost_per_request numeric(10,6),
  capabilities jsonb DEFAULT '[]'::jsonb,
  status text DEFAULT 'pending',
  is_free boolean DEFAULT true,
  setup_time_minutes integer,
  priority_rank integer DEFAULT 50,
  notes text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS web_api_keys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_id uuid REFERENCES web_api_services(id) ON DELETE CASCADE,
  key_name text NOT NULL,
  api_key text NOT NULL,
  environment text DEFAULT 'production',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  UNIQUE(service_id, environment)
);

CREATE TABLE IF NOT EXISTS web_api_usage (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_id uuid REFERENCES web_api_services(id) ON DELETE CASCADE,
  usage_date date NOT NULL DEFAULT CURRENT_DATE,
  usage_month text NOT NULL DEFAULT to_char(now(), 'YYYY-MM'),
  requests_count integer DEFAULT 0,
  successful_requests integer DEFAULT 0,
  failed_requests integer DEFAULT 0,
  estimated_cost numeric(10,4) DEFAULT 0.00,
  updated_at timestamptz DEFAULT now(),
  UNIQUE(service_id, usage_date)
);

CREATE TABLE IF NOT EXISTS web_api_cache (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_id uuid REFERENCES web_api_services(id) ON DELETE CASCADE,
  query_hash text NOT NULL,
  query_text text NOT NULL,
  response_data jsonb NOT NULL,
  cache_key text NOT NULL UNIQUE,
  expires_at timestamptz NOT NULL,
  hit_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS web_api_query_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_id uuid REFERENCES web_api_services(id) ON DELETE CASCADE,
  book_id uuid REFERENCES books(id) ON DELETE SET NULL,
  query_text text NOT NULL,
  query_type text,
  response_time_ms integer,
  results_count integer,
  success boolean DEFAULT true,
  error_message text,
  created_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES auth.users(id)
);

ALTER TABLE web_api_services ENABLE ROW LEVEL SECURITY;
ALTER TABLE web_api_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE web_api_usage ENABLE ROW LEVEL SECURITY;
ALTER TABLE web_api_cache ENABLE ROW LEVEL SECURITY;
ALTER TABLE web_api_query_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view services" ON web_api_services FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins manage services" ON web_api_services FOR ALL TO authenticated USING (EXISTS (SELECT 1 FROM user_roles WHERE user_roles.user_id = auth.uid() AND user_roles.role = 'admin')) WITH CHECK (EXISTS (SELECT 1 FROM user_roles WHERE user_roles.user_id = auth.uid() AND user_roles.role = 'admin'));

CREATE POLICY "Admins manage keys" ON web_api_keys FOR ALL TO authenticated USING (EXISTS (SELECT 1 FROM user_roles WHERE user_roles.user_id = auth.uid() AND user_roles.role = 'admin')) WITH CHECK (EXISTS (SELECT 1 FROM user_roles WHERE user_roles.user_id = auth.uid() AND user_roles.role = 'admin'));

CREATE POLICY "Users view usage" ON web_api_usage FOR SELECT TO authenticated USING (true);
CREATE POLICY "Users insert usage" ON web_api_usage FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Users update usage" ON web_api_usage FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "Users read cache" ON web_api_cache FOR SELECT TO authenticated USING (true);
CREATE POLICY "Users write cache" ON web_api_cache FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Users update cache" ON web_api_cache FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Users delete cache" ON web_api_cache FOR DELETE TO authenticated USING (expires_at < now());

CREATE POLICY "Users view logs" ON web_api_query_logs FOR SELECT TO authenticated USING (created_by = auth.uid() OR EXISTS (SELECT 1 FROM user_roles WHERE user_roles.user_id = auth.uid() AND user_roles.role = 'admin'));
CREATE POLICY "Users create logs" ON web_api_query_logs FOR INSERT TO authenticated WITH CHECK (true);

CREATE INDEX idx_web_api_services_category ON web_api_services(category);
CREATE INDEX idx_web_api_services_status ON web_api_services(status);
CREATE INDEX idx_web_api_usage_service ON web_api_usage(service_id);
CREATE INDEX idx_web_api_usage_date ON web_api_usage(usage_date DESC);
CREATE INDEX idx_web_api_cache_key ON web_api_cache(cache_key);
CREATE INDEX idx_web_api_query_logs_service ON web_api_query_logs(service_id);

INSERT INTO web_api_services (name, provider, category, tier, signup_url, free_tier_limit, paid_tier_cost, capabilities, status, setup_time_minutes, priority_rank, notes) VALUES
  ('Tavily AI Search', 'Tavily', 'search', 1, 'https://tavily.com', 1000, 40.00, '["web_search", "ai_optimized"]', 'pending', 1, 95, 'Best for AI research'),
  ('Brave Search API', 'Brave', 'search', 1, 'https://brave.com/search/api', 2000, 100.00, '["web_search", "privacy"]', 'pending', 1, 90, 'Independent index'),
  ('Serper (Google)', 'Serper', 'search', 1, 'https://serper.dev', 2500, 50.00, '["web_search"]', 'pending', 1, 85, 'Google proxy'),
  ('Semantic Scholar', 'Allen Institute', 'academic', 1, 'https://www.semanticscholar.org/product/api', NULL, 0.00, '["academic"]', 'pending', 2, 100, '200M+ papers'),
  ('PubMed API', 'NIH', 'academic', 1, 'https://www.ncbi.nlm.nih.gov/account', NULL, 0.00, '["academic", "medical"]', 'pending', 2, 100, 'Medical research'),
  ('arXiv API', 'Cornell', 'academic', 1, NULL, NULL, 0.00, '["academic", "physics"]', 'pending', 2, 100, 'Science papers'),
  ('Wikipedia API', 'Wikimedia', 'knowledge', 1, NULL, NULL, 0.00, '["encyclopedia"]', 'pending', 1, 95, 'Encyclopedia'),
  ('Wikidata API', 'Wikimedia', 'knowledge', 1, NULL, NULL, 0.00, '["structured_data"]', 'pending', 1, 90, 'Structured data')
ON CONFLICT (name) DO NOTHING;
