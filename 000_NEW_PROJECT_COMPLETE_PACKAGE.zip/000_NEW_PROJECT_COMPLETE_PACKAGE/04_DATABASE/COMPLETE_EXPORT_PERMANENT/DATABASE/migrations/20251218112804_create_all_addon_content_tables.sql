/*
  # Create All 8 Core Addon Content Tables

  1. New Tables
    - `addon_activities` - Activity Pack content (100-150 activities per topic)
    - `addon_worksheets` - Worksheet Set content (200-300 worksheets per topic)
    - `addon_quizzes` - Quiz Pack content (1,100-1,400 questions per topic)
    - `quiz_attempts` - Student quiz attempt tracking
    - `addon_answer_keys` - Answer Key content (1,400-1,850 solutions per topic)
    - `addon_lesson_plans` - Lesson Plans (111 plans per topic)
    - `lesson_plan_usage` - Teacher lesson plan usage tracking
    - `addon_presentation_slides` - Presentation Slides (2,060-3,200 slides per topic)
    - `addon_career_guides` - Career Guides (30-50 profiles per topic)
    - `addon_study_guides` - Study Guides (80-120 pages per topic)
    - `study_guide_usage` - Student study guide usage tracking

  2. Security
    - Enable RLS on all tables
    - Authenticated users can view
    - Admins can manage
    - Students can track their own usage
    - Teachers can track their own usage

  3. Important Notes
    - All tables include AI consensus scores from 5-phase generation
    - All tables include quality scores and verification details
    - All tables support multiple file formats
    - All tables include usage tracking and analytics
*/

-- =============================================================================
-- 1. ADDON ACTIVITIES (Activity Pack)
-- =============================================================================

CREATE TABLE IF NOT EXISTS addon_activities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id UUID REFERENCES books(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  activity_type TEXT CHECK (activity_type IN (
    'hands_on_project', 'experiment', 'simulation', 'field_trip',
    'role_play', 'debate', 'creative_arts', 'physical', 'group_challenge'
  )),
  learning_objective TEXT NOT NULL,
  age_range TEXT NOT NULL,
  time_required INTEGER NOT NULL,
  difficulty_level TEXT CHECK (difficulty_level IN ('easy', 'medium', 'hard')),
  materials_needed JSONB NOT NULL,
  safety_guidelines TEXT[],
  setup_instructions TEXT NOT NULL,
  step_by_step_procedure JSONB NOT NULL,
  expected_outcomes TEXT[],
  discussion_questions TEXT[],
  extension_activities JSONB,
  simplification_options JSONB,
  connections_to_content TEXT[],
  assessment_rubric JSONB NOT NULL,
  success_indicators TEXT[],
  research_consensus_score NUMERIC(4,2),
  generation_consensus_score NUMERIC(4,2),
  verification_consensus_score NUMERIC(4,2),
  refinement_consensus_score NUMERIC(4,2),
  polish_consensus_score NUMERIC(4,2),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  generated_by TEXT,
  quality_score NUMERIC(4,2),
  verification_details JSONB,
  pdf_url TEXT,
  html_url TEXT,
  docx_url TEXT,
  tags TEXT[],
  standards_aligned TEXT[],
  chapter_number INTEGER,
  section_number INTEGER,
  downloads INTEGER DEFAULT 0,
  times_completed INTEGER DEFAULT 0,
  teacher_rating NUMERIC(3,2),
  student_rating NUMERIC(3,2)
);

-- =============================================================================
-- 2. ADDON WORKSHEETS (Worksheet Set)
-- =============================================================================

CREATE TABLE IF NOT EXISTS addon_worksheets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id UUID REFERENCES books(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  worksheet_type TEXT CHECK (worksheet_type IN (
    'fill_in_blank', 'multiple_choice', 'matching', 'short_answer',
    'essay', 'diagram_labeling', 'concept_mapping', 'word_problems',
    'critical_thinking', 'research'
  )),
  learning_objective TEXT NOT NULL,
  time_estimate INTEGER,
  difficulty_level TEXT CHECK (difficulty_level IN ('easy', 'medium', 'hard', 'expert', 'challenge')),
  instructions TEXT NOT NULL,
  questions JSONB NOT NULL,
  total_points INTEGER NOT NULL,
  skills_practiced TEXT[],
  answer_key JSONB NOT NULL,
  grading_rubric JSONB,
  research_consensus_score NUMERIC(4,2),
  generation_consensus_score NUMERIC(4,2),
  verification_consensus_score NUMERIC(4,2),
  refinement_consensus_score NUMERIC(4,2),
  polish_consensus_score NUMERIC(4,2),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  generated_by TEXT,
  quality_score NUMERIC(4,2),
  verification_details JSONB,
  pdf_url TEXT,
  html_url TEXT,
  docx_url TEXT,
  latex_url TEXT,
  tags TEXT[],
  standards_aligned TEXT[],
  chapter_number INTEGER,
  section_number INTEGER,
  downloads INTEGER DEFAULT 0,
  times_completed INTEGER DEFAULT 0,
  average_score NUMERIC(4,2),
  teacher_rating NUMERIC(3,2)
);

-- =============================================================================
-- 3. ADDON QUIZZES (Quiz Pack)
-- =============================================================================

CREATE TABLE IF NOT EXISTS addon_quizzes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id UUID REFERENCES books(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  quiz_type TEXT CHECK (quiz_type IN (
    'quick_check', 'section_quiz', 'chapter_test',
    'unit_exam', 'comprehensive_final', 'pre_assessment', 'post_assessment'
  )),
  learning_objectives TEXT[] NOT NULL,
  time_limit INTEGER,
  total_points INTEGER NOT NULL,
  instructions TEXT NOT NULL,
  questions JSONB NOT NULL,
  difficulty_distribution JSONB,
  blooms_distribution JSONB,
  answer_key JSONB NOT NULL,
  grading_rubric JSONB,
  passing_score INTEGER,
  mastery_score INTEGER,
  research_consensus_score NUMERIC(4,2),
  generation_consensus_score NUMERIC(4,2),
  verification_consensus_score NUMERIC(4,2),
  refinement_consensus_score NUMERIC(4,2),
  polish_consensus_score NUMERIC(4,2),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  generated_by TEXT,
  quality_score NUMERIC(4,2),
  verification_details JSONB,
  pdf_url TEXT,
  html_url TEXT,
  json_url TEXT,
  scantron_url TEXT,
  qti_url TEXT,
  tags TEXT[],
  standards_aligned TEXT[],
  chapter_coverage INTEGER[],
  times_taken INTEGER DEFAULT 0,
  average_score NUMERIC(4,2),
  average_time INTEGER,
  question_analytics JSONB,
  reliability_coefficient NUMERIC(3,2)
);

CREATE TABLE IF NOT EXISTS quiz_attempts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  quiz_id UUID REFERENCES addon_quizzes(id) ON DELETE CASCADE,
  student_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  started_at TIMESTAMPTZ DEFAULT NOW(),
  completed_at TIMESTAMPTZ,
  time_taken INTEGER,
  score NUMERIC(5,2),
  percentage NUMERIC(5,2),
  passed BOOLEAN,
  mastered BOOLEAN,
  answers JSONB,
  feedback JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =============================================================================
-- 4. ADDON ANSWER KEYS (Answer Key)
-- =============================================================================

CREATE TABLE IF NOT EXISTS addon_answer_keys (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id UUID REFERENCES books(id) ON DELETE CASCADE,
  content_type TEXT CHECK (content_type IN ('worksheet', 'quiz', 'activity', 'textbook_problem')),
  content_id UUID NOT NULL,
  question_number INTEGER,
  correct_answer TEXT NOT NULL,
  answer_type TEXT CHECK (answer_type IN (
    'multiple_choice', 'true_false', 'fill_blank', 'short_answer',
    'essay', 'calculation', 'explanation', 'diagram'
  )),
  solution_steps JSONB NOT NULL,
  alternative_methods JSONB,
  key_concepts TEXT[],
  common_mistakes JSONB NOT NULL,
  teaching_tips TEXT[] NOT NULL,
  prerequisite_knowledge TEXT[],
  partial_credit_rules JSONB,
  scoring_rubric JSONB,
  exemplar_responses TEXT[],
  research_consensus_score NUMERIC(4,2),
  generation_consensus_score NUMERIC(4,2),
  verification_consensus_score NUMERIC(4,2),
  refinement_consensus_score NUMERIC(4,2),
  polish_consensus_score NUMERIC(4,2),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  generated_by TEXT,
  quality_score NUMERIC(4,2),
  verification_details JSONB,
  accuracy_verified BOOLEAN DEFAULT false,
  pedagogy_verified BOOLEAN DEFAULT false,
  completeness_verified BOOLEAN DEFAULT false,
  pdf_url TEXT,
  html_url TEXT,
  docx_url TEXT,
  tags TEXT[],
  difficulty_level TEXT,
  chapter_number INTEGER,
  section_number INTEGER
);

-- =============================================================================
-- 5. ADDON LESSON PLANS (Lesson Plans)
-- =============================================================================

CREATE TABLE IF NOT EXISTS addon_lesson_plans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id UUID REFERENCES books(id) ON DELETE CASCADE,
  plan_type TEXT CHECK (plan_type IN ('section', 'chapter', 'unit', 'pacing_guide')),
  title TEXT NOT NULL,
  grade_level TEXT NOT NULL,
  subject TEXT NOT NULL,
  total_time INTEGER,
  time_breakdown JSONB,
  learning_objectives JSONB NOT NULL,
  standards_aligned TEXT[] NOT NULL,
  success_criteria TEXT[],
  student_friendly_objectives TEXT[],
  prerequisite_knowledge TEXT[],
  prerequisite_check_activities JSONB,
  remediation_resources TEXT[],
  materials_needed JSONB NOT NULL,
  technology_requirements JSONB,
  handouts_needed TEXT[],
  warm_up JSONB NOT NULL,
  hook JSONB NOT NULL,
  direct_instruction JSONB NOT NULL,
  guided_practice JSONB NOT NULL,
  independent_practice JSONB NOT NULL,
  closure JSONB NOT NULL,
  struggling_learners JSONB NOT NULL,
  advanced_learners JSONB NOT NULL,
  ell_students JSONB NOT NULL,
  special_education JSONB NOT NULL,
  gifted_talented JSONB NOT NULL,
  formative_assessment JSONB NOT NULL,
  summative_assessment JSONB NOT NULL,
  assessment_rubrics JSONB,
  technology_integration JSONB,
  homework_assignments JSONB,
  extension_activities JSONB,
  common_misconceptions TEXT[],
  teaching_tips TEXT[],
  parent_communication TEXT,
  cross_curricular_connections TEXT[],
  real_world_applications TEXT[],
  career_connections TEXT[],
  discussion_questions TEXT[],
  research_consensus_score NUMERIC(4,2),
  generation_consensus_score NUMERIC(4,2),
  verification_consensus_score NUMERIC(4,2),
  refinement_consensus_score NUMERIC(4,2),
  polish_consensus_score NUMERIC(4,2),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  generated_by TEXT,
  quality_score NUMERIC(4,2),
  verification_details JSONB,
  pdf_url TEXT,
  docx_url TEXT,
  html_url TEXT,
  google_docs_url TEXT,
  lms_package_url TEXT,
  tags TEXT[],
  chapter_number INTEGER,
  section_number INTEGER,
  unit_number INTEGER,
  downloads INTEGER DEFAULT 0,
  teacher_rating NUMERIC(3,2),
  times_used INTEGER DEFAULT 0,
  feedback_count INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS lesson_plan_usage (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lesson_plan_id UUID REFERENCES addon_lesson_plans(id) ON DELETE CASCADE,
  teacher_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  used_date DATE NOT NULL,
  customizations_made TEXT,
  effectiveness_rating INTEGER CHECK (effectiveness_rating BETWEEN 1 AND 5),
  student_engagement_rating INTEGER CHECK (student_engagement_rating BETWEEN 1 AND 5),
  time_adjustment INTEGER,
  notes TEXT,
  would_use_again BOOLEAN,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =============================================================================
-- 6. ADDON PRESENTATION SLIDES (Presentation Slides)
-- =============================================================================

CREATE TABLE IF NOT EXISTS addon_presentation_slides (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id UUID REFERENCES books(id) ON DELETE CASCADE,
  deck_type TEXT CHECK (deck_type IN ('section', 'chapter', 'quick_review', 'comprehensive')),
  title TEXT NOT NULL,
  subtitle TEXT,
  chapter_number INTEGER,
  section_number INTEGER,
  total_slides INTEGER NOT NULL,
  estimated_duration INTEGER,
  slides JSONB NOT NULL,
  speaker_notes JSONB NOT NULL,
  learning_objectives TEXT[],
  key_concepts TEXT[],
  themes_available TEXT[] DEFAULT ARRAY['professional', 'colorful', 'minimal', 'dark', 'high_contrast'],
  primary_colors JSONB,
  font_family TEXT,
  template_style TEXT,
  discussion_prompts JSONB,
  practice_activities JSONB,
  assessment_slides INTEGER[],
  video_links JSONB,
  alt_text_complete BOOLEAN DEFAULT false,
  contrast_ratio NUMERIC(3,1),
  screen_reader_tested BOOLEAN DEFAULT false,
  captions_included BOOLEAN DEFAULT false,
  research_consensus_score NUMERIC(4,2),
  generation_consensus_score NUMERIC(4,2),
  verification_consensus_score NUMERIC(4,2),
  refinement_consensus_score NUMERIC(4,2),
  polish_consensus_score NUMERIC(4,2),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  generated_by TEXT,
  quality_score NUMERIC(4,2),
  verification_details JSONB,
  pptx_url TEXT,
  google_slides_url TEXT,
  pdf_url TEXT,
  keynote_url TEXT,
  html5_url TEXT,
  video_url TEXT,
  tags TEXT[],
  standards_aligned TEXT[],
  downloads INTEGER DEFAULT 0,
  presentations_given INTEGER DEFAULT 0,
  teacher_rating NUMERIC(3,2),
  effectiveness_rating NUMERIC(3,2)
);

-- =============================================================================
-- 7. ADDON CAREER GUIDES (Career Guide)
-- =============================================================================

CREATE TABLE IF NOT EXISTS addon_career_guides (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id UUID REFERENCES books(id) ON DELETE CASCADE,
  career_title TEXT NOT NULL,
  onet_code TEXT,
  industry_sector TEXT,
  description TEXT NOT NULL,
  day_in_life TEXT NOT NULL,
  work_environment TEXT NOT NULL,
  education_requirements JSONB NOT NULL,
  technical_skills JSONB NOT NULL,
  soft_skills JSONB NOT NULL,
  certifications_required TEXT[],
  salary_data JSONB NOT NULL,
  job_outlook JSONB NOT NULL,
  growth_projections TEXT,
  education_pathways JSONB NOT NULL,
  career_progression TEXT[],
  advancement_opportunities TEXT[],
  typical_employers TEXT[],
  related_careers TEXT[],
  professional_organizations TEXT[],
  continuing_education TEXT[],
  success_stories JSONB,
  role_models TEXT[],
  interview_tips TEXT[],
  resume_tips TEXT[],
  portfolio_examples TEXT[],
  networking_advice TEXT[],
  research_consensus_score NUMERIC(4,2),
  generation_consensus_score NUMERIC(4,2),
  verification_consensus_score NUMERIC(4,2),
  refinement_consensus_score NUMERIC(4,2),
  polish_consensus_score NUMERIC(4,2),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  generated_by TEXT,
  quality_score NUMERIC(4,2),
  verification_details JSONB,
  last_verified_date DATE,
  next_update_due DATE,
  pdf_url TEXT,
  html_url TEXT,
  docx_url TEXT,
  infographic_url TEXT,
  tags TEXT[],
  subject_connections TEXT[],
  downloads INTEGER DEFAULT 0,
  views INTEGER DEFAULT 0,
  student_rating NUMERIC(3,2),
  helpfulness_rating NUMERIC(3,2)
);

-- =============================================================================
-- 8. ADDON STUDY GUIDES (Study Guide)
-- =============================================================================

CREATE TABLE IF NOT EXISTS addon_study_guides (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id UUID REFERENCES books(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  total_pages INTEGER,
  chapter_summaries JSONB NOT NULL,
  section_summaries JSONB NOT NULL,
  key_terms_glossary JSONB NOT NULL,
  concept_maps JSONB NOT NULL,
  memory_aids JSONB NOT NULL,
  formula_sheets JSONB,
  quick_reference_charts JSONB,
  self_check_questions JSONB NOT NULL,
  practice_problems JSONB NOT NULL,
  answer_key JSONB NOT NULL,
  study_strategies JSONB NOT NULL,
  time_management_tips TEXT[],
  test_taking_tips TEXT[],
  self_assessment_tools JSONB NOT NULL,
  progress_tracking JSONB,
  mastery_checklists JSONB,
  exam_prep_timeline JSONB,
  common_exam_topics TEXT[],
  high_yield_concepts TEXT[],
  research_consensus_score NUMERIC(4,2),
  generation_consensus_score NUMERIC(4,2),
  verification_consensus_score NUMERIC(4,2),
  refinement_consensus_score NUMERIC(4,2),
  polish_consensus_score NUMERIC(4,2),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  generated_by TEXT,
  quality_score NUMERIC(4,2),
  verification_details JSONB,
  pdf_url TEXT,
  html_url TEXT,
  epub_url TEXT,
  docx_url TEXT,
  flashcard_anki_url TEXT,
  flashcard_quizlet_url TEXT,
  tags TEXT[],
  difficulty_level TEXT,
  downloads INTEGER DEFAULT 0,
  times_accessed INTEGER DEFAULT 0,
  student_rating NUMERIC(3,2),
  effectiveness_rating NUMERIC(3,2)
);

CREATE TABLE IF NOT EXISTS study_guide_usage (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  study_guide_id UUID REFERENCES addon_study_guides(id) ON DELETE CASCADE,
  student_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  sections_completed TEXT[],
  time_spent INTEGER,
  self_check_scores JSONB,
  practice_scores JSONB,
  effectiveness_rating INTEGER CHECK (effectiveness_rating BETWEEN 1 AND 5),
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =============================================================================
-- INDEXES FOR PERFORMANCE
-- =============================================================================

CREATE INDEX IF NOT EXISTS idx_activities_book_id ON addon_activities(book_id);
CREATE INDEX IF NOT EXISTS idx_activities_type ON addon_activities(activity_type);
CREATE INDEX IF NOT EXISTS idx_activities_quality ON addon_activities(quality_score);
CREATE INDEX IF NOT EXISTS idx_activities_chapter ON addon_activities(chapter_number, section_number);
CREATE INDEX IF NOT EXISTS idx_activities_tags ON addon_activities USING GIN(tags);

CREATE INDEX IF NOT EXISTS idx_worksheets_book_id ON addon_worksheets(book_id);
CREATE INDEX IF NOT EXISTS idx_worksheets_type ON addon_worksheets(worksheet_type);
CREATE INDEX IF NOT EXISTS idx_worksheets_difficulty ON addon_worksheets(difficulty_level);
CREATE INDEX IF NOT EXISTS idx_worksheets_quality ON addon_worksheets(quality_score);
CREATE INDEX IF NOT EXISTS idx_worksheets_tags ON addon_worksheets USING GIN(tags);

CREATE INDEX IF NOT EXISTS idx_quizzes_book_id ON addon_quizzes(book_id);
CREATE INDEX IF NOT EXISTS idx_quizzes_type ON addon_quizzes(quiz_type);
CREATE INDEX IF NOT EXISTS idx_quizzes_quality ON addon_quizzes(quality_score);
CREATE INDEX IF NOT EXISTS idx_quizzes_tags ON addon_quizzes USING GIN(tags);
CREATE INDEX IF NOT EXISTS idx_quizzes_standards ON addon_quizzes USING GIN(standards_aligned);

CREATE INDEX IF NOT EXISTS idx_attempts_quiz_id ON quiz_attempts(quiz_id);
CREATE INDEX IF NOT EXISTS idx_attempts_student_id ON quiz_attempts(student_id);
CREATE INDEX IF NOT EXISTS idx_attempts_score ON quiz_attempts(score);

CREATE INDEX IF NOT EXISTS idx_answer_keys_book_id ON addon_answer_keys(book_id);
CREATE INDEX IF NOT EXISTS idx_answer_keys_content ON addon_answer_keys(content_type, content_id);
CREATE INDEX IF NOT EXISTS idx_answer_keys_quality ON addon_answer_keys(quality_score);
CREATE INDEX IF NOT EXISTS idx_answer_keys_chapter ON addon_answer_keys(chapter_number, section_number);

CREATE INDEX IF NOT EXISTS idx_lesson_plans_book_id ON addon_lesson_plans(book_id);
CREATE INDEX IF NOT EXISTS idx_lesson_plans_type ON addon_lesson_plans(plan_type);
CREATE INDEX IF NOT EXISTS idx_lesson_plans_quality ON addon_lesson_plans(quality_score);
CREATE INDEX IF NOT EXISTS idx_lesson_plans_chapter ON addon_lesson_plans(chapter_number, section_number);
CREATE INDEX IF NOT EXISTS idx_lesson_plans_tags ON addon_lesson_plans USING GIN(tags);
CREATE INDEX IF NOT EXISTS idx_lesson_plans_standards ON addon_lesson_plans USING GIN(standards_aligned);

CREATE INDEX IF NOT EXISTS idx_usage_lesson_plan_id ON lesson_plan_usage(lesson_plan_id);
CREATE INDEX IF NOT EXISTS idx_usage_teacher_id ON lesson_plan_usage(teacher_id);

CREATE INDEX IF NOT EXISTS idx_slides_book_id ON addon_presentation_slides(book_id);
CREATE INDEX IF NOT EXISTS idx_slides_type ON addon_presentation_slides(deck_type);
CREATE INDEX IF NOT EXISTS idx_slides_chapter ON addon_presentation_slides(chapter_number, section_number);
CREATE INDEX IF NOT EXISTS idx_slides_quality ON addon_presentation_slides(quality_score);
CREATE INDEX IF NOT EXISTS idx_slides_tags ON addon_presentation_slides USING GIN(tags);

CREATE INDEX IF NOT EXISTS idx_career_guides_book_id ON addon_career_guides(book_id);
CREATE INDEX IF NOT EXISTS idx_career_guides_sector ON addon_career_guides(industry_sector);
CREATE INDEX IF NOT EXISTS idx_career_guides_quality ON addon_career_guides(quality_score);
CREATE INDEX IF NOT EXISTS idx_career_guides_tags ON addon_career_guides USING GIN(tags);

CREATE INDEX IF NOT EXISTS idx_study_guides_book_id ON addon_study_guides(book_id);
CREATE INDEX IF NOT EXISTS idx_study_guides_quality ON addon_study_guides(quality_score);
CREATE INDEX IF NOT EXISTS idx_study_guides_difficulty ON addon_study_guides(difficulty_level);

CREATE INDEX IF NOT EXISTS idx_study_usage_guide_id ON study_guide_usage(study_guide_id);
CREATE INDEX IF NOT EXISTS idx_study_usage_student_id ON study_guide_usage(student_id);

-- =============================================================================
-- ROW LEVEL SECURITY POLICIES
-- =============================================================================

ALTER TABLE addon_activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE addon_worksheets ENABLE ROW LEVEL SECURITY;
ALTER TABLE addon_quizzes ENABLE ROW LEVEL SECURITY;
ALTER TABLE quiz_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE addon_answer_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE addon_lesson_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE lesson_plan_usage ENABLE ROW LEVEL SECURITY;
ALTER TABLE addon_presentation_slides ENABLE ROW LEVEL SECURITY;
ALTER TABLE addon_career_guides ENABLE ROW LEVEL SECURITY;
ALTER TABLE addon_study_guides ENABLE ROW LEVEL SECURITY;
ALTER TABLE study_guide_usage ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Activities viewable by authenticated users"
  ON addon_activities FOR SELECT TO authenticated USING (true);

CREATE POLICY "Activities manageable by admins"
  ON addon_activities FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM user_roles WHERE user_roles.user_id = auth.uid() AND user_roles.role IN ('admin', 'super_admin')));

CREATE POLICY "Worksheets viewable by authenticated users"
  ON addon_worksheets FOR SELECT TO authenticated USING (true);

CREATE POLICY "Worksheets manageable by admins"
  ON addon_worksheets FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM user_roles WHERE user_roles.user_id = auth.uid() AND user_roles.role IN ('admin', 'super_admin')));

CREATE POLICY "Quizzes viewable by authenticated users"
  ON addon_quizzes FOR SELECT TO authenticated USING (true);

CREATE POLICY "Quizzes manageable by admins"
  ON addon_quizzes FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM user_roles WHERE user_roles.user_id = auth.uid() AND user_roles.role IN ('admin', 'super_admin')));

CREATE POLICY "Students can view own attempts"
  ON quiz_attempts FOR SELECT TO authenticated USING (auth.uid() = student_id);

CREATE POLICY "Students can create own attempts"
  ON quiz_attempts FOR INSERT TO authenticated WITH CHECK (auth.uid() = student_id);

CREATE POLICY "Teachers can view all attempts"
  ON quiz_attempts FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM user_roles WHERE user_roles.user_id = auth.uid() AND user_roles.role IN ('teacher', 'admin', 'super_admin')));

CREATE POLICY "Answer keys viewable by authenticated users"
  ON addon_answer_keys FOR SELECT TO authenticated USING (true);

CREATE POLICY "Answer keys manageable by admins"
  ON addon_answer_keys FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM user_roles WHERE user_roles.user_id = auth.uid() AND user_roles.role IN ('admin', 'super_admin')));

CREATE POLICY "Lesson plans viewable by authenticated users"
  ON addon_lesson_plans FOR SELECT TO authenticated USING (true);

CREATE POLICY "Lesson plans manageable by admins"
  ON addon_lesson_plans FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM user_roles WHERE user_roles.user_id = auth.uid() AND user_roles.role IN ('admin', 'super_admin')));

CREATE POLICY "Teachers can track own usage"
  ON lesson_plan_usage FOR ALL TO authenticated USING (auth.uid() = teacher_id);

CREATE POLICY "Slides viewable by authenticated users"
  ON addon_presentation_slides FOR SELECT TO authenticated USING (true);

CREATE POLICY "Slides manageable by admins"
  ON addon_presentation_slides FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM user_roles WHERE user_roles.user_id = auth.uid() AND user_roles.role IN ('admin', 'super_admin')));

CREATE POLICY "Career guides viewable by authenticated users"
  ON addon_career_guides FOR SELECT TO authenticated USING (true);

CREATE POLICY "Career guides manageable by admins"
  ON addon_career_guides FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM user_roles WHERE user_roles.user_id = auth.uid() AND user_roles.role IN ('admin', 'super_admin')));

CREATE POLICY "Study guides viewable by authenticated users"
  ON addon_study_guides FOR SELECT TO authenticated USING (true);

CREATE POLICY "Study guides manageable by admins"
  ON addon_study_guides FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM user_roles WHERE user_roles.user_id = auth.uid() AND user_roles.role IN ('admin', 'super_admin')));

CREATE POLICY "Students can track own study usage"
  ON study_guide_usage FOR ALL TO authenticated USING (auth.uid() = student_id);
