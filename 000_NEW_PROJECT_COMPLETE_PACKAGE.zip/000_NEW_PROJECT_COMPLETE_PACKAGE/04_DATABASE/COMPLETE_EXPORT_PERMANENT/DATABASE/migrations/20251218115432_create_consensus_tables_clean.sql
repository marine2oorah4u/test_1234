/*
  # AI Consensus Verification System

  1. New Tables
    - `ai_model_responses` - Individual AI model responses
    - `consensus_results` - Aggregated consensus results
    - `quality_scores` - Quality metrics
    - `model_performance` - AI model performance tracking

  2. Security
    - Enable RLS on all tables
    - Allow anon and authenticated access

  3. Indexes
    - Performance optimized queries
*/

-- AI Model Responses
CREATE TABLE ai_model_responses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  content_id UUID NOT NULL,
  content_type TEXT NOT NULL,
  verification_type TEXT NOT NULL,
  ai_model TEXT NOT NULL,
  model_tier INTEGER NOT NULL,
  prompt TEXT NOT NULL,
  prompt_tokens INTEGER,
  completion_tokens INTEGER,
  total_tokens INTEGER,
  response TEXT NOT NULL,
  response_metadata JSONB DEFAULT '{}',
  confidence_score NUMERIC(5,2),
  quality_score NUMERIC(5,2),
  passed_threshold BOOLEAN,
  issues_found TEXT[],
  suggestions TEXT[],
  response_time_ms INTEGER,
  api_cost_usd NUMERIC(10,6),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Consensus Results
CREATE TABLE consensus_results (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  content_id UUID NOT NULL,
  content_type TEXT NOT NULL,
  verification_round INTEGER DEFAULT 1,
  total_models INTEGER NOT NULL,
  models_agreed INTEGER DEFAULT 0,
  models_disagreed INTEGER DEFAULT 0,
  consensus_percentage NUMERIC(5,2),
  required_threshold NUMERIC(5,2) DEFAULT 90.0,
  threshold_met BOOLEAN DEFAULT false,
  average_quality_score NUMERIC(5,2),
  min_quality_score NUMERIC(5,2),
  max_quality_score NUMERIC(5,2),
  agreement_details JSONB DEFAULT '{}',
  disagreement_reasons TEXT[],
  model_votes JSONB DEFAULT '{}',
  final_decision TEXT,
  decision_confidence NUMERIC(5,2),
  critical_issues TEXT[],
  recommended_improvements TEXT[],
  total_api_cost_usd NUMERIC(10,6),
  total_time_ms INTEGER,
  created_at TIMESTAMPTZ DEFAULT now(),
  completed_at TIMESTAMPTZ
);

-- Quality Scores
CREATE TABLE quality_scores (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  content_id UUID NOT NULL,
  content_type TEXT NOT NULL,
  accuracy_score NUMERIC(5,2),
  completeness_score NUMERIC(5,2),
  clarity_score NUMERIC(5,2),
  age_appropriateness_score NUMERIC(5,2),
  engagement_score NUMERIC(5,2),
  safety_score NUMERIC(5,2),
  accessibility_score NUMERIC(5,2),
  overall_score NUMERIC(5,2),
  grade TEXT,
  strengths TEXT[],
  weaknesses TEXT[],
  improvement_suggestions TEXT[],
  verified_by_models TEXT[],
  verification_confidence NUMERIC(5,2),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Model Performance
CREATE TABLE model_performance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ai_model TEXT NOT NULL,
  model_tier INTEGER NOT NULL,
  total_requests INTEGER DEFAULT 0,
  successful_requests INTEGER DEFAULT 0,
  failed_requests INTEGER DEFAULT 0,
  success_rate NUMERIC(5,2),
  average_quality_score NUMERIC(5,2),
  average_confidence_score NUMERIC(5,2),
  agreement_rate NUMERIC(5,2),
  average_response_time_ms INTEGER,
  fastest_response_ms INTEGER,
  slowest_response_ms INTEGER,
  total_cost_usd NUMERIC(10,2),
  average_cost_per_request_usd NUMERIC(10,6),
  total_prompt_tokens BIGINT DEFAULT 0,
  total_completion_tokens BIGINT DEFAULT 0,
  total_tokens BIGINT DEFAULT 0,
  period_start TIMESTAMPTZ NOT NULL,
  period_end TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX idx_ai_responses_content ON ai_model_responses(content_id, content_type);
CREATE INDEX idx_ai_responses_model ON ai_model_responses(ai_model);
CREATE INDEX idx_ai_responses_created ON ai_model_responses(created_at DESC);

CREATE INDEX idx_consensus_content ON consensus_results(content_id, content_type);
CREATE INDEX idx_consensus_threshold ON consensus_results(threshold_met, final_decision);
CREATE INDEX idx_consensus_created ON consensus_results(created_at DESC);

CREATE INDEX idx_quality_content ON quality_scores(content_id, content_type);
CREATE INDEX idx_quality_overall ON quality_scores(overall_score DESC);

CREATE INDEX idx_model_performance_model ON model_performance(ai_model);
CREATE INDEX idx_model_performance_period ON model_performance(period_start, period_end);

-- Enable RLS
ALTER TABLE ai_model_responses ENABLE ROW LEVEL SECURITY;
ALTER TABLE consensus_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE quality_scores ENABLE ROW LEVEL SECURITY;
ALTER TABLE model_performance ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Allow anon read ai_model_responses" ON ai_model_responses FOR SELECT TO anon USING (true);
CREATE POLICY "Allow anon insert ai_model_responses" ON ai_model_responses FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "Allow authenticated read ai_model_responses" ON ai_model_responses FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated insert ai_model_responses" ON ai_model_responses FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Allow anon read consensus_results" ON consensus_results FOR SELECT TO anon USING (true);
CREATE POLICY "Allow anon insert consensus_results" ON consensus_results FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "Allow authenticated read consensus_results" ON consensus_results FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated insert consensus_results" ON consensus_results FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Allow anon read quality_scores" ON quality_scores FOR SELECT TO anon USING (true);
CREATE POLICY "Allow anon insert quality_scores" ON quality_scores FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "Allow authenticated read quality_scores" ON quality_scores FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated insert quality_scores" ON quality_scores FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Allow anon read model_performance" ON model_performance FOR SELECT TO anon USING (true);
CREATE POLICY "Allow anon insert model_performance" ON model_performance FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "Allow authenticated read model_performance" ON model_performance FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated insert model_performance" ON model_performance FOR INSERT TO authenticated WITH CHECK (true);
