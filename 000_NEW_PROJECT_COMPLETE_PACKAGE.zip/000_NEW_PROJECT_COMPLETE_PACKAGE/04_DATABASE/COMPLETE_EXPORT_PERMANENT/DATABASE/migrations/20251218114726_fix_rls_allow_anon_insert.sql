/*
  # Fix RLS Policies to Allow Anon Inserts

  1. Changes
    - Add INSERT policies for anon role on platform_features table
    - Add INSERT policies for anon role on addon_features table
    - Allows population script using anon key to work

  2. Security
    - Temporary policy for initial data population
    - Can be removed or restricted after population is complete
*/

-- Allow anon users to insert platform features
CREATE POLICY "Allow anon insert on platform_features"
  ON platform_features
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Allow anon users to insert addon features
CREATE POLICY "Allow anon insert on addon_features"
  ON addon_features
  FOR INSERT
  TO anon
  WITH CHECK (true);
