/*
  # Add Final Country (Namibia)

  Complete the 195 UN member states
*/

INSERT INTO countries (country_code, iso_code_2, iso_code_3, country_name, region, subregion, population, priority_tier, primary_language, additional_languages, measurement_system, currency_code, enabled, writing_system, text_direction) VALUES
('NA', 'NA', 'NAM', 'Namibia', 'africa', 'southern_africa', 2500000, 3, 'en', ARRAY['af'], 'metric', 'NAD', true, 'latin', 'ltr')
ON CONFLICT (country_code) DO NOTHING;
