/*
  # Fix RLS Policies for Feature Population

  1. Changes
    - Add INSERT policies for platform_features table
    - Add INSERT policies for addon_features table
    - Allow authenticated users to populate feature catalog

  2. Security
    - Only authenticated users can insert
    - Maintains read security
    - Allows population script to run
*/

-- Allow authenticated users to insert platform features
CREATE POLICY "Allow authenticated insert on platform_features"
  ON platform_features
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Allow authenticated users to insert addon features
CREATE POLICY "Allow authenticated insert on addon_features"
  ON addon_features
  FOR INSERT
  TO authenticated
  WITH CHECK (true);
