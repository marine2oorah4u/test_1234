/*
  # Pipeline 14: Career/Jobs/Trades Professional Training System

  ## Overview
  Complete database schema for global job catalog, career pathways, and educational content linking.

  ## New Tables
  1. `global_job_catalog` - Master catalog of 50,000+ jobs across 195 countries
  2. `educational_content_career_links` - Bidirectional educational content ↔ career mapping
  3. `career_learning_paths` - Structured career learning pathways
  4. `career_learning_path_stages` - Individual stages within pathways
  5. `job_skills_taxonomy` - Standardized skills taxonomy (10,000+ skills)
  6. `job_educational_pathways` - Subject area → career connections
  7. `career_addon_generation_queue` - Track addon generation for each career
  8. `career_guides` - Generated career guide addons (Addon Type 1)
  9. `phase_0_research_catalog` - Track Phase 0 research for 195 countries

  ## Security
  - RLS enabled on all tables
  - Public read access for job catalog and guides
  - Authenticated write access for content creation
  - Admin-only access for system management

  ## Performance
  - Strategic indexes on all common query patterns
  - Partitioning ready for country-based queries
  - Optimized for millions of career-content links
*/

-- =====================================================
-- 1. GLOBAL JOB CATALOG
-- =====================================================

CREATE TABLE IF NOT EXISTS global_job_catalog (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Classification Codes
  isco_code VARCHAR(10),
  soc_code VARCHAR(10),
  country_code VARCHAR(3) NOT NULL,
  country_specific_code VARCHAR(20),

  -- Job Information
  job_title_english TEXT NOT NULL,
  job_title_local TEXT,
  job_family VARCHAR(100),
  job_category VARCHAR(100),

  -- Educational Requirements
  minimum_education_level VARCHAR(50),
  recommended_education_level VARCHAR(50),
  alternative_pathways TEXT[],

  -- Skills and Competencies
  required_skills TEXT[],
  preferred_skills TEXT[],
  soft_skills TEXT[],
  certifications TEXT[],

  -- Experience Requirements
  entry_level_requirements TEXT,
  mid_level_requirements TEXT,
  senior_level_requirements TEXT,

  -- Market Data
  average_salary_local_currency DECIMAL(12,2),
  average_salary_usd DECIMAL(12,2),
  salary_range_low DECIMAL(12,2),
  salary_range_high DECIMAL(12,2),
  currency_code VARCHAR(3),
  job_outlook VARCHAR(50),
  demand_level VARCHAR(50),
  automation_risk_level VARCHAR(50),

  -- Working Conditions
  typical_work_environment TEXT,
  physical_demands TEXT,
  work_schedule_type VARCHAR(50),
  remote_work_potential VARCHAR(50),

  -- Career Progression
  typical_entry_jobs TEXT[],
  typical_progression_jobs TEXT[],
  career_ladder_position INTEGER,

  -- Content Linking (calculated fields)
  linked_books_count INTEGER DEFAULT 0,
  linked_lessons_count INTEGER DEFAULT 0,
  linked_activities_count INTEGER DEFAULT 0,

  -- Metadata
  data_source VARCHAR(100),
  data_last_updated TIMESTAMPTZ,
  verification_status VARCHAR(50) DEFAULT 'pending',
  quality_score INTEGER DEFAULT 0,

  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_job_catalog_country ON global_job_catalog(country_code);
CREATE INDEX IF NOT EXISTS idx_job_catalog_isco ON global_job_catalog(isco_code);
CREATE INDEX IF NOT EXISTS idx_job_catalog_soc ON global_job_catalog(soc_code);
CREATE INDEX IF NOT EXISTS idx_job_catalog_family ON global_job_catalog(job_family);
CREATE INDEX IF NOT EXISTS idx_job_catalog_category ON global_job_catalog(job_category);
CREATE INDEX IF NOT EXISTS idx_job_catalog_education ON global_job_catalog(minimum_education_level);
CREATE INDEX IF NOT EXISTS idx_job_catalog_demand ON global_job_catalog(demand_level);
CREATE INDEX IF NOT EXISTS idx_job_catalog_verification ON global_job_catalog(verification_status);

-- RLS
ALTER TABLE global_job_catalog ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Global job catalog is viewable by everyone"
  ON global_job_catalog FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can create job entries"
  ON global_job_catalog FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update job entries"
  ON global_job_catalog FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- =====================================================
-- 2. EDUCATIONAL CONTENT CAREER LINKS
-- =====================================================

CREATE TABLE IF NOT EXISTS educational_content_career_links (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Content Reference
  content_type VARCHAR(50) NOT NULL,
  content_id UUID NOT NULL,
  content_title TEXT,

  -- Career Reference
  job_id UUID REFERENCES global_job_catalog(id) ON DELETE CASCADE,

  -- Link Strength and Type
  relevance_score INTEGER CHECK (relevance_score >= 0 AND relevance_score <= 100),
  link_type VARCHAR(50),

  -- Skill Mapping
  skills_taught TEXT[],
  competencies_developed TEXT[],

  -- Learning Path Integration
  recommended_order INTEGER,
  prerequisite_content_ids UUID[],
  is_core_requirement BOOLEAN DEFAULT false,

  -- Career Stage Relevance
  relevant_for_entry_level BOOLEAN DEFAULT true,
  relevant_for_mid_level BOOLEAN DEFAULT false,
  relevant_for_senior_level BOOLEAN DEFAULT false,

  -- Metadata
  link_created_by VARCHAR(50),
  confidence_score INTEGER CHECK (confidence_score >= 0 AND confidence_score <= 100),
  verified_by_expert BOOLEAN DEFAULT false,
  verification_date TIMESTAMPTZ,

  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_career_links_content ON educational_content_career_links(content_type, content_id);
CREATE INDEX IF NOT EXISTS idx_career_links_job ON educational_content_career_links(job_id);
CREATE INDEX IF NOT EXISTS idx_career_links_relevance ON educational_content_career_links(relevance_score DESC);
CREATE INDEX IF NOT EXISTS idx_career_links_type ON educational_content_career_links(link_type);
CREATE INDEX IF NOT EXISTS idx_career_links_verified ON educational_content_career_links(verified_by_expert);

-- RLS
ALTER TABLE educational_content_career_links ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Career links are viewable by everyone"
  ON educational_content_career_links FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can create career links"
  ON educational_content_career_links FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update career links"
  ON educational_content_career_links FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- =====================================================
-- 3. CAREER LEARNING PATHS
-- =====================================================

CREATE TABLE IF NOT EXISTS career_learning_paths (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Career Reference
  job_id UUID REFERENCES global_job_catalog(id) ON DELETE CASCADE,

  -- Path Information
  path_name TEXT NOT NULL,
  path_description TEXT,
  path_type VARCHAR(50),

  -- Duration and Effort
  estimated_duration_months INTEGER,
  estimated_hours_total INTEGER,
  hours_per_week_recommended INTEGER,

  -- Prerequisites
  required_education_level VARCHAR(50),
  prerequisite_knowledge TEXT[],
  starting_skill_level VARCHAR(50),

  -- Path Structure
  total_stages INTEGER,
  current_stage_template JSONB,

  -- Success Metrics
  completion_rate DECIMAL(5,2),
  average_time_to_job DECIMAL(6,2),
  success_rate DECIMAL(5,2),

  -- Cost Estimates
  estimated_cost_low DECIMAL(10,2),
  estimated_cost_high DECIMAL(10,2),
  free_resources_available BOOLEAN DEFAULT false,

  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_learning_paths_job ON career_learning_paths(job_id);
CREATE INDEX IF NOT EXISTS idx_learning_paths_type ON career_learning_paths(path_type);

-- RLS
ALTER TABLE career_learning_paths ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Learning paths are viewable by everyone"
  ON career_learning_paths FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can create learning paths"
  ON career_learning_paths FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update learning paths"
  ON career_learning_paths FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- =====================================================
-- 4. CAREER LEARNING PATH STAGES
-- =====================================================

CREATE TABLE IF NOT EXISTS career_learning_path_stages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Path Reference
  path_id UUID REFERENCES career_learning_paths(id) ON DELETE CASCADE,

  -- Stage Details
  stage_number INTEGER NOT NULL,
  stage_name TEXT NOT NULL,
  stage_description TEXT,

  -- Content Requirements
  required_books UUID[],
  required_lessons UUID[],
  required_activities UUID[],
  required_quizzes UUID[],

  -- Learning Outcomes
  skills_acquired TEXT[],
  competencies_developed TEXT[],
  certifications_earned TEXT[],

  -- Progression
  duration_weeks INTEGER,
  minimum_completion_percentage INTEGER,
  recommended_projects TEXT[],

  -- Assessment
  assessment_type VARCHAR(50),
  passing_criteria TEXT,

  created_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_path_stages_path ON career_learning_path_stages(path_id);
CREATE INDEX IF NOT EXISTS idx_path_stages_number ON career_learning_path_stages(stage_number);

-- RLS
ALTER TABLE career_learning_path_stages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Path stages are viewable by everyone"
  ON career_learning_path_stages FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can create path stages"
  ON career_learning_path_stages FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update path stages"
  ON career_learning_path_stages FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- =====================================================
-- 5. JOB SKILLS TAXONOMY
-- =====================================================

CREATE TABLE IF NOT EXISTS job_skills_taxonomy (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Skill Classification
  skill_name TEXT NOT NULL,
  skill_category VARCHAR(50),
  skill_subcategory VARCHAR(100),

  -- Hierarchy
  parent_skill_id UUID REFERENCES job_skills_taxonomy(id),
  skill_level INTEGER,

  -- Descriptions
  skill_description TEXT,
  skill_keywords TEXT[],
  alternative_names TEXT[],

  -- Learning Resources
  typical_learning_time_hours INTEGER,
  difficulty_level VARCHAR(50),
  free_learning_available BOOLEAN DEFAULT false,

  -- Market Data
  jobs_requiring_count INTEGER DEFAULT 0,
  average_salary_premium DECIMAL(10,2),
  demand_trend VARCHAR(50),

  -- Educational Content Mapping
  teaching_books_count INTEGER DEFAULT 0,
  teaching_lessons_count INTEGER DEFAULT 0,

  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_skills_name ON job_skills_taxonomy(skill_name);
CREATE INDEX IF NOT EXISTS idx_skills_category ON job_skills_taxonomy(skill_category);
CREATE INDEX IF NOT EXISTS idx_skills_demand ON job_skills_taxonomy(demand_trend);
CREATE INDEX IF NOT EXISTS idx_skills_parent ON job_skills_taxonomy(parent_skill_id);

-- RLS
ALTER TABLE job_skills_taxonomy ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Skills taxonomy is viewable by everyone"
  ON job_skills_taxonomy FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can create skills"
  ON job_skills_taxonomy FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update skills"
  ON job_skills_taxonomy FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- =====================================================
-- 6. JOB EDUCATIONAL PATHWAYS
-- =====================================================

CREATE TABLE IF NOT EXISTS job_educational_pathways (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Subject Area
  subject_name VARCHAR(100) NOT NULL,
  subject_level VARCHAR(50),
  grade_levels INTEGER[],

  -- Career Connections
  directly_leads_to UUID[],
  indirectly_supports UUID[],
  foundational_for UUID[],

  -- Pathway Strength
  connection_strength VARCHAR(50),
  supporting_evidence TEXT,

  -- Student Guidance
  why_study_this TEXT,
  real_world_applications TEXT[],
  career_stories TEXT[],

  created_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_pathways_subject ON job_educational_pathways(subject_name);
CREATE INDEX IF NOT EXISTS idx_pathways_level ON job_educational_pathways(subject_level);

-- RLS
ALTER TABLE job_educational_pathways ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Educational pathways are viewable by everyone"
  ON job_educational_pathways FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can create pathways"
  ON job_educational_pathways FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update pathways"
  ON job_educational_pathways FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- =====================================================
-- 7. CAREER ADDON GENERATION QUEUE
-- =====================================================

CREATE TABLE IF NOT EXISTS career_addon_generation_queue (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Career Reference
  job_id UUID REFERENCES global_job_catalog(id) ON DELETE CASCADE,
  country_code VARCHAR(3),

  -- Generation Status
  generation_status VARCHAR(50) DEFAULT 'pending',
  priority_level INTEGER DEFAULT 5 CHECK (priority_level >= 1 AND priority_level <= 10),

  -- Addons to Generate (8 types)
  career_guides_status VARCHAR(50) DEFAULT 'pending',
  career_guides_id UUID,

  training_manuals_status VARCHAR(50) DEFAULT 'pending',
  training_manuals_id UUID,

  job_prep_workbooks_status VARCHAR(50) DEFAULT 'pending',
  job_prep_workbooks_id UUID,

  skill_assessments_status VARCHAR(50) DEFAULT 'pending',
  skill_assessments_id UUID,

  interview_prep_status VARCHAR(50) DEFAULT 'pending',
  interview_prep_id UUID,

  certification_guides_status VARCHAR(50) DEFAULT 'pending',
  certification_guides_id UUID,

  apprenticeship_materials_status VARCHAR(50) DEFAULT 'pending',
  apprenticeship_materials_id UUID,

  portfolio_projects_status VARCHAR(50) DEFAULT 'pending',
  portfolio_projects_id UUID,

  -- Progress Tracking
  total_addons INTEGER DEFAULT 8,
  completed_addons INTEGER DEFAULT 0,
  failed_addons INTEGER DEFAULT 0,
  completion_percentage DECIMAL(5,2) DEFAULT 0.00,

  -- Resource Usage
  ai_tokens_used INTEGER DEFAULT 0,
  generation_time_seconds INTEGER,
  cost_usd DECIMAL(10,4),

  -- Scheduling
  scheduled_generation_date TIMESTAMPTZ,
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,

  -- Error Handling
  error_message TEXT,
  retry_count INTEGER DEFAULT 0,
  max_retries INTEGER DEFAULT 3,

  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_career_queue_status ON career_addon_generation_queue(generation_status);
CREATE INDEX IF NOT EXISTS idx_career_queue_job ON career_addon_generation_queue(job_id);
CREATE INDEX IF NOT EXISTS idx_career_queue_priority ON career_addon_generation_queue(priority_level DESC);
CREATE INDEX IF NOT EXISTS idx_career_queue_country ON career_addon_generation_queue(country_code);

-- RLS
ALTER TABLE career_addon_generation_queue ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Generation queue is viewable by authenticated users"
  ON career_addon_generation_queue FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can create queue entries"
  ON career_addon_generation_queue FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update queue entries"
  ON career_addon_generation_queue FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- =====================================================
-- 8. CAREER GUIDES (Addon Type 1)
-- =====================================================

CREATE TABLE IF NOT EXISTS career_guides (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Career Reference
  job_id UUID REFERENCES global_job_catalog(id) ON DELETE CASCADE,
  country_code VARCHAR(3),
  language_code VARCHAR(3),

  -- Guide Content (50+ comprehensive aspects)
  job_overview TEXT NOT NULL,
  day_in_the_life TEXT,
  typical_tasks TEXT[],
  work_environment_description TEXT,

  -- Entry Requirements
  education_requirements_detailed TEXT,
  certification_paths TEXT[],
  skill_requirements_detailed JSONB,
  experience_levels JSONB,

  -- Career Development
  entry_level_jobs TEXT[],
  mid_level_progression TEXT[],
  senior_level_options TEXT[],
  career_timeline_infographic TEXT,

  -- Salary and Benefits
  salary_breakdown_by_level JSONB,
  benefits_overview TEXT,
  negotiation_tips TEXT,
  regional_variations JSONB,

  -- Job Search
  where_to_find_jobs TEXT[],
  networking_strategies TEXT,
  resume_tips TEXT,
  cover_letter_examples TEXT,

  -- Interview Preparation
  common_interview_questions TEXT[],
  technical_interview_prep TEXT,
  behavioral_questions TEXT[],
  what_employers_look_for TEXT,

  -- Skills Development
  core_skills_breakdown JSONB,
  how_to_learn_each_skill TEXT,
  recommended_courses TEXT[],
  recommended_books TEXT[],
  free_learning_resources TEXT[],

  -- Industry Insights
  industry_trends TEXT,
  future_outlook TEXT,
  automation_impact TEXT,
  emerging_opportunities TEXT,

  -- Success Stories
  real_career_stories TEXT[],
  quotes_from_professionals TEXT[],
  common_career_paths TEXT[],

  -- Challenges and Solutions
  common_challenges TEXT[],
  how_to_overcome_obstacles TEXT,
  work_life_balance_tips TEXT,

  -- Additional Resources
  professional_associations TEXT[],
  conferences_and_events TEXT[],
  online_communities TEXT[],
  mentorship_opportunities TEXT,

  -- Special Considerations
  diversity_inclusion_info TEXT,
  accommodations_for_disabilities TEXT,
  international_opportunities TEXT,
  remote_work_possibilities TEXT,

  -- Generation Metadata
  generated_by_phase VARCHAR(50),
  ai_models_used TEXT[],
  generation_quality_score INTEGER,
  content_length_words INTEGER,

  -- Format Versions
  pdf_url TEXT,
  epub_url TEXT,
  web_version_url TEXT,

  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_career_guides_job ON career_guides(job_id);
CREATE INDEX IF NOT EXISTS idx_career_guides_country ON career_guides(country_code);
CREATE INDEX IF NOT EXISTS idx_career_guides_language ON career_guides(language_code);

-- RLS
ALTER TABLE career_guides ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Career guides are viewable by everyone"
  ON career_guides FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can create career guides"
  ON career_guides FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update career guides"
  ON career_guides FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- =====================================================
-- 9. PHASE 0 RESEARCH CATALOG
-- =====================================================

CREATE TABLE IF NOT EXISTS phase_0_research_catalog (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Country Focus
  country_code VARCHAR(3) NOT NULL UNIQUE,
  country_name TEXT,
  research_priority INTEGER DEFAULT 5 CHECK (research_priority >= 1 AND research_priority <= 10),

  -- Research Sources
  primary_data_source TEXT,
  data_source_urls TEXT[],
  api_endpoints TEXT[],
  last_data_refresh TIMESTAMPTZ,

  -- Catalog Status
  total_jobs_identified INTEGER DEFAULT 0,
  jobs_cataloged INTEGER DEFAULT 0,
  jobs_verified INTEGER DEFAULT 0,
  catalog_completion_percentage DECIMAL(5,2) DEFAULT 0.00,

  -- Classification Mapping
  uses_isco BOOLEAN DEFAULT true,
  uses_soc BOOLEAN DEFAULT false,
  national_classification_system TEXT,
  mapping_complexity VARCHAR(50),

  -- Data Quality
  data_quality_score INTEGER CHECK (data_quality_score >= 0 AND data_quality_score <= 100),
  data_completeness_score INTEGER CHECK (data_completeness_score >= 0 AND data_completeness_score <= 100),
  verification_status VARCHAR(50) DEFAULT 'not_started',

  -- Research Progress
  research_status VARCHAR(50) DEFAULT 'not_started',
  research_started_date TIMESTAMPTZ,
  research_completed_date TIMESTAMPTZ,

  -- Team Assignment
  assigned_researcher VARCHAR(100),
  assigned_ai_model VARCHAR(50),

  -- Notes
  research_notes TEXT,
  data_challenges TEXT[],
  special_considerations TEXT[],

  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_phase0_country ON phase_0_research_catalog(country_code);
CREATE INDEX IF NOT EXISTS idx_phase0_status ON phase_0_research_catalog(research_status);
CREATE INDEX IF NOT EXISTS idx_phase0_priority ON phase_0_research_catalog(research_priority DESC);

-- RLS
ALTER TABLE phase_0_research_catalog ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Phase 0 research is viewable by authenticated users"
  ON phase_0_research_catalog FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can create research entries"
  ON phase_0_research_catalog FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update research entries"
  ON phase_0_research_catalog FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- =====================================================
-- FUNCTIONS FOR AUTOMATED UPDATES
-- =====================================================

-- Update linked content counts in job catalog
CREATE OR REPLACE FUNCTION update_job_linked_content_counts()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE global_job_catalog
  SET
    linked_books_count = (
      SELECT COUNT(*)
      FROM educational_content_career_links
      WHERE job_id = NEW.job_id AND content_type = 'book'
    ),
    linked_lessons_count = (
      SELECT COUNT(*)
      FROM educational_content_career_links
      WHERE job_id = NEW.job_id AND content_type = 'lesson'
    ),
    linked_activities_count = (
      SELECT COUNT(*)
      FROM educational_content_career_links
      WHERE job_id = NEW.job_id AND content_type = 'activity'
    ),
    updated_at = now()
  WHERE id = NEW.job_id;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_job_content_counts
  AFTER INSERT OR UPDATE OR DELETE ON educational_content_career_links
  FOR EACH ROW
  EXECUTE FUNCTION update_job_linked_content_counts();

-- Update generation queue completion percentage
CREATE OR REPLACE FUNCTION update_generation_queue_progress()
RETURNS TRIGGER AS $$
BEGIN
  NEW.completed_addons := (
    CASE WHEN NEW.career_guides_status = 'completed' THEN 1 ELSE 0 END +
    CASE WHEN NEW.training_manuals_status = 'completed' THEN 1 ELSE 0 END +
    CASE WHEN NEW.job_prep_workbooks_status = 'completed' THEN 1 ELSE 0 END +
    CASE WHEN NEW.skill_assessments_status = 'completed' THEN 1 ELSE 0 END +
    CASE WHEN NEW.interview_prep_status = 'completed' THEN 1 ELSE 0 END +
    CASE WHEN NEW.certification_guides_status = 'completed' THEN 1 ELSE 0 END +
    CASE WHEN NEW.apprenticeship_materials_status = 'completed' THEN 1 ELSE 0 END +
    CASE WHEN NEW.portfolio_projects_status = 'completed' THEN 1 ELSE 0 END
  );

  NEW.failed_addons := (
    CASE WHEN NEW.career_guides_status = 'failed' THEN 1 ELSE 0 END +
    CASE WHEN NEW.training_manuals_status = 'failed' THEN 1 ELSE 0 END +
    CASE WHEN NEW.job_prep_workbooks_status = 'failed' THEN 1 ELSE 0 END +
    CASE WHEN NEW.skill_assessments_status = 'failed' THEN 1 ELSE 0 END +
    CASE WHEN NEW.interview_prep_status = 'failed' THEN 1 ELSE 0 END +
    CASE WHEN NEW.certification_guides_status = 'failed' THEN 1 ELSE 0 END +
    CASE WHEN NEW.apprenticeship_materials_status = 'failed' THEN 1 ELSE 0 END +
    CASE WHEN NEW.portfolio_projects_status = 'failed' THEN 1 ELSE 0 END
  );

  NEW.completion_percentage := (NEW.completed_addons::DECIMAL / NEW.total_addons::DECIMAL) * 100;

  IF NEW.completion_percentage = 100 THEN
    NEW.generation_status := 'completed';
    NEW.completed_at := now();
  ELSIF NEW.completed_addons > 0 THEN
    NEW.generation_status := 'in_progress';
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_queue_progress
  BEFORE INSERT OR UPDATE ON career_addon_generation_queue
  FOR EACH ROW
  EXECUTE FUNCTION update_generation_queue_progress();
