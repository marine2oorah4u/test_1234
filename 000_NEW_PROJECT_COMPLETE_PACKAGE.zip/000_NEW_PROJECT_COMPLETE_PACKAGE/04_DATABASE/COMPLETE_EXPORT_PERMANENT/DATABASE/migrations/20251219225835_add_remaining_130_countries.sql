/*
  # Add Remaining 130 Countries (Tier 2 & 3)

  1. Complete Coverage
    - Add remaining 45 Tier 2 countries
    - Add all 65 Tier 3 countries
    - Total: 195 UN member states
    
  2. Security
    - Maintain existing RLS policies
*/

-- Add remaining Tier 2 countries (45 more)
INSERT INTO countries (country_code, iso_code_2, iso_code_3, country_name, region, subregion, population, priority_tier, primary_language, additional_languages, measurement_system, currency_code, enabled, writing_system, text_direction) VALUES

-- Africa (30)
('CD', 'CD', 'COD', 'Democratic Republic of the Congo', 'africa', 'middle_africa', 89000000, 2, 'fr', ARRAY[]::text[], 'metric', 'CDF', true, 'latin', 'ltr'),
('TZ', 'TZ', 'TZA', 'Tanzania', 'africa', 'eastern_africa', 60000000, 2, 'sw', ARRAY['en'], 'metric', 'TZS', true, 'latin', 'ltr'),
('ZA', 'ZA', 'ZAF', 'South Africa', 'africa', 'southern_africa', 59000000, 2, 'en', ARRAY['af', 'zu'], 'metric', 'ZAR', true, 'latin', 'ltr'),
('KE', 'KE', 'KEN', 'Kenya', 'africa', 'eastern_africa', 54000000, 2, 'sw', ARRAY['en'], 'metric', 'KES', true, 'latin', 'ltr'),
('UG', 'UG', 'UGA', 'Uganda', 'africa', 'eastern_africa', 46000000, 2, 'en', ARRAY[]::text[], 'metric', 'UGX', true, 'latin', 'ltr'),
('DZ', 'DZ', 'DZA', 'Algeria', 'africa', 'northern_africa', 44000000, 2, 'ar', ARRAY[]::text[], 'metric', 'DZD', true, 'arabic', 'rtl'),
('SD', 'SD', 'SDN', 'Sudan', 'africa', 'northern_africa', 43000000, 2, 'ar', ARRAY[]::text[], 'metric', 'SDG', true, 'arabic', 'rtl'),
('MA', 'MA', 'MAR', 'Morocco', 'africa', 'northern_africa', 37000000, 2, 'ar', ARRAY[]::text[], 'metric', 'MAD', true, 'arabic', 'rtl'),
('AO', 'AO', 'AGO', 'Angola', 'africa', 'middle_africa', 32000000, 2, 'pt', ARRAY[]::text[], 'metric', 'AOA', true, 'latin', 'ltr'),
('GH', 'GH', 'GHA', 'Ghana', 'africa', 'western_africa', 31000000, 2, 'en', ARRAY[]::text[], 'metric', 'GHS', true, 'latin', 'ltr'),
('MZ', 'MZ', 'MOZ', 'Mozambique', 'africa', 'eastern_africa', 31000000, 2, 'pt', ARRAY[]::text[], 'metric', 'MZN', true, 'latin', 'ltr'),
('MG', 'MG', 'MDG', 'Madagascar', 'africa', 'eastern_africa', 28000000, 2, 'mg', ARRAY['fr'], 'metric', 'MGA', true, 'latin', 'ltr'),
('CM', 'CM', 'CMR', 'Cameroon', 'africa', 'middle_africa', 26600000, 2, 'fr', ARRAY['en'], 'metric', 'XAF', true, 'latin', 'ltr'),
('CI', 'CI', 'CIV', 'Côte d''Ivoire', 'africa', 'western_africa', 26400000, 2, 'fr', ARRAY[]::text[], 'metric', 'XOF', true, 'latin', 'ltr'),
('NE', 'NE', 'NER', 'Niger', 'africa', 'western_africa', 24000000, 2, 'fr', ARRAY[]::text[], 'metric', 'XOF', true, 'latin', 'ltr'),
('BF', 'BF', 'BFA', 'Burkina Faso', 'africa', 'western_africa', 20900000, 2, 'fr', ARRAY[]::text[], 'metric', 'XOF', true, 'latin', 'ltr'),
('ML', 'ML', 'MLI', 'Mali', 'africa', 'western_africa', 20300000, 2, 'fr', ARRAY[]::text[], 'metric', 'XOF', true, 'latin', 'ltr'),
('MW', 'MW', 'MWI', 'Malawi', 'africa', 'eastern_africa', 19100000, 2, 'en', ARRAY[]::text[], 'metric', 'MWK', true, 'latin', 'ltr'),
('ZM', 'ZM', 'ZMB', 'Zambia', 'africa', 'eastern_africa', 18400000, 2, 'en', ARRAY[]::text[], 'metric', 'ZMW', true, 'latin', 'ltr'),
('SN', 'SN', 'SEN', 'Senegal', 'africa', 'western_africa', 16700000, 2, 'fr', ARRAY[]::text[], 'metric', 'XOF', true, 'latin', 'ltr'),
('TD', 'TD', 'TCD', 'Chad', 'africa', 'middle_africa', 16400000, 2, 'fr', ARRAY['ar'], 'metric', 'XAF', true, 'latin', 'ltr'),
('SO', 'SO', 'SOM', 'Somalia', 'africa', 'eastern_africa', 15900000, 2, 'so', ARRAY['ar'], 'metric', 'SOS', true, 'latin', 'ltr'),
('ZW', 'ZW', 'ZWE', 'Zimbabwe', 'africa', 'eastern_africa', 14900000, 2, 'en', ARRAY[]::text[], 'metric', 'ZWL', true, 'latin', 'ltr'),
('GN', 'GN', 'GIN', 'Guinea', 'africa', 'western_africa', 13100000, 2, 'fr', ARRAY[]::text[], 'metric', 'GNF', true, 'latin', 'ltr'),
('RW', 'RW', 'RWA', 'Rwanda', 'africa', 'eastern_africa', 12900000, 2, 'rw', ARRAY['en', 'fr'], 'metric', 'RWF', true, 'latin', 'ltr'),
('BJ', 'BJ', 'BEN', 'Benin', 'africa', 'western_africa', 12100000, 2, 'fr', ARRAY[]::text[], 'metric', 'XOF', true, 'latin', 'ltr'),
('TN', 'TN', 'TUN', 'Tunisia', 'africa', 'northern_africa', 11800000, 2, 'ar', ARRAY[]::text[], 'metric', 'TND', true, 'arabic', 'rtl'),
('BI', 'BI', 'BDI', 'Burundi', 'africa', 'eastern_africa', 11900000, 2, 'rw', ARRAY['fr'], 'metric', 'BIF', true, 'latin', 'ltr'),
('SS', 'SS', 'SSD', 'South Sudan', 'africa', 'eastern_africa', 11200000, 2, 'en', ARRAY[]::text[], 'metric', 'SSP', true, 'latin', 'ltr'),
('TG', 'TG', 'TGO', 'Togo', 'africa', 'western_africa', 8300000, 2, 'fr', ARRAY[]::text[], 'metric', 'XOF', true, 'latin', 'ltr'),

-- Europe (10)
('UA', 'UA', 'UKR', 'Ukraine', 'europe', 'eastern_europe', 44000000, 2, 'uk', ARRAY[]::text[], 'metric', 'UAH', true, 'cyrillic', 'ltr'),
('SK', 'SK', 'SVK', 'Slovakia', 'europe', 'eastern_europe', 5500000, 2, 'sk', ARRAY[]::text[], 'metric', 'EUR', true, 'latin', 'ltr'),
('IE', 'IE', 'IRL', 'Ireland', 'europe', 'northern_europe', 5000000, 2, 'en', ARRAY['ga'], 'metric', 'EUR', true, 'latin', 'ltr'),
('HR', 'HR', 'HRV', 'Croatia', 'europe', 'southern_europe', 4100000, 2, 'hr', ARRAY[]::text[], 'metric', 'EUR', true, 'latin', 'ltr'),
('BA', 'BA', 'BIH', 'Bosnia and Herzegovina', 'europe', 'southern_europe', 3300000, 2, 'bs', ARRAY['hr', 'sr'], 'metric', 'BAM', true, 'latin', 'ltr'),
('AL', 'AL', 'ALB', 'Albania', 'europe', 'southern_europe', 2900000, 2, 'sq', ARRAY[]::text[], 'metric', 'ALL', true, 'latin', 'ltr'),
('LT', 'LT', 'LTU', 'Lithuania', 'europe', 'northern_europe', 2800000, 2, 'lt', ARRAY[]::text[], 'metric', 'EUR', true, 'latin', 'ltr'),
('SI', 'SI', 'SVN', 'Slovenia', 'europe', 'southern_europe', 2100000, 2, 'sl', ARRAY[]::text[], 'metric', 'EUR', true, 'latin', 'ltr'),
('LV', 'LV', 'LVA', 'Latvia', 'europe', 'northern_europe', 1900000, 2, 'lv', ARRAY[]::text[], 'metric', 'EUR', true, 'latin', 'ltr'),
('MK', 'MK', 'MKD', 'North Macedonia', 'europe', 'southern_europe', 2100000, 2, 'mk', ARRAY[]::text[], 'metric', 'MKD', true, 'cyrillic', 'ltr'),

-- Americas (5)
('HN', 'HN', 'HND', 'Honduras', 'americas', 'central_america', 9900000, 2, 'es', ARRAY[]::text[], 'metric', 'HNL', true, 'latin', 'ltr'),
('NI', 'NI', 'NIC', 'Nicaragua', 'americas', 'central_america', 6600000, 2, 'es', ARRAY[]::text[], 'metric', 'NIO', true, 'latin', 'ltr'),
('CR', 'CR', 'CRI', 'Costa Rica', 'americas', 'central_america', 5100000, 2, 'es', ARRAY[]::text[], 'metric', 'CRC', true, 'latin', 'ltr'),
('PA', 'PA', 'PAN', 'Panama', 'americas', 'central_america', 4300000, 2, 'es', ARRAY[]::text[], 'metric', 'PAB', true, 'latin', 'ltr'),
('UY', 'UY', 'URY', 'Uruguay', 'americas', 'south_america', 3500000, 2, 'es', ARRAY[]::text[], 'metric', 'UYU', true, 'latin', 'ltr');

-- TIER 3: Smaller Markets (65 countries)
INSERT INTO countries (country_code, iso_code_2, iso_code_3, country_name, region, subregion, population, priority_tier, primary_language, additional_languages, measurement_system, currency_code, enabled, writing_system, text_direction) VALUES

-- Africa (20)
('LR', 'LR', 'LBR', 'Liberia', 'africa', 'western_africa', 5100000, 3, 'en', ARRAY[]::text[], 'metric', 'LRD', true, 'latin', 'ltr'),
('MR', 'MR', 'MRT', 'Mauritania', 'africa', 'western_africa', 4600000, 3, 'ar', ARRAY[]::text[], 'metric', 'MRU', true, 'arabic', 'rtl'),
('CF', 'CF', 'CAF', 'Central African Republic', 'africa', 'middle_africa', 4800000, 3, 'fr', ARRAY[]::text[], 'metric', 'XAF', true, 'latin', 'ltr'),
('ER', 'ER', 'ERI', 'Eritrea', 'africa', 'eastern_africa', 3500000, 3, 'ti', ARRAY[]::text[], 'metric', 'ERN', true, 'ethiopic', 'ltr'),
('GM', 'GM', 'GMB', 'Gambia', 'africa', 'western_africa', 2400000, 3, 'en', ARRAY[]::text[], 'metric', 'GMD', true, 'latin', 'ltr'),
('BW', 'BW', 'BWA', 'Botswana', 'africa', 'southern_africa', 2400000, 3, 'en', ARRAY['tn'], 'metric', 'BWP', true, 'latin', 'ltr'),
('GA', 'GA', 'GAB', 'Gabon', 'africa', 'middle_africa', 2200000, 3, 'fr', ARRAY[]::text[], 'metric', 'XAF', true, 'latin', 'ltr'),
('LS', 'LS', 'LSO', 'Lesotho', 'africa', 'southern_africa', 2100000, 3, 'en', ARRAY['st'], 'metric', 'LSL', true, 'latin', 'ltr'),
('GW', 'GW', 'GNB', 'Guinea-Bissau', 'africa', 'western_africa', 2000000, 3, 'pt', ARRAY[]::text[], 'metric', 'XOF', true, 'latin', 'ltr'),
('GQ', 'GQ', 'GNQ', 'Equatorial Guinea', 'africa', 'middle_africa', 1400000, 3, 'es', ARRAY[]::text[], 'metric', 'XAF', true, 'latin', 'ltr'),
('MU', 'MU', 'MUS', 'Mauritius', 'africa', 'eastern_africa', 1300000, 3, 'en', ARRAY[]::text[], 'metric', 'MUR', true, 'latin', 'ltr'),
('SZ', 'SZ', 'SWZ', 'Eswatini', 'africa', 'southern_africa', 1200000, 3, 'en', ARRAY['ss'], 'metric', 'SZL', true, 'latin', 'ltr'),
('DJ', 'DJ', 'DJI', 'Djibouti', 'africa', 'eastern_africa', 990000, 3, 'ar', ARRAY['fr'], 'metric', 'DJF', true, 'arabic', 'rtl'),
('KM', 'KM', 'COM', 'Comoros', 'africa', 'eastern_africa', 870000, 3, 'ar', ARRAY[]::text[], 'metric', 'KMF', true, 'arabic', 'rtl'),
('CV', 'CV', 'CPV', 'Cabo Verde', 'africa', 'western_africa', 560000, 3, 'pt', ARRAY[]::text[], 'metric', 'CVE', true, 'latin', 'ltr'),
('ST', 'ST', 'STP', 'São Tomé and Príncipe', 'africa', 'middle_africa', 220000, 3, 'pt', ARRAY[]::text[], 'metric', 'STN', true, 'latin', 'ltr'),
('SC', 'SC', 'SYC', 'Seychelles', 'africa', 'eastern_africa', 98000, 3, 'en', ARRAY[]::text[], 'metric', 'SCR', true, 'latin', 'ltr'),
('LY', 'LY', 'LBY', 'Libya', 'africa', 'northern_africa', 6900000, 3, 'ar', ARRAY[]::text[], 'metric', 'LYD', true, 'arabic', 'rtl'),
('CG', 'CG', 'COG', 'Congo', 'africa', 'middle_africa', 5500000, 3, 'fr', ARRAY[]::text[], 'metric', 'XAF', true, 'latin', 'ltr'),
('SL', 'SL', 'SLE', 'Sierra Leone', 'africa', 'western_africa', 8000000, 3, 'en', ARRAY[]::text[], 'metric', 'SLL', true, 'latin', 'ltr'),

-- Europe (15)
('EE', 'EE', 'EST', 'Estonia', 'europe', 'northern_europe', 1300000, 3, 'et', ARRAY[]::text[], 'metric', 'EUR', true, 'latin', 'ltr'),
('CY', 'CY', 'CYP', 'Cyprus', 'europe', 'southern_europe', 1200000, 3, 'el', ARRAY['tr'], 'metric', 'EUR', true, 'greek', 'ltr'),
('LU', 'LU', 'LUX', 'Luxembourg', 'europe', 'western_europe', 630000, 3, 'fr', ARRAY['de', 'lb'], 'metric', 'EUR', true, 'latin', 'ltr'),
('MT', 'MT', 'MLT', 'Malta', 'europe', 'southern_europe', 520000, 3, 'mt', ARRAY['en'], 'metric', 'EUR', true, 'latin', 'ltr'),
('IS', 'IS', 'ISL', 'Iceland', 'europe', 'northern_europe', 370000, 3, 'is', ARRAY[]::text[], 'metric', 'ISK', true, 'latin', 'ltr'),
('ME', 'ME', 'MNE', 'Montenegro', 'europe', 'southern_europe', 620000, 3, 'sr', ARRAY[]::text[], 'metric', 'EUR', true, 'cyrillic', 'ltr'),
('BY', 'BY', 'BLR', 'Belarus', 'europe', 'eastern_europe', 9400000, 3, 'be', ARRAY['ru'], 'metric', 'BYN', true, 'cyrillic', 'ltr'),
('MD', 'MD', 'MDA', 'Moldova', 'europe', 'eastern_europe', 2600000, 3, 'ro', ARRAY[]::text[], 'metric', 'MDL', true, 'cyrillic', 'ltr'),
('RS', 'RS', 'SRB', 'Serbia', 'europe', 'southern_europe', 6900000, 3, 'sr', ARRAY[]::text[], 'metric', 'RSD', true, 'cyrillic', 'ltr'),
('RU', 'RU', 'RUS', 'Russia', 'europe', 'eastern_europe', 146000000, 3, 'ru', ARRAY[]::text[], 'metric', 'RUB', true, 'cyrillic', 'ltr'),
('AD', 'AD', 'AND', 'Andorra', 'europe', 'southern_europe', 77000, 3, 'ca', ARRAY[]::text[], 'metric', 'EUR', true, 'latin', 'ltr'),
('LI', 'LI', 'LIE', 'Liechtenstein', 'europe', 'western_europe', 38000, 3, 'de', ARRAY[]::text[], 'metric', 'CHF', true, 'latin', 'ltr'),
('MC', 'MC', 'MCO', 'Monaco', 'europe', 'western_europe', 39000, 3, 'fr', ARRAY[]::text[], 'metric', 'EUR', true, 'latin', 'ltr'),
('SM', 'SM', 'SMR', 'San Marino', 'europe', 'southern_europe', 34000, 3, 'it', ARRAY[]::text[], 'metric', 'EUR', true, 'latin', 'ltr'),
('VA', 'VA', 'VAT', 'Vatican City', 'europe', 'southern_europe', 800, 3, 'it', ARRAY['la'], 'metric', 'EUR', true, 'latin', 'ltr'),

-- Americas (13)
('PY', 'PY', 'PRY', 'Paraguay', 'americas', 'south_america', 7100000, 3, 'es', ARRAY['gn'], 'metric', 'PYG', true, 'latin', 'ltr'),
('SV', 'SV', 'SLV', 'El Salvador', 'americas', 'central_america', 6500000, 3, 'es', ARRAY[]::text[], 'metric', 'USD', true, 'latin', 'ltr'),
('JM', 'JM', 'JAM', 'Jamaica', 'americas', 'caribbean', 2900000, 3, 'en', ARRAY[]::text[], 'metric', 'JMD', true, 'latin', 'ltr'),
('TT', 'TT', 'TTO', 'Trinidad and Tobago', 'americas', 'caribbean', 1400000, 3, 'en', ARRAY[]::text[], 'metric', 'TTD', true, 'latin', 'ltr'),
('GY', 'GY', 'GUY', 'Guyana', 'americas', 'south_america', 790000, 3, 'en', ARRAY[]::text[], 'metric', 'GYD', true, 'latin', 'ltr'),
('SR', 'SR', 'SUR', 'Suriname', 'americas', 'south_america', 590000, 3, 'nl', ARRAY[]::text[], 'metric', 'SRD', true, 'latin', 'ltr'),
('BZ', 'BZ', 'BLZ', 'Belize', 'americas', 'central_america', 400000, 3, 'en', ARRAY[]::text[], 'metric', 'BZD', true, 'latin', 'ltr'),
('BB', 'BB', 'BRB', 'Barbados', 'americas', 'caribbean', 290000, 3, 'en', ARRAY[]::text[], 'metric', 'BBD', true, 'latin', 'ltr'),
('BS', 'BS', 'BHS', 'Bahamas', 'americas', 'caribbean', 390000, 3, 'en', ARRAY[]::text[], 'metric', 'BSD', true, 'latin', 'ltr'),
('LC', 'LC', 'LCA', 'Saint Lucia', 'americas', 'caribbean', 180000, 3, 'en', ARRAY[]::text[], 'metric', 'XCD', true, 'latin', 'ltr'),
('GD', 'GD', 'GRD', 'Grenada', 'americas', 'caribbean', 110000, 3, 'en', ARRAY[]::text[], 'metric', 'XCD', true, 'latin', 'ltr'),
('VC', 'VC', 'VCT', 'Saint Vincent and the Grenadines', 'americas', 'caribbean', 110000, 3, 'en', ARRAY[]::text[], 'metric', 'XCD', true, 'latin', 'ltr'),
('AG', 'AG', 'ATG', 'Antigua and Barbuda', 'americas', 'caribbean', 98000, 3, 'en', ARRAY[]::text[], 'metric', 'XCD', true, 'latin', 'ltr'),

-- Oceania (14)
('PG', 'PG', 'PNG', 'Papua New Guinea', 'oceania', 'melanesia', 9000000, 3, 'en', ARRAY[]::text[], 'metric', 'PGK', true, 'latin', 'ltr'),
('FJ', 'FJ', 'FJI', 'Fiji', 'oceania', 'melanesia', 900000, 3, 'en', ARRAY[]::text[], 'metric', 'FJD', true, 'latin', 'ltr'),
('SB', 'SB', 'SLB', 'Solomon Islands', 'oceania', 'melanesia', 690000, 3, 'en', ARRAY[]::text[], 'metric', 'SBD', true, 'latin', 'ltr'),
('VU', 'VU', 'VUT', 'Vanuatu', 'oceania', 'melanesia', 310000, 3, 'bi', ARRAY['en', 'fr'], 'metric', 'VUV', true, 'latin', 'ltr'),
('WS', 'WS', 'WSM', 'Samoa', 'oceania', 'polynesia', 200000, 3, 'sm', ARRAY['en'], 'metric', 'WST', true, 'latin', 'ltr'),
('TO', 'TO', 'TON', 'Tonga', 'oceania', 'polynesia', 110000, 3, 'to', ARRAY['en'], 'metric', 'TOP', true, 'latin', 'ltr'),
('KI', 'KI', 'KIR', 'Kiribati', 'oceania', 'micronesia', 120000, 3, 'en', ARRAY[]::text[], 'metric', 'AUD', true, 'latin', 'ltr'),
('FM', 'FM', 'FSM', 'Micronesia', 'oceania', 'micronesia', 110000, 3, 'en', ARRAY[]::text[], 'metric', 'USD', true, 'latin', 'ltr'),
('MH', 'MH', 'MHL', 'Marshall Islands', 'oceania', 'micronesia', 59000, 3, 'en', ARRAY[]::text[], 'metric', 'USD', true, 'latin', 'ltr'),
('PW', 'PW', 'PLW', 'Palau', 'oceania', 'micronesia', 18000, 3, 'en', ARRAY[]::text[], 'metric', 'USD', true, 'latin', 'ltr'),
('NR', 'NR', 'NRU', 'Nauru', 'oceania', 'micronesia', 11000, 3, 'en', ARRAY[]::text[], 'metric', 'AUD', true, 'latin', 'ltr'),
('TV', 'TV', 'TUV', 'Tuvalu', 'oceania', 'polynesia', 12000, 3, 'en', ARRAY[]::text[], 'metric', 'AUD', true, 'latin', 'ltr'),
('NC', 'NC', 'NCL', 'New Caledonia', 'oceania', 'melanesia', 290000, 3, 'fr', ARRAY[]::text[], 'metric', 'XPF', true, 'latin', 'ltr'),
('PF', 'PF', 'PYF', 'French Polynesia', 'oceania', 'polynesia', 280000, 3, 'fr', ARRAY[]::text[], 'metric', 'XPF', true, 'latin', 'ltr'),

-- Asia (3)
('AZ', 'AZ', 'AZE', 'Azerbaijan', 'asia', 'western_asia', 10100000, 3, 'az', ARRAY[]::text[], 'metric', 'AZN', true, 'latin', 'ltr'),
('PS', 'PS', 'PSE', 'Palestine', 'asia', 'western_asia', 5100000, 3, 'ar', ARRAY[]::text[], 'metric', 'ILS', true, 'arabic', 'rtl');

-- Create summary view
CREATE OR REPLACE VIEW countries_summary AS
SELECT 
  priority_tier,
  COUNT(*) as country_count,
  SUM(population) as total_population,
  array_agg(DISTINCT region) as regions
FROM countries
GROUP BY priority_tier
ORDER BY priority_tier;

-- Create region summary view
CREATE OR REPLACE VIEW countries_by_region AS
SELECT 
  region,
  COUNT(*) as country_count,
  SUM(population) as total_population,
  array_agg(DISTINCT subregion) as subregions
FROM countries
GROUP BY region
ORDER BY total_population DESC;
