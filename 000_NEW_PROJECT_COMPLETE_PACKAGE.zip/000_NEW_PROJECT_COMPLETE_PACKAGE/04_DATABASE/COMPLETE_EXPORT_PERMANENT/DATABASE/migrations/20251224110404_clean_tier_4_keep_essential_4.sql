/*
  # Clean Tier 4 - Keep Only Essential 4 APIs

  Removes unnecessary Tier 4 APIs, keeping only:
  - GitHub API (code examples, repositories)
  - Stack Overflow API (programming Q&A)
  - YouTube Data API (educational videos)
  - Reddit API (community discussions)
*/

-- Remove non-essential Tier 4 APIs
DELETE FROM web_api_services
WHERE tier = 4 
AND name IN (
  'Discord API',
  'Hacker News API',
  'Mastodon API',
  'Podcast Index API',
  'Spotify API',
  'Twitter/X API',
  'Vimeo API'
);

-- Verify we have exactly 4 in Tier 4
-- GitHub API, Stack Overflow API, YouTube Data API, Reddit API