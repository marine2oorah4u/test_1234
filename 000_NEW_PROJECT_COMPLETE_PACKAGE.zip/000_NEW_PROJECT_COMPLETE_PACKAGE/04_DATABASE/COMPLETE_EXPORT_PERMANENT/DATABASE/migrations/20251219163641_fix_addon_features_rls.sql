/*
  # Fix RLS Policies for addon_features Table

  1. Changes
    - Add policy to allow inserts for seeding
    - Keep existing select policies

  2. Security
    - Temporary policy for data seeding
*/

-- Drop existing insert policies if they exist
DROP POLICY IF EXISTS "Allow anon insert for seeding" ON addon_features;
DROP POLICY IF EXISTS "Allow authenticated insert" ON addon_features;

-- Allow anon inserts for seeding (TEMPORARY - for population script)
CREATE POLICY "Allow anon insert for seeding"
  ON addon_features
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Allow authenticated users to insert
CREATE POLICY "Allow authenticated insert"
  ON addon_features
  FOR INSERT
  TO authenticated
  WITH CHECK (true);
