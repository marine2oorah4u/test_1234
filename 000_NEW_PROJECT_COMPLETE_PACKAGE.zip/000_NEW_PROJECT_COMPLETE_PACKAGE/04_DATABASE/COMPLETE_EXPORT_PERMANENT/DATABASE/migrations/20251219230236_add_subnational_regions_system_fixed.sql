/*
  # Add Sub-National Regions System

  1. New Tables
    - `regions` (states, provinces, territories, oblasts, etc.)
      - Links to countries
      - Regional languages
      - Regional content variations
    
  2. Examples
    - US: 50 states + DC + territories
    - Canada: 13 provinces & territories
    - Russia: 85 federal subjects
    - China: 34 provincial-level divisions
    - India: 36 states & union territories
    - Australia: 8 states & territories
    - Brazil: 27 states
    
  3. Security
    - Enable RLS
    - Public read access
*/

-- Create regions table
CREATE TABLE IF NOT EXISTS regions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  country_id uuid REFERENCES countries(id) ON DELETE CASCADE,
  region_code text NOT NULL,
  region_name text NOT NULL,
  region_type text, -- state, province, territory, oblast, prefecture, etc.
  capital_city text,
  population bigint,
  area_km2 integer,
  primary_language text,
  additional_languages text[] DEFAULT ARRAY[]::text[],
  cultural_notes text,
  historical_context text,
  enabled boolean DEFAULT true,
  priority_tier integer DEFAULT 2,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(country_id, region_code)
);

ALTER TABLE regions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Regions are viewable by everyone"
  ON regions FOR SELECT
  TO public
  USING (true);

-- Insert sample regions for major countries
-- United States (10 largest states by population)
INSERT INTO regions (country_id, region_code, region_name, region_type, capital_city, population, primary_language, additional_languages, priority_tier)
SELECT id, 'CA', 'California', 'state', 'Sacramento', 39500000, 'en', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'US'
UNION ALL
SELECT id, 'TX', 'Texas', 'state', 'Austin', 29000000, 'en', ARRAY['es'], 1 FROM countries WHERE country_code = 'US'
UNION ALL
SELECT id, 'FL', 'Florida', 'state', 'Tallahassee', 21500000, 'en', ARRAY['es'], 1 FROM countries WHERE country_code = 'US'
UNION ALL
SELECT id, 'NY', 'New York', 'state', 'Albany', 19500000, 'en', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'US'
UNION ALL
SELECT id, 'PA', 'Pennsylvania', 'state', 'Harrisburg', 12800000, 'en', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'US'
UNION ALL
SELECT id, 'IL', 'Illinois', 'state', 'Springfield', 12700000, 'en', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'US'
UNION ALL
SELECT id, 'OH', 'Ohio', 'state', 'Columbus', 11700000, 'en', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'US'
UNION ALL
SELECT id, 'GA', 'Georgia', 'state', 'Atlanta', 10600000, 'en', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'US'
UNION ALL
SELECT id, 'NC', 'North Carolina', 'state', 'Raleigh', 10400000, 'en', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'US'
UNION ALL
SELECT id, 'MI', 'Michigan', 'state', 'Lansing', 10000000, 'en', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'US';

-- Canada (13 provinces & territories)
INSERT INTO regions (country_id, region_code, region_name, region_type, capital_city, population, primary_language, additional_languages, priority_tier)
SELECT id, 'ON', 'Ontario', 'province', 'Toronto', 14700000, 'en', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'CA'
UNION ALL
SELECT id, 'QC', 'Quebec', 'province', 'Quebec City', 8500000, 'fr', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'CA'
UNION ALL
SELECT id, 'BC', 'British Columbia', 'province', 'Victoria', 5100000, 'en', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'CA'
UNION ALL
SELECT id, 'AB', 'Alberta', 'province', 'Edmonton', 4400000, 'en', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'CA'
UNION ALL
SELECT id, 'MB', 'Manitoba', 'province', 'Winnipeg', 1400000, 'en', ARRAY[]::text[], 2 FROM countries WHERE country_code = 'CA'
UNION ALL
SELECT id, 'SK', 'Saskatchewan', 'province', 'Regina', 1200000, 'en', ARRAY[]::text[], 2 FROM countries WHERE country_code = 'CA'
UNION ALL
SELECT id, 'NS', 'Nova Scotia', 'province', 'Halifax', 990000, 'en', ARRAY[]::text[], 2 FROM countries WHERE country_code = 'CA'
UNION ALL
SELECT id, 'NB', 'New Brunswick', 'province', 'Fredericton', 780000, 'en', ARRAY['fr'], 2 FROM countries WHERE country_code = 'CA'
UNION ALL
SELECT id, 'NL', 'Newfoundland and Labrador', 'province', 'St. John''s', 520000, 'en', ARRAY[]::text[], 2 FROM countries WHERE country_code = 'CA'
UNION ALL
SELECT id, 'PE', 'Prince Edward Island', 'province', 'Charlottetown', 160000, 'en', ARRAY[]::text[], 3 FROM countries WHERE country_code = 'CA'
UNION ALL
SELECT id, 'NT', 'Northwest Territories', 'territory', 'Yellowknife', 45000, 'en', ARRAY[]::text[], 3 FROM countries WHERE country_code = 'CA'
UNION ALL
SELECT id, 'YT', 'Yukon', 'territory', 'Whitehorse', 42000, 'en', ARRAY[]::text[], 3 FROM countries WHERE country_code = 'CA'
UNION ALL
SELECT id, 'NU', 'Nunavut', 'territory', 'Iqaluit', 39000, 'iu', ARRAY['en', 'fr'], 3 FROM countries WHERE country_code = 'CA';

-- Russia (8 major federal subjects)
INSERT INTO regions (country_id, region_code, region_name, region_type, capital_city, population, primary_language, additional_languages, priority_tier)
SELECT id, 'MOW', 'Moscow', 'federal_city', 'Moscow', 12600000, 'ru', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'RU'
UNION ALL
SELECT id, 'SPE', 'Saint Petersburg', 'federal_city', 'Saint Petersburg', 5400000, 'ru', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'RU'
UNION ALL
SELECT id, 'MOS', 'Moscow Oblast', 'oblast', 'Moscow', 7700000, 'ru', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'RU'
UNION ALL
SELECT id, 'KDA', 'Krasnodar Krai', 'krai', 'Krasnodar', 5700000, 'ru', ARRAY[]::text[], 2 FROM countries WHERE country_code = 'RU'
UNION ALL
SELECT id, 'SVE', 'Sverdlovsk Oblast', 'oblast', 'Yekaterinburg', 4300000, 'ru', ARRAY[]::text[], 2 FROM countries WHERE country_code = 'RU'
UNION ALL
SELECT id, 'ROS', 'Rostov Oblast', 'oblast', 'Rostov-on-Don', 4200000, 'ru', ARRAY[]::text[], 2 FROM countries WHERE country_code = 'RU'
UNION ALL
SELECT id, 'TAT', 'Tatarstan', 'republic', 'Kazan', 3900000, 'ru', ARRAY['tt'], 2 FROM countries WHERE country_code = 'RU'
UNION ALL
SELECT id, 'BA', 'Bashkortostan', 'republic', 'Ufa', 4000000, 'ru', ARRAY['ba'], 2 FROM countries WHERE country_code = 'RU';

-- China (8 major provinces & municipalities)
INSERT INTO regions (country_id, region_code, region_name, region_type, capital_city, population, primary_language, additional_languages, priority_tier)
SELECT id, '11', 'Beijing', 'municipality', 'Beijing', 21500000, 'zh', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'CN'
UNION ALL
SELECT id, '31', 'Shanghai', 'municipality', 'Shanghai', 24300000, 'zh', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'CN'
UNION ALL
SELECT id, '44', 'Guangdong', 'province', 'Guangzhou', 126000000, 'zh', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'CN'
UNION ALL
SELECT id, '37', 'Shandong', 'province', 'Jinan', 101000000, 'zh', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'CN'
UNION ALL
SELECT id, '41', 'Henan', 'province', 'Zhengzhou', 99000000, 'zh', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'CN'
UNION ALL
SELECT id, '51', 'Sichuan', 'province', 'Chengdu', 83700000, 'zh', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'CN'
UNION ALL
SELECT id, '32', 'Jiangsu', 'province', 'Nanjing', 84700000, 'zh', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'CN'
UNION ALL
SELECT id, '13', 'Hebei', 'province', 'Shijiazhuang', 75600000, 'zh', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'CN';

-- India (10 major states)
INSERT INTO regions (country_id, region_code, region_name, region_type, capital_city, population, primary_language, additional_languages, priority_tier)
SELECT id, 'UP', 'Uttar Pradesh', 'state', 'Lucknow', 230000000, 'hi', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'IN'
UNION ALL
SELECT id, 'MH', 'Maharashtra', 'state', 'Mumbai', 125000000, 'mr', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'IN'
UNION ALL
SELECT id, 'BR', 'Bihar', 'state', 'Patna', 125000000, 'hi', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'IN'
UNION ALL
SELECT id, 'WB', 'West Bengal', 'state', 'Kolkata', 100000000, 'bn', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'IN'
UNION ALL
SELECT id, 'MP', 'Madhya Pradesh', 'state', 'Bhopal', 85000000, 'hi', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'IN'
UNION ALL
SELECT id, 'TN', 'Tamil Nadu', 'state', 'Chennai', 77000000, 'ta', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'IN'
UNION ALL
SELECT id, 'RJ', 'Rajasthan', 'state', 'Jaipur', 81000000, 'hi', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'IN'
UNION ALL
SELECT id, 'KA', 'Karnataka', 'state', 'Bangalore', 67000000, 'kn', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'IN'
UNION ALL
SELECT id, 'GJ', 'Gujarat', 'state', 'Gandhinagar', 70000000, 'gu', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'IN'
UNION ALL
SELECT id, 'DL', 'Delhi', 'union_territory', 'New Delhi', 32000000, 'hi', ARRAY['en'], 1 FROM countries WHERE country_code = 'IN';

-- Australia (8 states & territories)
INSERT INTO regions (country_id, region_code, region_name, region_type, capital_city, population, primary_language, additional_languages, priority_tier)
SELECT id, 'NSW', 'New South Wales', 'state', 'Sydney', 8200000, 'en', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'AU'
UNION ALL
SELECT id, 'VIC', 'Victoria', 'state', 'Melbourne', 6700000, 'en', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'AU'
UNION ALL
SELECT id, 'QLD', 'Queensland', 'state', 'Brisbane', 5200000, 'en', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'AU'
UNION ALL
SELECT id, 'WA', 'Western Australia', 'state', 'Perth', 2700000, 'en', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'AU'
UNION ALL
SELECT id, 'SA', 'South Australia', 'state', 'Adelaide', 1800000, 'en', ARRAY[]::text[], 2 FROM countries WHERE country_code = 'AU'
UNION ALL
SELECT id, 'TAS', 'Tasmania', 'state', 'Hobart', 550000, 'en', ARRAY[]::text[], 2 FROM countries WHERE country_code = 'AU'
UNION ALL
SELECT id, 'ACT', 'Australian Capital Territory', 'territory', 'Canberra', 430000, 'en', ARRAY[]::text[], 2 FROM countries WHERE country_code = 'AU'
UNION ALL
SELECT id, 'NT', 'Northern Territory', 'territory', 'Darwin', 250000, 'en', ARRAY[]::text[], 3 FROM countries WHERE country_code = 'AU';

-- Brazil (6 major states)
INSERT INTO regions (country_id, region_code, region_name, region_type, capital_city, population, primary_language, additional_languages, priority_tier)
SELECT id, 'SP', 'São Paulo', 'state', 'São Paulo', 46600000, 'pt', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'BR'
UNION ALL
SELECT id, 'MG', 'Minas Gerais', 'state', 'Belo Horizonte', 21400000, 'pt', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'BR'
UNION ALL
SELECT id, 'RJ', 'Rio de Janeiro', 'state', 'Rio de Janeiro', 17500000, 'pt', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'BR'
UNION ALL
SELECT id, 'BA', 'Bahia', 'state', 'Salvador', 14900000, 'pt', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'BR'
UNION ALL
SELECT id, 'PR', 'Paraná', 'state', 'Curitiba', 11500000, 'pt', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'BR'
UNION ALL
SELECT id, 'RS', 'Rio Grande do Sul', 'state', 'Porto Alegre', 11400000, 'pt', ARRAY[]::text[], 1 FROM countries WHERE country_code = 'BR';

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_regions_country ON regions(country_id);
CREATE INDEX IF NOT EXISTS idx_regions_code ON regions(region_code);
CREATE INDEX IF NOT EXISTS idx_regions_tier ON regions(priority_tier);
CREATE INDEX IF NOT EXISTS idx_regions_enabled ON regions(enabled);

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_regions_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER regions_updated_at
  BEFORE UPDATE ON regions
  FOR EACH ROW
  EXECUTE FUNCTION update_regions_updated_at();

-- Create summary view
CREATE OR REPLACE VIEW regions_summary AS
SELECT 
  c.country_name,
  c.country_code,
  COUNT(r.id) as region_count,
  SUM(r.population) as total_regional_population,
  array_agg(DISTINCT r.region_type) as region_types
FROM countries c
LEFT JOIN regions r ON c.id = r.country_id
WHERE r.id IS NOT NULL
GROUP BY c.country_name, c.country_code
ORDER BY region_count DESC;

COMMENT ON TABLE regions IS 'Sub-national regions (states, provinces, territories) for granular localization - 63 major regions across 6 countries';
