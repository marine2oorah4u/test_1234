/*
  # Feature Specification & Approval Tracking System
  
  This migration creates a comprehensive tracking system for the 739 addon features:
  
  1. Tables Created
    - `feature_specifications` - Stores detailed specs for each feature
    - `feature_approvals` - Tracks review and approval status
    - `feature_templates` - Master templates for each phase
    - `specification_versions` - Version history of specifications
  
  2. Tracking Fields
    - Specification status (draft, review, approved, deprecated)
    - Approval workflow (who reviewed, when, feedback)
    - Template associations (which template was used)
    - Completion tracking (what's done vs left to do)
  
  3. Security
    - RLS enabled on all tables
    - Admins can manage specifications
    - Authenticated users can view approved specs
*/

-- Feature Specifications Table
CREATE TABLE IF NOT EXISTS feature_specifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  feature_id uuid REFERENCES addon_features(id) ON DELETE CASCADE,
  
  -- Specification Details
  detailed_description text NOT NULL,
  purpose text NOT NULL,
  input_requirements jsonb DEFAULT '{}',
  output_format jsonb DEFAULT '{}',
  
  -- AI Orchestration
  orchestration_workflow jsonb DEFAULT '{}',
  prompt_templates jsonb DEFAULT '{}',
  model_configuration jsonb DEFAULT '{}',
  
  -- Validation & Quality
  validation_rules jsonb DEFAULT '{}',
  quality_checks jsonb DEFAULT '{}',
  error_handling jsonb DEFAULT '{}',
  
  -- Implementation Details
  dependencies text[] DEFAULT '{}',
  integration_points jsonb DEFAULT '{}',
  test_cases jsonb DEFAULT '{}',
  
  -- Cost & Time
  estimated_cost_per_run numeric(10, 4) DEFAULT 0,
  estimated_time_seconds integer DEFAULT 0,
  token_estimates jsonb DEFAULT '{}',
  
  -- Template & Version
  template_used text,
  specification_version integer DEFAULT 1,
  
  -- Status
  status text DEFAULT 'draft' CHECK (status IN ('draft', 'review', 'approved', 'deprecated')),
  
  -- Metadata
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES auth.users(id),
  updated_by uuid REFERENCES auth.users(id)
);

-- Feature Approvals Table
CREATE TABLE IF NOT EXISTS feature_approvals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  feature_id uuid REFERENCES addon_features(id) ON DELETE CASCADE,
  specification_id uuid REFERENCES feature_specifications(id) ON DELETE CASCADE,
  
  -- Approval Details
  approval_status text DEFAULT 'pending' CHECK (
    approval_status IN ('pending', 'changes_requested', 'approved', 'rejected')
  ),
  
  -- Review Information
  reviewer_id uuid REFERENCES auth.users(id),
  review_date timestamptz,
  review_notes text,
  
  -- Specific Feedback
  feedback jsonb DEFAULT '{}',
  requested_changes text[] DEFAULT '{}',
  
  -- Quality Ratings (1-5)
  clarity_rating integer CHECK (clarity_rating BETWEEN 1 AND 5),
  completeness_rating integer CHECK (completeness_rating BETWEEN 1 AND 5),
  implementation_rating integer CHECK (implementation_rating BETWEEN 1 AND 5),
  overall_rating integer CHECK (overall_rating BETWEEN 1 AND 5),
  
  -- Timestamps
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Feature Templates Table (Master templates for each phase)
CREATE TABLE IF NOT EXISTS feature_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Template Identity
  template_name text UNIQUE NOT NULL,
  template_category text NOT NULL, -- research, generation, verification, refinement, polish
  template_description text NOT NULL,
  
  -- Template Structure
  template_structure jsonb NOT NULL,
  required_fields text[] DEFAULT '{}',
  optional_fields text[] DEFAULT '{}',
  
  -- Validation Rules
  validation_schema jsonb DEFAULT '{}',
  
  -- Usage Instructions
  usage_instructions text,
  example_specifications jsonb DEFAULT '[]',
  
  -- Metadata
  version integer DEFAULT 1,
  status text DEFAULT 'active' CHECK (status IN ('draft', 'active', 'deprecated')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Specification Versions Table (Version history)
CREATE TABLE IF NOT EXISTS specification_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  feature_id uuid REFERENCES addon_features(id) ON DELETE CASCADE,
  specification_id uuid REFERENCES feature_specifications(id) ON DELETE CASCADE,
  
  -- Version Info
  version_number integer NOT NULL,
  change_description text,
  
  -- Full Snapshot
  specification_snapshot jsonb NOT NULL,
  
  -- Change Tracking
  changed_by uuid REFERENCES auth.users(id),
  changed_at timestamptz DEFAULT now()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_feature_specs_feature_id ON feature_specifications(feature_id);
CREATE INDEX IF NOT EXISTS idx_feature_specs_status ON feature_specifications(status);
CREATE INDEX IF NOT EXISTS idx_feature_approvals_feature_id ON feature_approvals(feature_id);
CREATE INDEX IF NOT EXISTS idx_feature_approvals_status ON feature_approvals(approval_status);
CREATE INDEX IF NOT EXISTS idx_feature_templates_category ON feature_templates(template_category);

-- Enable Row Level Security
ALTER TABLE feature_specifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE feature_approvals ENABLE ROW LEVEL SECURITY;
ALTER TABLE feature_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE specification_versions ENABLE ROW LEVEL SECURITY;

-- RLS Policies: feature_specifications
CREATE POLICY "Admins can manage all feature specifications"
  ON feature_specifications FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Users can view approved specifications"
  ON feature_specifications FOR SELECT
  TO authenticated
  USING (status = 'approved');

-- RLS Policies: feature_approvals
CREATE POLICY "Admins can manage all approvals"
  ON feature_approvals FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

-- RLS Policies: feature_templates
CREATE POLICY "Admins can manage templates"
  ON feature_templates FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Users can view active templates"
  ON feature_templates FOR SELECT
  TO authenticated
  USING (status = 'active');

-- RLS Policies: specification_versions
CREATE POLICY "Admins can manage version history"
  ON specification_versions FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers for updated_at
CREATE TRIGGER update_feature_specifications_updated_at
  BEFORE UPDATE ON feature_specifications
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_feature_approvals_updated_at
  BEFORE UPDATE ON feature_approvals
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_feature_templates_updated_at
  BEFORE UPDATE ON feature_templates
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
