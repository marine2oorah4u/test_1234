/*
  # Complete 1,983 Features Integration with AI Model Assignments

  1. New Tables
    - `platform_features` - All 1,244 platform features
    - `addon_features` - All 739 addon feature types  
    - `ai_model_performance` - Tracks performance of 12 AI models
    - `feature_verifications` - Individual verification results
    - `consensus_results` - Multi-model consensus outcomes
    - `feature_ai_assignments` - Which AI models are assigned to each feature
    - `feature_quality_thresholds` - Quality standards per feature type

  2. Security
    - Enable RLS on all tables
    - Admin-only write access
    - Authenticated users can read their relevant data
*/

-- Platform Features Table (1,244 features)
CREATE TABLE IF NOT EXISTS platform_features (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  feature_number INTEGER NOT NULL UNIQUE,
  feature_name TEXT NOT NULL,
  category TEXT NOT NULL,
  description TEXT,
  tier INTEGER NOT NULL CHECK (tier IN (1, 2, 3)),
  assigned_ai_models TEXT[], -- Array of AI model names
  implementation_status TEXT DEFAULT 'pending' CHECK (implementation_status IN ('pending', 'in_progress', 'completed', 'blocked')),
  quality_score NUMERIC CHECK (quality_score >= 0 AND quality_score <= 100),
  requires_consensus BOOLEAN DEFAULT false,
  wcag_level TEXT CHECK (wcag_level IN ('A', 'AA', 'AAA', NULL)),
  dependencies TEXT[], -- Other feature IDs this depends on
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Addon Features Table (739 addon types)
CREATE TABLE IF NOT EXISTS addon_features (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  addon_type TEXT NOT NULL CHECK (addon_type IN ('activity_pack', 'worksheet_set', 'quiz_pack', 'answer_key', 'lesson_plan', 'presentation_slides', 'study_guide', 'career_guide')),
  feature_name TEXT NOT NULL,
  description TEXT,
  generation_phase TEXT NOT NULL CHECK (generation_phase IN ('research', 'generation', 'verification', 'refinement', 'polish')),
  assigned_ai_models TEXT[], -- Array of AI model names for this phase
  quality_threshold NUMERIC NOT NULL DEFAULT 90,
  requires_safety_check BOOLEAN DEFAULT false,
  age_appropriate_levels TEXT[], -- Array of age ranges
  subject_categories TEXT[], -- Which subjects this applies to
  implementation_status TEXT DEFAULT 'pending' CHECK (implementation_status IN ('pending', 'in_progress', 'completed', 'blocked')),
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- AI Model Performance Tracking
CREATE TABLE IF NOT EXISTS ai_model_performance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  model_name TEXT NOT NULL,
  model_tier INTEGER NOT NULL CHECK (model_tier IN (1, 2, 3)),
  total_tasks INTEGER DEFAULT 0,
  successful_tasks INTEGER DEFAULT 0,
  failed_tasks INTEGER DEFAULT 0,
  average_quality_score NUMERIC,
  average_response_time_ms NUMERIC,
  cost_per_task NUMERIC,
  specialties TEXT[], -- What this model is best at
  last_used_at TIMESTAMPTZ,
  performance_notes TEXT,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Feature Verifications (individual AI model results)
CREATE TABLE IF NOT EXISTS feature_verifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  feature_id UUID NOT NULL, -- References platform_features or addon_features
  feature_type TEXT NOT NULL CHECK (feature_type IN ('platform', 'addon')),
  ai_model_name TEXT NOT NULL,
  verification_phase TEXT NOT NULL,
  passed BOOLEAN NOT NULL,
  quality_score NUMERIC CHECK (quality_score >= 0 AND quality_score <= 100),
  issues_found TEXT[],
  suggestions TEXT[],
  verification_details JSONB DEFAULT '{}'::jsonb,
  verified_at TIMESTAMPTZ DEFAULT now()
);

-- Consensus Results (multi-model agreement)
CREATE TABLE IF NOT EXISTS consensus_results (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  feature_id UUID NOT NULL,
  feature_type TEXT NOT NULL CHECK (feature_type IN ('platform', 'addon')),
  total_models INTEGER NOT NULL,
  models_agreed INTEGER NOT NULL,
  consensus_percentage NUMERIC NOT NULL,
  consensus_passed BOOLEAN NOT NULL,
  min_required_consensus NUMERIC NOT NULL,
  dissenting_models TEXT[], -- Models that disagreed
  consensus_details JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Feature AI Assignments (which models work on what)
CREATE TABLE IF NOT EXISTS feature_ai_assignments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  feature_id UUID NOT NULL,
  feature_type TEXT NOT NULL CHECK (feature_type IN ('platform', 'addon')),
  phase TEXT NOT NULL,
  ai_model_name TEXT NOT NULL,
  assignment_reason TEXT, -- Why this model was chosen
  priority INTEGER DEFAULT 1,
  status TEXT DEFAULT 'assigned' CHECK (status IN ('assigned', 'in_progress', 'completed', 'failed')),
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Feature Quality Thresholds (standards per feature type)
CREATE TABLE IF NOT EXISTS feature_quality_thresholds (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  feature_type TEXT NOT NULL CHECK (feature_type IN ('platform', 'addon')),
  category TEXT, -- For platform features
  addon_type TEXT, -- For addon features
  min_consensus_score NUMERIC NOT NULL DEFAULT 0.90,
  min_accuracy_score NUMERIC NOT NULL DEFAULT 95,
  requires_safety_verification BOOLEAN DEFAULT false,
  requires_wcag_compliance BOOLEAN DEFAULT false,
  wcag_level TEXT CHECK (wcag_level IN ('A', 'AA', 'AAA', NULL)),
  threshold_notes TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(feature_type, category, addon_type)
);

-- Enable Row Level Security
ALTER TABLE platform_features ENABLE ROW LEVEL SECURITY;
ALTER TABLE addon_features ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_model_performance ENABLE ROW LEVEL SECURITY;
ALTER TABLE feature_verifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE consensus_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE feature_ai_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE feature_quality_thresholds ENABLE ROW LEVEL SECURITY;

-- RLS Policies: Admin can do everything
CREATE POLICY "Admins have full access to platform_features"
  ON platform_features FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Admins have full access to addon_features"
  ON addon_features FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Admins have full access to ai_model_performance"
  ON ai_model_performance FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Admins have full access to feature_verifications"
  ON feature_verifications FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Admins have full access to consensus_results"
  ON consensus_results FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Admins have full access to feature_ai_assignments"
  ON feature_ai_assignments FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Admins have full access to feature_quality_thresholds"
  ON feature_quality_thresholds FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

-- RLS Policies: Users can view (read-only)
CREATE POLICY "Users can view platform features"
  ON platform_features FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can view addon features"
  ON addon_features FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can view ai model performance"
  ON ai_model_performance FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can view quality thresholds"
  ON feature_quality_thresholds FOR SELECT
  TO authenticated
  USING (true);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_platform_features_category ON platform_features(category);
CREATE INDEX IF NOT EXISTS idx_platform_features_status ON platform_features(implementation_status);
CREATE INDEX IF NOT EXISTS idx_platform_features_tier ON platform_features(tier);
CREATE INDEX IF NOT EXISTS idx_addon_features_type ON addon_features(addon_type);
CREATE INDEX IF NOT EXISTS idx_addon_features_phase ON addon_features(generation_phase);
CREATE INDEX IF NOT EXISTS idx_addon_features_status ON addon_features(implementation_status);
CREATE INDEX IF NOT EXISTS idx_ai_model_performance_name ON ai_model_performance(model_name);
CREATE INDEX IF NOT EXISTS idx_feature_verifications_feature ON feature_verifications(feature_id, feature_type);
CREATE INDEX IF NOT EXISTS idx_consensus_results_feature ON consensus_results(feature_id, feature_type);
CREATE INDEX IF NOT EXISTS idx_feature_ai_assignments_feature ON feature_ai_assignments(feature_id, feature_type);

-- Insert default quality thresholds for platform feature categories
INSERT INTO feature_quality_thresholds (feature_type, category, min_consensus_score, min_accuracy_score, requires_safety_verification, requires_wcag_compliance, wcag_level)
VALUES
  ('platform', 'Content Delivery', 0.90, 95, false, true, 'AA'),
  ('platform', 'Interactive Learning', 0.90, 95, true, true, 'AA'),
  ('platform', 'Assessment Tools', 0.95, 98, false, true, 'AA'),
  ('platform', 'Accessibility Features', 0.95, 100, false, true, 'AAA'),
  ('platform', 'Gamification', 0.85, 90, false, true, 'AA'),
  ('platform', 'Social Learning', 0.90, 95, true, true, 'AA'),
  ('platform', 'Progress Tracking', 0.90, 95, false, true, 'AA'),
  ('platform', 'Admin Tools', 0.95, 98, false, true, 'AA'),
  ('platform', 'Security Features', 0.95, 100, true, true, 'AAA'),
  ('platform', 'Translation', 0.90, 95, false, true, 'AA')
ON CONFLICT DO NOTHING;

-- Insert default quality thresholds for addon types
INSERT INTO feature_quality_thresholds (feature_type, addon_type, min_consensus_score, min_accuracy_score, requires_safety_verification, requires_wcag_compliance, wcag_level)
VALUES
  ('addon', 'activity_pack', 0.90, 95, true, true, 'AA'),
  ('addon', 'worksheet_set', 0.90, 95, false, true, 'AA'),
  ('addon', 'quiz_pack', 0.95, 98, false, true, 'AA'),
  ('addon', 'answer_key', 0.95, 100, false, true, 'AA'),
  ('addon', 'lesson_plan', 0.90, 95, false, true, 'AA'),
  ('addon', 'presentation_slides', 0.85, 90, false, true, 'AA'),
  ('addon', 'study_guide', 0.90, 95, false, true, 'AA'),
  ('addon', 'career_guide', 0.90, 95, false, true, 'AA')
ON CONFLICT DO NOTHING;

-- Insert AI Model Performance baseline data
INSERT INTO ai_model_performance (model_name, model_tier, specialties)
VALUES
  ('GPT-5 Pro', 1, ARRAY['reasoning', 'instruction-following', 'complex-tasks']),
  ('Claude 3.5 Sonnet', 1, ARRAY['clarity', 'structure', 'safety', 'nuance']),
  ('o4-mini-deep-research', 1, ARRAY['research', 'fact-checking', 'depth']),
  ('Gemini Pro 1.5', 1, ARRAY['STEM', 'multimodal', 'code', 'data-analysis']),
  ('DeepSeek-V3', 2, ARRAY['logic', 'code', 'reasoning', 'safety']),
  ('Perplexity Pro', 2, ARRAY['research', 'real-world-examples', 'current-info']),
  ('GPT-5.1', 2, ARRAY['creative', 'engaging', 'varied-responses']),
  ('Gemini Flash', 2, ARRAY['speed', 'quick-facts', 'summaries']),
  ('Claude 3 Opus', 3, ARRAY['long-context', 'complex-analysis', 'reliability']),
  ('GPT-4 Turbo', 3, ARRAY['general-purpose', 'reliable', 'balanced']),
  ('Gemini Ultra', 3, ARRAY['advanced-reasoning', 'multimodal', 'complex-tasks']),
  ('Cohere Command R+', 3, ARRAY['enterprise', 'retrieval', 'grounded-generation'])
ON CONFLICT DO NOTHING;
