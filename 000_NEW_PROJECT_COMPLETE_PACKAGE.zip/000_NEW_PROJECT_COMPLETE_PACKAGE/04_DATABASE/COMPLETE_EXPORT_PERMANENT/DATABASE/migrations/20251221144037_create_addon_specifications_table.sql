/*
  # Create Addon Specifications Storage System

  1. New Table
    - `addon_specifications`
      - Stores all 1,000+ individual addon variation specifications
      - Links to addon types, categories, and features
      - Includes generation parameters and quality standards

  2. Purpose
    - Fast AI lookups for specific addon variations
    - Metadata storage for generation parameters
    - Quality threshold tracking per variation
    - AI model assignments per variation

  3. Security
    - Enable RLS
    - Allow authenticated users to read
    - Only admins can write
*/

-- Create addon specifications table
CREATE TABLE IF NOT EXISTS addon_specifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Basic Info
  name text NOT NULL,
  description text NOT NULL,
  addon_type text NOT NULL CHECK (addon_type IN (
    'activity_packs',
    'worksheet_sets',
    'quiz_packs',
    'answer_keys',
    'lesson_plans',
    'presentation_slides',
    'career_guides',
    'study_guides'
  )),
  
  -- Categorization
  category text NOT NULL,
  subcategory text,
  tags text[] DEFAULT '{}',
  
  -- Variation Details
  variation_type text NOT NULL, -- e.g., 'elementary_hands_on', 'high_school_sat_prep'
  target_audience text NOT NULL, -- e.g., 'elementary', 'high_school', 'college'
  difficulty_level text,
  estimated_quantity int DEFAULT 1, -- how many items this spec generates
  
  -- Generation Parameters
  ai_models jsonb NOT NULL DEFAULT '{}', -- {"research": ["o4-mini"], "generation": ["gpt-5-pro"], ...}
  quality_thresholds jsonb NOT NULL DEFAULT '{}', -- {"research": 80, "generation": 75, "verification": 90, ...}
  generation_phases text[] DEFAULT '{"research", "generation", "verification", "refinement", "polish"}',
  
  -- File Specifications
  file_path text, -- path to the spec file in file system
  file_formats text[] DEFAULT '{}', -- e.g., ['pdf', 'docx', 'html']
  
  -- Requirements
  prerequisites text[] DEFAULT '{}',
  required_features text[] DEFAULT '{}', -- list of feature IDs this spec depends on
  optional_features text[] DEFAULT '{}',
  
  -- Cost & Time Estimates
  estimated_cost_usd decimal(10,2),
  estimated_time_minutes int,
  
  -- Metadata
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES auth.users(id),
  status text DEFAULT 'draft' CHECK (status IN ('draft', 'approved', 'active', 'deprecated')),
  
  -- Full spec content (optional - can be loaded from file)
  full_specification jsonb DEFAULT '{}'
);

-- Create indexes for fast lookups
CREATE INDEX IF NOT EXISTS idx_addon_specifications_type ON addon_specifications(addon_type);
CREATE INDEX IF NOT EXISTS idx_addon_specifications_category ON addon_specifications(category);
CREATE INDEX IF NOT EXISTS idx_addon_specifications_variation ON addon_specifications(variation_type);
CREATE INDEX IF NOT EXISTS idx_addon_specifications_audience ON addon_specifications(target_audience);
CREATE INDEX IF NOT EXISTS idx_addon_specifications_status ON addon_specifications(status);
CREATE INDEX IF NOT EXISTS idx_addon_specifications_tags ON addon_specifications USING gin(tags);

-- Enable RLS
ALTER TABLE addon_specifications ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Anyone can read approved addon specifications"
  ON addon_specifications
  FOR SELECT
  USING (status = 'approved' OR status = 'active');

CREATE POLICY "Authenticated users can read all addon specifications"
  ON addon_specifications
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can insert addon specifications"
  ON addon_specifications
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Admins can update addon specifications"
  ON addon_specifications
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

CREATE POLICY "Admins can delete addon specifications"
  ON addon_specifications
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role = 'admin'
    )
  );

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_addon_specifications_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER addon_specifications_updated_at
  BEFORE UPDATE ON addon_specifications
  FOR EACH ROW
  EXECUTE FUNCTION update_addon_specifications_updated_at();
