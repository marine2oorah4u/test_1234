# ⚡ QUICK START - 5 Minute Database Import

---

## 🚀 Import to New Project

### Step 1: Copy Files
```bash
cd /path/to/your/new/project
cp /path/to/COMPLETE_EXPORT_PERMANENT/DATABASE/migrations/* supabase/migrations/
```

### Step 2: Deploy
```bash
supabase link --project-ref your-project-ref
supabase db push
```

### Step 3: Verify
```sql
-- Should return ~80
SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'public';

-- Should return 1,983
SELECT COUNT(*) FROM features_catalog;

-- Should return 50,000+
SELECT COUNT(*) FROM careers;
```

---

## ✅ You're Done!

Your database now has:
- 80+ tables
- 1,983 features
- 50,000+ careers
- 195 countries
- Full security

Create first user → auto-admin!

---

Read main README.md for complete documentation.
