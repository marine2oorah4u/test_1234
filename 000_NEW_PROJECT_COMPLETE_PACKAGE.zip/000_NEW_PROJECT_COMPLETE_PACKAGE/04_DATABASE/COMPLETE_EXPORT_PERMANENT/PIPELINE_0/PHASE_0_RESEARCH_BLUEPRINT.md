# Phase 0: Global Job Catalog Research Blueprint

**Created:** December 20, 2025
**Purpose:** Systematic research and cataloging of 50,000+ careers across 195 countries
**Timeline:** 6-12 months for initial catalog, ongoing updates quarterly
**Team:** AI-assisted research with human verification

---

## 🎯 MISSION STATEMENT

Build a comprehensive, accurate, and culturally-relevant job catalog covering every country's labor market, enabling bidirectional linking between educational content and career opportunities worldwide.

---

## 📊 SCOPE AND SCALE

### Target Coverage
- **195 Countries**: All UN-recognized sovereign states
- **50,000+ Jobs**: Comprehensive coverage of global workforce
- **110+ Languages**: Job titles and descriptions in local languages
- **3 Classification Systems**: ISCO (international), SOC (US), national systems

### Priority Tiers

**Tier 1: High Priority (First 6 months)**
- USA, Canada, UK, Australia, New Zealand
- Germany, France, Netherlands, Switzerland
- Japan, South Korea, Singapore
- **Target:** 15,000 jobs across 12 countries

**Tier 2: Medium Priority (Months 6-9)**
- European Union countries (remaining)
- Brazil, Mexico, Argentina
- India, China, UAE, Saudi Arabia
- **Target:** 20,000 jobs across 40 countries

**Tier 3: Standard Priority (Months 9-12)**
- All remaining countries
- **Target:** 15,000 jobs across 143 countries

---

## 🔬 RESEARCH METHODOLOGY

### Step 1: Country Assessment (Week 1 per country batch)

**Data Source Identification**
1. Primary government labor statistics agencies
2. National employment databases
3. International organizations (ILO, OECD, World Bank)
4. Regional labor market authorities

**Questions to Answer:**
- Does this country use ISCO classification?
- What is the national job classification system?
- Are official APIs available?
- What is the data update frequency?
- Is data available in English?
- What is the typical lag time for data?

**Deliverable:** Country Research Profile in `phase_0_research_catalog` table

---

### Step 2: Data Collection Strategy (Week 2)

**For Each Country, Determine:**

**Method A: API Access (Preferred)**
```
Example: US Bureau of Labor Statistics (BLS)
- API Endpoint: https://api.bls.gov/publicAPI/v2/
- Classification: SOC codes
- Update Frequency: Annual
- Coverage: 800+ occupations
- Rate Limits: 500 requests/day (free tier)
```

**Method B: Web Scraping (When needed)**
```
Considerations:
- Respect robots.txt
- Rate limiting (max 1 request/second)
- Caching to minimize requests
- Regular re-validation of scrapers
```

**Method C: Manual Research (Last resort)**
```
For countries with limited digital infrastructure:
- Government PDF reports
- International labor organization data
- Embassy economic reports
- Academic studies
```

**Method D: International Database Mapping**
```
Use ISCO codes as base:
- Map ISCO → Country codes
- Supplement with national specifics
- Verify with local sources
```

---

### Step 3: Job Cataloging Process (Ongoing)

**For Each Job, Collect 50+ Data Points:**

#### Basic Information
1. Job title (English)
2. Job title (local language)
3. ISCO code
4. SOC code (if applicable)
5. National classification code
6. Job family
7. Job category
8. Alternative job titles

#### Educational Requirements
9. Minimum education level
10. Recommended education level
11. Specific degrees/majors
12. Alternative pathways
13. Required certifications
14. Continuing education needs

#### Skills and Competencies
15. Technical skills required (list)
16. Soft skills required (list)
17. Tools/software proficiency
18. Language requirements
19. Physical requirements
20. Cognitive requirements

#### Experience Requirements
21. Entry-level expectations
22. Typical career progression
23. Mid-career requirements
24. Senior-level expectations
25. Industry-specific experience

#### Market Data
26. Average salary (local currency)
27. Average salary (USD equivalent)
28. Salary range (low)
29. Salary range (high)
30. Typical benefits package
31. Job growth outlook (5-year)
32. Current demand level
33. Number of annual openings
34. Unemployment rate for role
35. Automation risk assessment

#### Working Conditions
36. Typical work environment
37. Physical demands
38. Work schedule (full/part/shift)
39. Remote work potential
40. Travel requirements
41. Health and safety considerations

#### Career Information
42. Typical entry jobs
43. Jobs this leads to
44. Career ladder position
45. Related occupations
46. Industry sectors employing

#### Educational Content Mapping (AI Phase)
47. Related school subjects
48. Academic preparation needed
49. Skill development timeline
50. Learning resources available

---

### Step 4: Quality Verification (Continuous)

**Automated Checks:**
- Data completeness score (% of fields filled)
- Salary range validation (low < high)
- Cross-reference ISCO/SOC mappings
- Duplicate detection
- Outlier detection (salary anomalies)

**Human Verification:**
- Subject matter expert review (sample 10%)
- Native speaker validation (local language)
- Local market expert confirmation
- Annual re-verification of all data

**Quality Scoring:**
```
Quality Score =
  (Data Completeness × 0.40) +
  (Source Reliability × 0.30) +
  (Recency of Data × 0.20) +
  (Verification Status × 0.10)

Minimum Acceptable: 70/100
Target Average: 85/100
```

---

## 🤖 AI INTEGRATION STRATEGY

### Research AI Models

**Primary Research Models:**
1. **Perplexity AI** - Real-time web search and synthesis
2. **Claude 3.5 Sonnet** - Deep research and analysis
3. **GPT-5 Pro** - Cross-validation and fact-checking

**Research Workflow:**
```
1. Perplexity AI: Find official data sources for country X
2. Claude 3.5 Sonnet: Extract structured job data from sources
3. GPT-5 Pro: Cross-validate data against multiple sources
4. Consensus Check: Require 2/3 model agreement on key facts
5. Human Review: Verify 10% sample per country
```

### AI Prompt Templates

**Country Assessment Prompt:**
```
Research Task: Labor Market Data Sources for [COUNTRY]

1. Identify the official government labor statistics agency
2. Determine if they use ISCO classification system
3. List their national job classification system (if different)
4. Find any available APIs or data portals
5. Assess data quality and update frequency
6. Note any language barriers or access restrictions

Provide: Agency name, URL, classification system, API details, data quality assessment (1-10), notes.
```

**Job Research Prompt:**
```
Research Task: Comprehensive Job Profile

Job Title: [JOB_TITLE]
Country: [COUNTRY]
ISCO Code: [CODE] (if known)

Required Information:
1. Official job description
2. Educational requirements (minimum and recommended)
3. Required skills and competencies
4. Average salary range (local currency and USD)
5. Job outlook and demand trends
6. Typical career progression
7. Required certifications or licenses
8. Working conditions and environment
9. Alternative job titles in this country
10. Related occupations

Sources: Prioritize official government labor statistics, followed by international organizations (ILO, OECD), then reputable job sites.

Format: Structured data with confidence scores for each field.
```

---

## 📋 WORKFLOW PHASES

### Phase 0.1: Infrastructure Setup (Month 1)

**Database Preparation:**
- ✅ Create `global_job_catalog` table (DONE)
- ✅ Create `phase_0_research_catalog` table (DONE)
- Populate 195 country entries in research catalog
- Set research priorities for all countries

**Tool Development:**
- API integration scripts (BLS, Eurostat, etc.)
- Web scraping framework (with rate limiting)
- Data validation pipeline
- Quality scoring algorithm
- Duplicate detection system

**Team Setup:**
- Train AI models on job research tasks
- Recruit human verifiers (1 per major language group)
- Establish verification standards
- Create quality control checklists

---

### Phase 0.2: Tier 1 Countries (Months 2-6)

**Target: 12 Countries, 15,000 Jobs**

**Priority Order:**
1. **USA** (5,000 jobs) - BLS API, SOC codes
2. **UK** (2,000 jobs) - ONS data, SOC 2020
3. **Canada** (1,500 jobs) - NOC codes
4. **Australia** (1,500 jobs) - ANZSCO codes
5. **Germany** (1,500 jobs) - Bundesagentur für Arbeit
6. **France** (1,000 jobs) - INSEE, ROME codes
7. **Japan** (1,000 jobs) - Ministry of Health, Labour and Welfare
8. **Netherlands** (800 jobs)
9. **Switzerland** (700 jobs)
10. **New Zealand** (500 jobs)
11. **South Korea** (500 jobs)
12. **Singapore** (500 jobs)

**Weekly Target:** 250 jobs researched and cataloged

**Quality Gate:** 85%+ quality score average before moving to Tier 2

---

### Phase 0.3: Tier 2 Countries (Months 6-9)

**Target: 40 Countries, 20,000 Jobs**

**Regional Batches:**
- **EU Remaining** (15 countries): 8,000 jobs
- **Latin America** (8 countries): 5,000 jobs
- **Asia-Pacific** (10 countries): 5,000 jobs
- **Middle East** (7 countries): 2,000 jobs

**Weekly Target:** 600 jobs researched and cataloged

**Focus:** Establish regional research patterns, optimize AI prompts for different labor market structures

---

### Phase 0.4: Tier 3 Countries (Months 9-12)

**Target: 143 Countries, 15,000 Jobs**

**Strategy:**
- Focus on top 100-200 jobs per country
- Use ISCO as baseline, supplement with national data
- Higher reliance on international databases (ILO, World Bank)
- Regional experts validate sample sets

**Weekly Target:** 400 jobs researched and cataloged

**Acceptable Quality:** 75%+ quality score (lower threshold for data-scarce countries)

---

### Phase 0.5: Verification & Launch (Month 12)

**Activities:**
1. **Comprehensive Quality Audit**
   - Review 5% sample across all countries
   - Verify data accuracy with local experts
   - Correct systematic errors

2. **Data Enrichment**
   - Add missing fields where possible
   - Enhance descriptions for clarity
   - Standardize terminology

3. **Catalog Launch**
   - Mark verified jobs as "production ready"
   - Enable educational content linking
   - Begin Phase 1 career addon generation

**Success Criteria:**
- ✅ 50,000+ jobs cataloged
- ✅ 195 countries covered
- ✅ 80%+ average quality score
- ✅ All Tier 1 countries at 90%+ quality

---

## 🔄 ONGOING MAINTENANCE (Post-Launch)

### Quarterly Updates
- Refresh salary data for all jobs
- Update job outlook projections
- Add newly created job roles
- Remove obsolete positions

### Annual Full Review
- Re-verify 20% of catalog
- Update all educational requirements
- Refresh market demand data
- Add new countries (as needed)

### Continuous Improvement
- User feedback integration
- Expert corrections and enhancements
- AI model improvements
- Source diversification

---

## 📊 PROGRESS TRACKING

### Key Performance Indicators (KPIs)

**Coverage Metrics:**
- Jobs cataloged per week
- Countries completed
- Classification systems mapped
- Language coverage

**Quality Metrics:**
- Average quality score
- Data completeness percentage
- Verification success rate
- Error correction rate

**Efficiency Metrics:**
- Time per job (target: 15 minutes)
- AI automation rate (target: 80%)
- Human verification time
- Cost per job cataloged

### Dashboard Views

**Executive Dashboard:**
- Total jobs: 15,234 / 50,000 (30%)
- Countries complete: 12 / 195 (6%)
- Quality score: 87.2 / 100
- On track: YES

**Research Team Dashboard:**
- This week: 623 jobs added
- Jobs needing verification: 156
- Quality issues: 12 flagged
- Next milestone: Tier 1 completion (2 weeks)

**Country View:**
```
USA: ████████████████████ 100% (5,000 jobs) ✅
UK:  █████████████░░░░░░░  67% (1,340 jobs) 🔄
CAN: ███████░░░░░░░░░░░░░  40% (600 jobs) 🔄
AUS: ██░░░░░░░░░░░░░░░░░░  10% (150 jobs) 🔄
```

---

## 💰 BUDGET ESTIMATES

### AI Costs (First Year)
- Research: $15,000 (Perplexity, Claude, GPT-5)
- Verification: $5,000 (cross-checking)
- Translation: $10,000 (job titles in 110 languages)
- **Total AI:** $30,000

### Human Resources
- Project Manager (25% time): $25,000
- Research Coordinators (2 FTE): $120,000
- Subject Matter Experts (contract): $30,000
- Language Verifiers (contract): $20,000
- **Total Human:** $195,000

### Infrastructure
- Database hosting: $5,000
- API access fees: $3,000
- Tools and software: $2,000
- **Total Infrastructure:** $10,000

### **TOTAL PHASE 0 BUDGET:** $235,000

**Cost per Job:** $4.70 (50,000 jobs)

---

## 🚨 RISK MANAGEMENT

### Risk 1: Data Availability
**Issue:** Some countries lack comprehensive labor market data
**Mitigation:**
- Use ISCO as baseline
- Supplement with regional data
- Accept lower quality scores for data-scarce countries

### Risk 2: Language Barriers
**Issue:** Non-English sources require translation
**Mitigation:**
- Recruit native speaker verifiers
- Use AI translation with human review
- Partner with local universities

### Risk 3: Data Obsolescence
**Issue:** Job market changes rapidly
**Mitigation:**
- Quarterly update cycles
- Automated staleness detection
- User-submitted updates with verification

### Risk 4: Classification Inconsistencies
**Issue:** Different countries use different job taxonomies
**Mitigation:**
- Maintain cross-reference tables
- Store multiple classification codes
- Use ISCO as universal baseline

### Risk 5: Quality Control at Scale
**Issue:** Verifying 50,000 jobs is resource-intensive
**Mitigation:**
- Statistical sampling (10% verification)
- Automated quality checks
- Community feedback mechanism
- Progressive improvement model

---

## ✅ SUCCESS METRICS

### Phase 0 Complete When:
1. ✅ 50,000+ jobs cataloged across 195 countries
2. ✅ Average quality score ≥ 80/100
3. ✅ All Tier 1 countries at 90%+ quality
4. ✅ 110+ languages represented
5. ✅ All major classification systems mapped
6. ✅ Verification process operational
7. ✅ Quarterly update system functional
8. ✅ Ready for educational content linking (Pipeline Phase 1)

### Transition to Phase 1: Educational Content Linking
Once Phase 0 is complete, the system will:
- Begin analyzing all educational books/lessons
- Create bidirectional career links
- Populate `educational_content_career_links` table
- Enable "See Related Careers" features
- Launch career learning pathway generation

---

## 📁 DELIVERABLES

### Month 1
- ✅ Database schema (DONE)
- ✅ Phase 0 blueprint (THIS DOCUMENT)
- 195 country research profiles
- Research automation scripts

### Month 6
- 15,000 Tier 1 jobs cataloged
- Quality verification system operational
- First batch ready for content linking

### Month 12
- 50,000+ total jobs cataloged
- 195 countries covered
- Launch-ready catalog
- Maintenance system operational

---

**Status:** ✅ Phase 0 Blueprint Complete
**Next Step:** Populate `phase_0_research_catalog` with 195 countries and begin Tier 1 research
