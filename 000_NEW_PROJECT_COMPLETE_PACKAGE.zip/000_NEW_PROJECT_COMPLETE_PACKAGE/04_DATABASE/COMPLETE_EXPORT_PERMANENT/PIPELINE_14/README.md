# PIPELINE 14: Career Research System

**50,000+ careers with complete data**

## What's Inside

- `PIPELINE_14_DATABASE_SCHEMA.md` - Complete database design
- `20251220144204_create_pipeline_14_career_system.sql` - Ready-to-deploy migration

## Career Database

- 50,000+ career entries
- 10 interconnected tables
- Skills, education, salaries, outlook
- Industry clusters and pathways

## Quick Import

```bash
cp 20251220144204_create_pipeline_14_career_system.sql supabase/migrations/
supabase db push
```

Perfect for career guides, vocational training, and life skills education!
