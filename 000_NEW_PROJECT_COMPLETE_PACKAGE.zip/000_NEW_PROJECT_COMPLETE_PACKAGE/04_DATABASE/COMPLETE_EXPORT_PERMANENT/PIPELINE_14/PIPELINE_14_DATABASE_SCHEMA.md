# Pipeline 14: Career/Jobs/Trades Database Schema Design

**Created:** December 20, 2025
**Purpose:** Database structure for global job catalog and career pathway linking system
**Scope:** 195 countries, 50,000+ careers, bidirectional educational content linking

---

## 🎯 CORE DESIGN PRINCIPLES

1. **Universal Coverage**: Every country gets its own job market data
2. **Educational Integration**: Bidirectional links between books/lessons and careers
3. **Multi-Classification**: Support ISCO (international), SOC (US), and country-specific systems
4. **Localization**: Job titles, descriptions, requirements in 110+ languages
5. **Dynamic Updates**: Job market data refreshes quarterly
6. **Skill Mapping**: Connect educational content to specific job skills

---

## 📊 DATABASE TABLES

### 1. `global_job_catalog`
**Purpose:** Master catalog of all jobs across all countries

```sql
CREATE TABLE global_job_catalog (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Classification Codes
  isco_code VARCHAR(10),              -- International Standard Classification (e.g., "2310")
  soc_code VARCHAR(10),                -- US Standard Occupational Classification (e.g., "25-2021")
  country_code VARCHAR(3) NOT NULL,    -- ISO 3166-1 alpha-3 (e.g., "USA", "GBR", "JPN")
  country_specific_code VARCHAR(20),   -- National classification code

  -- Job Information
  job_title_english TEXT NOT NULL,
  job_title_local TEXT,                -- Title in country's primary language
  job_family VARCHAR(100),             -- Broad category (e.g., "Healthcare", "Technology")
  job_category VARCHAR(100),           -- Subcategory (e.g., "Nursing", "Software Development")

  -- Educational Requirements
  minimum_education_level VARCHAR(50), -- "High School", "Associate", "Bachelor", "Master", "PhD"
  recommended_education_level VARCHAR(50),
  alternative_pathways TEXT[],         -- ["Apprenticeship", "Bootcamp", "Military Training"]

  -- Skills and Competencies
  required_skills TEXT[],              -- Hard skills required
  preferred_skills TEXT[],             -- Nice to have skills
  soft_skills TEXT[],                  -- Communication, teamwork, etc.
  certifications TEXT[],               -- Required or recommended certifications

  -- Experience Requirements
  entry_level_requirements TEXT,
  mid_level_requirements TEXT,
  senior_level_requirements TEXT,

  -- Market Data
  average_salary_local_currency DECIMAL(12,2),
  average_salary_usd DECIMAL(12,2),
  salary_range_low DECIMAL(12,2),
  salary_range_high DECIMAL(12,2),
  currency_code VARCHAR(3),
  job_outlook VARCHAR(50),             -- "Growing", "Stable", "Declining"
  demand_level VARCHAR(50),            -- "High", "Moderate", "Low"
  automation_risk_level VARCHAR(50),   -- "Low", "Moderate", "High"

  -- Working Conditions
  typical_work_environment TEXT,
  physical_demands TEXT,
  work_schedule_type VARCHAR(50),      -- "Full-time", "Part-time", "Shift", "Flexible"
  remote_work_potential VARCHAR(50),   -- "Fully Remote", "Hybrid", "On-site"

  -- Career Progression
  typical_entry_jobs TEXT[],           -- Jobs that lead to this one
  typical_progression_jobs TEXT[],     -- Next career steps
  career_ladder_position INTEGER,      -- 1-10 scale

  -- Content Linking (calculated fields)
  linked_books_count INTEGER DEFAULT 0,
  linked_lessons_count INTEGER DEFAULT 0,
  linked_activities_count INTEGER DEFAULT 0,

  -- Metadata
  data_source VARCHAR(100),            -- "BLS", "Eurostat", "National Agency"
  data_last_updated TIMESTAMPTZ,
  verification_status VARCHAR(50),     -- "Verified", "Pending", "Outdated"
  quality_score INTEGER,               -- 0-100

  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes for performance
CREATE INDEX idx_job_catalog_country ON global_job_catalog(country_code);
CREATE INDEX idx_job_catalog_isco ON global_job_catalog(isco_code);
CREATE INDEX idx_job_catalog_soc ON global_job_catalog(soc_code);
CREATE INDEX idx_job_catalog_family ON global_job_catalog(job_family);
CREATE INDEX idx_job_catalog_category ON global_job_catalog(job_category);
CREATE INDEX idx_job_catalog_education ON global_job_catalog(minimum_education_level);
CREATE INDEX idx_job_catalog_demand ON global_job_catalog(demand_level);
```

---

### 2. `educational_content_career_links`
**Purpose:** Bidirectional mapping between educational content and careers

```sql
CREATE TABLE educational_content_career_links (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Content Reference
  content_type VARCHAR(50) NOT NULL,   -- "book", "chapter", "lesson", "activity", "quiz"
  content_id UUID NOT NULL,
  content_title TEXT,

  -- Career Reference
  job_id UUID REFERENCES global_job_catalog(id) ON DELETE CASCADE,

  -- Link Strength and Type
  relevance_score INTEGER,             -- 0-100, how relevant is this content to this career
  link_type VARCHAR(50),               -- "direct", "foundational", "complementary", "advanced"

  -- Skill Mapping
  skills_taught TEXT[],                -- Which job skills does this content teach
  competencies_developed TEXT[],       -- Broader competencies

  -- Learning Path Integration
  recommended_order INTEGER,           -- Sequence in career learning path
  prerequisite_content_ids UUID[],     -- Other content to complete first
  is_core_requirement BOOLEAN,         -- Must-have vs nice-to-have

  -- Career Stage Relevance
  relevant_for_entry_level BOOLEAN DEFAULT true,
  relevant_for_mid_level BOOLEAN DEFAULT false,
  relevant_for_senior_level BOOLEAN DEFAULT false,

  -- Metadata
  link_created_by VARCHAR(50),         -- "AI_Phase_0", "Manual_Curator", "Algorithm"
  confidence_score INTEGER,            -- 0-100, how confident is this link
  verified_by_expert BOOLEAN DEFAULT false,
  verification_date TIMESTAMPTZ,

  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX idx_career_links_content ON educational_content_career_links(content_type, content_id);
CREATE INDEX idx_career_links_job ON educational_content_career_links(job_id);
CREATE INDEX idx_career_links_relevance ON educational_content_career_links(relevance_score DESC);
CREATE INDEX idx_career_links_type ON educational_content_career_links(link_type);
```

---

### 3. `career_learning_paths`
**Purpose:** Structured pathways from education to career

```sql
CREATE TABLE career_learning_paths (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Career Reference
  job_id UUID REFERENCES global_job_catalog(id) ON DELETE CASCADE,

  -- Path Information
  path_name TEXT NOT NULL,             -- "Software Engineer Career Path"
  path_description TEXT,
  path_type VARCHAR(50),               -- "Traditional", "Accelerated", "Alternative", "Self-Taught"

  -- Duration and Effort
  estimated_duration_months INTEGER,
  estimated_hours_total INTEGER,
  hours_per_week_recommended INTEGER,

  -- Prerequisites
  required_education_level VARCHAR(50),
  prerequisite_knowledge TEXT[],
  starting_skill_level VARCHAR(50),    -- "Beginner", "Intermediate", "Advanced"

  -- Path Structure
  total_stages INTEGER,                -- Number of learning stages
  current_stage_template JSONB,        -- Template for tracking progress

  -- Success Metrics
  completion_rate DECIMAL(5,2),        -- % of learners who complete
  average_time_to_job DECIMAL(6,2),    -- Months to job placement
  success_rate DECIMAL(5,2),           -- % who get job in field

  -- Cost Estimates
  estimated_cost_low DECIMAL(10,2),
  estimated_cost_high DECIMAL(10,2),
  free_resources_available BOOLEAN,

  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_learning_paths_job ON career_learning_paths(job_id);
CREATE INDEX idx_learning_paths_type ON career_learning_paths(path_type);
```

---

### 4. `career_learning_path_stages`
**Purpose:** Individual stages within a learning path

```sql
CREATE TABLE career_learning_path_stages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Path Reference
  path_id UUID REFERENCES career_learning_paths(id) ON DELETE CASCADE,

  -- Stage Details
  stage_number INTEGER NOT NULL,
  stage_name TEXT NOT NULL,            -- "Foundation", "Core Skills", "Advanced Topics"
  stage_description TEXT,

  -- Content Requirements
  required_books UUID[],               -- Books to complete
  required_lessons UUID[],             -- Lessons to complete
  required_activities UUID[],          -- Activities to complete
  required_quizzes UUID[],             -- Quizzes to pass

  -- Learning Outcomes
  skills_acquired TEXT[],
  competencies_developed TEXT[],
  certifications_earned TEXT[],

  -- Progression
  duration_weeks INTEGER,
  minimum_completion_percentage INTEGER, -- % required to pass stage
  recommended_projects TEXT[],

  -- Assessment
  assessment_type VARCHAR(50),         -- "Quiz", "Project", "Portfolio", "Exam"
  passing_criteria TEXT,

  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_path_stages_path ON career_learning_path_stages(path_id);
CREATE INDEX idx_path_stages_number ON career_learning_path_stages(stage_number);
```

---

### 5. `job_skills_taxonomy`
**Purpose:** Standardized skills across all careers

```sql
CREATE TABLE job_skills_taxonomy (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Skill Classification
  skill_name TEXT NOT NULL,
  skill_category VARCHAR(50),          -- "Technical", "Soft", "Domain", "Tools", "Certifications"
  skill_subcategory VARCHAR(100),

  -- Hierarchy
  parent_skill_id UUID REFERENCES job_skills_taxonomy(id),
  skill_level INTEGER,                 -- 1=broad category, 2=skill group, 3=specific skill

  -- Descriptions
  skill_description TEXT,
  skill_keywords TEXT[],               -- For search and matching
  alternative_names TEXT[],            -- Different ways to refer to this skill

  -- Learning Resources
  typical_learning_time_hours INTEGER,
  difficulty_level VARCHAR(50),        -- "Beginner", "Intermediate", "Advanced", "Expert"
  free_learning_available BOOLEAN,

  -- Market Data
  jobs_requiring_count INTEGER,        -- How many jobs require this skill
  average_salary_premium DECIMAL(10,2), -- Extra $ for having this skill
  demand_trend VARCHAR(50),            -- "Rising", "Stable", "Declining"

  -- Educational Content Mapping
  teaching_books_count INTEGER DEFAULT 0,
  teaching_lessons_count INTEGER DEFAULT 0,

  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_skills_name ON job_skills_taxonomy(skill_name);
CREATE INDEX idx_skills_category ON job_skills_taxonomy(skill_category);
CREATE INDEX idx_skills_demand ON job_skills_taxonomy(demand_trend);
```

---

### 6. `job_educational_pathways`
**Purpose:** Links between educational subjects and careers

```sql
CREATE TABLE job_educational_pathways (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Subject Area
  subject_name VARCHAR(100) NOT NULL,  -- "Mathematics", "Biology", "History"
  subject_level VARCHAR(50),           -- "Elementary", "High School", "College"
  grade_levels INTEGER[],              -- [9, 10, 11, 12]

  -- Career Connections
  directly_leads_to UUID[],            -- Job IDs this subject directly prepares for
  indirectly_supports UUID[],          -- Job IDs where this subject helps
  foundational_for UUID[],             -- Job IDs where this is prerequisite

  -- Pathway Strength
  connection_strength VARCHAR(50),     -- "Essential", "Important", "Helpful", "Related"
  supporting_evidence TEXT,

  -- Student Guidance
  why_study_this TEXT,                 -- Career-focused explanation
  real_world_applications TEXT[],
  career_stories TEXT[],               -- Success stories

  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_pathways_subject ON job_educational_pathways(subject_name);
CREATE INDEX idx_pathways_level ON job_educational_pathways(subject_level);
```

---

### 7. `career_addon_generation_queue`
**Purpose:** Track Pipeline 14 addon generation for each career

```sql
CREATE TABLE career_addon_generation_queue (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Career Reference
  job_id UUID REFERENCES global_job_catalog(id) ON DELETE CASCADE,
  country_code VARCHAR(3),

  -- Generation Status
  generation_status VARCHAR(50) DEFAULT 'pending', -- "pending", "in_progress", "completed", "failed"
  priority_level INTEGER DEFAULT 5,   -- 1-10, higher = more urgent

  -- Addons to Generate (8 types)
  career_guides_status VARCHAR(50) DEFAULT 'pending',
  career_guides_id UUID,

  training_manuals_status VARCHAR(50) DEFAULT 'pending',
  training_manuals_id UUID,

  job_prep_workbooks_status VARCHAR(50) DEFAULT 'pending',
  job_prep_workbooks_id UUID,

  skill_assessments_status VARCHAR(50) DEFAULT 'pending',
  skill_assessments_id UUID,

  interview_prep_status VARCHAR(50) DEFAULT 'pending',
  interview_prep_id UUID,

  certification_guides_status VARCHAR(50) DEFAULT 'pending',
  certification_guides_id UUID,

  apprenticeship_materials_status VARCHAR(50) DEFAULT 'pending',
  apprenticeship_materials_id UUID,

  portfolio_projects_status VARCHAR(50) DEFAULT 'pending',
  portfolio_projects_id UUID,

  -- Progress Tracking
  total_addons INTEGER DEFAULT 8,
  completed_addons INTEGER DEFAULT 0,
  failed_addons INTEGER DEFAULT 0,
  completion_percentage DECIMAL(5,2) DEFAULT 0.00,

  -- Resource Usage
  ai_tokens_used INTEGER DEFAULT 0,
  generation_time_seconds INTEGER,
  cost_usd DECIMAL(10,4),

  -- Scheduling
  scheduled_generation_date TIMESTAMPTZ,
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,

  -- Error Handling
  error_message TEXT,
  retry_count INTEGER DEFAULT 0,
  max_retries INTEGER DEFAULT 3,

  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_career_queue_status ON career_addon_generation_queue(generation_status);
CREATE INDEX idx_career_queue_job ON career_addon_generation_queue(job_id);
CREATE INDEX idx_career_queue_priority ON career_addon_generation_queue(priority_level DESC);
CREATE INDEX idx_career_queue_country ON career_addon_generation_queue(country_code);
```

---

### 8. `career_guides` (Pipeline 14 Addon Type 1)
**Purpose:** Store generated career guide addons

```sql
CREATE TABLE career_guides (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Career Reference
  job_id UUID REFERENCES global_job_catalog(id) ON DELETE CASCADE,
  country_code VARCHAR(3),
  language_code VARCHAR(3),

  -- Guide Content (50+ comprehensive aspects)
  job_overview TEXT NOT NULL,
  day_in_the_life TEXT,
  typical_tasks TEXT[],
  work_environment_description TEXT,

  -- Entry Requirements
  education_requirements_detailed TEXT,
  certification_paths TEXT[],
  skill_requirements_detailed JSONB, -- Structured data
  experience_levels JSONB,

  -- Career Development
  entry_level_jobs TEXT[],
  mid_level_progression TEXT[],
  senior_level_options TEXT[],
  career_timeline_infographic TEXT,

  -- Salary and Benefits
  salary_breakdown_by_level JSONB,
  benefits_overview TEXT,
  negotiation_tips TEXT,
  regional_variations JSONB,

  -- Job Search
  where_to_find_jobs TEXT[],
  networking_strategies TEXT,
  resume_tips TEXT,
  cover_letter_examples TEXT,

  -- Interview Preparation
  common_interview_questions TEXT[],
  technical_interview_prep TEXT,
  behavioral_questions TEXT[],
  what_employers_look_for TEXT,

  -- Skills Development
  core_skills_breakdown JSONB,
  how_to_learn_each_skill TEXT,
  recommended_courses TEXT[],
  recommended_books TEXT[],
  free_learning_resources TEXT[],

  -- Industry Insights
  industry_trends TEXT,
  future_outlook TEXT,
  automation_impact TEXT,
  emerging_opportunities TEXT,

  -- Success Stories
  real_career_stories TEXT[],
  quotes_from_professionals TEXT[],
  common_career_paths TEXT[],

  -- Challenges and Solutions
  common_challenges TEXT[],
  how_to_overcome_obstacles TEXT,
  work_life_balance_tips TEXT,

  -- Additional Resources
  professional_associations TEXT[],
  conferences_and_events TEXT[],
  online_communities TEXT[],
  mentorship_opportunities TEXT,

  -- Special Considerations
  diversity_inclusion_info TEXT,
  accommodations_for_disabilities TEXT,
  international_opportunities TEXT,
  remote_work_possibilities TEXT,

  -- Generation Metadata
  generated_by_phase VARCHAR(50),
  ai_models_used TEXT[],
  generation_quality_score INTEGER,
  content_length_words INTEGER,

  -- Format Versions
  pdf_url TEXT,
  epub_url TEXT,
  web_version_url TEXT,

  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_career_guides_job ON career_guides(job_id);
CREATE INDEX idx_career_guides_country ON career_guides(country_code);
CREATE INDEX idx_career_guides_language ON career_guides(language_code);
```

---

### 9. `phase_0_research_catalog`
**Purpose:** Track Phase 0 research for job catalog population

```sql
CREATE TABLE phase_0_research_catalog (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Country Focus
  country_code VARCHAR(3) NOT NULL,
  country_name TEXT,
  research_priority INTEGER,          -- 1-10, higher priority countries first

  -- Research Sources
  primary_data_source TEXT,           -- "BLS", "Eurostat", "National Labor Agency"
  data_source_urls TEXT[],
  api_endpoints TEXT[],
  last_data_refresh TIMESTAMPTZ,

  -- Catalog Status
  total_jobs_identified INTEGER DEFAULT 0,
  jobs_cataloged INTEGER DEFAULT 0,
  jobs_verified INTEGER DEFAULT 0,
  catalog_completion_percentage DECIMAL(5,2) DEFAULT 0.00,

  -- Classification Mapping
  uses_isco BOOLEAN DEFAULT true,
  uses_soc BOOLEAN DEFAULT false,
  national_classification_system TEXT,
  mapping_complexity VARCHAR(50),     -- "Simple", "Moderate", "Complex"

  -- Data Quality
  data_quality_score INTEGER,         -- 0-100
  data_completeness_score INTEGER,    -- 0-100
  verification_status VARCHAR(50),

  -- Research Progress
  research_status VARCHAR(50) DEFAULT 'not_started',
  research_started_date TIMESTAMPTZ,
  research_completed_date TIMESTAMPTZ,

  -- Team Assignment
  assigned_researcher VARCHAR(100),
  assigned_ai_model VARCHAR(50),

  -- Notes
  research_notes TEXT,
  data_challenges TEXT[],
  special_considerations TEXT[],

  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_phase0_country ON phase_0_research_catalog(country_code);
CREATE INDEX idx_phase0_status ON phase_0_research_catalog(research_status);
CREATE INDEX idx_phase0_priority ON phase_0_research_catalog(research_priority DESC);
```

---

## 🔗 RELATIONSHIP SUMMARY

```
global_job_catalog (50,000+ jobs)
    ├── educational_content_career_links (bidirectional mapping)
    ├── career_learning_paths (structured pathways)
    │   └── career_learning_path_stages (stage breakdown)
    ├── career_addon_generation_queue (track generation)
    └── career_guides (and 7 other addon types)

job_skills_taxonomy (10,000+ skills)
    └── Links to educational_content_career_links via skills_taught[]

job_educational_pathways (subject → career mapping)
    └── Links to global_job_catalog via directly_leads_to[]

phase_0_research_catalog (195 countries)
    └── Drives population of global_job_catalog
```

---

## 📊 ESTIMATED DATA VOLUMES

| Table | Estimated Rows | Growth Rate |
|-------|---------------|-------------|
| `global_job_catalog` | 50,000+ | +5% annually |
| `educational_content_career_links` | 500,000+ | +20% as content grows |
| `career_learning_paths` | 10,000+ | +10% annually |
| `career_learning_path_stages` | 80,000+ | Linked to paths |
| `job_skills_taxonomy` | 10,000+ | +5% annually |
| `job_educational_pathways` | 2,000+ | Stable |
| `career_addon_generation_queue` | 50,000 (active) | Cycles through |
| `career_guides` | 50,000+ | One per job |
| `phase_0_research_catalog` | 195 | Static (countries) |

**Total Estimated Records:** 750,000+ across all Pipeline 14 tables

---

## 🎯 KEY FEATURES OF THIS DESIGN

### 1. **Scalability**
- Handles 50,000+ careers across 195 countries
- Supports 110+ languages via translation tables
- Can grow to millions of career-content links

### 2. **Flexibility**
- Multiple job classification systems (ISCO, SOC, national)
- Extensible addon types (easily add new types)
- JSON fields for complex, evolving data structures

### 3. **Performance**
- Strategic indexing on all common query patterns
- Denormalized counts for fast dashboards
- Partitioning potential by country_code

### 4. **Data Quality**
- Quality scores and verification status
- Confidence scoring on AI-generated links
- Source tracking for audit trails

### 5. **AI Integration**
- Queue system for managing AI generation
- Tracks tokens, cost, and performance
- Retry logic for failed generations

### 6. **Educational Integration**
- Bidirectional linking preserves context
- Relevance scoring for intelligent recommendations
- Learning path sequencing for structured progression

---

## 🔄 NEXT STEPS

1. **Create Migration File** - Convert this schema to Supabase migration SQL
2. **Add RLS Policies** - Secure each table appropriately
3. **Design Phase 0 Blueprint** - Research workflow for cataloging 50,000+ jobs
4. **Build Linking Algorithm** - AI system to create educational_content_career_links
5. **Create Addon Generation System** - Pipeline for 8 career addon types
6. **Populate Initial Data** - Start with high-priority countries (USA, UK, CA, AU)

---

**Status:** ✅ Schema design complete, ready for migration creation
