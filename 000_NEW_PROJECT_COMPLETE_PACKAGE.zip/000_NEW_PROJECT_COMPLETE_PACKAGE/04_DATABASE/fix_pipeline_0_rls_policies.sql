/*
  # Fix RLS Policies for Pipeline 0 Tables

  ## Purpose
  Pipeline 0 discovery script needs read access to knowledge tables and write
  access to discovery tables. These policies enable the discovery system to work.

  ## Tables Affected
  - knowledge_domains (allow public read - non-sensitive data)
  - knowledge_fields (allow public read)
  - knowledge_subjects (allow public read)
  - discovery_sessions (allow anon insert/update for system operations)
  - discovery_log (allow anon insert for system logging)
  - tag_taxonomy (allow public read - needed for tag lookups)
  - subject_tags (allow anon insert - needed for tagging)

  ## Security
  All write operations are for system discovery only. User data remains protected.
*/

-- Allow public read access to knowledge_domains
CREATE POLICY "Allow public read access to knowledge_domains"
  ON knowledge_domains
  FOR SELECT
  TO public
  USING (true);

-- Allow public read access to knowledge_fields
CREATE POLICY "Allow public read access to knowledge_fields"
  ON knowledge_fields
  FOR SELECT
  TO public
  USING (true);

-- Allow public read access to knowledge_subjects
CREATE POLICY "Allow public read access to knowledge_subjects"
  ON knowledge_subjects
  FOR SELECT
  TO public
  USING (true);

-- Allow public read access to tag_taxonomy (needed for tag lookups)
CREATE POLICY "Allow public read access to tag_taxonomy"
  ON tag_taxonomy
  FOR SELECT
  TO public
  USING (true);

-- Allow anon users to insert discovery sessions (system operations)
CREATE POLICY "Allow anon insert discovery sessions"
  ON discovery_sessions
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Allow anon users to update their own discovery sessions
CREATE POLICY "Allow anon update discovery sessions"
  ON discovery_sessions
  FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

-- Allow anon users to select discovery sessions
CREATE POLICY "Allow anon select discovery sessions"
  ON discovery_sessions
  FOR SELECT
  TO anon
  USING (true);

-- Allow anon users to insert discovery log entries
CREATE POLICY "Allow anon insert discovery log"
  ON discovery_log
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Allow anon users to insert into knowledge_fields
CREATE POLICY "Allow anon insert knowledge fields"
  ON knowledge_fields
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Allow anon users to insert into knowledge_subjects
CREATE POLICY "Allow anon insert knowledge subjects"
  ON knowledge_subjects
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Allow anon users to insert subject tags
CREATE POLICY "Allow anon insert subject tags"
  ON subject_tags
  FOR INSERT
  TO anon
  WITH CHECK (true);
