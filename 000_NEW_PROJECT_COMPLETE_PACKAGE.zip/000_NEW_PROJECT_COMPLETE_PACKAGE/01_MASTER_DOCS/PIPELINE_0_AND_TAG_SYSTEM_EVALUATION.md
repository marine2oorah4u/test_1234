# 🎯 PIPELINE 0 & TAG SYSTEM - COMPLETE EVALUATION

**Date:** January 2, 2026
**Purpose:** Define Pipeline 0 scope, tag taxonomy, and checklist requirements

---

## 📌 QUICK ANSWERS

### **Q1: "What are domains?"**
**Domains** are the 38 top-level categories of human knowledge (like "Natural Sciences", "Social Sciences", "Applied Sciences"). They're the highest level in our hierarchy:
- **Domains** → Fields → Subjects → Topics → Subtopics

---

## 🎯 PIPELINE 0: TRUE PURPOSE (CLARIFIED)

### **WHAT PIPELINE 0 DOES:**

#### ✅ **1. Subject Discovery & Organization**
- Discover ALL subjects that need books (~5,000 subjects)
- Organize into: Domains (38) → Fields (~300) → Subjects (~5,000)
- Research each subject deeply to identify:
  - Natural sub-categories (e.g., Anatomy → Cardiovascular, Skeletal, Muscular...)
  - Content scope (broad vs focused)
  - Complexity level
  - Natural divisions

**Example:**
```
Subject: First Aid
Pipeline 0 discovers these sub-categories:
  - Basic First Aid (home/workplace)
  - Wilderness First Aid (remote areas)
  - Advanced First Aid (pre-EMT level)
  - Pediatric First Aid (children)
  - Sports First Aid (athletics)

Pipeline 0 flags: "Medium complexity, recommend 3-5 focused books"
```

#### ✅ **2. Complete Tag System Creation**
- Define all 15 tag categories
- Create initial ~1,000 core tags
- Allow discovery of more tags as system runs
- Map tags to pipeline triggers

#### ✅ **3. API Catalog & Assignment**
- Master list of ALL APIs available
- Map specific APIs to each subject
- Identify gaps (subjects needing APIs we don't have)

#### ✅ **4. AI Model Assignment**
- Which AI(s) for each subject
- Consensus requirements
- Quality thresholds

#### ✅ **5. Master Checklist Generation**
- Complete organized list of all 5,000 subjects
- Status tracking (discovered, verified, ready, in-progress, complete)
- Priority assignment
- Dependencies mapped

---

### **WHAT PIPELINE 0 DOES NOT DO:**

❌ **Determine exact book sizes** - Pipeline 1 decides during generation
❌ **Write content** - Only creates the discovery checklist
❌ **Generate books** - Just says "these books need to exist"

---

### **WHAT PIPELINE 0 "RECOMMENDS" (Gray Area):**

🔶 **Complexity Flags:**
- "Very High Complexity" = Likely needs master + many sub-books
- "High Complexity" = Likely needs master + some sub-books
- "Medium/Low" = Probably single comprehensive book

🔶 **Natural Divisions:**
- If Pipeline 0 finds clear categorical divisions (body systems, historical periods, geographic regions), it flags them
- Pipeline 1 uses these as **recommendations**, not requirements

---

## 📋 COMPLETE TAG TAXONOMY (15 Categories)

### **1. SUBJECT_HIERARCHY**
Hierarchical tags showing knowledge structure
```
Examples:
- science:biology:anatomy:cardiovascular
- math:algebra:linear-algebra
- history:modern:20th-century:world-war-2
```

### **2. PIPELINE_TRIGGERS**
Tags that tell other pipelines to activate features
```
Examples:
- addon:activity-pack
- addon:flashcards
- addon:worksheet-set
- addon:quiz-pack
- addon:lesson-plans
- format:3d-models
- format:interactive-diagrams
- format:audio-heavy
- disability:dyslexia-critical (needs special attention)
```

### **3. READING_LEVELS**
Which reading levels apply to this subject
```
Examples:
- level:elementary
- level:middle-school
- level:college
- level:professional
- level:plain-language
- level:quick-reference
```

### **4. DISABILITY_REQUIREMENTS**
Specific disability adaptations needed
```
Examples:
- disability:dyslexia-friendly-critical
- disability:dyscalculia-adaptations
- disability:color-blind-safe
- disability:screen-reader-essential
- disability:aac-symbols-helpful
- disability:adhd-chunking-critical
```

### **5. FORMAT_NEEDS**
Special format requirements
```
Examples:
- format:requires-color-printing
- format:black-white-adequate
- format:requires-3d-models
- format:video-demonstrations-critical
- format:audio-narration-helpful
- format:interactive-required
- format:hands-on-materials
```

### **6. COMPLEXITY_LEVEL**
Content complexity (used by Pipeline 0 to flag splitting needs)
```
Examples:
- complexity:very-high
- complexity:high
- complexity:medium
- complexity:low
- complexity:multi-tier (needs beginner/intermediate/advanced)
```

### **7. CONTENT_TYPE**
Nature of the content
```
Examples:
- content:hands-on
- content:theoretical
- content:practical-application
- content:project-based
- content:experimental
- content:observational
- content:calculation-heavy
- content:memorization-intensive
- content:critical-thinking
```

### **8. AGE_APPROPRIATENESS**
Age ranges (broader than reading levels)
```
Examples:
- age:5-8
- age:9-12
- age:13-17
- age:18-plus
- age:adult-only (sensitive topics)
```

### **9. CAREER_CONNECTIONS**
Related careers
```
Examples:
- career:nursing
- career:engineering:civil
- career:education:k12
- career:culinary
- career:automotive-tech
```

### **10. STANDARDS_ALIGNMENT**
Educational standards
```
Examples:
- standard:common-core:math:grade-5
- standard:ngss:earth-science:middle
- standard:ap:biology
- standard:ib:chemistry:hl
```

### **11. USER_GROUPS**
Which of the 35 user groups need this
```
Examples:
- group:k12-students
- group:adult-learners
- group:homeschool
- group:special-education
- group:corporate-training
- group:scouts
```

### **12. SPECIAL_COLLECTIONS**
Belongs to themed collections
```
Examples:
- collection:scouts:merit-badge
- collection:library:adult-literacy
- collection:homeschool:grade-3-science
- collection:career-pathway:nursing
```

### **13. GEOGRAPHY_CULTURE**
Geographic or cultural contexts
```
Examples:
- geo:island-communities
- geo:rural
- geo:urban
- geo:arctic
- geo:tropical
- geo:maritime
- culture:indigenous
- culture:multicultural
```

### **14. LANGUAGE_TRANSLATION**
Translation needs/availability
```
Examples:
- lang:needs-translation
- lang:available-spanish
- lang:available-french
- lang:high-demand:mandarin
- lang:indigenous:navajo
```

### **15. SAFETY_REQUIREMENTS**
Safety considerations
```
Examples:
- safety:chemical-hazards
- safety:physical-activity
- safety:sharp-tools
- safety:electrical
- safety:fire-risk
- safety:emotional-content-warning
- safety:age-restriction
```

---

## 🔄 PIPELINE 1 RULES: When to Split Books

Pipeline 1 decides splitting based on **research findings**:

### **AUTO-SPLIT TRIGGERS:**
1. **Topic Count > 100:** If research finds 100+ distinct subtopics → needs sub-books
2. **Master Outline > 800 pages:** If comprehensive outline would be 800+ pages → needs sub-books
3. **Natural Categories Exist:** If subject has 5+ clear categorical divisions → consider sub-books
4. **Multiple Difficulty Tiers:** If content naturally splits into beginner/intermediate/advanced → consider tiered books

### **EXAMPLES:**

**Anatomy (Very High Complexity):**
- Pipeline 0 flags: "Very High Complexity, recommend master + sub-books"
- Pipeline 1 research finds: 11 body systems, 200+ major topics
- Pipeline 1 decides:
  - Master Book (1200 pages, comprehensive reference)
  - 11 Sub-Books (100-150 pages each, system-focused)

**First Aid (Medium Complexity):**
- Pipeline 0 flags: "Medium Complexity, multiple contexts"
- Pipeline 1 research finds: 3 main contexts (basic, wilderness, advanced)
- Pipeline 1 decides:
  - 3 Focused Books (no master needed, contexts are distinct)

**Bird Watching (Low Complexity):**
- Pipeline 0 flags: "Low Complexity, single comprehensive book adequate"
- Pipeline 1 research finds: Can cover comprehensively in 200-250 pages
- Pipeline 1 decides:
  - 1 Comprehensive Book (250 pages)

---

## 📊 WHICH PIPELINES NEED CHECKLISTS?

### **Pipelines with Built-in Checklists:**

| Pipeline | Checklist Type | Why |
|----------|---------------|-----|
| **0** | Subject Discovery Checklist | Track all 5,000 subjects |
| **1** | Book Generation Checklist | Track book progress through 18 steps |
| **5** | Addon Features Checklist | Track 739 features per book |
| **9** | Translation Checklist | Track 110 languages per book |
| **12** | Country Checklist | Track 195 countries |

### **Pipelines Using Tag-Driven Triggers (No Separate Checklist):**

Pipelines 2-4, 6-8, 10-11, 13-37 use **tags** to determine what runs:
- If book has `level:elementary` tag → Pipeline 2a runs
- If book has `addon:activity-pack` tag → Pipeline 5 creates activity packs
- If book has `group:scouts` tag → Pipeline 13 packages for scouts

---

## 🏗️ PIPELINE 0 DATABASE STRUCTURE (Current Schema)

### **Tables Created:**
1. ✅ `knowledge_domains` (38 domains)
2. ✅ `knowledge_fields` (~300 fields)
3. ✅ `knowledge_subjects` (~5,000 subjects)
4. ✅ `knowledge_topics` (~50,000 topics)
5. ✅ `knowledge_subtopics` (~250,000 subtopics)
6. ✅ `tag_categories` (15 categories)
7. ✅ `tag_taxonomy` (10,000+ tags)
8. ✅ `subject_tags` (many-to-many)
9. ✅ `topic_tags` (many-to-many)
10. ✅ `api_catalog` (master API list)
11. ✅ `subject_api_requirements` (APIs per subject)
12. ✅ `master_book_specs` (book specifications)
13. ✅ `discovery_sessions` (track discovery runs)
14. ✅ `discovery_log` (detailed discovery logs)
15. ✅ `pipeline_readiness` (readiness tracking)

---

## 📝 PIPELINE-SPECIFIC TAG NEEDS

### **Pipeline 1: Master Book Generation**
Tags needed:
- `complexity:*`
- `career:*`
- `standard:*`
- `format:*` (special needs)

### **Pipeline 2: Reading Level Adaptations**
Tags needed:
- `level:elementary` → triggers Pipeline 2a
- `level:middle-school` → triggers Pipeline 2b
- `level:college` → triggers Pipeline 2d
- etc.

### **Pipeline 3: Disability Adaptations**
Tags needed:
- `disability:dyslexia-friendly-critical` → triggers Pipeline 3.24
- `disability:adhd-chunking-critical` → triggers Pipeline 3.25
- `disability:color-blind-safe` → triggers Pipeline 3.26
- etc.

### **Pipeline 4: Format Conversions**
Tags needed:
- `format:requires-3d-models`
- `format:audio-narration-helpful`
- `format:interactive-required`

### **Pipeline 5: Educational Addons**
Tags needed:
- `addon:activity-pack` → triggers activity pack generation
- `addon:worksheet-set` → triggers worksheet generation
- `addon:quiz-pack` → triggers quiz generation
- `content:hands-on` → affects activity type

### **Pipeline 9: Translations**
Tags needed:
- `lang:high-demand:spanish`
- `lang:available-french`
- `geo:island-communities` (might need specific language)

### **Pipeline 11: Special Collections**
Tags needed:
- `collection:scouts:merit-badge`
- `geo:island-communities`
- `group:homeschool`
- Uses AI to auto-bundle based on tags

### **Pipeline 12: Country-Specific**
Tags needed:
- `geo:india`
- `culture:indigenous`
- `geo:rural`

### **Pipeline 13: User Group Packaging**
Tags needed:
- `group:k12-students`
- `group:adult-learners`
- `group:special-education`

### **Pipeline 14: Career Pathways**
Tags needed:
- `career:nursing`
- `career:engineering:civil`
- `career:education:k12`

---

## 🎯 HANDLING SPECIAL CONCERNS

### **Scouts & Youth Programs (Pipeline 15):**
- **Separate from main library:** Yes
- **When to define:** When building Pipeline 15
- **Tags:** `collection:scouts:*`, `group:youth-organizations`

### **Job/Career Content (Pipeline 14):**
- **How to handle:** Career Pathways System maps 400+ careers to content
- **Tags:** `career:*` on relevant subjects
- **When:** Phase 2 (next 6-12 months)

### **Country-Specific (Pipeline 12):**
- **When to handle:** As we work on each country
- **Process:** Pipeline 12 discovers unique needs per country
- **Tags:** `geo:*`, `culture:*`

---

## 🚀 NEXT STEPS FOR PIPELINE 0

### **Phase 1: Setup (Now)**
1. ✅ Database schema created
2. ✅ 38 domains defined
3. 🔄 Seed 15 tag categories
4. 🔄 Create ~1,000 core tags
5. 🔄 Build API catalog (100+ APIs)

### **Phase 2: Discovery (2-4 weeks)**
6. Build AI discovery script
7. Discover all ~300 fields
8. Discover all ~5,000 subjects
9. For each subject, discover:
   - Sub-categories
   - Complexity level
   - Natural divisions
   - API requirements
10. Apply tags

### **Phase 3: Organization (1-2 weeks)**
11. Generate master checklist
12. Build dashboard
13. Create "Ready for Pipeline 1" queue

---

## ✅ DECISIONS MADE

1. **Tag Creation:** Start with 1,000 core tags, discover more as needed ✓
2. **Sub-book Recommendations:** Pipeline 0 flags complexity, Pipeline 1 decides splitting ✓
3. **Start Scope:** Begin with 1-2 domains to test, then scale ✓
4. **Tag Types:** 15 categories defined ✓
5. **Checklist Approach:** Pipeline 0, 1, 5, 9, 12 have explicit checklists; others use tag triggers ✓

---

**END OF EVALUATION**
