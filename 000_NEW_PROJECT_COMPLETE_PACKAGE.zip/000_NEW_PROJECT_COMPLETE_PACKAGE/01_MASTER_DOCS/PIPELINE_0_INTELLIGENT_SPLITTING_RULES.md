# PIPELINE 0: INTELLIGENT SPLITTING RULES & QUALITY STANDARDS

**Problem to Solve:** Avoid over-splitting into useless tiny chunks, while ensuring comprehensive coverage

---

## CORE PRINCIPLE: MINIMUM VIABLE BOOK

```
RULE #1: No book or sub-book under 15,000 words
=============================================

If a topic can't sustain 15,000 words of quality content,
it should be COMBINED with related topics, not published alone.

Exception: Quick reference guides (5,000-10,000 words) -
but these are marked as "reference" format, not full books.
```

---

## SMART SPLITTING DECISION TREE

### Question 1: Is this a SUBJECT or a TOPIC?

```
SUBJECT = Worthy of master book
TOPIC   = Part of a master book

Examples:
=========

SUBJECT (gets master book):
- Human Anatomy (thousands of concepts, 100k+ words)
- First Aid (hundreds of procedures, 50k+ words)
- Algebra (complete mathematical system, 75k+ words)

TOPIC (part of a book, NOT separate):
- "The Radius Bone" (500 words) → Part of "Skeletal System"
- "CPR" (2,000 words) → Part of "First Aid"
- "Solving Linear Equations" (3,000 words) → Part of "Algebra"
```

**AI Decision Logic:**
```python
if estimated_content_words < 40000:
    classification = "TOPIC (not a subject)"
    recommendation = "Include in larger subject"
elif estimated_content_words >= 40000:
    classification = "SUBJECT (worthy of master book)"
    recommendation = "Create as standalone subject"
```

---

## HIERARCHY DEPTH LIMITS

### Maximum Breakdown Depth

```
Level 1: DOMAIN          (38 total)         Example: Natural Sciences
Level 2: FIELD           (5-15 per domain)  Example: Biology
Level 3: SUBJECT         (10-30 per field)  Example: Human Anatomy
Level 4: TOPIC           (10-50 per subject) Example: Skeletal System
Level 5: SUBTOPIC        (5-20 per topic)   Example: Upper Limb Bones
Level 6: CONCEPT         (3-10 per subtopic) Example: Radius, Ulna, Humerus

STOP AT LEVEL 6. DO NOT GO DEEPER.
```

**Why stop at Level 6?**
- Level 7 would be individual facts (too granular)
- Master book covers Levels 4-6 in full detail
- Sub-books split at Level 4 (topics), not deeper

---

## SUB-BOOK SPLITTING RULES

### Rule 1: Split by TOPICS (Level 4), Never Deeper

```
✅ GOOD SPLIT (Topic-based):

Master Book: "Human Anatomy"
├── Sub-Book 1: "Skeletal System" (20k words)
├── Sub-Book 2: "Muscular System" (25k words)
├── Sub-Book 3: "Circulatory System" (22k words)
├── Sub-Book 4: "Nervous System" (28k words)
└── Sub-Book 5: "Digestive System" (18k words)

Each sub-book contains:
- Multiple subtopics (Level 5)
- Multiple concepts (Level 6)
- Sufficient depth to be useful standalone
```

```
❌ BAD SPLIT (Too granular):

Master Book: "Human Anatomy"
├── Sub-Book 1: "The Femur" (800 words) ← TOO SMALL
├── Sub-Book 2: "The Tibia" (600 words) ← TOO SMALL
├── Sub-Book 3: "The Patella" (400 words) ← TOO SMALL
└── ... 206 more mini-books ← USELESS

This creates unusable fragments!
```

---

### Rule 2: Minimum Sub-Book Size

```
MINIMUM: 15,000 words per sub-book
IDEAL:   20,000 - 30,000 words per sub-book
MAXIMUM: 50,000 words per sub-book

If a topic has < 15,000 words:
→ COMBINE with related topics
→ Don't create a separate sub-book
```

---

### Rule 3: Smart Grouping

```
When topics are too small individually:

Example: "First Aid" master book

❌ BAD: Split each procedure into tiny books
- "CPR" (2,000 words)
- "Heimlich Maneuver" (1,500 words)
- "Treating Burns" (2,500 words)
Total: 200 micro-books

✅ GOOD: Group related procedures
- "Emergency Response Basics" (18k words)
  ├── CPR (2k)
  ├── Heimlich (1.5k)
  ├── Shock treatment (2k)
  ├── Unconsciousness (3k)
  └── Emergency assessment (9.5k)

- "Wound Care" (22k words)
  ├── Cuts and scrapes (4k)
  ├── Burns (4k)
  ├── Puncture wounds (3k)
  ├── Infection prevention (5k)
  └── Bandaging techniques (6k)

Result: 3-5 substantial sub-books instead of 200 useless ones
```

---

## SUBJECT QUALIFICATION CRITERIA

### To Be a SUBJECT (worthy of master book):

```
MINIMUM REQUIREMENTS:
====================

1. Estimated content: 40,000+ words
2. Contains 10+ distinct topics (Level 4)
3. Has clear scope and boundaries
4. Teachable as complete unit
5. Appears in academic/professional curricula
6. Has sufficient reference materials
7. Has real-world applications
8. Can sustain 8+ reading levels (Pipeline 2)

If ANY requirement fails → Downgrade to TOPIC within larger subject
```

---

## EXAMPLES: GOOD vs BAD SUBJECTS

### ✅ GOOD SUBJECTS (Pass all criteria)

```
SUBJECT: "Human Anatomy"
========================
✓ Content: 150,000+ words possible
✓ Topics: 11 major body systems
✓ Scope: Complete structure of human body
✓ Teachable: Yes (standard course)
✓ Curricula: Medical schools, nursing programs
✓ References: Thousands of textbooks
✓ Applications: Medicine, fitness, art
✓ Reading levels: Elementary to professional

SPLIT METHOD: By body system (11 sub-books)
```

```
SUBJECT: "Algebra"
==================
✓ Content: 80,000+ words possible
✓ Topics: 15+ major concept areas
✓ Scope: Complete algebraic system
✓ Teachable: Yes (standard course)
✓ Curricula: Grades 7-12, college
✓ References: Thousands of textbooks
✓ Applications: Math, science, engineering
✓ Reading levels: Elementary to expert

SPLIT METHOD: By complexity (beginner/intermediate/advanced)
```

---

### ❌ BAD SUBJECTS (Should be topics instead)

```
NOT A SUBJECT: "The Radius Bone"
=================================
✗ Content: 1,000 words max
✗ Topics: Only 3-4 minor aspects
✗ Scope: Single bone, too narrow
✗ Teachable: Not standalone (part of anatomy)
✗ Curricula: Never taught alone
✗ References: Only in larger anatomy texts
✗ Applications: Limited alone
✗ Reading levels: Can't sustain 8 versions

DECISION: Make this a SUBTOPIC within:
- Subject: Human Anatomy
- Topic: Skeletal System
- Subtopic: Upper Limb Bones
- Concept: Radius
```

```
NOT A SUBJECT: "How to Tie a Shoe"
===================================
✗ Content: 500 words max
✗ Topics: Only 1-2 methods
✗ Scope: Single skill, too narrow
✗ Teachable: Not a course
✗ Curricula: Not in any curriculum
✗ References: No dedicated textbooks
✗ Applications: Very limited
✗ Reading levels: Can't sustain adaptations

DECISION: Make this a CONCEPT within:
- Subject: Life Skills
- Topic: Personal Care Basics
- Subtopic: Dressing Skills
- Concept: Shoe Tying Methods
```

---

## AI VALIDATION RULES

### Multi-AI Consensus Required

```
For EACH potential subject, 3 AIs must answer:

QUESTION SET:
============

1. Can this sustain 40,000+ words of quality content? (Y/N)
2. Does this appear as standalone course in schools? (Y/N)
3. Are there 10+ major topics within this? (Y/N)
4. Can we find 5+ authoritative textbooks on this alone? (Y/N)
5. Is this too narrow (part of something bigger)? (Y/N)
6. Would someone buy a full book on this topic? (Y/N)

PASSING SCORE: 5/6 Yes answers (with #5 being No)

CONSENSUS REQUIREMENT: 2 out of 3 AIs must agree
```

---

## WORD COUNT CALIBRATION

### How to Estimate Content Depth

```
QUESTION: "How many words can we write about X?"

METHOD 1: Textbook Analysis
============================
AI searches for existing textbooks on topic
Average page count × 300 words/page = estimate

Example: "Human Anatomy" textbooks
- Average: 800 pages
- 800 × 300 = 240,000 words
- Assessment: ✓ Definitely a subject

Example: "The Femur Bone"
- Average: 2-3 pages in anatomy books
- 3 × 300 = 900 words
- Assessment: ✗ Not a subject (just a concept)


METHOD 2: Curriculum Hour Analysis
===================================
Standard course hours × 2,000 words/hour = estimate

Example: "Algebra"
- Typical course: 120 hours
- 120 × 2,000 = 240,000 words possible
- But focused textbook: 80,000 words
- Assessment: ✓ Subject

Example: "Shoe Tying"
- Typical lesson: 0.25 hours
- 0.25 × 2,000 = 500 words
- Assessment: ✗ Concept only


METHOD 3: Topic Enumeration
============================
AI lists all possible topics within subject
Count topics × average words per topic

Example: "First Aid"
- Topics: 45 procedures/conditions
- Average 1,200 words each
- 45 × 1,200 = 54,000 words
- Assessment: ✓ Subject

Example: "CPR"
- Sub-topics: 4 (adult, child, infant, choking)
- Average 500 words each
- 4 × 500 = 2,000 words
- Assessment: ✗ Topic within First Aid
```

---

## SPLIT DECISION ALGORITHM

```python
def should_split_into_subbooks(subject):
    """
    Determine if subject needs sub-books and how to split
    """

    # Calculate total word count
    total_words = estimate_total_words(subject)

    # Count major topics
    major_topics = count_level_4_topics(subject)

    # Calculate complexity variance
    complexity_variance = analyze_complexity_range(subject)

    # DECISION TREE

    if total_words < 50000:
        return {
            "split": False,
            "reason": "Content too small for splitting",
            "books": 1,
            "method": "single_comprehensive_book"
        }

    if total_words >= 100000 and major_topics >= 8:
        return {
            "split": True,
            "reason": "Large content with natural topic breaks",
            "books": major_topics,
            "method": "split_by_topic",
            "min_subbook_words": 15000
        }

    if complexity_variance >= 40:  # Big difficulty spread
        return {
            "split": True,
            "reason": "Wide complexity range",
            "books": 3,
            "method": "split_by_difficulty",
            "levels": ["beginner", "intermediate", "advanced"]
        }

    if 50000 <= total_words < 100000 and major_topics >= 5:
        # Medium-sized with clear topics
        # Group topics into 3-4 sub-books
        topics_per_book = major_topics // 3
        return {
            "split": True,
            "reason": "Medium size with natural groupings",
            "books": 3,
            "method": "group_related_topics",
            "topics_per_book": topics_per_book
        }

    # Default: single book
    return {
        "split": False,
        "reason": "Best kept as single comprehensive work",
        "books": 1,
        "method": "single_comprehensive_book"
    }
```

---

## QUALITY CHECKS

### Automated Quality Checks for Each Subject

```
CHECK 1: Content Depth
======================
✓ Total estimated words >= 40,000
✓ At least 10 Level-4 topics identified
✓ Each topic has 3+ subtopics
✓ Each subtopic has 2+ concepts
✗ FAIL: Flag for human review if any fail


CHECK 2: Splitting Logic
=========================
✓ If split, each sub-book >= 15,000 words
✓ Sub-books have logical grouping
✓ No orphaned concepts (all content covered)
✓ Sub-books can be read independently
✗ FAIL: Recalculate split or combine


CHECK 3: Coverage Completeness
===============================
✓ Compare to 3 authoritative textbooks
✓ All major topics from textbooks included
✓ No major gaps in coverage
✓ Appropriate depth for target audience
✗ FAIL: Research additional topics


CHECK 4: Hierarchy Logic
=========================
✓ No "only child" topics (1 topic under field)
✓ No "orphan concepts" (concepts with no home)
✓ Balanced tree (similar depth across branches)
✓ Meaningful level transitions
✗ FAIL: Restructure hierarchy


CHECK 5: API/Data Sources
==========================
✓ At least 2 authoritative sources identified
✓ Fact-checking APIs available
✓ Image sources identified
✓ Update frequency appropriate for content
✗ FAIL: Research additional sources
```

---

## EXAMPLE: SMART BREAKDOWN

### Case Study: "Biology" Field

```
DOMAIN: Natural Sciences
FIELD: Biology

SUBJECTS within Biology:
========================

1. Cell Biology (50k words, 12 topics)
   ✓ Qualifies as subject
   → Single comprehensive book (no split)

2. Genetics (80k words, 15 topics)
   ✓ Qualifies as subject
   → Split into 3 sub-books by topic groups:
      - Molecular Genetics (28k words)
      - Population Genetics (26k words)
      - Applied Genetics (26k words)

3. Human Anatomy (150k words, 11 topics)
   ✓ Qualifies as subject
   → Split into 11 sub-books by body system:
      - Skeletal System (18k words)
      - Muscular System (22k words)
      - [etc - each system 15-25k words]

4. Zoology (200k words, 30+ topics)
   ✓ Qualifies as subject
   → Split into 8 sub-books by animal groups:
      - Mammals (32k words)
      - Birds (28k words)
      - Reptiles & Amphibians (25k words)
      - Fish (22k words)
      - Invertebrates (35k words)
      - [etc]

NOT SUBJECTS (just topics):
===========================

❌ "Mitochondria" (2k words)
   → TOPIC within Cell Biology subject
   → Part of "Cellular Organelles" topic

❌ "DNA Structure" (3k words)
   → TOPIC within Genetics subject
   → Part of "Molecular Basis" topic

❌ "The Heart" (5k words)
   → TOPIC within Human Anatomy subject
   → Part of "Circulatory System" sub-book
```

---

## FILE STRUCTURE STANDARDS

### Consistent Naming Convention

```
/domains/
├── [##]_[domain-slug]/
│   ├── _domain_metadata.json
│   ├── fields/
│   │   ├── [field-slug]/
│   │   │   ├── _field_metadata.json
│   │   │   ├── subjects/
│   │   │   │   ├── [subject-slug]/
│   │   │   │   │   ├── _subject_metadata.json
│   │   │   │   │   ├── master_book_spec.json
│   │   │   │   │   ├── topics/
│   │   │   │   │   │   ├── [topic-slug].json
│   │   │   │   │   ├── api_requirements.json
│   │   │   │   │   └── sub_books/
│   │   │   │   │   │   ├── [subbook-slug].json

RULES:
======
- All slugs: lowercase, hyphens only, no special chars
- Numbering: Zero-padded to 2 digits (01, 02, ... 38)
- Metadata files: Always start with underscore
- No spaces in filenames ever
- Maximum depth: 6 levels from root
```

---

## SUMMARY: THE SMART SYSTEM

```
✅ PREVENTS:
- Over-splitting into useless mini-books
- Under-splitting that creates overwhelming books
- Inconsistent depth across subjects
- Orphaned concepts with no home
- Arbitrary hierarchy decisions

✅ ENSURES:
- Every book has 15k+ words (substantial)
- Logical grouping of related content
- Consistent quality across all subjects
- Complete coverage without gaps
- Reusable across all 37 pipelines

✅ VALIDATES:
- Multi-AI consensus on decisions
- Automated quality checks
- Human review for edge cases
- Reference against authoritative sources
- Mathematical verification of word counts
```

---

**Status:** RULES DEFINED, READY FOR IMPLEMENTATION
**Next Step:** Apply these rules to AI discovery prompts
