# PIPELINE 0: CURRENT STATE & WORKFLOW EXPLAINED

## CONFUSION POINT: Two Different "Pipeline 0s"

### OLD Pipeline 0 (Ignore This)
- Location: `database_migrations_ready_to_apply/COMPLETE_EXPORT_PERMANENT/PIPELINE_0/`
- Just a career research blueprint (50k job catalog)
- NOT what we're building now

### NEW Pipeline 0 (This is what we're doing)
- Location: Database tables + blueprint document
- Master Knowledge Discovery System
- Organizing ALL learnable knowledge

---

## WHAT EXISTS RIGHT NOW

### ✅ CREATED (In Database)

```
Tables Created:
================

1. knowledge_domains         38 rows seeded ← DONE
2. knowledge_fields          0 rows         ← EMPTY
3. knowledge_subjects        0 rows         ← EMPTY
4. knowledge_topics          0 rows         ← EMPTY
5. knowledge_subtopics       0 rows         ← EMPTY

6. tag_categories            15 rows seeded ← DONE
7. tag_taxonomy              0 rows         ← EMPTY
8. subject_tags              0 rows         ← EMPTY
9. topic_tags                0 rows         ← EMPTY

10. api_catalog              0 rows         ← EMPTY
11. subject_api_requirements 0 rows         ← EMPTY
12. master_book_specs        0 rows         ← EMPTY
13. discovery_sessions       0 rows         ← EMPTY
14. discovery_log            0 rows         ← EMPTY
15. pipeline_readiness       0 rows         ← EMPTY
```

**Translation:** We have the empty containers (tables) and category labels, but NO actual knowledge yet.

---

### ❌ NOT CREATED

```
File System:
============
/knowledge_catalog/          ← Doesn't exist
  ├── domains/               ← Doesn't exist
  ├── checklists/            ← Doesn't exist
  ├── progress/              ← Doesn't exist
  └── pipelines_ready/       ← Doesn't exist

Tag Taxonomy:
=============
~10,000 tags                 ← Not created (only categories exist)

API Catalog:
============
List of APIs needed          ← Not researched

Knowledge Content:
==================
Fields (300)                 ← Not discovered
Subjects (5,000)             ← Not discovered
Topics (50,000)              ← Not discovered
Subtopics (250,000)          ← Not discovered
```

---

## THE WORKFLOW: WHO DOES WHAT

### Role 1: AI Discovery Agent (Claude/GPT/Perplexity)

**Job:** Find and enumerate ALL knowledge

```
TASK                           METHOD                          OUTPUT
====                           ======                          ======

1. Find all Fields             Brainstorm + web research      Insert into knowledge_fields
   in Mathematics

2. Find all Subjects           Curriculum analysis            Insert into knowledge_subjects
   in Biology field            + textbook ToC analysis

3. Find all Topics             Break down each subject        Insert into knowledge_topics
   in Chemistry subject

4. Find all APIs               Search for data sources        Insert into api_catalog
   for Astronomy

5. Apply Tags                  Match to tag taxonomy          Insert into subject_tags
   to each subject
```

**Example AI Session:**

```
AI Prompt: "Enumerate ALL fields within the Mathematics domain"

AI Response:
1. Pure Mathematics
2. Applied Mathematics
3. Statistics
4. Logic & Foundations
5. Computational Mathematics

→ INSERT INTO knowledge_fields (domain_id, name, slug...)
```

---

### Role 2: Verification Agent (Multi-AI Consensus)

**Job:** Validate what Discovery Agent found

```
Discovery Agent: "I found 12 subjects in Pure Mathematics"

Verification Agent 1 (GPT-4): "I agree, found 12"
Verification Agent 2 (Claude): "I found 13, you missed Number Theory"
Verification Agent 3 (Perplexity): "I found 12, agreed"

CONSENSUS: 2/3 agree → Add Number Theory to list
```

---

### Role 3: Quality Checker Agent

**Job:** Score completeness/accuracy

```
Check Subject: "Algebra"

✓ Has description
✓ Has complexity_level
✓ Has estimated word count
✗ Missing api_requirements
✗ Missing tags

Quality Score: 60/100 → STATUS: needs_work
```

---

### Role 4: Human Admin

**Job:** Review, approve, fix issues

```
Dashboard shows:
- 47 subjects ready for approval
- 12 subjects flagged for review
- 3 subjects with conflicts

Human reviews flagged items, clicks "Approve" or "Fix"
```

---

### Role 5: System/Automation

**Job:** Track progress, generate checklists

```
Runs daily:
1. Count rows in each table
2. Calculate % complete
3. Generate checklist markdown
4. Update dashboard
5. Queue ready subjects for Pipeline 1
```

---

## THE CHECKLIST SYSTEM

### Checklist = Auto-Generated TODO List

```markdown
# Discovery Checklist (Auto-generated from database)

## Mathematics Domain [12% complete]

### Pure Mathematics Field [25% complete]
- [x] Algebra (READY_FOR_P1)
- [x] Geometry (READY_FOR_P1)
- [ ] Calculus (RESEARCHING)
- [ ] Number Theory (DISCOVERED)
- [ ] Topology (NOT_DISCOVERED)

### Applied Mathematics Field [0% complete]
- [ ] Differential Equations (DISCOVERED)
- [ ] Numerical Analysis (NOT_DISCOVERED)
```

**How it works:**

```sql
-- System queries database:
SELECT
  d.name as domain,
  f.name as field,
  s.name as subject,
  s.status
FROM knowledge_subjects s
JOIN knowledge_fields f ON s.field_id = f.id
JOIN knowledge_domains d ON f.domain_id = d.id
ORDER BY d.sort_order, f.sort_order, s.sort_order;

-- Generates markdown checklist
-- Updates daily automatically
```

---

## STEP-BY-STEP: HOW IT ACTUALLY WORKS

### Step 1: Populate Fields (AI Task)

```
AI receives prompt:
"Enumerate ALL fields within domain: Mathematics"

AI outputs JSON:
{
  "domain": "mathematics",
  "fields": [
    {"name": "Pure Mathematics", "description": "..."},
    {"name": "Applied Mathematics", "description": "..."},
    {"name": "Statistics", "description": "..."}
  ]
}

System inserts into database:
INSERT INTO knowledge_fields (domain_id, name, slug, description)
VALUES
  ('math-domain-uuid', 'Pure Mathematics', 'pure-mathematics', '...'),
  ('math-domain-uuid', 'Applied Mathematics', 'applied-mathematics', '...'),
  ...
```

---

### Step 2: Populate Subjects (AI Task)

```
For EACH field, AI receives prompt:
"Enumerate ALL subjects within field: Pure Mathematics"

AI outputs JSON:
{
  "field": "pure-mathematics",
  "subjects": [
    {"name": "Algebra", "complexity": "intermediate", "estimated_words": 75000},
    {"name": "Geometry", "complexity": "intermediate", "estimated_words": 60000},
    ...
  ]
}

System inserts into database:
INSERT INTO knowledge_subjects (field_id, name, slug, complexity_level, ...)
```

---

### Step 3: Populate Topics (AI Task)

```
For EACH subject, AI receives prompt:
"Enumerate ALL topics within subject: Algebra"

AI outputs:
[
  "Linear Equations",
  "Quadratic Equations",
  "Polynomials",
  "Matrices",
  ...
]

System inserts into knowledge_topics table
```

---

### Step 4: Populate API Requirements (AI Task)

```
For EACH subject, AI receives prompt:
"What APIs are needed for subject: Astronomy?"

AI searches web and outputs:
{
  "subject": "astronomy",
  "apis": [
    {
      "name": "NASA API",
      "url": "https://api.nasa.gov",
      "purpose": "Planetary data, images",
      "key_required": true
    },
    {
      "name": "Stellarium API",
      "purpose": "Star charts, constellations"
    }
  ]
}

System inserts into api_catalog and subject_api_requirements
```

---

### Step 5: Apply Tags (AI Task)

```
For EACH subject, AI receives prompt:
"What tags apply to subject: Marine Biology?"

AI outputs:
[
  "subject:natural-sciences:biology:marine",
  "grade:college",
  "level:intermediate",
  "skill:observation",
  "career:marine-biologist",
  "career:oceanographer"
]

System:
1. Creates tags in tag_taxonomy (if don't exist)
2. Links to subject in subject_tags table
```

---

### Step 6: Quality Check (AI Task)

```
For EACH subject, AI receives prompt:
"Review this subject for completeness"

AI checks:
✓ Has description
✓ Has topics listed
✓ Has API requirements
✓ Has tags
✗ Description too vague
✗ Missing 3 core topics

Score: 75/100
Status: needs_improvement

UPDATE knowledge_subjects
SET quality_score = 75, status = 'needs_improvement'
WHERE id = 'subject-uuid';
```

---

### Step 7: Human Review (Admin Task)

```
Admin opens dashboard:

"Flagged Items (3)"
-----------------------
❌ Biology:Zoology - Missing whale species list
❌ Chemistry:Organic - API not working
❌ History:Ancient - Dates conflict

Admin clicks each, reviews, fixes:
- Adds missing whale species
- Finds alternate API
- Corrects dates
- Clicks "Approve"

UPDATE knowledge_subjects SET status = 'approved'
```

---

### Step 8: Mark Ready for Pipeline 1

```
System checks EVERY subject nightly:

IF (
  status = 'approved' AND
  quality_score >= 80 AND
  api_requirements_complete = true AND
  tags_complete = true
) THEN
  UPDATE knowledge_subjects
  SET ready_for_pipeline_1 = true

  INSERT INTO pipeline_readiness (subject_id, pipeline_number, readiness_status)
  VALUES ('subject-uuid', 1, 'ready')
```

---

### Step 9: Dashboard Updates

```
System queries database:

SELECT COUNT(*) FROM knowledge_domains;  → 38
SELECT COUNT(*) FROM knowledge_fields;   → 247 (example)
SELECT COUNT(*) FROM knowledge_subjects; → 1,892 (example)
SELECT COUNT(*) FROM knowledge_subjects WHERE ready_for_pipeline_1 = true; → 423

Generates dashboard:
==================
Domains: 38/38 (100%) ✅
Fields: 247/300 (82%) 🔄
Subjects: 1,892/5,000 (38%) 🔄
Ready for P1: 423 subjects ✅
```

---

## CHECKLIST PROCESS IN DETAIL

### What IS a Checklist?

```
It's a markdown file AUTO-GENERATED from the database that shows:
- What's been discovered
- What's still missing
- What needs work
- What's ready

NOT manually maintained - regenerated every time database changes
```

### Example Checklist Generation

**Database State:**
```sql
-- knowledge_subjects table
id | name     | field       | status
---|----------|-------------|------------
1  | Algebra  | Pure Math   | approved
2  | Geometry | Pure Math   | researching
3  | Calculus | Pure Math   | discovered
```

**Generated Checklist:**
```markdown
## Pure Mathematics Field

- [x] Algebra (APPROVED ✅)
- [ ] Geometry (RESEARCHING 🔄)
- [ ] Calculus (DISCOVERED 📝)
```

---

## VISUALIZATION: THE COMPLETE FLOW

```
┌─────────────────────────────────────────────────────┐
│ STEP 1: AI DISCOVERY                                │
│ --------------------------------------------------- │
│ AI brainstorms → outputs JSON → inserts to database │
└─────────────────┬───────────────────────────────────┘
                  │
                  ↓
┌─────────────────────────────────────────────────────┐
│ STEP 2: AI VERIFICATION                             │
│ --------------------------------------------------- │
│ 3 AIs check → consensus required → conflicts flagged│
└─────────────────┬───────────────────────────────────┘
                  │
                  ↓
┌─────────────────────────────────────────────────────┐
│ STEP 3: AI QUALITY CHECK                            │
│ --------------------------------------------------- │
│ Score completeness → assign quality score → update  │
└─────────────────┬───────────────────────────────────┘
                  │
                  ↓
┌─────────────────────────────────────────────────────┐
│ STEP 4: HUMAN REVIEW (if needed)                    │
│ --------------------------------------------------- │
│ Admin reviews flagged items → fixes → approves      │
└─────────────────┬───────────────────────────────────┘
                  │
                  ↓
┌─────────────────────────────────────────────────────┐
│ STEP 5: SYSTEM MARKS READY                          │
│ --------------------------------------------------- │
│ Nightly job → checks criteria → sets ready=true     │
└─────────────────┬───────────────────────────────────┘
                  │
                  ↓
┌─────────────────────────────────────────────────────┐
│ STEP 6: PIPELINE 1 PICKS UP                         │
│ --------------------------------------------------- │
│ Queries subjects WHERE ready_for_pipeline_1 = true  │
│ Starts generating master books                      │
└─────────────────────────────────────────────────────┘
```

---

## WHAT TO DO NEXT (Decision Points)

### Option A: Populate Database Only
```
✅ Skip file system entirely
✅ Everything lives in Supabase
✅ Query database for all info
✅ Dashboard shows progress
✅ Checklists generated on-demand

Tools Needed:
- AI prompts for discovery
- Scripts to insert JSON → database
- Dashboard UI
- Checklist generator script
```

### Option B: Database + File System
```
✅ Database is source of truth
✅ Export to files for version control
✅ Humans can browse folders
⚠️ Must keep in sync

Tools Needed:
- Everything from Option A
- PLUS: Export script (database → files)
- PLUS: Import script (files → database)
- PLUS: Sync detection
```

### Option C: Start Small (Recommended)
```
1. Pick ONE domain (e.g., Mathematics)
2. AI discovers all fields in that domain
3. AI discovers all subjects in first field
4. Review quality
5. If good → repeat for other domains
6. If bad → adjust process

This tests the workflow before going big
```

---

## SPECIFIC RESPONSIBILITIES

### AI Agent 1 (Discovery)
- Receives: Domain name
- Does: Brainstorms all fields
- Outputs: JSON with field list
- Inserts: Into knowledge_fields table

### AI Agent 2 (Verification)
- Receives: Field list from Agent 1
- Does: Independently discovers fields
- Outputs: JSON with field list
- Compares: With Agent 1, flags differences

### AI Agent 3 (Research)
- Receives: Subject name
- Does: Web search for APIs, data sources
- Outputs: JSON with API list
- Inserts: Into api_catalog and subject_api_requirements

### AI Agent 4 (Tagging)
- Receives: Subject metadata
- Does: Determines appropriate tags
- Outputs: Tag list
- Inserts: Into tag_taxonomy and subject_tags

### System Scheduler
- Runs: Daily at midnight
- Does:
  1. Count rows
  2. Calculate percentages
  3. Check readiness criteria
  4. Generate checklists
  5. Update dashboard
  6. Log progress

### Human Admin
- Reviews: Flagged/conflicted items
- Fixes: Data quality issues
- Approves: Subjects ready for production
- Monitors: Overall progress via dashboard

---

## IMMEDIATE NEXT STEP OPTIONS

**1. Create Dashboard UI**
- Shows 38 domains
- Shows empty fields/subjects counts
- "Start Discovery" button

**2. Create AI Discovery Script**
- Prompt: "Find all fields in Mathematics"
- Parse JSON response
- Insert into database
- Show results

**3. Build Checklist Generator**
- Query current database state
- Generate markdown
- Show what's complete vs missing

**4. Manual Populate (Test)**
- Manually add 3 fields to Mathematics
- Manually add 5 subjects to one field
- See how tables relate
- Then automate

Which direction should we go?
