# PIPELINE 0 FILE STRUCTURE

## CURRENT STATE

```
/tmp/cc-agent/61983872/project/

├── blueprints/                                     # Blueprint specifications
│   ├── PIPELINE_0_MASTER_KNOWLEDGE_DISCOVERY_SYSTEM.md  ← NEW! Master blueprint
│   │
│   ├── pipeline_1_master_book_generation/         # Pipeline 1 specs
│   ├── pipeline_2_reading_level_adaptations/      # Pipeline 2 specs
│   ├── pipeline_3_disability_adaptations/         # Pipeline 3 specs
│   └── ... (pipelines 4-11)
│
├── database_migrations_ready_to_apply/
│   └── COMPLETE_EXPORT_PERMANENT/
│       ├── PIPELINE_0/                             # OLD - Careers only
│       │   ├── README.md
│       │   └── PHASE_0_RESEARCH_BLUEPRINT.md      # Job catalog (50k careers)
│       │
│       ├── PIPELINE_14/                            # Career system implementation
│       └── DATABASE/                               # All migrations
│           └── migrations/
│               └── 20260101224536_create_pipeline_0_knowledge_discovery_system.sql  ← NEW!
│
├── pipelines/                                      # Documentation & guides
│   ├── COMPLETE_PIPELINE_MASTER_LIST.md
│   └── ... (various pipeline docs)
│
└── supabase/                                       # Active database
    └── migrations/
        └── 20260101224536_create_pipeline_0_knowledge_discovery_system.sql  ← NEEDS APPLYING
```

---

## DATABASE STRUCTURE (Now in Supabase)

```sql
-- KNOWLEDGE HIERARCHY (6 levels)
knowledge_domains          (38 domains seeded)
  ↓
knowledge_fields           (~300 fields)
  ↓
knowledge_subjects         (~5,000 subjects)
  ↓
knowledge_topics           (~50,000 topics)
  ↓
knowledge_subtopics        (~250,000 subtopics)
  ↓
[concepts tracked in metadata]


-- TAG SYSTEM
tag_categories             (15 categories seeded)
  ↓
tag_taxonomy              (10,000+ tags)
  ↓
subject_tags              (many-to-many)
topic_tags                (many-to-many)


-- API REQUIREMENTS
api_catalog               (master list of all APIs)
  ↓
subject_api_requirements  (which APIs each subject needs)


-- SPECIFICATIONS
master_book_specs         (one per subject)


-- TRACKING
discovery_sessions        (research sessions)
  ↓
discovery_log            (what was discovered)

pipeline_readiness       (ready for each pipeline?)
```

---

## PROPOSED FILE STRUCTURE (Not Yet Created)

This is the file system structure proposed in the blueprint for organizing discovered knowledge:

```
/knowledge_catalog/                                  ← TO BE CREATED

├── _metadata/                                       ← Master reference files
│   ├── tag_taxonomy.json              # All tag definitions
│   ├── api_requirements.json          # All API mappings
│   ├── status_tracking.json           # Global status
│   └── quality_standards.json         # Quality thresholds
│
├── domains/                            ← 38 domain folders
│   │
│   ├── 01_mathematics/
│   │   ├── _domain_metadata.json      # Domain-level info
│   │   │
│   │   └── fields/
│   │       ├── pure_mathematics/
│   │       │   ├── _field_metadata.json
│   │       │   │
│   │       │   └── subjects/
│   │       │       ├── algebra/
│   │       │       │   ├── _subject_metadata.json
│   │       │       │   ├── master_book_spec.json
│   │       │       │   ├── api_requirements.json
│   │       │       │   ├── status.json
│   │       │       │   │
│   │       │       │   ├── sub_books/
│   │       │       │   │   ├── linear_algebra.json
│   │       │       │   │   ├── abstract_algebra.json
│   │       │       │   │   └── boolean_algebra.json
│   │       │       │   │
│   │       │       │   └── topics/
│   │       │       │       ├── equations.json
│   │       │       │       ├── functions.json
│   │       │       │       └── variables.json
│   │       │       │
│   │       │       ├── geometry/
│   │       │       ├── calculus/
│   │       │       └── ...
│   │       │
│   │       ├── applied_mathematics/
│   │       └── statistics/
│   │
│   ├── 02_natural_sciences/
│   │   └── fields/
│   │       ├── biology/
│   │       │   └── subjects/
│   │       │       ├── zoology/
│   │       │       │   └── topics/
│   │       │       │       ├── mammals/
│   │       │       │       │   ├── marine_mammals/
│   │       │       │       │   │   ├── whales.json
│   │       │       │       │   │   ├── dolphins.json
│   │       │       │       │   │   └── seals.json
│   │       │       │       │   ├── land_mammals/
│   │       │       │       │   └── flying_mammals/
│   │       │       │       │
│   │       │       │       ├── birds/
│   │       │       │       ├── reptiles/
│   │       │       │       └── ...
│   │       │       │
│   │       │       ├── botany/
│   │       │       └── microbiology/
│   │       │
│   │       ├── chemistry/
│   │       ├── physics/
│   │       └── astronomy/
│   │
│   ├── 03_social_sciences/
│   ├── 04_humanities/
│   ├── ... (all 38 domains)
│   │
│   └── 38_environmental/
│
├── checklists/                         ← Progress tracking
│   ├── discovery_checklist.md         # What needs discovering
│   ├── research_checklist.md          # What needs research
│   ├── organization_checklist.md      # What needs organizing
│   └── quality_checklist.md           # What needs review
│
├── progress/                           ← Status reports
│   ├── daily_progress.json
│   ├── weekly_reports/
│   │   ├── 2026-W01.json
│   │   ├── 2026-W02.json
│   │   └── ...
│   └── milestone_tracking.json
│
└── pipelines_ready/                    ← Queue for other pipelines
    ├── ready_for_pipeline_1/          # Subjects ready for book generation
    │   ├── mathematics_algebra.json
    │   ├── biology_zoology.json
    │   └── ...
    │
    ├── ready_for_pipeline_2/          # Books ready for reading levels
    └── ... (queues for each pipeline)
```

---

## FILE NAMING CONVENTIONS

### JSON Metadata Files

```json
// _domain_metadata.json
{
  "domain_id": "uuid",
  "name": "Mathematics",
  "slug": "mathematics",
  "description": "...",
  "field_count": 3,
  "subject_count": 47,
  "status": "active",
  "last_updated": "2026-01-01T00:00:00Z"
}

// _field_metadata.json
{
  "field_id": "uuid",
  "domain_id": "uuid",
  "name": "Pure Mathematics",
  "slug": "pure-mathematics",
  "subject_count": 12,
  "status": "active"
}

// _subject_metadata.json
{
  "subject_id": "uuid",
  "field_id": "uuid",
  "name": "Algebra",
  "slug": "algebra",
  "complexity_level": "intermediate",
  "topic_count": 25,
  "status": "outlined",
  "quality_score": 85.5
}

// master_book_spec.json
{
  "subject_id": "uuid",
  "title": "Complete Guide to Algebra",
  "estimated_words": 75000,
  "estimated_chapters": 12,
  "sub_book_count": 3,
  "sub_books": [
    "Linear Algebra Fundamentals",
    "Abstract Algebra Concepts",
    "Boolean Algebra Applications"
  ],
  "chapter_outline": { ... }
}

// api_requirements.json
{
  "subject_id": "uuid",
  "apis_required": [
    {
      "api_name": "Wolfram Alpha API",
      "purpose": "Mathematical verification",
      "priority": "required"
    }
  ]
}

// status.json
{
  "subject_id": "uuid",
  "current_status": "SPEC_COMPLETE",
  "ready_for_pipeline_1": true,
  "pipeline_1_status": "not_started",
  "last_updated": "2026-01-01T00:00:00Z",
  "blockers": []
}

// topics/equations.json
{
  "topic_id": "uuid",
  "subject_id": "uuid",
  "name": "Equations",
  "description": "...",
  "complexity_score": 65,
  "subtopics": [
    "Linear Equations",
    "Quadratic Equations",
    "Polynomial Equations"
  ],
  "learning_objectives": [ ... ]
}
```

---

## MARKDOWN Documentation Files

```
checklists/discovery_checklist.md

# Discovery Checklist

## Mathematics Domain
- [x] Pure Mathematics field
  - [x] Algebra subject
  - [x] Geometry subject
  - [ ] Calculus subject
- [ ] Applied Mathematics field
- [ ] Statistics field

## Natural Sciences Domain
- [x] Biology field
  - [x] Zoology subject
  - [ ] Botany subject
- [ ] Chemistry field
- [ ] Physics field
```

---

## HOW FILES RELATE TO DATABASE

```
DATABASE (source of truth)          FILE SYSTEM (organized view)
=====================               ========================

knowledge_domains table    →        domains/[domain_name]/
  ↓                                   ↓
knowledge_fields table     →        fields/[field_name]/
  ↓                                   ↓
knowledge_subjects table   →        subjects/[subject_name]/
  (JSON export)                       _subject_metadata.json
  ↓                                   ↓
knowledge_topics table     →        topics/[topic_name].json
  ↓
knowledge_subtopics table  →        (embedded in topic JSON)

master_book_specs table    →        master_book_spec.json
api_requirements table     →        api_requirements.json
pipeline_readiness table   →        status.json
```

---

## WORKFLOW: DATABASE → FILES

```bash
# Export from database to file system
1. Query knowledge_domains table
2. For each domain:
   - Create domain folder
   - Export to _domain_metadata.json
3. Query knowledge_fields for that domain
4. For each field:
   - Create field folder
   - Export to _field_metadata.json
5. Continue down hierarchy...

# Generate checklists
1. Query all subjects WHERE status != 'complete'
2. Group by domain/field
3. Generate markdown checklist

# Generate ready queues
1. Query pipeline_readiness WHERE readiness_status = 'ready'
2. Export to pipelines_ready/ready_for_pipeline_[N]/
```

---

## CURRENT STATUS

### ✅ COMPLETED
- Database schema designed and applied
- 38 domains seeded
- 15 tag categories seeded
- Master blueprint created

### 🔄 IN PROGRESS
- None currently

### ⏳ NOT STARTED
- File system structure creation
- Field/subject discovery
- Tag taxonomy population
- API catalog population
- Export scripts (database → files)
- Dashboard UI

---

## NEXT STEPS

1. **Decide:** Use database only OR database + file system?
   - Database = source of truth (always)
   - File system = organized view for humans (optional)

2. **Populate tag taxonomy** (~10,000 tags across 15 categories)

3. **Begin domain discovery** (AI-assisted enumeration)

4. **Create dashboard** to visualize progress

5. **Build export scripts** (if using file system)
