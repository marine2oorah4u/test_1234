# **DIFFICULTY LEVEL SYSTEM: 1-100 SCALE**
## **Granular Assessment for All Content**

---

## **📊 WHY 1-100 SCALE?**

**Problem with 1-5 Scale:**
- ❌ Only 5 levels for 8+ reading levels
- ❌ Can't differentiate between similar complexities
- ❌ Too coarse for 40+ disability adaptations
- ❌ Doesn't capture nuance

**Solution: 1-100 Scale:**
- ✅ Precise differentiation
- ✅ Maps to multiple dimensions
- ✅ Allows micro-adjustments
- ✅ Industry standard (like Lexile scores)

---

## **🎯 OVERALL DIFFICULTY BANDS**

| **Band** | **Range** | **Description** | **Audience** |
|----------|-----------|-----------------|--------------|
| **Beginner** | 1-20 | Very simple, highly scaffolded | Grades K-2, significant support needs |
| **Elementary** | 21-35 | Simple with guidance | Grades 3-5, moderate support |
| **Intermediate** | 36-50 | Moderate challenge | Grades 6-8, minimal support |
| **Advanced** | 51-65 | Challenging, independent | Grades 9-12, independent learners |
| **Professional** | 66-80 | Complex, specialized | College, professionals |
| **Expert** | 81-100 | Highly complex, research-level | Advanced professionals, researchers |

---

## **🧮 DIFFICULTY CALCULATION FORMULA**

```
Overall Difficulty Score =
  (Concept Complexity × 0.25) +
  (Skill Requirements × 0.20) +
  (Reading Level Required × 0.15) +
  (Material Handling × 0.10) +
  (Safety Considerations × 0.10) +
  (Time Commitment × 0.08) +
  (Independence Level × 0.12)

Each factor scored 1-100, weighted, then averaged
```

---

## **📏 FACTOR SCORING GUIDES**

### **1. Concept Complexity (1-100)**
- **1-20**: Single, concrete concept (e.g., "hot magma")
- **21-35**: Multiple related concepts (e.g., "magma becomes lava")
- **36-50**: Abstract relationships (e.g., "convection drives plates")
- **51-65**: Multiple abstract systems (e.g., "tectonic-volcanic-climate interaction")
- **66-80**: Theoretical frameworks (e.g., "mantle plume theory")
- **81-100**: Cutting-edge research (e.g., "quantum geophysics")

### **2. Skill Requirements (1-100)**
- **1-20**: Basic observation, single-step actions
- **21-35**: Following multi-step instructions, simple measurement
- **36-50**: Data collection, basic analysis, graphing
- **51-65**: Experimental design, variable control, synthesis
- **66-80**: Advanced analysis, statistical methods, modeling
- **81-100**: Original research design, novel methodology

### **3. Reading Level Required (1-100)**
```
Lexile-aligned:
1-20:   BR-400L  (Beginning Reader to early elementary)
21-35:  400-700L (Elementary)
36-50:  700-900L (Middle School)
51-65:  900-1100L (High School)
66-80:  1100-1300L (College/Professional)
81-100: 1300L+ (Graduate/Expert)
```

### **4. Material Handling (1-100)**
- **1-20**: No materials or pre-assembled
- **21-35**: Simple materials, safe handling
- **36-50**: Multiple materials, some complexity
- **51-65**: Specialized equipment, careful technique
- **66-80**: Precise measurements, calibration needed
- **81-100**: Advanced equipment, expert technique

### **5. Safety Considerations (1-100)**
- **1-20**: No hazards, minimal supervision
- **21-35**: Minor hazards, adult nearby
- **36-50**: Moderate hazards, direct supervision
- **51-65**: Significant hazards, safety training required
- **66-80**: Serious hazards, extensive precautions
- **81-100**: Extreme hazards, expert supervision only

### **6. Time Commitment (1-100)**
- **1-20**: 5-15 minutes
- **21-35**: 15-30 minutes
- **36-50**: 30-60 minutes
- **51-65**: 1-2 hours
- **66-80**: 2-5 hours or multi-day
- **81-100**: Extended project, weeks/months

### **7. Independence Level (1-100)**
- **1-20**: Constant adult guidance, hand-over-hand
- **21-35**: Frequent check-ins, high support
- **36-50**: Periodic check-ins, moderate support
- **51-65**: Minimal supervision, mostly independent
- **66-80**: Fully independent, self-directed
- **81-100**: Independent research, mentorship only

---

## **🎓 MAPPING TO GRADE LEVELS**

| **Difficulty Score** | **Typical Grade Range** | **Reading Level Equiv.** |
|---------------------|------------------------|-------------------------|
| 1-10 | PreK-K | Emerging Reader |
| 11-20 | K-1 | Beginning Reader |
| 21-28 | 2-3 | Early Elementary |
| 29-35 | 3-5 | Upper Elementary |
| 36-43 | 5-6 | Transition to MS |
| 44-50 | 6-8 | Middle School |
| 51-58 | 8-9 | Transition to HS |
| 59-65 | 9-12 | High School |
| 66-72 | College Intro | Undergraduate |
| 73-80 | College Advanced | Upper Division |
| 81-88 | Graduate Level | Master's Level |
| 89-100 | Expert/Research | PhD/Professional |

---

## **♿ MAPPING TO DISABILITY ADAPTATIONS**

### **Intellectual/Cognitive Disabilities**
- **Intellectual Disability**: Target 10-30 range (with adaptations)
- **Down Syndrome**: Target 15-35 range
- **FASD**: Target 20-40 range
- **Memory Impairments**: Reduce by 15-25 points from baseline

### **Learning Disabilities**
- **Dyslexia**: Reading level adjusted, concept complexity unchanged
- **Dyscalculia**: Math-heavy content reduced by 20-30 points
- **ADHD**: Time-sensitive tasks reduced by 10-15 points
- **Executive Function**: Multi-step tasks reduced by 15-20 points

### **Sensory Disabilities**
- **Blind/Low Vision**: Material handling adjusted, concept unchanged
- **Deaf/Hard of Hearing**: Audio-dependent reduced, visual increased
- **Sensory Processing**: Sensory load considerations, -10 to -20 points

### **Autism Spectrum**
- **Level 1**: -5 to -10 points for social aspects
- **Level 2**: -15 to -25 points for social/communication
- **Level 3**: -25 to -40 points, high support needs

---

## **🔄 MODIFICATION PATHWAYS**

### **Simplification (Reduce Difficulty)**
```
Original Score: 55 (Advanced, Grade 9-12)

Simplification Options:
-10 points: Remove one abstract concept → 45 (Intermediate)
-20 points: Simplify language + scaffold → 35 (Elementary)
-30 points: Break into smaller steps + visual aids → 25 (Beginner)
```

### **Enhancement (Increase Difficulty)**
```
Original Score: 35 (Elementary)

Enhancement Options:
+10 points: Add data analysis component → 45 (Intermediate)
+20 points: Require independent research → 55 (Advanced)
+30 points: Add theoretical framework → 65 (Professional)
```

---

## **📊 EXAMPLE SCORING**

### **Activity: Volcano Eruption Model**

**Factor Scoring:**
1. Concept Complexity: 35 (acid-base reaction, pressure buildup)
2. Skill Requirements: 28 (following multi-step, mixing, observing)
3. Reading Level: 32 (Grade 4-5 text)
4. Material Handling: 25 (liquids, measuring)
5. Safety: 40 (eye protection, acid handling)
6. Time: 30 (45 minutes)
7. Independence: 35 (moderate supervision)

**Calculation:**
```
(35 × 0.25) + (28 × 0.20) + (32 × 0.15) + (25 × 0.10) +
(40 × 0.10) + (30 × 0.08) + (35 × 0.12) = 32.75

Overall Difficulty: 33/100 (Upper Elementary Range)
Appropriate for: Grades 3-5
```

---

## **🤖 AI CONSENSUS SCORING**

### **Process:**
1. **3-5 AI models** independently score each factor (1-100)
2. Calculate average for each factor
3. Apply weighting formula
4. Generate overall score
5. If variance > 15 points, add more AI opinions
6. Consensus score = median of all AI scores

### **Quality Check:**
- ✅ All factors scored
- ✅ Variance within acceptable range (< 15 points)
- ✅ Score matches described characteristics
- ✅ Appropriate for stated grade levels
- ✅ Modifications properly calculated

---

## **💾 DATABASE SCHEMA**

```sql
ALTER TABLE addon_features
ADD COLUMN difficulty_score INTEGER CHECK (difficulty_score BETWEEN 1 AND 100);

ADD COLUMN difficulty_band TEXT CHECK (difficulty_band IN
  ('Beginner', 'Elementary', 'Intermediate', 'Advanced', 'Professional', 'Expert'));

ADD COLUMN difficulty_factors JSONB; -- Stores breakdown of 7 factors

CREATE INDEX idx_difficulty_score ON addon_features(difficulty_score);
CREATE INDEX idx_difficulty_band ON addon_features(difficulty_band);
```

---

## **✅ BENEFITS OF 1-100 SCALE**

1. **Precision**: Capture nuance between similar activities
2. **Flexibility**: Easy to adjust for different audiences
3. **Transparency**: Clear how score was calculated
4. **Comparability**: Compare across different activity types
5. **Personalization**: Match to exact student needs
6. **Industry Standard**: Aligns with Lexile, ATOS scales
7. **Disability Support**: Fine-tune for 40+ adaptations
8. **International**: Works across education systems

---

**This scale replaces all 1-5 difficulty systems across:**
- ✅ Activity Packs (168 features)
- ✅ Reading Level Adaptations (8 levels)
- ✅ Disability Adaptations (40+ types)
- ✅ All future content

**Implemented via AI consensus scoring with 3-5 models.**
