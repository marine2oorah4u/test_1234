# 🚨 CRITICAL AI FALLBACK RULES

**MANDATORY FOR ALL BLUEPRINTS AND GENERATORS**
**Status:** ACTIVE - Must be implemented in every AI call
**Last Updated:** December 18, 2025

---

## ⚠️ RULE #1: NEVER RELY ON SINGLE AI MODEL

**Every AI call MUST have a fallback chain.**

### ❌ WRONG (No Fallback):
```typescript
// DON'T DO THIS - Single point of failure!
const response = await callAI('GPT-5 Pro', prompt);
if (!response) {
  throw new Error('AI failed'); // System breaks!
}
```

### ✅ CORRECT (With Fallback Chain):
```typescript
// DO THIS - Automatic fallback chain
const response = await callAIModel(AI_MODELS['GPT-5 Pro'], prompt, verificationType);
// System automatically tries:
// 1. GPT-5 Pro (primary)
// 2. GPT-4 Turbo (fallback 1)
// 3. Claude 3.5 Sonnet (fallback 2)
// 4. Gemini Pro 1.5 (fallback 3)
// 5. Simulation (guaranteed success)
```

---

## 📋 COMPLETE FALLBACK CHAINS

### **Tier 1 Models (Premium)**

```typescript
'GPT-5 Pro': ['GPT-4 Turbo', 'Claude 3.5 Sonnet', 'Gemini Pro 1.5']
'Claude 3.5 Sonnet': ['GPT-4 Turbo', 'Claude 3 Opus']
'Gemini Pro 1.5': ['Gemini Flash', 'GPT-4 Turbo']
'Gemini Ultra': ['Gemini Pro 1.5', 'Claude 3.5 Sonnet']
'o4-mini-deep-research': ['GPT-4 Turbo', 'DeepSeek-V3']
```

### **Tier 2 Models (Standard)**

```typescript
'GPT-5.1': ['GPT-4 Turbo', 'Claude 3.5 Sonnet']
'DeepSeek-V3': ['Gemini Flash', 'GPT-4 Turbo']
'Perplexity Pro': ['GPT-4 Turbo', 'Claude 3.5 Sonnet']
'Gemini Flash': ['Gemini Pro 1.5', 'DeepSeek-V3']
```

### **Tier 3 Models (Specialized)**

```typescript
'GPT-4 Turbo': ['Claude 3.5 Sonnet', 'Gemini Pro 1.5']
'Claude 3 Opus': ['Claude 3.5 Sonnet', 'GPT-4 Turbo']
'Cohere Command R+': ['GPT-4 Turbo', 'Claude 3.5 Sonnet']
```

---

## 🔄 HOW FALLBACK CHAINS WORK

### **Automatic Retry Sequence:**

```
Step 1: Try Primary Model
  ├─ Has API key? → Make API call
  │   ├─ Success? → Return response ✅
  │   └─ Failed? → Retry 3x with exponential backoff
  │       ├─ Success? → Return response ✅
  │       └─ All retries failed? → Go to Step 2
  └─ No API key? → Go to Step 2

Step 2: Try Fallback Model #1
  ├─ Has API key? → Make API call
  │   ├─ Success? → Return response ✅
  │   └─ Failed? → Retry 3x
  │       ├─ Success? → Return response ✅
  │       └─ All retries failed? → Go to Step 3
  └─ No API key? → Go to Step 3

Step 3: Try Fallback Model #2
  [Same process as Step 2]

Step 4: Try Fallback Model #3
  [Same process as Step 2]

Step 5: Use Simulation (GUARANTEED SUCCESS)
  └─ Return simulated response ✅
```

### **Retry Logic Per Model:**

```
Attempt 1: Immediate call
  ↓ (fails - rate limit, timeout, etc.)
Wait 1 second (2^0 * 1000ms)
Attempt 2: Retry
  ↓ (fails)
Wait 2 seconds (2^1 * 1000ms)
Attempt 3: Final retry
  ↓ (fails)
Move to next model in fallback chain
```

---

## 🎯 RULE #2: ALL BLUEPRINTS MUST REFERENCE THIS FILE

**At the beginning of every blueprint file, add:**

```json
{
  "critical_rules": {
    "ai_fallback": "See /blueprints/CRITICAL_AI_FALLBACK_RULES.md",
    "implementation": "All AI calls MUST use fallback chains",
    "never_fail": "System must always return a result, even if simulated"
  }
}
```

---

## 📦 RULE #3: GENERATOR IMPLEMENTATION

### **Every Generator Must:**

1. **Import the AI consensus system:**
```typescript
import { runConsensusVerification, AI_MODELS } from '@/lib/aiConsensus';
```

2. **Use fallback chains for ALL AI calls:**
```typescript
// Every verification step
const result = await runConsensusVerification({
  contentId: 'activity-001',
  contentType: 'activity_pack',
  verificationType: 'quality',
  content: generatedContent,
  models: ['GPT-5 Pro', 'Claude 3.5 Sonnet', 'Gemini Pro 1.5']
});

// System automatically handles fallbacks
```

3. **Track which model succeeded:**
```typescript
console.log(`✅ Verification complete using: ${result.responses[0].model}`);
// Shows: "GPT-4 Turbo" if GPT-5 Pro fell back
```

4. **Store fallback information:**
```typescript
// Database automatically tracks:
// - Primary model requested
// - Actual model used
// - All models attempted
// - Fallback chain path taken
```

---

## 💡 RULE #4: COST OPTIMIZATION

### **Smart Model Selection:**

**For High-Quality Content (Books, Master Content):**
```typescript
// Use Tier 1 models with premium fallbacks
models: ['Claude 3.5 Sonnet', 'GPT-5 Pro', 'Gemini Pro 1.5']
```

**For Volume Content (Worksheets, Quizzes):**
```typescript
// Use Tier 2 models with cost-effective fallbacks
models: ['DeepSeek-V3', 'Gemini Flash', 'GPT-4 Turbo']
```

**For Testing/Development:**
```typescript
// Use simulation (no API keys needed)
models: ['GPT-5 Pro'] // Will automatically fall back to simulation
```

### **Fallback Cost Savings:**

If primary model costs $0.03/1k tokens but fallback costs $0.01/1k tokens:
- ✅ Still get high-quality result
- ✅ Save 66% on API costs
- ✅ System adapts to API availability
- ✅ No manual intervention needed

---

## 🚨 RULE #5: ERROR HANDLING

### **What Happens on Failure:**

```typescript
// NEVER throw errors that break the workflow
try {
  const response = await callAIModel(model, prompt, verificationType);
  // response is ALWAYS defined
  // May be from primary, fallback, or simulation
} catch (error) {
  // This NEVER happens - fallback to simulation prevents it
}
```

### **Logging Fallback Events:**

```typescript
// System automatically logs:
console.log('🔄 Trying GPT-5 Pro...');
console.log('⚠️  No API key for openai, trying fallback...');
console.log('🔄 Trying GPT-4 Turbo...');
console.log('✅ GPT-4 Turbo succeeded (1234ms, $0.0123)');

// Database tracks:
// - attempted_models: ['GPT-5 Pro', 'GPT-4 Turbo']
// - successful_model: 'GPT-4 Turbo'
// - fallback_reason: 'No API key'
```

---

## 📊 RULE #6: MONITORING & ALERTS

### **Track Fallback Frequency:**

```sql
-- Query to see fallback usage
SELECT
  ai_model,
  COUNT(*) as total_calls,
  SUM(CASE WHEN ai_model LIKE '% (simulated)%' THEN 1 ELSE 0 END) as simulated_calls,
  SUM(CASE WHEN ai_model NOT LIKE '% (simulated)%' THEN 1 ELSE 0 END) as real_calls
FROM ai_model_responses
GROUP BY ai_model
ORDER BY total_calls DESC;
```

### **Alert Conditions:**

1. **High Simulation Rate** (>50%)
   - Action: Check API keys
   - Action: Check API credits
   - Action: Check service status

2. **Frequent Fallbacks** (>30%)
   - Action: Primary model may be unstable
   - Action: Consider reordering fallback chain
   - Action: Increase rate limit delays

3. **Cost Spikes**
   - Action: More expensive fallbacks being used
   - Action: Review fallback chain order
   - Action: Consider cheaper alternatives

---

## 🎯 IMPLEMENTATION CHECKLIST

### **For New Blueprints:**

- [ ] Reference this file in critical_rules section
- [ ] Specify primary model and fallback chain
- [ ] Document expected model usage
- [ ] Include cost estimates for each model tier
- [ ] Plan for simulation fallback scenario

### **For New Generators:**

- [ ] Import aiConsensus system
- [ ] Use runConsensusVerification for all AI calls
- [ ] NEVER use raw API calls without fallbacks
- [ ] Log which models are being used
- [ ] Track costs per model
- [ ] Handle simulation gracefully (it's a feature!)

### **For Testing:**

- [ ] Test with all API keys present
- [ ] Test with only OpenAI key
- [ ] Test with no API keys (simulation mode)
- [ ] Test rate limiting scenarios
- [ ] Test API failure scenarios
- [ ] Verify fallback chains work correctly

---

## 🔧 CONFIGURATION

### **Location:** `/src/lib/aiConsensus.ts`

**Fallback chains defined in:**
```typescript
const FALLBACK_CHAINS: Record<string, string[]> = {
  'GPT-5 Pro': ['GPT-4 Turbo', 'Claude 3.5 Sonnet', 'Gemini Pro 1.5'],
  // ... all 12 models
};
```

**To modify fallback chains:**
1. Edit FALLBACK_CHAINS constant
2. Rebuild system
3. Test all affected blueprints
4. Update this documentation

**To add new AI models:**
1. Add to AI_MODELS config
2. Add to MODEL_API_NAMES mapping
3. Add to FALLBACK_CHAINS
4. Implement API call function
5. Test fallback behavior
6. Update documentation

---

## 📝 BLUEPRINT TEMPLATE

**Copy this to the beginning of every blueprint:**

```json
{
  "blueprint_version": "2.0",
  "critical_rules": {
    "ai_fallback_system": {
      "documentation": "/blueprints/CRITICAL_AI_FALLBACK_RULES.md",
      "implementation_required": true,
      "all_ai_calls_must_have_fallback": true,
      "simulation_is_valid_fallback": true,
      "never_throw_on_ai_failure": true,
      "track_fallback_usage": true
    }
  },
  "ai_configuration": {
    "primary_models": ["Model1", "Model2", "Model3"],
    "expected_fallback_rate": "< 20%",
    "simulation_fallback_acceptable": true,
    "cost_per_verification": "$0.05 - $0.10"
  }
}
```

---

## 🎉 BENEFITS

### **Reliability:**
- ✅ System NEVER fails completely
- ✅ Automatic recovery from API issues
- ✅ No manual intervention needed
- ✅ Graceful degradation

### **Cost Optimization:**
- ✅ Uses cheaper models when primary unavailable
- ✅ Simulation mode for free testing
- ✅ Tracks actual costs vs. budgeted costs
- ✅ Automatic cost-benefit analysis

### **Flexibility:**
- ✅ Works with any combination of API keys
- ✅ Works with no API keys (simulation)
- ✅ Easy to add new models
- ✅ Easy to reorder fallback chains

### **Developer Experience:**
- ✅ Simple to implement
- ✅ Clear logging of what's happening
- ✅ Easy to debug
- ✅ Comprehensive error handling

---

## 🚀 READY TO USE

**This system is LIVE and ACTIVE in:**
- `/src/lib/aiConsensus.ts` (main implementation)
- All consensus verification calls
- All AI model calls

**When creating new blueprints or generators:**
1. Copy the blueprint template above
2. Use `runConsensusVerification` for all AI calls
3. NEVER use direct API calls without fallbacks
4. Test with simulation mode first
5. Add real API keys when ready

---

**Questions? See:** `/AI_INTEGRATION_TESTING_GUIDE.md`
**Implementation:** `/src/lib/aiConsensus.ts`
**Test Script:** `/scripts/test_consensus_system.ts`
