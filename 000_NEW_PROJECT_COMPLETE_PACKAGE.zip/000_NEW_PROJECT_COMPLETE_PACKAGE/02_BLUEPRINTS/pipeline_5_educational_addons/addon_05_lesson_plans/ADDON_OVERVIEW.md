# 📖 ADDON TYPE 5: LESSON PLANS

**Pipeline:** 5 - Educational Addons
**Addon ID:** 05
**Priority:** ESSENTIAL
**Complexity:** VERY HIGH

---

## 📊 OVERVIEW

Lesson Plans are comprehensive instructional guides providing complete teaching frameworks, detailed procedures, differentiation strategies, assessment tools, and all supporting materials needed for effective instruction.

### **Purpose:**
- Guide effective instruction
- Ensure curriculum coverage
- Support teacher planning
- Enable consistent quality
- Facilitate professional development

### **Key Statistics:**
- **110+ features** across 11 major components
- **60-84 complete lesson plans** per subject book
- **Multiple lesson models** (direct instruction, inquiry, project-based, etc.)
- **Full differentiation support** built-in
- **Assessment integrated** throughout

---

## 📚 THE 11 MAJOR COMPONENTS

### **1. Lesson Overview (12 features)**
- Lesson title
- Grade level specification
- Time allocation
- Materials needed
- Technology requirements
- Prerequisite knowledge
- Learning objectives
- Standards alignment
- Essential questions
- Big ideas
- Vocabulary list
- Connection to prior/future learning

### **2. Learning Objectives (10 features)**
- Measurable outcomes
- Bloom's taxonomy levels
- Student-friendly language
- Success criteria
- Performance indicators
- Assessment connections
- Skill development goals
- Knowledge targets
- Application objectives
- Transfer goals

### **3. Standards Alignment (8 features)**
- Common Core references
- State standards
- Subject-specific standards
- 21st-century skills
- SEL competencies
- Digital literacy
- Cross-curricular connections
- Career readiness links

### **4. Materials & Resources (11 features)**
- Complete materials list
- Quantity specifications
- Technology needs
- Digital resources
- Manipulatives required
- Handout templates
- Visual aids
- Reference materials
- Alternative options
- Accessibility accommodations
- Cost considerations

### **5. Lesson Procedures (20 features)**

**Opening/Engagement (5-10 minutes):**
- Hook activity
- Prior knowledge activation
- Learning objective introduction
- Relevance connection
- Success criteria sharing

**Direct Instruction/Modeling (15-20 minutes):**
- Concept introduction
- Clear explanations
- Think-aloud demonstrations
- Multiple examples
- Visual supports
- Checking for understanding
- Guided practice
- Error prevention

**Guided Practice (15-20 minutes):**
- Scaffolded activities
- Teacher circulation
- Formative checks
- Immediate feedback
- Reteaching opportunities
- Group work
- Partner activities

**Independent Practice (15-20 minutes):**
- Individual application
- Transfer tasks
- Problem-solving
- Creative applications
- Skill reinforcement

**Closure/Reflection (5-10 minutes):**
- Summary
- Key takeaways
- Exit tickets
- Goal setting
- Preview next lesson

### **6. Differentiation Strategies (15 features)**
- Content differentiation
- Process modifications
- Product variations
- Environment adjustments
- Below-level support
- On-level expectations
- Above-level extensions
- English language learner support
- Special education modifications
- Gifted enrichment
- Learning style variations
- Multiple intelligence approaches
- Cultural responsiveness
- Readiness levels
- Interest-based options

### **7. Assessment Tools (14 features)**
- Formative assessments
- Summative assessments
- Pre-assessments
- Self-assessments
- Peer assessments
- Observation checklists
- Exit tickets
- Quick checks
- Performance tasks
- Rubrics
- Rating scales
- Anecdotal records
- Student work samples
- Data collection tools

### **8. Questioning Strategies (8 features)**
- Lower-order questions
- Higher-order questions
- Open-ended prompts
- Probing questions
- Wait time guidance
- Think-pair-share
- Socratic questioning
- Discussion starters

### **9. Classroom Management (6 features)**
- Transition strategies
- Grouping configurations
- Time management
- Behavior expectations
- Attention signals
- Pacing guidance

### **10. Extension & Enrichment (8 features)**
- Challenge activities
- Research projects
- Creative applications
- Real-world connections
- Technology integration
- Cross-curricular links
- Community connections
- Career exploration

### **11. Reflection & Follow-Up (8 features)**
- Teacher reflection prompts
- Lesson effectiveness analysis
- Student understanding assessment
- Pacing evaluation
- Modification notes
- Success indicators
- Areas for improvement
- Next steps planning

---

## 🎨 QUALITY STANDARDS

### **Each Lesson Plan Must Include:**

1. **Complete Instructional Framework**
   - All components present
   - Logical flow
   - Clear structure
   - Realistic timing
   - Practical application

2. **Clear Learning Path**
   - Objectives drive instruction
   - Assessment aligned
   - Scaffolding evident
   - Progression logical
   - Engagement maintained

3. **Differentiation Built-In**
   - Multiple entry points
   - Varied approaches
   - Flexible grouping
   - Support and challenge
   - Universal design

4. **Assessment Integration**
   - Formative throughout
   - Summative appropriate
   - Data-informed
   - Student-involved
   - Standards-aligned

5. **Teacher-Ready**
   - Easy to implement
   - Clear instructions
   - All materials included
   - Tested and refined
   - Professionally formatted

6. **Research-Based**
   - Best practices
   - Evidence-based strategies
   - Current pedagogy
   - Proven methods
   - Continuous improvement

---

## 🎯 LESSON MODELS SUPPORTED

### **1. Direct Instruction**
- Explicit teaching
- Modeling
- Guided practice
- Independent practice

### **2. Inquiry-Based**
- Question-driven
- Student investigation
- Discovery learning
- Problem-based

### **3. Cooperative Learning**
- Group work structured
- Individual accountability
- Positive interdependence
- Social skills development

### **4. Project-Based Learning**
- Authentic projects
- Extended investigation
- Product creation
- Public presentation

### **5. Flipped Classroom**
- Pre-class learning
- In-class application
- Teacher as facilitator
- Personalized support

### **6. Station Teaching**
- Multiple stations
- Rotation schedules
- Varied activities
- Small group instruction

### **7. Technology-Enhanced**
- Digital tools integrated
- Interactive elements
- Online resources
- Blended learning

---

## 🤖 AI MODEL ASSIGNMENTS

### **Lesson Planning:**
- **Primary:** Claude 3.5 Sonnet (educational expertise)
- **Secondary:** GPT-5.1 (creative activities)
- **Support:** Gemini Pro 1.5 (multi-modal integration)

### **Differentiation Design:**
- **Primary:** Claude 3.5 Sonnet (inclusive practices)
- **Support:** GPT-5 Pro (comprehensive options)

### **Assessment Creation:**
- **Primary:** GPT-5 Pro (quality assessments)
- **Verification:** Claude 3.5 Sonnet

### **Standards Alignment:**
- **Primary:** GPT-5 Pro (comprehensive alignment)
- **Verification:** Claude 3.5 Sonnet

### **Quality Assurance:**
- **Pedagogy:** Claude 3.5 Sonnet
- **Completeness:** Gemini Pro 1.5
- **Practicality:** GPT-5.1
- **Innovation:** Perplexity Pro

---

## 📈 SCALING FACTORS

**Per Subject Book:**
- **Elementary:** 60-70 lesson plans
- **Middle School:** 70-80 lesson plans
- **High School:** 80-84 lesson plans
- **Professional:** 40-50 lesson plans

**Lesson Lengths:**
- Mini-lessons: 15-20 minutes
- Standard lessons: 45-60 minutes
- Extended lessons: 90 minutes
- Multi-day units: 2-5 days

---

## 🎯 OUTPUT FORMATS

All lesson plans generated in:
- **PDF** (printable, formatted)
- **DOCX** (editable for customization)
- **HTML** (web-based, linked resources)
- **Google Docs format** (cloud collaboration)
- **Notion templates** (digital planning)

---

## ✅ COMPLETION CRITERIA

Lesson Plans are COMPLETE when:
1. ✅ All 11 components included
2. ✅ 60-84 lessons per subject
3. ✅ Standards alignment verified
4. ✅ Differentiation comprehensive
5. ✅ Assessments integrated
6. ✅ All materials listed
7. ✅ Timing realistic and tested
8. ✅ All formats generated
9. ✅ Teacher review completed
10. ✅ Classroom-tested (where possible)

---

**Status:** READY FOR GENERATION
**Last Updated:** December 21, 2025
