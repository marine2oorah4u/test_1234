# **FEATURE 36: PROBLEM SOLVING CHALLENGES**
## **Detailed Specification - ONE Comprehensive Challenge Per File**

---

## **📋 OVERVIEW**

### **What is a Problem Solving Challenge?**
A **complete, self-contained problem scenario** that requires students to:
- Analyze complex information
- Apply critical thinking
- Consider multiple perspectives
- Make evidence-based decisions
- Justify their reasoning
- Create a solution or recommendation

### **NOT Just a Worksheet**
- ❌ NOT a single-page worksheet with 5 questions
- ❌ NOT a collection of unrelated problems
- ❌ NOT simple practice problems
- ✅ ONE rich, deep, multi-faceted challenge

---

## **📏 STANDARD STRUCTURE (10-15 Pages)**

### **PAGE BREAKDOWN:**

```
SECTION 1: COVER & INTRODUCTION (2-3 pages)
├── Page 1: Cover Page
├── Page 2: Challenge Overview
└── Page 3: Learning Objectives & Standards

SECTION 2: THE CHALLENGE (2-3 pages)
├── Page 4: Scenario Introduction (engaging story)
├── Page 5: Problem Statement (clear, specific)
└── Page 6: Constraints & Success Criteria

SECTION 3: RESOURCE PACKET (3-4 pages)
├── Page 7: Data Set 1 (charts, graphs, facts)
├── Page 8: Data Set 2 (additional information)
├── Page 9: Reference Materials (glossary, formulas)
└── Page 10: Expert Perspectives (quotes, viewpoints)

SECTION 4: STUDENT WORKSHEETS (3-4 pages)
├── Page 11: Analysis Worksheet
├── Page 12: Planning Organizer
├── Page 13: Solution Development Template
└── Page 14: Presentation Outline

SECTION 5: TEACHER MATERIALS (2-3 pages)
├── Page 15: Solution Pathways Guide
├── Page 16: Assessment Rubric
└── Page 17: Extensions & Modifications

TOTAL: 17 pages (can be 10-15 depending on complexity)
```

---

## **📖 DETAILED EXAMPLE: "VOLCANO WARNING SYSTEM DESIGN CHALLENGE"**

### **SECTION 1: COVER & INTRODUCTION**

#### **Page 1: COVER PAGE**
```
Visual Design:
- Dramatic volcano photo background
- Title in large, engaging font: "DESIGN A VOLCANO WARNING SYSTEM"
- Subtitle: "An Engineering & Earth Science Challenge"
- Icons showing: Grade 6-8 | 2-3 class periods | Difficulty 48/100
- Subject tags: Earth Science, Engineering Design, Critical Thinking
- Colorful, professional layout (TIER 1 quality)
```

#### **Page 2: CHALLENGE OVERVIEW**
```
THE SITUATION:
[Engaging narrative, 2-3 paragraphs]

"Mount Cascade hasn't erupted in 150 years, but it's waking up.
The town of Riversdale (population 15,000) sits just 20 miles
from the volcano. For generations, this mountain has been a
peaceful neighbor, but recent activity has scientists worried.

Your team has been hired as engineering consultants to design
a comprehensive early warning system. Lives depend on your
ability to create a system that:
- Detects volcanic activity early
- Communicates warnings effectively to all residents
- Works even during power outages
- Fits within the town's limited budget

You'll need to balance safety, cost, technology, and human
factors to create the best possible solution."

WHAT YOU'LL DO:
[Bulleted list with icons]
• Analyze volcanic monitoring data
• Research warning system technologies
• Design a multi-component alert system
• Create a communication plan
• Present your solution to "town officials" (classmates)

WHY THIS MATTERS:
[Real-world connection, 1 paragraph]
"Real communities around the world face these exact challenges.
Scientists and engineers work together to save lives through
early warning systems. Your solution could mirror real approaches
used in places like Japan, Indonesia, or the Pacific Northwest."
```

#### **Page 3: LEARNING OBJECTIVES & STANDARDS**
```
LEARNING OBJECTIVES:
By completing this challenge, you will:
□ Analyze volcanic monitoring data and identify warning signs
□ Evaluate different technologies for effectiveness and cost
□ Apply the engineering design process to a real-world problem
□ Consider multiple stakeholder perspectives (scientists, officials, residents)
□ Communicate technical information to non-expert audiences
□ Make evidence-based decisions under constraints

SKILLS DEVELOPED:
[Visual skill badges/icons]
• Critical Thinking        • Data Analysis
• Systems Thinking        • Written Communication
• Problem Solving         • Oral Presentation
• Collaboration          • Engineering Design

STANDARDS ALIGNMENT:
Next Generation Science Standards (NGSS):
- MS-ESS3-2: Natural Hazard Solutions
- MS-ETS1-1: Engineering Design Process
- MS-ETS1-2: Evaluate Competing Design Solutions

Common Core Math:
- 7.SP.B.3: Compare data distributions
- 7.RP.A.3: Multi-step ratio problems

Common Core ELA:
- WHST.6-8.1: Write arguments with claims and evidence
- SL.6-8.4: Present information clearly
```

---

### **SECTION 2: THE CHALLENGE**

#### **Page 4: SCENARIO INTRODUCTION**
```
[Full-page visual with map and timeline]

MAP OF RIVERSDALE REGION:
[Colorful illustrated map showing]
- Mount Cascade (with elevation markers)
- Town of Riversdale (detailed)
- Evacuation routes (highways)
- Safe zones
- Rivers and valleys
- Critical infrastructure (hospital, schools, police/fire)
- Population density shading

TIMELINE OF RECENT ACTIVITY:
[Visual timeline graphic]

6 WEEKS AGO:
↓ First increased seismic activity detected
↓ Small earthquakes (magnitude 2-3)

4 WEEKS AGO:
↓ Steam vents appear near summit
↓ Slight increase in sulfur dioxide emissions

2 WEEKS AGO:
↓ Earthquake frequency doubles
↓ Scientists upgrade alert level to YELLOW

YESTERDAY:
↓ Ground deformation detected (3 cm uplift)
↓ Gas emissions increasing steadily

TODAY:
↓ You've been called in to design warning system
↓ Alert level remains YELLOW (heightened unrest)

THE QUESTION:
"The volcano might erupt tomorrow, next month, or not for
years. Your warning system needs to work for all scenarios.
What will you design?"
```

#### **Page 5: PROBLEM STATEMENT**
```
[Clear, boxed statement with visual emphasis]

YOUR MISSION:
Design a comprehensive volcano early warning system for
Riversdale that will:

1. DETECT volcanic activity changes
   - Monitor seismic activity
   - Track gas emissions
   - Measure ground deformation
   - Other monitoring methods

2. ANALYZE data and make decisions
   - Determine alert levels
   - Decide when to evacuate
   - Coordinate with officials

3. COMMUNICATE warnings effectively
   - Reach all 15,000 residents
   - Work in multiple languages
   - Function during power outages
   - Be clear and understandable

4. OPERATE within constraints
   - Budget: $500,000 for equipment
   - Annual operating cost: $75,000/year
   - Must work 24/7/365
   - Staff: Maximum 3 full-time employees

YOUR DELIVERABLES:
□ System design diagram (showing all components)
□ Budget breakdown (itemized costs)
□ Communication plan (who gets warned, how, when)
□ Evacuation protocol (step-by-step procedures)
□ 3-5 minute presentation to "town council"
```

#### **Page 6: CONSTRAINTS & SUCCESS CRITERIA**
```
[Two-column layout with icons]

CONSTRAINTS (What Limits You):
━━━━━━━━━━━━━━━━━━━━━━━━━━

BUDGET:
• $500,000 initial equipment purchase
• $75,000/year operating costs
• Cannot request more funding

TECHNOLOGY:
• Must use proven, reliable technology
• Must work during power outages (backup power)
• Must survive volcanic conditions (heat, ash)

STAFFING:
• Maximum 3 full-time positions
• 24/7 monitoring required
• Staff need breaks, vacation, sick days

GEOGRAPHY:
• 20 miles from volcano to town
• Mountainous terrain (difficult access)
• Some residents live in remote areas
• Roads can be blocked by snow/mud

POPULATION:
• 15,000 residents total
• 30% speak Spanish as primary language
• 12% are over age 65
• Tourists visit year-round (variable population)

---

SUCCESS CRITERIA (How You'll Be Judged):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

EFFECTIVENESS (40 points)
□ Detects volcanic changes reliably
□ Provides early warning (hours/days, not minutes)
□ Reaches all residents
□ Clear, understandable messages

FEASIBILITY (30 points)
□ Stays within budget
□ Uses proven technology
□ Can be operated with 3 staff
□ Realistic and practical

THOROUGHNESS (20 points)
□ Considers all stakeholder needs
□ Addresses failure scenarios
□ Includes backup systems
□ Detailed and complete plan

PRESENTATION (10 points)
□ Clear communication of design
□ Effective visuals
□ Responds to questions
□ Professional delivery

TOTAL: 100 points possible
```

---

### **SECTION 3: RESOURCE PACKET**

#### **Page 7: DATA SET 1 - Volcanic Monitoring Technologies**
```
[Professional table with images and specs]

AVAILABLE MONITORING EQUIPMENT:
━━━━━━━━━━━━━━━━━━━━━━━━━━

1. SEISMOMETER NETWORK
[Image of seismometer]
What it does: Detects earthquakes
Cost: $50,000 per station
Operating: $5,000/year per station
Recommended: 5-8 stations for coverage
Pros: Very reliable, proven technology
Cons: Expensive to install many stations

2. GAS MONITORING STATION
[Image of gas sensor]
What it does: Measures SO₂, CO₂ in volcanic gases
Cost: $75,000 per station
Operating: $8,000/year per station
Recommended: 2-3 stations (upwind/downwind)
Pros: Direct measure of magma movement
Cons: Affected by weather conditions

3. GPS DEFORMATION NETWORK
[Image of GPS station]
What it does: Detects ground swelling/movement
Cost: $40,000 per station
Operating: $4,000/year per station
Recommended: 6-10 stations around volcano
Pros: Millimeter precision
Cons: Requires satellite connectivity

4. THERMAL CAMERAS
[Image of infrared camera]
What it does: Detects heat changes
Cost: $90,000 per camera
Operating: $3,000/year per camera
Recommended: 2-3 cameras with different views
Pros: Can see through darkness
Cons: Expensive, affected by weather/clouds

5. TILTMETERS
[Image of tiltmeter]
What it does: Measures ground tilting
Cost: $30,000 per instrument
Operating: $2,000/year per instrument
Recommended: 4-6 instruments
Pros: Simple, reliable
Cons: Less precise than GPS

6. WEBCAMS
[Image of weather-resistant camera]
What it does: Visual monitoring
Cost: $5,000 per camera
Operating: $500/year per camera
Recommended: 3-5 cameras
Pros: Cheap, useful for public
Cons: Doesn't work at night, bad weather

COMPARISON CHART:
[Visual chart comparing all technologies on:]
- Detection capability
- Reliability
- Cost (initial & operating)
- Maintenance needs
- Weather resistance
```

#### **Page 8: DATA SET 2 - Warning & Communication Systems**
```
AVAILABLE ALERT SYSTEMS:
━━━━━━━━━━━━━━━━━━━━━━

1. EMERGENCY SIREN NETWORK
Cost: $25,000 per siren
Coverage: 1-mile radius per siren
Needed: ~8 sirens for full town coverage
Pros: Reaches everyone outdoors, works during power outage
Cons: Doesn't work indoors, not specific messages

2. EMERGENCY TEXT/CALL SYSTEM
Cost: $50,000 setup + $20,000/year service
Coverage: Anyone registered with phone number
Pros: Direct, detailed messages, two-way communication
Cons: Requires cell towers, not everyone has phones

3. LOCAL RADIO/TV INTERRUPTION
Cost: $30,000 equipment + $10,000/year
Coverage: Anyone with radio/TV on
Pros: Detailed information, maps, updates
Cons: Only works if people are listening/watching

4. SMARTPHONE APP
Cost: $80,000 development + $15,000/year maintenance
Coverage: Anyone who downloads app
Pros: GPS-based alerts, push notifications, maps
Cons: Requires smartphones, not all residents have

5. AUTOMATED PHONE CALLS
Cost: $40,000 setup + $12,000/year
Coverage: All landlines and registered cell phones
Pros: Reaches elderly, detailed voice message
Cons: Slow (100 calls/minute), landlines going away

6. OUTDOOR LED SIGNS
Cost: $35,000 per sign
Coverage: Major roads and intersections
Needed: 4-5 signs
Pros: Visible 24/7, changeable messages
Cons: Only works for people outside/driving

7. DOOR-TO-DOOR NOTIFICATION TEAMS
Cost: $0 equipment, requires volunteer coordination
Coverage: Every residence eventually
Pros: Reaches everyone, personal contact
Cons: SLOW (hours for full town), requires many volunteers

POPULATION DATA:
[Pie charts showing]
- 75% have smartphones
- 85% have cell phones (any type)
- 40% have landlines
- 30% speak Spanish primarily
- 12% over age 65
- 8% hearing impaired
```

#### **Page 9: REFERENCE MATERIALS**
```
VOLCANIC ALERT LEVELS:
━━━━━━━━━━━━━━━━━━━━

[Visual alert level graphic with colors]

GREEN (Normal, Non-eruptive)
• Background activity only
• No increased unrest
Action: Routine monitoring

YELLOW (Advisory, Elevated Unrest)
• Increased seismic activity OR
• Increased gas emissions OR
• Ground deformation detected
Action: Increased monitoring, inform officials

ORANGE (Watch, Heightened Unrest)
• Multiple warning signs present
• Eruption possible within weeks
Action: Prepare for evacuation, alert public

RED (Warning, Eruption Imminent/Underway)
• Eruption underway or expected within hours/days
• Major hazards likely
Action: EVACUATE immediately

---

EVACUATION TIME CALCULATIONS:
━━━━━━━━━━━━━━━━━━━━━━━━━━

[Diagram showing]
Town population: 15,000 people
Available vehicles: ~6,000 cars
Average occupancy: 2.5 people/car

Main highway capacity: 1,200 cars/hour
Time to evacuate: 15,000 ÷ 2.5 ÷ 1,200 = 5 hours

BUT: Many people at work, school, need to pack
Realistic evacuation time: 12-18 hours

Warning needed: At least 24 hours advance notice

---

KEY TERMS:
━━━━━━━━━━

Seismic Activity: Earthquakes caused by magma movement
Ground Deformation: Swelling/tilting as magma pushes up
Gas Emissions: Gases released as magma rises (SO₂, CO₂)
Lahar: Volcanic mudflow (mix of ash, water, debris)
Pyroclastic Flow: Fast-moving cloud of hot gas and rock
Tephra: Volcanic ash and rock fragments
```

#### **Page 10: EXPERT PERSPECTIVES**
```
WHAT DO THE EXPERTS SAY?
━━━━━━━━━━━━━━━━━━━━━━

[Quotation boxes with headshots/icons]

DR. SARAH CHEN, Volcanologist, USGS:
💬 "The best warning system combines multiple monitoring
technologies. No single instrument tells the whole story.
Seismometers might detect earthquakes, but gas sensors
tell us if new magma is involved. We need both."

CHIEF MARTINEZ, Riversdale Fire Department:
💬 "The technology is only half the battle. If people
don't understand the warning or don't believe it's serious,
they won't evacuate. We learned that the hard way in 2015
when we had a false alarm and people ignored the next
warning."

MARIA RODRIGUEZ, Community Organizer:
💬 "Many of our residents speak Spanish at home. Some
elderly residents don't use smartphones. Any warning
system that only works for tech-savvy English speakers
will fail our most vulnerable community members."

MAYOR JACKSON, Riversdale:
💬 "I support any system that saves lives, but we have
a limited budget. We can't afford a $2 million system.
We need something effective AND affordable. Creativity
and smart choices matter more than expensive equipment."

PROFESSOR KIM, University Engineering Department:
💬 "Redundancy is critical. What happens if your primary
alert system fails during the eruption? Volcanic ash can
knock out power, cell towers, even internet. Your backup
systems need backups."

HISTORICAL NOTE:
[Boxed callout]
⚠️ In 1985, the Nevado del Ruiz volcano in Colombia erupted.
Scientists detected warning signs, but communication failures
meant warnings didn't reach the town of Armero in time.
More than 23,000 people died. A better warning system could
have saved most of them.
```

---

### **SECTION 4: STUDENT WORKSHEETS**

#### **Page 11: ANALYSIS WORKSHEET**
```
STEP 1: ANALYZE THE MONITORING OPTIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[Table format for students to fill in]

Technology | Initial Cost | Annual Cost | Pros | Cons | Include? (Y/N)
-----------|--------------|-------------|------|------|---------------
Seismometer Network | $ _____ | $ _____ | | | □
Gas Monitoring | $ _____ | $ _____ | | | □
GPS Deformation | $ _____ | $ _____ | | | □
[etc. for all 6 technologies]

TOTAL MONITORING COSTS:
Initial: $ ____________
Annual: $ ____________

Does this fit the budget?
Initial Budget Available: $500,000
Annual Budget Available: $75,000

If NO, what will you cut? Why?
_________________________________________________
_________________________________________________

---

STEP 2: ANALYZE THE WARNING OPTIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[Similar table for warning systems]

Technology | Cost | Coverage | Pros | Cons | Include? (Y/N)
-----------|------|----------|------|------|---------------
Emergency Sirens | $ _____ | ____ % | | | □
Text/Call System | $ _____ | ____ % | | | □
[etc. for all 7 warning systems]

Which groups might each system miss?
_________________________________________________
_________________________________________________

How will you reach everyone?
_________________________________________________
_________________________________________________
```

#### **Page 12: PLANNING ORGANIZER**
```
SYSTEM DESIGN PLANNING
━━━━━━━━━━━━━━━━━━━━

PART 1: YOUR MONITORING NETWORK
[Box for students to draw/diagram]

Draw or describe where you'll place monitoring equipment:
□ How many seismometers? Where?
□ How many gas sensors? Where?
□ How many GPS stations? Where?
□ Other equipment?

Why did you choose these locations?
_________________________________________________
_________________________________________________

PART 2: YOUR WARNING STRATEGY
[Flowchart template]

YELLOW Alert Detected
↓
What happens? Who gets notified?
[Box to fill in]
↓
ORANGE Alert - Heightened
↓
What actions? What warnings go out?
[Box to fill in]
↓
RED Alert - Evacuate NOW
↓
How do you reach everyone? What's the message?
[Box to fill in]

PART 3: YOUR STAFFING PLAN

How will 3 people monitor 24/7?
[Shift schedule template to fill in]

Monday-Friday:
Shift 1 (7am-3pm): _________________
Shift 2 (3pm-11pm): _________________
Shift 3 (11pm-7am): _________________

Weekends:
[Similar schedule]

Who handles emergencies on days off?
_________________________________________________
```

#### **Page 13: SOLUTION DEVELOPMENT TEMPLATE**
```
FINAL SYSTEM DESIGN
━━━━━━━━━━━━━━━━━━

SYSTEM NAME: _______________________________

[Large box for system diagram]

DRAW YOUR COMPLETE SYSTEM:
Include:
• Monitoring equipment locations
• Communication between components
• Warning distribution methods
• Backup power systems
• Control center location

BUDGET BREAKDOWN:
━━━━━━━━━━━━━━━━

MONITORING EQUIPMENT:
Item 1: _________________ $ __________
Item 2: _________________ $ __________
Item 3: _________________ $ __________
[Continue...]

TOTAL INITIAL COST: $ __________
(Must be ≤ $500,000)

ANNUAL OPERATING COSTS:
Equipment maintenance: $ __________
Staff salaries (3 people): $ __________
Communication services: $ __________
Utilities: $ __________
Training: $ __________

TOTAL ANNUAL COST: $ __________
(Must be ≤ $75,000)

SPECIAL FEATURES:
━━━━━━━━━━━━━━━━

What makes your system special?
□ Reaches non-English speakers
□ Works without power
□ Redundant backups
□ Accessible to disabled residents
□ Other: _______________________

How does your system handle these scenarios?

SCENARIO 1: Eruption happens at 3am
_________________________________________________

SCENARIO 2: Power outage during evacuation
_________________________________________________

SCENARIO 3: Cell towers fail due to ash
_________________________________________________
```

#### **Page 14: PRESENTATION OUTLINE**
```
PRESENTATION PLANNING
━━━━━━━━━━━━━━━━━━━

You have 3-5 minutes to present your design to the
"Town Council" (your classmates).

OPENING (30 seconds)
Hook: Why your system will save lives
_________________________________________________
_________________________________________________

MAIN CONTENT (2-3 minutes)
1. Monitoring Approach
   What technologies? Why?
   _________________________________________________

2. Warning Strategy
   How will people be alerted?
   _________________________________________________

3. Budget Summary
   How you stayed within limits
   _________________________________________________

4. Special Features
   What makes your system better?
   _________________________________________________

CLOSING (30 seconds)
Call to action: Why the town should choose your design
_________________________________________________
_________________________________________________

VISUAL AIDS:
□ System diagram (drawn or digital)
□ Budget chart
□ Map showing equipment locations
□ Warning message example

PRACTICE NOTES:
□ Practice at least 3 times
□ Time yourself (stay under 5 minutes)
□ Prepare for questions
□ Speak clearly and confidently
```

---

### **SECTION 5: TEACHER MATERIALS**

#### **Page 15: SOLUTION PATHWAYS GUIDE** (TEACHER ONLY)
```
MULTIPLE VALID APPROACHES
━━━━━━━━━━━━━━━━━━━━━━

This challenge has NO single "correct" answer. Students
should make reasonable trade-offs based on their priorities.

APPROACH 1: TECHNOLOGY-FOCUSED
Prioritizes advanced monitoring equipment
- High-tech sensors (GPS, thermal cameras)
- Fewer redundant systems
- Assumes technology reliability
Budget: Maxes out equipment spending

APPROACH 2: COMMUNICATION-FOCUSED
Prioritizes reaching all residents
- Multiple warning methods
- Emphasis on Spanish-language support
- Low-tech backups (sirens, door-to-door)
Budget: More spent on alert systems

APPROACH 3: BALANCED COMPROMISE
Mix of monitoring and warning
- Essential sensors only (seismometers, gas)
- Multiple communication methods
- Some redundancy
Budget: Distributed across categories

APPROACH 4: HUMAN-CENTERED
Prioritizes community needs
- Focus on elderly, non-English speakers
- Door-to-door coordination plan
- Simple, clear messaging systems
Budget: Less on tech, more on communication

---

COMMON STUDENT CHALLENGES:
━━━━━━━━━━━━━━━━━━━━━━

CHALLENGE: Trying to buy everything
HINT: "Your budget is limited. What's most essential?"

CHALLENGE: Ignoring non-English speakers
HINT: "How will the 30% Spanish-speaking population
receive warnings?"

CHALLENGE: No backup plan for tech failure
HINT: "What if power and cell towers fail during eruption?"

CHALLENGE: Unrealistic staffing (1 person 24/7)
HINT: "People need sleep, breaks, and days off. How can
3 people cover all shifts?"

CHALLENGE: Vague evacuation plan
HINT: "Be specific: who gets warned first? What's the
exact message? How do you confirm everyone heard it?"

---

SAMPLE SCORING RUBRIC:
━━━━━━━━━━━━━━━━━━━

EFFECTIVENESS (40 points)
36-40: Comprehensive system, addresses all hazards,
       realistic warning timeline
31-35: Good system, minor gaps in coverage
26-30: Basic system, several missing elements
Below 25: Incomplete or ineffective

FEASIBILITY (30 points)
27-30: Within budget, realistic staffing, proven tech
23-26: Slightly over budget OR minor feasibility issues
19-22: Significant budget or feasibility problems
Below 19: Unrealistic or far over budget

[Continue for other categories...]
```

#### **Page 16: ASSESSMENT RUBRIC**
```
[Full-page detailed rubric - color-coded grid]

CRITERION | EXEMPLARY (9-10) | PROFICIENT (7-8) | DEVELOPING (5-6) | BEGINNING (1-4)
----------|------------------|------------------|------------------|----------------
Monitoring System Design | Comprehensive multi-sensor network, strategic placement, justified choices | Adequate sensors, reasonable placement, basic justification | Limited sensors, some placement issues, weak justification | Incomplete or ineffective monitoring
Warning System Design | Multiple methods, reaches all populations, includes backups | Good coverage, considers most groups, some redundancy | Basic coverage, misses some groups, limited backups | Inadequate coverage or no redundancy
Budget Management | Within limits, detailed breakdown, smart allocation | Within limits, adequate detail, reasonable choices | Slightly over OR lacks detail | Significantly over budget
Communication Plan | Clear protocols, multilingual, addresses special needs | Clear protocols, considers language, basic accommodations | Basic protocols, limited consideration of diversity | Unclear or incomplete protocols
Evidence Use | Extensive use of provided data, additional research, justified with evidence | Good use of data, research evident, solid justification | Some data use, limited research, weak justification | Little data use, no additional research
Presentation | Clear, confident, effective visuals, responds well to questions | Clear communication, good visuals, answers questions | Basic communication, simple visuals, struggles with questions | Unclear or incomplete presentation
```

#### **Page 17: EXTENSIONS & MODIFICATIONS**
```
DIFFERENTIATION OPTIONS:
━━━━━━━━━━━━━━━━━━━━━━

FOR ADVANCED STUDENTS:
□ Calculate cost-benefit ratio for each technology
□ Design computer model of alert system timing
□ Research real warning systems (Japan, Iceland)
□ Create training manual for system operators
□ Design public education campaign about volcano safety

FOR STRUGGLING STUDENTS:
□ Provide pre-selected technology options (3 instead of 6)
□ Give budget worksheet with costs pre-filled
□ Offer system design template to follow
□ Allow partner work with role assignments
□ Extend time for completion

FOR ELL STUDENTS:
□ Provide glossary with images for key terms
□ Allow presentation in primary language
□ Pair with bilingual buddy
□ Offer sentence frames for written responses
□ Pre-teach technical vocabulary

FOR STUDENTS WITH DISABILITIES:
□ Provide digital version for screen readers
□ Allow verbal responses instead of written
□ Break project into smaller milestones
□ Provide graphic organizers
□ Reduce presentation time requirement

---

EXTENSION ACTIVITIES:
━━━━━━━━━━━━━━━━━━

EXTENSION 1: Test Your System
Simulate an eruption scenario and "test" designs
Students respond to simulated events in real-time

EXTENSION 2: Cost-Benefit Analysis
Calculate lives saved vs. dollars spent
Compare to other community investments

EXTENSION 3: Public Communication
Create actual warning messages for different alert levels
Design social media posts, emergency broadcasts

EXTENSION 4: Stakeholder Presentations
Present to different audiences:
- Scientists (technical details)
- Town council (budget focus)
- Public (simple, clear messaging)

---

INTERDISCIPLINARY CONNECTIONS:
━━━━━━━━━━━━━━━━━━━━━━━━━

MATH: Budget calculations, cost comparisons, ratios
SCIENCE: Volcanic processes, hazard assessment
ELA: Technical writing, persuasive presentation
SOCIAL STUDIES: Community planning, emergency management
TECHNOLOGY: Communication systems, sensors, networks

---

REAL-WORLD CONNECTIONS:
━━━━━━━━━━━━━━━━━━━━

Examples to share with students:
• Cascades Volcano Observatory (USGS)
• Japan Meteorological Agency tsunami warnings
• Iceland's volcanic monitoring network
• Philippine Institute of Volcanology

Optional field trip: Local emergency management office
Guest speaker: Emergency manager or geologist
```

---

## **✅ QUALITY CHECKLIST**

Before releasing this challenge addon:

### **Content Quality**
- [x] Engaging, realistic scenario
- [x] Clear problem statement
- [x] Specific constraints and success criteria
- [x] Adequate data and resources provided
- [x] Multiple valid solution pathways
- [x] Appropriate difficulty level (48/100)
- [x] Real-world relevance demonstrated

### **Visual Quality**
- [x] TIER 1/2 professional design
- [x] Full-color throughout
- [x] High-quality images and graphics
- [x] Visual hierarchy clear
- [x] Engaging, not overwhelming
- [x] Maps, charts, diagrams included
- [x] Professional typography

### **Completeness**
- [x] All sections present (10-17 pages)
- [x] Teacher materials comprehensive
- [x] Student worksheets scaffolded
- [x] Assessment rubric detailed
- [x] Extensions and modifications provided
- [x] Standards alignment specified
- [x] Ready to use immediately

### **Usability**
- [x] Teacher can use without preparation
- [x] Instructions clear and specific
- [x] Resources organized logically
- [x] Print-ready formatting
- [x] Differentiation options included
- [x] No ambiguity or assumptions

---

## **📦 DELIVERABLE PACKAGE**

```
/challenge_volcano_warning_system/
  ├── volcano_warning_system_FULL_COLOR.pdf (17 pages)
  ├── volcano_warning_system_PRINT_FRIENDLY.pdf (B&W version)
  ├── volcano_warning_system_QUICK_START.pdf (1-page overview)
  └── /assets/
      ├── /images/
      │   ├── volcano_photo.jpg
      │   ├── map_riversdale.png
      │   ├── equipment_photos/
      │   └── alert_level_graphics.svg
      ├── /templates/
      │   ├── system_design_template.pdf
      │   ├── budget_worksheet.xlsx
      │   └── presentation_slides.pptx
      └── /answer_keys/
          └── sample_solutions.pdf
```

---

## **🎯 THIS IS THE STANDARD**

**Every Problem Solving Challenge must meet this level of detail.**

Not acceptable:
- ❌ "Challenge: Design a warning system. Use the budget worksheet."
- ❌ One-page problem with no context
- ❌ Collection of 10 small problems

Required:
- ✅ 10-17 pages comprehensive challenge
- ✅ Rich scenario with real-world context
- ✅ Complete resource packet
- ✅ Scaffolded student worksheets
- ✅ Detailed teacher guide
- ✅ Professional visual design
- ✅ Ready for immediate classroom use

**This is Feature 36. ONE challenge like this per addon file.**
