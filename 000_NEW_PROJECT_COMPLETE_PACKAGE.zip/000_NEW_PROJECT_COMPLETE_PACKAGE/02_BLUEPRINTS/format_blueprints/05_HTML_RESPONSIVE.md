# Format Blueprint: HTML Responsive Website

## Metadata
- **Format ID**: `05_HTML_RESPONSIVE`
- **Format Name**: Responsive HTML Website
- **Tier**: 1 (Core - Always Generate)
- **File Extension**: `.html` + assets
- **Priority**: Critical
- **Use Case**: Web reading, LMS, online access

---

## Overview

### Purpose
Create fully responsive, mobile-first websites for reading books online. Works on ANY device with a web browser - no apps, no downloads, instant access.

### Key Advantages
- ✅ **Universal Access**: Works on phones, tablets, desktops
- ✅ **No Installation**: Just open in browser
- ✅ **Always Up-to-Date**: Easy to update, no re-downloads
- ✅ **Search Engine Friendly**: Can be indexed by Google
- ✅ **Interactive**: Full JavaScript capabilities
- ✅ **Accessible**: Screen readers, keyboard navigation
- ✅ **Shareable**: Just send a link
- ✅ **Fast**: Progressive web app (PWA) capable

---

## Responsive Design Breakpoints

```css
/* Mobile First Approach */
/* Base styles: Mobile (320px+) */

@media (min-width: 640px) {
  /* sm: Small tablets */
}

@media (min-width: 768px) {
  /* md: Tablets */
}

@media (min-width: 1024px) {
  /* lg: Laptops */
}

@media (min-width: 1280px) {
  /* xl: Desktops */
}

@media (min-width: 1536px) {
  /* 2xl: Large screens */
}
```

---

## File Structure

```
book_website/
├── index.html (landing/cover page)
├── toc.html (table of contents)
├── chapter-01.html
├── chapter-02.html
├── ...
├── css/
│   ├── reset.css
│   ├── typography.css
│   ├── layout.css
│   ├── components.css
│   ├── themes.css (Math=blue, Science=green, etc.)
│   └── print.css (for Format 31)
├── js/
│   ├── navigation.js
│   ├── search.js
│   ├── bookmarks.js
│   ├── progress-tracker.js
│   ├── theme-switcher.js
│   └── accessibility.js
├── images/
│   ├── cover.jpg
│   ├── figure-01.jpg
│   └── ...
├── fonts/ (optional)
│   └── OpenDyslexic.woff2
├── manifest.json (PWA)
├── service-worker.js (offline support)
└── README.md
```

---

## HTML Structure

### index.html (Landing Page)
```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Book Title - Educational Books</title>

  <!-- SEO -->
  <meta name="description" content="Complete algebra course for high school">
  <meta name="keywords" content="algebra, mathematics, high school, education">
  <meta name="author" content="Author Name">

  <!-- Open Graph (Social Media) -->
  <meta property="og:title" content="Book Title">
  <meta property="og:description" content="Complete algebra course">
  <meta property="og:image" content="images/cover.jpg">
  <meta property="og:type" content="book">

  <!-- Stylesheets -->
  <link rel="stylesheet" href="css/reset.css">
  <link rel="stylesheet" href="css/typography.css">
  <link rel="stylesheet" href="css/layout.css">
  <link rel="stylesheet" href="css/themes.css">

  <!-- PWA -->
  <link rel="manifest" href="manifest.json">
  <meta name="theme-color" content="#2563eb">

  <!-- Icons -->
  <link rel="icon" href="images/favicon.ico">
  <link rel="apple-touch-icon" href="images/icon-192.png">
</head>
<body data-subject="mathematics" data-theme="blue">

  <!-- Header -->
  <header class="site-header">
    <div class="container">
      <h1 class="site-title">Educational Books</h1>
      <nav class="main-nav" aria-label="Main navigation">
        <button id="menu-toggle" aria-label="Toggle menu">☰</button>
        <ul class="nav-menu">
          <li><a href="index.html">Home</a></li>
          <li><a href="toc.html">Contents</a></li>
          <li><a href="#search">Search</a></li>
          <li><button id="theme-toggle">🌓 Theme</button></li>
        </ul>
      </nav>
    </div>
  </header>

  <!-- Main Content -->
  <main class="container">
    <!-- Hero Section -->
    <section class="hero">
      <div class="book-cover">
        <img src="images/cover.jpg" alt="Book cover" width="400" height="600">
      </div>
      <div class="book-info">
        <h1 class="book-title">Algebra I: Complete Course</h1>
        <p class="book-subtitle">Mastering Mathematical Fundamentals</p>
        <p class="book-author">By Author Name</p>
        <p class="book-meta">
          Grade Level: 9-12 | Subject: Mathematics
        </p>
        <div class="cta-buttons">
          <a href="chapter-01.html" class="btn btn-primary">Start Reading</a>
          <a href="toc.html" class="btn btn-secondary">Table of Contents</a>
        </div>
      </div>
    </section>

    <!-- Book Description -->
    <section class="description">
      <h2>About This Book</h2>
      <p>Comprehensive algebra course covering...</p>
    </section>

    <!-- Features -->
    <section class="features">
      <h2>Features</h2>
      <div class="feature-grid">
        <div class="feature">
          <h3>📱 Mobile Friendly</h3>
          <p>Read on any device</p>
        </div>
        <div class="feature">
          <h3>🔍 Searchable</h3>
          <p>Find content instantly</p>
        </div>
        <div class="feature">
          <h3>🎨 Customizable</h3>
          <p>Adjust fonts, themes, size</p>
        </div>
        <div class="feature">
          <h3>♿ Accessible</h3>
          <p>Screen reader compatible</p>
        </div>
      </div>
    </section>
  </main>

  <!-- Footer -->
  <footer class="site-footer">
    <div class="container">
      <p>&copy; 2025 Educational Books System</p>
    </div>
  </footer>

  <!-- Scripts -->
  <script src="js/navigation.js"></script>
  <script src="js/theme-switcher.js"></script>
</body>
</html>
```

### chapter-01.html (Chapter Page)
```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Chapter 1: Introduction to Algebra</title>
  <link rel="stylesheet" href="css/reset.css">
  <link rel="stylesheet" href="css/typography.css">
  <link rel="stylesheet" href="css/layout.css">
  <link rel="stylesheet" href="css/themes.css">
</head>
<body data-subject="mathematics">

  <!-- Sticky Header -->
  <header class="chapter-header">
    <div class="container">
      <button class="back-btn" onclick="history.back()">← Back</button>
      <span class="chapter-title-small">Chapter 1</span>
      <button class="menu-btn">☰</button>
    </div>
  </header>

  <!-- Sidebar Navigation (Desktop) -->
  <aside class="sidebar">
    <nav aria-label="Chapter navigation">
      <h3>Contents</h3>
      <ul>
        <li><a href="toc.html">All Chapters</a></li>
        <li><a href="#section1-1" class="active">1.1 Basic Concepts</a></li>
        <li><a href="#section1-2">1.2 Variables</a></li>
        <li><a href="#section1-3">1.3 Expressions</a></li>
      </ul>
    </nav>

    <!-- Progress Indicator -->
    <div class="progress-widget">
      <h4>Your Progress</h4>
      <div class="progress-bar">
        <div class="progress-fill" style="width: 25%"></div>
      </div>
      <p>25% Complete</p>
    </div>
  </aside>

  <!-- Main Content Area -->
  <main class="content">
    <article class="chapter">
      <h1 id="chapter-1">Chapter 1: Introduction to Algebra</h1>

      <p class="lead">
        In this chapter, we will explore the fundamental concepts of algebra...
      </p>

      <!-- Section -->
      <section id="section1-1">
        <h2>1.1 Basic Concepts</h2>

        <p>Algebra is a branch of mathematics that...</p>

        <!-- Figure -->
        <figure>
          <img src="images/figure-01.jpg"
               alt="Coordinate plane showing x and y axes"
               loading="lazy">
          <figcaption>Figure 1.1: The Coordinate Plane</figcaption>
        </figure>

        <!-- Callout Box -->
        <aside class="callout tip">
          <h3>💡 Key Concept</h3>
          <p>Remember: The x-axis is horizontal, the y-axis is vertical.</p>
        </aside>

        <!-- Interactive Example (if enabled) -->
        <div class="interactive-example">
          <h3>Try It Yourself</h3>
          <div class="example-content">
            <!-- Could embed interactive widget here -->
          </div>
        </div>

      </section>

      <!-- Navigation -->
      <nav class="chapter-nav" aria-label="Chapter navigation">
        <a href="toc.html" class="nav-prev">← Table of Contents</a>
        <a href="chapter-02.html" class="nav-next">Chapter 2 →</a>
      </nav>

    </article>
  </main>

  <!-- Back to Top Button -->
  <button class="back-to-top" aria-label="Back to top">↑</button>

  <!-- Scripts -->
  <script src="js/navigation.js"></script>
  <script src="js/progress-tracker.js"></script>
  <script src="js/bookmarks.js"></script>
</body>
</html>
```

---

## CSS: Complete Responsive Stylesheet

```css
/* ==========================================
   RESPONSIVE BOOK WEBSITE STYLESHEET
   ========================================== */

/* RESET & BASE */
:root {
  /* Theme Colors */
  --theme-mathematics: #2563eb;
  --theme-science: #16a34a;
  --theme-language: #7c3aed;
  --theme-history: #92400e;

  /* Grayscale */
  --gray-50: #f9fafb;
  --gray-100: #f3f4f6;
  --gray-800: #1f2937;
  --gray-900: #111827;

  /* Typography */
  --font-sans: 'Source Sans Pro', -apple-system, sans-serif;
  --font-serif: Georgia, 'Times New Roman', serif;
  --font-mono: 'Courier New', monospace;

  /* Spacing */
  --space-1: 0.25rem;
  --space-2: 0.5rem;
  --space-4: 1rem;
  --space-8: 2rem;

  /* Current theme (set by data-subject) */
  --theme-color: var(--theme-mathematics);
}

body[data-subject="science"] {
  --theme-color: var(--theme-science);
}

/* TYPOGRAPHY */
body {
  font-family: var(--font-serif);
  font-size: 18px;
  line-height: 1.6;
  color: var(--gray-900);
  background: white;
  margin: 0;
  padding: 0;
}

@media (max-width: 640px) {
  body {
    font-size: 16px; /* Slightly smaller on mobile */
  }
}

h1, h2, h3, h4, h5, h6 {
  font-family: var(--font-sans);
  font-weight: 700;
  line-height: 1.2;
  color: var(--theme-color);
}

h1 {
  font-size: 2.5rem;
  margin-bottom: 1.5rem;
}

@media (max-width: 768px) {
  h1 {
    font-size: 2rem;
  }
}

/* LAYOUT */
.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 var(--space-4);
}

@media (max-width: 640px) {
  .container {
    padding: 0 var(--space-2);
  }
}

/* GRID SYSTEM */
.feature-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: var(--space-4);
  margin: var(--space-8) 0;
}

/* HEADER */
.site-header {
  background: white;
  border-bottom: 2px solid var(--theme-color);
  padding: var(--space-4) 0;
  position: sticky;
  top: 0;
  z-index: 100;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.main-nav ul {
  display: flex;
  list-style: none;
  gap: var(--space-4);
  margin: 0;
  padding: 0;
}

@media (max-width: 768px) {
  .main-nav ul {
    flex-direction: column;
    display: none; /* Toggle with JS */
  }

  .main-nav ul.active {
    display: flex;
  }

  #menu-toggle {
    display: block;
    font-size: 1.5rem;
    background: none;
    border: none;
    cursor: pointer;
  }
}

/* SIDEBAR */
.sidebar {
  position: fixed;
  left: 0;
  top: 80px;
  width: 280px;
  height: calc(100vh - 80px);
  overflow-y: auto;
  padding: var(--space-4);
  background: var(--gray-50);
  border-right: 1px solid var(--gray-100);
}

@media (max-width: 1024px) {
  .sidebar {
    transform: translateX(-100%);
    transition: transform 0.3s;
  }

  .sidebar.active {
    transform: translateX(0);
  }
}

.content {
  margin-left: 300px;
  padding: var(--space-8) var(--space-4);
  max-width: 800px;
}

@media (max-width: 1024px) {
  .content {
    margin-left: 0;
  }
}

/* BUTTONS */
.btn {
  display: inline-block;
  padding: 0.75rem 1.5rem;
  font-size: 1rem;
  font-weight: 600;
  text-decoration: none;
  border-radius: 0.5rem;
  transition: all 0.2s;
  cursor: pointer;
  border: none;
}

.btn-primary {
  background: var(--theme-color);
  color: white;
}

.btn-primary:hover {
  opacity: 0.9;
  transform: translateY(-2px);
  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}

/* CALLOUTS */
.callout {
  border-left: 4px solid var(--theme-color);
  background: var(--gray-50);
  padding: var(--space-4);
  margin: var(--space-4) 0;
  border-radius: 0 0.5rem 0.5rem 0;
}

.callout.tip {
  border-color: #16a34a;
  background: #f0fdf4;
}

.callout.warning {
  border-color: #dc2626;
  background: #fef2f2;
}

/* FIGURES */
figure {
  margin: var(--space-8) 0;
  text-align: center;
}

figure img {
  max-width: 100%;
  height: auto;
  border-radius: 0.5rem;
  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}

figcaption {
  font-size: 0.9rem;
  color: var(--gray-800);
  margin-top: var(--space-2);
  font-style: italic;
}

/* DARK MODE */
@media (prefers-color-scheme: dark) {
  body {
    background: var(--gray-900);
    color: var(--gray-50);
  }

  .site-header {
    background: var(--gray-800);
    border-bottom-color: var(--theme-color);
  }
}

/* PRINT STYLES (reference Format 31) */
@media print {
  .sidebar, .site-header, .chapter-nav {
    display: none;
  }

  .content {
    margin-left: 0;
    max-width: 100%;
  }
}
```

---

## JavaScript: Key Features

### navigation.js
```javascript
// Smooth scrolling
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    target.scrollIntoView({ behavior: 'smooth' });
  });
});

// Mobile menu toggle
const menuToggle = document.getElementById('menu-toggle');
const navMenu = document.querySelector('.nav-menu');

menuToggle?.addEventListener('click', () => {
  navMenu.classList.toggle('active');
});

// Back to top button
const backToTop = document.querySelector('.back-to-top');
window.addEventListener('scroll', () => {
  if (window.pageYOffset > 300) {
    backToTop.style.display = 'block';
  } else {
    backToTop.style.display = 'none';
  }
});
```

### progress-tracker.js
```javascript
// Track reading progress
function updateProgress() {
  const chapters = document.querySelectorAll('.chapter');
  const completed = localStorage.getItem('completed_chapters') || '[]';
  const completedArray = JSON.parse(completed);

  const progress = (completedArray.length / chapters.length) * 100;
  document.querySelector('.progress-fill').style.width = `${progress}%`;
}

// Mark chapter as complete when scrolled to bottom
window.addEventListener('scroll', () => {
  const scrolled = window.scrollY + window.innerHeight;
  const pageHeight = document.documentElement.scrollHeight;

  if (scrolled >= pageHeight - 100) {
    markChapterComplete();
  }
});
```

### search.js
```javascript
// Client-side search
function searchContent(query) {
  const results = [];
  const chapters = document.querySelectorAll('.chapter');

  chapters.forEach(chapter => {
    const text = chapter.textContent.toLowerCase();
    if (text.includes(query.toLowerCase())) {
      results.push({
        title: chapter.querySelector('h1').textContent,
        url: chapter.closest('html').baseURI
      });
    }
  });

  displayResults(results);
}
```

---

## Progressive Web App (PWA)

### manifest.json
```json
{
  "name": "Algebra I: Complete Course",
  "short_name": "Algebra I",
  "description": "Complete algebra course for high school students",
  "start_url": "/index.html",
  "display": "standalone",
  "background_color": "#ffffff",
  "theme_color": "#2563eb",
  "orientation": "portrait-primary",
  "icons": [
    {
      "src": "images/icon-192.png",
      "sizes": "192x192",
      "type": "image/png"
    },
    {
      "src": "images/icon-512.png",
      "sizes": "512x512",
      "type": "image/png"
    }
  ]
}
```

### service-worker.js (Offline Support)
```javascript
const CACHE_NAME = 'book-cache-v1';
const urlsToCache = [
  '/',
  '/index.html',
  '/css/layout.css',
  '/js/navigation.js',
  '/images/cover.jpg'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(urlsToCache))
  );
});

self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => response || fetch(event.request))
  );
});
```

---

## SEO Optimization

### Sitemap.xml
```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://example.com/index.html</loc>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>https://example.com/chapter-01.html</loc>
    <priority>0.8</priority>
  </url>
</urlset>
```

---

## Accessibility Features

- ✅ Semantic HTML5 elements
- ✅ ARIA labels and roles
- ✅ Keyboard navigation
- ✅ Focus indicators
- ✅ Alt text for images
- ✅ Color contrast (WCAG AA)
- ✅ Scalable text (user zoom)
- ✅ Skip to content links

---

## Related Formats
- **02_PDF_DIGITAL_150DPI.md**: Download alternative
- **03_EPUB_30.md**: E-reader version
- **31_PRINT_FRIENDLY_HTML.md**: Print optimization

---

## Update History
- **2025-12-18**: Initial blueprint created
- **Format Number**: 05 of 34 total formats - **ALL 34 COMPLETE!** 🎉
