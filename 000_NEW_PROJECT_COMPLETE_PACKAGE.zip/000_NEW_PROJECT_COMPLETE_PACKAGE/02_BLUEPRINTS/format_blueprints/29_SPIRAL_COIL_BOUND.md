# Format Blueprint: Spiral/Coil Bound Book

## Metadata
- **Format ID**: `29_SPIRAL_COIL_BOUND`
- **Format Name**: Spiral/Coil Bound Workbook
- **Tier**: 6 (Print Formats - Specialized)
- **File Extension**: `.pdf` (print-ready)
- **Priority**: High (educational workbooks)
- **Accessibility Level**: Excellent (lies flat, easy to use)

---

## Overview

### Purpose
Create a durable, lay-flat book format using spiral or coil binding. Perfect for workbooks, lab manuals, planners, and any material requiring frequent reference while writing or working.

### Use Cases
- **Student Workbooks**: Math practice, writing journals, science labs
- **Lab Manuals**: Medical, science, engineering procedures
- **Planners & Journals**: Daily use, note-taking
- **Training Manuals**: Step-by-step procedures, checklists
- **Recipe Books**: Cooking instructions that lie flat
- **Music Books**: Sheet music that stays open
- **Art & Craft Books**: Project-based learning
- **Assessment Books**: Tests, quizzes, practice exams

### Key Advantages
- ✅ **Lies Completely Flat**: 180° opening for easy reference
- ✅ **Durable**: Withstands daily classroom use
- ✅ **Easy Page Turning**: Smooth flipping without cracking spine
- ✅ **Folds Back**: Can fold 360° for single-page viewing
- ✅ **Note-Taking Friendly**: Write while book stays open
- ✅ **Professional**: Clean, modern appearance

---

## Technical Specifications

### Binding Types

#### 1. Coil/Spiral Binding (Plastic)
**Most Common for Educational Books**
- **Material**: PVC or polypropylene plastic coil
- **Sizes**: 6mm to 50mm diameter (by page count)
- **Colors**: Black, white, clear, or subject-themed colors
- **Durability**: Very high, won't rust
- **Cost**: Low to moderate ($0.50-$2.00 per book)

**Page Capacity by Coil Size:**
```
6mm  (1/4") = Up to 30 sheets (60 pages)
8mm  (5/16") = Up to 45 sheets (90 pages)
10mm (3/8") = Up to 55 sheets (110 pages)
12mm (1/2") = Up to 90 sheets (180 pages)
16mm (5/8") = Up to 125 sheets (250 pages)
20mm (3/4") = Up to 165 sheets (330 pages)
25mm (1") = Up to 210 sheets (420 pages)
```

#### 2. Wire-O/Double Loop Binding (Metal)
**Premium Option**
- **Material**: Steel or aluminum wire
- **Sizes**: 3:1 pitch (3 holes per inch) or 2:1 pitch
- **Colors**: Black, silver, bronze, gold
- **Durability**: Extremely high
- **Cost**: Moderate to high ($1.50-$4.00 per book)
- **Professional Appearance**: More formal than plastic

---

## Page Layout Design

### Critical Margins

#### Left/Binding Margin
- **Minimum**: 0.75" from edge to binding holes
- **Recommended**: 1.0" for content safety
- **Coil Clearance**: Content should not enter coil area
- **Hole Pattern**: Standard 43-hole or 19-hole punch

#### Other Margins
- **Right Margin**: 0.75" (standard)
- **Top Margin**: 0.75" to 1.0"
- **Bottom Margin**: 0.75" to 1.0"
- **Gutter**: None needed (spiral binding advantage)

### Page Specifications

**US Letter Size (Most Common)**
- **Trim Size**: 8.5" × 11"
- **Printable Area**: 7.0" × 9.5" (with safe margins)
- **Binding Edge**: Left side (portrait) or top (landscape)
- **Holes**: 19-hole or 43-hole pattern

**Half-Letter/Junior Size (Portable)**
- **Trim Size**: 5.5" × 8.5"
- **Use Case**: Pocket planners, small workbooks
- **Binding**: Top or left

**A4 Size (International)**
- **Trim Size**: 210mm × 297mm (8.27" × 11.69")
- **Hole Pattern**: 21-hole or 23-hole European standard

---

## Cover Design

### Cover Stock Options

#### Standard (Educational Use)
- **Material**: 80 lb (216 gsm) cardstock
- **Finish**: Matte or gloss lamination
- **Durability**: Good for 1-2 year use
- **Printing**: Full color, both sides

#### Heavy Duty (Lab Manuals)
- **Material**: 100 lb (270 gsm) cardstock
- **Finish**: Water-resistant lamination or polypropylene
- **Durability**: Excellent, 3-5 year use
- **Features**: Wipeable surface

#### Premium (Professional)
- **Material**: Clear vinyl overlay with printed insert
- **Backing**: Heavy chipboard (20pt)
- **Finish**: Crystal-clear protective cover
- **Durability**: Exceptional

### Cover Layout

**Front Cover Design:**
```
┌─────────────────────────────────┐
│  [Binding Coil Area - 0.5"]     │
│                                  │
│    SUBJECT THEME COLOR           │
│    ═══════════════               │
│                                  │
│    BOOK TITLE                    │
│    Grade Level                   │
│                                  │
│    [Relevant Graphics 40%]       │
│                                  │
│    Author/Publisher              │
└─────────────────────────────────┘
```

**Back Cover Design:**
```
┌─────────────────────────────────┐
│  [Binding Coil Area - 0.5"]     │
│                                  │
│  • Book Description              │
│  • Key Features                  │
│  • ISBN Barcode                  │
│  • Price                         │
│                                  │
│  Subject Color Band (bottom)     │
└─────────────────────────────────┘
```

---

## Grade Level Design Variations

### Elementary School (Grades 3-5)

**Cover Design:**
- **Colors**: Bright, saturated primary colors
- **Graphics**: 50-60% coverage, cartoon-style
- **Fonts**: Large, friendly (18-24pt titles)
- **Features**: Character mascots, fun borders
- **Durability**: Heavy lamination, rounded corners

**Interior Design:**
- **Spacing**: Extra wide (1.5-2× normal)
- **Fonts**: 14-16pt body text
- **Graphics**: Large, colorful, every 2-3 pages
- **Practice Areas**: Extra large writing spaces
- **Visual Aids**: Icons, emoji, step numbers

**Paper:**
- **Weight**: 28-32 lb (heavier for durability)
- **Type**: Bright white or cream
- **Ruling**: Wide-ruled (11/32" spacing)

---

### Middle School (Grades 6-8)

**Cover Design:**
- **Colors**: Bold but sophisticated palette
- **Graphics**: 30-40% coverage, modern vector art
- **Fonts**: Clean sans-serif (16-20pt titles)
- **Features**: Cool, aspirational designs
- **Durability**: Standard matte lamination

**Interior Design:**
- **Spacing**: Standard to slightly generous
- **Fonts**: 11-12pt body text
- **Graphics**: Every 3-5 pages, photo-realistic
- **Practice Areas**: Standard college-ruled lines
- **Visual Aids**: Charts, diagrams, callout boxes

**Paper:**
- **Weight**: 24 lb (standard)
- **Type**: Bright white
- **Ruling**: College-ruled (9/32" spacing)

---

### High School (Grades 9-12)

**Cover Design:**
- **Colors**: Professional, subject-appropriate
- **Graphics**: 20-30% coverage, sophisticated
- **Fonts**: Academic fonts (14-18pt titles)
- **Features**: Minimalist, modern aesthetic
- **Durability**: Matte with spot UV on title

**Interior Design:**
- **Spacing**: Standard academic
- **Fonts**: 10-11pt body text
- **Graphics**: Every 5-7 pages, professional
- **Practice Areas**: Standard lined or graph paper
- **Visual Aids**: Advanced charts, data visualization

**Paper:**
- **Weight**: 20-24 lb
- **Type**: White or cream
- **Ruling**: College-ruled or blank

---

### College/University & Professional

**Cover Design:**
- **Colors**: Subdued, professional palette
- **Graphics**: 10-20% coverage, minimal
- **Fonts**: Professional serif/sans (14-16pt)
- **Features**: Clean, authoritative design
- **Durability**: Premium lamination or clear vinyl

**Interior Design:**
- **Spacing**: Compact, efficient
- **Fonts**: 9-10pt body text
- **Graphics**: As needed for content
- **Practice Areas**: Graph paper, blank, or lined
- **Visual Aids**: Technical diagrams, formulas

**Paper:**
- **Weight**: 20 lb (standard)
- **Type**: White or cream
- **Ruling**: Based on subject (graph, blank, lined)

---

## Subject-Specific Adaptations

### Mathematics Workbooks
- **Theme Color**: Blue (#2563eb)
- **Paper**: Graph paper or dot grid
- **Special Features**:
  - Pre-printed coordinate planes
  - Formula reference sheets
  - Practice problem templates
  - Answer spaces with guidelines

### Science Lab Manuals
- **Theme Color**: Green (#16a34a)
- **Paper**: Waterproof or coated option
- **Special Features**:
  - Data table templates
  - Observation recording pages
  - Safety checklist pages
  - Equipment diagrams

### Language Arts Journals
- **Theme Color**: Purple (#7c3aed)
- **Paper**: Wide-ruled or college-ruled
- **Special Features**:
  - Writing prompts on each page
  - Vocabulary boxes
  - Peer review checklists
  - Rubric pages

### Art & Design Books
- **Theme Color**: Orange (#ea580c)
- **Paper**: Heavy weight (32-60 lb), textured
- **Special Features**:
  - Blank pages for sketching
  - Project planning templates
  - Color mixing charts
  - Technique reference pages

---

## Production Specifications

### Print-Ready File Structure

```
spiral_bound_book/
├── PRINTING_SPECIFICATIONS.pdf
├── cover_exterior_front.pdf (8.5×11, cardstock)
├── cover_exterior_back.pdf (8.5×11, cardstock)
├── interior_pages.pdf (8.5×11, 20-32 lb paper)
├── binding_specifications.txt
├── coil_size_calculator.xlsx
└── assembly_instructions.pdf
```

### Binding Specifications Document

```
SPIRAL/COIL BINDING SPECIFICATIONS
==================================

Book Title: [Title]
Grade Level: [Elementary/Middle/High School/College]
Subject: [Mathematics/Science/etc.]
Total Pages: 150 pages (75 sheets)

BINDING:
- Type: Plastic Coil Binding
- Size: 12mm (1/2") diameter
- Color: Blue (match subject theme)
- Pitch: 4:1 (4 holes per inch)
- Holes: 43 holes for 11" edge

COVER:
- Stock: 80 lb gloss cardstock
- Finish: Gloss lamination (3 mil)
- Size: 8.5" × 11"
- Print: Full color, both sides
- Corners: Square (or rounded for elementary)

INTERIOR:
- Stock: 24 lb white paper
- Ruling: College-ruled lines
- Print: Black ink, single-sided or double-sided
- Perforation: None (or tearout sheets if specified)

ASSEMBLY:
1. Print and collate all interior pages
2. Punch 43 holes along left edge (0.375" from edge)
3. Print cover pages on cardstock
4. Laminate cover pages
5. Punch cover pages with same pattern
6. Insert coil through all pages
7. Crimp coil ends

QUANTITY: [Number]
DEADLINE: [Date]
```

### Hole Punch Patterns

**19-Hole Pattern (Letter Size)**
- **Hole Diameter**: 0.25" (6.35mm)
- **Hole Spacing**: 0.5" (12.7mm) apart
- **Edge Distance**: 0.375" (9.5mm) from edge
- **Total Length**: 10.5" (covers 11" edge with margins)

**43-Hole Pattern (Letter Size)**
- **Hole Diameter**: 0.1875" (4.76mm)
- **Hole Spacing**: 0.25" (6.35mm) apart
- **Edge Distance**: 0.375" (9.5mm) from edge
- **Total Length**: 10.5"
- **Use Case**: Stronger binding, more professional

---

## Special Features

### Tearout/Perforated Pages
- **Perforation**: Micro-perforated line at binding edge
- **Use Case**: Homework submission, project pages
- **Location**: Specific pages (e.g., every 10th page)
- **Reinforcement**: Extra holes or reinforcement strips

### Tabbed Dividers
- **Material**: Heavy cardstock (80-100 lb)
- **Tabs**: 5-8 position tabs
- **Labels**: Subject sections, chapters, units
- **Integration**: Punched and bound with coil

### Pocket Pages
- **Material**: Heavy clear plastic or paper
- **Location**: Inside front/back cover
- **Use**: Store loose materials, answer keys, cards

### Wraparound Cover
- **Design**: Cover wraps from front to back
- **Advantage**: Full bleed design, no visible binding
- **Material**: Heavier cardstock (100 lb+)

---

## Quality Control Checklist

### Design Requirements
- [ ] Left margin minimum 1.0" (content safety)
- [ ] Coil area (0.5") contains no critical content
- [ ] Cover design accounts for coil visibility
- [ ] Page numbers visible and not in coil area
- [ ] Headers/footers clear of binding edge

### Print Requirements
- [ ] Cover on 80+ lb cardstock
- [ ] Interior on specified paper weight
- [ ] Lamination applied if specified
- [ ] Colors match theme specifications
- [ ] Registration accurate (±1mm)

### Binding Requirements
- [ ] Correct coil size for page count
- [ ] 43-hole or 19-hole punch as specified
- [ ] Holes 0.375" from edge consistently
- [ ] Coil color matches or complements cover
- [ ] Coil ends properly crimped (not sharp)

### Durability Testing
- [ ] Opens 180° without resistance
- [ ] Folds back 360° without damage
- [ ] Pages turn smoothly
- [ ] Cover withstands flexing
- [ ] Binding secure under normal use

### User Experience
- [ ] Lies completely flat when open
- [ ] Easy single-handed page turning
- [ ] Coil doesn't catch on items
- [ ] Comfortable to hold
- [ ] Professional appearance

---

## Coil Size Calculator

**Formula:**
```
Required Coil Diameter (inches) = (Total Sheets × Paper Thickness) + 0.25"

Example:
75 sheets × 0.004" (24 lb paper) = 0.30"
0.30" + 0.25" = 0.55"
Round up to next standard size = 0.625" (16mm)
```

**Standard Sizes:**
| Coil Size | Sheets (24 lb) | Pages | Use Case |
|-----------|----------------|-------|----------|
| 6mm (1/4") | Up to 30 | 60 | Thin workbooks |
| 8mm (5/16") | Up to 45 | 90 | Small workbooks |
| 10mm (3/8") | Up to 55 | 110 | Standard workbooks |
| 12mm (1/2") | Up to 90 | 180 | Full workbooks |
| 16mm (5/8") | Up to 125 | 250 | Thick workbooks |
| 20mm (3/4") | Up to 165 | 330 | Lab manuals |
| 25mm (1") | Up to 210 | 420 | Comprehensive guides |

---

## AI Model Recommendations

### Cover Design
- **Visual Design**: DALL-E 3 or Midjourney (grade-appropriate graphics)
- **Layout Optimization**: Claude Opus (spacing, margins)
- **Color Selection**: GPT-4o (theme consistency)

### Interior Layout
- **Page Template**: Gemini Pro (grid layouts, practice areas)
- **Content Formatting**: Claude Sonnet (readability, spacing)
- **Ruling/Graphing**: Specialized tools (graph paper generators)

### Quality Verification
- **Margin Check**: GPT-4 Vision (verify safe zones)
- **Binding Compatibility**: Claude Opus (hole placement validation)

---

## Related Formats

- **19_BINDER_BOOK.md**: 3-ring binder alternative
- **01_PDF_PRINT_300DPI.md**: Standard bound book
- **32_HARDCOVER_CASE_BOUND.md**: Permanent binding alternative

---

## Advantages Over Other Bindings

**vs. Perfect Bound:**
- ✅ Lies completely flat
- ✅ More durable for daily use
- ✅ Easy to add/remove pages (with wire-o)
- ❌ Slightly higher cost

**vs. Saddle Stitch:**
- ✅ Accommodates more pages
- ✅ More professional appearance
- ✅ Individual page access
- ❌ Requires specialized equipment

**vs. 3-Ring Binder:**
- ✅ More portable (no bulky binder)
- ✅ Pages stay bound together
- ✅ Lower cost
- ❌ Cannot easily add/remove pages

---

## Metadata Example

```json
{
  "format": "Spiral/Coil Bound Book",
  "format_id": "29_SPIRAL_COIL_BOUND",
  "binding_type": "plastic_coil",
  "page_size": "8.5×11 inches",
  "page_count": 150,
  "sheets": 75,
  "coil_specifications": {
    "type": "plastic",
    "size_mm": 12,
    "size_inches": 0.5,
    "color": "blue",
    "hole_pattern": "43-hole",
    "pitch": "4:1"
  },
  "cover": {
    "stock": "80 lb cardstock",
    "finish": "gloss_lamination",
    "colors": "full_color_both_sides"
  },
  "interior": {
    "stock": "24 lb white paper",
    "ruling": "college_ruled",
    "print": "black_single_sided"
  },
  "grade_level": "high_school",
  "subject": "mathematics",
  "theme_color": "#2563eb",
  "features": {
    "lies_flat": true,
    "durable": true,
    "tearout_pages": false,
    "tabbed_dividers": false
  }
}
```

---

## Update History
- **2025-12-18**: Initial blueprint created
- **Format Number**: 29 of 34 total formats
