# Format Blueprint: Print-Friendly HTML with CSS Print Styles

## Metadata
- **Format ID**: `31_PRINT_FRIENDLY_HTML`
- **Format Name**: Print-Friendly HTML (Web-to-Print)
- **Tier**: 2 (High Priority - Modern Solution)
- **File Extension**: `.html`
- **Priority**: High (browser-based printing)
- **Accessibility Level**: Excellent (accessible + printable)

---

## Overview

### Purpose
Create web-based books that print beautifully directly from the browser, with intelligent CSS print styles that preserve themes, optimize ink usage, and provide user controls for print customization.

### Key Innovation
Combines the accessibility and interactivity of web content with professional print output. Users can read on screen, then print exactly what they need with theme preservation or economy modes.

### Use Cases
- **On-Demand Chapter Printing**: Students print only chapters they need
- **Browser-Based Reading**: Read online, print when needed
- **Institutional Deployment**: Schools host books on LMS, users print as needed
- **Remote Learning**: Teachers share links, students print assignments
- **Accessibility First**: Screen readers work perfectly, printing available
- **No Special Software**: Works in any modern browser

---

## The Power of CSS Print Styles

### What Happens When User Clicks "Print"

Browser automatically applies print-specific CSS:
```css
@media print {
  /* These styles ONLY apply when printing */
  /* Screen styles are ignored */
}
```

**User Experience:**
1. User reads book in browser (full interactive experience)
2. User clicks browser Print button (Ctrl+P / Cmd+P)
3. Print preview shows optimized layout
4. User selects options (color/grayscale, pages, chapters)
5. Prints or saves as PDF directly from browser

**No plugins, no downloads, no special software needed.**

---

## Three Print Modes (User-Selectable)

### Mode 1: Full Color (Theme Preserved)
**Activated By**: User has color printer, checks "Background graphics" in print dialog

**CSS Implementation:**
```css
@media print {
  /* Preserve theme colors in headers */
  h1, h2 {
    color: var(--theme-color);
    border-bottom: 3px solid var(--theme-color);
  }

  /* Light backgrounds become borders */
  .callout {
    background: none;
    border-left: 4px solid var(--theme-color);
  }

  /* Charts in full color */
  .chart, .diagram {
    color-adjust: exact; /* Force color printing */
    print-color-adjust: exact;
  }
}
```

---

### Mode 2: Grayscale (Auto-Detected)
**Activated By**: Browser detects B&W printer or user unchecks "Background graphics"

**CSS Implementation:**
```css
@media print {
  /* Convert to grayscale */
  * {
    filter: grayscale(100%);
  }

  /* Use patterns instead of colors */
  .math-section { border-left: 4px dotted gray; }
  .science-section { border-left: 4px dashed gray; }
  .language-section { border-left: 4px double gray; }
}
```

---

### Mode 3: High Contrast (Economy)
**Activated By**: User selects "Print backgrounds: off"

**CSS Implementation:**
```css
@media print {
  /* Pure black and white */
  * {
    color: black !important;
    background: white !important;
  }

  /* Borders only */
  .callout {
    border: 2px solid black;
  }

  /* Strong hierarchy */
  h1 { font-size: 24pt; font-weight: bold; }
  h2 { font-size: 18pt; font-weight: bold; }
}
```

---

## Complete CSS Print Stylesheet

```css
/* ============================================
   PRINT STYLES - AUTO-APPLIED WHEN PRINTING
   ============================================ */

@media print {

  /* ─────────────────────────
     PAGE SETUP
     ───────────────────────── */

  @page {
    size: letter portrait;
    margin: 1in 0.75in 0.75in 1in; /* Top Right Bottom Left */
  }

  @page :left {
    margin-left: 0.75in;
    margin-right: 1in;
  }

  @page :right {
    margin-left: 1in;
    margin-right: 0.75in;
  }

  @page :first {
    margin-top: 0.5in; /* Less margin on first page */
  }

  /* ─────────────────────────
     HIDE SCREEN-ONLY ELEMENTS
     ───────────────────────── */

  nav, .navigation,
  .interactive-widget,
  .video-player,
  .audio-player,
  .social-share,
  .comments,
  .sidebar,
  button,
  .no-print {
    display: none !important;
  }

  /* ─────────────────────────
     SHOW PRINT-ONLY ELEMENTS
     ───────────────────────── */

  .print-only {
    display: block !important;
  }

  /* ─────────────────────────
     PAGE BREAKS
     ───────────────────────── */

  /* Force breaks */
  h1, .chapter-start {
    page-break-before: always;
    break-before: page;
  }

  /* Avoid breaks */
  h1, h2, h3, h4, h5, h6 {
    page-break-after: avoid;
    break-after: avoid;
  }

  table, figure, img, .code-block {
    page-break-inside: avoid;
    break-inside: avoid;
  }

  /* Orphan/Widow control */
  p, li {
    orphans: 2;
    widows: 2;
  }

  /* ─────────────────────────
     TYPOGRAPHY
     ───────────────────────── */

  body {
    font-family: 'Times New Roman', Georgia, serif;
    font-size: 11pt;
    line-height: 1.5;
    color: black;
  }

  h1 {
    font-size: 24pt;
    font-weight: bold;
    color: var(--theme-color, #2563eb);
    border-bottom: 3px solid var(--theme-color, #2563eb);
    padding-bottom: 6pt;
    margin-top: 0;
    margin-bottom: 12pt;
  }

  h2 {
    font-size: 18pt;
    font-weight: bold;
    color: var(--theme-color, #2563eb);
    margin-top: 18pt;
    margin-bottom: 9pt;
  }

  h3 {
    font-size: 14pt;
    font-weight: bold;
    margin-top: 12pt;
    margin-bottom: 6pt;
  }

  p {
    margin: 0 0 9pt 0;
    text-align: justify;
  }

  /* ─────────────────────────
     LINKS
     ───────────────────────── */

  a {
    color: black;
    text-decoration: none;
  }

  /* Show URL after link text */
  a[href^="http"]:after {
    content: " (" attr(href) ")";
    font-size: 9pt;
    color: #666;
  }

  /* Don't show URLs for internal links */
  a[href^="#"]:after {
    content: "";
  }

  /* ─────────────────────────
     CALLOUTS & BOXES
     ───────────────────────── */

  .callout, .note, .tip, .warning {
    background: none !important;
    border-left: 4px solid var(--theme-color, #2563eb);
    padding-left: 12pt;
    margin: 12pt 0;
    page-break-inside: avoid;
  }

  .warning {
    border-left-color: #dc2626;
  }

  .tip {
    border-left-color: #16a34a;
  }

  /* ─────────────────────────
     LISTS
     ───────────────────────── */

  ul, ol {
    margin: 0 0 9pt 18pt;
    padding: 0;
  }

  li {
    margin: 0 0 6pt 0;
  }

  /* ─────────────────────────
     TABLES
     ───────────────────────── */

  table {
    width: 100%;
    border-collapse: collapse;
    margin: 12pt 0;
    page-break-inside: avoid;
  }

  th {
    background: #f0f0f0 !important;
    font-weight: bold;
    padding: 6pt;
    border: 1pt solid #ccc;
    text-align: left;
  }

  td {
    padding: 6pt;
    border: 1pt solid #ccc;
  }

  /* ─────────────────────────
     CODE BLOCKS
     ───────────────────────── */

  pre, code {
    font-family: 'Courier New', monospace;
    font-size: 9pt;
  }

  pre {
    background: #f5f5f5 !important;
    border: 1pt solid #ddd;
    padding: 9pt;
    overflow: hidden;
    page-break-inside: avoid;
  }

  /* ─────────────────────────
     IMAGES & FIGURES
     ───────────────────────── */

  img {
    max-width: 100%;
    page-break-inside: avoid;
  }

  figure {
    margin: 12pt 0;
    page-break-inside: avoid;
  }

  figcaption {
    font-size: 9pt;
    font-style: italic;
    text-align: center;
    margin-top: 6pt;
  }

  /* ─────────────────────────
     CHARTS & DIAGRAMS
     ───────────────────────── */

  .chart, .diagram {
    page-break-inside: avoid;
    print-color-adjust: exact;
    color-adjust: exact;
  }

  /* ─────────────────────────
     HEADERS & FOOTERS
     ───────────────────────── */

  header, footer {
    display: none; /* Hide screen header/footer */
  }

  /* Print headers/footers */
  @page {
    @top-right {
      content: "Page " counter(page);
    }

    @top-left {
      content: attr(data-chapter);
    }
  }

  /* ─────────────────────────
     SUBJECT THEME COLORS
     ───────────────────────── */

  body[data-subject="mathematics"] {
    --theme-color: #2563eb;
  }

  body[data-subject="science"] {
    --theme-color: #16a34a;
  }

  body[data-subject="language-arts"] {
    --theme-color: #7c3aed;
  }

  body[data-subject="history"] {
    --theme-color: #92400e;
  }

  body[data-subject="foreign-languages"] {
    --theme-color: #dc2626;
  }

  /* ─────────────────────────
     GRAYSCALE MODE (Auto)
     ───────────────────────── */

  @media print and (monochrome) {
    * {
      filter: grayscale(100%);
    }
  }

  /* ─────────────────────────
     ECONOMY MODE (User Choice)
     ───────────────────────── */

  @media print {
    .economy-mode {
      * {
        background: none !important;
        color: black !important;
      }
    }
  }

} /* END @media print */
```

---

## Interactive Print Controls

### User Control Panel (Screen Only)

```html
<div class="print-controls no-print">
  <h3>Print Options</h3>

  <label>
    <input type="radio" name="print-mode" value="full-color" checked>
    Full Color (Theme Preserved)
  </label>

  <label>
    <input type="radio" name="print-mode" value="grayscale">
    Grayscale (Printer-Friendly)
  </label>

  <label>
    <input type="radio" name="print-mode" value="economy">
    Black & White (Economy)
  </label>

  <hr>

  <h4>Print Sections:</h4>
  <label><input type="checkbox" class="print-chapter" data-chapter="1" checked> Chapter 1</label>
  <label><input type="checkbox" class="print-chapter" data-chapter="2" checked> Chapter 2</label>
  <label><input type="checkbox" class="print-chapter" data-chapter="3" checked> Chapter 3</label>

  <button onclick="window.print()">Print Selected Chapters</button>
  <button onclick="printToPDF()">Save as PDF</button>
</div>

<script>
// Apply user's print mode choice
document.querySelectorAll('[name="print-mode"]').forEach(radio => {
  radio.addEventListener('change', function() {
    document.body.className = this.value;
  });
});

// Hide/show chapters based on selection
function window.onbeforeprint() {
  document.querySelectorAll('.print-chapter').forEach(checkbox => {
    const chapter = document.querySelector(`#chapter-${checkbox.dataset.chapter}`);
    if (!checkbox.checked) {
      chapter.classList.add('no-print');
    }
  });
}

function printToPDF() {
  // Opens print dialog with PDF printer pre-selected (browser feature)
  window.print();
}
</script>
```

---

## HTML Document Structure

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Book Title - Print-Friendly Edition</title>

  <!-- Screen Styles -->
  <link rel="stylesheet" href="screen-styles.css">

  <!-- Print Styles (automatically applied when printing) -->
  <link rel="stylesheet" href="print-styles.css" media="print">

  <!-- Subject Theme -->
  <style>
    :root {
      --theme-color: #2563eb; /* Mathematics blue */
    }
  </style>
</head>

<body data-subject="mathematics" data-grade="high-school">

  <!-- Print Controls (Hidden when printing) -->
  <div class="print-controls no-print">
    <!-- User controls here -->
  </div>

  <!-- Navigation (Hidden when printing) -->
  <nav class="no-print">
    <a href="#chapter-1">Chapter 1</a>
    <a href="#chapter-2">Chapter 2</a>
  </nav>

  <!-- Book Content -->
  <main>
    <h1 class="book-title">Algebra I: Complete Course</h1>

    <section id="chapter-1" class="chapter">
      <h1>Chapter 1: Introduction to Algebra</h1>

      <p>Content here...</p>

      <div class="callout tip">
        <strong>Tip:</strong> Remember to check your work!
      </div>

      <figure>
        <img src="diagram-1.png" alt="Coordinate plane">
        <figcaption>Figure 1.1: The Coordinate Plane</figcaption>
      </figure>
    </section>

    <section id="chapter-2" class="chapter">
      <h1>Chapter 2: Linear Equations</h1>
      <p>Content here...</p>
    </section>
  </main>

  <!-- Footer (Hidden when printing) -->
  <footer class="no-print">
    <p>&copy; 2025 Educational Books</p>
  </footer>

</body>
</html>
```

---

## Advanced Features

### 1. Chapter-Only Printing

```javascript
function printChapter(chapterNumber) {
  // Hide all chapters except selected
  document.querySelectorAll('.chapter').forEach(chapter => {
    if (chapter.id !== `chapter-${chapterNumber}`) {
      chapter.classList.add('no-print');
    }
  });

  window.print();

  // Restore visibility after printing
  setTimeout(() => {
    document.querySelectorAll('.chapter').forEach(chapter => {
      chapter.classList.remove('no-print');
    });
  }, 100);
}
```

### 2. Page Range Selection

```html
<label>Print Pages:
  <input type="number" id="page-start" min="1" value="1"> to
  <input type="number" id="page-end" min="1" value="50">
</label>
<button onclick="printRange()">Print Range</button>
```

### 3. Custom Binding Margin

```html
<label>Binding Margin:
  <select id="binding-margin">
    <option value="0.5in">0.5 inch</option>
    <option value="1in" selected>1.0 inch</option>
    <option value="1.5in">1.5 inch</option>
  </select>
</label>

<script>
document.getElementById('binding-margin').addEventListener('change', function() {
  document.documentElement.style.setProperty('--binding-margin', this.value);
});
</script>

<style>
@media print {
  @page {
    margin-left: var(--binding-margin, 1in);
  }
}
</style>
```

### 4. Generate PDF Directly

```javascript
// Uses browser's built-in "Print to PDF" feature
function saveToPDF() {
  // Most browsers allow selecting "Save as PDF" as printer
  window.print();

  // Alternatively, use print-to-PDF libraries:
  // - jsPDF
  // - html2pdf.js
  // - pdfmake
}
```

---

## Browser Compatibility

### Supported Browsers
✅ Chrome/Edge (Chromium) - Excellent support
✅ Firefox - Excellent support
✅ Safari - Good support
✅ Opera - Excellent support

### Required Features
- CSS `@media print` (all modern browsers)
- CSS `@page` rules (all modern browsers)
- `page-break-*` properties (all modern browsers)
- CSS custom properties/variables (all modern browsers)

### Fallbacks
For older browsers:
```css
/* Fallback for browsers without custom properties */
@media print {
  body:not([data-subject]) h1 {
    color: #2563eb; /* Default blue */
  }
}
```

---

## Advantages Over PDF

| Feature | Print-Friendly HTML | Static PDF |
|---------|---------------------|------------|
| **Accessibility** | ✅ Perfect (native HTML) | ⚠️ Depends on tagging |
| **Search** | ✅ Native browser search | ⚠️ Depends on PDF viewer |
| **Responsive** | ✅ Adapts to screen size | ❌ Fixed layout |
| **Interactive** | ✅ Forms, videos, links | ⚠️ Limited |
| **File Size** | ✅ Very small (<1MB) | ❌ Large (20-60MB) |
| **Load Time** | ✅ Instant | ❌ Slow download |
| **Updates** | ✅ Live updates | ❌ Re-download needed |
| **Print Quality** | ✅ Excellent | ✅ Excellent |
| **Offline Use** | ✅ Can save locally | ✅ Yes |
| **Browser Support** | ✅ Universal | ⚠️ Needs PDF viewer |

---

## Deployment Options

### Option 1: Single HTML File (Portable)
```
book.html (includes all CSS inline)
```
**Pros**: Single file, easy to share
**Cons**: Larger file size

### Option 2: HTML + CSS Files
```
index.html
├── screen-styles.css
├── print-styles.css
└── assets/
    └── images/
```
**Pros**: Clean separation, cacheable
**Cons**: Multiple files to manage

### Option 3: Progressive Web App (PWA)
```
├── index.html
├── manifest.json
├── service-worker.js
└── assets/
```
**Pros**: Offline access, installable, fast
**Cons**: Requires web server

### Option 4: LMS Integration
Upload HTML package to:
- Canvas LMS
- Moodle
- Blackboard
- Google Classroom

Students access via browser, print as needed.

---

## SEO & Metadata

```html
<head>
  <title>Algebra I - Print-Friendly Edition</title>
  <meta name="description" content="Complete Algebra I course with print-friendly formatting">
  <meta name="keywords" content="algebra, mathematics, high school, print-friendly">
  <meta name="author" content="Educational Books System">
  <meta name="subject" content="Mathematics">
  <meta name="grade-level" content="High School">

  <!-- Open Graph for sharing -->
  <meta property="og:title" content="Algebra I - Print-Friendly Edition">
  <meta property="og:type" content="book">
  <meta property="og:image" content="cover-image.jpg">

  <!-- Print-specific -->
  <meta name="print-friendly" content="true">
  <meta name="print-modes" content="color,grayscale,black-white">
</head>
```

---

## AI Model Recommendations

### HTML Generation
- **Claude Opus**: Semantic HTML structure
- **GPT-4o**: Accessibility compliance (ARIA labels)

### CSS Print Styles
- **Claude Sonnet**: Complex CSS rules, page breaks
- **Gemini Pro**: Theme color systems, responsive design

### JavaScript Interactivity
- **GPT-4o**: Print controls, chapter selection
- **Claude Sonnet**: Advanced features (PDF generation)

### Quality Assurance
- **GPT-4 Vision**: Verify print preview appearance
- **Claude Opus**: Validate CSS compatibility

---

## Quality Checklist

### Functionality
- [ ] Prints correctly in Chrome, Firefox, Safari
- [ ] User can select print mode (color/grayscale/B&W)
- [ ] Chapter selection works
- [ ] Page breaks intelligent (no orphans/widows)
- [ ] URLs shown for external links

### Visual Quality
- [ ] Theme colors preserved in full color mode
- [ ] Grayscale conversion readable
- [ ] Tables print on single page (no splits)
- [ ] Images sized appropriately
- [ ] Headers/footers formatted correctly

### Accessibility
- [ ] Screen reader compatible
- [ ] Keyboard navigation works
- [ ] ARIA labels present
- [ ] Contrast ratios meet WCAG 2.1 AA
- [ ] Semantic HTML used

### Print Optimization
- [ ] No screen-only elements print
- [ ] Margins correct for binding
- [ ] Ink usage minimized
- [ ] File size reasonable (<5MB)
- [ ] Loads quickly (<2 seconds)

---

## Metadata Example

```json
{
  "format": "Print-Friendly HTML",
  "format_id": "31_PRINT_FRIENDLY_HTML",
  "file_type": "text/html",
  "modes": ["full_color", "grayscale", "black_white"],
  "features": {
    "responsive": true,
    "print_optimized": true,
    "theme_preservation": true,
    "chapter_selection": true,
    "browser_pdf_export": true,
    "offline_capable": true
  },
  "browser_support": {
    "chrome": "full",
    "firefox": "full",
    "safari": "full",
    "edge": "full"
  },
  "accessibility": {
    "wcag_level": "AA",
    "screen_reader": "full_support",
    "keyboard_nav": true
  },
  "subject": "mathematics",
  "theme_color": "#2563eb",
  "grade_level": "high_school",
  "file_size": "850 KB"
}
```

---

## Related Formats

- **30_PRINT_FRIENDLY_PDF_THEMES.md**: PDF alternative
- **05_HTML_RESPONSIVE.md**: Screen reading (not optimized for print)

---

## Update History
- **2025-12-18**: Initial blueprint created
- **Format Number**: 31 of 34 total formats
