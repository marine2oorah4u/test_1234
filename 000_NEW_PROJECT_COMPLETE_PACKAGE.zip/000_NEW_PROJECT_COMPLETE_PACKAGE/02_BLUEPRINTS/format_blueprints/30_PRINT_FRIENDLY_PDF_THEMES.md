# Format Blueprint: Print-Friendly PDF with Theme Preservation

## Metadata
- **Format ID**: `30_PRINT_FRIENDLY_PDF_THEMES`
- **Format Name**: Print-Friendly PDF (Theme Colors Preserved)
- **Tier**: 2 (High Priority - User Request)
- **File Extension**: `.pdf`
- **Priority**: High (home/office printing)
- **Accessibility Level**: High (user-customizable)

---

## Overview

### Purpose
Create printer-optimized PDF files that allow users to print books at home or office while preserving subject theme colors, or converting to grayscale/black-white modes for economy printing.

### Key Innovation
Unlike standard PDFs that either waste ink (full backgrounds) or lose all design (plain text), this format intelligently preserves thematic elements while optimizing for physical printing.

### Use Cases
- **Home Printing**: Parents printing for their children
- **Office/Work**: Professionals printing reference materials
- **Schools**: Teachers printing classroom sets on copiers
- **Study Materials**: Students printing chapters for exam prep
- **Cost-Conscious Users**: Need materials but budget-aware

---

## The Problem This Solves

### Traditional Print PDFs Issues:
❌ **Full Color PDFs**: Waste massive amounts of ink
- Background colors print solid
- Light backgrounds still use ink
- Decorative elements consume expensive color ink
- 200-page book = $40-60 in ink costs

❌ **Plain Text Export**: Loses all design
- No theme identification (Math vs Science unclear)
- No visual hierarchy
- Charts/diagrams broken or missing
- Headers/callouts removed
- Poor readability

### Our Solution:
✅ **Smart Theme Preservation**: Keep what matters, optimize what doesn't
- Subject colors in headers (minimal ink)
- Backgrounds converted to borders (outline only)
- Charts/diagrams preserved efficiently
- Visual hierarchy maintained
- 200-page book = $8-15 in ink costs

---

## Three Print Modes

### Mode 1: Full Color (Theme Preserved)
**Best For**: Important materials, final copies, color printer owners

**Optimizations:**
- ✅ Subject theme colors in titles/headers (Math=Blue, Science=Green)
- ✅ Charts and diagrams in full color
- ✅ Important callout boxes with theme colors
- ✅ Photos and illustrations preserved
- ❌ Decorative backgrounds removed or lightened to 10%
- ❌ Full-page backgrounds converted to page borders
- ❌ Gradient effects flattened to solid colors

**Ink Usage**: Moderate (60% less than original)

**Example Transformation:**
```
BEFORE (Original):
┌────────────────────────────────┐
│░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ ← Solid blue background
│  CHAPTER 3: ALGEBRA            │
│  ────────────────              │
│░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│
│                                 │
│  Content text here...           │
│                                 │
└────────────────────────────────┘

AFTER (Print-Friendly Full Color):
┌────────────────────────────────┐
│  ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ │ ← Thin blue bar (not solid)
│  CHAPTER 3: ALGEBRA (in blue)  │
│  ────────────────              │
│                                 │
│  Content text here...           │
│                                 │
└────────────────────────────────┘
```

---

### Mode 2: Grayscale (Printer-Friendly)
**Best For**: Black & white printers, economy printing, study copies

**Optimizations:**
- ✅ Theme colors converted to gray equivalents
  - Math Blue → Dark Gray (#404040)
  - Science Green → Medium Gray (#606060)
  - Language Purple → Medium-Dark Gray (#505050)
- ✅ Charts converted to patterns/hatching
- ✅ Photos converted to high-contrast grayscale
- ✅ Headers use bold text instead of color
- ✅ Callout boxes use border weight variations
- ❌ All backgrounds removed
- ❌ Decorative elements simplified

**Ink Usage**: Low (85% less than original)

**Accessibility**: Still maintains visual hierarchy through contrast

---

### Mode 3: Black & White (Economy)
**Best For**: Mass printing, draft copies, plain copiers

**Optimizations:**
- ✅ Pure black text on white background
- ✅ Headers in bold, larger sizes
- ✅ Essential diagrams in black line art
- ✅ Tables with black borders
- ❌ All colors removed
- ❌ Photos removed or converted to high-contrast outlines
- ❌ Decorative elements removed
- ❌ Backgrounds completely removed

**Ink Usage**: Minimal (95% less than original)

**Trade-off**: Some visual appeal lost, but maximum economy

---

## Technical Specifications

### Page Setup

**Margins for Binding:**
```
Standard:
- Left: 1.0" (for binding hole punch or stapling)
- Right: 0.75"
- Top: 0.75"
- Bottom: 0.75"

Duplex Printing:
- Odd pages: Left 1.0", Right 0.75"
- Even pages: Left 0.75", Right 1.0" (mirrored)
```

**Page Size:**
- US Letter: 8.5" × 11"
- A4: 210mm × 297mm
- Legal: 8.5" × 14" (if needed)

**Resolution:**
- Text: Vector (crisp at any size)
- Images: 150 DPI (sufficient for printing)
- Charts: Vector or 200 DPI

---

## Subject Theme Color Mappings

### Full Color Mode

| Subject | Original Theme | Print-Friendly Version |
|---------|---------------|------------------------|
| **Mathematics** | Blue (#2563eb) | Blue headers, thin accent bars |
| **Science** | Green (#16a34a) | Green section markers, chart accents |
| **Language Arts** | Purple (#7c3aed) | Purple chapter titles, quote borders |
| **History** | Brown (#92400e) | Brown timeline bars, era markers |
| **Foreign Languages** | Red (#dc2626) | Red vocabulary boxes, cultural markers |
| **Arts** | Orange (#ea580c) | Orange project headers, technique boxes |
| **Physical Education** | Teal (#14b8a6) | Teal exercise headers, safety boxes |

### Grayscale Mode

| Subject | Gray Equivalent | Pattern |
|---------|----------------|---------|
| **Mathematics** | #404040 (25% black) | Dotted patterns |
| **Science** | #606060 (38% black) | Diagonal lines |
| **Language Arts** | #505050 (31% black) | Crosshatch |
| **History** | #707070 (44% black) | Horizontal lines |
| **Foreign Languages** | #454545 (27% black) | Vertical lines |

---

## Background Conversion Rules

### Light Backgrounds (Tint < 20%)
**Original**: Solid light blue background (#eff6ff)
**Converted To**:
- **Full Color**: 2pt blue border (#2563eb) around element
- **Grayscale**: 1pt gray border (#404040)
- **B&W**: 0.5pt black border

### Medium Backgrounds (Tint 20-50%)
**Original**: Medium blue box (#bfdbfe)
**Converted To**:
- **Full Color**: 3pt blue left border + white background
- **Grayscale**: Bold text + gray left border
- **B&W**: Bold text + black left border

### Dark Backgrounds (Tint > 50%)
**Original**: Dark blue header (#1e40af) with white text
**Converted To**:
- **Full Color**: Thin dark blue bar (0.25" height) with white text
- **Grayscale**: White text on dark gray bar
- **B&W**: Black text with heavy border + white background

---

## Smart Element Handling

### Charts & Diagrams

**Full Color Mode:**
- Preserve all colors
- Remove background grids (use light gray lines)
- Increase line weights for visibility

**Grayscale Mode:**
- Convert colors to patterns:
  - Red → Dense dots
  - Blue → Diagonal lines ↗
  - Green → Crosshatch ⊞
  - Yellow → Light dots
- Labels remain legible
- Legend shows pattern key

**B&W Mode:**
- Line graphs: Different line styles (solid, dashed, dotted)
- Bar charts: Patterns (solid, striped, dotted)
- Pie charts: Labeled sections with patterns

### Photos & Images

**Full Color Mode:**
- Preserve essential photos (portraits, examples)
- Remove decorative images
- Compress to 150 DPI

**Grayscale Mode:**
- Convert to high-contrast B&W
- Apply histogram stretching for clarity
- Remove non-essential photos

**B&W Mode:**
- Convert to line art (high contrast threshold)
- Remove photos unless critical
- Replace with text descriptions if needed

### Tables

**Full Color Mode:**
- Header row: Theme color (light) with colored text
- Alternating rows: White and 5% tint
- Borders: Theme color

**Grayscale Mode:**
- Header row: Gray background with bold text
- Alternating rows: White and light gray
- Borders: Black

**B&W Mode:**
- Header row: Bold text only
- No background colors
- Black borders only

---

## Page Break Optimization

### Smart Breaks
- Never break:
  - Within a table
  - Within a code block
  - Within a formula
  - Within a figure and its caption
  - Within a bulleted/numbered list item

- Preferred breaks:
  - Between major sections
  - Between paragraphs
  - Before new headings (H1, H2)

### Orphan/Widow Control
- Minimum 2 lines at top of page (no widows)
- Minimum 2 lines at bottom of page (no orphans)
- Keep titles with at least 2 lines of following content

---

## Duplex (Double-Sided) Optimization

### Odd/Even Page Layout
```
ODD PAGES (Right side):
┌──────────────────────────┐
│ [0.75"] Header  Chapter │
│                          │
│ Content area             │
│ [1.0" binding margin]    │
│                          │
│ Page 45 [0.75"]          │
└──────────────────────────┘

EVEN PAGES (Left side):
┌──────────────────────────┐
│ Book Title Header [0.75"]│
│                          │
│            Content area  │
│   [1.0" binding margin]  │
│                          │
│     [0.75"] Page 46      │
└──────────────────────────┘
```

### Blank Page Handling
- Insert blank pages to ensure chapters start on odd pages
- Mark intentionally blank pages: "This page intentionally left blank"
- Remove blank pages if user selects single-sided printing

---

## PDF Properties

### Document Properties
```json
{
  "title": "Book Title - Print-Friendly Edition",
  "author": "Author Name",
  "subject": "Subject Area",
  "keywords": "print-friendly, home-printing, economy",
  "mode": "full_color|grayscale|black_white",
  "creator": "Educational Books System",
  "optimized_for": "home_office_printing",
  "paper_size": "us_letter",
  "duplex": true,
  "binding_margin": "1.0_inches_left"
}
```

### PDF Settings
- **Version**: PDF 1.7 or higher
- **Compression**: ZIP (lossless for text, JPEG for images)
- **Fonts**: Embedded subset
- **Color Profile**: sRGB (standard for screen/printer)
- **Transparency**: Flattened
- **Security**: None (allow printing)

---

## Generation Workflow

### Step 1: Source Analysis
- Identify theme colors used
- Catalog all background elements
- List all images, charts, diagrams
- Map page structure

### Step 2: Element Conversion (by mode)
**Full Color:**
- Replace solid backgrounds with borders/bars
- Lighten tint backgrounds to 10%
- Preserve theme colors in headers
- Optimize images to 150 DPI

**Grayscale:**
- Convert theme colors to gray equivalents
- Replace backgrounds with borders
- Convert charts to patterns
- Convert photos to B&W

**B&W:**
- Remove all colors
- Strengthen text hierarchy with sizing
- Convert charts to line styles
- Remove decorative elements

### Step 3: Layout Optimization
- Adjust margins for binding
- Mirror margins for duplex
- Insert page breaks intelligently
- Add printer marks (optional)

### Step 4: Quality Check
- Verify no ink-heavy elements remain
- Check contrast ratios (text readability)
- Validate duplex alignment
- Test print 2-3 sample pages

### Step 5: Generate Three Files
```
print_friendly_pdf/
├── BookTitle_PrintFriendly_FullColor.pdf
├── BookTitle_PrintFriendly_Grayscale.pdf
└── BookTitle_PrintFriendly_BlackWhite.pdf
```

---

## User Instructions Template

Include in each PDF:

```
─────────────────────────────────────────────
PRINTING INSTRUCTIONS - Print-Friendly Edition
─────────────────────────────────────────────

This PDF has been optimized for home/office printing.

PRINT SETTINGS:
□ Paper: US Letter (8.5" × 11")
□ Print: Double-sided (flip on long edge)
□ Orientation: Portrait
□ Binding: Left edge (1" margin)
□ Color: Color or Black & White (this file works with both)

INK SAVING FEATURES:
✓ Backgrounds removed or minimized
✓ Colors optimized for visibility
✓ Decorative elements removed
✓ Estimated ink cost: $8-15 for full book

BINDING OPTIONS:
• 3-hole punch and place in binder
• Staple in upper-left corner (small books)
• Take to copy shop for coil binding
• Use binder clips for temporary binding

TROUBLESHOOTING:
• If margins look wrong: Check duplex settings
• If colors too light: Use Full Color mode
• If using B&W printer: All modes work fine
• If ink usage high: Switch to B&W mode

─────────────────────────────────────────────
```

---

## Cost Comparison

### 200-Page Book Printing Costs

**Original Full-Color PDF:**
- Color ink: $35-45
- Black ink: $8-10
- Paper: $4-6
- **Total: $47-61**

**Print-Friendly Full Color:**
- Color ink: $12-18 (optimized theme colors)
- Black ink: $8-10
- Paper: $4-6
- **Total: $24-34** (50% savings)

**Print-Friendly Grayscale:**
- Color ink: $0
- Black ink: $10-13
- Paper: $4-6
- **Total: $14-19** (70% savings)

**Print-Friendly B&W:**
- Color ink: $0
- Black ink: $8-10
- Paper: $4-6
- **Total: $12-16** (75% savings)

---

## AI Model Recommendations

### Background Analysis & Removal
- **GPT-4 Vision**: Identify decorative vs essential elements
- **Claude Opus**: Determine optimal conversion strategy

### Color Conversion
- **Gemini Pro**: Convert colors to patterns/grayscale
- **Claude Sonnet**: Maintain visual hierarchy

### Layout Optimization
- **GPT-4o**: Page break optimization
- **Claude Opus**: Margin calculations, duplex layout

### Quality Verification
- **GPT-4 Vision**: Check contrast ratios, readability
- **Claude Sonnet**: Validate PDF properties

---

## Quality Checklist

### Visual Quality
- [ ] Headers visible and legible in all modes
- [ ] Theme colors preserved (full color) or converted (grayscale/B&W)
- [ ] Charts/diagrams readable
- [ ] Tables formatted correctly
- [ ] No ink-heavy backgrounds remain
- [ ] Visual hierarchy clear

### Print Optimization
- [ ] Margins correct for binding (1.0" left)
- [ ] Duplex layout mirrored correctly
- [ ] No content cut off at edges
- [ ] Page breaks intelligent (no orphans/widows)
- [ ] Blank pages inserted for chapter starts

### Functionality
- [ ] PDF opens in all major readers
- [ ] Prints correctly on standard printers
- [ ] File size reasonable (<5MB per 100 pages)
- [ ] Fonts embedded
- [ ] No print restrictions

### Cost Efficiency
- [ ] Estimated ink usage 50-75% less than original
- [ ] No solid backgrounds printing
- [ ] Decorative elements removed or minimized
- [ ] Images optimized (150 DPI sufficient)

---

## Metadata Example

```json
{
  "format": "Print-Friendly PDF with Theme Preservation",
  "format_id": "30_PRINT_FRIENDLY_PDF_THEMES",
  "modes": ["full_color", "grayscale", "black_white"],
  "page_size": "8.5×11 inches",
  "page_count": 200,
  "duplex": true,
  "binding_margin": "1.0 inches left",
  "ink_optimization": {
    "backgrounds_removed": true,
    "theme_colors_preserved": true,
    "decorative_elements": "minimized",
    "estimated_savings": "50-75%"
  },
  "print_settings": {
    "recommended_paper": "20-24 lb white",
    "orientation": "portrait",
    "duplex_mode": "flip_long_edge",
    "color_mode": "auto_detect"
  },
  "subject": "mathematics",
  "theme_color": "#2563eb",
  "grade_level": "high_school"
}
```

---

## Related Formats

- **01_PDF_PRINT_300DPI.md**: Professional printing (not optimized for home)
- **02_PDF_DIGITAL_150DPI.md**: Screen reading (not optimized for print)
- **31_PRINT_FRIENDLY_HTML.md**: Web-based print alternative

---

## Update History
- **2025-12-18**: Initial blueprint created
- **Format Number**: 30 of 34 total formats
