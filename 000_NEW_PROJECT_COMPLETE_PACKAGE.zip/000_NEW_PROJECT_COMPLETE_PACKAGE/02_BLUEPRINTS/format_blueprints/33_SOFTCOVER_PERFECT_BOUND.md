# Format Blueprint: Softcover/Perfect Bound Book

## Metadata
- **Format ID**: `33_SOFTCOVER_PERFECT_BOUND`
- **Format Name**: Softcover/Perfect Bound Paperback
- **Tier**: 7 (Physical Books - Standard)
- **File Extension**: `.pdf` (print-ready)
- **Priority**: High (retail, schools, budget-friendly)
- **Durability**: Good (2-5 year lifespan)

---

## Overview

### Purpose
Create affordable, professional paperback books using perfect binding (glued spine). Standard format for trade paperbacks, textbooks, workbooks, and retail distribution. Same professional appearance as hardcover but lower cost.

### Use Cases
- **School Textbooks**: Budget classroom sets
- **College Textbooks**: Rental programs, used market
- **Retail Bookstores**: Standard trade paperback format
- **Workbooks**: Student practice materials
- **Mass Market**: Large print runs for wide distribution
- **Self-Publishing**: Amazon KDP, IngramSpark
- **Professional Development**: Training manuals, guides

---

## Perfect Binding Explained

### What is Perfect Binding?
Pages are gathered, spine edge roughened, then glued to a flexible cover. Creates a square spine like traditional books.

**Process:**
1. Pages collated in correct order
2. Spine edge milled/roughened
3. Hot-melt glue applied to spine
4. Cover wrapped around book block
5. Trimmed to final size on 3 sides

**Advantages:**
- ✅ Clean, professional appearance
- ✅ Square spine for title printing
- ✅ Cost-effective for 50+ pages
- ✅ Industry standard format
- ✅ Fast production

**Limitations:**
- ❌ Won't lie completely flat (unless PUR glue)
- ❌ Less durable than sewn binding
- ❌ Minimum 50 pages typically required
- ❌ Pages can pull out if poorly bound

---

## Cover Design System

### Wraparound Cover Template

**Cover consists of single piece:**
```
┌──────────────────────────────────────────────────────────┐
│         │                    │         │                 │
│  Back   │      Spine         │  Front  │     Flap        │
│  Cover  │     0.5-1.0"       │  Cover  │   (optional)    │
│  8.5"   │                    │  8.5"   │                 │
│         │                    │         │                 │
└──────────────────────────────────────────────────────────┘
    ←─────────────────────────────────────────────────────→
              Total Width = 17.5" + spine + bleed
```

**Design Requirements:**
- Include 0.125" bleed on all edges
- No critical content in spine gutter (0.125" from fold)
- Barcode on back cover (bottom right)
- ISBN on back cover above barcode

---

## Subject Theme Designs

**Use Same Theme System as Hardcover (Format 32):**
- Mathematics: Blue (#2563eb)
- Science: Green (#16a34a)
- Language Arts: Purple (#7c3aed)
- History: Brown (#92400e)
- Foreign Languages: Red (#dc2626)

**Design Adaptation for Softcover:**
- Slightly more vibrant colors (covers are thinner, less premium feel)
- More graphics coverage (40-50% vs 20-30%)
- Bolder fonts (compensate for flex/bend)
- Eye-catching retail appeal

---

## Grade Level Variations

### Elementary (Grades 3-5)
**Cover:**
- Bright, saturated colors
- 60% graphics coverage
- Large friendly fonts
- Gloss lamination (wipeable)
- Rounded corners (optional safety feature)

**Interior:**
- 28-32 lb paper (heavier for durability)
- Full color or color inserts
- Large margins, large fonts

**Cost Target**: $4-6 per book

---

### Middle School (Grades 6-8)
**Cover:**
- Modern, aspirational design
- 40% graphics coverage
- Clean sans-serif fonts
- Matte or soft-touch lamination
- Square corners

**Interior:**
- 24-28 lb paper
- B&W with color insert sections
- Standard academic layout

**Cost Target**: $3-5 per book

---

### High School (Grades 9-12)
**Cover:**
- Professional, sophisticated
- 30% graphics coverage
- Academic fonts
- Matte lamination
- Optional spot UV

**Interior:**
- 20-24 lb paper
- Primarily B&W
- Dense academic content

**Cost Target**: $3-4 per book

---

### College/University
**Cover:**
- Authoritative academic design
- 20% graphics minimal
- Traditional fonts
- Matte finish
- Price prominently displayed

**Interior:**
- 20 lb paper (thin for page count)
- B&W only typically
- Maximum content density

**Cost Target**: $4-7 per book (higher page counts)

---

## Technical Specifications

### Standard Sizes

**US Trade Paperback:**
- 6" × 9" (most common novels/textbooks)
- 7" × 10" (larger textbooks)
- 8" × 10" (workbooks)
- 8.5" × 11" (full-size textbooks, manuals)

**Page Count Requirements:**
- Minimum: 50 pages (25 sheets)
- Maximum: 500+ pages (binding becomes difficult)
- Optimal: 150-300 pages

### Cover Specifications

**Stock:**
- 10pt C1S cardstock (Coated One Side) - Standard
- 12pt C1S cardstock - Premium
- 100 lb cover stock - Economy

**Lamination Options:**
1. **Gloss** - Shiny, vibrant, fingerprint-prone ($0.30-0.50/book)
2. **Matte** - Sophisticated, less glare ($0.40-0.60/book)
3. **Soft-Touch** - Velvet feel, premium ($0.80-1.20/book)
4. **Spot UV** - Gloss accents on matte ($0.60-1.00/book)

### Interior Specifications

**Paper Options:**
- 20 lb white: Economy, thin
- 24 lb white: Standard
- 28 lb white: Premium, heavier
- Cream/Natural: Easier on eyes, vintage feel

**Color:**
- Black & White: $0.02-0.04/page
- Grayscale: $0.03-0.05/page
- Full Color: $0.08-0.15/page

---

## Spine Width Calculator

**Formula:**
```
Spine Width (inches) = (Total Pages ÷ 2) × Paper Caliper

Paper Calipers:
- 20 lb: 0.0024"
- 24 lb: 0.0025"
- 28 lb: 0.0027"
- 32 lb: 0.0030"
```

**Examples:**
```
200 pages, 24 lb paper:
= (200 ÷ 2) × 0.0025"
= 100 × 0.0025"
= 0.25" spine

250 pages, 24 lb paper:
= (250 ÷ 2) × 0.0025"
= 0.3125" = ~5/16" spine

300 pages, 24 lb paper:
= (300 ÷ 2) × 0.0025"
= 0.375" = 3/8" spine
```

**Spine Text Minimum Widths:**
- 0.25" (1/4"): Horizontal text only, 6-8pt
- 0.375" (3/8"): Horizontal text, 8-10pt
- 0.5" (1/2"): Vertical or horizontal, 10-12pt
- 0.75" (3/4"): Comfortable vertical text, 12-14pt

---

## Print-Ready File Package

```
softcover_book/
├── SPECIFICATIONS.pdf
├── cover_wraparound.pdf (CMYK, 300 DPI)
│   ├── Includes: front, spine, back in one file
│   ├── Bleed: 0.125" all edges
│   ├── Safe zone: 0.25" from trim
│   └── Barcode positioned correctly
├── interior_pages.pdf (300 DPI, imposed or sequential)
├── spine_calculator.xlsx
├── binding_specifications.txt
└── mockup_3d.jpg
```

---

## Production Specifications Document

```
═══════════════════════════════════════════════
SOFTCOVER/PERFECT BOUND BOOK SPECIFICATIONS
═══════════════════════════════════════════════

BOOK INFORMATION:
Title: [Book Title]
ISBN-13: [978-X-XXXXX-XXX-X]
Trim Size: 8.5" × 11"
Total Pages: 250 pages
Binding: Perfect Bound (PUR glue)

COVER:
Stock: 10pt C1S cardstock
Finish: Matte lamination (3 mil)
Print: Full color (CMYK), outside only
Spine Width: 0.625"
Cover Dimensions: 17.75" × 11.25" (with bleed)

Breakdown:
- Front Cover: 8.5" × 11"
- Spine: 0.625" × 11"
- Back Cover: 8.5" × 11"
- Bleed: 0.125" all sides

INTERIOR:
Paper: 50 lb offset white
Pages: 250 pages (125 sheets)
Print: Black & white
Bleed: None (standard margins)

BARCODE:
Position: Back cover, bottom right
Size: 2" × 1.2"
Clear space: 0.25" around barcode

QUANTITY: 1,000 copies
UNIT COST: $4.25 per book
DELIVERY: [Date]
═══════════════════════════════════════════════
```

---

## Quality Control

### Cover Checklist
- [ ] Spine width calculated correctly
- [ ] Barcode scannable (test required)
- [ ] Price visible and correct
- [ ] Theme colors consistent
- [ ] No content in 0.25" spine safety zone
- [ ] Lamination type specified

### Interior Checklist
- [ ] Pages in correct order
- [ ] Page numbers sequential
- [ ] No blank pages unintended
- [ ] Margins consistent (0.5" minimum inside)
- [ ] Images 300 DPI minimum

### Binding Checklist
- [ ] PUR glue specified (stronger than EVA)
- [ ] Spine milling depth correct
- [ ] Cover alignment accurate
- [ ] Book opens without cracking
- [ ] Pages don't pull out easily

---

## Cost Comparison

### Per-Book Costs (250 pages, 8.5×11, B&W interior)

| Quantity | Setup | Per Book | Total | Unit Cost |
|----------|-------|----------|-------|-----------|
| 100 | $300 | $6.00 | $900 | $9.00 |
| 500 | $400 | $4.50 | $2,650 | $5.30 |
| 1,000 | $500 | $3.75 | $4,250 | $4.75 |
| 2,500 | $600 | $3.00 | $8,100 | $3.24 |
| 5,000 | $700 | $2.50 | $13,200 | $2.64 |

---

## AI Model Recommendations

### Cover Design
- **DALL-E 3 / Midjourney**: Graphics generation
- **Claude Opus**: Layout and typography
- **GPT-4o**: Color matching and theme consistency

### Spine Calculator
- **Claude Opus**: Mathematical precision
- **GPT-4o**: Specification generation

---

## Metadata Example

```json
{
  "format": "Softcover/Perfect Bound Book",
  "format_id": "33_SOFTCOVER_PERFECT_BOUND",
  "binding_type": "perfect_bound_pur_glue",
  "trim_size": "8.5×11 inches",
  "page_count": 250,
  "cover": {
    "stock": "10pt_c1s_cardstock",
    "finish": "matte_lamination",
    "print": "full_color_outside",
    "spine_width": "0.625 inches"
  },
  "interior": {
    "paper": "50 lb offset white",
    "color": "black_white",
    "page_count": 250
  },
  "subject": "mathematics",
  "theme_color": "#2563eb",
  "grade_level": "high_school",
  "use_case": "textbook_retail_school",
  "cost_per_unit": "$3-5 (volume dependent)"
}
```

---

## Related Formats
- **32_HARDCOVER_CASE_BOUND.md**: Premium version
- **29_SPIRAL_COIL_BOUND.md**: Lay-flat alternative
- **34_PRINT_SHOP_PACKAGE.md**: Complete specs

---

## Update History
- **2025-12-18**: Initial blueprint created
- **Format Number**: 33 of 34 total formats
