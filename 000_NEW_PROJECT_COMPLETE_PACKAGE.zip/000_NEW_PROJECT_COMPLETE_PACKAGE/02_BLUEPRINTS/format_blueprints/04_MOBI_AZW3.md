# Format Blueprint: MOBI/AZW3 (Amazon Kindle Format)

## Metadata
- **Format ID**: `04_MOBI_AZW3`
- **Format Name**: Kindle E-Book (MOBI/AZW3)
- **Tier**: 1 (Core - Always Generate)
- **File Extension**: `.mobi` or `.azw3`
- **Priority**: Critical
- **Platform**: Amazon Kindle ecosystem

---

## Overview

### Purpose
Create e-books specifically for Amazon Kindle devices and apps. Kindle is the world's largest e-book platform with 70%+ market share, making this format essential.

### Format Variants
1. **MOBI (KF7)**: Older Kindle format, universal compatibility
2. **AZW3 (KF8)**: Modern Kindle format, enhanced features
3. **Strategy**: Generate both for maximum compatibility

### Why Kindle Needs Special Format
- ❌ Kindle doesn't support EPUB natively
- ✅ MOBI/AZW3 are Amazon's proprietary formats
- ✅ Optimized for Kindle hardware (e-ink displays)
- ✅ Integration with Amazon ecosystem (Whispersync, X-Ray)

---

## Kindle Device Compatibility

### Kindle E-Readers
- ✅ Kindle (basic model)
- ✅ Kindle Paperwhite
- ✅ Kindle Oasis
- ✅ Kindle Scribe

### Kindle Apps
- ✅ iPhone/iPad (iOS app)
- ✅ Android phones/tablets
- ✅ Mac computers
- ✅ Windows computers
- ✅ Web browser (Kindle Cloud Reader)

### Legacy Devices
- ✅ Older Kindle models (2007+)
- ✅ Kindle Fire tablets

---

## Technical Specifications

### MOBI vs. AZW3 Comparison

| Feature | MOBI (KF7) | AZW3 (KF8) |
|---------|-----------|------------|
| **Release** | 2011 | 2011 |
| **HTML** | HTML 4 | HTML5 |
| **CSS** | CSS 2 | CSS3 |
| **Fonts** | Limited | Full embedding |
| **Images** | Basic | Advanced |
| **Tables** | Basic | Full support |
| **Lists** | Basic | Full support |
| **Fixed Layout** | No | Yes |
| **Compatibility** | All Kindles | 2011+ Kindles |

**Our Strategy**: Generate both, deliver AZW3 primarily, MOBI as fallback.

---

## File Structure (AZW3/MOBI)

Unlike EPUB (ZIP), MOBI is a single binary file with embedded resources.

### Internal Structure:
```
book.mobi
├── MOBI Header
├── PDB Database Header
├── EXTH Records (metadata)
├── HTML Content (all chapters concatenated)
├── Images (embedded as binary)
├── Fonts (if embedded)
├── Table of Contents (NCX-like)
├── Cover Image
└── DRM Info (if applicable - we don't use DRM)
```

---

## Metadata (EXTH Records)

### Complete Metadata Set:
```xml
<metadata>
  <dc:Title>Book Title</dc:Title>
  <dc:Creator opf:role="aut">Author Name</dc:Creator>
  <dc:Language>en</dc:Language>
  <dc:Identifier opf:scheme="ISBN">978-X-XXXXX-XXX-X</dc:Identifier>
  <dc:Subject>Mathematics</dc:Subject>
  <dc:Description>
    Complete algebra course for high school students...
  </dc:Description>
  <dc:Publisher>Educational Books System</dc:Publisher>
  <dc:Date>2025-12-18</dc:Date>

  <!-- Kindle-specific metadata -->
  <output encoding="utf-8" content-type="application/x-mobipocket-ebook"/>
  <x-metadata>
    <ASIN>BXXXXXXXXX</ASIN> <!-- Amazon assigns this -->
    <Fixed-Layout>false</Fixed-Layout>
    <RegionMagnification>false</RegionMagnification>
    <Print-Replica>false</Print-Replica>
  </x-metadata>
</metadata>
```

---

## HTML Content (Kindle-Optimized)

### Chapter HTML Structure:
```html
<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
  "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
  <title>Chapter 1: Introduction to Algebra</title>
  <style type="text/css">
    /* Inline CSS for Kindle */
  </style>
</head>
<body>
  <div class="chapter">
    <h1 class="chapter-title">Chapter 1: Introduction to Algebra</h1>

    <p>In this chapter, we will explore fundamental concepts...</p>

    <div class="figure">
      <img src="images/figure01.jpg" alt="Coordinate plane"/>
      <p class="caption">Figure 1.1: The Coordinate Plane</p>
    </div>

    <div class="callout">
      <h2>Key Concept</h2>
      <p>Remember: The x-axis is horizontal, y-axis is vertical.</p>
    </div>

    <h2>1.1 Basic Concepts</h2>
    <p>Content continues...</p>

    <!-- Page break for Kindle -->
    <mbp:pagebreak/>

  </div>
</body>
</html>
```

---

## CSS for Kindle

### Kindle-Safe CSS:
```css
/* ==========================================
   KINDLE STYLESHEET (KF8/AZW3)
   ========================================== */

/* BODY */
body {
  font-family: serif; /* Kindle provides fonts */
  font-size: 1em; /* User adjustable */
  line-height: 1.5;
  margin: 0;
  padding: 5px;
}

/* HEADINGS */
h1, h2, h3 {
  font-weight: bold;
  page-break-after: avoid;
  text-align: left;
}

h1.chapter-title {
  font-size: 1.75em;
  color: #000; /* E-ink is grayscale */
  border-bottom: 2px solid #000;
  margin-top: 0;
  margin-bottom: 1em;
  page-break-before: always;
}

h2 {
  font-size: 1.4em;
  margin-top: 1.5em;
  margin-bottom: 0.75em;
}

h3 {
  font-size: 1.2em;
  margin-top: 1.2em;
  margin-bottom: 0.5em;
}

/* PARAGRAPHS */
p {
  margin: 0 0 1em 0;
  text-indent: 0;
  text-align: justify;
}

p + p {
  text-indent: 1.5em; /* First line indent */
}

/* LISTS */
ul, ol {
  margin: 1em 0;
  padding-left: 2em;
}

li {
  margin-bottom: 0.5em;
}

/* FIGURES */
div.figure {
  margin: 1.5em 0;
  text-align: center;
  page-break-inside: avoid;
}

div.figure img {
  max-width: 100%;
  height: auto;
}

p.caption {
  font-size: 0.9em;
  font-style: italic;
  margin-top: 0.5em;
  text-align: center;
}

/* CALLOUT BOXES */
div.callout {
  border: 1px solid #000;
  padding: 1em;
  margin: 1.5em 0;
  page-break-inside: avoid;
}

div.callout h2 {
  margin-top: 0;
  font-size: 1.1em;
}

/* TABLES */
table {
  width: 100%;
  border-collapse: collapse;
  margin: 1.5em 0;
  page-break-inside: avoid;
}

th {
  font-weight: bold;
  padding: 0.5em;
  border: 1px solid #000;
  text-align: left;
  background-color: #e0e0e0;
}

td {
  padding: 0.5em;
  border: 1px solid #000;
}

/* CODE */
code, pre {
  font-family: monospace;
  font-size: 0.9em;
}

pre {
  background-color: #f0f0f0;
  border: 1px solid #ccc;
  padding: 0.75em;
  overflow-x: auto;
  page-break-inside: avoid;
}

/* LINKS (Kindle supports internal & external) */
a {
  color: inherit; /* Grayscale e-ink */
  text-decoration: underline;
}

/* KINDLE PAGE BREAKS */
.page-break, mbp\\:pagebreak {
  page-break-after: always;
}

/* COVER PAGE */
div.cover-page {
  text-align: center;
  margin-top: 30%;
}

div.cover-page img {
  max-width: 100%;
}

/* NO COLOR ON E-INK DEVICES */
/* All colors render as grayscale */
/* Use bold/borders for emphasis instead */
```

---

## Images for Kindle

### Image Requirements:
**Format**: JPEG or PNG
**Resolution**: 150 DPI (Kindle screens are ~167-300 PPI)
**Color**: RGB or Grayscale
**Size**: Max 5MB per image, 127KB recommended for e-ink

### Image Optimization:
```python
# Pseudocode
for image in book.images:
    # E-ink Kindles are grayscale (except Fire tablets)
    if target_device == "e-ink":
        image.convert_to_grayscale()

    image.resize_to_150dpi()
    image.compress(quality=80)

    if image.size > 127KB:
        image.compress_more(quality=70)
```

### Cover Image:
- **Size**: 1600 × 2560 pixels (Kindle ideal)
- **Aspect Ratio**: 1:1.6 (portrait)
- **Format**: JPEG
- **Quality**: High (90%)

---

## Table of Contents (TOC)

### NCX File (Navigation):
```xml
<?xml version="1.0" encoding="UTF-8"?>
<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1">
  <head>
    <meta name="dtb:uid" content="978-X-XXXXX-XXX-X"/>
    <meta name="dtb:depth" content="2"/>
    <meta name="dtb:totalPageCount" content="0"/>
    <meta name="dtb:maxPageNumber" content="0"/>
  </head>

  <docTitle>
    <text>Book Title</text>
  </docTitle>

  <navMap>
    <navPoint id="navPoint-1" playOrder="1">
      <navLabel><text>Cover</text></navLabel>
      <content src="cover.html"/>
    </navPoint>

    <navPoint id="navPoint-2" playOrder="2">
      <navLabel><text>Table of Contents</text></navLabel>
      <content src="toc.html"/>
    </navPoint>

    <navPoint id="navPoint-3" playOrder="3">
      <navLabel><text>Chapter 1: Introduction</text></navLabel>
      <content src="chapter01.html"/>

      <!-- Sub-sections -->
      <navPoint id="navPoint-3-1" playOrder="4">
        <navLabel><text>1.1 Basic Concepts</text></navLabel>
        <content src="chapter01.html#section1-1"/>
      </navPoint>
    </navPoint>

    <navPoint id="navPoint-4" playOrder="5">
      <navLabel><text>Chapter 2: Fundamentals</text></navLabel>
      <content src="chapter02.html"/>
    </navPoint>
  </navMap>
</ncx>
```

---

## Kindle-Specific Features

### 1. X-Ray (Amazon Feature)
Allows readers to explore characters, terms, and concepts.
```xml
<x-ray>
  <term id="variable">
    <name>Variable</name>
    <definition>A symbol representing a number</definition>
    <occurrences>
      <location>chapter01.html#para5</location>
      <location>chapter02.html#para12</location>
    </occurrences>
  </term>
</x-ray>
```

### 2. Whispersync for Voice
Sync between e-book and audiobook:
```xml
<sync-narration>
  <audio href="chapter01.mp3"/>
  <text href="chapter01.html"/>
</sync-narration>
```

### 3. Word Wise
Inline definitions for difficult words:
```xml
<word-wise>
  <word id="quadratic">
    <hint>relating to a math equation with squared variable</hint>
  </word>
</word-wise>
```

### 4. Page Flip
Navigate without losing place:
```xml
<page-flip enabled="true"/>
```

---

## Conversion Tools

### Kindle Previewer
Amazon's official tool for testing:
- Download: Amazon Kindle Previewer
- Tests on various Kindle models
- Shows how book will render

### Kindle Create
Amazon's book creation tool:
- WYSIWYG editor
- Auto-generates TOC
- Exports to KPF (Kindle Package Format)

### KindleGen (Deprecated)
Older command-line tool:
```bash
kindlegen book.opf -o output.mobi
```
**Note**: Replaced by Kindle Previewer

### Calibre
Open-source converter:
```bash
ebook-convert book.epub book.mobi
```

---

## File Size & Performance

### Target Sizes:
- **Text-Heavy**: 1-3 MB
- **Standard**: 3-8 MB
- **Image-Heavy**: 8-15 MB
- **Maximum**: 50 MB (Amazon limit)

### Delivery Costs:
Amazon charges delivery fees based on file size for self-published books:
- $0.15/MB (70% royalty option)
- Free (35% royalty option)

**Our Goal**: Keep under 10 MB when possible

---

## Generation Workflow

### Method 1: EPUB → MOBI Conversion
1. Generate EPUB 3.0 (Format 03)
2. Convert EPUB to MOBI using Calibre or Kindle Previewer
3. Test on Kindle devices/apps
4. Optimize if needed

### Method 2: Direct Generation
1. Use Amazon Kindle Create
2. Import content
3. Format for Kindle
4. Export KPF
5. Upload to KDP (Kindle Direct Publishing)

---

## Quality Checklist

### Content
- [ ] All chapters present and in order
- [ ] TOC functional and complete
- [ ] Images display correctly
- [ ] Tables format properly
- [ ] No missing content

### Formatting
- [ ] Chapter breaks correct
- [ ] Headings styled appropriately
- [ ] Paragraphs formatted consistently
- [ ] Lists render correctly
- [ ] Code blocks monospaced

### Images
- [ ] Cover image 1600×2560 px
- [ ] All images under 127 KB (recommended)
- [ ] Images grayscale for e-ink devices
- [ ] Alt text present

### Navigation
- [ ] TOC works on all devices
- [ ] Internal links functional
- [ ] External links work (if applicable)
- [ ] X-Ray data included (optional)

### Testing
- [ ] Kindle Previewer (multiple devices)
- [ ] Actual Kindle e-reader
- [ ] Kindle iOS/Android app
- [ ] Kindle Cloud Reader (web)

---

## Amazon KDP (Kindle Direct Publishing)

### Upload Process:
1. Create KDP account
2. Enter book details (title, author, description)
3. Upload MOBI or KPF file
4. Set pricing
5. Choose royalty option (35% or 70%)
6. Publish

### Book Details Required:
- Title and subtitle
- Author name
- Contributors (if any)
- Description (4000 characters)
- Categories (2 required)
- Keywords (7 max)
- Age/grade range
- Cover image

---

## AI Model Recommendations

### Content Conversion
- **Claude Opus**: EPUB → Kindle HTML conversion
- **GPT-4o**: Optimize CSS for Kindle constraints

### Image Optimization
- **GPT-4 Vision**: Determine which images need grayscale
- **Claude Sonnet**: Batch optimize images

### TOC Generation
- **Claude Sonnet**: Generate NCX navigation
- **Gemini Pro**: Validate structure

### X-Ray Data
- **GPT-4o**: Extract key terms and concepts
- **Claude Opus**: Generate definitions

---

## Metadata Example

```json
{
  "format": "MOBI/AZW3 (Kindle)",
  "format_id": "04_MOBI_AZW3",
  "file_extensions": [".mobi", ".azw3"],
  "file_size": "7.2 MB",
  "target_platform": "Amazon Kindle",
  "compatibility": {
    "kindle_ereaders": "all_models",
    "kindle_apps": ["iOS", "Android", "Mac", "Windows"],
    "kindle_cloud_reader": true
  },
  "features": {
    "x_ray": true,
    "whispersync": true,
    "word_wise": false,
    "page_flip": true
  },
  "images": {
    "format": "JPEG grayscale",
    "resolution": "150 DPI",
    "cover": "1600x2560 px"
  },
  "epub_compatible": false,
  "drm": false
}
```

---

## Related Formats
- **03_EPUB_30.md**: Universal e-reader format (non-Kindle)
- **02_PDF_DIGITAL_150DPI.md**: Fixed layout alternative
- **05_HTML_RESPONSIVE.md**: Web-based version

---

## Update History
- **2025-12-18**: Initial blueprint created
- **Format Number**: 04 of 34 total formats
