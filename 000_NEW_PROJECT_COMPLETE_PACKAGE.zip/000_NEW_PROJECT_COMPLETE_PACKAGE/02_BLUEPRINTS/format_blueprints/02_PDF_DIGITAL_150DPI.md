# Format Blueprint: PDF Digital 150 DPI

## Metadata
- **Format ID**: `02_PDF_DIGITAL_150DPI`
- **Format Name**: PDF Digital Edition (Screen Optimized)
- **Tier**: 1 (Core - Always Generate)
- **File Extension**: `.pdf`
- **Priority**: Critical
- **Use Case**: Screen reading, web distribution, email sharing

---

## Overview

### Purpose
Create screen-optimized PDFs for digital reading on computers, tablets, and phones. Smaller file size than print PDFs while maintaining excellent screen readability.

### Key Differences from Print PDF (Format 01)
| Feature | Print 300 DPI | Digital 150 DPI |
|---------|--------------|-----------------|
| **Resolution** | 300 DPI | 150 DPI |
| **File Size** | 30-60 MB | 8-15 MB |
| **Purpose** | Physical printing | Screen reading |
| **Images** | Print quality | Screen optimized |
| **Fonts** | Embedded for printing | Screen-optimized rendering |
| **Hyperlinks** | Minimal | Fully interactive |
| **Bookmarks** | Basic TOC | Full navigation tree |
| **File Size Priority** | Quality first | Balance quality & size |

---

## Technical Specifications

### Resolution & Image Quality
**Images**: 150 DPI (screens are typically 72-120 DPI)
- Photos: JPEG compression, optimized for screen
- Diagrams: PNG or vector (SVG embedded)
- Charts: Vector format when possible
- Icons: Vector or high-quality raster

**Why 150 DPI?**
- 2× screen resolution = crisp on all displays
- Handles Retina/HiDPI screens
- 70% smaller than 300 DPI
- Still looks great if printed at letter size

### File Size Optimization
**Target**: 8-15 MB for 200-page book
- Images: JPEG quality 80-85% (vs 95% for print)
- Compression: ZIP for text, JPEG for images
- Fonts: Subset embedding (only used characters)
- Remove: Print crop marks, bleed areas

### Page Setup
**Size**: Maintain standard sizes (8.5×11, A4)
**Orientation**: Portrait (or as designed)
**Margins**: Standard (no printer margins needed)
**Bleed**: None required

---

## Interactive Features

### Hyperlinks (Active & Clickable)
**Internal Links**:
- Table of Contents → Chapters
- Index entries → Page references
- Cross-references → Referenced sections
- Footnotes → Footnote text (bidirectional)

**External Links**:
- Citations → Source URLs
- References → Online resources
- Author website
- Publisher website
- Related materials

**Implementation**:
```xml
<link dest="chapter_3" type="internal">
<link href="https://example.com/resource" type="external">
```

### Navigation Bookmarks
**Full Bookmark Tree**:
```
Book Title
├─ Front Matter
│  ├─ Table of Contents
│  ├─ Introduction
│  └─ How to Use This Book
├─ Chapter 1: [Title]
│  ├─ Section 1.1
│  ├─ Section 1.2
│  └─ Summary
├─ Chapter 2: [Title]
│  ├─ Section 2.1
│  └─ Section 2.2
└─ Back Matter
   ├─ Glossary
   ├─ Index
   └─ References
```

**Benefits**:
- Jump to any section instantly
- Navigate without scrolling
- Especially useful on tablets/phones

### Form Fields (If Applicable)
For interactive workbooks:
- Text input fields
- Checkboxes for self-assessment
- Radio buttons for multiple choice
- Signature fields for completion

---

## Typography Optimization

### Screen-Optimized Fonts
**Body Text**:
- Font: Source Sans Pro, Open Sans, or Merriweather
- Size: 11-12pt (slightly larger than print)
- Line Height: 1.5-1.6 (more generous for screen)
- Color: True black (#000000) or dark gray (#1a1a1a)

**Headers**:
- Clear hierarchy
- Bold weights for emphasis
- Subject theme colors
- Sans-serif for clarity

### Anti-Aliasing
- Sub-pixel rendering enabled
- Smooth font edges
- Optimized for RGB screens

---

## Color Management

### Color Profile
**Profile**: sRGB IEC61966-2.1 (standard for screens)
- Not CMYK (printing)
- Consistent across devices
- Web-safe color space

### Subject Theme Colors
Full saturation allowed (unlike print):
- **Mathematics**: Vibrant blue (#2563eb)
- **Science**: Rich green (#16a34a)
- **Language Arts**: Deep purple (#7c3aed)
- **History**: Warm brown (#92400e)

No need for print color matching.

---

## Accessibility Features

### PDF/UA Compliance
- Tagged PDF structure
- Reading order defined
- Alt text for all images
- Table headers marked
- List structure preserved
- Headings hierarchically tagged

### Screen Reader Optimization
```xml
<H1>Chapter Title</H1>
<P>Body text here...</P>
<Figure Alt="Description of image">
<Table>
  <THead>
    <TR><TH>Header</TH></TR>
  </THead>
  <TBody>
    <TR><TD>Data</TD></TR>
  </TBody>
</Table>
```

### Text Selection
- All text selectable (not images of text)
- Copy/paste enabled
- Search enabled
- Dictionary lookup enabled

---

## Metadata (Enhanced for Digital)

```json
{
  "title": "Book Title",
  "author": "Author Name",
  "subject": "Mathematics",
  "keywords": "algebra, equations, high school, digital edition",
  "creator": "Educational Books System",
  "producer": "Digital PDF Generator v1.0",
  "format": "Digital Edition 150 DPI",
  "version": "1.0",
  "language": "en-US",
  "page_count": 250,
  "isbn": "978-X-XXXXX-XXX-X",
  "grade_level": "9-12",
  "pdf_version": "1.7",
  "pdf_a_compliant": false,
  "accessibility": "PDF/UA-1",
  "interactive": true,
  "file_size": "12.5 MB",
  "optimized_for": "screen_reading",
  "created": "2025-12-18",
  "modified": "2025-12-18"
}
```

---

## Device Optimization

### Desktop/Laptop
- Full-width layout
- Two-page spread view option
- Zoom controls effective
- Smooth scrolling

### Tablet (iPad, Android)
- Single-page view recommended
- Touch-friendly navigation
- Pinch-to-zoom support
- Landscape/portrait responsive

### Phone
- Single-page view only
- Reflowable reading mode (if supported)
- Larger touch targets
- Simplified navigation

---

## Compression Settings

### Image Compression
**Photos**:
```
Format: JPEG
Quality: 82%
Color Space: sRGB
Resolution: 150 DPI
Downsample: Bicubic
```

**Diagrams/Charts**:
```
Format: PNG-8 or PNG-24
Compression: Maximum (lossless)
Resolution: 150 DPI or Vector
Transparency: Preserved if needed
```

### Overall PDF Compression
```
Text: ZIP compression
Objects: Compressed
Fonts: Subset embedded
Streams: Compressed
Linearization: Yes (fast web view)
```

---

## Comparison with Other Formats

### vs. Print PDF (Format 01)
- ✅ 70% smaller file size
- ✅ Faster download/email
- ✅ Interactive hyperlinks
- ✅ Better on-screen clarity
- ❌ Not ideal for printing

### vs. EPUB (Format 03)
- ✅ Preserves exact layout
- ✅ Works in any PDF reader
- ✅ No reflowing issues
- ❌ Larger file size
- ❌ Less flexible on small screens

### vs. HTML (Format 05)
- ✅ Single file (portable)
- ✅ Offline reading
- ✅ Consistent appearance
- ❌ Not searchable like web
- ❌ Requires PDF reader

---

## Distribution Channels

**Perfect For**:
- Email attachments (manageable size)
- Website downloads
- Learning management systems (LMS)
- File sharing services (Dropbox, Google Drive)
- Mobile apps (embedded PDF readers)
- Corporate intranets
- Student portals

**Not Ideal For**:
- Professional printing (use Format 01)
- E-readers (use EPUB Format 03)
- Very small screens (use HTML Format 05)

---

## Generation Workflow

### Step 1: Start with Master Content
Use Pipeline 1 master content

### Step 2: Optimize Images
```python
# Pseudocode
for image in book.images:
    if image.is_photo():
        image.convert_to_jpeg(quality=82)
        image.resize_to_150dpi()
    elif image.is_diagram():
        if image.can_vectorize():
            image.convert_to_vector()
        else:
            image.convert_to_png(compression='max')
```

### Step 3: Add Interactive Features
- Generate bookmark tree from headings
- Convert cross-references to hyperlinks
- Add external links
- Create TOC navigation

### Step 4: Embed Fonts (Subset)
```
Only embed characters actually used in document
Reduces file size by 60-80%
```

### Step 5: Apply Compression
- ZIP compress text streams
- JPEG compress images
- Linearize for fast web view

### Step 6: Add Metadata
- Complete document properties
- Accessibility tags
- Search keywords

### Step 7: Validate
- Check file size (< 15 MB for 200 pages)
- Test hyperlinks
- Verify bookmarks
- Test on multiple devices

---

## Quality Checklist

### Visual Quality
- [ ] Text crisp and clear on screen
- [ ] Images clear at 100% zoom
- [ ] Charts/diagrams readable
- [ ] Colors accurate (sRGB)
- [ ] No pixelation on Retina displays

### Functionality
- [ ] All hyperlinks work
- [ ] Bookmarks navigate correctly
- [ ] TOC links functional
- [ ] Search works across entire document
- [ ] Text selectable and copyable

### File Properties
- [ ] File size under 15 MB (200-page book)
- [ ] Metadata complete
- [ ] Fonts embedded (subset)
- [ ] Linearized (fast web view)
- [ ] PDF version 1.7 or higher

### Accessibility
- [ ] Tagged PDF structure
- [ ] Reading order correct
- [ ] Alt text present for images
- [ ] Screen reader compatible
- [ ] Keyboard navigation works

### Device Compatibility
- [ ] Opens on Windows (Adobe, Edge, Chrome)
- [ ] Opens on Mac (Preview, Safari, Adobe)
- [ ] Works on iPad (Books, Adobe)
- [ ] Works on Android tablets
- [ ] Mobile-friendly on phones

---

## AI Model Recommendations

### Image Optimization
- **GPT-4 Vision**: Determine which images need vector conversion
- **Claude Opus**: Optimize compression settings per image type

### Hyperlink Generation
- **Claude Sonnet**: Parse references and create link structure
- **GPT-4o**: Validate all URLs

### Bookmark Tree Creation
- **Claude Opus**: Generate hierarchical bookmark structure
- **Gemini Pro**: Ensure proper nesting

### Accessibility Tagging
- **GPT-4o**: Generate PDF/UA tags
- **Claude Sonnet**: Create alt text for images

---

## Related Formats

- **01_PDF_PRINT_300DPI.md**: High-quality print version
- **03_EPUB_30.md**: Reflowable e-reader version
- **05_HTML_RESPONSIVE.md**: Web-based alternative
- **30_PRINT_FRIENDLY_PDF_THEMES.md**: Home printing version

---

## Update History
- **2025-12-18**: Initial blueprint created
- **Format Number**: 02 of 34 total formats
