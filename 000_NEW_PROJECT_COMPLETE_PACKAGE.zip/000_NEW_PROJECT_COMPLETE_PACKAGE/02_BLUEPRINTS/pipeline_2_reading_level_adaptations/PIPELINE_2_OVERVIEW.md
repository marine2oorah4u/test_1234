# PIPELINE 2: READING LEVEL ADAPTATIONS - OVERVIEW

## 🚨 CRITICAL: AI Fallback Rules Apply
**See:** `/blueprints/CRITICAL_AI_FALLBACK_RULES.md` - All AI calls in this pipeline MUST use fallback chains. System never fails.

---

## Quick Reference

**Purpose:** Adapt every book from Pipeline 1 to 8 different reading levels for maximum accessibility

**Input:** All books from Pipeline 1 (Master, Tiered, Sub-topic, General)

**Output:** 8 reading level versions of EVERY book

**Timeline:** 2-4 hours per book

**Cost:** $15-30 per book adaptation

**AI Models:** 6-8 models used for adaptation and verification

---

## What Gets Created

### For EVERY Book from Pipeline 1:

Starting with 20 books per subject (from Pipeline 1):
- 1 Master Reference Book
- 6 Tiered Books
- 12 Sub-topic Books
- 1 General Overview Book

**Pipeline 2 creates 8 reading level versions of each = 160 books per subject**

### 8 Reading Levels:

1. **Elementary (Grades 3-5)**
   - Simple sentences, basic vocabulary
   - Heavy visual support
   - 15-20 images per section

2. **Middle School (Grades 6-8)**
   - Moderate complexity
   - Standard vocabulary with definitions
   - 12-15 images per section

3. **High School (Grades 9-12)**
   - More complex sentences
   - Technical terms introduced
   - 10-12 images per section

4. **College/University**
   - Academic language
   - Research-oriented
   - 8-10 images per section

5. **Professional/Adult**
   - Industry terminology
   - Practical focus
   - 6-8 images per section

6. **Advanced Professional**
   - Expert-level content
   - Specialized jargon
   - 5-7 images per section

7. **Plain Language (Maximum Accessibility)**
   - Simplest possible language
   - Clear, direct communication
   - 20+ images per section
   - Perfect for ESL, cognitive disabilities

8. **Quick Reference**
   - Ultra-concise
   - Bullet points, tables, lists
   - Visual-heavy
   - Fast access format

---

## 12-Step Adaptation Process

### BOOK PIPELINE (Steps 1-12)
Runs once per book, creates all 8 levels simultaneously

#### STEP 1: Source Analysis
- 3 AI models analyze source book
- Identify content structure, complexity, key concepts
- Duration: 5-8 minutes

#### STEP 2: Adaptation Planning
- AI Planning Council determines adaptation strategy for each level
- Creates outline for all 8 versions
- Duration: 10-15 minutes

#### STEP 3-10: Level-Specific Adaptation (Parallel)
- Each reading level adapted simultaneously
- 5 AI models per level
- Content rewritten, vocabulary adjusted, examples modified
- Duration: 30-45 minutes (parallel for all 8 levels)

#### STEP 11: Cross-Level Verification
- 8 AI models verify consistency across levels
- Ensure proper progression from simple to complex
- Verify no information loss
- Duration: 15-20 minutes

#### STEP 12: Mark Complete
- All 8 versions ready
- Enter Pipeline 3 queue

---

## Key Features

### Comprehensive Adaptation
- **ALL books** from Pipeline 1 adapted to **ALL 8 levels**
- 160 books created per subject (20 books × 8 levels)
- No book left behind

### Content Integrity
- **Zero information loss** - all concepts preserved
- Language simplified, NOT content
- Same learning objectives across all levels

### Reading Level Science
- **Flesch-Kincaid Grade Level** verification
- **Lexile Framework** compatibility
- **SMOG Index** validation
- **Coleman-Liau Index** checking

### Accessibility First
- Plain Language version for maximum accessibility
- Heavy visual support in simpler levels
- Multiple pathways to same knowledge

---

## Adaptation Rules

### Language Simplification
- **Sentence length** adjusted per level
- **Vocabulary** matched to target grade level
- **Technical terms** introduced gradually or defined
- **Examples** age/level appropriate

### Visual Support
- **More images** in simpler levels
- **Infographics** replace complex paragraphs
- **Diagrams** with progressive detail levels
- **Tables** for clear data presentation

### Content Organization
- **Chunking** smaller in simpler levels
- **Headings** more frequent for navigation
- **Summaries** at multiple points
- **Review questions** matched to level

---

## Quality Standards

### Reading Level Verification
- **Flesch-Kincaid** must match target grade level (±0.5 grades)
- **Multiple readability scores** verified
- **AI consensus** on appropriateness (80%+ agreement)

### Content Completeness
- **100% concept coverage** - nothing omitted
- **All learning objectives** achievable at every level
- **Cross-reference** between levels maintained

### Accessibility Compliance
- **WCAG AAA** maintained across all levels
- **Plain Language** principles applied
- **Universal Design** for Learning (UDL) principles

---

## Documentation Structure

```
/blueprints/pipeline_2_reading_level_adaptations/
│
├── PIPELINE_2_OVERVIEW.md (this file)
├── PIPELINE_2_COMPLETE_BLUEPRINT.md (to be created)
│
├── /format_specifications/
│   ├── elementary_format.json
│   ├── middle_school_format.json
│   ├── high_school_format.json
│   ├── college_format.json
│   ├── professional_format.json
│   ├── advanced_professional_format.json
│   ├── plain_language_format.json
│   └── quick_reference_format.json
│
├── /step_blueprints/
│   ├── step_01_source_analysis.json
│   ├── step_02_adaptation_planning.json
│   ├── step_03_elementary_adaptation.json
│   ├── step_04_middle_school_adaptation.json
│   ├── step_05_high_school_adaptation.json
│   ├── step_06_college_adaptation.json
│   ├── step_07_professional_adaptation.json
│   ├── step_08_advanced_professional_adaptation.json
│   ├── step_09_plain_language_adaptation.json
│   ├── step_10_quick_reference_adaptation.json
│   ├── step_11_cross_level_verification.json
│   └── step_12_mark_complete.json
│
├── /adaptation_rules/
│   ├── vocabulary_guidelines.json
│   ├── sentence_structure_rules.json
│   ├── readability_targets.json
│   └── visual_support_requirements.json
│
├── /ai_model_assignments/
│   └── all_model_assignments.json
│
├── /worker_configurations/
│   └── complete_worker_config.json
│
└── /quality_thresholds/
    └── all_thresholds.json
```

---

## Database Storage

All blueprints stored in Supabase:
- `generation_blueprints` - Pipeline 2 registry
- `format_specifications` - 8 reading level formats
- `step_blueprints` - 12 adaptation steps
- `adaptation_rules` - Language/vocabulary rules
- `ai_model_configurations` - AI assignments
- `worker_configurations` - Worker pools
- `quality_thresholds` - Readability standards

---

## Scaling Numbers

### Per Subject:
- **Input:** 20 books from Pipeline 1
- **Output:** 160 books (20 × 8 levels)
- **Total Time:** 40-80 hours (highly parallelized)
- **Total Cost:** $300-600

### System-Wide (24 subject groups):
- **Input:** ~480 books from Pipeline 1
- **Output:** ~3,840 books (480 × 8 levels)
- **Timeline:** Weeks (with parallelization)
- **Cost:** $7,200-14,400

---

## Next Steps

1. Review this overview
2. Create complete Pipeline 2 blueprint
3. Create all format specifications (8 files)
4. Create all step blueprints (12 files)
5. Create adaptation rules (4 files)
6. Populate Supabase tables
7. Move to Pipeline 3

---

## Version History
- v1.0 (2024-12-02): Initial Pipeline 2 overview
