# Activity Packs - Complete Feature Specification

**Version**: 1.0
**Status**: Draft - Awaiting Approval
**Feature ID**: ADDON-001
**Category**: Student Learning Materials
**Complexity**: High
**Created**: 2024-12-19

---

## TABLE OF CONTENTS

1. [Overview](#1-overview)
2. [Purpose & Context](#2-purpose--context)
3. [Technical Requirements](#3-technical-requirements)
4. [Input Schema](#4-input-schema)
5. [Output Schema](#5-output-schema)
6. [AI Model Orchestration](#6-ai-model-orchestration)
7. [Complete AI Prompts](#7-complete-ai-prompts)
8. [Code Examples](#8-code-examples)
9. [Testing Requirements](#9-testing-requirements)
10. [Cost Analysis](#10-cost-analysis)
11. [Implementation Timeline](#11-implementation-timeline)
12. [Approval Status](#12-approval-status)

---

## 1. OVERVIEW

### 1.1 What It Does

Generates comprehensive, pedagogically-sound activity packs that transform book content into hands-on, interactive learning experiences. Each pack contains 15-30 diverse activities spanning multiple learning modalities (visual, kinesthetic, auditory, reading/writing) and Bloom's Taxonomy levels.

### 1.2 Why It Exists

**Problem**: Students need diverse ways to engage with content beyond reading. Different learners need different activity types. Teachers need ready-to-use materials that don't require hours of prep time.

**Solution**: AI-generated activity packs that:
- Match content to appropriate activity types
- Scale difficulty based on reading level
- Adapt for different disabilities
- Include all necessary materials/instructions
- Align with educational standards

### 1.3 Key Differentiators

1. **Disability-aware**: Every activity includes accessibility modifications
2. **Multi-modal**: Covers all 4 learning styles (VARK model)
3. **Scaffolded**: Activities progress from simple to complex
4. **Complete**: Includes materials, instructions, rubrics, and answer keys
5. **Adaptable**: Can be modified for different age groups and abilities

---

## 2. PURPOSE & CONTEXT

### 2.1 Use Cases

#### Primary Use Cases

**1. Classroom Teachers**
- **Need**: Ready-to-use activities for entire class
- **Benefit**: 10+ hours of prep time saved per unit
- **Output**: Printable activity sheets with full instructions

**2. Homeschool Parents**
- **Need**: Engaging activities for different ages
- **Benefit**: Professional-quality materials without education degree
- **Output**: Age-appropriate activities with clear guidance

**3. Special Education Teachers**
- **Need**: Modified activities for diverse abilities
- **Benefit**: Pre-adapted materials for multiple disabilities
- **Output**: Activities with built-in accommodations

**4. After-School Programs**
- **Need**: Educational but fun activities
- **Benefit**: Structured learning disguised as engagement
- **Output**: Low-prep, high-engagement activities

#### Secondary Use Cases

5. **Tutors**: Supplementary practice materials
6. **Libraries**: Community learning programs
7. **Summer Camps**: Educational enrichment activities
8. **Virtual Learning**: Remote-friendly activity formats

### 2.2 Business Value

#### Direct Revenue
- **Premium Add-on**: $4.99-$9.99 per activity pack
- **Bundle Pricing**: $19.99 for 5-pack, $34.99 for 10-pack
- **Subscription Upsell**: Include in "Educator Plus" tier

#### Market Differentiation
- Competitors offer generic worksheets
- We offer disability-adapted, multi-modal activity systems
- Estimated market: 3.2M teachers × $50/year = $160M TAM

#### Customer Retention
- High engagement = higher renewal rates
- Activities encourage repeated book purchases
- Parent satisfaction drives word-of-mouth growth

---

## 3. TECHNICAL REQUIREMENTS

### 3.1 Dependencies

#### AI Models Required

```typescript
{
  // Primary content generation
  "content_creation": "claude-3-5-sonnet-20241022",

  // Activity ideation (fast, creative)
  "activity_brainstorming": "gpt-4o",

  // Disability adaptation
  "accessibility_modification": "claude-3-5-sonnet-20241022",

  // Quality verification
  "quality_check": "gemini-2.0-flash-exp",

  // Fallbacks
  "fallback_content": "gpt-4o",
  "fallback_verification": "claude-3-5-haiku-20241022"
}
```

#### External APIs
- **Image Generation**: DALL-E 3 (optional illustrations)
- **Document Formatting**: Server-side PDF generation
- **Font Services**: Google Fonts API (dyslexia-friendly fonts)

#### Database Tables
- `addon_features` - Feature definitions
- `addon_content` - Generated activity packs
- `addon_templates` - Reusable activity templates
- `activity_types` - Master list of activity categories
- `learning_standards` - Educational standards mapping

#### Processing Requirements
- **CPU**: Moderate (PDF generation)
- **Memory**: 512MB per generation job
- **Storage**: 2-5MB per activity pack (with images)
- **Generation Time**: 4-8 minutes per pack

---

## 4. INPUT SCHEMA

### 4.1 Complete TypeScript Interface

```typescript
interface ActivityPackRequest {
  // REQUIRED FIELDS
  book_id: string; // UUID of source book

  content_scope: 'full_book' | 'chapter' | 'section' | 'concept';

  target_audience: {
    age_range: {
      min_age: number; // 5-18
      max_age: number; // 5-18
    };
    reading_level: 'elementary' | 'middle_school' | 'high_school' | 'college';
    grade_levels: string[]; // e.g., ['5th', '6th', '7th']
  };

  activity_preferences: {
    total_activities: number; // 10-50, default 20

    difficulty_distribution: {
      easy: number; // percentage
      medium: number; // percentage
      hard: number; // percentage
    };

    blooms_taxonomy_coverage: Array<
      'remember' | 'understand' | 'apply' |
      'analyze' | 'evaluate' | 'create'
    >;
  };

  // OPTIONAL FIELDS
  learning_modalities?: {
    visual: number; // percentage, default 25
    auditory: number; // percentage, default 20
    reading_writing: number; // percentage, default 30
    kinesthetic: number; // percentage, default 25
  };

  activity_types_include?: ActivityType[];
  activity_types_exclude?: ActivityType[];

  time_constraints?: {
    min_minutes: number; // default 5
    max_minutes: number; // default 45
    total_time_budget?: number; // total minutes for all activities
  };

  disability_adaptations?: DisabilityType[];

  materials_constraints?: {
    no_special_materials: boolean; // default false
    budget_per_student?: number; // USD
    printable_only: boolean; // default false
  };

  standards_alignment?: {
    framework: 'common_core' | 'ngss' | 'state_standards' | 'ib' | 'ap';
    specific_standards?: string[]; // e.g., ["CCSS.ELA-LITERACY.RI.6.1"]
  };

  output_format_preferences?: {
    include_answer_keys: boolean; // default true
    include_rubrics: boolean; // default true
    include_teacher_notes: boolean; // default true
    include_extensions: boolean; // default true
    language: string; // default "en-US"
    color_vs_bw: 'color' | 'black_and_white' | 'both'; // default 'both'
  };

  customization?: {
    school_name?: string;
    teacher_name?: string;
    class_name?: string;
    term?: string;
    custom_instructions?: string; // max 1000 chars
  };
}

type ActivityType =
  | 'word_search'
  | 'crossword'
  | 'matching'
  | 'fill_in_blank'
  | 'short_answer'
  | 'essay'
  | 'diagram_labeling'
  | 'timeline_creation'
  | 'concept_mapping'
  | 'role_play_scenario'
  | 'debate_prep'
  | 'research_project'
  | 'creative_writing'
  | 'art_project'
  | 'science_experiment'
  | 'math_problem_solving'
  | 'coding_challenge'
  | 'physical_activity'
  | 'music_creation'
  | 'game_design';

type DisabilityType =
  | 'dyslexia'
  | 'adhd'
  | 'autism_level1'
  | 'autism_level2'
  | 'autism_level3'
  | 'blind_low_vision'
  | 'deaf_hard_of_hearing'
  | 'motor_impairment'
  | 'intellectual_disability'
  | 'anxiety_disorders'
  | 'dyscalculia'
  | 'dysgraphia';
```

### 4.2 JSON Schema Example

```json
{
  "book_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "content_scope": "chapter",
  "target_audience": {
    "age_range": {
      "min_age": 10,
      "max_age": 12
    },
    "reading_level": "middle_school",
    "grade_levels": ["5th", "6th", "7th"]
  },
  "activity_preferences": {
    "total_activities": 20,
    "difficulty_distribution": {
      "easy": 30,
      "medium": 50,
      "hard": 20
    },
    "blooms_taxonomy_coverage": [
      "understand",
      "apply",
      "analyze"
    ]
  },
  "disability_adaptations": [
    "dyslexia",
    "adhd"
  ],
  "standards_alignment": {
    "framework": "common_core",
    "specific_standards": [
      "CCSS.ELA-LITERACY.RI.6.1",
      "CCSS.ELA-LITERACY.W.6.2"
    ]
  }
}
```

### 4.3 Validation Rules

```typescript
function validateActivityPackRequest(request: ActivityPackRequest): ValidationResult {
  const errors: string[] = [];

  // Age range validation
  if (request.target_audience.age_range.min_age < 5 ||
      request.target_audience.age_range.min_age > 18) {
    errors.push('min_age must be between 5 and 18');
  }

  if (request.target_audience.age_range.max_age <
      request.target_audience.age_range.min_age) {
    errors.push('max_age must be >= min_age');
  }

  // Activity count validation
  if (request.activity_preferences.total_activities < 10 ||
      request.activity_preferences.total_activities > 50) {
    errors.push('total_activities must be between 10 and 50');
  }

  // Difficulty distribution must sum to 100
  const diffSum =
    request.activity_preferences.difficulty_distribution.easy +
    request.activity_preferences.difficulty_distribution.medium +
    request.activity_preferences.difficulty_distribution.hard;

  if (diffSum !== 100) {
    errors.push('difficulty_distribution must sum to 100%');
  }

  // Learning modalities must sum to 100 (if provided)
  if (request.learning_modalities) {
    const modalitySum =
      request.learning_modalities.visual +
      request.learning_modalities.auditory +
      request.learning_modalities.reading_writing +
      request.learning_modalities.kinesthetic;

    if (modalitySum !== 100) {
      errors.push('learning_modalities must sum to 100%');
    }
  }

  return {
    valid: errors.length === 0,
    errors
  };
}
```

---

## 5. OUTPUT SCHEMA

### 5.1 Complete TypeScript Interface

```typescript
interface ActivityPackOutput {
  metadata: {
    pack_id: string; // UUID
    source_book_id: string; // UUID
    generation_date: string; // ISO timestamp
    version: string;
    total_activities: number;
    estimated_total_time_minutes: number;
    difficulty_profile: {
      easy_count: number;
      medium_count: number;
      hard_count: number;
    };
    standards_covered: string[];
  };

  pack_overview: {
    title: string;
    subtitle: string;
    description: string;
    learning_objectives: string[];
    prerequisite_knowledge: string[];
    materials_needed: {
      required: string[];
      optional: string[];
    };
  };

  activities: Activity[];

  supplementary_materials: {
    vocabulary_list: VocabularyTerm[];
    suggested_sequence: DailySequence[];
    assessment_tools: AssessmentTools;
    parent_letter: string;
  };

  files_generated: {
    pdf_files: GeneratedFile[];
    editable_formats: GeneratedFile[];
  };

  quality_metrics: QualityMetrics;
}

interface Activity {
  activity_id: string;
  activity_number: number;
  title: string;
  activity_type: ActivityType;

  category: 'warmup' | 'core_learning' | 'practice' |
           'application' | 'extension' | 'assessment' |
           'review' | 'enrichment';

  difficulty_level: 'easy' | 'medium' | 'hard';
  blooms_level: BloomsLevel;
  learning_modality: 'visual' | 'auditory' | 'reading_writing' | 'kinesthetic';

  estimated_time_minutes: number;
  individual_or_group: 'individual' | 'pairs' | 'small_group' |
                       'whole_class' | 'flexible';

  learning_objectives: string[];
  standards_addressed: string[];

  materials_needed: Material[];

  preparation: {
    teacher_prep_time_minutes: number;
    prep_instructions: string[];
    printables_needed: string[];
  };

  instructions: {
    student_instructions: InstructionStep[];
    teacher_notes: string[];
    teaching_tips: string[];
  };

  content: ActivityContent; // Type varies by activity type

  assessment: {
    answer_key: any; // Structure varies by activity type
    rubric: Rubric;
    self_assessment: string[];
  };

  differentiation: {
    scaffolding: string[];
    extensions: string[];
    modifications_by_disability: {
      [key in DisabilityType]?: string[];
    };
  };

  connections: {
    real_world_applications: string[];
    cross_curricular_links: CrossCurricularLink[];
    home_connection: string;
  };

  digital_resources: DigitalResource[];
}

interface InstructionStep {
  step_number: number;
  instruction: string;
  time_estimate: number;
  visual_aid?: string; // URL or description
}

interface Material {
  item: string;
  quantity_per_student: string;
  optional: boolean;
}

interface Rubric {
  criteria: RubricCriterion[];
  total_points: number;
}

interface RubricCriterion {
  criterion: string;
  exemplary: string;
  proficient: string;
  developing: string;
  beginning: string;
  points: number;
}

interface VocabularyTerm {
  term: string;
  definition: string;
  example_sentence: string;
}

interface DailySequence {
  day: number;
  activities: string[]; // activity IDs
  notes: string;
}

interface AssessmentTools {
  pre_assessment: any;
  formative_assessments: any[];
  summative_assessment: any;
}

interface GeneratedFile {
  file_name: string;
  file_type: string;
  file_size_bytes: number;
  storage_url: string;
  page_count?: number;
  description: string;
}

interface QualityMetrics {
  pedagogical_alignment_score: number; // 0-100
  accessibility_score: number; // 0-100
  diversity_score: number; // 0-100
  validation_checks_passed: string[];
  warnings: string[];
}

interface CrossCurricularLink {
  subject: string;
  connection: string;
}

interface DigitalResource {
  resource_type: string;
  url: string;
  description: string;
  required_vs_optional: 'required' | 'optional';
}

type BloomsLevel = 'remember' | 'understand' | 'apply' |
                   'analyze' | 'evaluate' | 'create';
```

### 5.2 Example Output (Abbreviated)

```json
{
  "metadata": {
    "pack_id": "550e8400-e29b-41d4-a716-446655440000",
    "source_book_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    "generation_date": "2024-12-19T10:30:00Z",
    "version": "1.0",
    "total_activities": 20,
    "estimated_total_time_minutes": 540,
    "difficulty_profile": {
      "easy_count": 6,
      "medium_count": 10,
      "hard_count": 4
    },
    "standards_covered": [
      "CCSS.ELA-LITERACY.RI.6.1",
      "CCSS.ELA-LITERACY.W.6.2"
    ]
  },
  "pack_overview": {
    "title": "Water Cycle Exploration Activity Pack",
    "subtitle": "20 Hands-On Activities for Middle School Science",
    "description": "Engage students with the water cycle through diverse, multi-modal activities...",
    "learning_objectives": [
      "Students will identify and describe the four stages of the water cycle",
      "Students will explain how water moves between stages",
      "Students will recognize the water cycle in everyday life"
    ],
    "prerequisite_knowledge": [
      "Basic understanding of states of matter (solid, liquid, gas)",
      "Familiarity with weather concepts"
    ],
    "materials_needed": {
      "required": [
        "Paper (various colors)",
        "Markers/colored pencils",
        "Scissors",
        "Tape or glue",
        "Access to water"
      ],
      "optional": [
        "Plastic bags",
        "Ice cubes",
        "Food coloring"
      ]
    }
  },
  "activities": [
    {
      "activity_id": "act_001",
      "activity_number": 1,
      "title": "Water Cycle Comic Strip",
      "activity_type": "creative_writing",
      "category": "core_learning",
      "difficulty_level": "medium",
      "blooms_level": "apply",
      "learning_modality": "visual",
      "estimated_time_minutes": 30,
      "individual_or_group": "individual",
      "learning_objectives": [
        "Students will sequence the stages of the water cycle correctly",
        "Students will explain each stage in their own words"
      ],
      "standards_addressed": [
        "NGSS.MS-ESS2-4"
      ],
      "materials_needed": [
        {
          "item": "White paper (8.5x11)",
          "quantity_per_student": "1 sheet",
          "optional": false
        },
        {
          "item": "Colored pencils or markers",
          "quantity_per_student": "1 set",
          "optional": false
        },
        {
          "item": "Ruler",
          "quantity_per_student": "1",
          "optional": true
        }
      ],
      "preparation": {
        "teacher_prep_time_minutes": 5,
        "prep_instructions": [
          "Review comic strip examples",
          "Prepare sample to show students",
          "Set up materials station"
        ],
        "printables_needed": [
          "Comic strip template (optional)",
          "Water cycle vocabulary list"
        ]
      },
      "instructions": {
        "student_instructions": [
          {
            "step_number": 1,
            "instruction": "Divide your paper into 6 equal panels (2 rows of 3)",
            "time_estimate": 3,
            "visual_aid": "diagram showing 6-panel layout"
          },
          {
            "step_number": 2,
            "instruction": "In panel 1, draw water in the ocean. Label it 'Collection'",
            "time_estimate": 4
          },
          {
            "step_number": 3,
            "instruction": "In panel 2, draw the sun heating the water. Show water vapor rising. Label it 'Evaporation'",
            "time_estimate": 5
          }
          // ... more steps
        ],
        "teacher_notes": [
          "Circulate to ensure students understand each stage",
          "Ask guiding questions: 'What happens to water when the sun heats it?'",
          "Check for common misconception: water 'disappearing' vs. changing state"
        ],
        "teaching_tips": [
          "Show a completed example but encourage creativity",
          "Allow students to add extra panels for more detail",
          "Consider pairing students who finish early to peer review"
        ]
      },
      "content": {
        "description": "Students create a 6-panel comic strip showing water's journey",
        "required_elements": [
          "All 4 stages present (evaporation, condensation, precipitation, collection)",
          "Clear labels for each stage",
          "Accurate representation of process",
          "Captions explaining what's happening"
        ]
      },
      "assessment": {
        "answer_key": {
          "key_elements": [
            "Panel showing ocean/lake/river water",
            "Panel showing evaporation with vapor rising",
            "Panel showing condensation forming clouds",
            "Panel showing precipitation (rain/snow/etc)",
            "Panel showing water returning to collection point",
            "All stages correctly labeled"
          ]
        },
        "rubric": {
          "criteria": [
            {
              "criterion": "Accuracy of Water Cycle Stages",
              "exemplary": "All 4 stages accurately depicted with scientifically correct processes shown",
              "proficient": "All 4 stages present with minor inaccuracies in depiction",
              "developing": "3 stages present or stages shown with significant inaccuracies",
              "beginning": "Fewer than 3 stages or major misconceptions evident",
              "points": 4
            },
            {
              "criterion": "Labels and Explanations",
              "exemplary": "All stages labeled correctly with clear, detailed captions",
              "proficient": "All stages labeled with adequate captions",
              "developing": "Most stages labeled but captions lack detail",
              "beginning": "Few or no labels; minimal explanation",
              "points": 3
            },
            {
              "criterion": "Visual Quality",
              "exemplary": "Clear, organized, easy to follow; creative and engaging",
              "proficient": "Clear and organized; adequate visual representation",
              "developing": "Somewhat unclear or disorganized",
              "beginning": "Difficult to follow or incomplete",
              "points": 3
            }
          ],
          "total_points": 10
        },
        "self_assessment": [
          "Did I include all 4 stages of the water cycle?",
          "Did I label each stage correctly?",
          "Can someone else understand my comic without me explaining it?",
          "Did I show how water moves from one stage to the next?"
        ]
      },
      "differentiation": {
        "scaffolding": [
          "Provide pre-divided comic strip template",
          "Give word bank with stage names",
          "Show multiple examples before starting",
          "Allow tracing or use of clipart instead of drawing",
          "Provide sentence starters for captions"
        ],
        "extensions": [
          "Add panels showing the role of temperature",
          "Include a panel showing human water use",
          "Create a second comic showing the cycle in a different environment",
          "Add scientific vocabulary (e.g., transpiration, sublimation)",
          "Make a mini flip-book version"
        ],
        "modifications_by_disability": {
          "dyslexia": [
            "Provide comic strip with stage names already printed in dyslexia-friendly font",
            "Allow audio recording of captions instead of writing",
            "Use color coding for each stage",
            "Extended time for completing captions"
          ],
          "adhd": [
            "Break into two sessions (drawing, then captions)",
            "Provide fidget tools during planning phase",
            "Use timer to show progress through steps",
            "Allow movement breaks between panels",
            "Minimize visual distractions on template"
          ],
          "autism_level1": [
            "Provide detailed example to follow",
            "Show exactly what each panel should contain",
            "Use checklist for required elements",
            "Allow use of computer for captions if handwriting is stressful"
          ],
          "blind_low_vision": [
            "Create tactile version with raised materials",
            "Verbal description activity instead of drawing",
            "Use large print labels (18pt+)",
            "High contrast materials (black on yellow)"
          ],
          "motor_impairment": [
            "Use adaptive scissors or pre-cut panels",
            "Allow digital creation (PowerPoint, Google Slides)",
            "Provide pre-drawn images to arrange and label",
            "Offer scribe for captions",
            "Larger spaces for drawing"
          ]
        }
      },
      "connections": {
        "real_world_applications": [
          "Weather forecasting uses water cycle knowledge",
          "Water treatment plants manage parts of the cycle",
          "Farmers rely on understanding precipitation patterns",
          "Climate scientists study changes in the water cycle"
        ],
        "cross_curricular_links": [
          {
            "subject": "Art",
            "connection": "Comic strip creation, visual storytelling techniques"
          },
          {
            "subject": "Language Arts",
            "connection": "Sequencing, cause-and-effect writing, using scientific vocabulary"
          },
          {
            "subject": "Math",
            "connection": "Dividing paper into equal sections, measuring panels"
          }
        ],
        "home_connection": "Observe and draw the water cycle you see at home this week. Where do you see evaporation? Condensation? Share your observations with your family."
      },
      "digital_resources": [
        {
          "resource_type": "Video",
          "url": "https://example.com/water-cycle-basics",
          "description": "3-minute animated water cycle explanation",
          "required_vs_optional": "optional"
        },
        {
          "resource_type": "Interactive",
          "url": "https://example.com/water-cycle-game",
          "description": "Drag-and-drop water cycle game",
          "required_vs_optional": "optional"
        }
      ]
    }
    // ... 19 more activities
  ],
  "supplementary_materials": {
    "vocabulary_list": [
      {
        "term": "Evaporation",
        "definition": "The process by which water changes from liquid to gas",
        "example_sentence": "Evaporation happens when the sun heats water in the ocean."
      },
      {
        "term": "Condensation",
        "definition": "The process by which water vapor changes to liquid water",
        "example_sentence": "Condensation forms clouds when water vapor cools in the sky."
      }
      // ... more terms
    ],
    "suggested_sequence": [
      {
        "day": 1,
        "activities": ["act_001", "act_002", "act_003"],
        "notes": "Start with visual activities to introduce concepts"
      },
      {
        "day": 2,
        "activities": ["act_004", "act_005"],
        "notes": "Hands-on experiments to deepen understanding"
      }
      // ... more days
    ],
    "assessment_tools": {
      "pre_assessment": {
        "type": "KWL Chart",
        "description": "What do students Know, Want to know, and Learned about water cycle"
      },
      "formative_assessments": [
        {
          "activity_id": "act_001",
          "assessment_type": "Comic strip rubric"
        },
        {
          "activity_id": "act_005",
          "assessment_type": "Lab report"
        }
      ],
      "summative_assessment": {
        "type": "Water Cycle Project",
        "description": "Students choose from 3 project options to demonstrate mastery"
      }
    },
    "parent_letter": "Dear Families,\n\nThis week we're exploring the water cycle through hands-on activities...\n\n[Full letter content]"
  },
  "files_generated": {
    "pdf_files": [
      {
        "file_name": "Water_Cycle_Activity_Pack_Complete.pdf",
        "file_type": "application/pdf",
        "file_size_bytes": 2458000,
        "storage_url": "https://storage.example.com/packs/550e8400/complete.pdf",
        "page_count": 87,
        "description": "Complete activity pack with all 20 activities, answer keys, and rubrics"
      },
      {
        "file_name": "Water_Cycle_Student_Worksheets.pdf",
        "file_type": "application/pdf",
        "file_size_bytes": 1205000,
        "storage_url": "https://storage.example.com/packs/550e8400/worksheets.pdf",
        "page_count": 42,
        "description": "Student-facing worksheets only (no answer keys)"
      },
      {
        "file_name": "Water_Cycle_Teacher_Guide.pdf",
        "file_type": "application/pdf",
        "file_size_bytes": 890000,
        "storage_url": "https://storage.example.com/packs/550e8400/teacher-guide.pdf",
        "page_count": 31,
        "description": "Teacher notes, answer keys, and rubrics"
      }
    ],
    "editable_formats": [
      {
        "file_name": "Water_Cycle_Activity_Pack.docx",
        "file_type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "file_size_bytes": 1850000,
        "storage_url": "https://storage.example.com/packs/550e8400/pack.docx",
        "description": "Editable Word document version"
      }
    ]
  },
  "quality_metrics": {
    "pedagogical_alignment_score": 92,
    "accessibility_score": 88,
    "diversity_score": 95,
    "validation_checks_passed": [
      "All learning objectives addressed",
      "Bloom's taxonomy distribution met",
      "Disability adaptations complete",
      "Materials are accessible",
      "Time estimates realistic",
      "Rubrics include measurable criteria",
      "Instructions are clear and sequential"
    ],
    "warnings": [
      "Activity #14 may require additional supervision for younger students"
    ]
  }
}
```

---

## 6. AI MODEL ORCHESTRATION

### 6.1 Generation Pipeline Flow

```
Phase 1: Content Analysis (5-10 seconds)
┌─────────────────────────────────────────┐
│ Model: Claude-3-5-Sonnet                │
│ Task: Analyze book content              │
│ Output: Concept map, difficulty levels  │
│ Fallback: GPT-4o                        │
└─────────────────────────────────────────┘
                  ↓
Phase 2: Activity Ideation (15-25 seconds)
┌─────────────────────────────────────────┐
│ Model: GPT-4o (creative generation)     │
│ Task: Generate 30-40 activity ideas     │
│ Output: Diverse activity concepts       │
│ Fallback: Claude-3-5-Sonnet             │
└─────────────────────────────────────────┘
                  ↓
Phase 3: Selection & Prioritization (5 seconds)
┌─────────────────────────────────────────┐
│ Model: Gemini-2.0-Flash-Exp             │
│ Task: Filter and rank activities        │
│ Output: Best 20 activities ranked       │
│ Fallback: Claude-3-5-Haiku              │
└─────────────────────────────────────────┘
                  ↓
Phase 4: Detailed Development (90-180 seconds)
┌─────────────────────────────────────────┐
│ PARALLEL: 3-5 activities at a time      │
│ Model: Claude-3-5-Sonnet                │
│ Task: Complete activity with all parts  │
│ Output: Full activities                 │
│ Fallback: GPT-4o                        │
└─────────────────────────────────────────┘
                  ↓
Phase 5: Disability Adaptation (30-60 seconds)
┌─────────────────────────────────────────┐
│ Model: Claude-3-5-Sonnet                │
│ Task: Add disability modifications      │
│ Output: Activities with accommodations  │
│ Fallback: GPT-4o-mini                   │
└─────────────────────────────────────────┘
                  ↓
Phase 6: Answer Keys & Rubrics (20-40 seconds)
┌─────────────────────────────────────────┐
│ Model: Claude-3-5-Sonnet                │
│ Task: Create answers and scoring guides │
│ Output: Complete assessment materials   │
│ Fallback: GPT-4o                        │
└─────────────────────────────────────────┘
                  ↓
Phase 7: Quality Verification (10-15 seconds)
┌─────────────────────────────────────────┐
│ Model: Gemini-2.0-Flash-Exp             │
│ Task: Verify quality standards          │
│ Output: Quality score, issues list      │
│ Fallback: Claude-3-5-Haiku              │
└─────────────────────────────────────────┘
                  ↓
Phase 8: File Generation (20-30 seconds)
┌─────────────────────────────────────────┐
│ System: PDF/DOCX generation             │
│ Task: Create formatted documents        │
│ Output: PDF files, editable documents   │
└─────────────────────────────────────────┘

Total Time: 4-8 minutes per activity pack
```

### 6.2 Model Selection Rationale

**Claude-3-5-Sonnet** (Primary workhorse)
- Excellent at structured content
- Strong instruction writing
- Good at following complex requirements
- Reliable for educational content

**GPT-4o** (Creative ideation)
- Best for brainstorming diverse ideas
- Strong at generating variety
- Good fallback for Claude

**Gemini-2.0-Flash-Exp** (Fast verification)
- Very fast (low latency)
- Good at quality checking
- Cost-effective for validation

**Claude-3-5-Haiku** (Fast fallback)
- Quick response times
- Lower cost
- Adequate quality for simple tasks

---

## 7. COMPLETE AI PROMPTS

### 7.1 Phase 1: Content Analysis Prompt

````markdown
# ROLE
You are an expert educational content analyst specializing in extracting learning objectives and key concepts from educational materials.

# TASK
Analyze the provided book content and create a comprehensive concept map that will guide activity creation.

# INPUT DATA
- Book Title: {{book_title}}
- Subject Area: {{subject}}
- Target Grade Level: {{grade_level}}
- Content Scope: {{scope}}
- Book Content: {{content_text}}

# ANALYSIS REQUIREMENTS

## 1. Key Concepts Extraction
Identify and categorize all major concepts:
- Primary concepts (must-know)
- Secondary concepts (should-know)
- Tertiary concepts (nice-to-know)
- Prerequisite concepts (assumed knowledge)

## 2. Learning Objectives
For each key concept, generate:
- Knowledge objectives (what students should know)
- Skill objectives (what students should be able to do)
- Application objectives (how students will use this)

## 3. Difficulty Assessment
Evaluate each concept:
- Cognitive complexity (1-5 scale)
- Abstract vs. concrete
- Prior knowledge required
- Common misconceptions

## 4. Activity Potential Analysis
For each concept, identify:
- Which learning modalities suit it best
- Which activity types would work well
- Real-world applications
- Cross-curricular connections

## 5. Vocabulary Analysis
Extract and categorize:
- Tier 1 vocabulary (common words)
- Tier 2 vocabulary (academic words)
- Tier 3 vocabulary (domain-specific terms)

# OUTPUT FORMAT
```json
{
  "content_analysis": {
    "key_concepts": [
      {
        "concept_id": "string",
        "concept_name": "string",
        "category": "primary|secondary|tertiary",
        "description": "string",
        "cognitive_complexity": 1-5,
        "bloom_levels_applicable": ["remember", "understand", "apply"],
        "best_modalities": ["visual", "kinesthetic"],
        "suggested_activity_types": ["experiment", "diagram"],
        "real_world_connections": ["weather forecasting"],
        "common_misconceptions": ["water disappears"],
        "prerequisite_concepts": ["states of matter"]
      }
    ],
    "learning_objectives": {
      "knowledge_objectives": ["Students will know..."],
      "skill_objectives": ["Students will be able to..."],
      "application_objectives": ["Students will apply..."]
    },
    "vocabulary": {
      "tier_1": [{"word": "rain", "context": "..."}],
      "tier_2": [{"word": "process", "definition": "..."}],
      "tier_3": [{"word": "evaporation", "definition": "...", "importance": "high"}]
    },
    "content_structure": {
      "main_topics": ["Water Cycle Basics", "Types of Precipitation"],
      "topic_relationships": [{"topic_a": "Evaporation", "relationship": "precedes", "topic_b": "Condensation"}],
      "narrative_flow": "Introduction → Processes → Applications"
    }
  }
}
```

# BEGIN ANALYSIS
````

---

### 7.2 Phase 2: Activity Ideation Prompt

````markdown
# ROLE
You are a creative educator with 15+ years of experience creating engaging learning activities. You excel at generating diverse, innovative activities that appeal to different learning styles.

# TASK
Generate 30-40 diverse, high-quality activity ideas based on the content analysis provided.

# INPUT DATA
Content Analysis: {{content_analysis}}
Target Age: {{min_age}}-{{max_age}}
Total Activities Needed: {{total_activities}}
Difficulty Distribution: {{easy}}% easy, {{medium}}% medium, {{hard}}% hard
Required Bloom's Levels: {{blooms_levels}}

# GENERATION GUIDELINES

## Diversity Requirements
Generate activities across:
- Paper-based (20-30%): worksheets, organizers, journals
- Interactive (15-25%): games, role-plays, simulations
- Creative (15-20%): art, writing, design
- Collaborative (10-20%): discussions, group projects
- Technology (5-15%): research, multimedia
- Kinesthetic (10-15%): experiments, building

## Bloom's Taxonomy Balance
- Remember: 15-20%
- Understand: 25-30%
- Apply: 20-25%
- Analyze: 15-20%
- Evaluate: 10-15%
- Create: 10-15%

## Time Distribution
- Quick (5-15 min): 30%
- Standard (15-30 min): 50%
- Extended (30-45 min): 20%

## Engagement Factors
Each activity must have at least 2 of:
- Choice/autonomy
- Appropriate challenge
- Real-world connection
- Creativity opportunity
- Collaboration
- Movement
- Novelty

# ACTIVITY IDEA TEMPLATE
For each idea, provide:
```json
{
  "idea_id": "unique_id",
  "working_title": "Catchy title",
  "activity_type": "specific type",
  "one_sentence_description": "Clear description",
  "learning_objective": "What students will learn",
  "bloom_level": "understand",
  "modality": "visual",
  "difficulty": "medium",
  "estimated_time": 25,
  "grouping": "individual",
  "materials_needed_brief": ["paper", "markers"],
  "engagement_hooks": ["creative expression", "real-world relevance"],
  "key_concept_addressed": "evaporation",
  "innovation_factor": "What makes this unique",
  "potential_challenges": ["May need extra time"],
  "why_this_works": "Pedagogical rationale"
}
```

# CREATIVITY GUIDELINES

Do Generate:
✅ Activities making abstract concepts concrete
✅ Activities incorporating student interests
✅ Activities with clear products/outcomes
✅ Activities building on prior knowledge
✅ Activities with real-world relevance

Don't Generate:
❌ Busy work
❌ Activities requiring expensive materials
❌ Activities with unclear objectives
❌ Just textbook problems
❌ Culturally insensitive content

# BEGIN IDEATION
Generate 30-40 creative activity ideas now.
````

---

### 7.3 Phase 4: Detailed Activity Development Prompt

````markdown
# ROLE
You are a master teacher creating complete, ready-to-use classroom activities. Your activities are known for clarity, completeness, and effectiveness.

# TASK
Develop ONE complete activity with all necessary components, ready for immediate classroom use.

# INPUT DATA
Activity Concept: {{activity_idea}}
Book Content: {{book_content}}
Target Audience: Age {{min_age}}-{{max_age}}, {{reading_level}}
Standards: {{standards}}

# DEVELOPMENT REQUIREMENTS

## Required Components

### 1. Activity Header
```
Title: [Clear, engaging, descriptive]
Type: [Specific category]
Duration: [X-Y minutes]
Difficulty: [Easy/Medium/Hard]
Bloom's Level: [Specific level]
Modality: [Primary modality]
Grouping: [Individual/Pairs/Group/Class]
```

### 2. Learning Objectives (3-5 objectives)
Format: "By the end of this activity, you will be able to [verb] [object]"

Use appropriate Bloom's verbs:
- Remember: define, identify, list, recall
- Understand: describe, explain, summarize
- Apply: demonstrate, solve, use
- Analyze: compare, examine, categorize
- Evaluate: judge, critique, justify
- Create: design, compose, develop

### 3. Materials Needed
Required materials (with quantities):
- Item name (quantity per student) - cost
- Example: "White paper (1 sheet) - $0.02"

Optional materials:
- Enhancement items (purpose)

### 4. Teacher Preparation
Prep time: X minutes

Setup steps:
1. [Action with time]
2. [Action with time]

### 5. Step-by-Step Instructions

For EACH step:

**Step [X]: [Step Name] (X minutes)**

*What students do:*
[Clear, specific instructions in student-friendly language]

*What teachers do:*
[Teacher actions, monitoring tips, questions to ask]

*Success indicators:*
[How to know students are on track]

*Common issues & solutions:*
- Issue: [problem]
  Solution: [fix]

### 6. Assessment Components

**Answer Key:**
[Complete answers with explanations]

**Rubric:**
| Criterion | Exemplary (4) | Proficient (3) | Developing (2) | Beginning (1) |
|-----------|---------------|----------------|----------------|----------------|
| [Criterion 1] | [Specific descriptor] | [Specific descriptor] | [Specific descriptor] | [Specific descriptor] |

Total: __/12 points

**Self-Assessment:**
- [Reflection question 1]
- [Reflection question 2]

### 7. Differentiation

**Scaffolding (for struggling learners):**
- [Specific support 1]
- [Specific support 2]

**Extensions (for advanced learners):**
- [Challenge 1]
- [Challenge 2]

**Disability Modifications:**
- Dyslexia: [specific accommodations]
- ADHD: [specific accommodations]
- Autism: [specific accommodations]
- Visual Impairment: [specific accommodations]
- Hearing Impairment: [specific accommodations]
- Motor Impairment: [specific accommodations]

### 8. Connections

**Real-World Applications:**
- [How this is used in real life]

**Cross-Curricular Links:**
- Math: [connection]
- ELA: [connection]
- Arts: [connection]

**Home Connection:**
[Family activity description]

### 9. Teaching Tips
- Before: [preparation tips]
- During: [implementation tips]
- After: [follow-up tips]

# OUTPUT FORMAT
Provide complete activity in structured JSON matching the Activity interface.

# QUALITY STANDARDS
✅ Complete enough for immediate use
✅ Clear enough for substitute teacher
✅ Detailed enough for new teacher
✅ Flexible enough for expert teacher
✅ Inclusive for diverse learners
✅ Engaging for student buy-in
✅ Rigorous for learning gains

# BEGIN DEVELOPMENT
Create the complete activity now.
````

---

**(Continuing with remaining sections...)**

## 8. CODE EXAMPLES

### 8.1 Service Implementation

```typescript
// src/services/activityPackService.ts

import { supabase } from '../lib/supabase';
import { AIModelOrchestrator } from './aiOrchestrator';
import type { ActivityPackRequest, ActivityPackOutput } from '../types/activityPack';

export class ActivityPackService {
  private orchestrator: AIModelOrchestrator;

  constructor() {
    this.orchestrator = new AIModelOrchestrator();
  }

  async generateActivityPack(
    request: ActivityPackRequest,
    userId: string
  ): Promise<ActivityPackOutput> {
    // Validate request
    const validation = this.validateRequest(request);
    if (!validation.valid) {
      throw new Error(`Invalid request: ${validation.errors.join(', ')}`);
    }

    // Create generation job
    const jobId = await this.createJob(request, userId);

    try {
      // Phase 1: Content Analysis
      await this.updateJobProgress(jobId, 10, 'Analyzing content...');
      const contentAnalysis = await this.orchestrator.analyzeContent({
        bookId: request.book_id,
        scope: request.content_scope
      });

      // Phase 2: Activity Ideation
      await this.updateJobProgress(jobId, 30, 'Generating activity ideas...');
      const activityIdeas = await this.orchestrator.generateActivityIdeas({
        contentAnalysis,
        preferences: request.activity_preferences,
        targetAudience: request.target_audience
      });

      // Phase 3: Selection
      await this.updateJobProgress(jobId, 40, 'Selecting best activities...');
      const selectedActivities = await this.orchestrator.selectActivities({
        ideas: activityIdeas,
        requirements: request.activity_preferences
      });

      // Phase 4: Detailed Development (parallel)
      await this.updateJobProgress(jobId, 50, 'Developing activities...');
      const developedActivities = await this.developActivitiesParallel(
        selectedActivities,
        request,
        jobId
      );

      // Phase 5: Disability Adaptations
      if (request.disability_adaptations) {
        await this.updateJobProgress(jobId, 80, 'Adding adaptations...');
        await this.addDisabilityAdaptations(
          developedActivities,
          request.disability_adaptations
        );
      }

      // Phase 6: Assessments
      await this.updateJobProgress(jobId, 90, 'Creating assessments...');
      await this.generateAssessments(developedActivities);

      // Phase 7: Quality Check
      await this.updateJobProgress(jobId, 95, 'Verifying quality...');
      const qualityReport = await this.orchestrator.verifyQuality(developedActivities);

      if (qualityReport.overall_score < 80) {
        throw new Error(`Quality too low: ${qualityReport.overall_score}/100`);
      }

      // Phase 8: File Generation
      await this.updateJobProgress(jobId, 98, 'Generating files...');
      const files = await this.generateFiles(developedActivities, request);

      // Assemble output
      const output: ActivityPackOutput = {
        metadata: {
          pack_id: jobId,
          source_book_id: request.book_id,
          generation_date: new Date().toISOString(),
          version: '1.0',
          total_activities: developedActivities.length,
          estimated_total_time_minutes: developedActivities.reduce(
            (sum, act) => sum + act.estimated_time_minutes, 0
          ),
          difficulty_profile: this.calculateDifficultyProfile(developedActivities),
          standards_covered: this.extractStandards(developedActivities)
        },
        pack_overview: await this.generatePackOverview(developedActivities, request),
        activities: developedActivities,
        supplementary_materials: await this.generateSupplementaryMaterials(developedActivities),
        files_generated: files,
        quality_metrics: qualityReport
      };

      // Save to database
      await this.saveActivityPack(output, userId);

      // Mark job complete
      await this.updateJobProgress(jobId, 100, 'Complete!');

      return output;

    } catch (error) {
      await this.markJobFailed(jobId, error.message);
      throw error;
    }
  }

  private async developActivitiesParallel(
    selectedActivities: any[],
    request: ActivityPackRequest,
    jobId: string
  ) {
    const batchSize = 4; // Process 4 at a time
    const allActivities = [];

    for (let i = 0; i < selectedActivities.length; i += batchSize) {
      const batch = selectedActivities.slice(i, i + batchSize);

      const batchPromises = batch.map(activity =>
        this.orchestrator.developActivity({
          activityIdea: activity,
          request
        })
      );

      const batchResults = await Promise.all(batchPromises);
      allActivities.push(...batchResults);

      // Update progress
      const progress = 50 + Math.floor((i + batchSize) / selectedActivities.length * 30);
      await this.updateJobProgress(
        jobId,
        progress,
        `Developed ${Math.min(i + batchSize, selectedActivities.length)}/${selectedActivities.length} activities`
      );
    }

    return allActivities;
  }

  private validateRequest(request: ActivityPackRequest) {
    const errors: string[] = [];

    // Age validation
    if (request.target_audience.age_range.min_age < 5 ||
        request.target_audience.age_range.min_age > 18) {
      errors.push('min_age must be 5-18');
    }

    // Difficulty distribution must sum to 100
    const diffSum =
      request.activity_preferences.difficulty_distribution.easy +
      request.activity_preferences.difficulty_distribution.medium +
      request.activity_preferences.difficulty_distribution.hard;

    if (diffSum !== 100) {
      errors.push('difficulty_distribution must sum to 100');
    }

    return {
      valid: errors.length === 0,
      errors
    };
  }

  private async createJob(request: ActivityPackRequest, userId: string) {
    const { data, error } = await supabase
      .from('addon_generation_jobs')
      .insert({
        user_id: userId,
        addon_type: 'activity_pack',
        request_params: request,
        status: 'processing',
        progress: 0
      })
      .select('id')
      .single();

    if (error) throw error;
    return data.id;
  }

  private async updateJobProgress(jobId: string, progress: number, message: string) {
    await supabase
      .from('addon_generation_jobs')
      .update({
        progress,
        status_message: message,
        updated_at: new Date().toISOString()
      })
      .eq('id', jobId);
  }

  private async markJobFailed(jobId: string, errorMessage: string) {
    await supabase
      .from('addon_generation_jobs')
      .update({
        status: 'failed',
        error_message: errorMessage
      })
      .eq('id', jobId);
  }

  private calculateDifficultyProfile(activities: any[]) {
    return {
      easy_count: activities.filter(a => a.difficulty_level === 'easy').length,
      medium_count: activities.filter(a => a.difficulty_level === 'medium').length,
      hard_count: activities.filter(a => a.difficulty_level === 'hard').length
    };
  }

  private extractStandards(activities: any[]) {
    const standardsSet = new Set<string>();
    activities.forEach(activity => {
      activity.standards_addressed.forEach((std: string) => standardsSet.add(std));
    });
    return Array.from(standardsSet);
  }

  // Additional helper methods...
}
```

### 8.2 React Component

```typescript
// src/components/ActivityPackGenerator.tsx

import React, { useState } from 'react';
import { ActivityPackService } from '../services/activityPackService';
import type { ActivityPackRequest } from '../types/activityPack';

export const ActivityPackGenerator: React.FC<{ bookId: string }> = ({ bookId }) => {
  const [generating, setGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [statusMessage, setStatusMessage] = useState('');
  const [formData, setFormData] = useState({
    totalActivities: 20,
    readingLevel: 'middle_school' as const,
    disabilities: [] as string[]
  });

  const handleGenerate = async () => {
    setGenerating(true);
    setProgress(0);

    const request: ActivityPackRequest = {
      book_id: bookId,
      content_scope: 'chapter',
      target_audience: {
        age_range: { min_age: 10, max_age: 14 },
        reading_level: formData.readingLevel,
        grade_levels: ['5th', '6th', '7th', '8th']
      },
      activity_preferences: {
        total_activities: formData.totalActivities,
        difficulty_distribution: {
          easy: 30,
          medium: 50,
          hard: 20
        },
        blooms_taxonomy_coverage: ['understand', 'apply', 'analyze']
      },
      disability_adaptations: formData.disabilities.length > 0
        ? formData.disabilities
        : undefined
    };

    const service = new ActivityPackService();

    try {
      // Poll for progress updates
      const pollInterval = setInterval(async () => {
        const { data } = await supabase
          .from('addon_generation_jobs')
          .select('progress, status_message')
          .order('created_at', { ascending: false })
          .limit(1)
          .single();

        if (data) {
          setProgress(data.progress);
          setStatusMessage(data.status_message);
        }
      }, 1000);

      const result = await service.generateActivityPack(request, 'user-id');

      clearInterval(pollInterval);

      // Success!
      console.log('Activity pack generated:', result);
      alert('Activity pack generated successfully!');

    } catch (error) {
      console.error('Generation failed:', error);
      alert(`Generation failed: ${error.message}`);
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white rounded-lg shadow">
      <h2 className="text-2xl font-bold mb-6">Generate Activity Pack</h2>

      <div className="space-y-6">
        {/* Number of Activities */}
        <div>
          <label className="block text-sm font-medium mb-2">
            Number of Activities: {formData.totalActivities}
          </label>
          <input
            type="range"
            min="10"
            max="50"
            value={formData.totalActivities}
            onChange={(e) => setFormData({
              ...formData,
              totalActivities: parseInt(e.target.value)
            })}
            className="w-full"
            disabled={generating}
          />
          <div className="flex justify-between text-xs text-gray-500 mt-1">
            <span>10</span>
            <span>50</span>
          </div>
        </div>

        {/* Reading Level */}
        <div>
          <label className="block text-sm font-medium mb-2">
            Reading Level
          </label>
          <select
            value={formData.readingLevel}
            onChange={(e) => setFormData({
              ...formData,
              readingLevel: e.target.value as any
            })}
            className="w-full px-3 py-2 border rounded"
            disabled={generating}
          >
            <option value="elementary">Elementary (Grades 3-5)</option>
            <option value="middle_school">Middle School (Grades 6-8)</option>
            <option value="high_school">High School (Grades 9-12)</option>
            <option value="college">College/University</option>
          </select>
        </div>

        {/* Disability Adaptations */}
        <div>
          <label className="block text-sm font-medium mb-2">
            Disability Adaptations (Optional)
          </label>
          <div className="grid grid-cols-2 gap-2">
            {['Dyslexia', 'ADHD', 'Autism Level 1', 'Blind/Low Vision'].map(disability => (
              <label key={disability} className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={formData.disabilities.includes(disability.toLowerCase().replace(/\s+/g, '_'))}
                  onChange={(e) => {
                    const value = disability.toLowerCase().replace(/\s+/g, '_');
                    setFormData({
                      ...formData,
                      disabilities: e.target.checked
                        ? [...formData.disabilities, value]
                        : formData.disabilities.filter(d => d !== value)
                    });
                  }}
                  disabled={generating}
                  className="rounded"
                />
                <span className="text-sm">{disability}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Generate Button */}
        <button
          onClick={handleGenerate}
          disabled={generating}
          className={`w-full py-3 px-4 rounded font-medium ${
            generating
              ? 'bg-gray-400 cursor-not-allowed'
              : 'bg-blue-600 hover:bg-blue-700 text-white'
          }`}
        >
          {generating ? 'Generating...' : 'Generate Activity Pack'}
        </button>

        {/* Progress Bar */}
        {generating && (
          <div className="space-y-2">
            <div className="w-full bg-gray-200 rounded-full h-4">
              <div
                className="bg-blue-600 h-4 rounded-full transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
            <p className="text-sm text-center text-gray-600">
              {progress}% - {statusMessage}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
```

---

## 9. TESTING REQUIREMENTS

### 9.1 Unit Tests

```typescript
describe('ActivityPackService', () => {
  describe('Request Validation', () => {
    it('should reject invalid age ranges', () => {
      const request = {
        target_audience: {
          age_range: { min_age: 3, max_age: 25 }
        }
      };

      const validation = service.validateRequest(request);
      expect(validation.valid).toBe(false);
      expect(validation.errors).toContain('min_age must be 5-18');
    });

    it('should reject difficulty distribution not summing to 100', () => {
      const request = {
        activity_preferences: {
          difficulty_distribution: { easy: 40, medium: 40, hard: 30 }
        }
      };

      const validation = service.validateRequest(request);
      expect(validation.valid).toBe(false);
      expect(validation.errors).toContain('difficulty_distribution must sum to 100');
    });

    it('should accept valid requests', () => {
      const request = createValidRequest();
      const validation = service.validateRequest(request);
      expect(validation.valid).toBe(true);
      expect(validation.errors).toHaveLength(0);
    });
  });

  describe('Activity Generation', () => {
    it('should generate requested number of activities', async () => {
      const request = createValidRequest({ total_activities: 15 });
      const result = await service.generateActivityPack(request, 'user-id');

      expect(result.activities).toHaveLength(15);
    });

    it('should respect difficulty distribution', async () => {
      const request = createValidRequest({
        difficulty_distribution: { easy: 20, medium: 60, hard: 20 }
      });
      const result = await service.generateActivityPack(request, 'user-id');

      const easyCount = result.activities.filter(a => a.difficulty_level === 'easy').length;
      const mediumCount = result.activities.filter(a => a.difficulty_level === 'medium').length;
      const hardCount = result.activities.filter(a => a.difficulty_level === 'hard').length;

      expect(easyCount).toBeCloseTo(3, 1); // 20% of 15 = 3
      expect(mediumCount).toBeCloseTo(9, 1); // 60% of 15 = 9
      expect(hardCount).toBeCloseTo(3, 1); // 20% of 15 = 3
    });

    it('should include all requested Bloom levels', async () => {
      const request = createValidRequest({
        blooms_taxonomy_coverage: ['understand', 'apply', 'analyze']
      });
      const result = await service.generateActivityPack(request, 'user-id');

      const bloomsLevels = new Set(result.activities.map(a => a.blooms_level));
      expect(bloomsLevels).toContain('understand');
      expect(bloomsLevels).toContain('apply');
      expect(bloomsLevels).toContain('analyze');
    });
  });

  describe('Disability Adaptations', () => {
    it('should include adaptations for requested disabilities', async () => {
      const request = createValidRequest({
        disability_adaptations: ['dyslexia', 'adhd']
      });
      const result = await service.generateActivityPack(request, 'user-id');

      result.activities.forEach(activity => {
        expect(activity.differentiation.modifications_by_disability).toHaveProperty('dyslexia');
        expect(activity.differentiation.modifications_by_disability).toHaveProperty('adhd');

        expect(activity.differentiation.modifications_by_disability.dyslexia).toBeInstanceOf(Array);
        expect(activity.differentiation.modifications_by_disability.dyslexia.length).toBeGreaterThan(0);
      });
    });
  });

  describe('Quality Verification', () => {
    it('should reject low-quality outputs', async () => {
      // Mock low-quality response
      mockAIProvider.setQualityScore(65);

      const request = createValidRequest();

      await expect(service.generateActivityPack(request, 'user-id'))
        .rejects.toThrow(/quality too low/i);
    });

    it('should accept high-quality outputs', async () => {
      mockAIProvider.setQualityScore(92);

      const request = createValidRequest();
      const result = await service.generateActivityPack(request, 'user-id');

      expect(result.quality_metrics.pedagogical_alignment_score).toBeGreaterThanOrEqual(80);
    });
  });
});
```

### 9.2 Integration Tests

```typescript
describe('Activity Pack Generation - End to End', () => {
  it('should complete full generation cycle', async () => {
    const startTime = Date.now();

    const request = createValidRequest();
    const service = new ActivityPackService();
    const result = await service.generateActivityPack(request, 'test-user');

    const endTime = Date.now();
    const duration = (endTime - startTime) / 1000; // seconds

    // Should complete in 4-8 minutes
    expect(duration).toBeLessThan(480); // 8 minutes
    expect(duration).toBeGreaterThan(240); // 4 minutes

    // Verify structure
    expect(result.metadata.pack_id).toBeDefined();
    expect(result.activities.length).toBeGreaterThan(0);
    expect(result.files_generated.pdf_files.length).toBeGreaterThan(0);

    // Verify quality
    expect(result.quality_metrics.overall_score).toBeGreaterThanOrEqual(80);

    // Verify files exist in storage
    for (const file of result.files_generated.pdf_files) {
      const exists = await checkFileExists(file.storage_url);
      expect(exists).toBe(true);
    }
  }, 600000); // 10 minute timeout

  it('should handle parallel processing correctly', async () => {
    const request = createValidRequest({ total_activities: 20 });
    const service = new ActivityPackService();

    const result = await service.generateActivityPack(request, 'test-user');

    expect(result.activities).toHaveLength(20);

    // All activities should have unique IDs
    const ids = result.activities.map(a => a.activity_id);
    const uniqueIds = new Set(ids);
    expect(uniqueIds.size).toBe(20);
  });

  it('should track progress in database', async () => {
    const request = createValidRequest();
    const service = new ActivityPackService();

    // Start generation (don't await yet)
    const generatePromise = service.generateActivityPack(request, 'test-user');

    // Wait a bit then check progress
    await new Promise(resolve => setTimeout(resolve, 30000)); // 30 seconds

    const { data: jobs } = await supabase
      .from('addon_generation_jobs')
      .select('*')
      .eq('user_id', 'test-user')
      .order('created_at', { ascending: false })
      .limit(1);

    expect(jobs[0].progress).toBeGreaterThan(0);
    expect(jobs[0].progress).toBeLessThanOrEqual(100);
    expect(jobs[0].status).toMatch(/processing|completed/);

    // Wait for completion
    await generatePromise;
  });
});
```

---

## 10. COST ANALYSIS

### 10.1 Token Usage Estimates

| Phase | Model | Avg Input | Avg Output | Cost/Pack |
|-------|-------|-----------|------------|-----------|
| Phase 1: Analysis | Claude-3-5-Sonnet | 15,000 | 3,000 | $0.055 |
| Phase 2: Ideation | GPT-4o | 5,000 | 8,000 | $0.065 |
| Phase 3: Selection | Gemini-2.0-Flash | 10,000 | 2,000 | $0.003 |
| Phase 4: Development (×20) | Claude-3-5-Sonnet | 160,000 | 80,000 | $2.20 |
| Phase 5: Disability | Claude-3-5-Sonnet | 25,000 | 5,000 | $0.092 |
| Phase 6: Assessment | Claude-3-5-Sonnet | 20,000 | 10,000 | $0.185 |
| Phase 7: Quality | Gemini-2.0-Flash | 30,000 | 3,000 | $0.008 |
| **TOTAL** | | **265,000** | **111,000** | **$2.61** |

### 10.2 Pricing Strategy

**Cost Structure:**
- AI Generation: $2.61
- Storage (5MB): $0.02
- Processing: $0.12
- Bandwidth: $0.05
- **Total Cost: $2.80**

**Pricing Tiers:**
- **Single Pack**: $9.99 (3.6x markup, 72% margin)
- **5-Pack Bundle**: $39.99 ($8.00 each, 20% discount)
- **10-Pack Bundle**: $69.99 ($7.00 each, 30% discount)
- **Unlimited (Monthly)**: $29.99/month

**Break-Even Analysis:**
- Fixed costs: $17,000 (development)
- Variable cost per pack: $2.80
- Profit per pack @ $9.99: $7.19
- Break-even units: 2,365 packs

**Revenue Projections:**
- Year 1 (Conservative): 500 packs/month = $4,995/month
- Year 2 (Moderate): 2,000 packs/month = $19,980/month
- Year 3 (Optimistic): 8,000 packs/month = $79,920/month

---

## 11. IMPLEMENTATION TIMELINE

### Week 1-2: Foundation
- [ ] Set up database schema
- [ ] Create TypeScript interfaces
- [ ] Implement request validation
- [ ] Set up job tracking system

### Week 3-4: AI Integration
- [ ] Implement AI orchestration layer
- [ ] Create all 7 phase prompts
- [ ] Set up fallback logic
- [ ] Test with mock data

### Week 5-6: Core Generation
- [ ] Implement content analysis
- [ ] Implement activity ideation
- [ ] Implement activity selection
- [ ] Implement detailed development

### Week 7-8: Enhancements
- [ ] Implement disability adaptations
- [ ] Implement assessment generation
- [ ] Implement quality verification
- [ ] Add parallel processing

### Week 9: File Generation
- [ ] Set up PDF generation
- [ ] Set up DOCX generation
- [ ] Set up file storage
- [ ] Optimize file sizes

### Week 10: Testing & QA
- [ ] Unit tests (80% coverage)
- [ ] Integration tests
- [ ] End-to-end tests
- [ ] Performance testing

### Week 11: Polish
- [ ] UI/UX refinement
- [ ] Error handling
- [ ] Progress tracking
- [ ] Documentation

### Week 12: Launch
- [ ] Beta testing
- [ ] Bug fixes
- [ ] Production deployment
- [ ] Monitoring setup

---

## 12. APPROVAL STATUS

**Status**: 🟡 **DRAFT - AWAITING REVIEW**

**Submitted By**: System
**Submitted Date**: 2024-12-19
**Review Requested From**: Project Owner

### Reviewer Checklist

Please review and approve/reject this specification:

- [ ] **Input Schema** - Complete and validates correctly
- [ ] **Output Schema** - Comprehensive and well-structured
- [ ] **AI Orchestration** - Efficient model usage with fallbacks
- [ ] **Prompts** - Detailed and effective
- [ ] **Code Examples** - Production-ready and tested
- [ ] **Testing Plan** - Adequate coverage
- [ ] **Cost Analysis** - Acceptable margins
- [ ] **Timeline** - Realistic and achievable

### Approval Decision

**Approved**: ☐ Yes ☐ No ☐ Conditional

**Conditions/Changes Required**:
```
[List any required changes or conditions for approval]
```

**Reviewer Signature**: ________________
**Date**: ________________

---

**END OF COMPLETE SPECIFICATION**
