# Activity Packs - Complete Technical Specification

**Version**: 2.0
**Status**: Draft - Awaiting Approval
**Feature ID**: ADDON-001
**Category**: Student Learning Materials
**Complexity**: High
**Created**: 2024-12-19
**Updated**: 2024-12-19

---

## TABLE OF CONTENTS

1. [Overview](#1-overview)
2. [Step-by-Step Workflow with Technical Parameters](#2-step-by-step-workflow-with-technical-parameters)
3. [AI Model Assignments](#3-ai-model-assignments)
4. [Technical Parameters by Step](#4-technical-parameters-by-step)
5. [Fallback Rules](#5-fallback-rules)
6. [Verification Integration](#6-verification-integration)
7. [Input/Output Specs](#7-inputoutput-specs)
8. [Dependencies Matrix](#8-dependencies-matrix)
9. [Quality Gates](#9-quality-gates)
10. [Complete AI Prompts](#10-complete-ai-prompts)
11. [Implementation Guide](#11-implementation-guide)
12. [Cost Analysis](#12-cost-analysis)
13. [Testing Requirements](#13-testing-requirements)
14. [Approval Status](#14-approval-status)

---

## 1. OVERVIEW

### 1.1 What It Does

Generates comprehensive, pedagogically-sound activity packs that transform book content into hands-on, interactive learning experiences. Each pack contains 15-30 diverse activities spanning multiple learning modalities and Bloom's Taxonomy levels.

### 1.2 Purpose

**Problem**: Students need diverse ways to engage with content beyond reading. Teachers need ready-to-use materials.

**Solution**: AI-generated activity packs that:
- Adapt to any book topic (generic, reusable system)
- Scale difficulty based on reading level
- Adapt for different disabilities
- Include all necessary materials/instructions
- Align with educational standards

### 1.3 Key Features

1. **Topic-Agnostic**: Works for any subject (science, history, math, literature, etc.)
2. **Disability-Aware**: Every activity includes accessibility modifications
3. **Multi-Modal**: Covers all 4 learning styles (VARK model)
4. **Scaffolded**: Activities progress from simple to complex
5. **Complete**: Includes materials, instructions, rubrics, and answer keys

---

## 2. STEP-BY-STEP WORKFLOW WITH TECHNICAL PARAMETERS

### Phase 1: Content Analysis
**Duration**: 5-10 seconds
**Purpose**: Extract key concepts and learning objectives from book content

#### Input Requirements
- Book content text (chapter/section)
- Target reading level
- Subject area

#### Processing
- AI analyzes content structure
- Identifies main concepts
- Maps to Bloom's taxonomy levels
- Extracts vocabulary

#### Output Deliverables
- Concept map with difficulty ratings
- Learning objectives list
- Vocabulary categorization
- Activity potential analysis

#### Success Criteria
- All major concepts identified (minimum 5, maximum 20)
- Concepts categorized by importance
- Difficulty ratings assigned
- No critical concepts missed

---

### Phase 2: Activity Ideation
**Duration**: 15-25 seconds
**Purpose**: Generate diverse, creative activity concepts

#### Input Requirements
- Content analysis from Phase 1
- Target activity count (e.g., 20)
- Difficulty distribution (e.g., 30% easy, 50% medium, 20% hard)
- Required Bloom's levels

#### Processing
- AI generates 30-40 activity ideas (more than needed)
- Ensures diversity across activity types
- Balances learning modalities
- Considers time requirements

#### Output Deliverables
- 30-40 activity concepts
- Each with brief description
- Difficulty level assigned
- Modality assigned
- Estimated time

#### Success Criteria
- At least 1.5x requested activities generated
- All activity types represented
- All modalities represented
- Diverse engagement strategies

---

### Phase 3: Activity Selection & Prioritization
**Duration**: 5 seconds
**Purpose**: Filter and rank activities to meet exact requirements

#### Input Requirements
- 30-40 activity ideas from Phase 2
- Target activity count (e.g., 20)
- Difficulty distribution requirements
- Bloom's level requirements

#### Processing
- AI scores each activity on multiple criteria
- Filters to meet exact distribution requirements
- Ranks by pedagogical value
- Ensures diversity

#### Output Deliverables
- Exactly [N] activities selected (e.g., 20)
- Meets difficulty distribution
- Meets Bloom's distribution
- Meets modality distribution

#### Success Criteria
- Exact number of activities selected
- Difficulty distribution within ±5%
- All required Bloom's levels present
- No duplicate activity types

---

### Phase 4: Detailed Activity Development
**Duration**: 90-180 seconds (parallel processing)
**Purpose**: Create complete, ready-to-use activities

#### Input Requirements
- Selected activity concepts from Phase 3
- Full book content
- Target audience details
- Standards alignment requirements

#### Processing (Per Activity)
- AI writes complete activity with all components:
  - Title and description
  - Learning objectives
  - Materials list
  - Step-by-step instructions
  - Teacher notes
  - Student worksheets
  - Real-world connections

#### Output Deliverables (Per Activity)
- Complete activity structure
- All required components present
- Clear, actionable instructions
- Materials list with quantities

#### Success Criteria (Per Activity)
- All 9 required components present
- Instructions are sequential and clear
- Materials are commonly available
- Time estimate is realistic
- Learning objectives are measurable

---

### Phase 5: Disability Adaptations
**Duration**: 30-60 seconds
**Purpose**: Add accessibility modifications for diverse learners

#### Input Requirements
- Developed activities from Phase 4
- List of disabilities to adapt for
- Disability adaptation guidelines

#### Processing
- AI analyzes each activity for barriers
- Generates specific modifications per disability
- Ensures modifications maintain learning objectives
- Considers assistive technology

#### Output Deliverables (Per Activity, Per Disability)
- 3-5 specific adaptations
- Each adaptation actionable
- Adaptations don't compromise rigor
- Alternative assessment options

#### Success Criteria
- All requested disabilities addressed
- Minimum 3 adaptations per disability per activity
- Adaptations are specific, not generic
- No "see teacher" cop-outs

---

### Phase 6: Answer Keys & Rubrics
**Duration**: 20-40 seconds
**Purpose**: Create assessment materials for teachers

#### Input Requirements
- Developed activities from Phase 4-5
- Learning objectives per activity
- Assessment type per activity

#### Processing
- AI generates complete answer keys
- Creates detailed rubrics with criteria
- Writes self-assessment questions
- Develops grading guidance

#### Output Deliverables (Per Activity)
- Complete answer key
- 3-5 criterion rubric
- Point values assigned
- Self-assessment questions (3-5)
- Teacher grading notes

#### Success Criteria
- Answer keys are complete and correct
- Rubrics have measurable criteria
- 4-point scale (exemplary → beginning)
- Total points clearly indicated
- Self-assessment promotes metacognition

---

### Phase 7: Quality Verification
**Duration**: 10-15 seconds
**Purpose**: Verify all quality standards are met

#### Input Requirements
- Complete activity pack from Phase 6
- Quality standards checklist
- Minimum score thresholds

#### Processing
- AI verifies each quality criterion
- Checks for completeness
- Validates accuracy
- Identifies issues

#### Output Deliverables
- Overall quality score (0-100)
- Pedagogical alignment score
- Accessibility score
- Diversity score
- List of passed checks
- List of warnings/issues

#### Success Criteria
- Overall score ≥ 80
- Pedagogical alignment ≥ 85
- Accessibility score ≥ 80
- No critical issues
- All required elements present

---

### Phase 8: File Generation
**Duration**: 20-30 seconds
**Purpose**: Create formatted PDF and editable documents

#### Input Requirements
- Complete activity pack data
- Formatting preferences
- Output format selections

#### Processing
- System generates PDF files
- Creates editable DOCX versions
- Applies formatting and styling
- Optimizes file sizes

#### Output Deliverables
- Complete activity pack PDF
- Student worksheets PDF
- Teacher guide PDF
- Editable DOCX version
- Files uploaded to storage

#### Success Criteria
- All files generated successfully
- PDFs are properly formatted
- File sizes are reasonable (<10MB)
- Files are accessible in storage
- Download links are valid

---

## 3. AI MODEL ASSIGNMENTS

### Model Selection by Phase

```json
{
  "phase_1_content_analysis": {
    "primary_model": "claude-3-5-sonnet-20241022",
    "rationale": "Excellent at structured analysis, extracting key concepts, understanding educational content",
    "estimated_tokens": {
      "input": 15000,
      "output": 3000
    }
  },

  "phase_2_activity_ideation": {
    "primary_model": "gpt-4o",
    "rationale": "Best for creative brainstorming, generating diverse ideas, thinking outside the box",
    "estimated_tokens": {
      "input": 5000,
      "output": 8000
    }
  },

  "phase_3_selection": {
    "primary_model": "gemini-2.0-flash-exp",
    "rationale": "Fast evaluation and ranking, cost-effective for filtering tasks",
    "estimated_tokens": {
      "input": 10000,
      "output": 2000
    }
  },

  "phase_4_development": {
    "primary_model": "claude-3-5-sonnet-20241022",
    "rationale": "Superior at detailed instructional writing, clear explanations, structured content",
    "estimated_tokens_per_activity": {
      "input": 8000,
      "output": 4000
    },
    "parallel_processing": {
      "concurrent_activities": 4,
      "batch_size": 4,
      "total_batches": 5
    }
  },

  "phase_5_disability_adaptations": {
    "primary_model": "claude-3-5-sonnet-20241022",
    "rationale": "Strong understanding of accessibility needs, specific and actionable recommendations",
    "estimated_tokens": {
      "input": 25000,
      "output": 5000
    }
  },

  "phase_6_assessment_creation": {
    "primary_model": "claude-3-5-sonnet-20241022",
    "rationale": "Excellent at creating clear rubrics, detailed answer keys, measurable criteria",
    "estimated_tokens": {
      "input": 20000,
      "output": 10000
    }
  },

  "phase_7_quality_verification": {
    "primary_model": "gemini-2.0-flash-exp",
    "rationale": "Fast verification, good at checklist-based evaluation, cost-effective",
    "estimated_tokens": {
      "input": 30000,
      "output": 3000
    }
  }
}
```

---

## 4. TECHNICAL PARAMETERS BY STEP

### Phase 1: Content Analysis

```json
{
  "technical_parameters": {
    "ai_model": "claude-3-5-sonnet-20241022",
    "temperature": 0.3,
    "max_tokens": 4000,
    "context_window_used": "~18K tokens",
    "timeout": 30000,
    "retry_attempts": 3,

    "quality_thresholds": {
      "min_concepts_identified": 5,
      "max_concepts_identified": 20,
      "min_vocabulary_terms": 10,
      "required_difficulty_spread": true
    },

    "validation_rules": {
      "must_have_primary_concepts": true,
      "must_have_learning_objectives": true,
      "must_categorize_vocabulary": true,
      "concept_descriptions_min_length": 50
    }
  }
}
```

### Phase 2: Activity Ideation

```json
{
  "technical_parameters": {
    "ai_model": "gpt-4o",
    "temperature": 0.8,
    "max_tokens": 10000,
    "context_window_used": "~13K tokens",
    "timeout": 45000,
    "retry_attempts": 3,

    "quality_thresholds": {
      "min_ideas_generated": "target_count * 1.5",
      "max_ideas_generated": "target_count * 2.0",
      "min_activity_types_represented": 12,
      "min_modalities_represented": 4,
      "min_bloom_levels_represented": 4
    },

    "validation_rules": {
      "each_idea_must_have_title": true,
      "each_idea_must_have_description": true,
      "each_idea_must_have_difficulty": true,
      "each_idea_must_have_modality": true,
      "each_idea_must_have_time_estimate": true,
      "no_duplicate_concepts": true
    }
  }
}
```

### Phase 3: Selection & Prioritization

```json
{
  "technical_parameters": {
    "ai_model": "gemini-2.0-flash-exp",
    "temperature": 0.2,
    "max_tokens": 3000,
    "context_window_used": "~12K tokens",
    "timeout": 20000,
    "retry_attempts": 3,

    "quality_thresholds": {
      "exact_activity_count": "must match target",
      "difficulty_distribution_tolerance": 0.05,
      "bloom_distribution_tolerance": 0.1,
      "modality_distribution_tolerance": 0.1,
      "min_diversity_score": 0.75
    },

    "validation_rules": {
      "exact_number_selected": true,
      "all_required_blooms_present": true,
      "difficulty_percentages_valid": true,
      "no_activity_type_overrepresentation": true,
      "selection_rationale_provided": true
    }
  }
}
```

### Phase 4: Detailed Development (Per Activity)

```json
{
  "technical_parameters": {
    "ai_model": "claude-3-5-sonnet-20241022",
    "temperature": 0.5,
    "max_tokens": 5000,
    "context_window_per_activity": "~12K tokens",
    "timeout_per_activity": 45000,
    "retry_attempts": 3,
    "parallel_processing": {
      "enabled": true,
      "concurrent_limit": 4,
      "batch_size": 4
    },

    "quality_thresholds": {
      "min_instruction_steps": 3,
      "max_instruction_steps": 12,
      "min_materials_listed": 1,
      "min_learning_objectives": 2,
      "max_learning_objectives": 5,
      "min_teacher_notes": 2,
      "min_real_world_connections": 1
    },

    "validation_rules": {
      "all_9_components_present": true,
      "instructions_are_sequential": true,
      "time_estimate_is_realistic": true,
      "materials_are_specific": true,
      "objectives_use_blooms_verbs": true,
      "no_placeholder_content": true
    },

    "required_components": [
      "title",
      "learning_objectives",
      "materials_needed",
      "teacher_preparation",
      "step_by_step_instructions",
      "real_world_connections",
      "cross_curricular_links",
      "teaching_tips",
      "time_estimates"
    ]
  }
}
```

### Phase 5: Disability Adaptations

```json
{
  "technical_parameters": {
    "ai_model": "claude-3-5-sonnet-20241022",
    "temperature": 0.4,
    "max_tokens": 6000,
    "context_window_used": "~30K tokens",
    "timeout": 90000,
    "retry_attempts": 3,

    "quality_thresholds": {
      "min_adaptations_per_disability": 3,
      "max_adaptations_per_disability": 7,
      "adaptation_specificity_score": 0.8,
      "maintains_rigor_score": 0.9
    },

    "validation_rules": {
      "all_disabilities_addressed": true,
      "adaptations_are_specific": true,
      "adaptations_are_actionable": true,
      "no_generic_statements": true,
      "rigor_maintained": true,
      "alternative_assessments_provided": true
    },

    "disability_categories_required": [
      "visual_impairments",
      "hearing_impairments",
      "motor_impairments",
      "cognitive_disabilities",
      "learning_disabilities",
      "attention_disorders",
      "autism_spectrum",
      "sensory_processing"
    ]
  }
}
```

### Phase 6: Answer Keys & Rubrics

```json
{
  "technical_parameters": {
    "ai_model": "claude-3-5-sonnet-20241022",
    "temperature": 0.2,
    "max_tokens": 12000,
    "context_window_used": "~30K tokens",
    "timeout": 60000,
    "retry_attempts": 3,

    "quality_thresholds": {
      "rubric_criteria_count_min": 3,
      "rubric_criteria_count_max": 6,
      "self_assessment_questions_min": 3,
      "self_assessment_questions_max": 7,
      "answer_completeness_score": 0.95
    },

    "validation_rules": {
      "answer_key_is_complete": true,
      "answer_key_is_accurate": true,
      "rubric_has_4_point_scale": true,
      "rubric_criteria_are_measurable": true,
      "point_values_total_is_clear": true,
      "self_assessment_promotes_reflection": true
    },

    "rubric_requirements": {
      "scale": "4-point",
      "levels": ["exemplary", "proficient", "developing", "beginning"],
      "each_criterion_has_descriptors": true,
      "descriptors_are_specific": true,
      "total_points_indicated": true
    }
  }
}
```

### Phase 7: Quality Verification

```json
{
  "technical_parameters": {
    "ai_model": "gemini-2.0-flash-exp",
    "temperature": 0.1,
    "max_tokens": 4000,
    "context_window_used": "~33K tokens",
    "timeout": 30000,
    "retry_attempts": 2,

    "quality_thresholds": {
      "overall_score_minimum": 80,
      "pedagogical_alignment_minimum": 85,
      "accessibility_score_minimum": 80,
      "diversity_score_minimum": 75,
      "completeness_score_minimum": 90
    },

    "validation_rules": {
      "all_activities_have_required_components": true,
      "no_placeholder_content": true,
      "no_broken_references": true,
      "time_estimates_are_realistic": true,
      "difficulty_progression_is_logical": true,
      "standards_alignment_is_valid": true
    },

    "scoring_criteria": [
      "pedagogical_soundness",
      "completeness",
      "clarity",
      "accessibility",
      "diversity",
      "engagement_potential",
      "real_world_relevance",
      "assessment_quality"
    ]
  }
}
```

### Phase 8: File Generation

```json
{
  "technical_parameters": {
    "system": "PDF/DOCX generation pipeline",
    "timeout": 60000,
    "retry_attempts": 2,

    "quality_thresholds": {
      "max_file_size_pdf": 10485760,
      "max_file_size_docx": 8388608,
      "min_page_count": 15,
      "max_page_count": 150,
      "image_quality_dpi": 150
    },

    "validation_rules": {
      "all_files_generated": true,
      "files_are_accessible": true,
      "files_are_properly_formatted": true,
      "download_links_are_valid": true,
      "file_sizes_within_limits": true
    },

    "output_files_required": [
      "complete_activity_pack.pdf",
      "student_worksheets.pdf",
      "teacher_guide.pdf",
      "editable_version.docx"
    ]
  }
}
```

---

## 5. FALLBACK RULES

### Fallback Strategy Overview

Each phase has primary and fallback models to ensure reliability.

```json
{
  "fallback_configuration": {
    "max_retry_attempts_before_fallback": 3,
    "retry_delay_ms": 2000,
    "exponential_backoff": true,
    "fallback_timeout_multiplier": 1.5,

    "phase_fallbacks": {
      "phase_1_content_analysis": {
        "primary": "claude-3-5-sonnet-20241022",
        "fallback_1": "gpt-4o",
        "fallback_2": "claude-3-5-haiku-20241022",
        "fallback_3": "gemini-2.0-flash-exp"
      },

      "phase_2_activity_ideation": {
        "primary": "gpt-4o",
        "fallback_1": "claude-3-5-sonnet-20241022",
        "fallback_2": "gemini-2.0-flash-exp",
        "fallback_3": "claude-3-5-haiku-20241022"
      },

      "phase_3_selection": {
        "primary": "gemini-2.0-flash-exp",
        "fallback_1": "claude-3-5-haiku-20241022",
        "fallback_2": "gpt-4o-mini",
        "fallback_3": "claude-3-5-sonnet-20241022"
      },

      "phase_4_development": {
        "primary": "claude-3-5-sonnet-20241022",
        "fallback_1": "gpt-4o",
        "fallback_2": "claude-3-5-haiku-20241022",
        "fallback_3": null
      },

      "phase_5_disability_adaptations": {
        "primary": "claude-3-5-sonnet-20241022",
        "fallback_1": "gpt-4o",
        "fallback_2": "gpt-4o-mini",
        "fallback_3": null
      },

      "phase_6_assessment_creation": {
        "primary": "claude-3-5-sonnet-20241022",
        "fallback_1": "gpt-4o",
        "fallback_2": "claude-3-5-haiku-20241022",
        "fallback_3": null
      },

      "phase_7_quality_verification": {
        "primary": "gemini-2.0-flash-exp",
        "fallback_1": "claude-3-5-haiku-20241022",
        "fallback_2": "gpt-4o-mini",
        "fallback_3": "claude-3-5-sonnet-20241022"
      }
    }
  }
}
```

### Fallback Trigger Conditions

```typescript
interface FallbackTrigger {
  condition: string;
  action: string;
}

const fallbackTriggers: FallbackTrigger[] = [
  {
    condition: "API returns 429 (rate limit)",
    action: "Immediate fallback to next model"
  },
  {
    condition: "API returns 500/502/503 (server error)",
    action: "Retry 3x with exponential backoff, then fallback"
  },
  {
    condition: "API returns 400 (bad request)",
    action: "Log error, adjust prompt, retry same model once, then fallback"
  },
  {
    condition: "Response timeout (no response within timeout period)",
    action: "Cancel request, immediate fallback"
  },
  {
    condition: "Invalid JSON response",
    action: "Retry same model 2x, then fallback"
  },
  {
    condition: "Quality score below threshold",
    action: "Retry with same model (different temperature), then fallback"
  },
  {
    condition: "Missing required fields in response",
    action: "Retry same model with enhanced prompt, then fallback"
  }
];
```

### Fallback Quality Adjustments

When using fallback models, adjust quality expectations:

```json
{
  "quality_adjustment_rules": {
    "fallback_1": {
      "quality_threshold_reduction": 0,
      "notes": "First fallback should maintain same quality standards"
    },
    "fallback_2": {
      "quality_threshold_reduction": 5,
      "notes": "Second fallback may accept 5% lower quality score"
    },
    "fallback_3": {
      "quality_threshold_reduction": 10,
      "notes": "Third fallback may accept 10% lower quality score"
    },
    "if_all_fallbacks_fail": {
      "action": "Mark phase as failed",
      "notify": "system_admin",
      "user_message": "Generation failed after multiple attempts. Please try again later."
    }
  }
}
```

---

## 6. VERIFICATION INTEGRATION

### Data Verification (Per Phase)

Each phase includes automated data verification to ensure quality and completeness.

#### Phase 1: Content Analysis Verification

```json
{
  "verification_checks": {
    "structural_validation": {
      "check_name": "Required fields present",
      "validates": [
        "key_concepts array exists",
        "learning_objectives object exists",
        "vocabulary object exists",
        "content_structure object exists"
      ],
      "failure_action": "reject_output_retry"
    },

    "content_validation": {
      "check_name": "Concept quality",
      "validates": [
        "min 5 concepts identified",
        "max 20 concepts identified",
        "each concept has description (min 50 chars)",
        "each concept has difficulty rating (1-5)",
        "each concept has applicable Bloom's levels"
      ],
      "failure_action": "reject_output_retry"
    },

    "vocabulary_validation": {
      "check_name": "Vocabulary completeness",
      "validates": [
        "min 10 vocabulary terms total",
        "tier 2 and tier 3 terms present",
        "each term has definition",
        "definitions are clear (min 20 chars)"
      ],
      "failure_action": "reject_output_retry"
    }
  }
}
```

#### Phase 2: Activity Ideation Verification

```json
{
  "verification_checks": {
    "quantity_validation": {
      "check_name": "Sufficient ideas generated",
      "validates": [
        "number of ideas >= target_count * 1.5",
        "number of ideas <= target_count * 2.0"
      ],
      "failure_action": "reject_output_retry"
    },

    "diversity_validation": {
      "check_name": "Diversity requirements met",
      "validates": [
        "min 12 different activity types represented",
        "all 4 modalities represented",
        "all requested Bloom's levels represented",
        "time estimates range from 5-45 minutes"
      ],
      "failure_action": "reject_output_retry"
    },

    "completeness_validation": {
      "check_name": "Each idea is complete",
      "validates": [
        "each idea has title (5-80 chars)",
        "each idea has description (20-200 chars)",
        "each idea has difficulty level",
        "each idea has modality",
        "each idea has time estimate",
        "each idea has Bloom's level"
      ],
      "failure_action": "reject_output_retry"
    }
  }
}
```

#### Phase 3: Selection Verification

```json
{
  "verification_checks": {
    "count_validation": {
      "check_name": "Exact count selected",
      "validates": [
        "selected_count === target_count"
      ],
      "failure_action": "reject_output_retry"
    },

    "distribution_validation": {
      "check_name": "Distribution requirements met",
      "validates": [
        "difficulty distribution within ±5% of target",
        "Bloom's distribution includes all required levels",
        "modality distribution within ±10% of target",
        "no activity type appears more than 30%"
      ],
      "failure_action": "reject_output_retry"
    },

    "selection_quality": {
      "check_name": "Best activities selected",
      "validates": [
        "activities ranked by quality",
        "selection rationale provided",
        "no low-quality activities selected"
      ],
      "failure_action": "log_warning"
    }
  }
}
```

#### Phase 4: Activity Development Verification

```json
{
  "verification_checks": {
    "component_validation": {
      "check_name": "All 9 components present",
      "validates": [
        "title exists (5-100 chars)",
        "learning_objectives exist (2-5 items)",
        "materials_needed exists (min 1 item)",
        "teacher_preparation exists",
        "step_by_step_instructions exists (3-12 steps)",
        "real_world_connections exist (min 1)",
        "cross_curricular_links exist (min 1)",
        "teaching_tips exist (min 2)",
        "time_estimates present"
      ],
      "failure_action": "reject_activity_retry"
    },

    "instruction_validation": {
      "check_name": "Instructions are clear",
      "validates": [
        "steps are numbered sequentially",
        "each step has action verb",
        "each step has time estimate",
        "total time matches individual step times (±10%)",
        "no placeholder text",
        "instructions are student-friendly"
      ],
      "failure_action": "reject_activity_retry"
    },

    "objective_validation": {
      "check_name": "Learning objectives are measurable",
      "validates": [
        "objectives use Bloom's verbs",
        "objectives are specific",
        "objectives align with activity type",
        "objectives are achievable in time given"
      ],
      "failure_action": "reject_activity_retry"
    },

    "materials_validation": {
      "check_name": "Materials are specific",
      "validates": [
        "each material has quantity",
        "materials are commonly available",
        "required vs optional clearly marked",
        "no vague items (e.g., 'various supplies')"
      ],
      "failure_action": "log_warning"
    }
  }
}
```

#### Phase 5: Disability Adaptations Verification

```json
{
  "verification_checks": {
    "coverage_validation": {
      "check_name": "All disabilities addressed",
      "validates": [
        "all requested disabilities have adaptations",
        "min 3 adaptations per disability per activity",
        "max 7 adaptations per disability per activity"
      ],
      "failure_action": "reject_output_retry"
    },

    "specificity_validation": {
      "check_name": "Adaptations are specific",
      "validates": [
        "no generic statements (e.g., 'provide accommodations')",
        "adaptations are actionable",
        "adaptations reference specific activity components",
        "adaptations don't just say 'allow extra time'"
      ],
      "failure_action": "reject_output_retry"
    },

    "rigor_validation": {
      "check_name": "Rigor is maintained",
      "validates": [
        "adaptations modify access, not standards",
        "learning objectives still achievable",
        "alternative assessments are equivalent",
        "adaptations don't oversimplify content"
      ],
      "failure_action": "log_warning"
    }
  }
}
```

#### Phase 6: Assessment Verification

```json
{
  "verification_checks": {
    "answer_key_validation": {
      "check_name": "Answer keys are complete",
      "validates": [
        "answer key addresses all questions",
        "answers are accurate",
        "answers include explanations where needed",
        "no 'answers may vary' without guidance"
      ],
      "failure_action": "reject_output_retry"
    },

    "rubric_validation": {
      "check_name": "Rubrics are well-designed",
      "validates": [
        "rubric has 3-6 criteria",
        "each criterion has 4-point scale",
        "descriptors are specific and measurable",
        "total points clearly indicated",
        "rubric aligns with learning objectives"
      ],
      "failure_action": "reject_output_retry"
    },

    "self_assessment_validation": {
      "check_name": "Self-assessment promotes reflection",
      "validates": [
        "3-7 self-assessment questions",
        "questions promote metacognition",
        "questions reference learning objectives",
        "questions are answerable by students"
      ],
      "failure_action": "log_warning"
    }
  }
}
```

#### Phase 7: Overall Quality Verification

```json
{
  "verification_checks": {
    "score_validation": {
      "check_name": "Minimum quality scores met",
      "validates": [
        "overall_score >= 80",
        "pedagogical_alignment >= 85",
        "accessibility_score >= 80",
        "diversity_score >= 75",
        "completeness_score >= 90"
      ],
      "failure_action": "reject_pack_regenerate"
    },

    "completeness_validation": {
      "check_name": "All components present",
      "validates": [
        "all activities have all required components",
        "no placeholder content",
        "no TODO markers",
        "no '[INSERT X HERE]' text",
        "all references are valid"
      ],
      "failure_action": "reject_pack_fix_issues"
    },

    "consistency_validation": {
      "check_name": "Pack is internally consistent",
      "validates": [
        "difficulty progression makes sense",
        "time estimates are consistent",
        "standards alignment is valid",
        "cross-references work",
        "vocabulary is consistent across activities"
      ],
      "failure_action": "log_warning"
    }
  }
}
```

### Visual Verification

Visual verification checks formatting and presentation quality.

```json
{
  "visual_verification": {
    "layout_checks": {
      "page_formatting": [
        "margins are consistent (1 inch all sides)",
        "font sizes are appropriate (body 11-12pt, headings 14-18pt)",
        "line spacing is readable (1.5 for instructions)",
        "page breaks are logical",
        "no orphaned headers"
      ],
      "visual_hierarchy": [
        "headers are clearly distinguished",
        "sections are visually separated",
        "important information stands out",
        "consistent use of bold/italic",
        "bullet points and numbering used appropriately"
      ]
    },

    "accessibility_checks": {
      "dyslexia_friendly": [
        "sans-serif fonts available (Arial, Verdana, OpenDyslexic)",
        "sufficient white space",
        "adequate line spacing (min 1.5)",
        "no justified text",
        "color is not sole indicator"
      ],
      "visual_impairment": [
        "minimum font size 11pt (larger for low vision versions)",
        "high contrast (4.5:1 minimum)",
        "images have alt text",
        "diagrams have text descriptions"
      ],
      "print_quality": [
        "graphics are crisp (150dpi minimum)",
        "no pixelated images",
        "tables fit on page",
        "worksheets are printable on standard paper",
        "black and white version is readable"
      ]
    },

    "professional_appearance": {
      "branding": [
        "consistent header/footer",
        "page numbers present",
        "copyright notice included",
        "contact information appropriate"
      ],
      "polish": [
        "no spelling errors",
        "no grammar errors",
        "no formatting glitches",
        "professional appearance overall",
        "suitable for school distribution"
      ]
    }
  }
}
```

---

## 7. INPUT/OUTPUT SPECS

### Input Schema (Complete)

```typescript
interface ActivityPackRequest {
  // REQUIRED FIELDS
  book_id: string;
  content_scope: 'full_book' | 'chapter' | 'section' | 'concept';

  target_audience: {
    age_range: {
      min_age: number; // 5-18
      max_age: number; // 5-18
    };
    reading_level: 'elementary' | 'middle_school' | 'high_school' | 'college';
    grade_levels: string[]; // ['5th', '6th']
  };

  activity_preferences: {
    total_activities: number; // 10-50
    difficulty_distribution: {
      easy: number; // percentage (must sum to 100)
      medium: number;
      hard: number;
    };
    blooms_taxonomy_coverage: BloomsLevel[];
  };

  // OPTIONAL FIELDS
  learning_modalities?: {
    visual: number; // percentage
    auditory: number;
    reading_writing: number;
    kinesthetic: number;
  };

  activity_types_include?: ActivityType[];
  activity_types_exclude?: ActivityType[];

  time_constraints?: {
    min_minutes: number;
    max_minutes: number;
  };

  disability_adaptations?: DisabilityType[];

  standards_alignment?: {
    framework: 'common_core' | 'ngss' | 'state_standards' | 'ib' | 'ap';
    specific_standards?: string[];
  };

  output_format_preferences?: {
    include_answer_keys: boolean;
    include_rubrics: boolean;
    include_teacher_notes: boolean;
    language: string;
    color_vs_bw: 'color' | 'black_and_white' | 'both';
  };
}

type BloomsLevel = 'remember' | 'understand' | 'apply' |
                   'analyze' | 'evaluate' | 'create';

type ActivityType =
  | 'word_search' | 'crossword' | 'matching' | 'fill_in_blank'
  | 'short_answer' | 'essay' | 'diagram_labeling' | 'timeline_creation'
  | 'concept_mapping' | 'role_play_scenario' | 'debate_prep'
  | 'research_project' | 'creative_writing' | 'art_project'
  | 'science_experiment' | 'math_problem_solving' | 'coding_challenge'
  | 'physical_activity' | 'music_creation' | 'game_design';

type DisabilityType =
  | 'dyslexia' | 'adhd' | 'autism_level1' | 'autism_level2' | 'autism_level3'
  | 'blind_low_vision' | 'deaf_hard_of_hearing' | 'motor_impairment'
  | 'intellectual_disability' | 'dyscalculia' | 'dysgraphia'
  | 'visual_processing' | 'auditory_processing' | 'executive_function';
```

### Output Schema (Complete)

```typescript
interface ActivityPackOutput {
  metadata: {
    pack_id: string;
    source_book_id: string;
    generation_date: string;
    version: string;
    total_activities: number;
    estimated_total_time_minutes: number;
    difficulty_profile: {
      easy_count: number;
      medium_count: number;
      hard_count: number;
    };
    standards_covered: string[];
  };

  pack_overview: {
    title: string;
    subtitle: string;
    description: string;
    learning_objectives: string[];
    prerequisite_knowledge: string[];
    materials_needed: {
      required: string[];
      optional: string[];
    };
  };

  activities: Activity[];

  supplementary_materials: {
    vocabulary_list: VocabularyTerm[];
    suggested_sequence: DailySequence[];
    assessment_tools: AssessmentTools;
    parent_letter: string;
  };

  files_generated: {
    pdf_files: GeneratedFile[];
    editable_formats: GeneratedFile[];
  };

  quality_metrics: QualityMetrics;
}

interface Activity {
  activity_id: string;
  activity_number: number;
  title: string;
  activity_type: ActivityType;

  category: 'warmup' | 'core_learning' | 'practice' |
           'application' | 'extension' | 'assessment';

  difficulty_level: 'easy' | 'medium' | 'hard';
  blooms_level: BloomsLevel;
  learning_modality: 'visual' | 'auditory' | 'reading_writing' | 'kinesthetic';

  estimated_time_minutes: number;
  individual_or_group: 'individual' | 'pairs' | 'small_group' | 'whole_class';

  learning_objectives: string[];
  standards_addressed: string[];

  materials_needed: Material[];

  preparation: {
    teacher_prep_time_minutes: number;
    prep_instructions: string[];
    printables_needed: string[];
  };

  instructions: {
    student_instructions: InstructionStep[];
    teacher_notes: string[];
    teaching_tips: string[];
  };

  content: ActivityContent;

  assessment: {
    answer_key: any;
    rubric: Rubric;
    self_assessment: string[];
  };

  differentiation: {
    scaffolding: string[];
    extensions: string[];
    modifications_by_disability: {
      [key in DisabilityType]?: string[];
    };
  };

  connections: {
    real_world_applications: string[];
    cross_curricular_links: CrossCurricularLink[];
    home_connection: string;
  };
}

interface InstructionStep {
  step_number: number;
  instruction: string;
  time_estimate: number;
  success_indicator: string;
}

interface Rubric {
  criteria: RubricCriterion[];
  total_points: number;
}

interface RubricCriterion {
  criterion: string;
  exemplary: string; // 4 points
  proficient: string; // 3 points
  developing: string; // 2 points
  beginning: string; // 1 point
  points: number;
}

interface QualityMetrics {
  overall_score: number; // 0-100
  pedagogical_alignment_score: number; // 0-100
  accessibility_score: number; // 0-100
  diversity_score: number; // 0-100
  completeness_score: number; // 0-100
  validation_checks_passed: string[];
  warnings: string[];
}
```

### Data Flow Between Phases

```
INPUT REQUEST
     ↓
Phase 1: Content Analysis
     ├─ book_id → fetch book content
     ├─ content_scope → determine what to analyze
     ├─ target_audience → inform difficulty assessment
     └─ OUTPUT: ContentAnalysis
              ↓
Phase 2: Activity Ideation
     ├─ ContentAnalysis (from Phase 1)
     ├─ activity_preferences (from INPUT)
     ├─ target_audience (from INPUT)
     └─ OUTPUT: ActivityIdeas[]
              ↓
Phase 3: Selection
     ├─ ActivityIdeas[] (from Phase 2)
     ├─ activity_preferences (from INPUT)
     └─ OUTPUT: SelectedActivities[]
              ↓
Phase 4: Development (parallel)
     ├─ SelectedActivities[] (from Phase 3)
     ├─ Full book content (from INPUT)
     ├─ target_audience (from INPUT)
     ├─ standards_alignment (from INPUT)
     └─ OUTPUT: DevelopedActivities[]
              ↓
Phase 5: Disability Adaptations
     ├─ DevelopedActivities[] (from Phase 4)
     ├─ disability_adaptations (from INPUT)
     └─ OUTPUT: ActivitiesWithAdaptations[]
              ↓
Phase 6: Assessment Creation
     ├─ ActivitiesWithAdaptations[] (from Phase 5)
     └─ OUTPUT: ActivitiesWithAssessments[]
              ↓
Phase 7: Quality Verification
     ├─ ActivitiesWithAssessments[] (from Phase 6)
     └─ OUTPUT: QualityReport + ValidatedActivities[]
              ↓
Phase 8: File Generation
     ├─ ValidatedActivities[] (from Phase 7)
     ├─ output_format_preferences (from INPUT)
     └─ OUTPUT: GeneratedFiles[] + URLs
              ↓
FINAL OUTPUT: ActivityPackOutput
```

---

## 8. DEPENDENCIES MATRIX

### Phase Dependencies

| Phase | Depends On | Required Data | Optional Data | Can Run in Parallel |
|-------|-----------|---------------|---------------|---------------------|
| Phase 1: Content Analysis | User Request | book_id, content_scope, target_audience | standards_alignment | No |
| Phase 2: Activity Ideation | Phase 1 | ContentAnalysis, activity_preferences | activity_types_include/exclude | No |
| Phase 3: Selection | Phase 2 | ActivityIdeas[], activity_preferences | None | No |
| Phase 4: Development | Phase 3 | SelectedActivities[], Full book content | standards_alignment | Yes (4 concurrent) |
| Phase 5: Disability Adaptations | Phase 4 | DevelopedActivities[], disability_adaptations | None | No (but can process all activities at once) |
| Phase 6: Assessment Creation | Phase 5 | ActivitiesWithAdaptations[] | None | No (but can process all activities at once) |
| Phase 7: Quality Verification | Phase 6 | Complete activity pack | None | No |
| Phase 8: File Generation | Phase 7 | ValidatedActivities[], format_preferences | None | Yes (can generate multiple files concurrently) |

### External Dependencies

```json
{
  "external_dependencies": {
    "ai_providers": {
      "required": [
        "OpenAI API (GPT-4o)",
        "Anthropic API (Claude-3-5-Sonnet, Claude-3-5-Haiku)",
        "Google AI API (Gemini-2.0-Flash-Exp)"
      ],
      "fallback_requirements": "At least 2 of 3 providers must be available"
    },

    "database": {
      "required": [
        "Supabase (PostgreSQL)",
        "addon_features table",
        "addon_content table",
        "addon_generation_jobs table",
        "books table"
      ],
      "read_access": ["books table"],
      "write_access": ["addon_content table", "addon_generation_jobs table"]
    },

    "storage": {
      "required": [
        "Supabase Storage",
        "activity-packs bucket"
      ],
      "permissions": ["upload", "read"]
    },

    "file_generation": {
      "required": [
        "PDF generation library (e.g., jsPDF, PDFKit)",
        "DOCX generation library (e.g., docx.js)"
      ]
    },

    "optional_services": {
      "image_generation": "DALL-E 3 API (for custom illustrations)",
      "font_services": "Google Fonts API (for dyslexia-friendly fonts)"
    }
  }
}
```

### Data Dependencies Per Activity Component

```json
{
  "activity_component_dependencies": {
    "learning_objectives": {
      "requires": [
        "key_concepts from Phase 1",
        "Bloom's level assignment",
        "target_audience age/grade level"
      ]
    },

    "materials_needed": {
      "requires": [
        "activity_type",
        "difficulty_level",
        "age appropriateness check"
      ]
    },

    "step_by_step_instructions": {
      "requires": [
        "activity_type",
        "learning_objectives",
        "materials_needed",
        "time_estimate"
      ]
    },

    "disability_adaptations": {
      "requires": [
        "complete activity structure",
        "list of disabilities to adapt for",
        "original instructions and materials"
      ]
    },

    "answer_keys": {
      "requires": [
        "complete activity content",
        "learning_objectives",
        "activity_type"
      ]
    },

    "rubrics": {
      "requires": [
        "learning_objectives",
        "difficulty_level",
        "activity_type"
      ]
    }
  }
}
```

---

## 9. QUALITY GATES

### Overall Quality Gate

Activity pack must pass ALL quality gates to be approved for delivery.

```json
{
  "overall_quality_gate": {
    "minimum_scores": {
      "overall_score": 80,
      "pedagogical_alignment": 85,
      "accessibility_score": 80,
      "diversity_score": 75,
      "completeness_score": 90
    },
    "critical_failures": {
      "zero_tolerance": [
        "plagiarism detected",
        "offensive content",
        "dangerous activities",
        "major factual errors",
        "discriminatory content"
      ],
      "action_if_detected": "immediate_rejection_human_review"
    },
    "approval_requirement": "ALL scores above minimum AND NO critical failures"
  }
}
```

### Phase-Specific Quality Gates

#### Phase 1: Content Analysis Quality Gate

```json
{
  "quality_criteria": {
    "completeness": {
      "weight": 30,
      "checks": [
        {
          "criterion": "Minimum concepts identified",
          "requirement": ">= 5 concepts",
          "points": 10
        },
        {
          "criterion": "Concepts have descriptions",
          "requirement": "100% have descriptions >= 50 chars",
          "points": 10
        },
        {
          "criterion": "Vocabulary extracted",
          "requirement": ">= 10 terms with definitions",
          "points": 10
        }
      ]
    },
    "accuracy": {
      "weight": 40,
      "checks": [
        {
          "criterion": "Difficulty ratings are reasonable",
          "requirement": "Difficulty spread across 1-5 scale",
          "points": 15
        },
        {
          "criterion": "Bloom's levels appropriately assigned",
          "requirement": "Levels match concept complexity",
          "points": 15
        },
        {
          "criterion": "No mischaracterization of content",
          "requirement": "Analysis reflects actual book content",
          "points": 10
        }
      ]
    },
    "usefulness": {
      "weight": 30,
      "checks": [
        {
          "criterion": "Actionable activity suggestions",
          "requirement": "Activity types suggested per concept",
          "points": 15
        },
        {
          "criterion": "Real-world connections identified",
          "requirement": ">= 1 connection per major concept",
          "points": 15
        }
      ]
    }
  },
  "passing_score": 80,
  "failure_action": "retry_with_different_model"
}
```

#### Phase 2: Activity Ideation Quality Gate

```json
{
  "quality_criteria": {
    "quantity": {
      "weight": 20,
      "checks": [
        {
          "criterion": "Sufficient ideas generated",
          "requirement": "count >= target * 1.5",
          "points": 20
        }
      ]
    },
    "diversity": {
      "weight": 40,
      "checks": [
        {
          "criterion": "Activity type variety",
          "requirement": ">= 12 different types",
          "points": 15
        },
        {
          "criterion": "Modality balance",
          "requirement": "All 4 modalities represented",
          "points": 10
        },
        {
          "criterion": "Difficulty spread",
          "requirement": "Easy, medium, hard all present",
          "points": 10
        },
        {
          "criterion": "No repetitive ideas",
          "requirement": "Each idea is unique",
          "points": 5
        }
      ]
    },
    "quality": {
      "weight": 40,
      "checks": [
        {
          "criterion": "Ideas are well-described",
          "requirement": "Descriptions >= 20 chars",
          "points": 10
        },
        {
          "criterion": "Ideas are creative",
          "requirement": "Not just textbook questions",
          "points": 15
        },
        {
          "criterion": "Ideas are feasible",
          "requirement": "Can be completed in classroom",
          "points": 15
        }
      ]
    }
  },
  "passing_score": 75,
  "failure_action": "retry_with_higher_temperature"
}
```

#### Phase 3: Selection Quality Gate

```json
{
  "quality_criteria": {
    "accuracy": {
      "weight": 50,
      "checks": [
        {
          "criterion": "Exact count selected",
          "requirement": "selected_count === target_count",
          "points": 20,
          "critical": true
        },
        {
          "criterion": "Difficulty distribution met",
          "requirement": "Within ±5% of target percentages",
          "points": 15,
          "critical": true
        },
        {
          "criterion": "Bloom's coverage met",
          "requirement": "All required levels present",
          "points": 15,
          "critical": true
        }
      ]
    },
    "quality": {
      "weight": 50,
      "checks": [
        {
          "criterion": "Best activities selected",
          "requirement": "High-quality ideas chosen",
          "points": 25
        },
        {
          "criterion": "Diversity maintained",
          "requirement": "Good variety in final selection",
          "points": 25
        }
      ]
    }
  },
  "passing_score": 90,
  "critical_checks_must_pass": true,
  "failure_action": "retry_selection_algorithm"
}
```

#### Phase 4: Activity Development Quality Gate (Per Activity)

```json
{
  "quality_criteria": {
    "completeness": {
      "weight": 30,
      "checks": [
        {
          "criterion": "All 9 components present",
          "requirement": "100% of required components",
          "points": 15,
          "critical": true
        },
        {
          "criterion": "No placeholder content",
          "requirement": "No TODO, [INSERT], etc.",
          "points": 10,
          "critical": true
        },
        {
          "criterion": "Time estimates provided",
          "requirement": "All steps have time estimates",
          "points": 5
        }
      ]
    },
    "clarity": {
      "weight": 30,
      "checks": [
        {
          "criterion": "Instructions are sequential",
          "requirement": "Steps numbered and logical",
          "points": 10
        },
        {
          "criterion": "Language is age-appropriate",
          "requirement": "Readability matches target",
          "points": 10
        },
        {
          "criterion": "No ambiguity",
          "requirement": "Clear what students should do",
          "points": 10
        }
      ]
    },
    "pedagogical_soundness": {
      "weight": 40,
      "checks": [
        {
          "criterion": "Objectives are measurable",
          "requirement": "Use Bloom's verbs, are specific",
          "points": 15
        },
        {
          "criterion": "Activity matches objectives",
          "requirement": "Students can achieve objectives",
          "points": 15
        },
        {
          "criterion": "Appropriate difficulty",
          "requirement": "Matches assigned difficulty level",
          "points": 10
        }
      ]
    }
  },
  "passing_score": 85,
  "critical_checks_must_pass": true,
  "failure_action": "regenerate_activity"
}
```

#### Phase 5: Disability Adaptations Quality Gate

```json
{
  "quality_criteria": {
    "coverage": {
      "weight": 30,
      "checks": [
        {
          "criterion": "All disabilities addressed",
          "requirement": "100% of requested disabilities",
          "points": 15,
          "critical": true
        },
        {
          "criterion": "Sufficient adaptations",
          "requirement": ">= 3 per disability per activity",
          "points": 15
        }
      ]
    },
    "specificity": {
      "weight": 40,
      "checks": [
        {
          "criterion": "Adaptations are actionable",
          "requirement": "No vague suggestions",
          "points": 15,
          "critical": true
        },
        {
          "criterion": "Adaptations are specific to activity",
          "requirement": "Reference specific components",
          "points": 15
        },
        {
          "criterion": "No generic statements",
          "requirement": "Not just 'provide accommodations'",
          "points": 10
        }
      ]
    },
    "maintains_rigor": {
      "weight": 30,
      "checks": [
        {
          "criterion": "Objectives still achievable",
          "requirement": "Adaptations modify access, not standards",
          "points": 15
        },
        {
          "criterion": "Alternative assessments equivalent",
          "requirement": "Measure same learning",
          "points": 15
        }
      ]
    }
  },
  "passing_score": 85,
  "critical_checks_must_pass": true,
  "failure_action": "regenerate_adaptations"
}
```

#### Phase 6: Assessment Creation Quality Gate

```json
{
  "quality_criteria": {
    "answer_key_quality": {
      "weight": 35,
      "checks": [
        {
          "criterion": "Answers are complete",
          "requirement": "All questions answered",
          "points": 15,
          "critical": true
        },
        {
          "criterion": "Answers are accurate",
          "requirement": "Correct information",
          "points": 15,
          "critical": true
        },
        {
          "criterion": "Explanations provided",
          "requirement": "Why answers are correct",
          "points": 5
        }
      ]
    },
    "rubric_quality": {
      "weight": 35,
      "checks": [
        {
          "criterion": "Has 3-6 criteria",
          "requirement": "Appropriate number of criteria",
          "points": 5
        },
        {
          "criterion": "4-point scale used",
          "requirement": "Exemplary → Beginning",
          "points": 10,
          "critical": true
        },
        {
          "criterion": "Descriptors are measurable",
          "requirement": "Specific, observable behaviors",
          "points": 15
        },
        {
          "criterion": "Points clearly indicated",
          "requirement": "Total points shown",
          "points": 5
        }
      ]
    },
    "self_assessment_quality": {
      "weight": 30,
      "checks": [
        {
          "criterion": "Has 3-7 questions",
          "requirement": "Appropriate number",
          "points": 10
        },
        {
          "criterion": "Promotes metacognition",
          "requirement": "Encourages reflection",
          "points": 10
        },
        {
          "criterion": "Aligned with objectives",
          "requirement": "References learning goals",
          "points": 10
        }
      ]
    }
  },
  "passing_score": 85,
  "critical_checks_must_pass": true,
  "failure_action": "regenerate_assessments"
}
```

#### Phase 7: Final Quality Verification Gate

```json
{
  "quality_criteria": {
    "overall_completeness": {
      "weight": 25,
      "checks": [
        {
          "criterion": "All activities complete",
          "requirement": "100% have all components",
          "points": 10,
          "critical": true
        },
        {
          "criterion": "No placeholders",
          "requirement": "No TODO, [INSERT], etc.",
          "points": 10,
          "critical": true
        },
        {
          "criterion": "Supplementary materials included",
          "requirement": "Vocabulary, sequence, parent letter",
          "points": 5
        }
      ]
    },
    "pedagogical_alignment": {
      "weight": 25,
      "checks": [
        {
          "criterion": "Objectives → activities alignment",
          "requirement": "Activities achieve stated objectives",
          "points": 15
        },
        {
          "criterion": "Difficulty progression",
          "requirement": "Logical scaffolding",
          "points": 10
        }
      ]
    },
    "accessibility": {
      "weight": 25,
      "checks": [
        {
          "criterion": "All disabilities adapted",
          "requirement": "Requested adaptations present",
          "points": 15
        },
        {
          "criterion": "Materials are accessible",
          "requirement": "Commonly available",
          "points": 10
        }
      ]
    },
    "diversity": {
      "weight": 25,
      "checks": [
        {
          "criterion": "Activity type variety",
          "requirement": "Good spread across types",
          "points": 10
        },
        {
          "criterion": "Modality balance",
          "requirement": "All 4 modalities represented",
          "points": 10
        },
        {
          "criterion": "Bloom's coverage",
          "requirement": "Multiple cognitive levels",
          "points": 5
        }
      ]
    }
  },
  "minimum_score_required": 80,
  "minimum_per_category": 70,
  "critical_checks_must_pass": true,
  "failure_action": "reject_pack_fix_issues_or_regenerate"
}
```

### Quality Gate Actions

```typescript
type QualityGateAction =
  | 'pass' // Continue to next phase
  | 'retry_same_model' // Retry with same model, adjusted parameters
  | 'retry_fallback_model' // Use fallback model
  | 'regenerate_component' // Regenerate specific component
  | 'manual_review' // Flag for human review
  | 'reject_pack'; // Fail entire pack generation

interface QualityGateResult {
  passed: boolean;
  score: number;
  category_scores: {
    [category: string]: number;
  };
  failed_checks: FailedCheck[];
  critical_failures: boolean;
  recommended_action: QualityGateAction;
  retry_count: number;
}

interface FailedCheck {
  criterion: string;
  required: string;
  actual: string;
  severity: 'critical' | 'major' | 'minor';
}
```

---

## 10. COMPLETE AI PROMPTS

### Phase 1: Content Analysis Prompt

```markdown
# ROLE
You are an expert educational content analyst specializing in extracting learning objectives and key concepts from educational materials.

# TASK
Analyze the provided book content and create a comprehensive concept map that will guide activity creation.

# INPUT DATA
- Book Title: {{book_title}}
- Subject Area: {{subject}}
- Target Grade Level: {{grade_level}}
- Content Scope: {{scope}}
- Book Content: {{content_text}}

# ANALYSIS REQUIREMENTS

## 1. Key Concepts Extraction
Identify and categorize all major concepts:
- Primary concepts (must-know)
- Secondary concepts (should-know)
- Tertiary concepts (nice-to-know)
- Prerequisite concepts (assumed knowledge)

## 2. Learning Objectives
For each key concept, generate:
- Knowledge objectives (what students should know)
- Skill objectives (what students should be able to do)
- Application objectives (how students will use this)

## 3. Difficulty Assessment
Evaluate each concept:
- Cognitive complexity (1-5 scale)
- Abstract vs. concrete
- Prior knowledge required
- Common misconceptions

## 4. Activity Potential Analysis
For each concept, identify:
- Which learning modalities suit it best
- Which activity types would work well
- Real-world applications
- Cross-curricular connections

## 5. Vocabulary Analysis
Extract and categorize:
- Tier 1 vocabulary (common words)
- Tier 2 vocabulary (academic words)
- Tier 3 vocabulary (domain-specific terms)

# OUTPUT FORMAT
```json
{
  "content_analysis": {
    "key_concepts": [
      {
        "concept_id": "string",
        "concept_name": "string",
        "category": "primary|secondary|tertiary",
        "description": "string (min 50 chars)",
        "cognitive_complexity": 1-5,
        "bloom_levels_applicable": ["remember", "understand", "apply"],
        "best_modalities": ["visual", "kinesthetic"],
        "suggested_activity_types": ["experiment", "diagram"],
        "real_world_connections": ["example1", "example2"],
        "common_misconceptions": ["misconception1"],
        "prerequisite_concepts": ["concept_name"]
      }
    ],
    "learning_objectives": {
      "knowledge_objectives": ["Students will know..."],
      "skill_objectives": ["Students will be able to..."],
      "application_objectives": ["Students will apply..."]
    },
    "vocabulary": {
      "tier_1": [{"word": "word", "context": "context"}],
      "tier_2": [{"word": "word", "definition": "def"}],
      "tier_3": [{"word": "word", "definition": "def", "importance": "high"}]
    },
    "content_structure": {
      "main_topics": ["Topic 1", "Topic 2"],
      "topic_relationships": [{"topic_a": "A", "relationship": "precedes", "topic_b": "B"}],
      "narrative_flow": "Description of how content flows"
    }
  }
}
```

# QUALITY REQUIREMENTS
- Minimum 5 key concepts
- Each concept must have description >= 50 characters
- Minimum 10 vocabulary terms total
- All difficulty ratings must use 1-5 scale
- No placeholder or generic content

# BEGIN ANALYSIS
```

### Phase 2: Activity Ideation Prompt

```markdown
# ROLE
You are a creative educator with 15+ years of experience creating engaging learning activities for diverse learners.

# TASK
Generate {{target_count * 1.5 to 2}} diverse, creative activity ideas based on the content analysis provided.

# INPUT DATA
- Content Analysis: {{content_analysis}}
- Target Age: {{min_age}}-{{max_age}}
- Target Activities: {{total_activities}}
- Difficulty Distribution: {{easy}}% easy, {{medium}}% medium, {{hard}}% hard
- Required Bloom's Levels: {{blooms_levels}}

# GENERATION GUIDELINES

## Diversity Requirements
Generate activities across:
- Paper-based (20-30%): worksheets, organizers, journals
- Interactive (15-25%): games, role-plays, simulations
- Creative (15-20%): art, writing, design
- Collaborative (10-20%): discussions, group projects
- Technology (5-15%): research, multimedia
- Kinesthetic (10-15%): experiments, building

## Bloom's Taxonomy Balance
- Remember: 15-20%
- Understand: 25-30%
- Apply: 20-25%
- Analyze: 15-20%
- Evaluate: 10-15%
- Create: 10-15%

## Time Distribution
- Quick (5-15 min): 30%
- Standard (15-30 min): 50%
- Extended (30-45 min): 20%

## Engagement Factors
Each activity must have at least 2 of:
- Choice/autonomy
- Appropriate challenge
- Real-world connection
- Creativity opportunity
- Collaboration
- Movement
- Novelty

# ACTIVITY IDEA TEMPLATE
For each idea, provide:
```json
{
  "idea_id": "unique_id",
  "working_title": "Catchy, descriptive title",
  "activity_type": "specific_type",
  "one_sentence_description": "Clear description (20-200 chars)",
  "learning_objective": "What students will learn",
  "bloom_level": "understand",
  "modality": "visual",
  "difficulty": "medium",
  "estimated_time": 25,
  "grouping": "individual",
  "materials_needed_brief": ["item1", "item2"],
  "engagement_hooks": ["hook1", "hook2"],
  "key_concept_addressed": "concept_name",
  "innovation_factor": "What makes this unique",
  "potential_challenges": ["challenge1"],
  "why_this_works": "Pedagogical rationale"
}
```

# CREATIVITY GUIDELINES

✅ DO Generate:
- Activities making abstract concepts concrete
- Activities incorporating student interests
- Activities with clear products/outcomes
- Activities building on prior knowledge
- Activities with real-world relevance

❌ DO NOT Generate:
- Busy work
- Activities requiring expensive materials
- Activities with unclear objectives
- Just textbook problems
- Culturally insensitive content

# QUALITY REQUIREMENTS
- Generate {{target_count * 1.5}} to {{target_count * 2}} ideas
- Minimum 12 different activity types
- All 4 modalities represented
- All requested Bloom's levels represented
- Each idea is unique (no duplicates)
- Each description is 20-200 characters

# BEGIN IDEATION
Generate creative activity ideas now.
```

### Phase 4: Detailed Activity Development Prompt

```markdown
# ROLE
You are a master teacher creating complete, ready-to-use classroom activities. Your activities are known for clarity, completeness, and effectiveness.

# TASK
Develop ONE complete activity with all necessary components, ready for immediate classroom use without any modifications.

# INPUT DATA
- Activity Concept: {{activity_idea}}
- Book Content: {{book_content}}
- Target Audience: Age {{min_age}}-{{max_age}}, {{reading_level}}
- Standards: {{standards}}

# REQUIRED COMPONENTS

You MUST include ALL 9 components:

## 1. Activity Header
- Title (5-100 chars, clear and engaging)
- Activity type
- Duration (realistic estimate)
- Difficulty level
- Bloom's level
- Learning modality
- Grouping (individual/pairs/group/class)

## 2. Learning Objectives (2-5 objectives)
Format: "By the end of this activity, you will be able to [Bloom's verb] [specific object]"

Bloom's verbs by level:
- Remember: define, identify, list, recall, recognize
- Understand: describe, explain, summarize, paraphrase
- Apply: demonstrate, solve, use, apply, implement
- Analyze: compare, examine, categorize, differentiate
- Evaluate: judge, critique, justify, assess, evaluate
- Create: design, compose, develop, construct, create

## 3. Materials Needed
List with:
- Item name
- Quantity per student (specific)
- Required vs. optional
- Approximate cost (if > $1)

Format: "Item (quantity) - Required/Optional - $X"

## 4. Teacher Preparation
- Prep time estimate
- Setup steps (numbered, with time estimates)
- Printables needed

## 5. Step-by-Step Instructions

For EACH step include:

**Step [X]: [Step Name] ([X] minutes)**

*What students do:*
[Clear, specific instructions in student-friendly language. Start with action verb.]

*What teachers do:*
[Teacher actions, monitoring strategies, questions to ask students]

*Success indicators:*
[Observable behaviors showing students are on track]

*Common issues & solutions:*
- Issue: [specific problem]
  Solution: [specific fix]

## 6. Real-World Connections
- At least 2 real-world applications
- Specific examples of how this is used
- Career connections if applicable

## 7. Cross-Curricular Links
Format:
- Subject: [specific connection]

Include at least 2 different subjects.

## 8. Teaching Tips
- Before: [preparation tips]
- During: [implementation tips]
- After: [follow-up tips]

Include at least 3 tips total.

## 9. Home Connection
[Activity families can do at home to reinforce learning. Must be specific and actionable.]

# OUTPUT FORMAT
Provide complete activity in structured JSON format.

# QUALITY REQUIREMENTS

✅ Must Have:
- All 9 components present (no exceptions)
- No placeholder content (no "TODO", "[INSERT]", etc.)
- Instructions are numbered sequentially
- Time estimates for all steps
- Materials are specific (not "various supplies")
- Language matches target age
- Clear success criteria
- Objectives use correct Bloom's verbs
- Total time estimate is realistic

❌ Must NOT Have:
- Vague instructions
- Unsafe activities
- Expensive materials (>$10 total)
- Culturally insensitive content
- Placeholder text
- Generic statements

# TESTING CRITERIA
Before returning, verify:
1. Can a substitute teacher run this activity with zero prep?
2. Are instructions clear enough for students to work independently?
3. Is every material listed and quantified?
4. Are all 9 components present?
5. Is the language age-appropriate?
6. Is the time estimate realistic?
7. Will students achieve the learning objectives?

# BEGIN DEVELOPMENT
Create the complete activity now. Output as structured JSON.
```

### Phase 5: Disability Adaptations Prompt

```markdown
# ROLE
You are a special education specialist with expertise in Universal Design for Learning (UDL) and disability accommodations across multiple categories.

# TASK
For the provided activity, create specific, actionable adaptations for each requested disability type. Adaptations must maintain rigor while removing barriers.

# INPUT DATA
- Complete Activity: {{activity}}
- Disabilities to Adapt For: {{disabilities_list}}

# ADAPTATION PRINCIPLES

## Core Principles
1. **Maintain Rigor**: Adapt access, not standards
2. **Be Specific**: Reference specific activity components
3. **Be Actionable**: Teachers can implement immediately
4. **Multiple Options**: Provide 3-7 adaptations per disability
5. **Preserve Objectives**: Learning goals remain achievable

## UDL Framework
- Multiple Means of Representation (how information is presented)
- Multiple Means of Action & Expression (how students demonstrate learning)
- Multiple Means of Engagement (how students stay motivated)

# DISABILITY-SPECIFIC GUIDELINES

## Visual Impairments (Blind/Low Vision)
Focus on:
- Text-to-speech compatibility
- Large print options (18pt+)
- High contrast (4.5:1 minimum)
- Tactile alternatives
- Audio descriptions
- Braille options if applicable

## Hearing Impairments (Deaf/Hard of Hearing)
Focus on:
- Visual alternatives to audio
- Written instructions
- Visual timers
- Sign language support
- Captions/transcripts
- Vibrating timers

## Motor Impairments
Focus on:
- Alternative input methods
- Adaptive tools (pencil grips, scissors)
- Digital alternatives
- Reduced writing requirements
- Positioning supports
- Partner assistance options

## Cognitive Disabilities (Intellectual Disability)
Focus on:
- Simplified language (shorter sentences)
- Chunking information
- Visual supports
- Concrete examples
- Increased repetition
- Reduced choices

## Learning Disabilities

### Dyslexia
- Dyslexia-friendly fonts (OpenDyslexic, Arial, Verdana)
- Increased line spacing (1.5+)
- Audio alternatives
- Color overlays
- No justified text
- Extended time

### Dyscalculia
- Visual math aids
- Number lines
- Calculator allowed
- Manipulatives
- Graph paper
- Step-by-step breakdowns

### Dysgraphia
- Typing alternatives
- Oral responses
- Voice-to-text
- Reduced writing
- Graphic organizers
- Scribe options

## Attention Disorders (ADHD)
Focus on:
- Break tasks into smaller chunks
- Fidget tools allowed
- Movement breaks
- Clear visual structure
- Timers and checklists
- Reduced visual clutter
- Designated quiet space

## Autism Spectrum

### Level 1 (Requiring Support)
- Clear expectations (written)
- Visual schedules
- Social scripts
- Predictable routines
- Explicit instructions
- Choice boards

### Level 2 (Requiring Substantial Support)
- Simplified language
- Picture supports
- Task breakdowns
- Sensory accommodations
- Visual timers
- Communication supports

### Level 3 (Requiring Very Substantial Support)
- Heavy visual supports
- Picture Exchange Communication System (PECS)
- Sensory modifications
- One-step directions
- Physical prompts
- Individualized materials

## Processing Disorders

### Visual Processing
- Reduce visual complexity
- Clear fonts (sans-serif)
- Ample white space
- Color coding
- Verbal explanations
- Simplified graphics

### Auditory Processing
- Written instructions
- Visual supports
- Quiet environment
- Slow pace
- Frequent checks
- Visual schedule

## Executive Function Deficits
Focus on:
- Clear step-by-step process
- Checklists
- Organizational tools
- Time management supports
- Visual reminders
- Planning templates

# OUTPUT FORMAT

For EACH disability type, provide:

```json
{
  "disability_type": "name",
  "adaptations": [
    {
      "adaptation_number": 1,
      "adaptation_description": "Specific, actionable adaptation (min 30 chars)",
      "component_modified": "which part of activity this affects",
      "implementation_notes": "how teacher implements this",
      "maintains_objective": "how this preserves learning goals",
      "udl_principle": "representation|action|engagement"
    }
  ],
  "alternative_assessment": {
    "description": "Alternative way to demonstrate learning",
    "maintains_rigor": true,
    "measures_same_objective": "explanation"
  }
}
```

# QUALITY REQUIREMENTS

✅ Must Have:
- 3-7 adaptations per disability
- Each adaptation is specific (not "provide accommodations")
- Each adaptation references specific activity components
- Each adaptation is immediately implementable
- Alternative assessment option provided
- Rigor is maintained

❌ Must NOT Have:
- Generic statements ("see teacher for help")
- Just "allow extra time" (too vague)
- Adaptations that lower standards
- Adaptations that oversimplify content
- Adaptations requiring expensive equipment
- Vague suggestions

# VALIDATION CHECKLIST

Before returning, verify:
1. All requested disabilities have adaptations?
2. Each disability has 3-7 specific adaptations?
3. Each adaptation is actionable (can be implemented immediately)?
4. Adaptations reference specific activity components?
5. Learning objectives remain achievable?
6. No generic "see teacher" cop-outs?
7. Alternative assessments are equivalent in rigor?

# BEGIN ADAPTATION DEVELOPMENT
Create specific, actionable adaptations now. Output as structured JSON.
```

### Phase 6: Assessment Creation Prompt

```markdown
# ROLE
You are an assessment design expert specializing in creating fair, valid, and reliable assessments that accurately measure learning.

# TASK
For the provided activity, create:
1. Complete answer key
2. Detailed rubric with measurable criteria
3. Self-assessment questions for students

# INPUT DATA
- Complete Activity: {{activity_with_adaptations}}
- Learning Objectives: {{objectives}}
- Activity Type: {{activity_type}}

# ASSESSMENT REQUIREMENTS

## 1. Answer Key

### Format
- Provide complete answers for all questions/tasks
- Include explanations for why answers are correct
- Show work for problem-solving tasks
- Provide sample responses for open-ended questions
- Note acceptable variations in answers

### Quality Criteria
- Accuracy: 100% correct
- Completeness: All questions answered
- Clarity: Explanations are clear
- Usefulness: Teachers can grade confidently

## 2. Rubric

### Structure
- 3-6 criteria (based on learning objectives)
- 4-point scale (Exemplary, Proficient, Developing, Beginning)
- Point values assigned
- Specific, measurable descriptors

### Criterion Guidelines
Each criterion must:
- Align with a learning objective
- Have 4 distinct performance levels
- Use observable, measurable language
- Avoid subjective terms ("good", "nice")
- Be independent of other criteria

### Descriptor Requirements

**Exemplary (4 points)**
- Exceeds standard
- Shows depth of understanding
- Includes extensions
- Observable behaviors listed

**Proficient (3 points)**
- Meets standard fully
- Shows adequate understanding
- Completes all requirements
- Observable behaviors listed

**Developing (2 points)**
- Partially meets standard
- Shows partial understanding
- Completes some requirements
- Observable behaviors listed

**Beginning (1 point)**
- Does not meet standard
- Shows minimal understanding
- Minimal completion
- Observable behaviors listed

### Example Rubric Criterion

**Criterion: Content Accuracy**
- Exemplary (4): All key concepts accurately explained with 3+ supporting details. No errors. Includes examples beyond what was taught.
- Proficient (3): All key concepts accurately explained with 1-2 supporting details. Minor errors present but don't affect understanding.
- Developing (2): Some key concepts explained accurately. Multiple errors or missing details. Understanding is incomplete.
- Beginning (1): Few or no concepts explained accurately. Major errors present. Minimal understanding demonstrated.

## 3. Self-Assessment Questions

### Purpose
- Promote metacognition
- Encourage student reflection
- Support growth mindset
- Connect to learning objectives

### Question Types
Include mix of:
- Completion checks ("Did I...?")
- Understanding checks ("Can I explain...?")
- Application checks ("Could I use this to...?")
- Reflection prompts ("What was challenging...?")
- Goal-setting prompts ("Next time I will...?")

### Quality Criteria
- 3-7 questions total
- Written at student reading level
- Reference learning objectives
- Promote genuine reflection
- Are answerable by students
- Encourage growth mindset

# OUTPUT FORMAT

```json
{
  "answer_key": {
    "format": "structured_answers",
    "answers": [
      {
        "question_number": 1,
        "correct_answer": "Answer text or description",
        "explanation": "Why this is correct",
        "common_errors": ["Common mistake 1", "Common mistake 2"],
        "partial_credit_notes": "If applicable"
      }
    ],
    "sample_responses": {
      "exemplary": "Example of excellent work",
      "proficient": "Example of adequate work"
    }
  },

  "rubric": {
    "criteria": [
      {
        "criterion_name": "Name (aligns with objective)",
        "point_value": 4,
        "levels": {
          "exemplary": {
            "points": 4,
            "descriptor": "Specific, observable, measurable description"
          },
          "proficient": {
            "points": 3,
            "descriptor": "Specific, observable, measurable description"
          },
          "developing": {
            "points": 2,
            "descriptor": "Specific, observable, measurable description"
          },
          "beginning": {
            "points": 1,
            "descriptor": "Specific, observable, measurable description"
          }
        }
      }
    ],
    "total_points": "Sum of all criterion point values",
    "scoring_notes": "How to apply rubric fairly"
  },

  "self_assessment": {
    "instructions": "How students should use these questions",
    "questions": [
      {
        "question": "Self-assessment question text",
        "type": "completion_check|understanding|application|reflection|goal_setting",
        "objective_alignment": "Which learning objective this connects to"
      }
    ]
  }
}
```

# QUALITY REQUIREMENTS

✅ Answer Key Must Have:
- 100% accuracy
- All questions/tasks addressed
- Explanations included
- Sample responses for open-ended items
- Common errors noted

✅ Rubric Must Have:
- 3-6 criteria
- 4-point scale (Exemplary → Beginning)
- Specific, measurable descriptors for each level
- Criteria align with learning objectives
- Total points clearly indicated
- No subjective language

✅ Self-Assessment Must Have:
- 3-7 questions
- Age-appropriate language
- Promotes metacognition
- References learning objectives
- Variety of question types

❌ Must NOT Have:
- Incorrect answers
- Vague rubric descriptors ("good", "nice")
- Subjective criteria
- Generic self-assessment questions
- "Answers may vary" without guidance

# VALIDATION CHECKLIST

Before returning, verify:
1. Answer key is 100% accurate?
2. All questions/tasks have answers?
3. Rubric has 3-6 criteria?
4. Each criterion has 4 distinct levels?
5. Descriptors are specific and measurable?
6. Total points are indicated?
7. Self-assessment has 3-7 questions?
8. Self-assessment promotes reflection?
9. All components align with learning objectives?

# BEGIN ASSESSMENT CREATION
Create complete assessment materials now. Output as structured JSON.
```

---

## 11. IMPLEMENTATION GUIDE

### System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     User Interface                          │
│  (Activity Pack Request Form + Progress Tracking)          │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│                  Activity Pack Service                      │
│  - Request Validation                                       │
│  - Job Management                                           │
│  - Progress Updates                                         │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│                   AI Model Orchestrator                     │
│  - Model Selection                                          │
│  - Fallback Logic                                           │
│  - Retry Management                                         │
│  - Parallel Processing                                      │
└─────────────────────────────────────────────────────────────┘
                            ↓
        ┌──────────────────┴──────────────────┐
        ↓                  ↓                  ↓
┌──────────────┐  ┌──────────────┐  ┌──────────────┐
│   OpenAI     │  │  Anthropic   │  │  Google AI   │
│   (GPT-4o)   │  │  (Claude)    │  │  (Gemini)    │
└──────────────┘  └──────────────┘  └──────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│              Verification & Quality System                  │
│  - Data Validation                                          │
│  - Quality Scoring                                          │
│  - Visual Verification                                      │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│               File Generation Pipeline                      │
│  - PDF Generation (jsPDF / PDFKit)                         │
│  - DOCX Generation (docx.js)                               │
│  - File Upload (Supabase Storage)                          │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│                  Supabase Database                          │
│  - addon_content table                                      │
│  - addon_generation_jobs table                             │
│  - addon_features table                                     │
└─────────────────────────────────────────────────────────────┘
```

### Implementation Timeline

**Week 1-2: Foundation**
- Set up database schema (addon_generation_jobs, addon_content)
- Create TypeScript interfaces
- Implement request validation
- Set up job tracking system

**Week 3-4: AI Integration**
- Implement AI orchestration layer
- Create all 8 phase prompts
- Set up fallback logic
- Test with mock data

**Week 5-6: Core Generation**
- Implement Phases 1-3 (Analysis, Ideation, Selection)
- Add verification checks
- Test end-to-end for these phases

**Week 7-8: Activity Development**
- Implement Phase 4 (detailed development)
- Add parallel processing (4 concurrent activities)
- Implement quality gates

**Week 9-10: Enhancements**
- Implement Phase 5 (disability adaptations)
- Implement Phase 6 (assessments)
- Implement Phase 7 (quality verification)

**Week 11: File Generation**
- Set up PDF generation
- Set up DOCX generation
- Implement file upload to Supabase Storage
- Add visual verification

**Week 12: Testing & Polish**
- Unit tests (80% coverage)
- Integration tests
- End-to-end tests
- Performance optimization

**Week 13: Launch Prep**
- Beta testing with real users
- Bug fixes
- Documentation
- Production deployment

---

## 12. COST ANALYSIS

### Token Usage & Cost per Pack (20 Activities)

| Phase | Model | Input Tokens | Output Tokens | Cost |
|-------|-------|--------------|---------------|------|
| Phase 1 | Claude-3-5-Sonnet | 15,000 | 3,000 | $0.055 |
| Phase 2 | GPT-4o | 5,000 | 8,000 | $0.065 |
| Phase 3 | Gemini-2.0-Flash | 10,000 | 2,000 | $0.003 |
| Phase 4 (×20) | Claude-3-5-Sonnet | 160,000 | 80,000 | $2.20 |
| Phase 5 | Claude-3-5-Sonnet | 25,000 | 5,000 | $0.092 |
| Phase 6 | Claude-3-5-Sonnet | 20,000 | 10,000 | $0.185 |
| Phase 7 | Gemini-2.0-Flash | 30,000 | 3,000 | $0.008 |
| **TOTAL** | | **265,000** | **111,000** | **$2.61** |

### Total Cost per Pack

- AI Generation: $2.61
- Storage (5MB): $0.02
- Processing: $0.12
- Bandwidth: $0.05
- **Total Cost: $2.80**

### Pricing Strategy

**Single Pack**: $9.99 (257% markup, 72% margin)
**5-Pack Bundle**: $39.99 ($8.00 each, 186% markup)
**10-Pack Bundle**: $69.99 ($7.00 each, 150% markup)

---

## 13. TESTING REQUIREMENTS

### Unit Test Coverage

```typescript
describe('ActivityPackService', () => {
  describe('Request Validation', () => {
    it('should reject invalid age ranges');
    it('should reject difficulty distribution not summing to 100');
    it('should accept valid requests');
  });

  describe('Activity Generation', () => {
    it('should generate requested number of activities');
    it('should respect difficulty distribution');
    it('should include all requested Bloom levels');
  });

  describe('Quality Verification', () => {
    it('should reject low-quality outputs');
    it('should accept high-quality outputs');
  });
});
```

### Integration Tests

- Complete generation cycle (end-to-end)
- Parallel processing correctness
- Progress tracking in database
- File generation and storage
- Fallback system activation

---

## 14. APPROVAL STATUS

**Status**: 🟡 **DRAFT - AWAITING REVIEW**

**Submitted By**: System
**Submitted Date**: 2024-12-19
**Review Requested From**: Project Owner

### Approval Checklist

- [ ] All 8 phases have technical parameters
- [ ] AI model assignments are appropriate
- [ ] Fallback rules are comprehensive
- [ ] Verification integration is complete
- [ ] Input/Output specs are accurate
- [ ] Dependencies matrix is correct
- [ ] Quality gates are measurable
- [ ] Prompts are detailed and effective
- [ ] Implementation guide is clear
- [ ] Cost analysis is reasonable
- [ ] Testing requirements are adequate

### Decision

**Approved**: ☐ Yes ☐ No ☐ Conditional

**Conditions/Changes Required**:
```
[List any required changes]
```

**Reviewer Signature**: ________________
**Date**: ________________

---

**END OF COMPLETE TECHNICAL SPECIFICATION**
