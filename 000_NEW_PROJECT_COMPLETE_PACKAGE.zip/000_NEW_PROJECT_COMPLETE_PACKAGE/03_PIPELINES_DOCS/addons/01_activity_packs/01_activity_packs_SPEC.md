# Activity Packs - Implementation Spec

**Status**: Draft | **Feature ID**: ADDON-001 | **Category**: Student Materials

---

## OVERVIEW

Generates 15-30 pedagogically-sound activities per book/chapter with full instructions, materials, rubrics, answer keys, and disability adaptations.

**Value**: Saves teachers 10+ hours prep time per unit | Revenue: $9.99/pack | Cost: $2.80/pack (72% margin)

---

## INPUT

```typescript
interface ActivityPackRequest {
  book_id: string;
  content_scope: 'full_book' | 'chapter' | 'section';
  target_audience: {
    age_range: { min: 5-18, max: 5-18 };
    reading_level: 'elementary' | 'middle' | 'high' | 'college';
  };
  activity_preferences: {
    total_activities: 10-50; // default 20
    difficulty_dist: { easy: %, medium: %, hard: % }; // must sum to 100
    blooms_levels: ['understand', 'apply', 'analyze']; // required coverage
  };
  disability_adaptations?: ['dyslexia', 'adhd', 'autism_level1', ...];
  standards?: { framework: 'common_core' | 'ngss' | 'state' };
}
```

**Validation**: Age 5-18, difficulty sums to 100%, min 10 activities, max 50

---

## OUTPUT

```typescript
interface ActivityPackOutput {
  metadata: {
    pack_id: string;
    total_activities: number;
    estimated_time_minutes: number;
    standards_covered: string[];
  };
  pack_overview: {
    title: string;
    learning_objectives: string[];
    materials_needed: { required: string[], optional: string[] };
  };
  activities: Activity[]; // Array of 10-50 complete activities
  supplementary: {
    vocabulary_list: VocabularyTerm[];
    suggested_sequence: DailySequence[];
    parent_letter: string;
  };
  files: { pdf_files: File[], editable: File[] };
  quality_metrics: { overall_score: 0-100, warnings: string[] };
}

interface Activity {
  activity_id: string;
  title: string;
  type: 'word_search' | 'crossword' | 'concept_map' | 'experiment' | ...;
  difficulty: 'easy' | 'medium' | 'hard';
  blooms_level: 'remember' | 'understand' | 'apply' | 'analyze' | 'evaluate' | 'create';
  modality: 'visual' | 'auditory' | 'kinesthetic' | 'reading_writing';
  time_minutes: number;
  grouping: 'individual' | 'pairs' | 'small_group' | 'whole_class';
  objectives: string[];
  materials: Material[];
  instructions: { student: Step[], teacher_notes: string[] };
  content: any; // varies by activity type
  assessment: { answer_key: any, rubric: Rubric, self_check: string[] };
  differentiation: {
    scaffolds: string[];
    extensions: string[];
    disability_mods: { [disability]: string[] };
  };
}
```

---

## AI CONSENSUS GENERATION PIPELINE

### Phase 1: Content Analysis (3 AIs - Research)
**Models**: Claude-3.5-Sonnet, GPT-4o, Gemini-Pro
**Task**: Extract concepts, objectives, vocabulary, difficulty levels
**Consensus**: Merge 3 analyses into unified concept map
**Time**: 15 sec | **Cost**: $0.15

### Phase 2: Activity Ideation (5 AIs - Creative)
**Models**: GPT-4o, Claude-3.5-Sonnet, DeepSeek-V3, Gemini-Flash, Perplexity
**Task**: Each generates 30-40 diverse activity ideas
**Consensus**: Vote on best 20-25 ideas (60% agreement required)
**Time**: 20 sec | **Cost**: $0.35

### Phase 3: Detailed Development (4 AIs per activity - Parallel)
**Models**: Claude-3.5-Sonnet (primary), GPT-4o, Gemini-Pro, Claude-Opus
**Task**: Each AI develops complete activity with all components
**Consensus**: Merge best elements from 4 versions
**Parallelization**: Process 4 activities simultaneously
**Time**: 90 sec for 20 activities | **Cost**: $1.80

### Phase 4: Disability Adaptation (3 AIs - Specialized)
**Models**: Claude-3.5-Sonnet, GPT-4o, Cohere-Command-R+
**Task**: Add modifications for each requested disability
**Consensus**: Combine unique accommodations from all 3
**Time**: 30 sec | **Cost**: $0.25

### Phase 5: Quality Verification (12 AIs - Full Consensus)
**Models**: All 12 from consensus system
**Task**: Verify pedagogy, safety, accuracy, age-appropriateness
**Consensus**: 90% agreement required (11/12 models)
**Time**: 10 sec | **Cost**: $0.40

### Phase 6: File Generation (System)
**Task**: Generate PDFs (complete, student-only, teacher-only), DOCX
**Time**: 20 sec | **Cost**: $0.05

**TOTAL TIME**: ~3 minutes | **TOTAL COST**: $3.00

---

## CONSENSUS INTEGRATION

```typescript
import { runConsensusVerification } from '../lib/aiConsensus';
import { consensusEngine } from '../lib/multiAIConsensus';

// Phase 1: Content Analysis with multiple AIs
const analysisResponses = await Promise.all([
  callClaude(analysisPrompt),
  callGPT4o(analysisPrompt),
  callGemini(analysisPrompt)
]);

const analysisConsensus = await consensusEngine.generateWithConsensus(
  analysisPrompt,
  { minAIs: 3, consensusThreshold: 0.75 },
  analysisResponses
);

// Phase 3: Develop activities in parallel with consensus
const activityDevelopments = await Promise.all(
  selectedActivities.map(async (activityIdea) => {
    const responses = await Promise.all([
      callClaude(developPrompt),
      callGPT4o(developPrompt),
      callGemini(developPrompt),
      callOpus(developPrompt)
    ]);

    return consensusEngine.generateWithConsensus(
      developPrompt,
      { minAIs: 4, consensusThreshold: 0.70 },
      responses
    );
  })
);

// Phase 5: Quality verification with all 12 models
const qualityCheck = await runConsensusVerification({
  contentId: packId,
  contentType: 'activity_pack',
  verificationType: 'quality',
  content: JSON.stringify(activityPack),
  requiredThreshold: 90 // 90% = 11/12 models must approve
});

if (!qualityCheck.passed) {
  // Refine based on consensus issues
  await refineActivities(qualityCheck.consensusIssues);
}
```

---

## KEY PROMPTS

### Phase 1: Content Analysis
```
Analyze this book content and extract:
1. Key concepts (primary/secondary/tertiary)
2. Learning objectives (knowledge/skill/application)
3. Vocabulary (Tier 1/2/3)
4. Difficulty levels (by concept)
5. Activity type suggestions (by concept)

Output: JSON with concepts, objectives, vocab, suggestions
```

### Phase 2: Activity Ideation
```
Generate 35 diverse activity ideas for:
- Content: {{concepts}}
- Age: {{age_range}}
- Requirements: {{blooms_levels}}, {{difficulty_dist}}

Ensure variety across:
- Activity types (20 different types)
- Bloom's levels (balanced distribution)
- Learning modalities (VARK)
- Time ranges (5-45 min)

Output: Array of activity ideas with metadata
```

### Phase 3: Detailed Development
```
Develop ONE complete activity from this idea:
{{activity_idea}}

Include ALL components:
- Clear title and learning objectives
- Complete materials list
- Step-by-step instructions (student + teacher)
- Activity content (specific to type)
- Answer key + rubric
- Scaffolds and extensions

Output: Complete Activity object
```

### Phase 4: Disability Adaptation
```
Add disability modifications for: {{disabilities}}

For each activity, provide:
- 3-5 specific accommodations per disability
- Evidence-based strategies
- Maintain learning objectives

Output: Updated activities with disability_mods filled
```

### Phase 5: Quality Verification
```
Evaluate this activity pack on:
1. Pedagogical soundness (0-100)
2. Safety (0-100)
3. Accuracy (0-100)
4. Age appropriateness (0-100)
5. Engagement (0-100)
6. Accessibility (0-100)
7. Completeness (0-100)

Identify issues and suggest improvements.
Pass if overall score ≥ 90.
```

---

## TESTING

```typescript
describe('Activity Pack Generation', () => {
  it('should complete in under 5 minutes', async () => {
    const result = await generateActivityPack(validRequest);
    expect(result.metadata.total_activities).toBe(20);
  }, 300000);

  it('should use multi-AI consensus', async () => {
    // Verify consensus system is called
    expect(consensusEngine.generateWithConsensus).toHaveBeenCalled();
  });

  it('should meet 90% quality threshold', async () => {
    const result = await generateActivityPack(validRequest);
    expect(result.quality_metrics.overall_score).toBeGreaterThanOrEqual(90);
  });

  it('should include all disability adaptations', async () => {
    const request = { ...validRequest, disability_adaptations: ['dyslexia', 'adhd'] };
    const result = await generateActivityPack(request);

    result.activities.forEach(activity => {
      expect(activity.differentiation.disability_mods).toHaveProperty('dyslexia');
      expect(activity.differentiation.disability_mods).toHaveProperty('adhd');
    });
  });
});
```

---

## COST & PRICING

**Generation Cost**: $3.00 per pack
**Storage**: $0.02 (5MB)
**Processing**: $0.12
**Total Cost**: $3.14

**Pricing**:
- Single: $9.99 (68% margin)
- 5-pack: $39.99 ($8 each, 20% off)
- 10-pack: $69.99 ($7 each, 30% off)
- Unlimited: $29.99/month

**Break-even**: 5,415 packs (@ $17k dev cost)

---

## IMPLEMENTATION

**Week 1-2**: Database schema, TypeScript interfaces, validation
**Week 3-4**: AI orchestration, consensus integration, prompts
**Week 5-6**: Phase 1-2 (analysis + ideation)
**Week 7-8**: Phase 3-4 (development + adaptation)
**Week 9**: Phase 5-6 (verification + file generation)
**Week 10**: Testing (unit, integration, E2E)
**Week 11**: Polish (UI, error handling, docs)
**Week 12**: Beta + launch

---

## APPROVAL

**Status**: 🟡 DRAFT - AWAITING REVIEW

- [ ] Input/output schemas approved
- [ ] AI consensus approach validated
- [ ] Cost model acceptable
- [ ] Timeline realistic

**Approved**: ☐ Yes | **Date**: _______ | **Signature**: _______

---

**END SPEC** - 150 lines vs 743 lines ✓
