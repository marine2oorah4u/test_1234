# Elementary Hands-On Science Activities

**Addon Type:** Activity Packs
**Category:** Science
**Subcategory:** Hands-On Experiments
**Target Audience:** Elementary (Grades 3-5)
**Difficulty Level:** Beginner to Intermediate
**Estimated Quantity:** 125 activities per science topic

---

## 📋 DESCRIPTION

This addon specification generates 125 hands-on science activities specifically designed for elementary students (grades 3-5). Each activity emphasizes safe, engaging, practical experiments that can be conducted with commonly available materials. Activities are designed to build scientific thinking, observation skills, and curiosity while meeting age-appropriate safety standards.

**What This Generates:**
- 125 complete activity instructions
- Step-by-step procedures (4-8 steps each)
- Materials lists (all common, safe items)
- Safety guidelines for each activity
- Learning objectives (2-3 per activity)
- Assessment rubrics (simple 3-point scale)
- Expected outcomes and observations
- Discussion questions (3-5 per activity)
- Differentiation strategies (struggling, advanced, ELL, special needs)
- Real-world connections
- Extension activities

---

## 🧩 REQUIRED FEATURES (from 739 base features)

This spec uses **18 features** from the base feature library:

### **Research Phase:**
1. Feature #1: Pedagogical Research for Activities
2. Feature #2: Real-world Example Research
3. Feature #3: STEM Verification Research
4. Feature #4: Safety Checks and Guidelines

### **Generation Phase:**
5. Feature #8: Premium Activity Instructions
6. Feature #13: Hands-on Project Design
7. Feature #16: Experiment Protocol Writing
8. Feature #49: Real-World Connection Building

### **Verification Phase:**
9. Feature #18: Safety Verification Consensus (ALL 12 models)
10. Feature #19: Age-appropriateness Consensus (90%+ of 12 models)
11. Feature #20: Feasibility Verification Consensus
12. Feature #21: Materials Availability Verification
13. Feature #25: Learning Objectives Verification

### **Refinement Phase:**
14. Feature #30: Improve Based on Verification Feedback
15. Feature #33: Materials List Generation
16. Feature #37: Safety Guidelines Refinement

### **Polish Phase:**
17. Feature #40: Final Readability Check
18. Feature #42: Production-ready Preparation

---

## 🤖 AI MODEL ASSIGNMENTS

### **Research Phase (Features #1-4):**
- o4-mini-deep-research (pedagogical research)
- Perplexity Pro (current examples, safety data)
- Gemini Pro 1.5 (STEM fact verification)
- DeepSeek-V3 (safety protocol validation)

### **Generation Phase (Features #5, #13, #16, #49):**
- GPT-5 Pro (primary instruction writing)
- Claude 3.5 Sonnet (clarity and structure)
- Gemini Pro 1.5 (experiment protocols)
- Perplexity Pro (real-world connections)

### **Verification Phase (Features #18-25):**
- **ALL 12 AI MODELS** (consensus required)
- Safety must have 100% agreement
- Age-appropriateness requires 90%+ agreement
- Feasibility requires 90%+ agreement

### **Refinement Phase (Features #30, #33, #37):**
- GPT-5 Pro (instruction improvement)
- Claude 3.5 Sonnet (materials list optimization)
- DeepSeek-V3 (safety refinement)

### **Polish Phase (Features #40, #42):**
- Claude 3.5 Sonnet (final readability)
- Gemini Flash (quick verification)

---

## 📊 QUALITY THRESHOLDS

### **By Phase:**
- **Research:** 80% consensus among research models
- **Generation:** 75% consensus among generation models
- **Verification:** 90% consensus (100% for safety!)
- **Refinement:** 85% consensus
- **Polish:** 90% consensus

### **Specific Requirements:**
- **Safety:** 100% of all 12 models must approve (zero tolerance)
- **Age-appropriateness:** Minimum 90% of 12 models agree
- **Feasibility:** Minimum 90% agreement that activities are doable
- **Materials:** 100% agreement that materials are commonly available
- **Clarity:** Minimum 85% agreement that instructions are clear

---

## 📂 FILE FORMATS

Generated in the following formats:

### **Primary Formats:**
- **PDF (Print-Ready)** - High-quality, 300dpi, print-friendly layout
- **PDF (Digital)** - Optimized for screen reading, 150dpi, hyperlinked
- **DOCX (Editable)** - Microsoft Word format for teacher customization
- **HTML (Interactive)** - Web-based version with embedded videos/images

### **Accessibility Formats:**
- **EPUB 3.0** - E-reader compatible with accessibility features
- **Large Print PDF** - 18pt font minimum
- **High Contrast PDF** - For visual impairments
- **Plain Text** - Screen reader optimized

### **Specialized Formats:**
- **Individual Activity Cards** (PDF) - One activity per page for printing
- **Activity Poster Set** (PDF) - Large format visual instructions
- **Spanish Translation** (all formats)

---

## 💰 COST & TIME ESTIMATES

### **Per Science Topic (125 activities):**

**Cost Breakdown:**
- Research Phase: $2.50 (premium models)
- Generation Phase: $8.75 (125 activities × $0.07 each)
- Verification Phase: $5.00 (ALL 12 models × 125 items)
- Refinement Phase: $1.75
- Polish Phase: $0.75
- **Total Cost per Topic: ~$18.75**

**Time Breakdown:**
- Research Phase: 5 minutes
- Generation Phase: 25 minutes (125 activities)
- Verification Phase: 15 minutes (parallel processing)
- Refinement Phase: 8 minutes
- Polish Phase: 5 minutes
- File Format Generation: 10 minutes
- **Total Time per Topic: ~68 minutes**

### **Scaling:**
- **Per Book (20 topics):** $375 cost, ~23 hours
- **Per Subject (100+ books):** $37,500+ cost, ~115 days parallel processing

---

## 🎯 ACTIVITY STRUCTURE

Each of the 125 activities follows this structure:

```markdown
# Activity Title (Clear, Engaging)

**Grade Level:** 3-5
**Subject:** [Physics/Chemistry/Biology/Earth Science]
**Time Required:** 15-45 minutes
**Difficulty:** ⭐⭐ (2/5)
**Group Size:** Individual / Pairs / Small Group

## Learning Objectives
1. Students will [action verb] [concept]
2. Students will [action verb] [concept]
3. Students will [action verb] [concept]

## Materials Needed
- [ ] Item 1 (quantity)
- [ ] Item 2 (quantity)
- [ ] Item 3 (quantity)
[All items commonly available in classrooms or homes]

## Safety Guidelines
⚠️ [Clear, specific safety instructions]
✅ [Adult supervision requirements]
🧤 [Safety equipment if needed]

## Procedure
1. [Clear, numbered step]
2. [Clear, numbered step]
3. [Clear, numbered step]
[4-8 steps total]

## Expected Observations
- Students should observe [specific outcome]
- Students will notice [specific observation]
- Results may vary because [explanation]

## Discussion Questions
1. Why do you think [question]?
2. What would happen if [question]?
3. How does this connect to [real-world example]?

## Assessment Rubric (Simple 3-point scale)
- ⭐ Developing: [criteria]
- ⭐⭐ Proficient: [criteria]
- ⭐⭐⭐ Advanced: [criteria]

## Differentiation

**For Struggling Learners:**
- [Specific accommodation]
- [Specific accommodation]

**For Advanced Learners:**
- [Extension challenge]
- [Extension challenge]

**For ELL Students:**
- [Language support]
- [Visual support]

**For Special Needs:**
- [Accessibility modification]
- [Alternative approach]

## Real-World Connections
[How this activity connects to real life, careers, daily experiences]

## Extension Activities
1. [Related activity or investigation]
2. [Related activity or investigation]

## Cross-Curricular Links
- **Math:** [connection]
- **Language Arts:** [connection]
- **Social Studies:** [connection]

## Teacher Tips
💡 [Helpful tip for successful implementation]
💡 [Common pitfall to avoid]
```

---

## 🔬 EXAMPLE ACTIVITIES (Categories)

The 125 activities are distributed across:

**Physical Science (40 activities):**
- Simple machines
- Forces and motion
- Energy transfer
- Sound and light
- Magnetism and electricity

**Life Science (40 activities):**
- Plant biology
- Animal adaptations
- Ecosystems
- Human body systems
- Life cycles

**Earth Science (30 activities):**
- Weather and climate
- Rocks and minerals
- Water cycle
- Space and astronomy
- Environmental science

**General Scientific Skills (15 activities):**
- Observation and measurement
- Data collection and graphing
- Scientific method practice
- Hypothesis testing
- Scientific communication

---

## 📝 VERIFICATION CHECKLIST

Before marking this spec complete, verify:

### **Safety (100% Required):**
- [ ] Every activity reviewed by all 12 AI models for safety
- [ ] All materials are non-toxic and age-appropriate
- [ ] Clear supervision requirements stated
- [ ] Potential hazards identified and mitigated
- [ ] Emergency procedures included where needed

### **Age-Appropriateness (90%+ Required):**
- [ ] Language at 3rd-5th grade reading level
- [ ] Concepts appropriate for developmental stage
- [ ] Activities achievable in listed time
- [ ] Instructions clear without adult interpretation needed

### **Feasibility (90%+ Required):**
- [ ] All materials commonly available
- [ ] Activities possible in typical classroom
- [ ] Time estimates realistic
- [ ] No specialized equipment required

### **Educational Value:**
- [ ] Learning objectives are SMART (Specific, Measurable, Achievable, Relevant, Time-bound)
- [ ] Activities align with Next Generation Science Standards (NGSS)
- [ ] Assessment rubrics are clear and fair
- [ ] Differentiation supports all learners

### **Format Quality:**
- [ ] All file formats generated successfully
- [ ] Accessibility features work correctly
- [ ] Print versions are print-friendly
- [ ] Digital versions are interactive

---

## 🔗 RELATED SPECIFICATIONS

This spec connects to:
- **Worksheet Sets:** Science worksheets to accompany activities
- **Quiz Packs:** Pre/post assessments for activities
- **Answer Keys:** Expected results and explanations
- **Lesson Plans:** How to integrate activities into lessons
- **Study Guides:** Summarize concepts from activities

---

## 📅 UPDATE SCHEDULE

This specification should be reviewed/updated:
- **Safety Standards:** Annually (or when standards change)
- **Materials Availability:** Every 2 years
- **Educational Standards:** When NGSS or state standards update
- **Cost Estimates:** Annually
- **Real-World Examples:** Every 2 years (keep current)

---

## ✅ STATUS

- **Created:** December 21, 2025
- **Last Updated:** December 21, 2025
- **Status:** EXAMPLE SPECIFICATION
- **Approved:** Pending
- **Database Entry:** Pending

---

**This specification serves as the template for all elementary hands-on science activity pack generation. It defines the exact structure, quality standards, and AI model routing that should be used for this variation.**
