# Worksheet Sets - Complete Technical Specification

**Version**: 2.0
**Status**: Draft - Awaiting Approval
**Feature ID**: ADDON-002
**Category**: Student Practice Materials
**Complexity**: Medium-High
**Created**: 2024-12-19

---

## TABLE OF CONTENTS

1. [Overview](#1-overview)
2. [Step-by-Step Workflow](#2-step-by-step-workflow)
3. [AI Model Assignments](#3-ai-model-assignments)
4. [Technical Parameters](#4-technical-parameters)
5. [Fallback Rules](#5-fallback-rules)
6. [Verification Integration](#6-verification-integration)
7. [Input/Output Specs](#7-inputoutput-specs)
8. [Dependencies Matrix](#8-dependencies-matrix)
9. [Quality Gates](#9-quality-gates)
10. [Complete AI Prompts](#10-complete-ai-prompts)
11. [Cost Analysis](#11-cost-analysis)

---

## 1. OVERVIEW

### 1.1 What It Does

Generates comprehensive worksheet sets with practice problems, exercises, and reinforcement activities. Each set contains 10-30 worksheets covering different skill levels and question types, with complete answer keys and grading rubrics.

### 1.2 Purpose

**Problem**: Students need varied practice to master concepts. Teachers need ready-to-print worksheets that don't require hours of creation.

**Solution**: AI-generated worksheet sets that:
- Adapt to any subject or topic
- Scale difficulty across multiple levels
- Provide diverse question types
- Include complete answer keys
- Support differentiated instruction

### 1.3 Key Features

1. **Topic-Agnostic**: Works for any subject (math, science, language arts, history, etc.)
2. **Progressive Difficulty**: Easy → Medium → Hard progression
3. **Multiple Question Types**: Multiple choice, short answer, problem solving, etc.
4. **Print-Ready**: Professional formatting for immediate use
5. **Complete Answer Keys**: Detailed solutions with explanations

---

## 2. STEP-BY-STEP WORKFLOW

### Phase 1: Content Analysis & Skill Extraction
**Duration**: 5-10 seconds

#### Input Requirements
- Book content or chapter
- Target reading/skill level
- Subject area

#### Processing
- Extract key skills and concepts
- Identify prerequisite knowledge
- Map to difficulty levels
- Determine question types suitable for each skill

#### Output Deliverables
- List of skills to practice (10-30 skills)
- Difficulty rating per skill (1-5)
- Recommended question types per skill
- Prerequisite skill map

#### Success Criteria
- Minimum 10 skills identified
- Skills categorized by difficulty
- Question type recommendations provided
- No duplicate skills

---

### Phase 2: Worksheet Planning
**Duration**: 10-15 seconds

#### Input Requirements
- Skills from Phase 1
- Target worksheet count (e.g., 20)
- Difficulty distribution
- Question type preferences

#### Processing
- Organize skills into logical worksheet groups
- Assign difficulty levels to worksheets
- Determine question types per worksheet
- Calculate questions per worksheet (typically 8-15)

#### Output Deliverables
- Worksheet outline (one per worksheet)
- Skills covered per worksheet
- Question types per worksheet
- Difficulty progression plan

#### Success Criteria
- Logical skill grouping
- Clear difficulty progression
- Appropriate question distribution
- No skill gaps or overlaps

---

### Phase 3: Question Generation
**Duration**: 60-120 seconds (parallel)

#### Input Requirements
- Worksheet plans from Phase 2
- Book content for context
- Target audience details

#### Processing (Per Worksheet)
- Generate 8-15 questions per worksheet
- Create varied question formats
- Ensure appropriate difficulty
- Include visual elements if needed
- Generate instructions

#### Output Deliverables (Per Worksheet)
- Complete set of questions
- Clear instructions
- Answer spaces formatted
- Visual aids if applicable

#### Success Criteria (Per Worksheet)
- 8-15 questions generated
- Questions test target skills
- Difficulty is consistent
- Instructions are clear
- Professional formatting

---

### Phase 4: Answer Key Generation
**Duration**: 20-30 seconds

#### Input Requirements
- Complete worksheets from Phase 3
- Question types and formats

#### Processing
- Generate correct answers
- Create step-by-step solutions
- Add explanations for complex problems
- Note common errors
- Create grading guidance

#### Output Deliverables
- Complete answer key for all worksheets
- Solution steps shown
- Point values assigned
- Common error notes
- Grading rubrics

#### Success Criteria
- 100% answer accuracy
- All questions have answers
- Complex problems have solution steps
- Clear grading guidance
- Point values total correctly

---

### Phase 5: Quality Verification
**Duration**: 10-15 seconds

#### Input Requirements
- Complete worksheet set
- Answer keys

#### Processing
- Verify question quality
- Check answer accuracy
- Validate formatting
- Ensure difficulty progression
- Check for errors

#### Output Deliverables
- Quality score (0-100)
- List of issues found
- Validation results
- Recommendations

#### Success Criteria
- Quality score ≥ 85
- No critical errors
- Answer keys 100% accurate
- Professional appearance
- Print-ready formatting

---

### Phase 6: File Generation
**Duration**: 15-20 seconds

#### Input Requirements
- Validated worksheets
- Answer keys
- Format preferences

#### Processing
- Generate PDF files
- Create editable versions
- Apply professional styling
- Optimize for printing

#### Output Deliverables
- Student worksheets PDF
- Answer keys PDF
- Editable DOCX versions
- Storage URLs

#### Success Criteria
- All files generated successfully
- Professional formatting
- Print-optimized (300 DPI)
- Files accessible in storage

---

## 3. AI MODEL ASSIGNMENTS

```json
{
  "phase_1_skill_extraction": {
    "primary_model": "claude-3-5-sonnet-20241022",
    "rationale": "Excellent at analyzing educational content and extracting learning objectives",
    "estimated_tokens": {
      "input": 12000,
      "output": 2500
    }
  },

  "phase_2_worksheet_planning": {
    "primary_model": "gpt-4o",
    "rationale": "Good at organizational planning and logical grouping",
    "estimated_tokens": {
      "input": 4000,
      "output": 3000
    }
  },

  "phase_3_question_generation": {
    "primary_model": "claude-3-5-sonnet-20241022",
    "rationale": "Superior at creating clear, well-formatted educational questions",
    "estimated_tokens_per_worksheet": {
      "input": 6000,
      "output": 3000
    },
    "parallel_processing": {
      "concurrent_worksheets": 5,
      "batch_size": 5
    }
  },

  "phase_4_answer_keys": {
    "primary_model": "claude-3-5-sonnet-20241022",
    "rationale": "Accurate at solving problems and explaining solutions",
    "estimated_tokens": {
      "input": 30000,
      "output": 15000
    }
  },

  "phase_5_quality_verification": {
    "primary_model": "gemini-2.0-flash-exp",
    "rationale": "Fast verification, good at accuracy checking",
    "estimated_tokens": {
      "input": 40000,
      "output": 2000
    }
  }
}
```

---

## 4. TECHNICAL PARAMETERS

### Phase 1: Content Analysis & Skill Extraction

```json
{
  "technical_parameters": {
    "ai_model": "claude-3-5-sonnet-20241022",
    "temperature": 0.3,
    "max_tokens": 3500,
    "context_window_used": "~14K tokens",
    "timeout": 25000,
    "retry_attempts": 3,

    "quality_thresholds": {
      "min_skills_identified": 10,
      "max_skills_identified": 30,
      "skills_must_have_difficulty": true,
      "skills_must_have_description": true
    },

    "validation_rules": {
      "each_skill_has_name": true,
      "each_skill_has_difficulty_1_to_5": true,
      "each_skill_has_description_min_30_chars": true,
      "no_duplicate_skills": true,
      "prerequisite_map_present": true
    }
  }
}
```

### Phase 2: Worksheet Planning

```json
{
  "technical_parameters": {
    "ai_model": "gpt-4o",
    "temperature": 0.4,
    "max_tokens": 4000,
    "context_window_used": "~7K tokens",
    "timeout": 30000,
    "retry_attempts": 3,

    "quality_thresholds": {
      "worksheets_match_target_count": true,
      "difficulty_distribution_tolerance": 0.05,
      "questions_per_worksheet_min": 8,
      "questions_per_worksheet_max": 15
    },

    "validation_rules": {
      "each_worksheet_has_title": true,
      "each_worksheet_has_skills": true,
      "each_worksheet_has_question_types": true,
      "logical_skill_progression": true,
      "no_skill_gaps": true
    }
  }
}
```

### Phase 3: Question Generation

```json
{
  "technical_parameters": {
    "ai_model": "claude-3-5-sonnet-20241022",
    "temperature": 0.5,
    "max_tokens": 4000,
    "context_window_per_worksheet": "~9K tokens",
    "timeout_per_worksheet": 40000,
    "retry_attempts": 3,
    "parallel_processing": {
      "enabled": true,
      "concurrent_limit": 5,
      "batch_size": 5
    },

    "quality_thresholds": {
      "questions_per_worksheet_min": 8,
      "questions_per_worksheet_max": 15,
      "question_clarity_score": 0.85,
      "difficulty_consistency": true
    },

    "validation_rules": {
      "all_questions_have_instructions": true,
      "answer_spaces_provided": true,
      "questions_test_target_skills": true,
      "no_ambiguous_questions": true,
      "formatting_is_print_ready": true
    }
  }
}
```

### Phase 4: Answer Key Generation

```json
{
  "technical_parameters": {
    "ai_model": "claude-3-5-sonnet-20241022",
    "temperature": 0.2,
    "max_tokens": 16000,
    "context_window_used": "~45K tokens",
    "timeout": 60000,
    "retry_attempts": 3,

    "quality_thresholds": {
      "answer_accuracy_required": 1.0,
      "all_questions_answered": true,
      "complex_problems_show_work": true,
      "grading_guidance_provided": true
    },

    "validation_rules": {
      "answers_are_correct": true,
      "all_questions_have_answers": true,
      "solution_steps_for_complex_problems": true,
      "point_values_assigned": true,
      "common_errors_noted": true
    }
  }
}
```

### Phase 5: Quality Verification

```json
{
  "technical_parameters": {
    "ai_model": "gemini-2.0-flash-exp",
    "temperature": 0.1,
    "max_tokens": 3000,
    "context_window_used": "~42K tokens",
    "timeout": 25000,
    "retry_attempts": 2,

    "quality_thresholds": {
      "overall_score_minimum": 85,
      "accuracy_score_minimum": 95,
      "clarity_score_minimum": 85,
      "formatting_score_minimum": 85
    },

    "validation_rules": {
      "all_worksheets_verified": true,
      "answer_keys_accurate": true,
      "no_formatting_errors": true,
      "difficulty_progression_logical": true,
      "print_ready_confirmed": true
    }
  }
}
```

---

## 5. FALLBACK RULES

```json
{
  "fallback_configuration": {
    "max_retry_attempts_before_fallback": 3,
    "retry_delay_ms": 2000,
    "exponential_backoff": true,

    "phase_fallbacks": {
      "phase_1_skill_extraction": {
        "primary": "claude-3-5-sonnet-20241022",
        "fallback_1": "gpt-4o",
        "fallback_2": "gemini-2.0-flash-exp",
        "fallback_3": "claude-3-5-haiku-20241022"
      },

      "phase_2_worksheet_planning": {
        "primary": "gpt-4o",
        "fallback_1": "claude-3-5-sonnet-20241022",
        "fallback_2": "gemini-2.0-flash-exp",
        "fallback_3": "claude-3-5-haiku-20241022"
      },

      "phase_3_question_generation": {
        "primary": "claude-3-5-sonnet-20241022",
        "fallback_1": "gpt-4o",
        "fallback_2": "claude-3-5-haiku-20241022",
        "fallback_3": null
      },

      "phase_4_answer_keys": {
        "primary": "claude-3-5-sonnet-20241022",
        "fallback_1": "gpt-4o",
        "fallback_2": "gemini-2.0-flash-exp",
        "fallback_3": null
      },

      "phase_5_quality_verification": {
        "primary": "gemini-2.0-flash-exp",
        "fallback_1": "claude-3-5-haiku-20241022",
        "fallback_2": "gpt-4o-mini",
        "fallback_3": "claude-3-5-sonnet-20241022"
      }
    }
  }
}
```

---

## 6. VERIFICATION INTEGRATION

### Phase 1: Skill Extraction Verification

```json
{
  "verification_checks": {
    "quantity_validation": {
      "min_skills": 10,
      "max_skills": 30,
      "failure_action": "reject_retry"
    },
    "completeness_validation": {
      "each_skill_has_name": true,
      "each_skill_has_description": true,
      "each_skill_has_difficulty": true,
      "description_min_length": 30,
      "failure_action": "reject_retry"
    },
    "quality_validation": {
      "no_duplicate_skills": true,
      "difficulty_spread": true,
      "prerequisite_map_valid": true,
      "failure_action": "log_warning"
    }
  }
}
```

### Phase 3: Question Generation Verification

```json
{
  "verification_checks": {
    "quantity_validation": {
      "questions_per_worksheet_min": 8,
      "questions_per_worksheet_max": 15,
      "failure_action": "reject_worksheet_retry"
    },
    "quality_validation": {
      "questions_are_clear": true,
      "answer_spaces_provided": true,
      "instructions_present": true,
      "no_ambiguous_wording": true,
      "failure_action": "reject_worksheet_retry"
    },
    "accuracy_validation": {
      "questions_test_target_skills": true,
      "difficulty_is_consistent": true,
      "no_errors_or_typos": true,
      "failure_action": "reject_worksheet_retry"
    }
  }
}
```

### Phase 4: Answer Key Verification

```json
{
  "verification_checks": {
    "completeness_validation": {
      "all_questions_answered": true,
      "failure_action": "reject_retry_critical"
    },
    "accuracy_validation": {
      "answers_are_correct": true,
      "solution_steps_shown": true,
      "failure_action": "reject_retry_critical"
    },
    "grading_validation": {
      "point_values_assigned": true,
      "total_points_calculated": true,
      "grading_guidance_provided": true,
      "failure_action": "log_warning"
    }
  }
}
```

---

## 7. INPUT/OUTPUT SPECS

### Input Schema

```typescript
interface WorksheetSetRequest {
  // REQUIRED
  book_id: string;
  content_scope: 'full_book' | 'chapter' | 'section' | 'topic';

  target_audience: {
    age_range: { min_age: number; max_age: number; };
    grade_level: string;
    skill_level: 'beginner' | 'intermediate' | 'advanced';
  };

  worksheet_preferences: {
    total_worksheets: number; // 10-30
    difficulty_distribution: {
      easy: number; // percentage
      medium: number;
      hard: number;
    };
    questions_per_worksheet: number; // 8-15
  };

  // OPTIONAL
  question_types_include?: QuestionType[];
  question_types_exclude?: QuestionType[];

  format_preferences?: {
    include_answer_keys: boolean;
    include_grading_rubrics: boolean;
    color_vs_bw: 'color' | 'black_and_white' | 'both';
  };
}

type QuestionType =
  | 'multiple_choice'
  | 'true_false'
  | 'short_answer'
  | 'fill_in_blank'
  | 'matching'
  | 'problem_solving'
  | 'essay'
  | 'diagram_labeling';
```

### Output Schema

```typescript
interface WorksheetSetOutput {
  metadata: {
    set_id: string;
    source_book_id: string;
    generation_date: string;
    total_worksheets: number;
    total_questions: number;
    difficulty_profile: {
      easy_count: number;
      medium_count: number;
      hard_count: number;
    };
  };

  worksheets: Worksheet[];

  answer_keys: {
    complete_answer_key: AnswerKey;
    grading_rubrics: GradingRubric[];
  };

  files_generated: {
    student_worksheets_pdf: GeneratedFile;
    answer_keys_pdf: GeneratedFile;
    editable_versions: GeneratedFile[];
  };

  quality_metrics: {
    overall_score: number;
    accuracy_score: number;
    clarity_score: number;
    formatting_score: number;
  };
}

interface Worksheet {
  worksheet_id: string;
  worksheet_number: number;
  title: string;
  skills_covered: string[];
  difficulty_level: 'easy' | 'medium' | 'hard';
  questions: Question[];
  instructions: string;
  estimated_time_minutes: number;
}

interface Question {
  question_number: number;
  question_type: QuestionType;
  question_text: string;
  options?: string[]; // for multiple choice
  answer_space_size: 'small' | 'medium' | 'large';
  points: number;
}

interface AnswerKey {
  answers: Answer[];
  total_points: number;
}

interface Answer {
  worksheet_number: number;
  question_number: number;
  correct_answer: string | string[];
  solution_steps?: string[];
  common_errors: string[];
  grading_notes: string;
}
```

---

## 8. DEPENDENCIES MATRIX

| Phase | Depends On | Required Data | Can Run in Parallel |
|-------|-----------|---------------|---------------------|
| Phase 1 | User Request | book_id, content_scope, target_audience | No |
| Phase 2 | Phase 1 | Skills list, difficulty ratings | No |
| Phase 3 | Phase 2 | Worksheet plans, book content | Yes (5 concurrent) |
| Phase 4 | Phase 3 | Complete worksheets | No |
| Phase 5 | Phase 4 | Worksheets + answer keys | No |
| Phase 6 | Phase 5 | Validated content | Yes (multiple files) |

---

## 9. QUALITY GATES

### Phase 1: Skill Extraction Quality Gate

```json
{
  "minimum_score": 80,
  "criteria": {
    "completeness": {
      "weight": 40,
      "checks": [
        "10-30 skills identified",
        "All skills have descriptions",
        "All skills have difficulty ratings"
      ]
    },
    "accuracy": {
      "weight": 40,
      "checks": [
        "Skills reflect content accurately",
        "Difficulty ratings are appropriate",
        "No duplicate skills"
      ]
    },
    "usefulness": {
      "weight": 20,
      "checks": [
        "Question types suggested",
        "Prerequisite map provided"
      ]
    }
  }
}
```

### Phase 3: Question Generation Quality Gate

```json
{
  "minimum_score": 85,
  "criteria": {
    "completeness": {
      "weight": 30,
      "checks": [
        "8-15 questions per worksheet",
        "All questions have instructions",
        "Answer spaces provided"
      ]
    },
    "clarity": {
      "weight": 40,
      "checks": [
        "Questions are unambiguous",
        "Language is age-appropriate",
        "Instructions are clear"
      ]
    },
    "accuracy": {
      "weight": 30,
      "checks": [
        "Questions test target skills",
        "Difficulty is consistent",
        "No errors or typos"
      ]
    }
  }
}
```

### Phase 4: Answer Key Quality Gate

```json
{
  "minimum_score": 95,
  "criteria": {
    "accuracy": {
      "weight": 60,
      "checks": [
        "All answers are correct",
        "Solution steps are accurate",
        "No errors"
      ],
      "critical": true
    },
    "completeness": {
      "weight": 30,
      "checks": [
        "All questions answered",
        "Complex problems show work",
        "Grading guidance provided"
      ],
      "critical": true
    },
    "usefulness": {
      "weight": 10,
      "checks": [
        "Common errors noted",
        "Point values assigned"
      ]
    }
  }
}
```

---

## 10. COMPLETE AI PROMPTS

### Phase 1: Skill Extraction Prompt

```markdown
# ROLE
You are an educational content analyst specializing in breaking down learning materials into discrete, practicable skills.

# TASK
Analyze the provided content and extract all key skills that students need to practice.

# INPUT DATA
- Book Content: {{content}}
- Subject Area: {{subject}}
- Grade Level: {{grade}}

# EXTRACTION REQUIREMENTS

Extract 10-30 skills that:
1. Are discrete and measurable
2. Can be practiced through worksheets
3. Build on each other logically
4. Cover the full content scope

For each skill, provide:
- Skill name (clear, specific)
- Description (what students will do)
- Difficulty level (1-5 scale)
- Prerequisite skills (if any)
- Recommended question types

# OUTPUT FORMAT
```json
{
  "skills": [
    {
      "skill_id": "unique_id",
      "skill_name": "Name",
      "description": "What students will practice (min 30 chars)",
      "difficulty": 1-5,
      "prerequisites": ["skill_name"],
      "recommended_question_types": ["multiple_choice", "short_answer"],
      "example_question": "Sample question testing this skill"
    }
  ],
  "skill_progression": {
    "beginner": ["skill1", "skill2"],
    "intermediate": ["skill3", "skill4"],
    "advanced": ["skill5", "skill6"]
  }
}
```

# QUALITY REQUIREMENTS
- 10-30 skills total
- Each skill has description >= 30 characters
- All difficulty levels 1-5
- No duplicate skills
- Clear skill progression

# BEGIN EXTRACTION
```

### Phase 3: Question Generation Prompt

```markdown
# ROLE
You are an expert worksheet creator specializing in clear, effective practice questions.

# TASK
Generate {{questions_per_worksheet}} high-quality questions for a single worksheet.

# INPUT DATA
- Worksheet Title: {{title}}
- Skills to Practice: {{skills}}
- Difficulty Level: {{difficulty}}
- Question Types: {{question_types}}
- Target Age: {{age}}

# QUESTION GENERATION REQUIREMENTS

Generate {{questions_per_worksheet}} questions that:
1. Test the target skills
2. Match the difficulty level
3. Are clear and unambiguous
4. Are age-appropriate
5. Vary in format

Question Distribution:
- {{question_types_breakdown}}

# OUTPUT FORMAT (Per Question)
```json
{
  "question_number": 1,
  "question_type": "multiple_choice",
  "question_text": "Clear question text",
  "options": ["A", "B", "C", "D"], // if applicable
  "answer_space_size": "small|medium|large",
  "points": 5,
  "skill_tested": "skill_name",
  "difficulty_check": "matches worksheet difficulty"
}
```

# QUALITY REQUIREMENTS
- {{questions_per_worksheet}} questions total
- All questions are clear
- Answer spaces appropriately sized
- Questions test target skills
- Difficulty is consistent
- No ambiguous wording

# BEGIN GENERATION
```

### Phase 4: Answer Key Generation Prompt

```markdown
# ROLE
You are a subject matter expert creating detailed, accurate answer keys.

# TASK
Generate complete answer key for all worksheets with correct answers and solution steps.

# INPUT DATA
- Complete Worksheets: {{worksheets}}
- Subject Area: {{subject}}

# ANSWER KEY REQUIREMENTS

For EACH question provide:
1. Correct answer
2. Solution steps (for complex problems)
3. Common errors students make
4. Grading notes
5. Point value

# OUTPUT FORMAT
```json
{
  "answer_key": [
    {
      "worksheet_number": 1,
      "question_number": 1,
      "correct_answer": "Answer",
      "solution_steps": [
        "Step 1: ...",
        "Step 2: ..."
      ],
      "common_errors": [
        "Students often...",
        "Common mistake..."
      ],
      "grading_notes": "How to award partial credit",
      "points": 5
    }
  ],
  "grading_rubric": {
    "total_points_per_worksheet": [worksheet_points],
    "point_distribution": {
      "knowledge_recall": 30,
      "application": 50,
      "analysis": 20
    }
  }
}
```

# QUALITY REQUIREMENTS
- 100% answer accuracy (CRITICAL)
- All questions have answers
- Complex problems show solution steps
- Common errors noted
- Clear grading guidance

# BEGIN ANSWER KEY CREATION
```

---

## 11. COST ANALYSIS

### Token Usage & Cost per Set (20 Worksheets)

| Phase | Model | Input | Output | Cost |
|-------|-------|-------|--------|------|
| Phase 1 | Claude-3-5-Sonnet | 12,000 | 2,500 | $0.044 |
| Phase 2 | GPT-4o | 4,000 | 3,000 | $0.035 |
| Phase 3 (×20) | Claude-3-5-Sonnet | 120,000 | 60,000 | $1.65 |
| Phase 4 | Claude-3-5-Sonnet | 30,000 | 15,000 | $0.277 |
| Phase 5 | Gemini-2.0-Flash | 40,000 | 2,000 | $0.011 |
| **TOTAL** | | **206,000** | **82,500** | **$2.02** |

### Pricing Strategy

**Total Cost**: $2.30 (with overhead)

**Pricing Tiers**:
- Single Set: $7.99 (247% markup, 71% margin)
- 5-Set Bundle: $34.99 ($7.00 each)
- 10-Set Bundle: $59.99 ($6.00 each)

---

## 12. IMPLEMENTATION GUIDE

### System Integration Points

```typescript
// API Endpoint
POST /api/v1/addons/worksheet-sets/generate

// Request Handler
async function generateWorksheetSet(request: WorksheetSetRequest): Promise<WorksheetSetOutput> {
  // Phase 1: Skill Extraction
  const skills = await skillExtractionService.extract({
    bookContent: await getBookContent(request.book_id),
    targetAudience: request.target_audience,
    worksheetCount: request.worksheet_preferences.total_worksheets
  });

  // Phase 2: Worksheet Planning
  const worksheetPlans = await worksheetPlanningService.plan({
    skills: skills,
    preferences: request.worksheet_preferences,
    targetAudience: request.target_audience
  });

  // Phase 3: Question Generation (Parallel)
  const worksheets = await Promise.all(
    worksheetPlans.map(plan =>
      questionGenerationService.generate({
        plan: plan,
        bookContent: await getBookContent(request.book_id),
        targetAudience: request.target_audience
      })
    )
  );

  // Phase 4: Answer Key Generation
  const answerKeys = await answerKeyService.generate({
    worksheets: worksheets,
    subject: request.target_audience.subject
  });

  // Phase 5: Quality Verification
  const qualityReport = await qualityVerificationService.verify({
    worksheets: worksheets,
    answerKeys: answerKeys
  });

  if (qualityReport.overall_score < 85) {
    throw new QualityThresholdError(qualityReport);
  }

  // Phase 6: File Generation
  const files = await fileGenerationService.generate({
    worksheets: worksheets,
    answerKeys: answerKeys,
    formatPreferences: request.format_preferences
  });

  return {
    metadata: {
      set_id: generateSetId(),
      source_book_id: request.book_id,
      generation_date: new Date().toISOString(),
      total_worksheets: worksheets.length,
      total_questions: worksheets.reduce((sum, w) => sum + w.questions.length, 0),
      difficulty_profile: calculateDifficultyProfile(worksheets)
    },
    worksheets: worksheets,
    answer_keys: answerKeys,
    files_generated: files,
    quality_metrics: qualityReport
  };
}
```

### Database Schema

```sql
-- Worksheet Sets Table
CREATE TABLE worksheet_sets (
  set_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_book_id UUID REFERENCES books(id) NOT NULL,
  content_scope TEXT NOT NULL,
  target_audience JSONB NOT NULL,
  worksheet_preferences JSONB NOT NULL,

  total_worksheets INTEGER NOT NULL,
  total_questions INTEGER NOT NULL,
  difficulty_profile JSONB NOT NULL,

  generation_status TEXT NOT NULL DEFAULT 'pending',
  quality_score NUMERIC(5,2),

  created_at TIMESTAMPTZ DEFAULT now(),
  completed_at TIMESTAMPTZ,
  created_by UUID REFERENCES users(id)
);

-- Individual Worksheets Table
CREATE TABLE worksheets (
  worksheet_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  set_id UUID REFERENCES worksheet_sets(set_id) NOT NULL,
  worksheet_number INTEGER NOT NULL,

  title TEXT NOT NULL,
  skills_covered TEXT[] NOT NULL,
  difficulty_level TEXT NOT NULL,
  questions JSONB NOT NULL,
  instructions TEXT NOT NULL,
  estimated_time_minutes INTEGER,

  created_at TIMESTAMPTZ DEFAULT now()
);

-- Answer Keys Table
CREATE TABLE answer_keys (
  answer_key_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  set_id UUID REFERENCES worksheet_sets(set_id) NOT NULL,

  answers JSONB NOT NULL,
  grading_rubrics JSONB NOT NULL,
  total_points INTEGER NOT NULL,

  created_at TIMESTAMPTZ DEFAULT now()
);

-- Generated Files Table
CREATE TABLE worksheet_files (
  file_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  set_id UUID REFERENCES worksheet_sets(set_id) NOT NULL,

  file_type TEXT NOT NULL, -- 'student_pdf', 'answer_key_pdf', 'editable_docx'
  file_format TEXT NOT NULL, -- 'pdf', 'docx', 'html'
  storage_url TEXT NOT NULL,
  file_size_bytes BIGINT,

  created_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX idx_worksheet_sets_book ON worksheet_sets(source_book_id);
CREATE INDEX idx_worksheet_sets_status ON worksheet_sets(generation_status);
CREATE INDEX idx_worksheets_set ON worksheets(set_id);
CREATE INDEX idx_answer_keys_set ON answer_keys(set_id);
CREATE INDEX idx_worksheet_files_set ON worksheet_files(set_id);

-- RLS Policies
ALTER TABLE worksheet_sets ENABLE ROW LEVEL SECURITY;
ALTER TABLE worksheets ENABLE ROW LEVEL SECURITY;
ALTER TABLE answer_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE worksheet_files ENABLE ROW LEVEL SECURITY;

-- Users can view their own worksheet sets
CREATE POLICY "Users can view own worksheet sets"
  ON worksheet_sets FOR SELECT
  TO authenticated
  USING (created_by = auth.uid());

-- Users can create worksheet sets
CREATE POLICY "Users can create worksheet sets"
  ON worksheet_sets FOR INSERT
  TO authenticated
  WITH CHECK (created_by = auth.uid());
```

### Error Handling

```typescript
class WorksheetGenerationError extends Error {
  constructor(
    message: string,
    public phase: string,
    public details: any
  ) {
    super(message);
    this.name = 'WorksheetGenerationError';
  }
}

class QualityThresholdError extends Error {
  constructor(public qualityReport: any) {
    super(`Quality threshold not met: ${qualityReport.overall_score}/100`);
    this.name = 'QualityThresholdError';
  }
}

// Error Recovery Strategy
async function handleGenerationError(error: Error, phase: string, context: any) {
  // Log error
  await logError({
    error: error,
    phase: phase,
    context: context,
    timestamp: new Date().toISOString()
  });

  // Attempt retry with fallback model
  if (error instanceof AIModelError && retriesRemaining > 0) {
    const fallbackModel = getFallbackModel(phase, currentModel);
    return await retryWithFallback(phase, fallbackModel, context);
  }

  // If all retries exhausted, notify user and admin
  await notifyGenerationFailure({
    userId: context.userId,
    bookId: context.bookId,
    phase: phase,
    error: error.message
  });

  throw error;
}
```

### Monitoring & Logging

```typescript
// Performance Metrics
interface WorksheetGenerationMetrics {
  set_id: string;
  total_duration_ms: number;
  phase_durations: {
    phase_1: number;
    phase_2: number;
    phase_3: number;
    phase_4: number;
    phase_5: number;
    phase_6: number;
  };
  token_usage: {
    total_input: number;
    total_output: number;
    cost_usd: number;
  };
  quality_scores: {
    overall: number;
    accuracy: number;
    clarity: number;
    formatting: number;
  };
  success: boolean;
  errors: string[];
}

// Log to monitoring system
async function logGenerationMetrics(metrics: WorksheetGenerationMetrics) {
  await metricsService.record('worksheet_set_generation', metrics);

  // Alert if quality below threshold
  if (metrics.quality_scores.overall < 85) {
    await alertService.notify({
      severity: 'warning',
      message: `Worksheet set ${metrics.set_id} quality below threshold`,
      metrics: metrics.quality_scores
    });
  }

  // Alert if duration exceeds expected time
  if (metrics.total_duration_ms > 180000) { // 3 minutes
    await alertService.notify({
      severity: 'info',
      message: `Worksheet set ${metrics.set_id} generation took ${metrics.total_duration_ms}ms`,
      phase_durations: metrics.phase_durations
    });
  }
}
```

---

## 13. TESTING REQUIREMENTS

### Unit Tests

```typescript
describe('WorksheetSetGeneration', () => {
  describe('Phase 1: Skill Extraction', () => {
    it('should extract 10-30 skills from book content', async () => {
      const result = await skillExtractionService.extract({
        bookContent: mockBookContent,
        targetAudience: mockAudience,
        worksheetCount: 20
      });

      expect(result.skills.length).toBeGreaterThanOrEqual(10);
      expect(result.skills.length).toBeLessThanOrEqual(30);
    });

    it('should assign difficulty ratings to all skills', async () => {
      const result = await skillExtractionService.extract({
        bookContent: mockBookContent,
        targetAudience: mockAudience,
        worksheetCount: 20
      });

      result.skills.forEach(skill => {
        expect(skill.difficulty).toBeGreaterThanOrEqual(1);
        expect(skill.difficulty).toBeLessThanOrEqual(5);
      });
    });

    it('should not contain duplicate skills', async () => {
      const result = await skillExtractionService.extract({
        bookContent: mockBookContent,
        targetAudience: mockAudience,
        worksheetCount: 20
      });

      const skillNames = result.skills.map(s => s.skill_name);
      const uniqueNames = new Set(skillNames);
      expect(skillNames.length).toBe(uniqueNames.size);
    });
  });

  describe('Phase 2: Worksheet Planning', () => {
    it('should create the requested number of worksheets', async () => {
      const result = await worksheetPlanningService.plan({
        skills: mockSkills,
        preferences: { total_worksheets: 20 },
        targetAudience: mockAudience
      });

      expect(result.length).toBe(20);
    });

    it('should distribute difficulty according to preferences', async () => {
      const result = await worksheetPlanningService.plan({
        skills: mockSkills,
        preferences: {
          total_worksheets: 20,
          difficulty_distribution: { easy: 0.3, medium: 0.5, hard: 0.2 }
        },
        targetAudience: mockAudience
      });

      const easy = result.filter(w => w.difficulty === 'easy').length;
      const medium = result.filter(w => w.difficulty === 'medium').length;
      const hard = result.filter(w => w.difficulty === 'hard').length;

      expect(easy).toBeCloseTo(6, 1);
      expect(medium).toBeCloseTo(10, 1);
      expect(hard).toBeCloseTo(4, 1);
    });
  });

  describe('Phase 3: Question Generation', () => {
    it('should generate 8-15 questions per worksheet', async () => {
      const result = await questionGenerationService.generate({
        plan: mockWorksheetPlan,
        bookContent: mockBookContent,
        targetAudience: mockAudience
      });

      expect(result.questions.length).toBeGreaterThanOrEqual(8);
      expect(result.questions.length).toBeLessThanOrEqual(15);
    });

    it('should include clear instructions', async () => {
      const result = await questionGenerationService.generate({
        plan: mockWorksheetPlan,
        bookContent: mockBookContent,
        targetAudience: mockAudience
      });

      expect(result.instructions).toBeTruthy();
      expect(result.instructions.length).toBeGreaterThan(20);
    });

    it('should provide answer spaces for all questions', async () => {
      const result = await questionGenerationService.generate({
        plan: mockWorksheetPlan,
        bookContent: mockBookContent,
        targetAudience: mockAudience
      });

      result.questions.forEach(q => {
        expect(q.answer_space_size).toMatch(/small|medium|large/);
      });
    });
  });

  describe('Phase 4: Answer Key Generation', () => {
    it('should provide answers for all questions', async () => {
      const result = await answerKeyService.generate({
        worksheets: mockWorksheets,
        subject: 'mathematics'
      });

      const totalQuestions = mockWorksheets.reduce(
        (sum, w) => sum + w.questions.length, 0
      );
      expect(result.complete_answer_key.answers.length).toBe(totalQuestions);
    });

    it('should include solution steps for complex problems', async () => {
      const result = await answerKeyService.generate({
        worksheets: mockComplexWorksheets,
        subject: 'mathematics'
      });

      const complexAnswers = result.complete_answer_key.answers.filter(
        a => a.solution_steps && a.solution_steps.length > 0
      );
      expect(complexAnswers.length).toBeGreaterThan(0);
    });

    it('should calculate total points correctly', async () => {
      const result = await answerKeyService.generate({
        worksheets: mockWorksheets,
        subject: 'science'
      });

      const calculatedTotal = result.complete_answer_key.answers.reduce(
        (sum, a) => sum + (a.points || 0), 0
      );
      expect(result.complete_answer_key.total_points).toBe(calculatedTotal);
    });
  });

  describe('Phase 5: Quality Verification', () => {
    it('should assign quality scores', async () => {
      const result = await qualityVerificationService.verify({
        worksheets: mockWorksheets,
        answerKeys: mockAnswerKeys
      });

      expect(result.overall_score).toBeGreaterThanOrEqual(0);
      expect(result.overall_score).toBeLessThanOrEqual(100);
      expect(result.accuracy_score).toBeDefined();
      expect(result.clarity_score).toBeDefined();
      expect(result.formatting_score).toBeDefined();
    });

    it('should fail if quality below threshold', async () => {
      await expect(
        qualityVerificationService.verify({
          worksheets: mockPoorQualityWorksheets,
          answerKeys: mockPoorQualityAnswerKeys
        })
      ).rejects.toThrow(QualityThresholdError);
    });
  });
});
```

### Integration Tests

```typescript
describe('WorksheetSetGeneration Integration', () => {
  it('should generate complete worksheet set end-to-end', async () => {
    const request: WorksheetSetRequest = {
      book_id: 'test-book-123',
      content_scope: 'chapter',
      target_audience: {
        age_range: { min_age: 10, max_age: 12 },
        grade_level: '6th',
        skill_level: 'intermediate'
      },
      worksheet_preferences: {
        total_worksheets: 10,
        difficulty_distribution: { easy: 0.3, medium: 0.5, hard: 0.2 },
        questions_per_worksheet: 12
      }
    };

    const result = await generateWorksheetSet(request);

    // Verify metadata
    expect(result.metadata.total_worksheets).toBe(10);
    expect(result.metadata.source_book_id).toBe('test-book-123');

    // Verify worksheets generated
    expect(result.worksheets.length).toBe(10);

    // Verify answer keys
    expect(result.answer_keys.complete_answer_key).toBeDefined();
    expect(result.answer_keys.grading_rubrics).toBeDefined();

    // Verify files generated
    expect(result.files_generated.student_worksheets_pdf).toBeDefined();
    expect(result.files_generated.answer_keys_pdf).toBeDefined();

    // Verify quality
    expect(result.quality_metrics.overall_score).toBeGreaterThanOrEqual(85);
  });

  it('should handle parallel worksheet generation correctly', async () => {
    const startTime = Date.now();

    const result = await generateWorksheetSet({
      book_id: 'test-book-456',
      content_scope: 'full_book',
      target_audience: mockAudience,
      worksheet_preferences: {
        total_worksheets: 20,
        difficulty_distribution: { easy: 0.3, medium: 0.5, hard: 0.2 },
        questions_per_worksheet: 10
      }
    });

    const duration = Date.now() - startTime;

    // Should complete in reasonable time with parallelization
    expect(duration).toBeLessThan(180000); // 3 minutes
    expect(result.worksheets.length).toBe(20);
  });
});
```

### Performance Tests

```typescript
describe('WorksheetSetGeneration Performance', () => {
  it('should complete within time limits', async () => {
    const phases = [
      { name: 'Phase 1', maxMs: 10000 },
      { name: 'Phase 2', maxMs: 15000 },
      { name: 'Phase 3', maxMs: 120000 },
      { name: 'Phase 4', maxMs: 30000 },
      { name: 'Phase 5', maxMs: 15000 },
      { name: 'Phase 6', maxMs: 20000 }
    ];

    for (const phase of phases) {
      const startTime = Date.now();
      await runPhase(phase.name);
      const duration = Date.now() - startTime;

      expect(duration).toBeLessThan(phase.maxMs);
    }
  });

  it('should stay within token budget', async () => {
    const result = await generateWorksheetSet(mockRequest);

    const totalInputTokens = result.token_usage.total_input;
    const totalOutputTokens = result.token_usage.total_output;

    expect(totalInputTokens).toBeLessThan(220000); // 10% buffer
    expect(totalOutputTokens).toBeLessThan(90000); // 10% buffer
  });

  it('should stay within cost budget', async () => {
    const result = await generateWorksheetSet(mockRequest);

    expect(result.token_usage.cost_usd).toBeLessThan(2.50); // $2.30 + buffer
  });
});
```

---

## 14. APPROVAL STATUS

### Current Status: DRAFT - AWAITING APPROVAL

### Review Checklist

- [ ] **Technical Review**
  - [ ] AI model assignments verified
  - [ ] Token estimates validated
  - [ ] Cost analysis confirmed
  - [ ] Fallback rules tested

- [ ] **Quality Review**
  - [ ] Quality gates appropriate
  - [ ] Verification rules comprehensive
  - [ ] Success criteria measurable
  - [ ] Error handling robust

- [ ] **Implementation Review**
  - [ ] Database schema validated
  - [ ] API endpoints defined
  - [ ] Integration points clear
  - [ ] Monitoring in place

- [ ] **Testing Review**
  - [ ] Unit test coverage adequate
  - [ ] Integration tests comprehensive
  - [ ] Performance tests defined
  - [ ] Edge cases covered

### Approval Required From

1. **Technical Lead**: ___________________ Date: ______
2. **Product Owner**: ___________________ Date: ______
3. **QA Lead**: ___________________ Date: ______

### Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | 2024-12-19 | System | Initial draft |
| 2.0 | 2024-12-21 | System | Added implementation guide, testing requirements, approval section |

---

**END OF SPECIFICATION**
