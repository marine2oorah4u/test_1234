# Answer Keys - Complete Technical Specification

**Version**: 2.0
**Status**: Draft - Awaiting Approval
**Feature ID**: ADDON-004
**Category**: Teacher Support Materials
**Complexity**: Medium
**Created**: 2024-12-21

---

## TABLE OF CONTENTS

1. [Overview](#1-overview)
2. [Step-by-Step Workflow](#2-step-by-step-workflow)
3. [AI Model Assignments](#3-ai-model-assignments)
4. [Technical Parameters](#4-technical-parameters)
5. [Fallback Rules](#5-fallback-rules)
6. [Verification Integration](#6-verification-integration)
7. [Input/Output Specs](#7-inputoutput-specs)
8. [Dependencies Matrix](#8-dependencies-matrix)
9. [Quality Gates](#9-quality-gates)
10. [Complete AI Prompts](#10-complete-ai-prompts)
11. [Implementation Guide](#11-implementation-guide)
12. [Cost Analysis](#12-cost-analysis)
13. [Testing Requirements](#13-testing-requirements)
14. [Approval Status](#14-approval-status)

---

## 1. OVERVIEW

### 1.1 What It Does

Generates comprehensive, detailed answer keys for all educational materials including worksheets, quizzes, activities, and assessments. Each answer key includes correct answers, step-by-step solutions, explanations, common error identification, and partial credit guidelines.

### 1.2 Purpose

**Problem**: Teachers need accurate, detailed answer keys to grade student work efficiently and consistently. Creating comprehensive answer keys with explanations is time-consuming.

**Solution**: AI-generated answer keys that:
- Provide 100% accurate answers for all questions
- Include step-by-step solution processes
- Explain reasoning behind answers
- Identify common student errors
- Provide partial credit guidelines
- Include grading rubrics and scoring guides
- Support consistent grading across teachers

### 1.3 Key Features

1. **Complete Coverage**: Answer key for every question in every material
2. **Step-by-Step Solutions**: Detailed solution process for complex problems
3. **Explanations**: Clear reasoning for why answers are correct
4. **Error Analysis**: Common mistakes students make
5. **Grading Support**: Partial credit guidelines and rubrics
6. **Multiple Formats**: Separate answer keys and teacher editions with inline answers
7. **Subject Expertise**: Accurate answers across all subjects (math, science, language arts, etc.)

---

## 2. STEP-BY-STEP WORKFLOW

### Phase 1: Source Material Analysis
**Duration**: 5-10 seconds
**Purpose**: Analyze all questions requiring answer keys

#### Input Requirements
- Source materials (worksheets, quizzes, activities, etc.)
- Question types and formats
- Subject area
- Grade level

#### Processing
- Extract all questions from source materials
- Identify question types (MCQ, short answer, problems, essays, etc.)
- Categorize by complexity level
- Determine solution requirements
- Identify questions needing detailed explanations

#### Output Deliverables
- Complete question inventory
- Question categorization by type
- Complexity ratings per question
- Solution requirements list

#### Success Criteria
- All questions identified
- Correct question type classification
- Appropriate complexity ratings
- No questions missed

---

### Phase 2: Answer Generation
**Duration**: 45-90 seconds
**Purpose**: Generate correct answers for all questions

#### Input Requirements
- Question inventory from Phase 1
- Source content/book materials
- Subject matter context

#### Processing
- Generate correct answers for each question
- Verify answer accuracy
- Ensure answers match question format
- Validate against source material
- Cross-check complex calculations
- Verify factual accuracy

#### Output Deliverables
- Correct answer for each question
- Answer format matching question type
- Confidence scores for each answer
- Source references where applicable

#### Success Criteria
- 100% answer accuracy (CRITICAL)
- All answers provided
- Answers match question formats
- Source material alignment verified

---

### Phase 3: Solution Process Documentation
**Duration**: 60-120 seconds
**Purpose**: Create step-by-step solution processes for complex questions

#### Input Requirements
- Answers from Phase 2
- Complex questions requiring solutions
- Subject standards and methods

#### Processing
- Identify questions needing solution steps
- Create step-by-step solution processes
- Document multiple solution methods where applicable
- Show all work and calculations
- Explain reasoning at each step
- Validate solution accuracy

#### Output Deliverables
- Step-by-step solutions for complex problems
- Multiple solution methods (where applicable)
- Clear explanations for each step
- Visual aids (diagrams, graphs) if needed

#### Success Criteria
- Solutions are mathematically/logically correct
- Steps are clear and complete
- Alternative methods shown when relevant
- All work is shown

---

### Phase 4: Explanation & Reasoning
**Duration**: 40-60 seconds
**Purpose**: Explain why answers are correct and provide reasoning

#### Input Requirements
- Answers and solutions from Phases 2 & 3
- Educational context
- Target audience

#### Processing
- Create clear explanations for each answer
- Explain reasoning process
- Connect to learning objectives
- Use age-appropriate language
- Reference relevant concepts
- Provide context for understanding

#### Output Deliverables
- Clear explanation for each answer
- Reasoning process documentation
- Connections to learning objectives
- Context and background information

#### Success Criteria
- Explanations are clear and accurate
- Language is age-appropriate
- Reasoning is sound
- Connections to concepts made

---

### Phase 5: Common Error Analysis
**Duration**: 30-45 seconds
**Purpose**: Identify and document common student errors

#### Input Requirements
- Questions and correct answers
- Subject matter expertise
- Common misconception knowledge

#### Processing
- Identify likely student errors
- Analyze common misconceptions
- Document typical mistakes
- Explain why errors occur
- Suggest remediation strategies

#### Output Deliverables
- Common errors for each question
- Error analysis and reasoning
- Misconception identification
- Remediation suggestions

#### Success Criteria
- Common errors identified
- Error reasoning explained
- Helpful remediation provided
- Realistic error patterns

---

### Phase 6: Grading Guidelines & Rubrics
**Duration**: 25-35 seconds
**Purpose**: Create grading guidelines and scoring rubrics

#### Input Requirements
- All questions and answers
- Point value assignments
- Question types

#### Processing
- Assign point values
- Create partial credit guidelines
- Develop scoring rubrics
- Define grading criteria
- Establish consistency standards
- Document edge cases

#### Output Deliverables
- Point values for all questions
- Partial credit guidelines
- Detailed scoring rubrics
- Grading criteria documentation
- Edge case handling

#### Success Criteria
- Fair point distribution
- Clear partial credit rules
- Comprehensive rubrics
- Consistent grading standards

---

### Phase 7: Quality Verification
**Duration**: 15-20 seconds
**Purpose**: Verify answer key accuracy and completeness

#### Input Requirements
- Complete answer key
- Original questions
- Source materials

#### Processing
- Verify all answers are correct
- Check solution accuracy
- Validate explanations
- Ensure completeness
- Check formatting
- Verify rubric fairness

#### Output Deliverables
- Quality verification report
- Accuracy score
- Completeness confirmation
- Issue list (if any)

#### Success Criteria
- 100% answer accuracy confirmed
- All questions covered
- Explanations clear
- No errors found

---

### Phase 8: File Generation
**Duration**: 15-25 seconds
**Purpose**: Generate answer key files in multiple formats

#### Input Requirements
- Verified answer key content
- Format preferences
- Layout specifications

#### Processing
- Generate separate answer key files
- Create teacher editions with inline answers
- Format for printing
- Optimize for digital use
- Create editable versions
- Apply professional styling

#### Output Deliverables
- Answer key PDF (separate)
- Teacher edition PDF (inline answers)
- Editable DOCX versions
- Digital formats (HTML)
- Storage URLs

#### Success Criteria
- All files generated successfully
- Professional formatting
- Print-optimized
- Files accessible

---

## 3. AI MODEL ASSIGNMENTS

```json
{
  "phase_1_source_analysis": {
    "primary_model": "claude-3-5-haiku-20241022",
    "rationale": "Fast and efficient for simple analysis tasks",
    "estimated_tokens": {
      "input": 8000,
      "output": 1500
    }
  },

  "phase_2_answer_generation": {
    "primary_model": "claude-3-5-sonnet-20241022",
    "rationale": "High accuracy for generating correct answers across subjects",
    "estimated_tokens": {
      "input": 25000,
      "output": 8000
    }
  },

  "phase_3_solution_documentation": {
    "primary_model": "claude-3-5-sonnet-20241022",
    "rationale": "Excellent at showing step-by-step mathematical and logical processes",
    "estimated_tokens": {
      "input": 30000,
      "output": 15000
    }
  },

  "phase_4_explanation_reasoning": {
    "primary_model": "claude-3-5-sonnet-20241022",
    "rationale": "Superior at explaining concepts clearly",
    "estimated_tokens": {
      "input": 35000,
      "output": 12000
    }
  },

  "phase_5_error_analysis": {
    "primary_model": "gpt-4o",
    "rationale": "Good at identifying common misconceptions and errors",
    "estimated_tokens": {
      "input": 40000,
      "output": 8000
    }
  },

  "phase_6_grading_guidelines": {
    "primary_model": "claude-3-5-sonnet-20241022",
    "rationale": "Fair and detailed at creating grading criteria",
    "estimated_tokens": {
      "input": 45000,
      "output": 6000
    }
  },

  "phase_7_quality_verification": {
    "primary_model": "gemini-2.0-flash-exp",
    "rationale": "Fast verification with good accuracy checking",
    "estimated_tokens": {
      "input": 50000,
      "output": 2000
    }
  }
}
```

---

## 4. TECHNICAL PARAMETERS

### Phase 2: Answer Generation

```json
{
  "technical_parameters": {
    "ai_model": "claude-3-5-sonnet-20241022",
    "temperature": 0.1,
    "max_tokens": 10000,
    "context_window_used": "~33K tokens",
    "timeout": 60000,
    "retry_attempts": 3,

    "quality_thresholds": {
      "answer_accuracy_required": 1.0,
      "all_questions_answered": true,
      "answer_format_matches_question": true
    },

    "validation_rules": {
      "answers_verified_against_source": true,
      "calculations_double_checked": true,
      "factual_accuracy_confirmed": true,
      "no_ambiguous_answers": true
    }
  }
}
```

### Phase 3: Solution Process Documentation

```json
{
  "technical_parameters": {
    "ai_model": "claude-3-5-sonnet-20241022",
    "temperature": 0.2,
    "max_tokens": 16000,
    "context_window_used": "~45K tokens",
    "timeout": 90000,
    "retry_attempts": 3,

    "quality_thresholds": {
      "solutions_mathematically_correct": true,
      "all_steps_shown": true,
      "explanations_clear": true
    },

    "validation_rules": {
      "solution_leads_to_correct_answer": true,
      "all_steps_logical": true,
      "no_skipped_steps": true,
      "alternative_methods_shown_when_relevant": true
    }
  }
}
```

### Phase 7: Quality Verification

```json
{
  "technical_parameters": {
    "ai_model": "gemini-2.0-flash-exp",
    "temperature": 0.05,
    "max_tokens": 3000,
    "context_window_used": "~52K tokens",
    "timeout": 30000,
    "retry_attempts": 2,

    "quality_thresholds": {
      "overall_score_minimum": 98,
      "accuracy_score_required": 100,
      "completeness_score_minimum": 98
    },

    "validation_rules": {
      "all_answers_verified_correct": true,
      "all_questions_covered": true,
      "no_errors_found": true,
      "explanations_accurate": true
    }
  }
}
```

---

## 5. FALLBACK RULES

```json
{
  "fallback_configuration": {
    "max_retry_attempts_before_fallback": 3,
    "retry_delay_ms": 2000,
    "exponential_backoff": true,

    "phase_fallbacks": {
      "phase_2_answer_generation": {
        "primary": "claude-3-5-sonnet-20241022",
        "fallback_1": "gpt-4o",
        "fallback_2": "gemini-2.0-flash-exp",
        "fallback_3": null
      },

      "phase_3_solution_documentation": {
        "primary": "claude-3-5-sonnet-20241022",
        "fallback_1": "gpt-4o",
        "fallback_2": "claude-3-5-haiku-20241022",
        "fallback_3": null
      },

      "phase_4_explanation_reasoning": {
        "primary": "claude-3-5-sonnet-20241022",
        "fallback_1": "gpt-4o",
        "fallback_2": "gemini-2.0-flash-exp",
        "fallback_3": null
      },

      "phase_7_quality_verification": {
        "primary": "gemini-2.0-flash-exp",
        "fallback_1": "claude-3-5-haiku-20241022",
        "fallback_2": "gpt-4o-mini",
        "fallback_3": "claude-3-5-sonnet-20241022"
      }
    }
  }
}
```

---

## 6. VERIFICATION INTEGRATION

### Phase 2: Answer Generation Verification

```json
{
  "verification_checks": {
    "completeness_validation": {
      "all_questions_answered": true,
      "failure_action": "reject_retry_critical"
    },
    "accuracy_validation": {
      "answers_are_correct": true,
      "calculations_verified": true,
      "facts_validated": true,
      "failure_action": "reject_retry_critical"
    },
    "format_validation": {
      "answer_format_matches_question": true,
      "units_included_where_needed": true,
      "failure_action": "reject_retry"
    }
  }
}
```

### Phase 3: Solution Process Verification

```json
{
  "verification_checks": {
    "accuracy_validation": {
      "solution_reaches_correct_answer": true,
      "all_steps_mathematically_valid": true,
      "no_logical_errors": true,
      "failure_action": "reject_retry_critical"
    },
    "completeness_validation": {
      "all_steps_shown": true,
      "no_steps_skipped": true,
      "work_shown_completely": true,
      "failure_action": "reject_retry"
    },
    "clarity_validation": {
      "steps_are_clear": true,
      "explanations_provided": true,
      "notation_correct": true,
      "failure_action": "log_warning"
    }
  }
}
```

---

## 7. INPUT/OUTPUT SPECS

### Input Schema

```typescript
interface AnswerKeyRequest {
  // REQUIRED
  source_material_ids: string[]; // worksheets, quizzes, activities
  source_material_types: MaterialType[];

  subject_area: string;
  grade_level: string;

  // OPTIONAL
  include_solution_steps?: boolean; // default true
  include_explanations?: boolean; // default true
  include_common_errors?: boolean; // default true
  include_grading_rubrics?: boolean; // default true

  format_preferences?: {
    separate_answer_key: boolean; // default true
    teacher_edition_inline: boolean; // default true
    editable_versions: boolean; // default true
  };
}

type MaterialType =
  | 'worksheet'
  | 'quiz'
  | 'test'
  | 'exam'
  | 'activity'
  | 'assessment';
```

### Output Schema

```typescript
interface AnswerKeyOutput {
  metadata: {
    answer_key_id: string;
    source_material_ids: string[];
    generation_date: string;
    total_questions_answered: number;
    subject_area: string;
  };

  answers: DetailedAnswer[];

  grading_support: {
    total_points: number;
    point_distribution: PointDistribution;
    grading_rubrics: GradingRubric[];
    partial_credit_guidelines: PartialCreditGuideline[];
  };

  files_generated: {
    separate_answer_key: GeneratedFile;
    teacher_edition: GeneratedFile;
    editable_versions: GeneratedFile[];
  };

  quality_metrics: {
    accuracy_score: number; // must be 100
    completeness_score: number;
    clarity_score: number;
  };
}

interface DetailedAnswer {
  material_id: string;
  material_type: MaterialType;
  question_number: number;
  question_text: string;

  correct_answer: string | string[];
  answer_format: 'text' | 'number' | 'multiple_choice' | 'boolean';

  solution_steps?: SolutionStep[];
  explanation: string;
  reasoning: string;

  common_errors: CommonError[];
  partial_credit_guidelines?: string;

  points: number;
  difficulty: 1 | 2 | 3 | 4 | 5;
}

interface SolutionStep {
  step_number: number;
  description: string;
  calculation?: string;
  result?: string;
  explanation: string;
}

interface CommonError {
  error_description: string;
  why_its_wrong: string;
  misconception: string;
  remediation_suggestion: string;
}

interface GradingRubric {
  material_id: string;
  rubric_type: 'objective' | 'subjective' | 'mixed';
  criteria: RubricCriterion[];
  total_points: number;
}

interface RubricCriterion {
  criterion_name: string;
  description: string;
  points_possible: number;
  scoring_levels: ScoringLevel[];
}

interface ScoringLevel {
  level_name: string; // e.g., "Excellent", "Good", "Fair", "Poor"
  points: number;
  description: string;
}
```

---

## 8. DEPENDENCIES MATRIX

| Phase | Depends On | Required Data | Can Run in Parallel |
|-------|-----------|---------------|---------------------|
| Phase 1 | User Request | source_materials | No |
| Phase 2 | Phase 1 | Question inventory | No |
| Phase 3 | Phase 2 | Answers | No |
| Phase 4 | Phases 2 & 3 | Answers + solutions | No |
| Phase 5 | Phases 2, 3, 4 | Complete answer content | No |
| Phase 6 | Phases 2-5 | All answer components | No |
| Phase 7 | Phase 6 | Verified content | No |
| Phase 8 | Phase 7 | Quality-checked content | Yes (multiple files) |

---

## 9. QUALITY GATES

### Phase 2: Answer Generation Quality Gate

```json
{
  "minimum_score": 100,
  "criteria": {
    "accuracy": {
      "weight": 100,
      "checks": [
        "All answers are correct",
        "Calculations verified",
        "Facts validated",
        "No errors"
      ],
      "critical": true
    }
  },
  "notes": "Answer accuracy is non-negotiable. Must be 100%."
}
```

### Phase 3: Solution Process Quality Gate

```json
{
  "minimum_score": 95,
  "criteria": {
    "accuracy": {
      "weight": 60,
      "checks": [
        "Solution leads to correct answer",
        "All steps are valid",
        "No mathematical/logical errors"
      ],
      "critical": true
    },
    "completeness": {
      "weight": 30,
      "checks": [
        "All steps shown",
        "No steps skipped",
        "Work is complete"
      ]
    },
    "clarity": {
      "weight": 10,
      "checks": [
        "Steps are clear",
        "Explanations provided",
        "Notation correct"
      ]
    }
  }
}
```

---

## 10. COMPLETE AI PROMPTS

### Phase 2: Answer Generation Prompt

```markdown
# ROLE
You are a subject matter expert providing 100% accurate answers to educational questions.

# TASK
Generate correct answers for ALL questions in the provided materials. Answer accuracy must be perfect.

# INPUT DATA
- Questions: {{all_questions}}
- Subject Area: {{subject}}
- Grade Level: {{grade}}
- Source Content: {{book_content}}

# ANSWER GENERATION REQUIREMENTS

For EACH question provide:
1. The correct answer
2. Confidence level (must be 100% to proceed)
3. Source reference if applicable
4. Verification notes

CRITICAL: If you are not 100% confident in an answer, flag it for human review. Never guess.

# OUTPUT FORMAT
```json
{
  "answers": [
    {
      "material_id": "worksheet_001",
      "question_number": 1,
      "question_text": "Original question",
      "correct_answer": "Accurate answer",
      "answer_format": "text|number|multiple_choice|boolean",
      "confidence_level": 1.0,
      "source_reference": "Chapter 3, page 42",
      "verification_notes": "Cross-checked with primary source"
    }
  ]
}
```

# QUALITY REQUIREMENTS
- 100% answer accuracy (NON-NEGOTIABLE)
- All questions must be answered
- Answers must match question format
- Calculations must be verified
- Facts must be validated

# BEGIN ANSWER GENERATION
```

### Phase 3: Solution Process Documentation Prompt

```markdown
# ROLE
You are an expert educator creating clear, step-by-step solutions for complex problems.

# TASK
Create detailed solution processes for all questions that require step-by-step explanations.

# INPUT DATA
- Questions with Answers: {{questions_and_answers}}
- Subject Area: {{subject}}
- Target Audience: {{grade_level}}

# SOLUTION DOCUMENTATION REQUIREMENTS

For each complex question:
1. Break down into clear, logical steps
2. Show all work and calculations
3. Explain reasoning at each step
4. Provide alternative methods when applicable
5. Use appropriate mathematical/scientific notation
6. Ensure solution reaches the correct answer

# OUTPUT FORMAT
```json
{
  "solutions": [
    {
      "material_id": "worksheet_001",
      "question_number": 5,
      "solution_steps": [
        {
          "step_number": 1,
          "description": "Identify what we're solving for",
          "calculation": "Let x = unknown value",
          "result": "x",
          "explanation": "We need to find the value of x"
        },
        {
          "step_number": 2,
          "description": "Set up the equation",
          "calculation": "2x + 5 = 13",
          "result": "2x + 5 = 13",
          "explanation": "Based on the given information"
        }
      ],
      "alternative_methods": [
        {
          "method_name": "Graphical method",
          "steps": [...]
        }
      ]
    }
  ]
}
```

# QUALITY REQUIREMENTS
- Solution must lead to correct answer
- All steps must be shown
- Each step must be explained
- No steps can be skipped
- Notation must be correct
- Alternative methods when relevant

# BEGIN SOLUTION DOCUMENTATION
```

---

## 11. IMPLEMENTATION GUIDE

### System Integration Points

```typescript
// API Endpoint
POST /api/v1/addons/answer-keys/generate

// Request Handler
async function generateAnswerKey(request: AnswerKeyRequest): Promise<AnswerKeyOutput> {
  // Phase 1: Source Material Analysis
  const questionInventory = await analyzeSourceMaterials({
    materialIds: request.source_material_ids,
    materialTypes: request.source_material_types
  });

  // Phase 2: Answer Generation
  const answers = await answerGenerationService.generate({
    questions: questionInventory,
    subject: request.subject_area,
    gradeLevel: request.grade_level
  });

  // Verify 100% accuracy before proceeding
  if (!answers.every(a => a.confidence_level === 1.0)) {
    throw new AnswerAccuracyError("Not all answers have 100% confidence");
  }

  // Phase 3: Solution Documentation
  const solutions = request.include_solution_steps !== false
    ? await solutionService.document({
        answers: answers,
        complexQuestions: questionInventory.filter(q => q.complexity >= 3)
      })
    : null;

  // Phase 4: Explanation & Reasoning
  const explanations = request.include_explanations !== false
    ? await explanationService.generate({
        answers: answers,
        targetAudience: request.grade_level
      })
    : null;

  // Phase 5: Common Error Analysis
  const errorAnalysis = request.include_common_errors !== false
    ? await errorAnalysisService.analyze({
        answers: answers,
        subject: request.subject_area
      })
    : null;

  // Phase 6: Grading Guidelines
  const gradingSupport = request.include_grading_rubrics !== false
    ? await gradingService.createGuidelines({
        answers: answers,
        materials: questionInventory
      })
    : null;

  // Phase 7: Quality Verification
  const qualityReport = await qualityVerificationService.verify({
    answers: answers,
    solutions: solutions,
    explanations: explanations
  });

  if (qualityReport.accuracy_score < 100) {
    throw new QualityThresholdError("Answer accuracy must be 100%");
  }

  // Phase 8: File Generation
  const files = await fileGenerationService.generate({
    answers: answers,
    solutions: solutions,
    explanations: explanations,
    errorAnalysis: errorAnalysis,
    gradingSupport: gradingSupport,
    formatPreferences: request.format_preferences
  });

  return {
    metadata: {
      answer_key_id: generateAnswerKeyId(),
      source_material_ids: request.source_material_ids,
      generation_date: new Date().toISOString(),
      total_questions_answered: answers.length,
      subject_area: request.subject_area
    },
    answers: combineAnswerComponents(answers, solutions, explanations, errorAnalysis),
    grading_support: gradingSupport,
    files_generated: files,
    quality_metrics: qualityReport
  };
}
```

### Database Schema

```sql
-- Answer Keys Table
CREATE TABLE answer_keys (
  answer_key_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_material_ids UUID[] NOT NULL,
  subject_area TEXT NOT NULL,
  grade_level TEXT NOT NULL,

  total_questions_answered INTEGER NOT NULL,
  answers JSONB NOT NULL,
  grading_support JSONB,

  generation_status TEXT NOT NULL DEFAULT 'pending',
  accuracy_score NUMERIC(5,2) NOT NULL,

  created_at TIMESTAMPTZ DEFAULT now(),
  completed_at TIMESTAMPTZ,
  created_by UUID REFERENCES users(id)
);

-- Answer Key Files Table
CREATE TABLE answer_key_files (
  file_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  answer_key_id UUID REFERENCES answer_keys(answer_key_id) NOT NULL,

  file_type TEXT NOT NULL, -- 'separate_key', 'teacher_edition', 'editable'
  file_format TEXT NOT NULL, -- 'pdf', 'docx', 'html'
  storage_url TEXT NOT NULL,
  file_size_bytes BIGINT,

  created_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX idx_answer_keys_materials ON answer_keys USING GIN(source_material_ids);
CREATE INDEX idx_answer_keys_status ON answer_keys(generation_status);
CREATE INDEX idx_answer_key_files_key ON answer_key_files(answer_key_id);

-- RLS Policies
ALTER TABLE answer_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE answer_key_files ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own answer keys"
  ON answer_keys FOR SELECT
  TO authenticated
  USING (created_by = auth.uid());

CREATE POLICY "Users can create answer keys"
  ON answer_keys FOR INSERT
  TO authenticated
  WITH CHECK (created_by = auth.uid());
```

---

## 12. COST ANALYSIS

### Token Usage & Cost per Answer Key (100 Questions)

| Phase | Model | Input | Output | Cost |
|-------|-------|-------|--------|------|
| Phase 1 | Claude-3-5-Haiku | 8,000 | 1,500 | $0.008 |
| Phase 2 | Claude-3-5-Sonnet | 25,000 | 8,000 | $0.156 |
| Phase 3 | Claude-3-5-Sonnet | 30,000 | 15,000 | $0.345 |
| Phase 4 | Claude-3-5-Sonnet | 35,000 | 12,000 | $0.341 |
| Phase 5 | GPT-4o | 40,000 | 8,000 | $0.140 |
| Phase 6 | Claude-3-5-Sonnet | 45,000 | 6,000 | $0.348 |
| Phase 7 | Gemini-2.0-Flash | 50,000 | 2,000 | $0.014 |
| **TOTAL** | | **233,000** | **52,500** | **$1.35** |

### Pricing Strategy

**Total Cost**: $1.55 (with overhead)

**Pricing Tiers**:
- Standalone Answer Key: $4.99 (222% markup, 69% margin)
- Bundled with Materials: +$2.99
- School License (10+): +$1.99 each

---

## 13. TESTING REQUIREMENTS

### Unit Tests

```typescript
describe('AnswerKeyGeneration', () => {
  describe('Phase 2: Answer Generation', () => {
    it('should answer all questions', async () => {
      const result = await answerGenerationService.generate({
        questions: mockQuestions,
        subject: 'mathematics',
        gradeLevel: '6th'
      });

      expect(result.length).toBe(mockQuestions.length);
    });

    it('should have 100% accuracy', async () => {
      const result = await answerGenerationService.generate({
        questions: mockQuestions,
        subject: 'science',
        gradeLevel: '8th'
      });

      expect(result.every(a => a.confidence_level === 1.0)).toBe(true);
    });
  });
});
```

---

## 14. APPROVAL STATUS

### Current Status: DRAFT - AWAITING APPROVAL

### Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | 2024-12-19 | System | Initial draft |
| 2.0 | 2024-12-21 | System | Complete specification |

---

**END OF SPECIFICATION**
