# Quiz Packs - Complete Technical Specification

**Version**: 2.0
**Status**: Draft - Awaiting Approval
**Feature ID**: ADDON-003
**Category**: Assessment Materials
**Complexity**: High
**Created**: 2024-12-21

---

## TABLE OF CONTENTS

1. [Overview](#1-overview)
2. [Step-by-Step Workflow](#2-step-by-step-workflow)
3. [AI Model Assignments](#3-ai-model-assignments)
4. [Technical Parameters](#4-technical-parameters)
5. [Fallback Rules](#5-fallback-rules)
6. [Verification Integration](#6-verification-integration)
7. [Input/Output Specs](#7-inputoutput-specs)
8. [Dependencies Matrix](#8-dependencies-matrix)
9. [Quality Gates](#9-quality-gates)
10. [Complete AI Prompts](#10-complete-ai-prompts)
11. [Implementation Guide](#11-implementation-guide)
12. [Cost Analysis](#12-cost-analysis)
13. [Testing Requirements](#13-testing-requirements)
14. [Approval Status](#14-approval-status)

---

## 1. OVERVIEW

### 1.1 What It Does

Generates comprehensive quiz and assessment packs with 500+ questions spanning multiple formats, difficulty levels, and question types. Each pack includes quick checks, section quizzes, chapter tests, unit exams, and comprehensive finals with complete answer keys and scoring rubrics.

### 1.2 Purpose

**Problem**: Teachers need diverse assessment tools to measure student learning. Creating 500+ quality questions manually takes weeks.

**Solution**: AI-generated quiz packs that:
- Generate 500+ high-quality questions per topic
- Organize into logical assessment hierarchy
- Support multiple question formats (MCQ, T/F, short answer, matching, etc.)
- Include detailed answer keys with explanations
- Provide grading rubrics and scoring guidelines
- Scale difficulty appropriately
- Align with learning objectives

### 1.3 Key Features

1. **Comprehensive Coverage**: 500+ questions covering all content
2. **Hierarchical Organization**: Quick checks → Section quizzes → Chapter tests → Unit exams → Final exam
3. **Multiple Question Types**: MCQ (60%), T/F (15%), Short answer (15%), Matching (5%), Fill-blank (5%)
4. **Adaptive Difficulty**: Questions scaled to target audience
5. **Complete Assessment Suite**: Pre-assessment, formative, summative, and final evaluations
6. **Detailed Scoring**: Point values, partial credit guidelines, rubrics

---

## 2. STEP-BY-STEP WORKFLOW

### Phase 1: Content Analysis & Learning Objectives Mapping
**Duration**: 10-15 seconds
**Purpose**: Analyze book content and map to testable learning objectives

#### Input Requirements
- Book content (full text or specific chapters)
- Target reading/skill level
- Subject area
- Content scope (chapter, unit, full book)

#### Processing
- AI analyzes content structure
- Extracts key concepts and facts
- Maps to Bloom's taxonomy levels
- Identifies testable learning objectives
- Creates assessment blueprint

#### Output Deliverables
- Learning objectives list (20-50 objectives)
- Concept hierarchy map
- Bloom's taxonomy distribution
- Assessment blueprint (what to test, how)
- Difficulty ratings per objective

#### Success Criteria
- 20-50 learning objectives identified
- All major concepts covered
- Balanced Bloom's taxonomy distribution
- Clear assessment strategy

---

### Phase 2: Question Bank Planning
**Duration**: 15-20 seconds
**Purpose**: Plan the complete question bank structure

#### Input Requirements
- Learning objectives from Phase 1
- Target question count (typically 500+)
- Question type distribution preferences
- Assessment types needed

#### Processing
- Organize objectives into assessment hierarchy
- Plan question distribution:
  - Quick Checks (5Q each): 40-50 quizzes = 200-250 questions
  - Section Quizzes (10Q): 20-30 quizzes = 200-300 questions
  - Chapter Tests (25Q): 12 tests = 300 questions
  - Unit Exams (50Q): 4-6 exams = 200-300 questions
  - Comprehensive Final (100-150Q): 1 exam = 100-150 questions
  - Pre/Post Assessments: 2 tests = 100 questions
- Assign question types to objectives
- Calculate difficulty distribution

#### Output Deliverables
- Complete quiz structure plan
- Question count per assessment
- Question type distribution per quiz
- Difficulty progression map
- Testing schedule suggestion

#### Success Criteria
- Total questions meet target (500+)
- Logical progression from simple to complex
- Balanced question type distribution
- No learning objective gaps

---

### Phase 3: Question Generation - Quick Checks & Formative
**Duration**: 90-120 seconds (parallel)
**Purpose**: Generate quick check and section quiz questions

#### Input Requirements
- Quiz structure plan
- Book content
- Learning objectives
- Question type requirements

#### Processing (Per Quiz)
- Generate questions for each quiz
- Ensure variety in question types
- Match difficulty to objectives
- Create clear, unambiguous questions
- Include distractors for MCQ
- Validate against content

#### Output Deliverables (Per Quiz)
- 5-10 questions per quiz
- Clear instructions
- Answer choices (for MCQ/matching)
- Point values assigned
- Estimated time to complete

#### Success Criteria (Per Quiz)
- Correct number of questions
- Clear, unambiguous wording
- Appropriate difficulty
- Valid distractors for MCQ
- No errors or ambiguity

---

### Phase 4: Question Generation - Summative Assessments
**Duration**: 120-180 seconds (parallel)
**Purpose**: Generate chapter tests, unit exams, and final exam

#### Input Requirements
- Assessment structure plan
- Book content
- Cumulative learning objectives
- Question requirements

#### Processing (Per Assessment)
- Generate comprehensive questions
- Cover all relevant objectives
- Mix question types
- Create complex scenario questions
- Ensure no question overlap with formative
- Build on prior knowledge

#### Output Deliverables (Per Assessment)
- 25-150 questions per assessment
- Mixed question types
- Clear instructions
- Scoring guidelines
- Time recommendations

#### Success Criteria (Per Assessment)
- Complete coverage of objectives
- Appropriate complexity
- No duplicate questions
- Clear scoring criteria
- Realistic time estimates

---

### Phase 5: Answer Key Generation
**Duration**: 60-90 seconds
**Purpose**: Create complete answer keys for all assessments

#### Input Requirements
- All generated quizzes/exams
- Subject matter context
- Grading preferences

#### Processing
- Generate correct answers
- Create detailed explanations
- Provide solution steps (where applicable)
- Note common misconceptions
- Assign point values
- Create partial credit guidelines
- Build grading rubrics

#### Output Deliverables
- Complete answer key for all 500+ questions
- Detailed explanations
- Solution steps for complex problems
- Common error identification
- Point value justifications
- Grading rubrics for subjective questions

#### Success Criteria
- 100% answer accuracy (CRITICAL)
- All questions have answers
- Explanations are clear
- Rubrics are detailed
- Point values are reasonable

---

### Phase 6: Quality Verification & Validation
**Duration**: 20-30 seconds
**Purpose**: Verify quality and accuracy of entire question bank

#### Input Requirements
- Complete quiz pack
- Answer keys
- Quality standards

#### Processing
- Verify question quality
- Check answer accuracy
- Validate difficulty progression
- Ensure objective coverage
- Check for duplicates
- Verify question clarity
- Validate scoring guidelines

#### Output Deliverables
- Quality score (0-100)
- Validation report
- Issue list (if any)
- Coverage analysis
- Difficulty distribution confirmation

#### Success Criteria
- Quality score ≥ 90
- No critical errors
- 100% answer accuracy
- Complete objective coverage
- Appropriate difficulty distribution

---

### Phase 7: File Generation & Packaging
**Duration**: 25-35 seconds
**Purpose**: Generate all quiz files in required formats

#### Input Requirements
- Validated quiz pack
- Answer keys
- Format preferences

#### Processing
- Generate student versions (no answers)
- Generate teacher versions (with answers)
- Create separate answer keys
- Generate grading rubrics
- Create scantron-compatible versions
- Export to multiple formats
- Optimize for printing

#### Output Deliverables
- Student quiz PDFs
- Teacher edition PDFs
- Separate answer key PDFs
- Editable DOCX versions
- Scantron-compatible PDFs
- Digital quiz files (HTML/JSON)
- Storage URLs

#### Success Criteria
- All files generated successfully
- Professional formatting
- Print-optimized
- Digital versions functional
- Files accessible in storage

---

## 3. AI MODEL ASSIGNMENTS

```json
{
  "phase_1_content_analysis": {
    "primary_model": "claude-3-5-sonnet-20241022",
    "rationale": "Excellent at analyzing educational content and extracting learning objectives",
    "estimated_tokens": {
      "input": 15000,
      "output": 3500
    }
  },

  "phase_2_question_bank_planning": {
    "primary_model": "gpt-4o",
    "rationale": "Superior organizational and planning capabilities",
    "estimated_tokens": {
      "input": 5000,
      "output": 4000
    }
  },

  "phase_3_formative_question_generation": {
    "primary_model": "claude-3-5-sonnet-20241022",
    "rationale": "Best at creating clear, well-formatted quiz questions",
    "estimated_tokens_per_batch": {
      "input": 8000,
      "output": 5000
    },
    "parallel_processing": {
      "concurrent_batches": 8,
      "batch_size": 10
    }
  },

  "phase_4_summative_question_generation": {
    "primary_model": "claude-3-5-sonnet-20241022",
    "rationale": "Handles complex assessment creation well",
    "estimated_tokens_per_assessment": {
      "input": 12000,
      "output": 8000
    },
    "parallel_processing": {
      "concurrent_assessments": 6,
      "batch_size": 3
    }
  },

  "phase_5_answer_key_generation": {
    "primary_model": "claude-3-5-sonnet-20241022",
    "rationale": "Highly accurate at solving problems and explaining solutions",
    "estimated_tokens": {
      "input": 60000,
      "output": 30000
    }
  },

  "phase_6_quality_verification": {
    "primary_model": "gemini-2.0-flash-exp",
    "rationale": "Fast, efficient verification with good accuracy checking",
    "estimated_tokens": {
      "input": 80000,
      "output": 3000
    }
  }
}
```

---

## 4. TECHNICAL PARAMETERS

### Phase 1: Content Analysis & Learning Objectives Mapping

```json
{
  "technical_parameters": {
    "ai_model": "claude-3-5-sonnet-20241022",
    "temperature": 0.3,
    "max_tokens": 4500,
    "context_window_used": "~18K tokens",
    "timeout": 30000,
    "retry_attempts": 3,

    "quality_thresholds": {
      "min_objectives": 20,
      "max_objectives": 50,
      "bloom_taxonomy_coverage_all_levels": true,
      "difficulty_range_min": 1,
      "difficulty_range_max": 5
    },

    "validation_rules": {
      "each_objective_has_description": true,
      "each_objective_has_bloom_level": true,
      "each_objective_has_difficulty": true,
      "no_duplicate_objectives": true,
      "assessment_blueprint_present": true
    }
  }
}
```

### Phase 2: Question Bank Planning

```json
{
  "technical_parameters": {
    "ai_model": "gpt-4o",
    "temperature": 0.4,
    "max_tokens": 5000,
    "context_window_used": "~9K tokens",
    "timeout": 35000,
    "retry_attempts": 3,

    "quality_thresholds": {
      "total_questions_min": 500,
      "question_type_distribution_tolerance": 0.05,
      "difficulty_distribution_appropriate": true,
      "all_objectives_tested": true
    },

    "validation_rules": {
      "hierarchical_structure_valid": true,
      "question_counts_match_target": true,
      "no_objective_gaps": true,
      "logical_progression": true,
      "time_estimates_reasonable": true
    }
  }
}
```

### Phase 3: Formative Question Generation

```json
{
  "technical_parameters": {
    "ai_model": "claude-3-5-sonnet-20241022",
    "temperature": 0.5,
    "max_tokens": 6000,
    "context_window_per_batch": "~13K tokens",
    "timeout_per_batch": 45000,
    "retry_attempts": 3,
    "parallel_processing": {
      "enabled": true,
      "concurrent_limit": 8,
      "batch_size": 10
    },

    "quality_thresholds": {
      "questions_per_quiz_match_plan": true,
      "question_clarity_score": 0.90,
      "distractor_quality_mcq": 0.85,
      "no_ambiguous_questions": true
    },

    "validation_rules": {
      "all_questions_have_clear_wording": true,
      "mcq_has_valid_distractors": true,
      "answer_choices_provided": true,
      "point_values_assigned": true,
      "no_typos_or_errors": true
    }
  }
}
```

### Phase 4: Summative Question Generation

```json
{
  "technical_parameters": {
    "ai_model": "claude-3-5-sonnet-20241022",
    "temperature": 0.5,
    "max_tokens": 9000,
    "context_window_per_assessment": "~20K tokens",
    "timeout_per_assessment": 60000,
    "retry_attempts": 3,
    "parallel_processing": {
      "enabled": true,
      "concurrent_limit": 6,
      "batch_size": 3
    },

    "quality_thresholds": {
      "comprehensive_coverage": true,
      "no_question_overlap_with_formative": true,
      "appropriate_complexity": true,
      "question_clarity_score": 0.90
    },

    "validation_rules": {
      "all_objectives_tested": true,
      "question_variety_maintained": true,
      "difficulty_appropriate": true,
      "no_duplicate_questions": true,
      "scoring_guidelines_clear": true
    }
  }
}
```

### Phase 5: Answer Key Generation

```json
{
  "technical_parameters": {
    "ai_model": "claude-3-5-sonnet-20241022",
    "temperature": 0.2,
    "max_tokens": 32000,
    "context_window_used": "~90K tokens",
    "timeout": 120000,
    "retry_attempts": 3,

    "quality_thresholds": {
      "answer_accuracy_required": 1.0,
      "all_questions_answered": true,
      "explanations_provided": true,
      "rubrics_detailed": true
    },

    "validation_rules": {
      "answers_are_correct": true,
      "explanations_are_clear": true,
      "solution_steps_for_complex": true,
      "partial_credit_guidelines": true,
      "point_values_justified": true
    }
  }
}
```

### Phase 6: Quality Verification

```json
{
  "technical_parameters": {
    "ai_model": "gemini-2.0-flash-exp",
    "temperature": 0.1,
    "max_tokens": 4000,
    "context_window_used": "~83K tokens",
    "timeout": 40000,
    "retry_attempts": 2,

    "quality_thresholds": {
      "overall_score_minimum": 90,
      "accuracy_score_minimum": 98,
      "clarity_score_minimum": 90,
      "coverage_score_minimum": 95
    },

    "validation_rules": {
      "all_questions_verified": true,
      "answer_keys_accurate": true,
      "no_duplicate_questions": true,
      "difficulty_progression_logical": true,
      "objective_coverage_complete": true
    }
  }
}
```

---

## 5. FALLBACK RULES

```json
{
  "fallback_configuration": {
    "max_retry_attempts_before_fallback": 3,
    "retry_delay_ms": 2500,
    "exponential_backoff": true,

    "phase_fallbacks": {
      "phase_1_content_analysis": {
        "primary": "claude-3-5-sonnet-20241022",
        "fallback_1": "gpt-4o",
        "fallback_2": "gemini-2.0-flash-exp",
        "fallback_3": "claude-3-5-haiku-20241022"
      },

      "phase_2_question_bank_planning": {
        "primary": "gpt-4o",
        "fallback_1": "claude-3-5-sonnet-20241022",
        "fallback_2": "gemini-2.0-flash-exp",
        "fallback_3": null
      },

      "phase_3_formative_generation": {
        "primary": "claude-3-5-sonnet-20241022",
        "fallback_1": "gpt-4o",
        "fallback_2": "claude-3-5-haiku-20241022",
        "fallback_3": null
      },

      "phase_4_summative_generation": {
        "primary": "claude-3-5-sonnet-20241022",
        "fallback_1": "gpt-4o",
        "fallback_2": "claude-3-5-haiku-20241022",
        "fallback_3": null
      },

      "phase_5_answer_keys": {
        "primary": "claude-3-5-sonnet-20241022",
        "fallback_1": "gpt-4o",
        "fallback_2": "gemini-2.0-flash-exp",
        "fallback_3": null
      },

      "phase_6_quality_verification": {
        "primary": "gemini-2.0-flash-exp",
        "fallback_1": "claude-3-5-haiku-20241022",
        "fallback_2": "gpt-4o-mini",
        "fallback_3": "claude-3-5-sonnet-20241022"
      }
    }
  }
}
```

---

## 6. VERIFICATION INTEGRATION

### Phase 1: Content Analysis Verification

```json
{
  "verification_checks": {
    "quantity_validation": {
      "min_objectives": 20,
      "max_objectives": 50,
      "failure_action": "reject_retry"
    },
    "completeness_validation": {
      "each_objective_has_description": true,
      "each_objective_has_bloom_level": true,
      "each_objective_has_difficulty": true,
      "description_min_length": 40,
      "failure_action": "reject_retry"
    },
    "quality_validation": {
      "no_duplicate_objectives": true,
      "bloom_levels_balanced": true,
      "assessment_blueprint_valid": true,
      "failure_action": "log_warning"
    }
  }
}
```

### Phase 3 & 4: Question Generation Verification

```json
{
  "verification_checks": {
    "quantity_validation": {
      "questions_match_plan": true,
      "failure_action": "reject_retry"
    },
    "quality_validation": {
      "questions_are_clear": true,
      "no_ambiguous_wording": true,
      "mcq_distractors_valid": true,
      "difficulty_consistent": true,
      "failure_action": "reject_retry"
    },
    "accuracy_validation": {
      "questions_test_objectives": true,
      "no_errors_or_typos": true,
      "point_values_reasonable": true,
      "failure_action": "reject_retry"
    }
  }
}
```

### Phase 5: Answer Key Verification

```json
{
  "verification_checks": {
    "completeness_validation": {
      "all_questions_answered": true,
      "failure_action": "reject_retry_critical"
    },
    "accuracy_validation": {
      "answers_are_correct": true,
      "explanations_provided": true,
      "solution_steps_shown": true,
      "failure_action": "reject_retry_critical"
    },
    "grading_validation": {
      "point_values_assigned": true,
      "rubrics_provided": true,
      "partial_credit_guidelines": true,
      "failure_action": "log_warning"
    }
  }
}
```

---

## 7. INPUT/OUTPUT SPECS

### Input Schema

```typescript
interface QuizPackRequest {
  // REQUIRED
  book_id: string;
  content_scope: 'full_book' | 'unit' | 'chapter' | 'section';

  target_audience: {
    age_range: { min_age: number; max_age: number; };
    grade_level: string;
    skill_level: 'beginner' | 'intermediate' | 'advanced';
  };

  quiz_preferences: {
    total_questions_target: number; // typically 500+
    question_type_distribution?: {
      multiple_choice_percent: number; // default 60%
      true_false_percent: number; // default 15%
      short_answer_percent: number; // default 15%
      matching_percent: number; // default 5%
      fill_blank_percent: number; // default 5%
    };
    difficulty_distribution?: {
      easy: number; // percentage
      medium: number;
      hard: number;
    };
  };

  // OPTIONAL
  assessment_types_include?: AssessmentType[];
  standards_alignment?: string[]; // e.g., ["CCSS.MATH.6.NS.A.1"]

  format_preferences?: {
    include_scantron_versions: boolean;
    include_digital_versions: boolean;
    color_vs_bw: 'color' | 'black_and_white' | 'both';
  };
}

type AssessmentType =
  | 'quick_checks'
  | 'section_quizzes'
  | 'chapter_tests'
  | 'unit_exams'
  | 'final_exam'
  | 'pre_assessment'
  | 'post_assessment';
```

### Output Schema

```typescript
interface QuizPackOutput {
  metadata: {
    pack_id: string;
    source_book_id: string;
    generation_date: string;
    total_assessments: number;
    total_questions: number;
    question_type_breakdown: {
      multiple_choice: number;
      true_false: number;
      short_answer: number;
      matching: number;
      fill_blank: number;
    };
    difficulty_profile: {
      easy_count: number;
      medium_count: number;
      hard_count: number;
    };
  };

  assessments: {
    quick_checks: Assessment[];
    section_quizzes: Assessment[];
    chapter_tests: Assessment[];
    unit_exams: Assessment[];
    final_exam: Assessment;
    pre_assessment?: Assessment;
    post_assessment?: Assessment;
  };

  answer_keys: {
    complete_answer_key: AnswerKeySet;
    grading_rubrics: GradingRubric[];
  };

  files_generated: {
    student_versions: GeneratedFile[];
    teacher_editions: GeneratedFile[];
    answer_keys_separate: GeneratedFile[];
    scantron_versions?: GeneratedFile[];
    digital_versions?: GeneratedFile[];
  };

  quality_metrics: {
    overall_score: number;
    accuracy_score: number;
    clarity_score: number;
    coverage_score: number;
  };
}

interface Assessment {
  assessment_id: string;
  assessment_type: AssessmentType;
  title: string;
  objectives_tested: string[];
  questions: Question[];
  total_points: number;
  estimated_time_minutes: number;
  difficulty_level: 'easy' | 'medium' | 'hard';
}

interface Question {
  question_number: number;
  question_type: 'mcq' | 'true_false' | 'short_answer' | 'matching' | 'fill_blank';
  question_text: string;
  options?: string[]; // for MCQ, matching
  correct_answer: string | string[];
  points: number;
  difficulty: 1 | 2 | 3 | 4 | 5;
  bloom_level: 'remember' | 'understand' | 'apply' | 'analyze' | 'evaluate' | 'create';
  objective_tested: string;
}

interface AnswerKeySet {
  answers: DetailedAnswer[];
  total_points: number;
}

interface DetailedAnswer {
  assessment_id: string;
  question_number: number;
  correct_answer: string | string[];
  explanation: string;
  solution_steps?: string[];
  common_errors: string[];
  partial_credit_guidelines?: string;
  points: number;
}

interface GradingRubric {
  assessment_id: string;
  rubric_type: 'objective' | 'subjective';
  scoring_criteria: ScoringCriterion[];
  point_distribution: {
    knowledge_recall: number;
    comprehension: number;
    application: number;
    analysis: number;
    synthesis: number;
    evaluation: number;
  };
}
```

---

## 8. DEPENDENCIES MATRIX

| Phase | Depends On | Required Data | Can Run in Parallel |
|-------|-----------|---------------|---------------------|
| Phase 1 | User Request | book_id, content, target_audience | No |
| Phase 2 | Phase 1 | Learning objectives, assessment blueprint | No |
| Phase 3 | Phase 2 | Question bank plan, formative structure | Yes (8 concurrent) |
| Phase 4 | Phase 2 | Question bank plan, summative structure | Yes (6 concurrent) |
| Phase 5 | Phases 3 & 4 | All generated questions | No |
| Phase 6 | Phase 5 | Complete pack + answer keys | No |
| Phase 7 | Phase 6 | Validated content | Yes (multiple files) |

---

## 9. QUALITY GATES

### Phase 1: Content Analysis Quality Gate

```json
{
  "minimum_score": 85,
  "criteria": {
    "completeness": {
      "weight": 40,
      "checks": [
        "20-50 objectives identified",
        "All objectives have descriptions",
        "Bloom's taxonomy levels assigned"
      ]
    },
    "accuracy": {
      "weight": 40,
      "checks": [
        "Objectives reflect content accurately",
        "Difficulty ratings appropriate",
        "No duplicate objectives"
      ]
    },
    "usefulness": {
      "weight": 20,
      "checks": [
        "Assessment blueprint provided",
        "Clear testing strategy"
      ]
    }
  }
}
```

### Phase 3 & 4: Question Generation Quality Gate

```json
{
  "minimum_score": 90,
  "criteria": {
    "completeness": {
      "weight": 30,
      "checks": [
        "Target question count met",
        "All question types included",
        "All objectives tested"
      ]
    },
    "clarity": {
      "weight": 40,
      "checks": [
        "Questions are unambiguous",
        "Language is age-appropriate",
        "Instructions are clear",
        "MCQ distractors are plausible"
      ]
    },
    "accuracy": {
      "weight": 30,
      "checks": [
        "Questions test stated objectives",
        "Difficulty is appropriate",
        "No errors or typos"
      ]
    }
  }
}
```

### Phase 5: Answer Key Quality Gate

```json
{
  "minimum_score": 98,
  "criteria": {
    "accuracy": {
      "weight": 70,
      "checks": [
        "All answers are correct",
        "Solution steps are accurate",
        "No errors"
      ],
      "critical": true
    },
    "completeness": {
      "weight": 20,
      "checks": [
        "All questions answered",
        "Explanations provided",
        "Rubrics detailed"
      ],
      "critical": true
    },
    "usefulness": {
      "weight": 10,
      "checks": [
        "Common errors noted",
        "Partial credit guidelines",
        "Point values justified"
      ]
    }
  }
}
```

---

## 10. COMPLETE AI PROMPTS

### Phase 1: Content Analysis Prompt

```markdown
# ROLE
You are an educational assessment expert specializing in analyzing learning content and creating testable learning objectives.

# TASK
Analyze the provided content and extract all testable learning objectives that students should be able to demonstrate.

# INPUT DATA
- Book Content: {{content}}
- Subject Area: {{subject}}
- Grade Level: {{grade}}
- Target Question Count: {{target_questions}}

# EXTRACTION REQUIREMENTS

Extract 20-50 learning objectives that:
1. Are measurable and testable
2. Cover the full content scope
3. Span all Bloom's taxonomy levels
4. Build on each other logically
5. Can be assessed through various question types

For each objective, provide:
- Objective ID (unique)
- Objective statement (clear, measurable)
- Description (what students will demonstrate)
- Bloom's taxonomy level
- Difficulty rating (1-5)
- Suggested question types for testing
- Estimated questions needed

# OUTPUT FORMAT
```json
{
  "learning_objectives": [
    {
      "objective_id": "obj_001",
      "statement": "Students will be able to...",
      "description": "Detailed description (min 40 chars)",
      "bloom_level": "understand",
      "difficulty": 3,
      "suggested_question_types": ["mcq", "short_answer"],
      "estimated_questions": 10
    }
  ],
  "assessment_blueprint": {
    "bloom_distribution": {
      "remember": 0.15,
      "understand": 0.25,
      "apply": 0.25,
      "analyze": 0.20,
      "evaluate": 0.10,
      "create": 0.05
    },
    "difficulty_distribution": {
      "easy": 0.30,
      "medium": 0.50,
      "hard": 0.20
    },
    "testing_strategy": "Description of assessment approach"
  }
}
```

# QUALITY REQUIREMENTS
- 20-50 objectives total
- Each objective >= 40 character description
- All Bloom's levels represented
- Clear difficulty progression
- Balanced testing strategy

# BEGIN EXTRACTION
```

### Phase 3: Formative Question Generation Prompt

```markdown
# ROLE
You are an expert quiz creator specializing in formative assessment questions.

# TASK
Generate {{questions_per_quiz}} high-quality quiz questions for formative assessment.

# INPUT DATA
- Quiz Type: {{quiz_type}}
- Learning Objectives: {{objectives}}
- Difficulty Level: {{difficulty}}
- Question Types: {{question_types}}
- Book Content: {{content_excerpt}}
- Target Age: {{age}}

# QUESTION GENERATION REQUIREMENTS

Generate {{questions_per_quiz}} questions that:
1. Test the stated learning objectives
2. Match the specified difficulty level
3. Use the designated question types
4. Are clear and unambiguous
5. Have age-appropriate language
6. Include valid distractors (for MCQ)

Question Type Distribution:
- {{question_type_breakdown}}

# OUTPUT FORMAT (Per Question)
```json
{
  "question_number": 1,
  "question_type": "mcq",
  "question_text": "Clear, concise question",
  "options": ["A", "B", "C", "D"], // if MCQ
  "correct_answer": "B",
  "distractor_rationale": ["Why A is wrong", "Why C is wrong", "Why D is wrong"],
  "points": 2,
  "difficulty": 3,
  "bloom_level": "apply",
  "objective_tested": "obj_001"
}
```

# QUALITY REQUIREMENTS
- {{questions_per_quiz}} questions total
- All questions are clear and unambiguous
- MCQ distractors are plausible
- Difficulty is consistent
- No ambiguous wording
- Age-appropriate vocabulary

# BEGIN GENERATION
```

### Phase 5: Answer Key Generation Prompt

```markdown
# ROLE
You are a subject matter expert creating comprehensive, accurate answer keys.

# TASK
Generate complete answer keys for all {{total_questions}} questions with correct answers, detailed explanations, and grading guidelines.

# INPUT DATA
- Complete Quiz Pack: {{all_quizzes}}
- Subject Area: {{subject}}
- Grade Level: {{grade}}

# ANSWER KEY REQUIREMENTS

For EACH question provide:
1. Correct answer(s)
2. Detailed explanation of why answer is correct
3. Solution steps (for problem-solving questions)
4. Common errors students make
5. Partial credit guidelines (where applicable)
6. Point value justification

# OUTPUT FORMAT
```json
{
  "answer_key": [
    {
      "assessment_id": "quiz_001",
      "question_number": 1,
      "correct_answer": "Answer",
      "explanation": "Detailed explanation why this is correct",
      "solution_steps": [
        "Step 1: ...",
        "Step 2: ..."
      ],
      "common_errors": [
        "Students often confuse...",
        "Common mistake is..."
      ],
      "partial_credit_guidelines": "Award 1 point for..., 2 points for...",
      "points": 3
    }
  ],
  "grading_rubrics": [
    {
      "assessment_id": "quiz_001",
      "rubric_type": "objective",
      "scoring_criteria": [
        {
          "criterion": "Correct answer",
          "points": 2
        },
        {
          "criterion": "Work shown",
          "points": 1
        }
      ],
      "point_distribution": {
        "knowledge_recall": 30,
        "comprehension": 30,
        "application": 40
      }
    }
  ]
}
```

# QUALITY REQUIREMENTS
- 100% answer accuracy (CRITICAL)
- All questions have answers
- Explanations are detailed and clear
- Rubrics are comprehensive
- Partial credit guidelines are fair
- Common errors identified

# BEGIN ANSWER KEY CREATION
```

---

## 11. IMPLEMENTATION GUIDE

### System Integration Points

```typescript
// API Endpoint
POST /api/v1/addons/quiz-packs/generate

// Request Handler
async function generateQuizPack(request: QuizPackRequest): Promise<QuizPackOutput> {
  // Phase 1: Content Analysis
  const objectives = await contentAnalysisService.analyze({
    bookContent: await getBookContent(request.book_id),
    targetAudience: request.target_audience,
    targetQuestions: request.quiz_preferences.total_questions_target
  });

  // Phase 2: Question Bank Planning
  const questionBankPlan = await questionBankPlanningService.plan({
    objectives: objectives,
    preferences: request.quiz_preferences,
    assessmentTypes: request.assessment_types_include || DEFAULT_TYPES
  });

  // Phase 3: Formative Question Generation (Parallel)
  const formativeQuestions = await Promise.all([
    ...questionBankPlan.quick_checks.map(quiz =>
      questionGenerationService.generateFormative(quiz)
    ),
    ...questionBankPlan.section_quizzes.map(quiz =>
      questionGenerationService.generateFormative(quiz)
    )
  ]);

  // Phase 4: Summative Question Generation (Parallel)
  const summativeQuestions = await Promise.all([
    ...questionBankPlan.chapter_tests.map(test =>
      questionGenerationService.generateSummative(test)
    ),
    ...questionBankPlan.unit_exams.map(exam =>
      questionGenerationService.generateSummative(exam)
    ),
    questionGenerationService.generateFinalExam(questionBankPlan.final_exam)
  ]);

  // Phase 5: Answer Key Generation
  const answerKeys = await answerKeyService.generate({
    formativeQuestions: formativeQuestions,
    summativeQuestions: summativeQuestions,
    subject: request.target_audience.subject
  });

  // Phase 6: Quality Verification
  const qualityReport = await qualityVerificationService.verify({
    allQuestions: [...formativeQuestions, ...summativeQuestions],
    answerKeys: answerKeys,
    objectives: objectives
  });

  if (qualityReport.overall_score < 90) {
    throw new QualityThresholdError(qualityReport);
  }

  // Phase 7: File Generation
  const files = await fileGenerationService.generate({
    assessments: { formative: formativeQuestions, summative: summativeQuestions },
    answerKeys: answerKeys,
    formatPreferences: request.format_preferences
  });

  return {
    metadata: {
      pack_id: generatePackId(),
      source_book_id: request.book_id,
      generation_date: new Date().toISOString(),
      total_assessments: formativeQuestions.length + summativeQuestions.length,
      total_questions: calculateTotalQuestions([...formativeQuestions, ...summativeQuestions]),
      question_type_breakdown: calculateTypeBreakdown([...formativeQuestions, ...summativeQuestions]),
      difficulty_profile: calculateDifficultyProfile([...formativeQuestions, ...summativeQuestions])
    },
    assessments: organizessments(formativeQuestions, summativeQuestions),
    answer_keys: answerKeys,
    files_generated: files,
    quality_metrics: qualityReport
  };
}
```

### Database Schema

```sql
-- Quiz Packs Table
CREATE TABLE quiz_packs (
  pack_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_book_id UUID REFERENCES books(id) NOT NULL,
  content_scope TEXT NOT NULL,
  target_audience JSONB NOT NULL,
  quiz_preferences JSONB NOT NULL,

  total_assessments INTEGER NOT NULL,
  total_questions INTEGER NOT NULL,
  question_type_breakdown JSONB NOT NULL,
  difficulty_profile JSONB NOT NULL,

  generation_status TEXT NOT NULL DEFAULT 'pending',
  quality_score NUMERIC(5,2),

  created_at TIMESTAMPTZ DEFAULT now(),
  completed_at TIMESTAMPTZ,
  created_by UUID REFERENCES users(id)
);

-- Assessments Table
CREATE TABLE assessments (
  assessment_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pack_id UUID REFERENCES quiz_packs(pack_id) NOT NULL,

  assessment_type TEXT NOT NULL,
  title TEXT NOT NULL,
  objectives_tested TEXT[] NOT NULL,
  questions JSONB NOT NULL,
  total_points INTEGER NOT NULL,
  estimated_time_minutes INTEGER,
  difficulty_level TEXT NOT NULL,

  created_at TIMESTAMPTZ DEFAULT now()
);

-- Quiz Answer Keys Table
CREATE TABLE quiz_answer_keys (
  answer_key_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pack_id UUID REFERENCES quiz_packs(pack_id) NOT NULL,

  answers JSONB NOT NULL,
  grading_rubrics JSONB NOT NULL,
  total_points INTEGER NOT NULL,

  created_at TIMESTAMPTZ DEFAULT now()
);

-- Quiz Files Table
CREATE TABLE quiz_files (
  file_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pack_id UUID REFERENCES quiz_packs(pack_id) NOT NULL,

  file_type TEXT NOT NULL, -- 'student_version', 'teacher_edition', 'answer_key', 'scantron'
  file_format TEXT NOT NULL, -- 'pdf', 'docx', 'html', 'json'
  storage_url TEXT NOT NULL,
  file_size_bytes BIGINT,

  created_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX idx_quiz_packs_book ON quiz_packs(source_book_id);
CREATE INDEX idx_quiz_packs_status ON quiz_packs(generation_status);
CREATE INDEX idx_assessments_pack ON assessments(pack_id);
CREATE INDEX idx_quiz_answer_keys_pack ON quiz_answer_keys(pack_id);
CREATE INDEX idx_quiz_files_pack ON quiz_files(pack_id);

-- RLS Policies
ALTER TABLE quiz_packs ENABLE ROW LEVEL SECURITY;
ALTER TABLE assessments ENABLE ROW LEVEL SECURITY;
ALTER TABLE quiz_answer_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE quiz_files ENABLE ROW LEVEL SECURITY;

-- Users can view their own quiz packs
CREATE POLICY "Users can view own quiz packs"
  ON quiz_packs FOR SELECT
  TO authenticated
  USING (created_by = auth.uid());

-- Users can create quiz packs
CREATE POLICY "Users can create quiz packs"
  ON quiz_packs FOR INSERT
  TO authenticated
  WITH CHECK (created_by = auth.uid());
```

---

## 12. COST ANALYSIS

### Token Usage & Cost per Pack (500 Questions)

| Phase | Model | Input | Output | Cost |
|-------|-------|-------|--------|------|
| Phase 1 | Claude-3-5-Sonnet | 15,000 | 3,500 | $0.065 |
| Phase 2 | GPT-4o | 5,000 | 4,000 | $0.035 |
| Phase 3 (×8 batches) | Claude-3-5-Sonnet | 64,000 | 40,000 | $0.816 |
| Phase 4 (×6 assessments) | Claude-3-5-Sonnet | 72,000 | 48,000 | $0.996 |
| Phase 5 | Claude-3-5-Sonnet | 60,000 | 30,000 | $0.585 |
| Phase 6 | Gemini-2.0-Flash | 80,000 | 3,000 | $0.022 |
| **TOTAL** | | **296,000** | **128,500** | **$2.52** |

### Pricing Strategy

**Total Cost**: $2.85 (with overhead)

**Pricing Tiers**:
- Single Pack: $14.99 (426% markup, 81% margin)
- 3-Pack Bundle: $39.99 ($13.33 each)
- 5-Pack Bundle: $59.99 ($12.00 each)
- School License (10+): $99.99 ($10.00 each)

---

## 13. TESTING REQUIREMENTS

### Unit Tests

```typescript
describe('QuizPackGeneration', () => {
  describe('Phase 1: Content Analysis', () => {
    it('should extract 20-50 learning objectives', async () => {
      const result = await contentAnalysisService.analyze({
        bookContent: mockBookContent,
        targetAudience: mockAudience,
        targetQuestions: 500
      });

      expect(result.learning_objectives.length).toBeGreaterThanOrEqual(20);
      expect(result.learning_objectives.length).toBeLessThanOrEqual(50);
    });

    it('should assign Bloom levels to all objectives', async () => {
      const result = await contentAnalysisService.analyze({
        bookContent: mockBookContent,
        targetAudience: mockAudience,
        targetQuestions: 500
      });

      result.learning_objectives.forEach(obj => {
        expect(obj.bloom_level).toMatch(/remember|understand|apply|analyze|evaluate|create/);
      });
    });
  });

  describe('Phase 2: Question Bank Planning', () => {
    it('should plan for target question count', async () => {
      const result = await questionBankPlanningService.plan({
        objectives: mockObjectives,
        preferences: { total_questions_target: 500 },
        assessmentTypes: DEFAULT_TYPES
      });

      const totalPlanned = calculateTotalQuestions(result);
      expect(totalPlanned).toBeGreaterThanOrEqual(490);
      expect(totalPlanned).toBeLessThanOrEqual(510);
    });
  });

  describe('Phase 5: Answer Key Generation', () => {
    it('should provide answers for all 500+ questions', async () => {
      const result = await answerKeyService.generate({
        formativeQuestions: mockFormativeQuestions,
        summativeQuestions: mockSummativeQuestions,
        subject: 'mathematics'
      });

      expect(result.complete_answer_key.answers.length).toBeGreaterThanOrEqual(500);
    });

    it('should have 100% answer accuracy', async () => {
      const result = await answerKeyService.generate({
        formativeQuestions: mockFormativeQuestions,
        summativeQuestions: mockSummativeQuestions,
        subject: 'science'
      });

      // Verify each answer is correct (this would use validation logic)
      const accuracyScore = await validateAnswerAccuracy(result);
      expect(accuracyScore).toBe(1.0);
    });
  });
});
```

---

## 14. APPROVAL STATUS

### Current Status: DRAFT - AWAITING APPROVAL

### Review Checklist

- [ ] **Technical Review**
  - [ ] AI model assignments verified
  - [ ] Token estimates validated
  - [ ] Cost analysis confirmed
  - [ ] Fallback rules tested

- [ ] **Quality Review**
  - [ ] Quality gates appropriate
  - [ ] Verification rules comprehensive
  - [ ] Success criteria measurable
  - [ ] Error handling robust

- [ ] **Implementation Review**
  - [ ] Database schema validated
  - [ ] API endpoints defined
  - [ ] Integration points clear
  - [ ] Monitoring in place

- [ ] **Testing Review**
  - [ ] Unit test coverage adequate
  - [ ] Integration tests comprehensive
  - [ ] Performance tests defined
  - [ ] Edge cases covered

### Approval Required From

1. **Technical Lead**: ___________________ Date: ______
2. **Product Owner**: ___________________ Date: ______
3. **QA Lead**: ___________________ Date: ______

### Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | 2024-12-19 | System | Initial draft |
| 2.0 | 2024-12-21 | System | Complete specification with all sections |

---

**END OF SPECIFICATION**
