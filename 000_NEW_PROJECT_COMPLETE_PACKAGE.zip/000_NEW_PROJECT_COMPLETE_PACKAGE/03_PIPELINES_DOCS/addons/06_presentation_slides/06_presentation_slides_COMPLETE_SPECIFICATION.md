# Presentation Slides - Complete Technical Specification

**Version**: 4.0
**Status**: Production Ready
**Feature ID**: ADDON-006
**Category**: Visual Teaching Materials
**Complexity**: High
**Created**: 2024-12-19
**Updated**: 2024-12-23 (Complete workflow & implementation added)

---

## 1. OVERVIEW

### 1.1 What It Does

Generates professional presentation slide decks with **AI-powered visual design**, content organization, speaker notes, and teaching prompts. Features multiple design styles from simple to highly visually appealing (Gamma.ai/Beautiful.ai style).

### 1.2 Purpose

**Problem**: Creating effective presentation slides is time-consuming and requires design skills. Manual design can't match modern AI-powered presentation tools.

**Solution**: AI-generated slide decks that:
- Work for any subject or topic
- Include professional visual design (from simple to stunning)
- Auto-generate layouts, colors, and visual elements
- Provide speaker notes and teaching guidance
- Support multiple presentation styles
- Export to PowerPoint, Google Slides, PDF, HTML

### 1.3 Key Features

1. **Topic-Agnostic**: Works for any content
2. **Multi-Style Design**: Simple → Professional → Stunning (context-appropriate)
3. **Auto-Generation**: Full visual design automation
4. **Multiple Formats**: PowerPoint, Google Slides, PDF, HTML
5. **Speaker Notes**: Detailed teaching guidance
6. **Interactive Elements**: Discussion prompts, polling questions
7. **Visual Asset Integration**: Icons, images, diagrams, charts

---

## 2. DESIGN STYLES & CONTEXTS

### 2.1 Design Style Levels

```typescript
enum DesignStyle {
  SIMPLE = 'simple',           // Clean, minimal, fast generation
  PROFESSIONAL = 'professional', // Business-ready, polished
  STUNNING = 'stunning'         // Highly visual, Gamma.ai/Beautiful.ai style
}

interface StyleSelection {
  context_determines: boolean;
  style_priority: {
    academic_lectures: 'simple' | 'professional';
    conference_presentations: 'professional' | 'stunning';
    sales_pitches: 'stunning';
    classroom_teaching: 'professional';
    webinars: 'professional' | 'stunning';
    student_projects: 'simple' | 'professional';
  };
}
```

### 2.2 Style Characteristics

#### SIMPLE Style
- **Use When**: Quick presentations, academic lectures, draft reviews
- **Features**:
  - Clean layouts, no decorative elements
  - Basic bullet points and headings
  - Minimal images (only when essential)
  - Standard fonts and colors
  - Fast generation (<2 min for 30 slides)
- **Visual Complexity**: Low
- **Generation Cost**: $0.80 per deck

#### PROFESSIONAL Style
- **Use When**: Business meetings, classroom instruction, professional training
- **Features**:
  - Polished layouts with visual hierarchy
  - Professional color schemes
  - Icons and diagrams included
  - Data visualizations (charts/graphs)
  - Balanced text and visuals
  - Consistent branding
- **Visual Complexity**: Medium
- **Generation Cost**: $1.80 per deck

#### STUNNING Style (Gamma.ai/Beautiful.ai equivalent)
- **Use When**: Conference talks, sales presentations, keynotes, high-stakes demos
- **Features**:
  - Stunning visual layouts with gradients, animations
  - AI-generated background images
  - Advanced typography and spacing
  - Animated transitions and effects
  - Rich media integration
  - Interactive elements
  - Full-bleed images and creative layouts
  - Custom illustrations and icons
- **Visual Complexity**: High
- **Generation Cost**: $4.50 per deck

---

## 3. COMPLETE WORKFLOW (6 Phases)

### Phase 1: Content Analysis & Slide Structure Planning (5-8 minutes)

**Purpose**: Analyze book content and determine optimal slide structure, flow, and presentation strategy.

**AI Model**: GPT-4o
**Temperature**: 0.5 (balanced creativity and structure)
**Input Tokens**: ~15,000
**Output Tokens**: ~5,000

**Process**:
1. Read book chapter/section content
2. Identify main concepts and sub-topics
3. Determine logical flow and narrative arc
4. Plan slide count and structure
5. Identify slides needing special treatments (title, question, visual-heavy)
6. Create slide outline with transitions
7. Determine design style (if auto)
8. Output structured slide plan

**Output**: Slide structure plan with titles, types, and transitions

### Phase 2: Slide Content Creation (8-15 minutes for 30 slides)

**Purpose**: Generate concise, engaging content for each slide with proper text hierarchy.

**AI Model**: Claude-3-5-Sonnet-20241022
**Temperature**: 0.6 (clear, concise writing)
**Per-Slide Tokens**: Input ~2,000, Output ~800
**Parallel Processing**: 8 slides concurrently

**Process**:
1. For each slide in the structure:
   - Generate slide title (clear, action-oriented)
   - Create main content (bullets, text, key points)
   - Suggest visual elements (images, icons, diagrams)
   - Write transitions to next slide
   - Identify interactive opportunities
2. Ensure conciseness (max 50 words per slide)
3. Balance text and visual recommendations
4. Maintain consistent tone and style
5. Include engagement hooks

**Output**: Complete slide content with visual recommendations

### Phase 3: Visual Design Generation (Time varies by style)

**Purpose**: Create comprehensive visual design system and slide-specific layouts.

**AI Models**:
- Simple/Professional: GPT-4o
- Stunning: GPT-4o + DALL-E 3

**Simple Style (2-3 minutes)**:
- Basic layout selection
- Standard color scheme
- Minimal visual elements
- Fast export

**Professional Style (6-10 minutes)**:
- Custom layout system
- Professional color palette
- Icon and diagram integration
- Data visualization design
- Polished export

**Stunning Style (15-20 minutes)**:
- Custom visual design system
- Advanced typography
- DALL-E 3 background generation (10-15 images)
- Custom icons and illustrations
- Animation design
- Interactive elements
- Rich media integration

**Output**: Complete design system with slide-specific visual specifications

### Phase 4: Speaker Notes & Teaching Guidance (6-10 minutes)

**Purpose**: Generate detailed speaker notes with teaching tips, timing, and engagement strategies.

**AI Model**: Claude-3-5-Sonnet-20241022
**Temperature**: 0.6
**Input Tokens**: ~40,000 (all slides)
**Output Tokens**: ~15,000

**Process**:
1. For each slide, generate:
   - What to say (talking points, 100-200 words)
   - Why it matters (concept importance)
   - How to present (delivery tips)
   - Estimated timing (1-3 minutes)
   - Engagement strategies (questions, activities)
   - Common misconceptions to address
   - Transition to next slide
2. Add presentation-level guidance:
   - Opening hook strategies
   - Pacing recommendations
   - Audience engagement tips
   - Q&A preparation

**Output**: Comprehensive speaker notes for each slide

### Phase 5: File Generation & Export (3-5 minutes)

**Purpose**: Generate presentation files in multiple formats with full design implementation.

**AI Model**: GPT-4o
**Temperature**: 0.3 (precision for export)
**Input Tokens**: ~60,000 (all content + design)
**Output Tokens**: ~5,000

**Process**:
1. **PowerPoint (.pptx) Generation**:
   - Apply design system
   - Implement layouts
   - Add animations (professional/stunning)
   - Embed fonts
   - Include speaker notes
   - Generate file

2. **PDF Export**:
   - High-resolution render (300 DPI)
   - Optional speaker notes pages
   - Print-ready formatting

3. **Google Slides JSON**:
   - Generate API-compatible JSON
   - Prepare for Google Slides import
   - Include all design specs

4. **HTML5 (Stunning style only)**:
   - Interactive web presentation
   - Keyboard navigation
   - Full-screen support
   - Responsive design

**Output**: Multiple file formats ready for download/distribution

### Phase 6: Quality Verification & Final Polish (2-3 minutes)

**Purpose**: Verify design consistency, content quality, and file integrity.

**AI Model**: Claude-3-5-Sonnet-20241022
**Temperature**: 0.2 (analytical precision)
**Input Tokens**: ~30,000
**Output Tokens**: ~2,000

**Process**:
1. **Content Verification**:
   - Check all slides for text clarity
   - Verify bullet points ≤ 6 per slide
   - Ensure consistent terminology
   - Check for typos

2. **Design Verification**:
   - Verify color consistency
   - Check layout alignment
   - Validate image quality
   - Verify font usage

3. **Technical Verification**:
   - Test file exports
   - Verify animations work
   - Check file sizes
   - Validate speaker notes

4. **Final Polish**:
   - Fix any issues found
   - Optimize file sizes
   - Generate metadata

**Output**: Verified, polished presentation ready for delivery

---

## 4. COMPLETE AI PROMPTS

### Phase 1 Prompt: Content Analysis & Structure Planning

```
ROLE: You are an expert presentation designer and instructional designer with deep knowledge of effective visual communication and audience engagement.

TASK: Analyze the provided book chapter/section and create a comprehensive slide structure plan for a {total_slides}-slide presentation.

CONTEXT:
- Book Title: {book_title}
- Chapter/Section: {content_scope}
- Target Audience: {grade_level}, {context}
- Presentation Duration: {duration_minutes} minutes
- Design Style: {design_style}

CONTENT TO ANALYZE:
{book_content}

INSTRUCTIONS:

1. CONTENT ANALYSIS
   - Identify the main learning objectives (3-5)
   - Extract key concepts and sub-topics
   - Determine the logical flow and narrative arc
   - Identify opportunities for visuals, examples, and engagement

2. SLIDE STRUCTURE PLANNING
   Create a slide-by-slide plan with:

   **Slide 1: Title Slide**
   - Title: [Compelling presentation title]
   - Subtitle: [Context/audience]
   - Visual recommendation: [Background style]

   **Slides 2-{total_slides-2}: Content Slides**
   For each slide, specify:
   - Slide number
   - Slide type: (choose one)
     * content: Standard bullet points/text
     * two_column: Split content
     * visual_focus: Large image with minimal text
     * question: Engagement/discussion prompt
     * diagram: Process/concept visualization
     * comparison: Side-by-side comparison
     * full_bleed: Full-screen impactful image with text overlay
   - Title: [Clear, action-oriented title]
   - Main points: [2-4 key points to cover]
   - Visual element: [What kind of visual would support this? Icons, diagram, photo, chart, etc.]
   - Estimated time: [1-3 minutes]
   - Transition note: [How this connects to next slide]

   **Last Slide: Closing/Summary**
   - Type: summary or call_to_action
   - Key takeaways
   - Next steps or discussion prompts

3. DESIGN STYLE CONSIDERATIONS
   Based on {design_style}:
   - **Simple**: Focus on text clarity, minimal visuals
   - **Professional**: Balance text and visuals, use icons and diagrams
   - **Stunning**: Plan for impactful visuals, custom backgrounds, rich media

4. ENGAGEMENT STRATEGY
   - Identify 3-5 slides for interactive elements (questions, polls, activities)
   - Note opportunities for audience participation
   - Suggest pacing variations (fast vs. deep-dive slides)

5. NARRATIVE ARC
   Ensure the presentation has:
   - Strong opening (hook, relevance)
   - Logical progression (building concepts)
   - Clear transitions between sections
   - Compelling conclusion (takeaways, action items)

OUTPUT FORMAT:
Return a structured JSON object:
{
  "presentation_overview": {
    "title": "...",
    "learning_objectives": ["...", "..."],
    "total_slides": number,
    "estimated_duration_minutes": number,
    "design_style_recommended": "simple|professional|stunning",
    "narrative_arc_summary": "..."
  },
  "slides": [
    {
      "slide_number": 1,
      "slide_type": "title|content|two_column|visual_focus|question|diagram|comparison|full_bleed|summary",
      "title": "...",
      "content_points": ["...", "..."],
      "visual_element_type": "icon|photo|diagram|chart|illustration|background",
      "visual_description": "...",
      "estimated_time_minutes": number,
      "speaker_notes_guidance": "...",
      "interactive_element": "none|question|poll|activity|discussion",
      "transition_to_next": "..."
    },
    ...
  ],
  "engagement_strategy": {
    "interactive_moments": [...],
    "pacing_notes": "...",
    "audience_participation": [...]
  }
}

QUALITY STANDARDS:
- Total slides must be exactly {total_slides}
- Each slide should have clear purpose
- Logical flow with smooth transitions
- Balance of content types (not all bullet points)
- Appropriate visual recommendations
- Realistic timing estimates (total equals {duration_minutes} ±10%)
```

### Phase 2 Prompt: Slide Content Creation (Per Slide)

```
ROLE: You are an expert at creating concise, impactful slide content that engages audiences and communicates clearly.

TASK: Generate the specific content for this slide, following presentation best practices for clarity and engagement.

SLIDE CONTEXT:
- Slide Number: {slide_number} of {total_slides}
- Slide Type: {slide_type}
- Planned Title: {planned_title}
- Main Points: {content_points}
- Visual Element: {visual_element_type} - {visual_description}
- Time Allocation: {estimated_time_minutes} minutes
- Design Style: {design_style}

BOOK CONTENT (relevant section):
{relevant_content}

INSTRUCTIONS:

1. SLIDE TITLE
   Create a clear, engaging title that:
   - Is concise (4-8 words)
   - Uses action words when appropriate
   - Makes the slide's purpose clear
   - Is audience-appropriate for {grade_level}

2. SLIDE CONTENT
   Based on slide type {slide_type}:

   **For "content" slides**:
   - Create 3-5 bullet points
   - Each point: 5-10 words maximum
   - Use parallel structure
   - Start with strong verbs or key terms
   - No sub-bullets (keep it simple)

   **For "two_column" slides**:
   - Left column: 2-3 points
   - Right column: 2-3 points
   - Clear relationship between columns (compare, contrast, cause-effect)

   **For "visual_focus" slides**:
   - Minimal text: One powerful statement (8-12 words)
   - Large, impactful visual is the star

   **For "question" slides**:
   - One clear question
   - Optional: 2-3 thought-provoking sub-questions
   - Leave space for audience response

   **For "diagram" slides**:
   - Clear labels (2-4 words each)
   - Brief explanatory text if needed (10-15 words)
   - Process/relationship indicators

   **For "comparison" slides**:
   - Side-by-side structure
   - Parallel elements
   - 2-4 comparison points per side

3. VISUAL SPECIFICATIONS
   Detailed description of visual element:
   - What to show (be specific)
   - Style/tone of visual
   - Colors that would work
   - Placement on slide
   - Size relative to text

   For {design_style} = "stunning":
   - Provide detailed image generation prompt
   - Specify composition, mood, style
   - Include specific visual elements

4. ENGAGEMENT ELEMENTS
   If {interactive_element} is not "none":
   - Write the specific question/prompt
   - Suggest audience interaction method
   - Provide expected response guidance

5. TEXT OPTIMIZATION
   Ensure:
   - Total text: 30-50 words (content slides)
   - No complete sentences (bullet points are phrases)
   - Active voice
   - Consistent terminology with previous slides
   - Appropriate reading level for {grade_level}

OUTPUT FORMAT:
{
  "slide_number": number,
  "title": "...",
  "content": {
    "type": "bullets|two_column|single_statement|question|diagram_labels|comparison",
    "text_elements": [
      {
        "position": "main|left|right|center|top|bottom",
        "text": "...",
        "format": "bullet|heading|label|statement",
        "font_size_relative": "large|medium|small"
      },
      ...
    ]
  },
  "visual_element": {
    "type": "icon|photo|illustration|diagram|chart|background",
    "description": "...",
    "style": "...",
    "placement": "left|right|center|top|bottom|background|full_bleed",
    "size": "small|medium|large|full_width|full_height",
    "image_generation_prompt": "..." // Only for stunning style
  },
  "interactive_element": {
    "type": "none|question|poll|activity|discussion",
    "prompt_text": "...",
    "interaction_method": "...",
    "expected_duration_seconds": number
  },
  "design_notes": {
    "layout_suggestion": "...",
    "color_emphasis": ["...", "..."],
    "animation_suggestion": "..." // Only for professional/stunning
  }
}

QUALITY STANDARDS:
- Maximum 50 words total text
- Maximum 6 bullet points
- Clear, concise language
- No jargon (unless necessary for {grade_level})
- Specific visual descriptions
- Appropriate for {estimated_time_minutes} minutes presentation time
```

### Phase 4 Prompt: Speaker Notes & Teaching Guidance

```
ROLE: You are an expert educator and presentation coach who helps speakers deliver engaging, effective presentations.

TASK: Generate comprehensive speaker notes for this slide that guide the presenter on what to say, how to engage the audience, and how to maximize learning.

SLIDE INFORMATION:
- Slide Number: {slide_number} of {total_slides}
- Title: {slide_title}
- Content: {slide_content}
- Visual Elements: {visual_elements}
- Interactive Element: {interactive_element}
- Estimated Time: {estimated_time_minutes} minutes
- Audience: {grade_level}, {context}

BOOK CONTENT (relevant section for depth):
{book_content_section}

INSTRUCTIONS:

1. WHAT TO SAY (Main Talking Points)
   Write 100-200 words that:
   - Expand on the bullet points with examples and details
   - Tell a story or provide context
   - Use conversational language
   - Include specific numbers, facts, or examples from the book
   - Make connections to real-world applications
   - Use analogies or metaphors where helpful

2. WHY IT MATTERS (Significance & Relevance)
   Explain (50-75 words):
   - Why this slide's content is important
   - How it connects to learning objectives
   - Real-world relevance for {grade_level} audience
   - How it builds on previous slides
   - What comes next and why

3. HOW TO PRESENT (Delivery Tips)
   Provide specific advice:
   - Pacing: How fast/slow to go through this slide
   - Emphasis: Which points to stress
   - Body language: Gestures, movement suggestions
   - Voice modulation: Where to pause, raise/lower volume
   - Visual interaction: When to point to elements

4. ENGAGEMENT STRATEGIES
   For this specific slide:
   - Ask a specific question to the audience (provide the exact question)
   - Suggest an interaction technique (think-pair-share, poll, show of hands, etc.)
   - Provide a relevant example or story to share
   - Note common misconceptions to address
   - Suggest a memory hook or mnemonic

5. TIMING GUIDANCE
   Break down {estimated_time_minutes} minutes:
   - Introduction/hook: X seconds
   - Main content delivery: X seconds
   - Interaction/discussion: X seconds
   - Transition: X seconds

6. TRANSITIONS
   Provide specific language for:
   - Opening this slide (connect from previous)
   - Closing this slide (bridge to next)
   - Ensure smooth narrative flow

7. COMMON QUESTIONS & RESPONSES
   Anticipate 2-3 questions audience might ask:
   - Question: "..."
   - Suggested response: "..."

8. ADDITIONAL RESOURCES
   If relevant:
   - Suggest supplementary materials
   - Mention related topics for deeper exploration
   - Note where to find more information in the book

OUTPUT FORMAT:
{
  "slide_number": number,
  "speaker_notes": {
    "talking_points": "...", // 100-200 words
    "key_messages": ["...", "...", "..."], // 3-5 main points
    "examples_to_share": ["...", "..."],
    "analogies": ["..."],

    "significance": {
      "why_important": "...",
      "learning_objective_alignment": "...",
      "real_world_relevance": "...",
      "connection_to_previous": "...",
      "preview_of_next": "..."
    },

    "delivery_guidance": {
      "pacing": "slow|moderate|quick",
      "emphasis_points": ["...", "..."],
      "body_language": "...",
      "voice_modulation": "...",
      "visual_interaction": "..."
    },

    "engagement": {
      "question_to_ask": "...",
      "interaction_technique": "...",
      "story_or_example": "...",
      "common_misconceptions": ["...", "..."],
      "memory_hook": "..."
    },

    "timing": {
      "intro_seconds": number,
      "content_delivery_seconds": number,
      "interaction_seconds": number,
      "transition_seconds": number,
      "total_seconds": number
    },

    "transitions": {
      "opening_line": "...",
      "closing_line": "...",
      "connection_to_previous": "...",
      "bridge_to_next": "..."
    },

    "anticipated_questions": [
      {
        "question": "...",
        "suggested_response": "..."
      },
      ...
    ],

    "additional_resources": {
      "book_references": ["Page X", "Chapter Y"],
      "supplementary_topics": ["...", "..."],
      "further_exploration": "..."
    }
  }
}

QUALITY STANDARDS:
- Conversational, natural language (not formal/stiff)
- Specific, actionable guidance (not generic tips)
- Appropriate depth for {grade_level}
- Realistic timing (must sum to {estimated_time_minutes} minutes)
- Smooth transitions that maintain narrative flow
- Practical engagement strategies that work in {context}
```

---

## 5. FALLBACK RULES & ERROR HANDLING

### 5.1 Model Fallback Configuration

```typescript
interface FallbackConfig {
  phase_1_content_structuring: {
    primary: 'gpt-4o',
    fallback_1: 'claude-3-5-sonnet-20241022',
    fallback_2: 'gpt-4-turbo',
    retry_attempts: 3,
    backoff_multiplier: 2,
    timeout_ms: 60000
  },

  phase_2_slide_content: {
    primary: 'claude-3-5-sonnet-20241022',
    fallback_1: 'gpt-4o',
    fallback_2: 'gpt-4-turbo',
    retry_attempts: 2,
    parallel_timeout_ms: 15000
  },

  phase_3_visual_design: {
    simple_professional: {
      primary: 'gpt-4o',
      fallback_1: 'claude-3-5-sonnet-20241022',
      retry_attempts: 2
    },
    stunning: {
      primary: 'gpt-4o',
      fallback_1: 'claude-3-5-sonnet-20241022',
      image_generation: {
        primary: 'dall-e-3',
        fallback: 'use_stock_photos',
        fallback_sources: ['unsplash', 'pexels', 'pixabay']
      },
      retry_attempts: 2
    }
  },

  phase_4_speaker_notes: {
    primary: 'claude-3-5-sonnet-20241022',
    fallback_1: 'gpt-4o',
    retry_attempts: 2,
    timeout_ms: 45000
  },

  phase_5_export: {
    primary: 'gpt-4o',
    fallback: 'use_templates',
    retry_attempts: 1
  }
}
```

### 5.2 Error Handling

```typescript
enum PresentationError {
  CONTENT_ANALYSIS_FAILED = 'Failed to analyze content',
  SLIDE_GENERATION_FAILED = 'Failed to generate slide content',
  DESIGN_GENERATION_FAILED = 'Failed to generate visual design',
  IMAGE_GENERATION_FAILED = 'Failed to generate images',
  EXPORT_FAILED = 'Failed to export presentation file',
  INVALID_DESIGN_STYLE = 'Invalid design style specified',
  INSUFFICIENT_CONTENT = 'Insufficient content for requested slide count',
  TOKEN_LIMIT_EXCEEDED = 'Content exceeds token limits'
}

interface ErrorRecovery {
  strategy: 'retry' | 'fallback_model' | 'simplify_request' | 'use_cache' | 'fail';
  max_attempts: number;
  recovery_action: string;
}
```

---

## 6. VERIFICATION & QUALITY GATES

### Phase 1 Verification (Structure Planning)
- ✅ Total slides matches requested count (±2 acceptable)
- ✅ All slides have titles and types
- ✅ Total estimated time within 10% of target duration
- ✅ Logical flow with clear transitions
- ✅ Mix of slide types (not all "content")
- ✅ Visual elements recommended for 80%+ of slides
- **Threshold**: 0.90

### Phase 2 Verification (Slide Content)
- ✅ All slides have content
- ✅ Text per slide ≤ 50 words
- ✅ Bullet points ≤ 6 per slide
- ✅ Titles are concise (4-10 words)
- ✅ Visual specifications are specific
- ✅ Language appropriate for grade level
- **Threshold**: 0.92

### Phase 3 Verification (Visual Design)
- ✅ Consistent design system applied
- ✅ Color palette harmonious
- ✅ Layouts appropriate for slide types
- ✅ Visual elements match recommendations
- ✅ Images high quality (if generated)
- ✅ Animations appropriate (professional/stunning)
- **Threshold**: 0.88

### Phase 4 Verification (Speaker Notes)
- ✅ All slides have speaker notes
- ✅ Notes are 100-250 words per slide
- ✅ Timing estimates realistic
- ✅ Engagement strategies specific
- ✅ Transitions smooth and logical
- **Threshold**: 0.90

### Phase 5 Verification (Export)
- ✅ Files generated successfully
- ✅ All requested formats present
- ✅ Files open without errors
- ✅ Design integrity maintained
- ✅ Speaker notes included (where applicable)
- ✅ File sizes reasonable
- **Threshold**: 0.95

---

## 7. DEPENDENCIES MATRIX

```
Phase 1 (Structure) → Phase 2 (Content) → Phase 3 (Design) → Phase 5 (Export)
                                              ↓
                                         Phase 4 (Speaker Notes) → Phase 6 (Verification)

Parallel Opportunities:
- Phase 2 slides can be generated in parallel (8 concurrent)
- Phase 3 and Phase 4 can run in parallel (design + speaker notes)
- Phase 5 exports can be generated in parallel (multiple formats)
```

---

## 8. INPUT/OUTPUT SPECIFICATIONS

### Input Schema

```typescript
interface PresentationRequest {
  book_id: string;
  content_scope: 'chapter' | 'section' | 'topic';

  presentation_preferences: {
    total_slides: number; // 10-50
    presentation_style: 'lecture' | 'interactive' | 'flipped' | 'discovery';
    design_style: 'simple' | 'professional' | 'stunning' | 'auto';
    include_images: boolean;
    include_animations: boolean;
    auto_generate_visuals: boolean;
  };

  target_audience: {
    grade_level: string;
    presentation_duration_minutes: number;
    context: 'classroom' | 'conference' | 'webinar' | 'sales' | 'training';
  };

  design_preferences?: {
    color_scheme: 'professional' | 'vibrant' | 'minimal' | 'academic' | 'brand';
    brand_colors?: string[];
    font_style: 'modern' | 'classic' | 'dyslexia_friendly' | 'bold';
    visual_density: 'minimal' | 'balanced' | 'rich';
  };
}
```

### Output Schema

```typescript
interface PresentationOutput {
  metadata: {
    presentation_id: string;
    title: string;
    total_slides: number;
    design_style_used: DesignStyle;
    estimated_duration_minutes: number;
    generation_time_seconds: number;
  };

  slides: Slide[];

  design_system: {
    color_palette: ColorPalette;
    typography: TypographySystem;
    spacing: SpacingSystem;
    visual_style: VisualStyleGuide;
  };

  files_generated: {
    powerpoint_file: GeneratedFile;
    pdf_file: GeneratedFile;
    google_slides_json: GeneratedFile;
    html_version?: GeneratedFile;
  };

  visual_assets: {
    custom_images: ImageAsset[];
    icons_used: IconAsset[];
    diagrams: DiagramAsset[];
    charts: ChartAsset[];
  };
}

interface Slide {
  slide_number: number;
  slide_type: 'title' | 'content' | 'two_column' | 'visual_focus' | 'question' | 'diagram' | 'comparison' | 'full_bleed' | 'summary';
  title: string;
  content: SlideContent;
  speaker_notes: SpeakerNotes;
  design_specs: DesignSpec;
  estimated_time_minutes: number;
  visual_design: VisualDesign;
}
```

---

## 9. IMPLEMENTATION GUIDE

### TypeScript Class Structure

```typescript
class PresentationGenerator {
  constructor(
    private aiOrchestrator: AIOrchestrator,
    private imageGenerator: ImageGenerator,
    private exportEngine: ExportEngine
  ) {}

  async generatePresentation(
    request: PresentationRequest
  ): Promise<PresentationOutput> {
    console.log('Starting presentation generation:', request.book_id);

    // Phase 1: Structure Planning
    const structure = await this.phase1_structurePlanning(request);

    // Phase 2: Slide Content (parallel)
    const slideContent = await this.phase2_generateSlideContent(request, structure);

    // Phases 3 & 4 can run in parallel
    const [visualDesign, speakerNotes] = await Promise.all([
      this.phase3_generateVisualDesign(request, slideContent),
      this.phase4_generateSpeakerNotes(request, slideContent)
    ]);

    // Phase 5: Export (parallel formats)
    const files = await this.phase5_exportFiles(request, {
      slideContent,
      visualDesign,
      speakerNotes
    });

    // Phase 6: Verification
    const verified = await this.phase6_verify({
      structure,
      slideContent,
      visualDesign,
      speakerNotes,
      files
    });

    // Save to database
    await this.savePresentation(verified);

    return verified;
  }

  private async phase1_structurePlanning(
    request: PresentationRequest
  ): Promise<PresentationStructure> {
    const bookContent = await this.getBookContent(request.book_id);

    const prompt = this.buildPhase1Prompt(request, bookContent);

    const result = await this.aiOrchestrator.complete({
      model: 'gpt-4o',
      temperature: 0.5,
      messages: [{ role: 'user', content: prompt }],
      timeout: 60000
    });

    const structure = JSON.parse(result.content);

    // Validate structure
    if (structure.slides.length !== request.presentation_preferences.total_slides) {
      throw new Error('Slide count mismatch');
    }

    return structure;
  }

  private async phase2_generateSlideContent(
    request: PresentationRequest,
    structure: PresentationStructure
  ): Promise<SlideContent[]> {
    const slides = structure.slides;
    const batchSize = 8; // Process 8 slides in parallel

    const slideContent: SlideContent[] = [];

    for (let i = 0; i < slides.length; i += batchSize) {
      const batch = slides.slice(i, i + batchSize);

      const batchResults = await Promise.all(
        batch.map(slide => this.generateSingleSlide(request, slide))
      );

      slideContent.push(...batchResults);
    }

    return slideContent;
  }

  private async generateSingleSlide(
    request: PresentationRequest,
    slide: StructuredSlide
  ): Promise<SlideContent> {
    const prompt = this.buildPhase2Prompt(request, slide);

    const result = await this.aiOrchestrator.complete({
      model: 'claude-3-5-sonnet-20241022',
      temperature: 0.6,
      messages: [{ role: 'user', content: prompt }],
      timeout: 15000
    });

    return JSON.parse(result.content);
  }

  private async phase3_generateVisualDesign(
    request: PresentationRequest,
    slideContent: SlideContent[]
  ): Promise<VisualDesign> {
    const designStyle = this.determineDesignStyle(request);

    switch (designStyle) {
      case 'simple':
        return this.generateSimpleDesign(slideContent);
      case 'professional':
        return this.generateProfessionalDesign(slideContent);
      case 'stunning':
        return this.generateStunningDesign(request, slideContent);
      default:
        throw new Error(`Unknown design style: ${designStyle}`);
    }
  }

  private async generateStunningDesign(
    request: PresentationRequest,
    slideContent: SlideContent[]
  ): Promise<VisualDesign> {
    // Generate custom design system
    const designSystem = await this.createDesignSystem(request);

    // Generate custom images with DALL-E 3
    const imagesToGenerate = slideContent
      .filter(slide => slide.visual_element?.image_generation_prompt)
      .slice(0, 15); // Limit to 15 images

    const customImages = await Promise.all(
      imagesToGenerate.map(slide =>
        this.imageGenerator.generate({
          prompt: slide.visual_element.image_generation_prompt,
          size: '1792x1024',
          quality: 'hd'
        })
      )
    );

    // Apply design system to all slides
    const visualDesign = {
      design_system: designSystem,
      slide_designs: slideContent.map((slide, idx) => ({
        slide_number: idx + 1,
        layout: this.selectLayout(slide.type, designSystem),
        background: this.createBackground(slide, designSystem, customImages[idx]),
        typography: this.applyTypography(slide, designSystem),
        animations: this.createAnimations(slide, 'stunning')
      })),
      custom_images: customImages
    };

    return visualDesign;
  }

  private async phase5_exportFiles(
    request: PresentationRequest,
    data: {
      slideContent: SlideContent[];
      visualDesign: VisualDesign;
      speakerNotes: SpeakerNotes[];
    }
  ): Promise<GeneratedFiles> {
    // Export in parallel
    const [pptx, pdf, googleSlides, html] = await Promise.all([
      this.exportEngine.toPowerPoint(data),
      this.exportEngine.toPDF(data),
      this.exportEngine.toGoogleSlidesJSON(data),
      request.presentation_preferences.design_style === 'stunning'
        ? this.exportEngine.toHTML5(data)
        : Promise.resolve(null)
    ]);

    return { pptx, pdf, googleSlides, html };
  }
}
```

---

## 10. DATABASE SCHEMA

```sql
CREATE TABLE presentation_slides (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id UUID REFERENCES books(id),

  -- Metadata
  title TEXT NOT NULL,
  total_slides INTEGER NOT NULL,
  design_style TEXT NOT NULL CHECK (design_style IN ('simple', 'professional', 'stunning')),
  presentation_style TEXT NOT NULL,
  context TEXT NOT NULL,

  -- Audience
  grade_level TEXT NOT NULL,
  duration_minutes INTEGER NOT NULL,

  -- Content
  slides JSONB NOT NULL,
  design_system JSONB NOT NULL,
  speaker_notes JSONB NOT NULL,

  -- Visual Assets
  custom_images JSONB,
  visual_assets JSONB,

  -- Files
  powerpoint_url TEXT,
  pdf_url TEXT,
  google_slides_json JSONB,
  html_url TEXT,

  -- Generation Tracking
  generation_duration_seconds INTEGER,
  ai_models_used JSONB,
  cost_usd DECIMAL(10, 4),
  quality_score DECIMAL(3, 2),

  -- Timestamps
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_presentation_slides_book ON presentation_slides(book_id);
CREATE INDEX idx_presentation_slides_design_style ON presentation_slides(design_style);
CREATE INDEX idx_presentation_slides_created ON presentation_slides(created_at DESC);

-- RLS Policies
ALTER TABLE presentation_slides ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view presentations"
  ON presentation_slides FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "System can insert presentations"
  ON presentation_slides FOR INSERT
  TO authenticated
  WITH CHECK (true);
```

---

## 11. COST ANALYSIS

### Token Usage & Cost by Style (30-Slide Deck)

#### Simple Style
| Phase | Model | Input | Output | Cost |
|-------|-------|-------|--------|------|
| Phase 1 | GPT-4o | 15,000 | 5,000 | $0.063 |
| Phase 2 (×30) | Claude-3-5-Sonnet | 60,000 | 24,000 | $0.614 |
| Phase 3 | GPT-4o | 20,000 | 8,000 | $0.100 |
| Phase 4 | Claude-3-5-Sonnet | 40,000 | 15,000 | $0.414 |
| **TOTAL** | | **135,000** | **52,000** | **$1.19** |

**Total Cost**: $1.40 (with overhead)
**Retail Price**: $6.99
**Margin**: 80% ($5.59 profit)

#### Professional Style
| Phase | Model | Input | Output | Cost |
|-------|-------|-------|--------|------|
| Phase 1 | GPT-4o | 15,000 | 5,000 | $0.063 |
| Phase 2 (×30) | Claude-3-5-Sonnet | 60,000 | 24,000 | $0.614 |
| Phase 3 | GPT-4o | 35,000 | 15,000 | $0.200 |
| Phase 4 | Claude-3-5-Sonnet | 40,000 | 15,000 | $0.414 |
| Phase 5 | GPT-4o | 60,000 | 5,000 | $0.175 |
| **TOTAL** | | **210,000** | **64,000** | **$1.47** |

**Total Cost**: $1.80 (with overhead)
**Retail Price**: $12.99
**Margin**: 86% ($11.19 profit)

#### Stunning Style (Full Auto-Generation)
| Phase | Model | Input | Output | Cost |
|-------|-------|-------|--------|------|
| Phase 1 | GPT-4o | 15,000 | 5,000 | $0.063 |
| Phase 2 (×30) | Claude-3-5-Sonnet | 60,000 | 24,000 | $0.614 |
| Phase 3 | GPT-4o | 50,000 | 25,000 | $0.350 |
| Phase 3b | DALL-E 3 (15 images) | - | - | $0.600 |
| Phase 4 | Claude-3-5-Sonnet | 40,000 | 15,000 | $0.414 |
| Phase 5 | GPT-4o | 80,000 | 8,000 | $0.260 |
| **TOTAL** | | **245,000** | **77,000** | **$2.30** |

**Total Cost**: $4.50 (with DALL-E + overhead)
**Retail Price**: $24.99
**Margin**: 82% ($20.49 profit)

---

## 12. TESTING REQUIREMENTS

### Unit Tests
- Content structure generation for various book types
- Slide content generation with different design styles
- Visual design system creation
- Speaker notes generation
- File export for all formats

### Integration Tests
- Full workflow: book → presentation (all styles)
- Parallel slide generation
- Design system application across all slides
- Multi-format export
- Database save and retrieval

### Quality Tests
- Verify slide count accuracy
- Verify text limits (50 words per slide)
- Verify bullet point limits (6 max)
- Verify timing estimates realistic
- Verify file integrity for all formats
- Verify speaker notes completeness

### Performance Tests
- 30-slide simple style generation < 3 minutes
- 30-slide professional style generation < 10 minutes
- 30-slide stunning style generation < 30 minutes
- Parallel slide generation scales linearly
- Export generation < 5 minutes

---

## 13. ERROR HANDLING

```typescript
enum PresentationError {
  CONTENT_ANALYSIS_FAILED = 'Failed to analyze book content',
  STRUCTURE_GENERATION_FAILED = 'Failed to generate slide structure',
  SLIDE_CONTENT_FAILED = 'Failed to generate slide content',
  DESIGN_GENERATION_FAILED = 'Failed to generate visual design',
  IMAGE_GENERATION_FAILED = 'Failed to generate custom images',
  SPEAKER_NOTES_FAILED = 'Failed to generate speaker notes',
  EXPORT_FAILED = 'Failed to export presentation file',
  INVALID_DESIGN_STYLE = 'Invalid design style specified',
  INSUFFICIENT_CONTENT = 'Book content too short for requested slides',
  SLIDE_COUNT_MISMATCH = 'Generated slides do not match requested count',
  TOKEN_LIMIT_EXCEEDED = 'Content exceeds AI model token limits',
  FILE_TOO_LARGE = 'Generated file exceeds size limits'
}

class PresentationErrorHandler {
  async handleError(error: PresentationError, context: any): Promise<void> {
    switch (error) {
      case PresentationError.IMAGE_GENERATION_FAILED:
        // Fall back to stock photos
        return this.useStockPhotos(context);

      case PresentationError.DESIGN_GENERATION_FAILED:
        // Fall back to simple design
        return this.useSimpleDesign(context);

      case PresentationError.EXPORT_FAILED:
        // Retry with template-based export
        return this.useTemplateExport(context);

      case PresentationError.SLIDE_COUNT_MISMATCH:
        // Regenerate with corrected count
        return this.regenerateStructure(context);

      default:
        throw error;
    }
  }
}
```

---

## 14. EXAMPLES

### Example 1: Simple Style (Mathematics Lecture)

**Context**: High school algebra, 20 slides, 40-minute class

**Generated Slides**:
1. Title: "Linear Equations"
2. "What is a Linear Equation?"
   - Definition
   - General form: y = mx + b
   - Components explained
3. "Slope (m)"
   - Rate of change
   - Rise over run
   - Positive vs negative
4. [Question Slide] "What does slope tell us?"
5. "Y-Intercept (b)"
   - Starting point
   - Where line crosses y-axis
   ...

**Design**: Clean white background, black text, minimal images, standard fonts

**Cost**: $1.40 | **Retail**: $6.99

---

### Example 2: Professional Style (Business Training)

**Context**: Corporate training, 25 slides, 60-minute session

**Generated Slides**:
1. [Title with corporate colors] "Project Management Fundamentals"
2. [Two-column] "Traditional vs. Agile"
   - Left: Waterfall characteristics
   - Right: Agile characteristics
3. [Visual focus] Large diagram showing project lifecycle
4. [Content] "5 Key PM Principles"
   - Icons next to each principle
   - Professional color scheme
5. [Chart] "Project Success Metrics"
   - Bar chart showing statistics
   ...

**Design**: Professional color palette, icons throughout, charts and diagrams, balanced layouts

**Cost**: $1.80 | **Retail**: $12.99

---

### Example 3: Stunning Style (Conference Keynote)

**Context**: Tech conference, 30 slides, 45-minute keynote

**Generated Slides**:
1. [Full-bleed image] "The Future of AI in Education"
   - Custom DALL-E 3 background: futuristic classroom
   - Large, bold typography
   - Gradient overlay
2. [Visual impact] Single powerful statistic
   - "85% of jobs in 2030 don't exist yet"
   - Abstract background with data visualization theme
3. [Animated diagram] AI integration ecosystem
   - Custom illustration showing connections
   - Elements animate in sequence
4. [Image focus] Student using AI tool
   - Custom generated image
   - Minimal text overlay
5. [Two-column visual] Before/After comparison
   - Split-screen custom images
   - Smooth transition effect
   ...

**Design**: Custom color palette, 15 DALL-E 3 images, advanced typography, smooth animations, full-bleed layouts, gradient backgrounds

**Cost**: $4.50 | **Retail**: $24.99

---

## 15. FEATURE SUMMARY

### ✅ What This Addon Does

1. **Content Structuring**: Organizes any content into effective slides
2. **Design Generation**: Creates visual designs from simple to stunning
3. **Auto-Layout**: Applies professional layouts automatically
4. **Visual Assets**: Generates/sources images, icons, diagrams, charts
5. **Animation Design**: Adds transitions and effects
6. **Speaker Notes**: Provides detailed teaching guidance
7. **Multi-Format Export**: PowerPoint, Google Slides, PDF, HTML5
8. **Context-Aware**: Automatically selects appropriate design level
9. **Brand-Ready**: Supports custom colors, fonts, logos
10. **Interactive Elements**: Includes polls, questions, discussion prompts

### 🎨 Design Capabilities

- **Simple**: Clean, fast, academic-ready (2 min, $1.40, $6.99 retail)
- **Professional**: Polished, business-ready (8 min, $1.80, $12.99 retail)
- **Stunning**: Gamma.ai equivalent (25 min, $4.50, $24.99 retail)

---

**SPECIFICATION COMPLETE**
**Status**: Production Ready
**Total Lines**: 1,286
**Completeness**: 95%
