# COUNTRY LANGUAGE DATABASE - DOCUMENTATION GUIDE

This folder contains comprehensive documentation of ALL languages spoken at large in every country worldwide.

---

## 🎯 PURPOSE

Document every language that requires country-specific content translation for each of the 195 countries.

---

## 📋 DOCUMENTATION RULES

### For EACH country, we must research and document:

1. **Official National Languages**
   - Languages with official status at the national level
   - **Always include in translations**

2. **Official Regional Languages**
   - Languages with official status in specific states/provinces/regions
   - **Always include in translations**

3. **Major Spoken Languages (5%+ of population)**
   - Languages spoken by at least 5% of the population
   - **Always include in translations**

4. **Educationally Significant Languages**
   - Languages used in schools and educational institutions
   - Languages used in higher education
   - Languages used in vocational training
   - **Include if significant**

5. **Institutionally Used Languages**
   - Languages used in government services
   - Languages required by law for public services
   - Languages used in courts
   - **Include if required by law or widely used**

6. **Minority Languages with Protection Status**
   - Languages protected by national or international law
   - Languages with cultural preservation status
   - **Include if legally protected or culturally significant**

---

## ✅ INCLUSION CRITERIA

A language should be included if it meets ANY of these criteria:

- ✅ Official national language
- ✅ Official regional language
- ✅ Spoken by 5%+ of population
- ✅ Used in educational institutions
- ✅ Required by law for government services
- ✅ Legally protected minority language
- ✅ Used in more than one state/province
- ✅ Significant cultural/historical importance

---

## ❌ EXCLUSION CRITERIA

A language should typically be excluded if:

- ❌ Less than 1% of population
- ❌ No educational use
- ❌ No institutional use
- ❌ No legal protection or requirement
- ❌ Isolated to single small community
- ❌ Primarily spoken by non-citizen populations (unless significant)

**Exception:** Even small languages may be included if they have legal protection or significant cultural importance.

---

## 📝 DOCUMENTATION FORMAT

For each country, document:

```markdown
## [Country Name]

**Population:** [total population]
**Number of Languages:** [count]
**ISO Code:** [ISO 3166-1]

### Official Languages
1. **[Language Name]**
   - Status: National Official
   - Speakers: [count] ([percentage]%)
   - Regions: Nationwide
   - Priority: Critical

2. **[Language Name]**
   - Status: Regional Official ([regions])
   - Speakers: [count] ([percentage]%)
   - Regions: [list regions]
   - Priority: Critical

### Major Languages (5%+)
3. **[Language Name]**
   - Speakers: [count] ([percentage]%)
   - Regions: [list regions]
   - Educational Use: Yes/No
   - Institutional Use: Yes/No
   - Priority: High

### Significant Languages (1-5%)
4. **[Language Name]**
   - Speakers: [count] ([percentage]%)
   - Regions: [list regions]
   - Educational Use: Yes/No
   - Institutional Use: Yes/No
   - Legal Status: Protected/Standard
   - Priority: Medium/Low

### Summary
- **Total Languages for Translation:** [count]
- **Critical Priority:** [count] (official languages)
- **High Priority:** [count] (major languages 5%+)
- **Medium/Low Priority:** [count] (significant languages)
```

---

## 🌍 FILE ORGANIZATION

Languages are organized by continent:

- **africa_countries.md** - All 54 African countries
- **asia_countries.md** - All 48 Asian countries
- **europe_countries.md** - All 44 European countries (includes Russia west of Urals)
- **north_america_countries.md** - All 23 North American countries
- **south_america_countries.md** - All 12 South American countries
- **oceania_countries.md** - All 14 Oceania countries

**Total: 195 countries**

---

## 🔢 EXPECTED LANGUAGE COUNTS

### Typical Ranges:
- **Single Language Countries:** 1-2 languages (rare)
  - Examples: Japan, Iceland, Portugal

- **Low Diversity Countries:** 2-5 languages (common)
  - Examples: USA, Canada, France, Germany, Australia

- **Medium Diversity Countries:** 5-15 languages (common)
  - Examples: India, Switzerland, Spain, China, South Africa

- **High Diversity Countries:** 15-30 languages (less common)
  - Examples: Indonesia, Philippines, Nigeria, Mexico

- **Extreme Diversity Countries:** 30-100+ languages (rare)
  - Examples: Papua New Guinea (select 15-25 most widely spoken)
  - Examples: Cameroon, DR Congo (select 10-20 most widely spoken)

### Special Cases:
For countries with extreme linguistic diversity (100+ languages), we select:
- All official languages
- All languages with 2%+ of population
- Top 15-25 most widely-spoken languages
- All languages used in education
- All languages required by law

**Rationale:** Even in highly diverse countries, most education happens in 10-20 dominant languages.

---

## 🎯 PRIORITY LEVELS

**Critical Priority:**
- Official national languages
- Official regional languages
- **Must be included**

**High Priority:**
- Languages with 5%+ of population
- Languages widely used in education
- **Should be included**

**Medium Priority:**
- Languages with 2-5% of population
- Languages with institutional use
- Protected minority languages
- **Include if resources allow**

**Low Priority:**
- Languages with 1-2% of population
- Languages with cultural significance but limited use
- **Include for completeness**

---

## ✅ VERIFICATION CHECKLIST

For each country, verify:

- [ ] All official national languages documented
- [ ] All official regional languages documented
- [ ] All languages with 5%+ population documented
- [ ] Educational language use researched
- [ ] Institutional language use researched
- [ ] Legal language requirements researched
- [ ] Speaker counts and percentages calculated
- [ ] Regional distribution documented
- [ ] Priority levels assigned
- [ ] Total language count confirmed

---

## 📚 RESEARCH SOURCES

Recommended sources for language documentation:

1. **Ethnologue** (ethnologue.com) - Comprehensive language database
2. **UNESCO Atlas of Languages** - Language endangerment status
3. **CIA World Factbook** - Official languages and demographics
4. **National Census Data** - Most accurate speaker counts
5. **Constitutional Documents** - Legal language status
6. **Education Ministry Websites** - Languages used in schools
7. **Wikipedia Language Demographics** - Good starting point

---

## 🚀 WORKFLOW

1. **Research Phase**
   - Research each country's languages
   - Identify all qualifying languages
   - Gather speaker statistics

2. **Documentation Phase**
   - Document in appropriate continent file
   - Use standardized format
   - Include all required data

3. **Database Phase**
   - Enter data into Supabase
   - Link to country and region tables
   - Verify data integrity

4. **Review Phase**
   - Cross-check data
   - Verify completeness
   - Confirm priority assignments

---

## 📊 STATUS TRACKING

**Countries Documented:** 0/195
**Languages Documented:** 0/~1,200-1,500 estimated
**Database Entries Created:** 0

---

## 🔗 RELATED FILES

- Parent documentation: `/pipelines/PIPELINE_12_COUNTRY_SPECIFIC_CONTENT.md`
- Database schema: `/supabase/migrations/20251219224014_create_global_country_content_system.sql`
- This will integrate with the existing 195 countries table
