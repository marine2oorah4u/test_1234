# PIPELINES vs USER GROUPS - COMPLETE CLARIFICATION
**Purpose:** Clear separation between what we MAKE (Pipelines) vs who we SELL TO (User Groups)
**Last Updated:** 2025-12-30

---

## 🔑 KEY DISTINCTION

### PIPELINES = WHAT WE MAKE
**Pipelines are AUTOMATED WORKFLOWS that generate content**

- Pipeline 1: Master Book Generation
- Pipeline 2: Reading Level Adaptations
- etc.

### USER GROUPS = WHO WE SELL TO
**User Groups are CUSTOMER SEGMENTS that buy our products**

- Individual Learners
- Schools
- Homeschools
- Libraries
- Corporate Training
- etc.

---

## ✅ CONFIRMED PIPELINES (1-12)

### Pipeline 1: Master Book Generation (75-90 min)
**Input:** Topic
**Output:** 1 master reference book
**Status:** ✅ Fully documented

### Pipeline 2: Reading Level Adaptations (5.25-7 hours)
**Input:** Master book
**Output:** 8 reading levels (K through PhD + Plain Language + Quick Reference)
**Status:** ✅ Fully documented

### Pipeline 3: Disability Adaptations (20-33 hours)
**Input:** All 8 reading level books
**Output:** 40 disability types × 8 reading levels = 320 versions
**Status:** ✅ Fully documented (40 disability pipelines)

### Pipeline 4: Format Conversions (1.2-2.3 hours)
**Input:** All 328 books
**Output:** 7 formats each = 2,296 files (PDF, EPUB, HTML, Audio, DOCX, Markdown, LaTeX)
**Status:** ✅ Fully documented (34 formats total)

### Pipeline 5: Educational Addons (3.3-5.3 hours)
**Input:** Master book
**Output:** 8 addon types (Activity Packs, Worksheets, Quizzes, Answer Keys, Lesson Plans, Slides, Career Guides, Study Guides)
**Status:** ✅ Fully documented (739 features cataloged)

### Pipeline 6: Educator Packages (2-3 hours)
**Input:** Master book + addons
**Output:** 3 packages (Complete Curriculum, Quick Start Kit, Professional Development)
**Status:** ✅ Fully documented

### Pipeline 7: Interactive Elements (4.5-7 hours)
**Input:** Master book
**Output:** 6 types (Embedded quizzes, exercises, simulations, virtual labs, code sandboxes, assessments)
**Status:** ✅ Fully documented

### Pipeline 8: Binder Books (3.3-6.7 hours)
**Input:** Master book + reading levels + addons
**Output:** 4 editions (Student, Teacher, Workbook, Complete Reference)
**Status:** ✅ Fully documented

### Pipeline 9: Translations (variable)
**Input:** All content from Pipelines 1-8
**Output:** 6,000 languages across 4 tiers
**Status:** ✅ Fully documented

### Pipeline 10: Online Course Packaging (15-30 min per course)
**Input:** Topics grouped into courses
**Output:** ~50,000 courses (SCORM, xAPI, LMS-ready with gamification)
**Status:** ✅ Fully documented

### Pipeline 11: Special Collections (45-90 min per collection)
**Input:** Topics with substantial research
**Output:** Encyclopedia articles, museum exhibits, research guides, primary sources, cultural heritage
**Status:** ✅ Fully documented

### Pipeline 12: Country-Specific Content (30-60 min per country)
**Input:** Master book
**Output:** Localized for 195 countries (examples, context, regulations, datasets)
**Status:** ⚠️ Mentioned in docs but NOT fully detailed like others

---

## ❓ UNCLEAR PIPELINES (13-14+)

### What We Found in OLD Documentation:

**OLD Pipeline 13: Advanced Interactive Addons**
- 255 features mentioned
- Interactive simulations, virtual labs, drag-drop, timelines, clickable diagrams, maps, calculators, quiz games, flashcards, puzzles, video lessons, audio lessons, 3D models, code editors
- Plus specialized editions: binder books, workbooks, physical flashcards, posters

**USER NOTE:** "arent we already doing this in online courses? i dont think this is needed"
**STATUS:** ❌ May be REJECTED if redundant with Pipelines 5, 7, 10

---

**OLD Pipeline 14: Career/Jobs/Trades Professional Training**
- Global Job Catalog (50,000+ jobs × 195 countries)
- Career Pathways (structured learning paths)
- Skills Taxonomy (10,000+ skills)
- Educational Content ↔ Career Linking
- Career Guides, Job Market Data, Country-specific codes
- Trade & Vocational Training

**USER NOTE:** "pipeline 14 is the careers stuff"
**STATUS:** ❓ User says Pipeline 14 IS careers, but also suggested Youth Programs could be Pipeline 14

---

## 🆕 NEW PIPELINE PROPOSALS (USER INPUT TODAY)

### USER WANTS:
1. **Youth/Scouts as Separate Pipeline** - "separate dashboard, not tied to book generation"
2. **Homeschool Curriculum as Pipeline** ✅ CONFIRMED
3. **Religion Pipeline** - "maybe we can do this as its own pipeline yes"

### WHERE DO THESE FIT?

**Option A: They are NEW pipelines (13, 14, 15, 16+)**
- Pipeline 13: User Group Packaging System
- Pipeline 14: Youth Programs (Scouts, 4-H, etc.) - Separate Dashboard
- Pipeline 15: Religious & Spiritual Education
- Pipeline 16: Homeschool Curriculum Packages

**Option B: They are DELIVERY SYSTEMS, not generation pipelines**
- Same content library
- Different dashboards/access methods
- Different packaging
- Different features enabled

---

## 🤔 THE CONFUSION

### User said:
> "you have Pipeline 14 = Youth Programs (Scouts, Boys & Girls Clubs, etc.)
> but pipeline 14 is the careers stuff, unless u made the youth pipeline 14"

### And also:
> "13 was youth stuff or scouts
> 14 was i forget. u have a readme though for it right?"

**ISSUE:** We have conflicting information about what Pipelines 13-14 actually are!

---

## 📋 25 USER GROUPS (NOT PIPELINES)

These are CUSTOMER SEGMENTS who buy our products:

**CONFIRMED (18 groups):**
1. ✅ Individual Learners
2. ✅ Traditional Schools (K-12)
3. ✅ Homeschools
4. ✅ Teachers & Educators
5. ✅ School Districts
6. ✅ Higher Education
7. ✅ Corporate Training
8. ✅ Libraries
9. ✅ Community Organizations (Boys & Girls Clubs, YMCA, 4-H)
10. ✅ Disability Services
11. ✅ Workforce Development
12. ✅ Military & Veterans (Veterans confirmed, Active Duty TBD)
13. ✅ International Markets
14. ✅ Specialized Programs (Gifted, ELL, Credit Recovery)
15. ✅ Adult Education Centers
16. ✅ Trade Unions

**CONDITIONAL (3 groups - need expert review):**
17. ⚠️ Healthcare Training (medical accuracy critical)
18. ⚠️ Sports Organizations (safety/medical critical)
19. ⚠️ Military Active Duty (need DoD approval)

**CONSIDERING (7 groups - need more research):**
20. 🤔 Correctional Education
21. 🤔 Museums & Cultural Institutions
22. 🤔 Test Prep Centers
23. 🤔 Eldercare & Senior Centers
24. 🤔 Refugee Resettlement
25. 🤔 Foster Care & Child Welfare
26. 🤔 Tribal Education

---

## 🎯 WHAT WE NEED FROM USER

### 1. Confirm Actual Pipelines 1-12
Are these correct:
- ✅ Pipelines 1-11 as documented?
- ❓ Pipeline 12: Country-Specific Content (needs full blueprint)?

### 2. Decide on Pipelines 13-14
**Option A:** Keep OLD definitions
- Pipeline 13: Advanced Interactive Addons (255 features)
- Pipeline 14: Career/Jobs/Trades System

**Option B:** Replace with NEW priorities
- Pipeline 13: Something else?
- Pipeline 14: Youth Programs (Scouts) - Separate Dashboard

### 3. Clarify Youth Programs & Scouts
User said: "separate process or dashboard thing for it, vs being tied in with book generation"

**IS THIS:**
- **Option A:** NEW Pipeline (generates youth-specific content)?
- **Option B:** DELIVERY SYSTEM (same content, different dashboard)?
- **Option C:** USER GROUP (customer segment, not a pipeline)?

### 4. Clarify Homeschool Curriculum
User confirmed: "yes lets make homeschool a pipeline"

**IS THIS:**
- **Option A:** NEW Pipeline that GENERATES homeschool curriculum?
- **Option B:** PACKAGING of existing content into curriculum?
- **Option C:** USER GROUP feature (same content, organized differently)?

### 5. Religion Pipeline
User said: "religion we would look into, but i feel we can do it as its own pipeline yes"

**WHAT DOES THIS GENERATE:**
- Multi-faith education content?
- Sacred texts study materials?
- Religious history courses?
- Ethical frameworks?
- Age-appropriate religious education?

### 6. Career Content
User mentioned earlier conversation about Career Pathway Collections being different from Pipeline 5 Career Guides

**CLARIFY:**
- Is there a separate CAREER PIPELINE?
- Or is career content part of Pipeline 5 (Career Guides addon)?
- Or is it Pipeline 14?

---

## 💡 PROPOSED SOLUTION

### KEEP: Pipelines 1-12 as documented
These are the CORE GENERATION PIPELINES

### CREATE: New category "Specialized Delivery Systems"
These use the SAME content library but have:
- Different dashboards
- Different packaging
- Different features
- Different access models

**Specialized Delivery Systems:**
- Youth Programs (Scouts, 4-H, Boys & Girls Clubs)
- Homeschool Curriculum Packages
- Religious Education Programs
- Career Pathways System
- Any other specialized delivery

### KEEP: User Groups as Customer Segments
These are WHO WE SELL TO, not what we make

---

## 🔥 QUESTIONS FOR USER

1. **Are Pipelines 1-11 correct as documented?**

2. **What is Pipeline 12?** (Country-Specific Content or something else?)

3. **What were Pipelines 13-14 originally supposed to be?**

4. **Should Youth/Scouts be:**
   - A. New generation pipeline (creates youth content)?
   - B. Specialized delivery system (same content, different dashboard)?
   - C. Just a user group (customer segment)?

5. **Should Homeschool be:**
   - A. New generation pipeline?
   - B. Packaging system for existing content?
   - C. Just a user group?

6. **Should Religion be a generation pipeline?** If yes, what does it generate?

7. **Where does Career content fit?**
   - Pipeline 5 (Career Guides addon)?
   - Separate Career Pipeline?
   - Something else?

8. **Do you want to:**
   - A. Add more generation pipelines (13, 14, 15+)?
   - B. Keep 1-12 and create "delivery systems" instead?
   - C. Both?

---

## 📊 SUMMARY

**WE HAVE:**
- ✅ Pipelines 1-11: Fully documented
- ❓ Pipeline 12: Mentioned but not fully detailed
- ❓ Pipelines 13-14: Conflicting information
- ✅ 25 User Groups: Customer segments (who we sell to)

**WE NEED:**
- Clarify what Pipelines 12-14 actually are
- Decide if Youth/Scouts/Homeschool/Religion are:
  - Generation pipelines (create new content types)?
  - Delivery systems (organize existing content)?
  - User groups (customer segments)?
- Finalize the pipeline list
- Create detailed blueprints for any new pipelines

**NEXT STEP:** User answers questions above, then we can finalize and document everything properly!
