# USER GROUP 26: IMMIGRANTS & NEW ARRIVALS

**Status:** Phase 2-3, Medium Priority
**Last Updated:** 2025-12-30

---

## 📋 OVERVIEW

Specialized content and packaging for immigrants, refugees, visa holders, and new arrivals to a country. Focuses on language learning, cultural adaptation, job skills, and legal information.

---

## 🎯 TARGET POPULATIONS

### Immigration Categories:
- **Recent immigrants** (green card holders)
- **Refugees** (fleeing persecution/war)
- **Asylum seekers** (waiting for status)
- **Visa holders** (student, work, family)
- **Undocumented** (no legal status, need education)
- **Temporary protected status** (TPS holders)
- **DACA recipients** (childhood arrivals)

### Countries of Origin:
- **Top 20 sending countries** (Mexico, China, India, Philippines, etc.)
- **All 195 countries** (comprehensive coverage)
- **Refugee populations** (Syria, Afghanistan, Myanmar, etc.)

### English Proficiency:
- **Beginner** (just arrived, minimal English)
- **Intermediate** (conversational)
- **Advanced** (fluent but academic gaps)
- **Native speakers** (immigrants from English-speaking countries)

---

## 📚 CONTENT FOCUS AREAS

### 1. ENGLISH LANGUAGE LEARNING (Priority #1!)

**ESL/ESOL Content:**
- **Survival English** (first 100 words, basic phrases)
- **Daily life vocabulary** (grocery, doctor, school, work)
- **Grammar** (step-by-step, practical)
- **Pronunciation** (audio support)
- **Reading comprehension**
- **Writing skills**
- **Listening practice**
- **Speaking practice** (conversation scenarios)

**Specialized Vocabulary:**
- **Job-specific English** (healthcare, construction, hospitality)
- **Academic English** (for students)
- **Legal English** (immigration paperwork)
- **Technology English** (computer, smartphone)

### 2. CULTURAL ADAPTATION

**Understanding New Culture:**
- **Social norms** (greetings, personal space, eye contact)
- **Cultural values** (individualism vs. collectivism, time, directness)
- **Holidays & traditions** (what Americans celebrate)
- **Food & dining** (grocery stores, restaurants, tipping)
- **Clothing & dress codes** (casual vs. formal)
- **Communication styles** (direct vs. indirect)

**Practical Life Skills:**
- **Using public transportation** (bus, subway, train)
- **Opening bank account** (checking, savings, credit)
- **Getting driver's license** (DMV process, rules of road)
- **Renting apartment** (lease, utilities, rights)
- **Healthcare system** (insurance, finding doctor, emergency)
- **Education system** (enrolling kids, PTA, report cards)
- **Legal system** (rights, police interactions, courts)

### 3. JOB READINESS & CAREER

**Finding Work:**
- **Resume writing** (American format)
- **Cover letters**
- **Job search** (online, networking, agencies)
- **Interview skills** (common questions, cultural expectations)
- **Workplace culture** (punctuality, communication, teamwork)
- **Workers' rights** (minimum wage, breaks, safety, discrimination)

**Career Advancement:**
- **Skill development** (technical, soft skills)
- **Certifications** (credentials recognized in new country)
- **Professional networking** (LinkedIn, professional groups)
- **Continuing education** (community college, training programs)
- **Entrepreneurship** (starting small business)

### 4. LEGAL INFORMATION

**Immigration Status:**
- **Understanding visa type** (rights, restrictions)
- **Path to citizenship** (green card → citizenship process)
- **Maintaining status** (what you must do)
- **Family reunification** (bringing relatives)
- **Rights & responsibilities** (what you can/cannot do)

**Legal Rights:**
- **Employment rights** (wages, safety, discrimination)
- **Housing rights** (fair housing, eviction process)
- **Education rights** (children have right to school regardless of status)
- **Healthcare rights** (emergency care, Medicaid)
- **Consumer protection** (avoiding scams)
- **Domestic violence resources** (safety, support)

**⚠️ LEGAL DISCLAIMER:**
- Information is educational only
- Not legal advice
- Recommend consulting immigration attorney
- Provide referrals to legal aid

### 5. FAMILY & CHILDREN

**Parenting in New Country:**
- **School system** (K-12, how it works)
- **Helping with homework** (even if you don't speak English well)
- **Parent-teacher communication**
- **After-school activities** (sports, clubs)
- **Child safety** (laws about leaving kids alone, car seats)

**Supporting Children:**
- **Language development** (maintaining home language while learning English)
- **Cultural identity** (being bicultural)
- **Academic success** (navigating school system)
- **College preparation** (financial aid, applications)

---

## 🌍 LOCALIZATION BY COUNTRY

### Country of Origin:
- **Language** (all materials in native language + English)
- **Cultural context** (examples relevant to home country)
- **Comparative information** ("In China schools work like this, in U.S. they work like this")

### Country of Destination:
- **Local information** (specific to state/province/city)
- **Local resources** (immigrant services in area)
- **Local laws** (vary by state/province)
- **Local job market** (industries hiring, wages)

---

## 📱 DELIVERY FORMAT

### Digital-First:
- **Mobile app** (most immigrants have smartphones)
- **Offline access** (download lessons)
- **Audio support** (for non-readers)
- **Translation toggle** (switch between languages)
- **Low data usage** (works on limited plans)

### Community Access:
- **Library kiosks** (public access)
- **Resettlement agency** (partner organizations)
- **Community centers** (group classes)
- **Churches/mosques** (community gathering places)

---

## 🤝 PARTNERSHIPS

### Organizations:
- **Refugee resettlement agencies** (IRC, USCRI, LIRS, etc.)
- **Adult education centers** (ESL classes)
- **Community colleges** (workforce programs)
- **Libraries** (free computer/internet access)
- **Legal aid organizations** (immigration law)
- **Ethnic community organizations** (cultural support)

---

## 💾 DATABASE STRUCTURE

See migration file: `add_pipelines_32_37_and_user_groups_26_28.sql`

Table: `immigrant_content_packages`

Tracks:
- Target audience (refugees, students, workers, etc.)
- Language pairs (origin → destination)
- English proficiency level
- Content focus (language, culture, jobs, legal)
- Cultural sensitivity review

---

## 🔄 RELATIONSHIP TO OTHER CONTENT

### Uses Existing Content:
- **Pipeline 1** (Master Books) - Educational content
- **Pipeline 2** (Reading Levels) - ESL-friendly versions
- **Pipeline 5** (Addons) - Activity packs, worksheets
- **Pipeline 9** (Translations) - Native language materials
- **Pipeline 12** (Country-Specific) - Local adaptation
- **Pipeline 19** (Life Skills) - Practical content

### Additional Unique Content:
- ESL/ESOL curriculum
- Cultural adaptation guides
- Legal information
- Immigration-specific resources

---

## 📈 MARKET OPPORTUNITY

### U.S. Market:
- **45 million immigrants** (13.7% of population)
- **1 million new arrivals/year** (average)
- **25 million limited English proficiency**
- **$2 billion ESL market**

### Global Market:
- **280 million international migrants** worldwide
- Growing in Canada, Australia, Europe
- Refugee crises (ongoing need)

### Our Advantage:
- **Comprehensive** (language + culture + jobs + legal)
- **Affordable** (vs. expensive ESL programs)
- **Accessible** (mobile, offline)
- **Integrated** (connects to full education platform)

---

## 💰 MONETIZATION

### Direct to Consumer:
- **Free tier** (basic survival English)
- **Premium** ($9.99/month) (full program)
- **Family** ($14.99/month) (multiple learners)

### Organizations:
- **Resettlement agencies** ($5,000-25,000/year)
- **Adult ed centers** ($10,000-50,000/year)
- **Libraries** (bundled with library licensing)

### Grant Funding:
- Department of Health & Human Services (refugee programs)
- Department of Education (adult ed)
- Foundations (immigrant support)
- Often free to end users (grant-funded)

---

## 🚀 IMPLEMENTATION TIMELINE

### Phase 1: Foundation (6-12 months)
- Top 10 languages
- Core ESL curriculum
- Basic cultural adaptation
- Job readiness basics

### Phase 2: Expansion (12-24 months)
- All major languages (50+)
- Comprehensive cultural content
- Legal information library
- Community partnerships

### Phase 3: Comprehensive (24-36 months)
- All 195 countries
- Advanced career content
- Specialized pathways
- Deep local customization

---

## 📝 CULTURAL SENSITIVITY REQUIREMENTS

**CRITICAL - Must Review:**
- ✅ Avoid stereotypes about countries/cultures
- ✅ Respect religious/cultural differences
- ✅ Acknowledge trauma (many refugees experienced violence)
- ✅ Non-judgmental (no "American way is better")
- ✅ Inclusive (various countries, religions, family structures)
- ✅ Accurate (don't oversimplify cultural differences)
- ✅ Empowering (not deficit-focused)

**Review by:**
- Immigrants from target communities
- Resettlement professionals
- Cultural liaisons
- Translation accuracy experts

---

## 🔗 RELATED DOCUMENTATION

- Database migration: `/database_migrations_ready_to_apply/add_pipelines_32_37_and_user_groups_26_28.sql`
- Master user groups list: `/pipelines/COMPLETE_USER_GROUPS_AND_CONTEXTS.md`
- Implementation tracking: (Create when starting implementation)

---

**Ready to implement when you reach this user group in your development schedule.**
